

GuiRadarCtrl and GuiRadarTSCtrl port for T3D
http://www.garagegames.com/community/resources/view/19519