//-----------------------------------------------------------------------------
// Torque Game Engine Advanced v1.0
// Copyright (C) GarageGames.com, Inc.
// Convertion to TGEA 1.8.1 with karakurty
//-----------------------------------------------------------------------------
#include "platform/platform.h"

#include "gui/core/guiControl.h"
#include "gfx/gfxDrawUtil.h"
#include "T3D/player.h"

#include "console/console.h"
#include "console/consoleTypes.h"
#include "gfx/gfxDevice.h"
#include "app/game.h"
#include "T3D/gameBase/gameConnection.h"
#include "T3D/ShapeBase.h"
#include "gfx/primBuilder.h"

#include "GuiRadarCtrl.h"

IMPLEMENT_CONOBJECT(GuiRadarCtrl);

GuiRadarCtrl::GuiRadarCtrl(void)
{
	// Radar Background default
	mRadarBitmapName = StringTable->insert("art/gui/compass_map_radar/radar_base.png");

	// Blip defaults
	mBlipUpName = StringTable->insert("art/gui/compass_map_radar/dot_teal.png");
	mBlipBelowName = StringTable->insert("art/gui/compass_map_radar/dot_black.png");
	mBlipLevelName = StringTable->insert("art/gui/compass_map_radar/dot_red.png");
	mShowRadar = true;
	//mRadarWrap = false;
	mRadarRadiusRange = 100.0f;

	mLevelRange = 20.0f;

	// As default show only players
	mShowShapeBase = false;
	mShowVehicles = false;
	mShowPlayers = true;
    mShowBots = true;

	// Compass defaults
	mCompassBitmapName = StringTable->insert("art/gui/compass_map_radar/compass.png");
	mShowCompass = true;

	mCompassRotation = 0.0f;

	// <MH>
	// Map defaults
	mMapBitmapName = StringTable->insert("art/gui/compass_map_radar/scorchedPlanet.png");
	mShowMap = true;
	// </MH>

	mHideAll = false;
}


void GuiRadarCtrl::initPersistFields()
{
   Parent::initPersistFields();

    addGroup("Radar");
    addField("RadarBitmap",		TypeFilename,	  Offset(mRadarBitmapName,    GuiRadarCtrl));
    //addField("RadarWrap",		TypeBool,		  Offset(mRadarWrap,          GuiRadarCtrl));
    addField("blip_above",		TypeFilename,     Offset(mBlipUpName,         GuiRadarCtrl));
	addField("blip_below",		TypeFilename,     Offset(mBlipBelowName,      GuiRadarCtrl));
	addField("blip_level",		TypeFilename,     Offset(mBlipLevelName,      GuiRadarCtrl));
	addField("RadarRange",		TypeF32,		  Offset(mRadarRadiusRange,   GuiRadarCtrl));
	addField("ShowRadar",		TypeBool,		  Offset(mShowRadar,          GuiRadarCtrl));
	endGroup("Radar");
   
	addGroup("Compass");
	addField("CompassBitmap",	TypeFilename,	Offset(mCompassBitmapName, GuiRadarCtrl));
	addField("ShowCompass",		TypeBool,		Offset(mShowCompass,       GuiRadarCtrl),"Show Compass)");
    endGroup("Compass");		

	// <MH>
	addGroup("Map");
	addField("MapBitmap",		TypeFilename,	Offset(mMapBitmapName,    GuiRadarCtrl));
	addField("ShowMap",			TypeBool,		Offset(mShowMap,		  GuiRadarCtrl), "Show Map");
    endGroup("Map");	
	// </MH>
	
	addGroup("Misc");
	addField("RadarShowPlayers",	TypeBool,     Offset(mShowPlayers,     GuiRadarCtrl),"Show Players on Radar");
	addField("RadarShowVehicles",	TypeBool,     Offset(mShowVehicles,    GuiRadarCtrl),"Show Vehicles on Radar");
    addField("RadarShowBots",		TypeBool,     Offset(mShowBots,        GuiRadarCtrl),"Show Bots on Radar");
	addField("RadarShowShapeBase",	TypeBool,     Offset(mShowShapeBase,   GuiRadarCtrl),"Show All ShapeBase derived objects on Radar");
	addField("LevelRange",			TypeS32,      Offset(mLevelRange,      GuiRadarCtrl),"The height difference at which the Level blip is displayed");
	addField("HideAll",				TypeBool,     Offset(mHideAll,         GuiRadarCtrl));
	addField("ShowFrame",			TypeBool,     Offset(mShowFrame,       GuiRadarCtrl));
	endGroup("Misc");
}

ConsoleMethod( GuiRadarCtrl, setValue, void, 4, 4, "(int xAxis, int yAxis)"
              "Set the offset of the bitmap.")
{
	object->setValue(dAtoi(argv[2]), dAtoi(argv[3]));
}

ConsoleMethod( GuiRadarCtrl, setRadarBitmap, void, 3, 4, "(string filename, bool resize=false)"
               "Set the bitmap displayed in the control. Note that it is limited in size, to 256x256.")
{
   char fileName[1024];
   Con::expandScriptFilename(fileName, sizeof(fileName), argv[2]);
   object->setRadarBitmap(fileName, argc > 3 ? dAtob( argv[3] ) : false );
}

ConsoleMethod( GuiRadarCtrl, setRadarRange, void, 3, 3, "")
{
	Con::printf("Object->SetRadius = %f", dAtof(argv[2]));
	object->setRadius(dAtof(argv[2]));
}

bool GuiRadarCtrl::onWake()
{
   if (! Parent::onWake())
      return false;
   
	setActive(true);
    setRadarBitmap(mRadarBitmapName);
	setRadarUpBlipBitmap(mBlipUpName);
	setRadarBelowBlipBitmap(mBlipBelowName);
	setRadarLevelBlipBitmap(mBlipLevelName);
	setRadius(mRadarRadiusRange);
	setLevelRange(mLevelRange);
	setCompassBitmap(mCompassBitmapName);
	setMapBitmap(mMapBitmapName);

   return true;
}

void GuiRadarCtrl::onSleep()
{
    //Parent::onSleep();

    mRadarTextureObject = NULL;
	mRadarDot = NULL;
	mRadarUp = NULL;
	mRadarDown = NULL;

	mCompassTextureObject = NULL;
	mMapTextureObject = NULL;

    Parent::onSleep();
}

//-------------------------------------
void GuiRadarCtrl::inspectPostApply()
{
   // if the extent is set to (0,0) in the gui editor and appy hit, this control will
   // set it's extent to be exactly the size of the bitmap (if present)
   Parent::inspectPostApply();

   if ((getExtent().y == 0) && (getExtent().x == 0) && mRadarTextureObject)
   {
	   setExtent(mRadarTextureObject->getWidth(), mRadarTextureObject->getHeight());
   }

   if ((getExtent().y == 0) && (getExtent().x == 0) && mCompassTextureObject)
   {
	   //setExtent(mCompassTextureObject->getWidth(), mCompassTextureObject->getHeight());
   	   setExtent(mRadarTextureObject->getWidth(), mRadarTextureObject->getHeight());
   }

}

void GuiRadarCtrl::setRadarBitmap(const char *name, bool resize)
{
   mRadarBitmapName = StringTable->insert(name);
   if (*mRadarBitmapName)
	{
		mRadarTextureObject.set( mRadarBitmapName, &GFXDefaultGUIProfile, avar("%s() - mRadarTextureObject (line %d)", __FUNCTION__, __LINE__) );

      // Resize the control to fit the bitmap
      if( mRadarTextureObject && resize )
      {
	     setExtent(mRadarTextureObject->getWidth(), mRadarTextureObject->getHeight());
         updateSizing();

      }
   }
   else
      mRadarTextureObject = NULL;

   setUpdate();
}

void GuiRadarCtrl::setRadarLevelBlipBitmap(const char *name)
{
   mBlipLevelName = StringTable->insert(name);
   if (*mBlipLevelName)
		mRadarDot.set( mBlipLevelName, &GFXDefaultGUIProfile, avar("%s() - mRadarDot (line %d)", __FUNCTION__, __LINE__) );
   else
      mRadarDot = NULL;

   setUpdate();
}

void GuiRadarCtrl::setRadarUpBlipBitmap(const char *name)
{

   mBlipUpName = StringTable->insert(name);
   if (*mBlipUpName)
		mRadarUp.set( mBlipUpName, &GFXDefaultGUIProfile, avar("%s() - mRadarUp (line %d)", __FUNCTION__, __LINE__) );
   else
      mRadarUp = NULL;

   setUpdate();

}

void GuiRadarCtrl::setRadarBelowBlipBitmap(const char *name)
{

   mBlipBelowName = StringTable->insert(name);
   if (*mBlipBelowName)
		mRadarDown.set( mBlipBelowName, &GFXDefaultGUIProfile, avar("%s() - mRadarDown (line %d)", __FUNCTION__, __LINE__) );
   else
      mRadarDown = NULL;

   setUpdate();
}

void GuiRadarCtrl::setCompassBitmap(const char *name, bool resize)
{
   mCompassBitmapName = StringTable->insert(name);
   if (*mCompassBitmapName)
	{
		mCompassTextureObject.set( mCompassBitmapName, &GFXDefaultGUIProfile, avar("%s() - mCompassTextureObject (line %d)", __FUNCTION__, __LINE__) );

      // Resize the control to fit the bitmap
      if( mCompassTextureObject && resize )
      {
		 setExtent(mCompassTextureObject->getWidth(), mCompassTextureObject->getHeight());
         updateSizing();
      }
   }
   else
      mCompassTextureObject = NULL;

   setUpdate();
}

// <MH>
void GuiRadarCtrl::setMapBitmap(const char *name)
{
   mMapBitmapName = StringTable->insert(name);

   if (*mMapBitmapName)
		mMapTextureObject.set( mMapBitmapName, &GFXDefaultGUIProfile, avar("%s() - mMapTextureObject (line %d)", __FUNCTION__, __LINE__) );
   else
      mMapTextureObject = NULL;

   setUpdate();
}
// </MH>

void GuiRadarCtrl::setRadius(const F32 newRange)
{
	mRadarRadiusRange = newRange;
}

void GuiRadarCtrl::setLevelRange(const F32 newLevelRange)
{
	mLevelRange = newLevelRange;
}

void GuiRadarCtrl::setCompassRotation(const F32 rotation)
{
	mCompassRotation = rotation;
}

ConsoleMethod( GuiRadarCtrl, setCompassRotation, void, 3, 3, "")
{
	Con::printf("Object->SetRadius = %f", dAtof(argv[2]));
	object->setCompassRotation(dAtof(argv[2]));
}

float Vector3dToDegree(Point3F vector)
{
    float angle;
	if (vector.x == 0.0F)
    {
        if (vector.y > 0.0F)
            return 0.0F;
        else if (vector.y == 0.0F)
            return -1.0F;
        else
            return 180.0F;
    }
    if (vector.y == 0.0F)
    {
        if (vector.x < 0.0F)
            return 270.0F;
        else
            return 90.0F;
    }
    angle = atanf((vector.x) / (-vector.y)) * (180.0F / M_PI);
    if ((-vector.y) < 0.0F)
        return angle + 180.0F;
    else
    {
        if (vector.x > 0.0F)
            return angle;
        else
            return angle + 360.0F;
    }
}

// Conversion function, Degrees to vector (used after manipulating camera angle to represent angle of object on radar)
void DegreeToVector2d(float angle, float length, Point3F &vector)
{
	angle = (angle / 180.0F) * M_PI;
    vector.x = length * (sin(angle) );
	vector.y = length * (-cos(angle) );
}

void GuiRadarCtrl::onRender(Point2I offset, const RectI &updateRect)
{
	// Must have a connection
	GameConnection* conn = GameConnection::getConnectionToServer();
	if (!conn) return;
	// Must have controlled object
	GameBase* control = conn->getControlObject();
	if (!control) return;

	//Find distance from top-left corner to center of radar image 
	Point2F center(getExtent().x / 2, getExtent().y / 2); 

	F32 HW = getExtent().y / 2.0;

	//Make center the UI object's coordinate center 
	center.x += getBounds().point.x; 
	center.y += getBounds().point.y; 


    MatrixF cam;
	VectorF camDir;
	Point3F cameraRot;

    conn->getControlCameraTransform(0,&cam);	// store camera information
    cam.getColumn(3, &mMyCoords);				// get camera position
    cam.getColumn(1, &camDir);					// get camera vector
	cam.getRow(1,&cameraRot);					// get camera rotation

	// Remove Rotation around the X/Y axis
	//cameraRot.x = 0;
	//cameraRot.y = 0;
	
	cameraRot.neg();							// bug forces us to need to invert camera rotation angle

	// get angle that camera is facing
	float cameraAngle = Vector3dToDegree(cameraRot);

	if (mMapTextureObject && mShowMap)
    {
		GFX->getDrawUtil()->clearBitmapModulation();

        GFXTextureObject* texture = mMapTextureObject;

        setupStateBlocks();
        GFX->setStateBlock(mBeforeStateBlock);

		GFX->setTexture( 0, texture );
        GFX->disableShaders();
		
    	F32 width = getBounds().extent.x * 0.5;

		MatrixF rotMatrix(EulerF(0.0, 0.0, mDegToRad(cameraAngle)));

//		Point3F offset(offset.x + mBounds.extent.x / 2, offset.y + mBounds.extent.y / 2, 0.0);
		Point3F offset( offset.x + getBounds().extent.x / 2, offset.y + getBounds().extent.y / 2, 0.0);

		// The 8 will help model the scale of which the player moves across the map
		Point2F offsetTexture(mMyCoords.x / ((float)mMapTextureObject->getBitmapWidth() * 8), 
							 -mMyCoords.y / ((float)mMapTextureObject->getBitmapHeight() * 8));

//		F32 uvOffset = (float)mBounds.extent.x / (float)mMapTextureObject->getBitmapWidth() / 2;
		F32 uvOffset = (float)getBounds().extent.x / (float)mMapTextureObject->getBitmapWidth() / 2;

		// Octagons Vertices
		Point3F points[10];
		points[0] = Point3F(0.0f, 0.0f, 0.0f);
		points[1] = Point3F(0.0f, width, 0.0f);
		points[2] = Point3F(width * 0.7f, width * 0.7f, 0.0f);
		points[3] = Point3F(width, 0.0f, 0.0f);
		points[4] = Point3F(width * 0.7f, -width * 0.7f, 0.0f);
		points[5] = Point3F(0.0f, -width, 0.0f);
		points[6] = Point3F(-width * 0.7f, -width * 0.7f, 0.0f);
		points[7] = Point3F(-width, 0.0f, 0.0f);
		points[8] = Point3F(-width * 0.7f, width * 0.7f, 0.0f);
		points[9] = Point3F(0.0f, width, 0.0f);

		for (int i = 0; i < 10; i++)
		{
			rotMatrix.mulP(points[i]);
			points[i] += offset;
		}

		PrimBuild::color3f(1.0f, 1.0f, 1.0f);

		PrimBuild::begin(GFXTriangleFan, 10);
		PrimBuild::texCoord2f(offsetTexture.x + 0.0f, offsetTexture.y + 0.0f);
		PrimBuild::vertex3fv(points[0]);
		PrimBuild::texCoord2f(offsetTexture.x + 0.0f, offsetTexture.y + uvOffset);
		PrimBuild::vertex3fv(points[1]);
		PrimBuild::texCoord2f(offsetTexture.x + uvOffset * 0.7f, offsetTexture.y + uvOffset * 0.7f);
		PrimBuild::vertex3fv(points[2]);
		PrimBuild::texCoord2f(offsetTexture.x + uvOffset, offsetTexture.y + 0.0f);
		PrimBuild::vertex3fv(points[3]);
		PrimBuild::texCoord2f(offsetTexture.x + uvOffset * 0.7f, offsetTexture.y + -uvOffset * 0.7f);
		PrimBuild::vertex3fv(points[4]);
		PrimBuild::texCoord2f(offsetTexture.x + 0.0f, offsetTexture.y + -uvOffset);
		PrimBuild::vertex3fv(points[5]);
		PrimBuild::texCoord2f(offsetTexture.x + -uvOffset * 0.7f, offsetTexture.y + -uvOffset * 0.7f);
		PrimBuild::vertex3fv(points[6]);
		PrimBuild::texCoord2f(offsetTexture.x + -uvOffset, offsetTexture.y + 0.0f);
		PrimBuild::vertex3fv(points[7]);
		PrimBuild::texCoord2f(offsetTexture.x + -uvOffset * 0.7f, offsetTexture.y + uvOffset * 0.7f);
		PrimBuild::vertex3fv(points[8]);
		PrimBuild::texCoord2f(offsetTexture.x + 0.0f, offsetTexture.y + uvOffset);
		PrimBuild::vertex3fv(points[9]);
		PrimBuild::end();


		GFX->setStateBlock(mBlendDisabledStateBlock);
	}

	if (mRadarTextureObject && mShowRadar)
    {
        GFX->getDrawUtil()->clearBitmapModulation();

        RectI rect(offset, getExtent());
        GFX->getDrawUtil()->drawBitmapStretch(mRadarTextureObject, rect);
    }

	GFX->getDrawUtil()->clearBitmapModulation();

	GFXTextureObject* LevelBlip = (GFXTextureObject*) mRadarDot;
	GFXTextureObject* HighBlip = (GFXTextureObject*) mRadarUp;
	GFXTextureObject* LowBlip = (GFXTextureObject*) mRadarDown;	

	// Go through all ghosted objects on connection (client-side)
	for (SimSetIterator itr(conn); *itr; ++itr) {
      // Make sure that the object is a ShapeBase object
      if ((*itr)->getTypeMask() & ShapeBaseObjectType) {
         ShapeBase* shape = static_cast<ShapeBase*>(*itr);
		 // Make sure that the object isn't the client
		 if (shape != control  && shape->getShapeName()) { 
			// Make sure the ShapeBase object is a player

			 if (shape->getTypeMask()) {
					
				   //ONly check when ShapeBase is not selecting, we are after all iterating through ShapeBaseObjects
					if (!mShowShapeBase)
					{
						if (!mShowPlayers && shape->getTypeMask() == PlayerObjectType)
							continue;

						if (!mShowVehicles && shape->getTypeMask() == VehicleObjectType) 
							continue;

                        if (!mShowBots && shape->getTypeMask() == AIObjectType)
                            continue;
					}

					Point3F newCoord;
   					// Get coords of player object
					newCoord = shape->getPosition();

					// Find distance from point A (player object) to point B (client's player)
					VectorF shapeDir = newCoord - mMyCoords;

					// Test to see if player object in range (deal with squared objects in cheap way to use non-negative value)
					F32 shapeDist = shapeDir.lenSquared();
					if (shapeDist == 0 || shapeDist > (mRadarRadiusRange * mRadarRadiusRange))
						continue;

					// Convert map coordinates to screen coordinates
					newCoord.x -= mMyCoords.x;
					newCoord.y -= mMyCoords.y;
					newCoord.y = -newCoord.y;
					
					float coord_z = newCoord.z - mMyCoords.z; 

					newCoord.z = 0;

					// Adjust object's vector to represent rotation of camera
					float objectAngle = Vector3dToDegree(newCoord);
					float length = newCoord.len()*HW/mRadarRadiusRange;
					DegreeToVector2d(((360-objectAngle)+(cameraAngle) ), length, newCoord);
					
					newCoord.x = -newCoord.x;

					// Add tour calculation to the centre of the GuiControl
					newCoord.x += (center.x);
					newCoord.y += (center.y);
						
					// Draw radar blips based on height
					if(coord_z < F32(0 - mLevelRange)){
						if (LowBlip) 
						{
							GFX->getDrawUtil()->drawBitmap(LowBlip, Point2I(newCoord.x,newCoord.y));
						}
					}
					else if(coord_z > mLevelRange){
						if (HighBlip) 
						{
							GFX->getDrawUtil()->drawBitmap(HighBlip, Point2I(newCoord.x,newCoord.y));
						}
					}
					else{
						if (LevelBlip) 
						{
							GFX->getDrawUtil()->drawBitmap(LevelBlip, Point2I(newCoord.x,newCoord.y));
						}
					}
					}
				}
			}
		}

   if (mProfile->mBorder || !mRadarTextureObject)
   {
		if (mShowFrame)
		{
			RectI rect(offset.x, offset.y, getExtent().y, getExtent().x);
			GFX->getDrawUtil()->drawRect(rect, mProfile->mBorderColor);
		}
   }
	
   if (mCompassTextureObject && mShowCompass)
   {

		GFX->getDrawUtil()->clearBitmapModulation();

		GFXTextureObject* texture = mCompassTextureObject;

        setupStateBlocks();
        GFX->setStateBlock(mBeforeStateBlock);

		GFX->setTexture( 0, texture );
		GFX->disableShaders();

		F32 width = getExtent().y * 0.5;

		MatrixF rotMatrix( EulerF( 0.0, 0.0, mDegToRad(cameraAngle)));

		Point3F offset( offset.x + getExtent().y / 2,
			offset.y + getExtent().x / 2, 0.0);

		Point3F points[4];
		points[0] = Point3F(-width, -width, 0.0f);
		points[1] = Point3F(-width, width, 0.0f);
		points[2] = Point3F( width, width, 0.0f);
		points[3] = Point3F( width, -width, 0.0f);

		for(int i = 0; i < 4; i++)
		{
			rotMatrix.mulP( points[i] );
			points[i] += offset;
		}

		PrimBuild::color3f(1.0f,1.0f,1.0f);

		PrimBuild::begin(GFXTriangleFan, 4);
		PrimBuild::texCoord2f(0, 0);
		PrimBuild::vertex3fv(points[0]);
		PrimBuild::texCoord2f(0, 1);
		PrimBuild::vertex3fv(points[1]);
		PrimBuild::texCoord2f(1, 1);
		PrimBuild::vertex3fv(points[2]);
		PrimBuild::texCoord2f(1, 0);
		PrimBuild::vertex3fv(points[3]);
		PrimBuild::end();

		GFX->setStateBlock(mBlendDisabledStateBlock);

	}

   renderChildControls(offset, updateRect);
}

void GuiRadarCtrl::setupStateBlocks()
{
   if (mBeforeStateBlock.isNull())
   {
       GFXStateBlockDesc desc;
       
       desc.setCullMode(GFXCullNone);
       //desc.setZEnable(false);

       desc.setBlend(true, GFXBlendSrcAlpha, GFXBlendInvSrcAlpha);

       desc.samplersDefined = true;
       desc.samplers[0].textureColorOp = GFXTOPModulate;
       desc.samplers[1].textureColorOp = GFXTOPDisable;
	   desc.samplers[0].addressModeU = GFXAddressWrap;
       desc.samplers[0].addressModeV = GFXAddressWrap;

       mBeforeStateBlock = GFX->createStateBlock( desc );
   }

   if (mBlendDisabledStateBlock.isNull())
   {
      GFXStateBlockDesc desc;
      desc.setBlend(false, GFXBlendOne, GFXBlendZero);
      mBlendDisabledStateBlock = GFX->createStateBlock( desc );
   }

}