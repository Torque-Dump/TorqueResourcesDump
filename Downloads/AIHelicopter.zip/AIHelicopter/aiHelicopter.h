//-----------------------------------------------------------------------------
// AIHelicopter
// Copyright (C) Martin Schultz, Decane
// and parts GarageGames, Inc.
//-----------------------------------------------------------------------------

#ifndef _AIHelicopter_H_
#define _AIHelicopter_H_

#ifndef _PLAYER_H_
#include "T3D/vehicles/heliVehicle.h"
#endif


class AIHelicopter : public heliVehicle {

	typedef heliVehicle Parent;

public:
	enum MoveState {
		ModeStop,
		ModeMove,
		ModeStuck,
	};

private:
		MoveState mMoveState;
		//S32	mMoveType;
		F32 mMoveSpeed;
		F32 mMoveTolerance;                 // Distance from destination before we stop
		Point3F mMoveDestination;           // Destination for movement
		Point3F mLastLocation;              // For stuck check
		bool mMoveSlowdown;                 // Slowdown as we near the destination

		SimObjectPtr<GameBase> mAimObject; 	// Object to point at, overrides location
		bool mAimLocationSet;               // Has an aim location been set?
		Point3F mAimLocation;               // Point to look at
		bool mTargetInLOS;                  // Is target object visible?

		MatrixF mMat; 						// for rotation functions
		Point3F mRot; 						// for rotation functions
		F32 pitchMultiplier;				// The factor to scale the pitch with
		F32 shootRange;						// Distance below the bot starts to fire automatically
		
		// Utility Methods
		void throwCallback( const char *name );
public:
		DECLARE_CONOBJECT( AIHelicopter );
		
		AIHelicopter();
		~AIHelicopter();
		
		void processTick(const Move* move);
		bool getAIMove(Move *movePtr);
		bool isInLOS(GameBase *obj, S32 weaponSlot);

		// Targeting and aiming sets/gets
		void setAimObject( GameBase *targetObject );
		GameBase* getAimObject() const  { return mAimObject; }
		void setAimLocation( const Point3F &location );
		Point3F getAimLocation() const { return mAimLocation; }
		void clearAim();
		Point3F& getRotation()
		{
			mMat = getTransform();
			mMat.getColumn(1, &mRot);
			mRot.normalize();
			return mRot;
		}

		// Movement methods
		void setMoveSpeed( const F32 speed );
		F32 getMoveSpeed() const { return mMoveSpeed; }
		void setMoveTolerance( const F32 tolerance );
		F32 getMoveTolerance() const { return mMoveTolerance; }
		void setMoveDestination( const Point3F &location, bool slowdown );
		Point3F getMoveDestination() const { return mMoveDestination; }
		void stopMove();
		void setPitchMultiplier(F32 value);
		F32 getPitchMultiplier();
		void setShootRange(F32 value);
		F32 getShootRange();
};

#endif
