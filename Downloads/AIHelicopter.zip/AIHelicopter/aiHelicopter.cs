function CreateAIHelicopter(%name, %botPath, %onReachDestination, %triggerNode, %team)
{
	// Create the A.I. driven bot object...	
	%player = new AIHelicopter()
	{
		dataBlock = DefaultHeli;
		path = %botPath;
		onReachDestination = %onReachDestination;
		triggerNode = %triggerNode;
		team = %team;
	};

	MissionCleanup.add( %player );
	%player.setShapeName( %name );
  
  %node = %botPath.getObject(0);  
	%player.setTransform( %node.getTransform());
  %player.curentNode = 0;    // current node
  
  %player.setMoveSpeed(1.5);
  %player.setMoveTolerance(5.0);
  
  %player.score = 0;
  
  %player.playThread(0,"ambient");
 
    
	return %player;
}

function AIHelicopter::followPath( %this, %path, %node )
{
  // Start the bot following a path
  %this.stopThread(0);

   // Make sure our path is valid
  if( !isObject( %path ) )
  {
    echo( "AIHelicopter::followPath failed - Bad Path!" );
    %this.path = "";
    return;
	}

  // How far do we want to travel on the path?
  if(( %node > %path.getCount() - 1 ) || (%node == -1))
    %this.targetNode = %path.getCount() - 1;
	else
		%this.targetNode = %node;
    
  if( %this.path $= %path ) {    
    %this.moveToNode(%this.currentNode + 1);
  }	else {    
		%this.path = %path;
		%this.moveToNode(0);
    %this.currentNode = 0;
	}
}

function AIHelicopter::moveToNextNode( %this )
{
	if( %this.targetNode < 0 || %this.currentNode < %this.targetNode )
	{
		if( %this.currentNode < %this.path.getCount() - 1 )
			%this.moveToNode( %this.currentNode + 1 );
		else
			%this.moveToNode( 0 );
	}
	else
	{
		if( %this.currentNode == 0 )
			%this.moveToNode( %this.path.getCount() - 1 );
		else
			%this.moveToNode( %this.currentNode - 1 );
	}
}

function AIHelicopter::moveToNode( %this, %index )
{   
   // Move to the given path node index
   %this.currentNode = %index;
   %node = %this.path.getObject(%index);
   %this.setMoveDestination( %node.getTransform(), %index == %this.targetNode );
}

///
/// Default defaultHeli callbacks!
///
function defaultHeli::onReachDestination( %this, %obj )
{
	if(%obj.triggerNode == %obj.currentNode)
	{
	if(%obj.onReachDestination $= "standByOpen")
	{
	
	//%obj.moveToNode(%obj.triggerNode);
	%obj.canExit = true;
	%this.setGravity(0);
	
	}else if(%obj.onReachDestination $= "goBack"){
	
	
	%obj.schedule(120000, "delete");
	%obj.moveToNode(0);
	
	}else if(%obj.onReachDestination $= "land"){
	
	return;
	
	}else if(%obj.onReachDestination $= "BailOut"){
		
	$enemy4.unmount();
	$enemy5.unmount();
	$enemy6.unmount();
	
	$enemy4.setControlObject($enemy4);
	$enemy5.setControlObject($enemy5);
	$enemy6.setControlObject($enemy6);
	
	%obj.schedule(120000, "delete");
	%obj.moveToNode(0);
	
	}
	}else{
	// Moves to the next node on the path.
	if( %obj.path !$= "" )
	{
		if( %obj.currentNode == %obj.targetNode )
			%this.onEndOfPath( %obj, %obj.path );
		else
			%obj.moveToNextNode();
	}
	else
		echo( "AIHelicopter::onReachDestination warning - Path is blank!" );
        }
}

function defaultHeli::onEndOfPath( %this, %obj, %path )
{
  %obj.moveToNode(1);
	//%obj.nextTask();
}

   
   
function AIHelicopter::Start(%this, %player1, %player2, %spawnPoint, %onReachDestination, %triggerNode)
{
   	
   echo("Loading...");
   if(!isObject(startInVehicle))
   {
   %startInVehicle = new AIHelicopter(startInVehicle)
    {
	   dataBlock = defaultHeli;
	   client = %this;
	   canExit = false;
    };
   }
   
   %startInVehicle.setTransform(%spawnPoint.getTransform());
   %startInVehicle.setForwardManeuvering(true);
   
   //%startInVehicle.mountObject(%player,1);
   if(isObject(%player1))
   {
   %startInVehicle.mountObject(%player1,1);
   CommandToClient(%player1.client, 'PushActionMapHelicopterPassenger', heliPassengerMap);
   %player1.mvehicle = %startInVehicle;
   }
   if(isObject(%player2))
   {
   %startInVehicle.mountObject(%player2,1);
   CommandToClient(%player2.client, 'PushActionMapHelicopterPassenger', heliPassengerMap);
   %player2.mvehicle = %startInVehicle;
   }
   
   %startInVehicle.followPath("MissionGroup/Paths/StartPath",-1);
   
   %startInVehicle.onReachDestination = %onReachDestination;
   
   %startInVehicle.triggerNode = %triggerNode;
   
   %startInVehicle.mountable = true;
   
   %startInVehicle.playThread(0,"ambient");
   $HelicopterCount++;
   
   //}
}
   