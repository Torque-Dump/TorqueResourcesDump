//-----------------------------------------------------------------------------
// AIHelicopter
// Copyright (C) Martin Schultz, Decane
// and parts GarageGames, Inc.
//-----------------------------------------------------------------------------
#include "AIHelicopter.h"
#include "console/consoleInternal.h"
#include "math/mMatrix.h"
#include "math/mPoint2.h"
#include "math/mPoint3.h"
#include "math/mPoint4.h"
#include "T3D/gameBase/moveManager.h"

IMPLEMENT_CO_NETOBJECT_V1(AIHelicopter);

//
// Constructor
//
AIHelicopter::AIHelicopter()
{
	mMoveDestination.set( 0.0f, 0.0f, 0.0f );
	mMoveSpeed = 1.0f;
	mMoveTolerance = 10.0f;
	mMoveSlowdown = true;
	
	mAimObject = 0;
	mAimLocationSet = false;
	mTargetInLOS = false;
	pitchMultiplier = 3.0f;
	shootRange = 150.0f;
}

//
// Destructor
//
AIHelicopter::~AIHelicopter()
{
}

//
// Sets the speed at which this AI moves
// @param speed Speed to move, default player was 10
//
void AIHelicopter::setMoveSpeed( F32 speed )
{
	mMoveSpeed = getMax(0.0f, getMin( 1.0f, speed ));
}

//
// Stops movement for this AI
//
void AIHelicopter::stopMove()
{
	mMoveState = ModeStop;
}

//
// Sets how far away from the move location is considered "on target"
// @param tolerance Movement tolerance for error
//
void AIHelicopter::setMoveTolerance( const F32 tolerance )
{
	mMoveTolerance = getMax( 0.1f, tolerance );
}

//
// Sets the location for the bot to fly to
// @param location Point to run to
// 
void AIHelicopter::setMoveDestination( const Point3F &location, bool slowdown )
{
	mMoveDestination = location;
	mMoveState = ModeMove;
	mMoveSlowdown = slowdown;
	mAimLocation = location;
	mAimObject = 0;
}

//
// Sets the object the bot is targeting
// @param targetObject The object to target
//
void AIHelicopter::setAimObject( GameBase *targetObject )
{   
	mAimObject = targetObject;
	mMoveState = ModeMove;
	mTargetInLOS = false;
}

//
// Sets the location for the bot to aim at
// @param location Point to aim at
//
void AIHelicopter::setAimLocation( const Point3F &location )
{
	mAimObject = 0;
	mAimLocationSet = true;
	mAimLocation = location;
}

//
// Clears the aim location and sets it to the bot's
// current destination so he looks where he's going
//
void AIHelicopter::clearAim() 
{
	mAimObject = 0;
	mAimLocationSet = false;
}

//
// Our processTick method where we check if an ai move
// has to be done or not.
//
void AIHelicopter::processTick(const Move* move)
{
	Move aiMove;
	if (!move && getAIMove(&aiMove))
	{
		move = &aiMove;
	}
	Parent::processTick(move);
}

//
// This method calculates the moves for the AI player
// @param movePtr Pointer to move the move list into
//
bool AIHelicopter::getAIMove(Move *movePtr)
{
	*movePtr = NullMove;
	
	//Dirty way for doing script-side updates. Warning: Inefficient!
	//throwCallback("onUpdatePosition");
	
	// Use the eye as the current position.
	Point3F location = getPosition();
	Point3F rotation = getRotation();
	
	if (mAimObject)
	{
		// if we have an aim object we continously update our move destination		
		mMoveDestination = mAimObject->getPosition();
		if (mMoveState == ModeStop)
			mMoveState = ModeMove;
	}
	
	// Move towards the destination
	if (mMoveState == ModeMove)
	{
		// Check if we should mMove, or if we are close enough
		Point3F targetVec = mMoveDestination - getPosition();
		F32 distance = targetVec.len(); 
		if (distance < (mMoveTolerance))
		{
			mMoveState = ModeStop;
			mSteering.x = 0;
			mSteering.y = 0;
			movePtr->y = 0.0f;
			movePtr->pitch = 0.0f;
			// If we have an aim object, we don't want this callback
			// to be thrown. Otherwise, if for example doing waypoint
			// flying, we need this. 
			if (! mAimObject)
			{
				throwCallback("onReachDestination");
			}
		}
		else
		{
			MatrixF eye;
			Point3F forward;
			Point3F up;
			Point3F right;
			Point3F targettoai;

			// Get the AIs transform.
			eye = getTransform();

			// Get the AIs eye vector and normalize it.
			eye.getColumn(1, &forward);
			forward.normalize();

			// Get the up vector
			eye.getColumn(2, &up);
			up.normalize();

			// Get the right vector.
			mCross( forward, up, &right );
			right.normalize();

			// Get the Target to AI vector and normalize it.
			targettoai = mMoveDestination - location;
			targettoai.normalize();

			F32 dotTurn = mDot( right, targettoai );
			F32 dotPitch = mDot( up, targettoai );

			// pitch of the vehicle. Use the direct inverted dotPitch. Works great! 
			// We're multiplying with the pitchMultiplier to allow the pitch to get extrem like to fly to a position
			// right above us which would be impossible with only using dotPitch alone.
			movePtr->pitch = -dotPitch * pitchMultiplier; // 3.0 - 7.0 is a good value for the pitchMultiplier
	
			// We use a slight "dead-zone" where no steering
			// action happens to not have the ship "jitter" when
			// coming near the target destination.
			if( dotTurn > 0.05f )
			{
				movePtr->yaw = 0.2f;
			}
			else if( dotTurn < -0.05f )
			{
				movePtr->yaw = -0.2f;
			}
			else
			{
				mSteering.x = 0;
				mSteering.y = 0;
			}

			// How much speed to we put in?
			movePtr->y = 1.0; // full speed!
			//if (distance < 40)
			//{
			//	//Con::errorf(ConsoleLogEntry::General, "SLOWDOWN");
			//	movePtr->y = 0.5; //slow down a bit before reaching the destination
			//}

			// if far away, move quickly using the booster.
			F32 slowdownNoBoosterDistance = 150;
			// if aiming an object like the repairship, we need to get closer to the 
			// destination any maybe use the booster to get behind.
			if (mAimObject)
				slowdownNoBoosterDistance = 100; 

			// Check if we need to activate our booster 
			if (distance > slowdownNoBoosterDistance)// && getEnergyValue() > 0.7
				movePtr->trigger[3] = true;
		}
	}
	else if (mMoveState == ModeStop)
	{
		if (mAimObject)
		{
			// aim the object anyway and try to shoot it. We're very near the target.
			MatrixF eye;
			Point3F forward;
			Point3F up;
			Point3F right;
			Point3F targettoai;

			// Get the AIs transform.
			eye = getTransform();

			// Get the AIs eye vector and normalize it.
			eye.getColumn(1, &forward);
			forward.normalize();

			// Get the up vector
			eye.getColumn(2, &up);
			up.normalize();

			// Get the right vector.
			mCross( forward, up, &right );
			right.normalize();

			// Get the Target to AI vector and normalize it.
			targettoai = mMoveDestination - location;
			targettoai.normalize();

			F32 dotTurn = mDot( right, targettoai );
			F32 dotPitch = mDot( up, targettoai );

			movePtr->pitch = -dotPitch * pitchMultiplier;
			movePtr->yaw = dotTurn;
		}
		else
		{
			// no aim object - just level out the ship
			if (rotation.z != 0)
				movePtr->pitch = rotation.z;
		}
		
	}

	// Check if an aim object is set
	if (mAimObject)
	{
		// we're going to check only the distance to the object and if in a certain
		// range, automatically fire at it. We don't need any LOS check - ship is 
		// auto-aiming at the target more or less precisely!
		Point3F targetVec = mMoveDestination - getPosition();
		F32 distance = targetVec.len(); 
		if (distance < shootRange)
		{
			if (mTargetInLOS == false)
			{
				//Con::errorf(ConsoleLogEntry::General, "onTargetNear");
				throwCallback("onTargetNear");
				mTargetInLOS = true;
			}
		} 
		else 
		{
			if (mTargetInLOS) 
			{
				//Con::errorf(ConsoleLogEntry::General, "onTargetOutOfReach");
				throwCallback("onTargetOutOfReach");
				mTargetInLOS = false;
			}
		}

		// Don't need this here and yet. If the aim object is set, the ship automatically
		// aims always the aim object so we don't need to check if it is in LOS, we only 
		// need to find out if we're too far away or not. This code stays here if someone
		// needs to do a LOS check anyway.
		//MatrixF eyeMat;
		//getEyeTransform(&eyeMat);
		//eyeMat.getColumn(3,&location);
		//Point3F targetLoc = mAimObject->getBoxCenter();
		//
		//// This ray ignores non-static shapes. Cast Ray returns true
		//// if it hit something.
		//if (isInLOS(mAimObject, 0))
		//{
		//	if (!mTargetInLOS)
		//	{
		//		Con::errorf(ConsoleLogEntry::General, "onTargetEnterLOS");
		//		throwCallback( "onTargetEnterLOS" );
		//		mTargetInLOS = true;
		//	}
		//} 
		//else 
		//{
		//	if (mTargetInLOS) 
		//	{
		//		Con::errorf(ConsoleLogEntry::General, "onTargetExitLOS");
		//		throwCallback( "onTargetExitLOS" );
		//		mTargetInLOS = false;
		//	}
		//}
	}


	// Replicate the trigger state into the move so that
	// triggers can be controlled from scripts.
	//for( int i = 0; i < MaxTriggerKeys; i++ )
	//	movePtr->trigger[i] = getImageTriggerState(i);
	return true;
}

bool AIHelicopter::isInLOS(GameBase *obj, S32 weaponSlot)
{
	disableCollision();
	// Test for object in sight. The LOS is run from the muzzle point
	// to the center of the target bounding box.
	Point3F location;
	getMuzzlePoint(5, &location);
	//getMuzzlePoint(weaponSlot,&location);
	Point3F targetLoc = obj->getBoxCenter();

	// This ray ignores non-static shapes. Cast Ray returns true
	// if it hit something.
	RayInfo dummy;
	if (getContainer()->castRay(location, targetLoc, InteriorObjectType | StaticShapeObjectType | StaticObjectType | TerrainObjectType, &dummy))
	{
		if (mTargetInLOS)
		{
            throwCallback( "onTargetExitLOS" );
            mTargetInLOS = false;
         }
	}
	else
	{
         if (!mTargetInLOS)
		 {
            throwCallback( "onTargetEnterLOS" );
            mTargetInLOS = true;
         }
	}
	enableCollision();
	return true;
}

//
// Utility function to throw callbacks. Callbacks always occure
// on the datablock class.
// @param name Name of script function to call
//
void AIHelicopter::throwCallback( const char *name )
{
	Con::executef(getDataBlock(), name, scriptThis());
}

void AIHelicopter::setPitchMultiplier(F32 value)
{
	pitchMultiplier = value;
}

F32 AIHelicopter::getPitchMultiplier()
{
	return pitchMultiplier;
}

void AIHelicopter::setShootRange(F32 value)
{
	shootRange = value;
}

F32 AIHelicopter::getShootRange()
{
	return shootRange;
}


// --------------------------------------------------------------------------------------------
// Console Functions
// --------------------------------------------------------------------------------------------
ConsoleMethod( AIHelicopter, setPitchMultiplier, void, 3, 3, "( float value )" "Sets the pitch multiplier.")
{
	AIHelicopter *ai = static_cast<AIHelicopter *>( object );
	ai->setPitchMultiplier( dAtof( argv[2] ) );
}

ConsoleMethod( AIHelicopter, getPitchMultiplier, F32, 2, 2, "()" "Gets the pitch multiplier.")
{
	AIHelicopter *ai = static_cast<AIHelicopter *>( object );
	return ai->getPitchMultiplier();
}

ConsoleMethod( AIHelicopter, setShootRange, void, 3, 3, "( float value )" "Sets the shoot range below the bot starts to fire.")
{
	AIHelicopter *ai = static_cast<AIHelicopter *>( object );
	ai->setShootRange( dAtof( argv[2] ) );
}

ConsoleMethod( AIHelicopter, getShootRange, F32, 2, 2, "()" "Gets the shoot range below the bot starts to fire.")
{
	AIHelicopter *ai = static_cast<AIHelicopter *>( object );
	return ai->getShootRange();
}


ConsoleMethod( AIHelicopter, stop, void, 2, 2, "()" "Stop moving.")
{
	AIHelicopter *ai = static_cast<AIHelicopter *>( object );
	ai->stopMove();
}

ConsoleMethod( AIHelicopter, clearAim, void, 2, 2, "()" "Stop aiming at anything.")
{
	AIHelicopter *ai = static_cast<AIHelicopter *>( object );
	ai->clearAim();
}

ConsoleMethod( AIHelicopter, setMoveSpeed, void, 3, 3, "( float speed )" "Sets the move speed for an AI object.")
{
	AIHelicopter *ai = static_cast<AIHelicopter *>( object );
	ai->setMoveSpeed( dAtof( argv[2] ) );
}

ConsoleMethod( AIHelicopter, setMoveTolerance, void, 3, 3, "( float tolerance )" "Sets the move tolerance for an AI object.")
{
	AIHelicopter *ai = static_cast<AIHelicopter *>( object );
	ai->setMoveTolerance( dAtof( argv[2] ) );
}

ConsoleMethod( AIHelicopter, setMoveDestination, void, 3, 4, "(Point3F goal, bool slowDown=true)" "Tells the AI to move to the location provided.")
{
	AIHelicopter *ai = static_cast<AIHelicopter *>( object );
	Point3F v( 0.0f, 0.0f, 0.0f );
	dSscanf( argv[2], "%f %f %f", &v.x, &v.y, &v.z );
	bool slowdown = (argc > 3)? dAtob(argv[3]): true;
	ai->setMoveDestination( v, slowdown);
}

ConsoleMethod( AIHelicopter, getMoveDestination, const char *, 2, 2, "()" "Returns the point the AI is set to move to.")
{
	AIHelicopter *ai = static_cast<AIHelicopter *>( object );
	Point3F movePoint = ai->getMoveDestination();
	
	char *returnBuffer = Con::getReturnBuffer( 256 );
	dSprintf( returnBuffer, 256, "%f %f %f", movePoint.x, movePoint.y, movePoint.z );
	
	return returnBuffer;
}

ConsoleMethod( AIHelicopter, setAimLocation, void, 3, 3, "( Point3F target )" "Tells the AI to aim at the location provided.")
{
	AIHelicopter *ai = static_cast<AIHelicopter *>( object );
	Point3F v( 0.0f,0.0f,0.0f );
	dSscanf( argv[2], "%f %f %f", &v.x, &v.y, &v.z );
	
	ai->setAimLocation( v );
}

ConsoleMethod( AIHelicopter, getAimLocation, const char *, 2, 2, "()" "Returns the point the AI is aiming at.")
{
	AIHelicopter *ai = static_cast<AIHelicopter *>( object );
	Point3F aimPoint = ai->getAimLocation();
	
	char *returnBuffer = Con::getReturnBuffer( 256 );
	dSprintf( returnBuffer, 256, "%f %f %f", aimPoint.x, aimPoint.y, aimPoint.z );
	
	return returnBuffer;
}

ConsoleMethod( AIHelicopter, setAimObject, void, 3, 3, "( GameBase obj )" "Sets the bot's target object.")
{
	AIHelicopter *ai = static_cast<AIHelicopter *>( object );
	
	// Find the target
	GameBase *targetObject;
	if( Sim::findObject( argv[2], targetObject ) )
		ai->setAimObject( targetObject );
	else
		ai->setAimObject( 0 );
}

ConsoleMethod( AIHelicopter, getAimObject, S32, 2, 2, "()" "Gets the object the AI is targeting.")
{
	AIHelicopter *ai = static_cast<AIHelicopter *>( object );
	GameBase* obj = ai->getAimObject();
	return obj? obj->getId(): -1;
}

