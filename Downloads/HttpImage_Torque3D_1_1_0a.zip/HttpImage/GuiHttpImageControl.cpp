//-----------------------------------------------------------------------------
// Torque Twitter Itegration
// Copyright (C) Violent Tulip.
//-----------------------------------------------------------------------------

#include "GuiHttpImageControl.h"

#include "console/consoleTypes.h"
#include "gfx/gfxDevice.h"
#include "gfx/gfxDrawUtil.h"

//-----------------------------------------------------------------------------
IMPLEMENT_CONOBJECT( GuiHttpImageControl );
//-----------------------------------------------------------------------------

GuiHttpImageControl::GuiHttpImageControl( void ) :
        mImageUrl( String::EmptyString ),
        mImageObject( NULL )
{
    // Void.
}

GuiHttpImageControl::~GuiHttpImageControl( void )
{
    // Clear the Object.
    mImageObject = NULL;
}

void GuiHttpImageControl::initPersistFields( void )
{
    // Image URL.
    addProtectedField( "ImageUrl", TypeRealString, Offset( mImageUrl, GuiHttpImageControl ), &SetImage, &defaultProtectedGetFn, "" );

    // Parent Call.
    Parent::initPersistFields();
}




//-----------------------------------------------------------------------------
// Refresh Image.
//-----------------------------------------------------------------------------
bool GuiHttpImageControl::onWake( void )
{
    // Parent Call.
    if ( !Parent::onWake() )
    {
        // Invalid.
        return false;
    }

    // Valid Texture?
    if ( !mImageObject )
    {
        // Refresh.
        RefreshImage();
    }

    // Valid.
    return true;
}




//-----------------------------------------------------------------------------
// Set Image.
//-----------------------------------------------------------------------------
void GuiHttpImageControl::SetImage( const String &pUrl )
{
    // Set Image Url.
    mImageUrl = pUrl;

    // Awake?
    if ( isAwake() )
    {
        // Refresh Image.
        RefreshImage();
    }
}

ConsoleMethod( GuiHttpImageControl, SetImage, void, 3, 3, "( String pUrl )" )
{
    // Set Image.
    object->SetImage( argv[2] );
}

//-----------------------------------------------------------------------------
// Refresh Image.
//-----------------------------------------------------------------------------
void GuiHttpImageControl::RefreshImage( void )
{
    // Valid URL?
    if ( mImageUrl == String::EmptyString )
    {
        // Warn.
        Con::warnf( "GuiHttpImageControl::RefreshImage() - Invalid Image URL." );
        return;
    }

    // Load the Image.
    mHttpController.LoadImage( mImageUrl );
    // Bind the Response Method.
    mHttpController.GetResponseDelegate().bind( this, &GuiHttpImageControl::OnRefreshImage );
}

ConsoleMethod( GuiHttpImageControl, RefreshImage, void, 2, 2, "( void )" )
{
    // Refresh Image.
    object->RefreshImage();
}

//-----------------------------------------------------------------------------
// On Refresh Image.
//-----------------------------------------------------------------------------
void GuiHttpImageControl::OnRefreshImage( GFXTexHandle &pImageObject )
{
    // Store Object.
    mImageObject = pImageObject;

    // Process Callback.
    Con::executef( this, "OnRefreshImage" );
}




//-----------------------------------------------------------------------------
// Render Control.
//-----------------------------------------------------------------------------
void GuiHttpImageControl::onRender( Point2I pOffset, const RectI &pUpdateRect )
{
    // Setup Rect.
    const RectI rect( pOffset, getExtent() );

    // Fill?
    if ( mProfile->mOpaque )
    {
        GFX->getDrawUtil()->drawRectFill( rect, mProfile->mFillColor );
    }

    // Valid Image?
    if ( mImageObject )
    {
        // Clear Modulation.
        GFX->getDrawUtil()->clearBitmapModulation();
        // Draw Image.
        GFX->getDrawUtil()->drawBitmapStretch( mImageObject, rect, GFXBitmapFlip_None, GFXTextureFilterLinear );
    }

    // Draw Border?
    if ( mProfile->mBorder || !mImageObject )
    {
        GFX->getDrawUtil()->drawRect( rect, mProfile->mBorderColor );
    }

    // Render Children.
    renderChildControls( pOffset, pUpdateRect );
}