//-----------------------------------------------------------------------------
// Torque Twitter Itegration
// Copyright (C) Violent Tulip.
//-----------------------------------------------------------------------------

#include "HttpImageController.h"

#include "console/console.h"
#include "core/stream/memStream.h"
#include "core/util/safeDelete.h"
#include "gfx/bitmap/gBitmap.h"

//-----------------------------------------------------------------------------

HttpImageController::HttpImageController( void ) :
        mSocket( InvalidSocket ),
        mResponseBuffer( NULL ),
        mResponseSize( 0 ),
        mImageUrl( String::EmptyString ),
        mImageObject( NULL )
{
    // Add Notification.
    Net::smConnectionReceive.notify( this, &HttpImageController::OnReceiveData );
    Net::smConnectionNotify.notify( this, &HttpImageController::OnUpdateConnection );
}

HttpImageController::~HttpImageController( void )
{
    // Break Current Connection.
    Disconnect();

    // Clear Notification.
    Net::smConnectionReceive.remove( this, &HttpImageController::OnReceiveData );
    Net::smConnectionNotify.remove( this, &HttpImageController::OnUpdateConnection );

    // Free.
    SAFE_FREE( mResponseBuffer );
}




//-----------------------------------------------------------------------------
// Load Image.
//-----------------------------------------------------------------------------
void HttpImageController::LoadImage( const String &pUrl )
{
    // Buffer the String.
    String urlBuffer( pUrl );
    // Strip "http://"
    const String::SizeType http = urlBuffer.find( "http://" );
    if ( http != String::NPos )
    {
        // Strip.
        urlBuffer = urlBuffer.substr( http + strlen( "http://" ) );
    }

    // Store Image URL.
    mImageUrl = urlBuffer;

    // Find the First Slash.
    const String::SizeType slash = urlBuffer.find( "/" );
    // Get the Host.
    String host = urlBuffer.substr( 0, slash );

    // Add Port?
    const String::SizeType port = host.find( ":" );
    if ( port == String::NPos )
    {
        // Add Port 80;
        host += ":80";
    }

    // Connect to the Host.
    if ( !Connect( host ) )
    {
        // Clear URL.
        mImageUrl = String::EmptyString;
        // Invalid.
        return;
    }
}



//-----------------------------------------------------------------------------
// Valid Connection?
//-----------------------------------------------------------------------------
bool HttpImageController::IsConnected( void ) const
{
    // Valid Socket?
    return ( mSocket != InvalidSocket );
}




//-----------------------------------------------------------------------------
// Make Connection.
//-----------------------------------------------------------------------------
bool HttpImageController::Connect( const String &pUrl )
{
    // Valid Connection?
    if ( IsConnected() )
    {
        // Already Connected.
        return false;
    }

    // Open Connection.
    mSocket = Net::openConnectTo( pUrl.c_str() );

    // Return Validity.
    return ( mSocket != InvalidSocket );
}

//-----------------------------------------------------------------------------
// Successful Connection.
//-----------------------------------------------------------------------------
void HttpImageController::OnConnect( void )
{
    if ( mImageUrl == String::EmptyString )
    {
        // Invalid.
        Con::warnf( "HttpImageController::OnConnect() - Invalid URL." );
        // Disconnect.
        Disconnect();
        return;
    }

    // Empty Delegate?
    if ( mResponseDelegate.empty() )
    {
        // Invalid.
        Con::warnf( "HttpImageController::OnConnect() - Response Delegate Empty." );
        // Disconnect.
        Disconnect();
        return;
    }

    // Find the First Slash.
    const String::SizeType slash = mImageUrl.find( "/" );
    // Get the Host.
    String host = mImageUrl.substr( 0, slash );
    // Get the Command.
    String query = mImageUrl.substr( slash );

    // Default Header String.
    static const char *header = "GET %s HTTP/1.1\r\n"
                                "Host: %s\r\n"
                                "Connection: close\r\n"
                                "\r\n";

    // Setup the Header.
    String requestHeader = String::ToString( header, query.c_str(), host.c_str() );
    // Send Request.
    if ( !Send( requestHeader ) )
    {
        // Disconnect.
        Disconnect();
    }
}

//-----------------------------------------------------------------------------
// Unsuccessful Connection.
//-----------------------------------------------------------------------------
void HttpImageController::OnConnectFail( void )
{
    // Clear Socket.
    mSocket = InvalidSocket;
    // Clear URL.
    mImageUrl = String::EmptyString;
}




//-----------------------------------------------------------------------------
// Send Data to Connection.
//-----------------------------------------------------------------------------
bool HttpImageController::Send( const String &pString )
{
    // Send Data.
    return Send( ( const U8* )pString.c_str(), pString.length() );
}

//-----------------------------------------------------------------------------
// Send Data to Connection.
//-----------------------------------------------------------------------------
bool HttpImageController::Send( const U8 *pBuffer, const U32 &pSize )
{
    // Valid Connection?
    if ( !IsConnected() )
    {
        // No Connection.
        return false;
    }

    // Send Data.
    return ( Net::sendtoSocket( mSocket, pBuffer, ( S32 )pSize ) == Net::NoError );
}




//-----------------------------------------------------------------------------
// Break Connection.
//-----------------------------------------------------------------------------
void HttpImageController::Disconnect( void )
{
    // Valid Connection?
    if ( !IsConnected() )
    {
        // Quit Now.
        return;
    }

    // Close Connection.
    Net::closeConnectTo( mSocket );
}

//-----------------------------------------------------------------------------
// Broken Connection.
//-----------------------------------------------------------------------------
void HttpImageController::OnDisconnect( void )
{
    // Clear Socket.
    mSocket = InvalidSocket;

    // Valid Response Buffer?
    if ( mResponseBuffer && mResponseSize )
    {
        // Parse the Header.
        U32 headerSize = 0;
        ParseResponseHeader( mResponseBuffer, mResponseSize, headerSize );
        // Parse Response.
        ParseResponse( ( mResponseBuffer + headerSize ), ( mResponseSize - headerSize ) );

        // Free the Buffer.
        SAFE_FREE( mResponseBuffer );
        // Clear the Size.
        mResponseSize = 0;
    }

    // Clear URL.
    mImageUrl = String::EmptyString;
}




//-----------------------------------------------------------------------------
// Parse Response.
//-----------------------------------------------------------------------------
void HttpImageController::ParseResponse( U8 *pBuffer, const U32 &pSize )
{
    if ( mResponseDelegate.empty() )
    {
        // Assert.
        AssertWarn( !mResponseDelegate.empty(), "HttpImageController::ParseResponse() - Response Delegate Empty." );
        return;
    }

    // Find the Period.
    const String::SizeType period = mImageUrl.find( ".", mImageUrl.length(), String::Right );
    // Fetch the Image Extension.
    const String extn = mImageUrl.substr( period + 1 );

    // Setup the Memory Stream.
    MemStream stream( pSize, ( void* )pBuffer );
    // Create the Bitmap.
    GBitmap *texObject = new GBitmap();
    // Read the Stream.
    if ( !texObject->readBitmap( extn, stream ) )
    {
        // Warn.
        Con::warnf( "HttpImageController::ParseResponse() - Unable to read Bitmap." );
        return;
    }

    // Setup the Handle.
    mImageObject.set( texObject, &GFXDefaultStaticDiffuseProfile, true, avar( "%s() - mImageObject (line %d)", __FUNCTION__, __LINE__ ) );

    // Send Signal.
    mResponseDelegate( mImageObject );
    // Clear the Delegate.
    mResponseDelegate.clear();

    // Clear the Image.
    mImageObject = NULL;
}

//-----------------------------------------------------------------------------
// Parse Response Header.
//-----------------------------------------------------------------------------
void HttpImageController::ParseResponseHeader( U8 *pData, const U32 &pSize, U32 &pHeaderLength )
{
    U8 *buffer = pData;
    for ( U32 i = 0; i < pSize; )
    {
        U32 lineLength = 0;
        for ( U32 j = 0; j < ( pSize - i ); j++ )
        {
            // New Line Character?
            if ( buffer[j] == '\n' || buffer[j] == 0 )
            {
                // Store Line Length.
                lineLength = j;
                // Carriage Return?
                if ( j && buffer[j - 1] == '\r' )
                {
                    // Decrease Length.
                    lineLength--;
                }

                // Increment Position.
                i += ( j + 1 );
                break;
            }
        }

        // Empty Line?
        if ( lineLength == 0 )
        {
            // Set Header Length.
            pHeaderLength = i;
            // Return.
            return;
        }

        // Increment Buffer Position.
        buffer = ( pData + i );
    }
}




//-----------------------------------------------------------------------------
// On Update Connection.
//-----------------------------------------------------------------------------
void HttpImageController::OnUpdateConnection( NetSocket pSocket, U32 pState )
{
    // Correct Object?
    if ( pSocket != mSocket )
    {
        // Quit.
        return;
    }

    switch( pState )
    {
    case Net::Connected :
        {
            // Connect.
            OnConnect();

        } break;

    case Net::ConnectFailed :
        {
            // Connect Fail.
            OnConnectFail();

        } break;

    case Net::Disconnected :
        {
            // Disconnect.
            OnDisconnect();

        } break;
    }
}

//-----------------------------------------------------------------------------
// On Receive Data.
//-----------------------------------------------------------------------------
void HttpImageController::OnReceiveData( NetSocket pSocket, RawData pData )
{
    // Correct Object?
    if ( pSocket != mSocket )
    {
        // Quit.
        return;
    }

    // Allocate.
    mResponseBuffer = ( U8* )dRealloc( mResponseBuffer, mResponseSize + pData.size );
    // Copy Data.
    dMemcpy( mResponseBuffer + mResponseSize, pData.data, pData.size );
    // Store Total Size.
    mResponseSize += pData.size;
}