//-----------------------------------------------------------------------------
// Torque Twitter Itegration
// Copyright (C) Violent Tulip.
//-----------------------------------------------------------------------------

#ifndef _GUIHTTPIMAGECONTROL_H_
#define _GUIHTTPIMAGECONTROL_H_

#ifndef _GUICONTROL_H_
#include "gui/core/guiControl.h"
#endif

#ifndef _HTTPIMAGECONTROLLER_H_
#include "HttpImageController.h"
#endif

#ifndef _GFXTEXTUREHANDLE_H_
#include "gfx/gfxImageHandle.h"
#endif

//-----------------------------------------------------------------------------

class GuiHttpImageControl : public GuiControl
{
    typedef GuiControl Parent;

protected:

    HttpImageController    mHttpController;
    String                 mImageUrl;
    GFXTexHandle           mImageObject;

public:

    GuiHttpImageControl( void );
    ~GuiHttpImageControl( void );

    static void initPersistFields( void );

public:

    /// On Wake.
    bool onWake( void );

    /// Set Image.
    void SetImage( const String &pUrl );
    /// Refresh Image.
    void RefreshImage( void );
    /// Reponse Method.
    void OnRefreshImage( GFXTexHandle &pImageObject );

    /// Render Control.
    void onRender( Point2I pOffset, const RectI &pUpdateRect );

    /// Console Declaration.
    DECLARE_CONOBJECT( GuiHttpImageControl );

public:

    /// Protected Field Setter.
    static bool SetImage( void *pObject, const char *pArray, const char *pData ) { static_cast<GuiHttpImageControl*>( pObject )->SetImage( pData ); return false; };
};

//-----------------------------------------------------------------------------

#endif // _GUIHTTPIMAGECONTROL_H_