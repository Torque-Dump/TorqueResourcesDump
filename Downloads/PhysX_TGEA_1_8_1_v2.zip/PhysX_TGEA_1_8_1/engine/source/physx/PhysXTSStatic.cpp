//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// PhysXInterior.cpp
// Create by Shannon Scarvaci
// See PhysXTSStatic.h for more details
//-----------------------------------------------------------------------------
#include "physX/PhysX.h"
#include "physX/PhysXTSStatic.h"
#include "physX/PhysXWorld.h"
#include "physX/PhysXStream.h"
#include "collision/convex.h"
#include "collision/concretePolyList.h"
#include "T3D/tsstatic.h"
#include "ts/tsShapeInstance.h"


IMPLEMENT_CONOBJECT(PhysXTSStatic);

PhysXTSStatic::PhysXTSStatic()
{
	mServer = false;
	gTSStatic = NULL;
	tsstaticMesh = NULL;
	mTriangleMesh = NULL;
	VECTOR_SET_ASSOCIATION(convexShapeDesc);
	VECTOR_SET_ASSOCIATION(triangleMeshDesc);
	mNumTSStatic = 1;
	nbVerts = 0;
	nbFaces = 0;
	verts = NULL;
	faces = NULL;
}

PhysXTSStatic::~PhysXTSStatic()
{
}

bool PhysXTSStatic::onAdd()
{
	return Parent::onAdd();
}

void PhysXTSStatic::onRemove()
{
	Parent::onRemove();
	PhysXWorld *PxWorld = PhysXWorld::getWorld(mServer);
	if (PxWorld && gTSStatic)
	{
		PxWorld->RemoveActor(*gTSStatic);
	}
}

void PhysXTSStatic::SetupCollision(bool server, TSStatic &tsstatic)
{
	mServer = server;

	PhysXWorld *PxWorld = PhysXWorld::getWorld(server);
	if (PxWorld) {
		Box3F box = tsstatic.getObjBox();
		VectorF scale = tsstatic.getScale()*10.0;
		box.minExtents.convolve(scale);
		box.maxExtents.convolve(scale);
		ConcretePolyList list;
		NxActorDesc actorDesc;

		if (!tsstatic.mShapeInstance) return;

		list.setTransform(&tsstatic.mObjToWorld, tsstatic.mObjScale);
		list.setObject(&tsstatic);

		bool found = false;
		for (U32 i = 0; i < tsstatic.mCollisionDetails.size(); i++)
		{
			S32 dl = tsstatic.mCollisionDetails[i];

			if (dl==-1)
			{
				//nothing to do
				break;
			}

			AssertFatal(dl>=0 && dl<tsstatic.mShapeInstance->mShape->details.size(),"PhysXTSStatic::SetupCollision");

			// get subshape and object detail
			const TSDetail * detail = &tsstatic.mShapeInstance->mShape->details[dl];
			S32 ss = detail->subShapeNum;
			S32 od = detail->objectDetailNum;

			// set up static data
			tsstatic.mShapeInstance->setStatics(dl);

			// nothing emitted yet...
			bool emitted = false;
			U32 surfaceKey = 0;

             TSMaterialList* mMaterialList = tsstatic.mShapeInstance->getMaterialList();
			 if (mMaterialList == NULL)
				 mMaterialList = tsstatic.mShapeInstance->getShape()->materialList;

			S32 start = tsstatic.mShapeInstance->mShape->subShapeFirstObject[ss];
			S32 end   = tsstatic.mShapeInstance->mShape->subShapeNumObjects[ss] + start;
			if (start<end)
			{
				MatrixF initialMat;
				Point3F initialScale;
				list.getTransform(&initialMat,&initialScale);

				// set up for first object's node
				MatrixF mat;
				MatrixF scaleMat(true);
				F32* p = scaleMat;
				p[0]  = initialScale.x;
				p[5]  = initialScale.y;
				p[10] = initialScale.z;
				MatrixF * previousMat = tsstatic.mShapeInstance->mMeshObjects[start].getTransform();
				mat.mul(initialMat,scaleMat);
				mat.mul(*previousMat);
				list.setTransform(&mat,Point3F(1, 1, 1));

				S32 numConvex = end - start;
				convexShapeDesc.setSize(numConvex);
				for(U32 i_convex=0; i_convex<numConvex; i_convex++)
				{
					convexShapeDesc[i_convex] = new NxConvexShapeDesc();
				}

				// run through objects and collide
				for (S32 i=start; i<end; i++)
				{
					TSShapeInstance::MeshObjectInstance * mesh = &tsstatic.mShapeInstance->mMeshObjects[i];

					if (od >= mesh->object->numMeshes)
						continue;

					if (mesh->getTransform() != previousMat)
					{
						// different node from before, set up for this node
						previousMat = mesh->getTransform();

						if (previousMat != NULL)
						{
							mat.mul(initialMat,scaleMat);
							mat.mul(*previousMat);
							list.setTransform(&mat,Point3F(1, 1, 1));
						}
					}
					// collide...
					emitted |= mesh->buildPolyList(od,&list,surfaceKey, tsstatic.mShapeInstance->getMaterialList());

					int vertBound = list.mVertexList.size();
					if (vertBound == 0) return;

					NxVec3 * verts = new NxVec3[vertBound];

					// Load vertices
					for(U32 k=0; k<vertBound; k++)
					{
						verts[k].x = list.mVertexList[k].x;
						verts[k].y = list.mVertexList[k].y;
						verts[k].z = list.mVertexList[k].z;
					}

					NxConvexMeshDesc convexDesc;
					convexDesc.numVertices		  = vertBound;
					convexDesc.pointStrideBytes	  = sizeof(NxVec3);
					convexDesc.points			  = verts;
					convexDesc.flags			  = NX_CF_COMPUTE_CONVEX;

					// cook it
					MemoryWriteBuffer buf;	
					NxInitCooking();
					NxCookingParams params;
					params.targetPlatform = PLATFORM_PC;
					params.skinWidth=0.0f;
					params.hintCollisionSpeed = false;
					NxSetCookingParams(params);
					bool status = NxCookConvexMesh(convexDesc, buf);
					NxCloseCooking();

					if (status)
					{
						MemoryReadBuffer readBuffer(buf.data);
						convexShapeDesc[i]->meshData = PxWorld->createConvexMesh(readBuffer);
						convexShapeDesc[i]->localPose.t = NxVec3(0,0,0);
						actorDesc.shapes.pushBack((convexShapeDesc[i]));
					}
					list.clear();

				} // end of for (S32 i=start; i<end; i++)

				// restore original transform...
				list.setTransform(&initialMat,initialScale);
			}

			tsstatic.mShapeInstance->clearStatics();

			found = true;
		}
		if (!found) return;

		actorDesc.body = NULL;

		gTSStatic = PxWorld->AddActor(actorDesc);

		if(gTSStatic->active)
		{
			gTSStatic->actor->userData = (void*) static_cast<SimObject*>( this );
		}

		//clean up
		for(U32 i=0; i<convexShapeDesc.size(); i++)
		{
			if (convexShapeDesc[i])
				convexShapeDesc[i]->~NxConvexShapeDesc();
		}
		convexShapeDesc.clear();
	}
}


void PhysXTSStatic::SetupTriangleCollision(bool server, TSStatic &tsstatic)
{
	mServer = server;

	PhysXWorld *PxWorld = PhysXWorld::getWorld(server);

	// If we don't have a PhysXWorld, just return.
	if ( !PxWorld ) 
	{
		Con::printf("*****SetupTriangleCollision - NO PHYSX WORLD*****");
		return; 
	}

	Box3F box = tsstatic.getObjBox();
	VectorF scale = tsstatic.getScale();//*10.0;
	box.minExtents.convolve(scale);
	box.maxExtents.convolve(scale);
	MatrixF wmat = tsstatic.getWorldTransform();
	Point3F placePos = tsstatic.getPosition();
	// make our matrices into Quats... for the physx engine
	QuatF q(wmat);
	Point3F wpos;
	wmat.getColumn(3,&wpos);
	NxQuat quat;
	quat. setXYZW(q.x, q.y, q.z, q.w);
	NxActorDesc actorDesc;
	
	TSShapeInstance *shapeInst = tsstatic.mShapeInstance; 

	ConcretePolyList polyList;
	MatrixF mat;
	mat.identity();
	polyList.setTransform( &mat, tsstatic.mObjScale );

	if ( !shapeInst )
	{
		Con::printf("*****SetupTriangleCollision - NO SHAPE INSTANCE*****");
		return;
	}

	if (!shapeInst->buildPolyList(&polyList, 0 ))
	{
		Con::printf("*****SetupTriangleCollision - NO POLYLIST*****");
		return;
	}
	
	//need to build the index list because polylist reuses indices
	Vector<U32> indices;
	for (U32 i = 0; i < polyList.mPolyList.size(); i++)
	{
		ConcretePolyList::Poly poly = polyList.mPolyList[i];
		
		U32 index = poly.vertexStart;
		indices.push_back( polyList.mIndexList[index++] );
		indices.push_back( polyList.mIndexList[index++] );
		indices.push_back( polyList.mIndexList[index++] );
	}

	NxInitCooking();
	
	NxTriangleMeshDesc triangleDesc;
	triangleDesc.numVertices            = polyList.mVertexList.size();
	triangleDesc.numTriangles           = polyList.mPolyList.size();
	triangleDesc.pointStrideBytes       = sizeof(NxVec3);
	triangleDesc.triangleStrideBytes	= 3*sizeof(NxU32);
	triangleDesc.points			        = polyList.mVertexList.address();
	triangleDesc.triangles              = indices.address();
	triangleDesc.flags		     	    = NX_MF_FLIPNORMALS;
	
	// cook it
	MemoryWriteBuffer buf;
	NxCookingParams params;
	params.targetPlatform = PLATFORM_PC;
	params.skinWidth = 0.1f;
	params.hintCollisionSpeed = false;
	NxSetCookingParams(params);
	bool status = NxCookTriangleMesh(triangleDesc, buf);
	
	if (status)
	{
		MemoryReadBuffer readBuffer(buf.data);
		mTriangleMesh = PxWorld->createTriangleMesh(readBuffer);
		
		// Push this actor back into our actor list.
		NxTriangleMeshShapeDesc staticMeshDesc;
		staticMeshDesc.skinWidth = 0.1f;
		staticMeshDesc.meshData = mTriangleMesh;
		actorDesc.shapes.push_back(&staticMeshDesc);
		NxCloseCooking();
	}
	else
	{
		Con::printf("*****SetupTriangleCollision - COOKING FAILED*****");
		NxCloseCooking();
		return;
	}
	

	actorDesc.body = NULL;
	gTSStatic = PxWorld->AddActor(actorDesc);

	if(gTSStatic->active)
	{
		gTSStatic->actor->setGlobalOrientationQuat(quat);
		gTSStatic->actor->setGlobalPosition( NxVec3(placePos) );
		gTSStatic->actor->userData = (void*) static_cast<SimObject*>( this );
	}
	else
		Con::printf("*****SetupTriangleCollision - ACTOR NOT ACTIVE*****");
}
