//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// PhysXActor.cpp
// Create by Shannon Scarvaci
// See PhysXActor.h for more details
//-----------------------------------------------------------------------------
#include "physX/PhysX.h"
#include "physX/PhysXActor.h"
#include "physX/PhysXWorld.h"
#include "physX/PhysXStream.h"
#include "math/mathIO.h"
#include "T3D/trigger.h"
#include "T3D/missionArea.h"
#include "console/consoleTypes.h"
#include "core/stream/bitStream.h"
#include "sim/netConnection.h"
#include "console/consoleTypes.h"
#include "collision/convex.h"
#include "collision/concretePolyList.h"
#include "ts/tsShapeInstance.h"
#include "T3D/gameConnection.h"

IMPLEMENT_CO_DATABLOCK_V1(PhysXMaterialData);

PhysXMaterialData::PhysXMaterialData()
{
	pxRestitution		= 0.0f;
	pxStaticFriction	= 0.1f;
	pxDynamicFriction	= 0.95f;

	id = 0;
}

PhysXMaterialData::~PhysXMaterialData()
{

}

void PhysXMaterialData::consoleInit()
{
	Parent::consoleInit();
}

void PhysXMaterialData::initPersistFields()
{
	Parent::initPersistFields();

	addGroup("PhysXMaterial");		
	addField("pxRestitution", TypeF32, Offset(pxRestitution, PhysXMaterialData));
	addField("pxStaticFriction", TypeF32, Offset(pxStaticFriction, PhysXMaterialData));
	addField("pxDynamicFriction", TypeF32, Offset(pxDynamicFriction, PhysXMaterialData));
	endGroup("PhysXMaterial");		
}

bool PhysXMaterialData::preload(bool server, String &errorStr)
{
	return Parent::preload(server, errorStr);
}

void PhysXMaterialData::packData(BitStream* stream)
{
	Parent::packData(stream);
	stream->write(id);
	stream->write(pxRestitution);
	stream->write(pxStaticFriction);
	stream->write(pxDynamicFriction);
}

void PhysXMaterialData::unpackData(BitStream* stream)
{
	Parent::unpackData(stream);
	stream->read(&id);
	stream->read(&pxRestitution);
	stream->read(&pxStaticFriction);
	stream->read(&pxDynamicFriction);
}

bool PhysXMaterialData::updatePhysX(bool server)
{
	PhysXWorld *PxWorld = PhysXWorld::getWorld(server);
	if (PxWorld) {
		NxMaterialDesc	material;
		material.restitution		  = pxRestitution;
		material.staticFriction		= pxStaticFriction;
		material.dynamicFriction	= pxDynamicFriction;
		if (id == 0)
			id = PxWorld->createMaterial(material);
		else
			id = PxWorld->setMaterial(material,id);
		return true;
	}
	return false;
}

IMPLEMENT_CO_DATABLOCK_V1(PhysXActorData);

PhysXActorData::PhysXActorData()
{
	//PhysXActorData:
	pxShape = pxShapeBox;
	pxRadius = 1.0f;
	pxHeight = 1.0f;
	pxKinematicBody = false;
}

PhysXActorData::~PhysXActorData()
{

}

void PhysXActorData::consoleInit()
{
	Parent::consoleInit();
}

static EnumTable::Enums pxShapeEnums[] =
{
	{ PhysXActorData::pxShapeBox, "box" },
	{ PhysXActorData::pxShapeSphere, "sphere" },
	{ PhysXActorData::pxShapeCapsule, "capsule" },
	{ PhysXActorData::pxShapeTrimesh, "trimesh" },
	{ PhysXActorData::pxShapeOther, "other" }
};
static EnumTable gPxShapeTable(5, &pxShapeEnums[0]);

void PhysXActorData::initPersistFields()
{
	Parent::initPersistFields();

	addGroup("PhysX");		
	addField("pxShape", TypeEnum, Offset(pxShape, PhysXActorData), 1, &gPxShapeTable);
	addField("pxRadius", TypeF32, Offset(pxRadius, PhysXActorData));
	addField("pxHeight", TypeF32, Offset(pxHeight, PhysXActorData));
	addField("pxKinematicBody", TypeBool, Offset(pxKinematicBody,PhysXActorData));
	endGroup("PhysX");		
}

bool PhysXActorData::preload(bool server, String &errorStr)
{
	return Parent::preload(server, errorStr);
}

void PhysXActorData::packData(BitStream* stream)
{
	Parent::packData(stream);
	stream->write(pxShape);
	stream->write(pxRadius);
	stream->write(pxHeight);
	stream->writeFlag(pxKinematicBody);
}

void PhysXActorData::unpackData(BitStream* stream)
{
	Parent::unpackData(stream);
	stream->read(&pxShape);
	stream->read(&pxRadius);
	stream->read(&pxHeight);
	pxKinematicBody = stream->readFlag();
}

//*************************************************************************

IMPLEMENT_CO_NETOBJECT_V1(PhysXActor);

PhysXActor::PhysXActor(void)
{
	mTypeMask |= StaticShapeObjectType;
	mNetFlags.set(Ghostable | ScopeAlways);
	mActor = NULL;
	mGrabbing = false;
	bMoveKinematicActor = false;
	bToggleKinematicActor = false;
	mDataBlock = 0;
	isCollided = false;
	remoteClient = false;
	mInMissionArea = true;
	mProcessTick = true;

	clientFirstInsert = false;

	serverQuat.zero();
	serverPos.zero();
	serverLinear.zero();
	serverAngular.zero();
	serverSentPhysx = false;
	sendCount = 0;
	interpolateTickRemoteClient = false;

	VECTOR_SET_ASSOCIATION(convexShapeDesc);
	mNumActor = 1;
	nbVerts = 0;
	nbFaces = 0;
	verts = NULL;
	faces = NULL;

	mActorID = -1;
}

PhysXActor::~PhysXActor(void)
{
}

void PhysXActor::initPersistFields()
{
	Parent::initPersistFields();
	addField("actorID", TypeS32, Offset(mActorID, PhysXActor));
}

void PhysXActor::consoleInit()
{
	Parent::consoleInit();
}

bool PhysXActor::onAdd()
{
	if(!Parent::onAdd() || !mDataBlock)
		return false;

	addToScene();

	if (!isServerObject())
	{
		PhysXWorld *pw = PhysXWorld::getWorld(true); // test if server are not exist then is remote client
		if (!pw)
			remoteClient = true;
		else
		{
			// must create one before onAdd()
		}
	}

	if (remoteClient || isServerObject())
	{
		createActor(isServerObject(),remoteClient);
		scriptOnAdd();

		setMaskBits(PositionMask);

	}// end is server

	setMaskBits(ActorMask);

	return true;
}

bool PhysXActor::createActor(bool server, bool remote)
{
	PhysXWorld *PxWorld = PhysXWorld::getWorld(isServerObject());
	if (!PxWorld) return false;

	if (server || remote)
	{
		NxBodyDesc bodyDesc;

		switch (mDataBlock->pxShape)
		{
			case PhysXActorData::pxShapeBox:
				{
					NxBoxShapeDesc boxDesc;
					boxDesc.dimensions.set(mObjBox.len_x() / 2.0,mObjBox.len_y() / 2.0,mObjBox.len_z() / 2.0);
					NxVec3 local;
					local.x = (mObjBox.maxExtents.x - mObjBox.minExtents.x)/2.0 + mObjBox.minExtents.x;
					local.y = (mObjBox.maxExtents.y - mObjBox.minExtents.y)/2.0 + mObjBox.minExtents.y;
					local.z = (mObjBox.maxExtents.z - mObjBox.minExtents.z)/2.0 + mObjBox.minExtents.z;
					boxDesc.localPose.t = local;
					if (mDataBlock->mMaterialBlock)
						boxDesc.materialIndex = mDataBlock->mMaterialBlock->id; //mMaterialBlock->id;
					actorDesc.shapes.pushBack(&boxDesc);
					break;
				}
			case PhysXActorData::pxShapeSphere:
				{
					NxSphereShapeDesc sphereDesc;    
					sphereDesc.radius = mDataBlock->pxRadius;   
					if (mDataBlock->mMaterialBlock)
						sphereDesc.materialIndex = mDataBlock->mMaterialBlock->id;
					actorDesc.shapes.pushBack(&sphereDesc);
					break;
				}
			case PhysXActorData::pxShapeCapsule:
				{
					NxCapsuleShapeDesc capsuleDesc;
					capsuleDesc.height = mDataBlock->pxHeight;
					capsuleDesc.radius = mDataBlock->pxRadius;
					if (mDataBlock->mMaterialBlock)
						capsuleDesc.materialIndex = mDataBlock->mMaterialBlock->id; //mMaterialBlock->id;
					actorDesc.shapes.pushBack(&capsuleDesc);
					break;
				}
			case PhysXActorData::pxShapeTrimesh:
				{
					// The actor has one shape, a box, 1m on a side
					SetupTrimesh(isServerObject(),actorDesc);
					break;
				}
			case PhysXActorData::pxShapeOther:
				{
					// The actor has one shape, a box, 1m on a side
					NxBoxShapeDesc boxDesc;
					boxDesc.dimensions.set(mObjBox.len_x() / 2.0,mObjBox.len_y() / 2.0,mObjBox.len_z() / 2.0);
					if (mDataBlock->mMaterialBlock)
						boxDesc.materialIndex = mDataBlock->mMaterialBlock->id; //mMaterialBlock->id;
					actorDesc.shapes.pushBack(&boxDesc);
					break;
				}
			default:
				AssertFatal(false,"Wrong physXShape Type");
		}

		bodyDesc.mass = 1;
		if (mDataBlock->pxKinematicBody)
			bodyDesc.flags |= NX_BF_KINEMATIC;

		actorDesc.body = &bodyDesc;
		QuatF q(mObjToWorld);
		Point3F pos;
		mObjToWorld.getColumn(3,&pos);
		NxQuat quat;
		quat.setXYZW(q.x,q.y,q.z,q.w);

		PhysXWorld *PxWorld = PhysXWorld::getWorld(isServerObject());
		if (PxWorld)
			mActor = PxWorld->AddActor(actorDesc);
		if (!mActor && !remoteClient) 
			return false;
		if (mActor)
			if (!mActor->active && !remoteClient)
				return false;

		if (mActor)
		{
			if (mActor->actor)
			{
				mActor->actor->wakeUp(1.0);
			}

			if ( isServerObject() )
			{
				Con::printf("***PHYSX*** - Adding Server Actor - '%s'", this->getDataBlock()->getName());

			}
			else if (isClientObject())
			{
				Con::printf("***PHYSX*** - Adding Client Actor - '%s'", this->getDataBlock()->getName());
				clientFirstInsert = true;
			}

			// you really need a material!
			if (mDataBlock->mass)
			{
				if (mActor)
				{
					if (mActor->actor)
					{
						mActor->actor->updateMassFromShapes(0,mDataBlock->mass);
						Con::printf("***PHYSX*** - Physx (PhysxActor) 'mass' set  to %f", mDataBlock->mass);
					}
				}
			}
			else
			{

				if (mActor)
				{
					if (mActor->actor)
					{
						Con::errorf("***PHYSX*** - found a Physx (PhysxActor) object with missing 'mass' in datablock!");
						mActor->actor->updateMassFromShapes(0,1);	
					}
				}
			}

			Con::printf("***PHYSX*** - Physx (PhysxActor) 'material' set  to %s", mDataBlock->mMaterialBlock->getName());

			if (mActor)
			{
				if (mActor->actor)
				{
					mActor->actor->setGlobalOrientationQuat(quat);
					mActor->actor->setGlobalPosition(NxVec3(pos.x,pos.y,pos.z));
				}
			}
		}
	}
	return true;
}

void PhysXActor::onRemove()
{
	scriptOnRemove();
	removeFromScene();
	Parent::onRemove();
	PhysXWorld *PxWorld = PhysXWorld::getWorld(isServerObject());
	if (PxWorld && mActor) {
		PxWorld->RemoveActor(*mActor);
	}
}

bool PhysXActor::onNewDataBlock(GameBaseData* dptr)
{
	mDataBlock = dynamic_cast<PhysXActorData*>(dptr);
	if (!mDataBlock || !Parent::onNewDataBlock(dptr))
		return false;

	scriptOnNewDataBlock();
	return true;
}

void PhysXActor::processTick(const Move *move)
{
	Parent::processTick(move);

	if (isServerObject()) // only do this on the server
	{
		if (mActor) // if an actor
		{	
			if (mActor->active && !mActor->actor->isSleeping() ) // if we are awake
			{
				NxVec3 pos = mActor->actor->getGlobalPosition();
				NxQuat quat = mActor->actor->getGlobalOrientationQuat();
				MatrixF mat;
				QuatF	q(quat.x,quat.y,quat.z,quat.w);
				q.setMatrix(&mat);
				mat.inverse(); // coz in setTransform it will inverse!
				mat.setColumn(3,Point3F(pos.x,pos.y,pos.z));
				Parent::setTransform(mat);
			    
				if (!mActor->actor->isSleeping()) 
				{
						setMaskBits(PositionMask);
					isCollided = false;
				}		
			}
		}
	}
}


void PhysXActor::interpolateTick(F32 dt)
{
	Parent::interpolateTick(dt);

	if (mActor == NULL) return;
	if (!mActor->active) return;
	if (mActor->actor == NULL) return;

	if (remoteClient)
	{
		if (interpolateTickRemoteClient) 
		{
			if (mActor->actor->isSleeping())
			  interpolateTickRemoteClient = false;
			return;
		}
	}

	if(!mActor->actor->isSleeping())
	{
		// get the data from the physx object...
		NxVec3 pos = mActor->actor->getGlobalPosition();
		NxQuat quat = mActor->actor->getGlobalOrientationQuat();

		// figure out an interpolated position...
		Point3F actorPos	=  Point3F(pos.x,pos.y,pos.z);
		Point3F objectPos	= Parent::getPosition();
		Point3F interpPos;

		interpPos.interpolate(actorPos, objectPos, dt);

		// figure out interpolated rotation...
		MatrixF obMat = Parent::getTransform();
		obMat.affineInverse();
		QuatF	objectQuat(obMat);
		QuatF	actorQuat(quat.x,quat.y,quat.z,quat.w);
		QuatF interpQuat;
		interpQuat.interpolate(actorQuat, objectQuat, dt);

		// build an interpolated transform...
		MatrixF mat;
		interpQuat.setMatrix(&mat);
		mat.inverse(); // coz in setTransform it will inverse!
		mat.setColumn(3,interpPos);

		// apply to the rendering...
		setRenderTransform(mat);
	}
	interpolateTickRemoteClient = false;
}

void PhysXActor::advanceTime(F32 dt)
{
	Parent::advanceTime(dt);
}

U32 PhysXActor::packUpdate(NetConnection *conn, U32 mask, BitStream *stream)
{
	U32 retMask = Parent::packUpdate(conn, mask, stream);

	if (stream->writeFlag(mask & ActorMask))
	{
		stream->write(U32(mActor));
		stream->write(mActorID);
	}
	bool posMark = mask & PositionMask; // this not alway work!
	if (stream->writeFlag(posMark)) 
	{
		stream->writeAffineTransform(mObjToWorld);
		if (stream->writeFlag(mActor)) 
		{
			VectorF linear, angular;
			NxVec3 NxTmp = mActor->actor->getLinearVelocity();
			linear = VectorF(NxTmp.x,NxTmp.y,NxTmp.z);
			NxTmp = mActor->actor->getAngularVelocity();
			angular = VectorF(NxTmp.x,NxTmp.y,NxTmp.z);
			mathWrite(*stream,linear);
			mathWrite(*stream,angular);
		}
	}

	return retMask;
}
void PhysXActor::unpackUpdate(NetConnection *con, BitStream *stream)
{
	Parent::unpackUpdate(con, stream);

	// Actor Mask
	if (stream->readFlag())
	{
		U32 actor;
		stream->read(&actor);
		if(con->isLocalConnection())
		{
			mActor = (sNxActor*)actor;
			if (mActor)
			{
				mActor->actor->wakeUp();
			}
		}
		stream->read(&mActorID);
	}

	// Position Mask
	if (stream->readFlag())
	{
		interpolateTickRemoteClient = true;
		MatrixF mat;
		stream->readAffineTransform(&mat);
		Parent::setTransform(mat);
		Parent::setRenderTransform(mat);

		if (mActor && remoteClient)
		{
			if (mActor->active)
			{
				QuatF q(mat);
				Point3F pos;
				mat.getColumn(3,&pos);
				NxQuat quat;
				quat.setXYZW(q.x,q.y,q.z,q.w);
				mActor->actor->moveGlobalOrientationQuat(quat);
				mActor->actor->moveGlobalPosition(NxVec3(pos.x,pos.y,pos.z));
			}
		}
		if (stream->readFlag()) { // get linear and torque force
			VectorF linear, angular;
			mathRead(*stream,&linear);
			mathRead(*stream,&angular);
			if (mActor && remoteClient) 
			{
				if (mActor->active) {
					mActor->actor->setLinearVelocity(NxVec3(linear.x,linear.y,linear.z));
					mActor->actor->setAngularVelocity(NxVec3(angular.x,angular.y,angular.z));
				}
			}
		}
	}
}

//----------------------------------------------------------------------------

void PhysXActor::writePacketData(GameConnection *connection, BitStream *stream)
{
}

void PhysXActor::readPacketData(GameConnection *connection, BitStream *stream)
{
}

void PhysXActor::setTransform(const MatrixF& mat)
{
	Parent::setTransform(mat);

	if (mActor) {
		if (mActor->active){

			Point3F pos;
			mat.getColumn(3,&pos);

			MatrixF inverter = mat;
			inverter.inverse(); // yes you need this... must be after pos!
			QuatF q(inverter);
			NxQuat quat;
			quat.setXYZW(q.x,q.y,q.z,q.w);

			mActor->actor->setGlobalOrientationQuat(quat);
			mActor->actor->setGlobalPosition(NxVec3(pos.x,pos.y,pos.z));
		}
	}
}

void PhysXActor::moveTransform(const MatrixF& mat)
{
	Parent::setTransform(mat);

	if (mActor)
	{
		if (mActor->active)
		{
			Point3F pos;
			mat.getColumn(3,&pos);

			MatrixF inverter = mat;
			inverter.inverse(); // yes you need this... must be after pos!
			QuatF q(inverter);
			NxQuat quat;
			quat.setXYZW(q.x,q.y,q.z,q.w);

			mActor->actor->moveGlobalOrientationQuat(quat);
			mActor->actor->moveGlobalPosition(NxVec3(pos.x,pos.y,pos.z));
		}
	}
}

void PhysXActor::ProcessInput()
{
}

void PhysXActor::setActorCollided()
{
	isCollided = true;
}

void PhysXActor::updateWorkingCollisionSet()
{
}

bool PhysXActor::updatePhysX(bool server)
{
	if (mActor != NULL) return false;
	PhysXWorld *PxWorld = PhysXWorld::getWorld(server);
	if (PxWorld)
	{
		return createActor(server);
	}
	return false;
}

void PhysXActor::checkMissionArea()
{
	// Checks to see if the player is in the Mission Area...
	Point3F pos;
	MissionArea * obj = dynamic_cast<MissionArea*>(Sim::findObject("MissionArea"));

	if(!obj)
	{
		return;
	}

	const RectI &area = obj->getArea();
	getTransform().getColumn(3, &pos);

	if ((pos.x < area.point.x || pos.x > area.point.x + area.extent.x ||
		pos.y < area.point.y || pos.y > area.point.y + area.extent.y))
	{
		if(mInMissionArea)
		{
			mInMissionArea = false;
			Con::executef(mDataBlock,"onLeaveMissionArea",scriptThis());
		}
	}
	else if(!mInMissionArea)
	{
		mInMissionArea = true;
		Con::executef(mDataBlock,"onEnterMissionArea",scriptThis());
	}
}

ConsoleMethod( PhysXActor, setProcessTick, void, 3, 3, "(bool tick)")
{
	object->setProcessTick(dAtob(argv[2]));
}

void PhysXActor::SetupTrimesh(bool server, NxActorDesc &actorDesc)
{
	PhysXWorld *PxWorld = PhysXWorld::getWorld(server);
	if (PxWorld)
	{
		Box3F box = getObjBox();
		VectorF scale = getScale()*10.0;
		box.minExtents.convolve(scale);
		box.maxExtents.convolve(scale);
		ConcretePolyList list;

		if (!mShapeInstance) return;
		
		list.setTransform(&mObjToWorld, mObjScale);
		list.setObject(this);

		bool found = false;
		for (U32 i = 0; i < mDataBlock->collisionDetails.size(); i++)
		{
			//tsstatic.mShapeInstance->buildPolyList(&list, tsstatic.mCollisionDetails[i]);
			S32 dl = mDataBlock->collisionDetails[i];

			if (dl == -1)
			{
				//nothing to do			
				break;
			}

			AssertFatal(dl>=0 && dl<mShapeInstance->mShape->details.size(),"PhysXActor::SetupTrimesh");

			// get subshape and object detail
			const TSDetail * detail = &mShapeInstance->mShape->details[dl];
			S32 ss = detail->subShapeNum;
			S32 od = detail->objectDetailNum;

			// set up static data
			mShapeInstance->setStatics(dl);

			TSMaterialList * mMaterialList = mShapeInstance->getMaterialList();
			if (mMaterialList == NULL)
				mMaterialList = mShapeInstance->getShape()->materialList;

			// nothing emitted yet...
			bool emitted = false;
			U32 surfaceKey = 0;

			S32 start = mShapeInstance->mShape->subShapeFirstObject[ss];
			S32 end   = mShapeInstance->mShape->subShapeNumObjects[ss] + start;
			if (start<end)
			{
				MatrixF initialMat;
				Point3F initialScale;
				list.getTransform(&initialMat,&initialScale);

				// set up for first object's node
				MatrixF * previousMat = mShapeInstance->mMeshObjects[start].getTransform();
				list.setTransform(previousMat,Point3F(1, 1, 1));

				S32 numConvex = end - start;
				convexShapeDesc.setSize(numConvex);
				for(U32 i_convex=0; i_convex<numConvex; i_convex++)
				{
					convexShapeDesc[i_convex] = new NxConvexShapeDesc();
				}
				// run through objects and collide
				for (S32 i=start; i<end; i++)
				{
					TSShapeInstance::MeshObjectInstance * mesh = &mShapeInstance->mMeshObjects[i];

					if (od >= mesh->object->numMeshes)
						continue;

					if (mesh->getTransform() != previousMat)
					{
						// different node from before, set up for this node
						previousMat = mesh->getTransform();

						if (previousMat != NULL)
						{
							list.setTransform(previousMat,Point3F(1, 1, 1));
						}
					}
					// collide...
					emitted |= mesh->buildPolyList(od,&list,surfaceKey,mMaterialList);

					int vertBound = list.mVertexList.size();
					if (vertBound == 0) return;

					NxVec3 * verts = new NxVec3[vertBound];

					// Load vertices
					for(U32 k=0; k<vertBound; k++)
					{
						verts[k].x = list.mVertexList[k].x;
						verts[k].y = list.mVertexList[k].y;
						verts[k].z = list.mVertexList[k].z;
					}	 

					NxConvexMeshDesc convexDesc;
					convexDesc.numVertices				= vertBound;
					convexDesc.pointStrideBytes	  = sizeof(NxVec3);
					convexDesc.points						  = verts;
					convexDesc.flags							= NX_CF_COMPUTE_CONVEX;

					NxInitCooking();

					// Cooking from memory
					MemoryWriteBuffer buf;
					bool status = NxCookConvexMesh(convexDesc, buf);
					if (status){
						MemoryReadBuffer readBuffer(buf.data);
						convexShapeDesc[i]->meshData = PxWorld->createConvexMesh(readBuffer);
						convexShapeDesc[i]->localPose.t = NxVec3(0,0,0);
						if (mDataBlock->mMaterialBlock)
							convexShapeDesc[i]->materialIndex = mDataBlock->mMaterialBlock->id;

						actorDesc.shapes.pushBack((convexShapeDesc[i]));
					}		
					list.clear();
				}

				// restore original transform...
				list.setTransform(&initialMat,initialScale);
			}

			mShapeInstance->clearStatics();

			found = true;
		}
		if (!found) return;
		//////////////////////
		//////////////////////
		for(U32 i=0; i<convexShapeDesc.size(); i++)
		{
			if (convexShapeDesc[i])
				convexShapeDesc[i]->~NxConvexShapeDesc();
		}
		convexShapeDesc.clear();

	}
}

bool PhysXActor::getNodeLocalPoint(const char* nodeName,Point3F &pos)
{   
	// Returns mount point to world space transform   
	S32 ni = mDataBlock->mShape->findNode(nodeName);
	if (ni != -1) {   
		MatrixF nodeTransform = mShapeInstance->mNodeTransforms[ni];  
		pos = nodeTransform.getPosition(); 
		return true;
	}
	return false;
}

//-----------------------------------------------------------------------------
// PhysXActor::applyImpulse
// 
// Applies an impulse defined in global coordinates, acting at a particular
// point in global coordinates, to the actor. If the force does not act along
// the center of mass of the actor, this will also add the corresponding torque.
//-----------------------------------------------------------------------------
void PhysXActor::applyImpulse(const Point3F& pos, const VectorF& impulse)
{
	if (mDataBlock->pxKinematicBody)
		return;

	Con::printf("***PHYSX*** ---- Applying impluse (%f,%f,%f) at (%f,%f,%f) to #%d", impulse.x, impulse.y, impulse.z, pos.x, pos.y, pos.z, getId());

	NxVec3 nxPos(pos.x, pos.y, pos.z);
	NxVec3 nxImpulse(impulse.x, impulse.y, impulse.z);
	
	mActor->actor->addForceAtPos(nxImpulse, nxPos, NX_IMPULSE);

	setMaskBits(PositionMask);
}
