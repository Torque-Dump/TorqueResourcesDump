//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// PhysXInterior.cpp
// Create by Shannon Scarvaci
// See PhysXInterior.h for more details
//-----------------------------------------------------------------------------
#include "physX/PhysX.h"
#include "physX/PhysXInterior.h"
#include "physX/PhysXWorld.h"
#include "physX/PhysXStream.h"
#include "collision/convex.h"
#include "collision/concretePolyList.h"
#include "interior/interiorInstance.h"
#include "interior/interior.h"
#include "core/frameAllocator.h"

#include "physX/PhysXActor.h"


IMPLEMENT_CONOBJECT(PhysXInterior);

PhysXInterior::PhysXInterior()
{
	mServer = false;
	gInterior = NULL;
	VECTOR_SET_ASSOCIATION(convexShapeDesc);
	mNumInterior = 1;
	nbVerts = 0;
	nbFaces = 0;
	verts = NULL;
	faces = NULL;
}

PhysXInterior::~PhysXInterior()
{
}

bool PhysXInterior::onAdd()
{
	return Parent::onAdd();
}

void PhysXInterior::onRemove()
{
	Parent::onRemove();
	PhysXWorld *PxWorld = PhysXWorld::getWorld(mServer);
	if (PxWorld && gInterior) {
		PxWorld->RemoveActor(*gInterior);
	}
}
const U32 sClientCollisionMask = (TerrainObjectType     | InteriorObjectType |
								  StaticShapeObjectType | VehicleObjectType  |
								  PlayerObjectType      | StaticTSObjectType);

sNxActor* PhysXInterior::SetupCollision(bool server, InteriorInstance &interior)
{

	// bail if no resourse
	if (bool(interior.mInteriorRes) == false)
	{
		Con::errorf("***PHYSX*** - Interior setup bailed with no resource! *************");
		return NULL;
	}

	// bail if no physx server running
	mServer = server;
	PhysXWorld *PxWorld = PhysXWorld::getWorld(server);
	if (!PxWorld)
	{
		Con::errorf("***PHYSX*** - Interior setup bailed with no PhysX Server! ********************");
		return NULL;
	}

	//physx material... this is required!!
	PhysXMaterialData * interiorMaterial;
	interiorMaterial = dynamic_cast<PhysXMaterialData*>(Sim::findObject("pxInteriorMaterial"));
	if (!interiorMaterial)
	{
		Con::errorf("***PHYSX*** - No Interior Material Datablock! (pxInteriorMaterial) *************");
		return NULL;
	}

	// get the interior
	if (bool(interior.mInteriorRes) == false)
		return NULL;
	Interior* inter = interior.mInteriorRes->getDetailLevel(0);

	//**************************************************************
	// setup for the ripped buildpolylist code
	//**************************************************************
	ConcretePolyList	list;
	Box3F				box = interior.getWorldBox();//  getObjBox();
	MatrixF				transform = interior.mWorldToObj;
	MatrixF				mat = interior.getTransform();
	MatrixF				wmat = interior.getWorldTransform();
	Point3F				scale = interior.getScale();
	MatrixF				local( true);

	box.minExtents.convolve(scale);
	box.maxExtents.convolve(scale);

	list.setTransform(&local, scale);
	list.setObject(&interior);

	//**************************************************************
	// straight from interior::buildpolylist...
	//**************************************************************
	Box3F testBox;
	MatrixF toItr;
	if (!list.getMapping(&toItr,&testBox))
	{
		// this list doesn't do this, use world space box and transform
		testBox = box;
		toItr = transform;
	}

	// construct an interior space box from testBox and toItr
	// source space may be world space, or may be something else...
	// that's up to the list
	// Note: transform maps to interior, but scale is itr -> world...
	//       that is why we divide by scale below...
	F32 * f = toItr;

	F32 xx = mFabs(f[0]); F32 xy = mFabs(f[4]); F32 xz = mFabs(f[8]);
	F32 yx = mFabs(f[1]); F32 yy = mFabs(f[5]); F32 yz = mFabs(f[9]);
	F32 zx = mFabs(f[2]); F32 zy = mFabs(f[6]); F32 zz = mFabs(f[10]);

	F32 xlen = testBox.maxExtents.x - testBox.minExtents.x;
	F32 ylen = testBox.maxExtents.y - testBox.minExtents.y;
	F32 zlen = testBox.maxExtents.z - testBox.minExtents.z;

	F32 invScalex = 1.0f/scale.x;
	F32 invScaley = 1.0f/scale.y;
	F32 invScalez = 1.0f/scale.z;

	F32 xrad = (xx * xlen + yx * ylen + zx * zlen) * invScalex;
	F32 yrad = (xy * xlen + yy * ylen + zy * zlen) * invScaley;
	F32 zrad = (xz * xlen + yz * ylen + zz * zlen) * invScalez;

	Box3F interiorBox;
	testBox.getCenter(&interiorBox.minExtents);
	toItr.mulP(interiorBox.minExtents);

	interiorBox.minExtents.x *= invScalex;
	interiorBox.minExtents.y *= invScaley;
	interiorBox.minExtents.z *= invScalez;

	interiorBox.maxExtents = interiorBox.minExtents;

	interiorBox.minExtents.x -= xrad;
	interiorBox.minExtents.y -= yrad;
	interiorBox.minExtents.z -= zrad;

	interiorBox.maxExtents.x += xrad;
	interiorBox.maxExtents.y += yrad;
	interiorBox.maxExtents.z += zrad;

	U32 waterMark = FrameAllocator::getWaterMark();

	U16* hulls = (U16*)FrameAllocator::alloc(inter->mConvexHulls.size() * sizeof(U16));
	U32 numHulls = 0;

	inter->getIntersectingHulls(interiorBox,hulls, &numHulls);

	if (numHulls == 0) 
	{
		FrameAllocator::setWaterMark(waterMark);
		Con::errorf("***PHYSX*** - Bailed with no intersecting hulls!!! *************");
		return false;
	}

	// we've found all the hulls that intersect the lists interior space bounding box...
	// now cull out those hulls which don't intersect the oriented bounding box...

	Point3F radii = testBox.maxExtents - testBox.minExtents;
	radii *= 0.5f;
	radii.x *= invScalex;
	radii.y *= invScaley;
	radii.z *= invScalez;

	// adjust toItr transform so that origin of source space is box center
	// Note:  center of interior box will be = to transformed center of testBox
	Point3F center = interiorBox.minExtents + interiorBox.maxExtents;
	center *= 0.5f;
	toItr.setColumn(3,center); // (0,0,0) now goes where box center used to...

	//**************************************************************
	// add the hulls...
	//**************************************************************


	// counters...
	int vertexCount = 0;
	int hullAddedCount = 0;
	int surfaceCount = 0;

	for (S32 i=0; i<numHulls; i++)
	{
		const Interior::ConvexHull & hull = (inter->mConvexHulls[hulls[i]]);
		Box3F hullBox(hull.minX,hull.minY,hull.minZ,hull.maxX,hull.maxY,hull.maxZ);
		if (!hullBox.collideOrientedBox(radii,toItr))
			// oriented bounding boxes don't intersect...
			continue;

		for (S32 j=0; j<hull.surfaceCount; j++)
		{
			U32 surfaceIndex = inter->mHullSurfaceIndices[j+hull.surfaceStart];

			if (inter->isNullSurfaceIndex(surfaceIndex))
			{
				// Is a NULL surface
				const Interior::NullSurface& rSurface = inter->mNullSurfaces[inter->getNullSurfaceIndex(surfaceIndex)];
				U32 array[32];

				list.begin(0, rSurface.planeIndex);
				for (U32 k = 0; k < rSurface.windingCount; k++)
				{
					array[k] = list.addPoint(inter->mPoints[inter->mWindings[rSurface.windingStart + k]].point);
					list.vertex(array[k]);
				}

				list.plane(inter->getFlippedPlane(rSurface.planeIndex));
				list.end();
			}
			else
			{
				const Interior::Surface& rSurface = inter->mSurfaces[surfaceIndex];
				U32 array[32];
				U32 fanVerts[32];
				U32 numVerts;

				inter->collisionFanFromSurface(rSurface, fanVerts, &numVerts);

				list.begin(0, rSurface.planeIndex);
				for (U32 k = 0; k < numVerts; k++)
				{
					array[k] = list.addPoint(inter->mPoints[fanVerts[k]].point);
					list.vertex(array[k]);
				}
				list.plane(inter->getFlippedPlane(rSurface.planeIndex));
				list.end();
			}

			surfaceCount++;
		} // end of for (S32 j=0; j<hull.surfaceCount; j++)

		int vertBound = list.mVertexList.size();
		vertexCount = vertexCount + vertBound;

		// flag to see if the normal try fails...
		bool firstTryToCookPassed = true;

		// this is the first try to cook
		if (vertBound != 0)
		{

			NxVec3 * verts = new NxVec3[vertBound];

			// Load vertices
			for(U32 k=0; k<vertBound; k++)
			{
				verts[k].x = list.mVertexList[k].x;
				verts[k].y = list.mVertexList[k].y;
				verts[k].z = list.mVertexList[k].z;
			}	 

			// setup the physx convex mecs shape description
			NxConvexMeshDesc convexDesc;
			convexDesc.numVertices		= vertBound;
			convexDesc.pointStrideBytes	= sizeof(NxVec3);
			convexDesc.points			= verts;
			convexDesc.flags			= NX_CF_COMPUTE_CONVEX;

			// cook it
			MemoryWriteBuffer buf;	
			NxInitCooking();
			bool status = NxCookConvexMesh(convexDesc, buf);
			NxCloseCooking();
			NxActorDesc actorDesc;

			if (status)
			{
				QuatF q(wmat);
				Point3F pos;
				mat.getColumn(3,&pos);
				NxQuat quat;
				quat.setXYZW(q.x,q.y,q.z,q.w);
				NxMat33 M_nx = NxMat33(quat);
				NxVec3 t_nx = NxVec3(pos.x,pos.y,pos.z);

				MemoryReadBuffer readBuffer(buf.data);
				NxConvexShapeDesc sconvexShapeDesc;
				sconvexShapeDesc.meshData = PxWorld->createConvexMesh(readBuffer);
				sconvexShapeDesc.materialIndex = interiorMaterial->id;

				actorDesc.shapes.pushBack(&sconvexShapeDesc);

				actorDesc.body = NULL;
				gInterior = PxWorld->AddActor(actorDesc);

				if (gInterior->active)
				{
					gInterior->actor->setGlobalPosition(NxVec3(pos.x,pos.y,pos.z));
					gInterior->actor->setGlobalOrientationQuat(quat);
					gInterior->actor->userData = (void*) static_cast<SimObject*>( this );
					hullAddedCount = hullAddedCount + 1;
				}
			}
			else
			{
				firstTryToCookPassed = false;
				Con::errorf("***PHYSX*** - NOTE - Failed to add Hull %i! with %i verts.  Trying extruded...", i, vertBound);
			}
		}

		// this is the second try if we failed... we will double the verts down in Z and try to cook that.
		// This should work for almost all failed hulls EXCEPT ones where extruding in Z won't make a convex
		if (vertBound != 0 && !firstTryToCookPassed)
		{
			// first, lets double the vertices
			NxVec3 * verts = new NxVec3[vertBound];

			// Load vertices for the first half
			for(U32 k=0; k<vertBound; k++)
			{
				verts[k].x = list.mVertexList[k].x;
				verts[k].y = list.mVertexList[k].y;
				verts[k].z = list.mVertexList[k].z;
			}

			// setup the physx convex mecs shape description
			NxConvexMeshDesc convexDesc;
			convexDesc.numVertices		= vertBound;
			convexDesc.pointStrideBytes	= sizeof(NxVec3);
			convexDesc.points			= verts;
			convexDesc.flags			= NX_CF_INFLATE_CONVEX | NX_CF_COMPUTE_CONVEX;

			// cook it
			MemoryWriteBuffer buf;	
			NxInitCooking();
			bool status = NxCookConvexMesh(convexDesc, buf);
			NxCloseCooking();
			NxActorDesc actorDesc;

			if (status)
			{
				QuatF q(wmat);
				Point3F pos;
				mat.getColumn(3,&pos);
				NxQuat quat;
				quat.setXYZW(q.x,q.y,q.z,q.w);
				NxMat33 M_nx = NxMat33(quat);
				NxVec3 t_nx = NxVec3(pos.x,pos.y,pos.z);

				MemoryReadBuffer readBuffer(buf.data);
				NxConvexShapeDesc sconvexShapeDesc;
				sconvexShapeDesc.meshData = PxWorld->createConvexMesh(readBuffer);
				sconvexShapeDesc.materialIndex = interiorMaterial->id;

				actorDesc.shapes.pushBack(&sconvexShapeDesc);

				actorDesc.body = NULL;
				gInterior = PxWorld->AddActor(actorDesc);

				if (gInterior->active)
				{
					gInterior->actor->setGlobalPosition(NxVec3(pos.x,pos.y,pos.z));
					gInterior->actor->setGlobalOrientationQuat(quat);
					gInterior->actor->userData = (void*) static_cast<SimObject*>( this );
					hullAddedCount = hullAddedCount + 1;
				}
			}
			else
			{
				Con::errorf("***PHYSX*** - Error - Failed on second try to extrude");
			}
		}
		list.clear();

	} // end of for (S32 i=0; i<numHulls; i++)





	Con::errorf("***PHYSX*** - for this object.....");
	Con::errorf("***PHYSX*** - Added %i Hulls out of %i Total", hullAddedCount, numHulls);
	Con::errorf("***PHYSX*** - with %i surfaces and %i vertices", surfaceCount, vertexCount);
	Con::errorf("***PHYSX*** - **Done with interior**");

	FrameAllocator::setWaterMark(waterMark);
	return NULL;
}