//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// PhysXActor.h
// Create by Shannon Scarvaci
//
// Description:
//   PhysXActor class is the simple box, sphere, capsule, etc for 
//   Dynmaic Rigid Shape.
//
//-----------------------------------------------------------------------------
#ifndef _PHYSX_ACTOR_H_
#define _PHYSX_ACTOR_H_

#ifndef _SHAPEBASE_H_
#include "T3D/shapeBase.h"
#endif

struct PhysXMaterialData : public SimDataBlock
{
	typedef SimDataBlock Parent;

	F32 pxRestitution;
	F32 pxStaticFriction;
	F32 pxDynamicFriction;

	U32 id;

public:
	DECLARE_CONOBJECT(PhysXMaterialData);
	PhysXMaterialData();
	~PhysXMaterialData();
	static void consoleInit();
	static void initPersistFields();
	bool preload(bool server, String &errorStr);
	virtual void packData(BitStream* stream);
	virtual void unpackData(BitStream* stream);
	bool updatePhysX(bool server);
};
DECLARE_CONSOLETYPE(PhysXMaterialData)

//----------------------------------------------------------------------------
struct PhysXActorData: public ShapeBaseData 
{
	typedef ShapeBaseData Parent;

	enum pxShapeOptions
	{
		pxShapeBox = 0,   
		pxShapeSphere,       
		pxShapeCapsule,          
		pxShapeTrimesh,
		pxShapeOther
	};

	S32	 pxShape;
	F32  pxRadius;
	F32  pxHeight;

	bool pxKinematicBody;

public:
	DECLARE_CONOBJECT(PhysXActorData);
	PhysXActorData();
	~PhysXActorData();
	static void consoleInit();
	static void initPersistFields();
	bool preload(bool server, String &errorStr);
	void packData(BitStream* stream);
	void unpackData(BitStream* stream);
};

struct sNxActor;
class NxActorDesc;



//------------------------------------------------------------------
class PhysXActor : public ShapeBase
{
	typedef ShapeBase Parent;
	friend class PhysXJoint;
	friend class Projectile;
	friend class Vehicle;
	friend class PhysXWorld;


private:
	PhysXActorData* mDataBlock;
	bool  remoteClient;
	bool	isCollided;

public:
	DECLARE_CONOBJECT(PhysXActor);

	enum MaskBits
	{
		MaterialDataBlockMask   = Parent::NextFreeMask,
		ActorMask		 = MaterialDataBlockMask << 1,
		PositionMask = ActorMask << 1,
		NextFreeMask = PositionMask << 1
	};

	bool serverSentPhysx;
	NxQuat serverQuat;
	NxVec3 serverPos;
	NxVec3 serverLinear;
	NxVec3 serverAngular;

	bool clientFirstInsert;
	int sendCount;
	bool interpolateTickRemoteClient;

	PhysXActor();
	virtual ~PhysXActor();


protected:
	S32 mNumActor;
	S32 mActorID;
	NxConvexMesh* actorMesh;
	Vector<NxConvexShapeDesc*> convexShapeDesc;
	unsigned int	nbVerts;
	unsigned int		nbFaces;
	NxVec3*		verts;
	unsigned int*		faces;
	sNxActor	  *mActor;
	NxActorDesc actorDesc;

	bool mInMissionArea;          ///< Are we in the mission area?
	///See if the player is still in the mission area
	void checkMissionArea();


public:
	bool mGrabbing;
	bool onAdd();
	void onRemove();
	static void initPersistFields();
	static void consoleInit();
	bool onNewDataBlock(GameBaseData* dptr);
	void processTick(const Move *move);
	void interpolateTick(F32 delta);
	void advanceTime(F32 dt);

    void writePacketData(GameConnection * conn, BitStream *stream);
    void readPacketData (GameConnection * conn, BitStream *stream);
	U32  packUpdate(NetConnection *conn, U32 mask, BitStream *stream);
	void unpackUpdate(NetConnection *conn, BitStream *stream);

	void setTransform(const MatrixF& mat);
	void moveTransform(const MatrixF& mat);
	void ProcessInput();
	bool bMoveKinematicActor;
	bool bToggleKinematicActor;

	void setActorCollided();

	void updateWorkingCollisionSet();
	bool updatePhysX(bool server);
	bool createActor(bool server, bool remote = true);
	void SetupTrimesh(bool server, NxActorDesc &actorDesc);

	bool getNodeLocalPoint(const char* nodeName, Point3F &pos);
	void applyImpulse(const Point3F& pos, const VectorF& vec);
};

#endif