//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// PhysX.h
// Create by Shannon Scarvaci
//
// Description:
//   PhysX Engine allow to run in win32, linux and mac platform.
//   This file is to use PhysX engine with specific platform.
//   Also there is configuration for testing allow to have whole issue to run by
//   PhysX engine including Hardware (PPU)
//
//-----------------------------------------------------------------------------
#ifndef _PHYSX_H_
#define _PHYSX_H_

#ifndef _TORQUE_TYPES_H_
#	include "platform/types.h"
#endif

#if defined(TORQUE_OS_MAC)
#	define __APPLE__
#elif defined(TORQUE_OS_LINUX)
#	define LINUX
#elif defined(TORQUE_OS_WIN32)
#	define WIN32
#endif

#include <NxPhysics.h>
#include <NxStream.h>
#include <NxCooking.h>

#pragma comment(lib, "PhysXLoader.lib")
#pragma comment(lib, "NxCooking.lib")

// PhysX configuration

// do the whole terrain which is 256x256 data collision on 2048x2048 (squareSize = 8) because cannot do whole data otherwise crash!
#define _WHOLE_TERRAIN_ 

// to test on invisiable plane above terrain (250 units above 0 level)
//#define USE_TESTING_PLANE 

// for testing without physXActor collide with player's shapebase
//#define _DONT_USE_SHAPEBASE_ 


#endif