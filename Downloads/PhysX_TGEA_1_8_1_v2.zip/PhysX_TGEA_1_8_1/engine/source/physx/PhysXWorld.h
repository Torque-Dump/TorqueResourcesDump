//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// PhysXWorld.h
// Create by Shannon Scarvaci
//
// Description:
//   This is NetObject object and it create during the script or in mission object.
//   This had to be only one object per game for each server and client.
//
//   MyOutputSteam is the error report from the PhysX engine.
//
//-----------------------------------------------------------------------------
#ifndef _PHYSX_WORLD_H_
#define _PHYSX_WORLD_H_

#ifndef _NETOBJECT_H_
#include "sim/netObject.h"
#endif
#ifndef _ITICKABLE_H_
#include "core/iTickable.h"
#endif

//----------------------------------------------------------------------------
class NxActor;
struct sNxActor { // Need this structure of NxActor to avoid crash when remove NxActor in Server side and client is still active.
	NxActor *actor;
	bool		active; // true - NxActor is exist
};


class NxPhysicsSDK;
class NxScene;
class NxVec3;
typedef float NxReal;
class NxMaterialDesc;
class NxActorDesc;
class NxActorDescBase;
class NxJoint;
class NxJointDesc;
class PhysXTerrain;
class NxTriangleMesh;
class NxConvexMesh;
class NxStream;
class NxHeightField;
class NxHeightFieldDesc;
class ShapeBase;
class InteriorInstance;
class PhysXInterior;
class TSStatic;
class PhysXTSStatic;
class PhysXJoint;
class PhysXWorld : public NetObject, public virtual ITickable
{
private:
	typedef NetObject Parent;
    friend class TSStatic;

	NxPhysicsSDK	*gPhysicsSDK;
	NxScene			*gScene; // non-hardware
	NxScene			*gSceneHW; // hardware (PPU)
	VectorF			gDefaultGravity;

	PhysXTerrain		*pxTerrain;
	Vector <PhysXInterior*> mInteriorList;
	Vector <PhysXTSStatic*> mTSStaticList;

protected:
	bool  mRemoteClient; // false - single player, which have different network system and it faster
	bool  mErrorReport;
	static PhysXWorld *mPhysXWorldServer;
	static PhysXWorld *mPhysXWorldClient;

	bool	mStartPhysX;
public:
	PhysXWorld(void);

	static PhysXWorld* getWorld(bool bIsServer);
	static const PhysXWorld * getServerObject() { return mPhysXWorldServer; };
	static const PhysXWorld * getClientControlObject() { return mPhysXWorldClient; };

	bool createWorld();

	// SimObject
	bool onAdd();
	void onRemove();

	virtual void processTick();
	virtual void interpolateTick(F32 delta);
	virtual void advanceTime(F32 dt);

	static void initPersistFields();

	enum NetMaskBits {
		UpdateMask     = BIT(0)
	};

	U32  packUpdate  (NetConnection *conn, U32 mask, BitStream *stream);
	void unpackUpdate(NetConnection *conn,           BitStream *stream);

	void StartPhysics(NxReal deltaTime);
	void GetPhysicsResults();
	void ProcessInput();

	unsigned short createMaterial(NxMaterialDesc &material);
	unsigned short setMaterial(NxMaterialDesc &material, unsigned short id);
	sNxActor* AddActor(const NxActorDescBase &actorDesc);
	sNxActor* AddShapeBase(ShapeBase *shape);
	NxJoint* AddJoint(const NxJointDesc &jointDesc);
	NxTriangleMesh* createTriangleMesh(const NxStream& stream);
	NxConvexMesh* createConvexMesh(const NxStream& stream);
	NxHeightField* createHightfield(const NxHeightFieldDesc& hightField);
	bool		 RemoveActor(sNxActor  &actor);
	bool		 RemoveJoint(NxJoint &joint);

	bool isRemoteClient() { return mRemoteClient; }
	bool updatePhysX(); // call all PhysX's relate objects to update into this PhysX once PhysXWorld loaded (server sided)
	void StartPhysX();
	void debugPhysX();
	bool updateJoints();

	void SetupTerrainCollision();
	sNxActor* SetupInterior(InteriorInstance &);
	void SetupTSStatic(TSStatic &);

	DECLARE_CONOBJECT(PhysXWorld);

	//hanna added
	bool onFirstServerCycle;
	bool onFirstClientCycle;
	int physxTickCount;
	int physxTickCycle;
	int lastCycleTime;

};

#endif
