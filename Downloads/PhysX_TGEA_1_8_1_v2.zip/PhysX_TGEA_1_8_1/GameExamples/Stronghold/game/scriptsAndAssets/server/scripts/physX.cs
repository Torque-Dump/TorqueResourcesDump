﻿// ============================================================
// Project      :   PhysXTGE
// File         :   .\starter.fps\server\scripts\physX.cs
// Copyright    :   © 2006
// Author       :   
// Editor       :   Codeweaver 1.2.2199.34718
// 
// Description  :   
//              :   
//              :   
// ============================================================
datablock PhysXMaterialData(pxInteriorMaterial) {
	pxRestitution = 0.5;
	pxStaticFriction = 0.5;
	pxDynamicFriction = 0.5;
};

datablock PhysXMaterialData(pxTerrainMaterial) {
	pxRestitution = 0.5;
	pxStaticFriction = 0.5;
	pxDynamicFriction = 0.5;
};

function PhysXActor::onLeaveMissionArea(%this) {
	echo("Leave: " @ %this);
	%this.setProcessTick(false);
	%this.schedule(150,"delete"); // make sure client side to stop ticking before delete!
}