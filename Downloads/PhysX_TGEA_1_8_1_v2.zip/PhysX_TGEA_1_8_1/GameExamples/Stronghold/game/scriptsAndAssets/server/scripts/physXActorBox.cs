// ============================================================
// Project      :   RedbackStudios
// File         :   .\auslan\server\scripts\pxActorBox.cs
// Copyright    :   © 2006
// Author       :   
// Editor       :   Codeweaver 1.2.2199.34718
// 
// Description  :   
//              :   
//              :   
// ============================================================

datablock PhysXMaterialData(pxMaterialBox)
{
	pxRestitution = 0.5;
	pxStaticFriction = 0.5;
	pxDynamicFriction = 0.5;
};

datablock PhysXActorData(pxCrate1)
{
   // Mission editor category
   category = "Physics";

   pxShape = "box";
   friction = 0.5;
   mass = 30.0;
   elasticity = 0.5;
   shapeFile = "~/data/shapes/boxes/crate/crate.dts";
   materialBlock = pxMaterialBox;
};

datablock PhysXActorData(pxBox)
{
   // Mission editor category
   category = "Physics";

   pxShape = "box";
   friction = 0.5;
   mass = 100.0;
   elasticity = 0.5;
   shapeFile = "~/data/shapes/crates/crate1.dts";
   materialBlock = pxMaterialBox;
};

function PhysXActorData::create(%data)
{
	%obj = new PhysXActor() {
		dataBlock = %data;
	};
	return %obj;
}

function serverCmdpxbox(%client) {
	createpxBox(%client);
}

function createpxBox(%client)
{
   %pos = %client.getControlObject().getPosition();
   %actor = new PhysXActor()
   {
      position = %pos;
      rotation = "1 0 0 0";
      dataBlock = pxBox;
      materialBlock = pxMaterialBox;
   };
   MissionCleanup.add(%actor);
}

function serverCmdpxcrate(%client)
{
	createpxCrate(%client);
}

function createpxCrate(%client)
{
   %pos = %client.getControlObject().getPosition();
   %actor = new PhysXActor()
   {
      position = %pos;
      rotation = "1 0 0 0";
      dataBlock = pxCrate1;
      materialBlock = pxMaterialBox;
   };
   MissionCleanup.add(%actor);
}