Below resource MUST be installed for the barrel angle to work correctly.
SetForwardVector Resource: http://www.torquepowered.com/community/resources/view/15119


1. Place missileVehicle.cc,.h into your engine/game/vehicles/ folder and install the above required resource and recompile your project.(At this point your done in VC++)

2. Place missile.cs and javelin.cs into your server/scripts/ folder and exec from your game.cs file.

3. Place the Javelin folder into your data/shapes/ folder.

4. In your player.cs file add this code into your player datablock:
[code]
   maxInv[JavelinAmmo] = 50;
   maxInv[Javelin] = 1;
[/code]
Then add this to the bottom of the file:
[code]
//----------------------------------------------------------------------------
// Missile Control
//----------------------------------------------------------------------------
function Player::MissileControl(%this, %obj)
{
      echo("\c3missile Mounted");
      echo("\c4Obj.Client#: " @ %obj.client);
      echo("\c4Obj#: " @ %obj);
      
      //commandToClient(%obj.client, 'setHudMode', 'HeliPilot');
      commandToClient(%obj.client, 'SetmissilePilotVehicleKeys');

      $mvForwardAction = 1;
}
//----------------------------------------------------------------------------
[/code]

5. At the bottom of your commands.cs file (server side) add:
[code]
//------------------------------------------------------------------------------
// Javelin Missile
//------------------------------------------------------------------------------
function serverCmdCreateMissile(%client)//fixme
{
    %player = %client.player;
    
    
    if(%client.player$="")
      return;
    if(%client.player)
      if(%client.player.isMounted())
         return;
    %vehicle = new MissileVehicle()
    {
       dataBlock = Missile;
    };
    %vehicle.mountable = true;
    %vehicle.setEnergyLevel(60);

    // Spawn the car 10 units in front of the player rotated so that the driver-side
    // door is facing them and taking the terrain height into account
    // Get the position of the player's eye
    %pos = %client.player.getMuzzlePoint($WeaponSlot);
    // Use the ForwardVector calculate a 10 unit offset vector
    %offset = VectorScale( %client.player.getForwardVector(), 1.25 );
    // Add the offset to the position to get a point 1.25 units in front of the player
    %spawn = VectorAdd( %pos, %offset );
    // Now get the terrain height at that point to avoid spawning the car inside a hill
    // getTerrainHeight() takes an x and y position
    %xy = getWord( %spawn, 0 ) SPC getWord( %spawn, 1 );
    // Get a spawn point 1.25 units in front of the player but
    // at the height of the terrain plus a little extra padding
    %spawn = getWord(%spawn, 0) SPC getWord(%spawn, 1) SPC getTerrainHeight(%xy) + 2;


    // Get the transform
    %trans = %client.player.getTransform();  //default
    //%trans = %client.player.getMountedImage($WeaponSlot).getMuzzleVector($WeaponSlot);
  
    
    // Get the rotational axis
    %axis = getWord( %trans, 3 ) SPC getWord( %trans, 4 ) SPC getWord( %trans, 5 );

    // Get the ang that the player is rotated around the axis
    // Compensate for inverted axis
    if (getWord(%axis, 2) < 0)
      %ang = -getWord( %trans, 6 );
    else
      %ang =  getWord( %trans, 6 );

    // Add the rotation to make the door face the player (270 degrees in radians)
    %ang += 6.3;  //default    // exec("./common/scripts/server/core/commands.cs");
    //%ang += 0;

    // Now set the transform we calculated
    %vehicle.setTransform( %spawn SPC "0 0 1" SPC %ang );
    %vehicle.setForwardVector(%client.player.getMuzzleVector(0));

    //%vehicle.setGravity(0);// Optional recommended :)
    %vehicle.nextWeaponFire = 1;
    //%vehicle.schedule(5500, "playThread", $ActivateThread, "activate");
    MissionCleanup.add(%vehicle);
    
    
    
    
   // Set newly spawned missile as ControlObject here
   ////messageClient( %client, 'MsgMountSuccess', '\c2Entering missile- %1.', %vehicle.getDataBlock().nameTag);
   
   %client.setControlObject(%vehicle);  
   %player.MissileControl(%player);
   
   ////return;
}

function serverCmdUnmountmissile(%client) //Used when Missile is destroyed
{
      %client.setControlObject(%client.player);  
      
      commandToClient(%client, 'RestoreMoveMap');
      CommandToClient(%client, 'NormalMovement');
      commandToClient(%client, 'setHudMode', 'Play');
}
//------------------------------------------------------------------------------
[/code]

6. At the bottom of your default.bind.cs file add:
[code]
//------------------------------------------------------------------------------
//  Missile Functions
//------------------------------------------------------------------------------
function clientCmdSetMissilePilotVehicleKeys()
{
   new ActionMap( MissilePilotKeys );


   //MissilePilotKeys.bind( mouse, "button1", mouseFire );
   //MissilePilotKeys.bind( mouse, "button2", altTrigger );
   MissilePilotKeys.Bind( keyboard, "d", moveleft ); //for some reason these are reverse
   MissilePilotKeys.Bind( keyboard, "a", moveright );//for some reason these are reverse 
   
   
   //MissilePilotKeys.bind( keyboard, "w", moveforward );
   //MissilePilotKeys.bind( keyboard, "s", reducethrust );
   //MissilePilotKeys.bind( keyboard, "q", mouseJetdn );
   //MissilePilotKeys.bind( keyboard, "e", mouseJet );
   
   MissilePilotKeys.bind( mouse, "xaxis", missileyaw );
   MissilePilotKeys.bind( mouse, "yaxis", missilepitch );
   //MissilePilotKeys.copyBind( moveMap, panUp );
   //MissilePilotKeys.copyBind( moveMap, panDown );

   MissilePilotKeys.copyBind( moveMap, toggleFirstPerson );
   MissilePilotKeys.copyBind( moveMap, toggleFreeLook );


   // Miscellaneous other binds:
   MissilePilotKeys.bindCmd( keyboard, "escape", "", "escapeFromGame();" );


   // Use the InvertVehicleYAxis pref:
   if ( $pref::Vehicle::InvertYAxis )
   {
      %bind = moveMap.getBinding( pitch );
      %device = getField( %bind, 0 );
      %action = getField( %bind, 1 );
      %flags = moveMap.isInverted( %device, %action ) ? "SD" : "SDI";
      %deadZone = moveMap.getDeadZone( %device, %action );
      %scale = moveMap.getScale( %device, %action );
      MissilePilotKeys.bind( %device, %action, %flags, %deadZone, %scale, pitch );
   }
   if ( isObject( moveMap ) )
      moveMap.pop();

   MissilePilotKeys.push();
}

function missileyaw(%val)
{
   $mvYaw += getMouseAdjustAmount(%val) * 4;
}

function missilepitch(%val)
{
   $mvPitch += getMouseAdjustAmount(%val) * 4;
}

function clientCmdNormalMovement()
{
   $mvForwardAction = 0;
   $mvPitchUpSpeed = 0;
   $mvPitchDownSpeed = 0;
}

function clientCmdRestoreMoveMap()
{
   moveMap.push();
}
//------------------------------------------------------------------------------
[/code]

Note: Testing this I have found that for some reason upon impact the missile is not exploding, I am using a much differant codebase then StockTGE so I am not sure why the impact code is not being called.

I have also included a basic cylinder with the required nodes to be used as a template.

Btw: The MissileVehicle type is a HeliVehicle without Jetdn to avoid dealing with the vehicle.cc,.h changes required, so if you have the HeliVehicle resource pre-installed and do not want another module then simply rename MissileVehicle to HeliVehicle.