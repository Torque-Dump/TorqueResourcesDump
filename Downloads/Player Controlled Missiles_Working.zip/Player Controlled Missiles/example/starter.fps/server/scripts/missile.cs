//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// Missile Emitter profiles

datablock ParticleData(MissileTrailParticle)
{
  dragCoefficient      = 1.5;
  gravityCoefficient   = 0;
  inheritedVelFactor   = 0.2;
  constantAcceleration = 0.0;
  lifetimeMS           = 1500;
  lifetimeVarianceMS   = 750;
  textureName          = "~/data/shapes/crossbow/splash";
  colors[0]     = "0.9 0.4 0.4 0.9";
  colors[1]     = "0.9 0.9 0.9 0.7";
  colors[2]     = "0.6 0.6 0.5 0.2";
  sizes[0]      = 0.3;
  sizes[1]      = 0.5;
  sizes[2]      = 0.7;
};

datablock ParticleEmitterData(MissileTrailEmitter)
{
  ejectionPeriodMS = 7;
  periodVarianceMS = 5;
  ejectionVelocity = 1;
  velocityVariance = 0.7;
  ejectionOffset   = 0.0;
  thetaMin         = 0;
  thetaMax         = 10;
  phiReferenceVel  = 0;
  phiVariance      = 360;
  overrideAdvances = false;
  particles = "MissileTrailParticle";
};
//-----------------------------------------------------------------------------
datablock MissileVehicleData(missile)
{
   vehicleType = "missile";
   category    = "Missile";
   shapeFile   = "~/data/shapes/javelin/missile.dts";
   emap        = "true";

   // TGE 1.5
   shadowEnable = "true";
   shadowCanMove = "true";
   shadowCanAnimate = "true";

   mountable     = "true";
   maxMountSpeed = "40.0";
   mountDelay    = "0";
   dismountDelay = "10.5";

   stationaryThreshold = "0.5";
   maxDismountSpeed    = "10.0";
   numMountPoints      = "1";

   mountPose[0]             = "Sitting";
   mountPointTransform[0]   = "0 0 0 0 0 1 0";
   isProtectedMountPoint[0] = "false";
   
   
   maxDamage      = "5.0";
   destroyedLevel = "5.0";

   // 3rd person camera settings
   cameraRoll = "true";           // Roll the camera with the vehicle
   cameraMaxDist = 0.2;
   cameraMinDist = 0.001;
   cameraOffset = "0.0";             // Vertical offset from camera mount point
   cameraLag = "0.001";              // Velocity lag of camera
   cameraDecay = "0.001";           // Decay per sec. rate of velocity lag

   isShielded = "true";

   maxEnergy = "350";              //Afterburner and any energy weapon pool
   rechargeRate = "0";

   minDrag = "350";                //Linear Drag (eventually slows you down when not thrusting...constant drag)
   rotationalDrag = "20";          //Anguler Drag (dampens the drift after you stop moving the mouse...also tumble drag)

   maxAutoSpeed = "15";            //Autostabilizer kicks in when less than this speed. (meters/second)
   autoAngularForce = "200";        //Angular stabilizer force (this force levels you out when autostabilizer kicks in) up & down force
   autoLinearForce = "200";         //Linear stabilzer force (this slows you down when autostabilizer kicks in)
   autoInputDamping = "0.95";      //Dampen control input so you don't` whack out at very slow speeds
   
   // Maneuvering
   maxSteeringAngle = "3.5";       //Max radiens you can rotate the wheel. Smaller number is more maneuverable.//5
   horizontalSurfaceForce = "120";  //Horizontal center "wing" (provides "bite" into the wind for climbing/diving & turning)
   verticalSurfaceForce = "100";   //Vertical center "wing" (controls side slip. lower numbers make MORE slide.)
   maneuveringForce = "650";       //Horizontal Thrust
   steeringForce = "1700";         //Steering jets (force applied when you move the mouse)
   steeringRollForce = "400";      //Steering jets (how much you heel over when you turn)
   rollForce = "1000";              //Auto-roll (self-correction to right you after you roll/invert)
   HoverHeight = "2.5";             //Height off the ground at rest
   createflyingHeight = "5";       // Height off the ground when created

   // Turbo Jet
   jetForce = "1500";              //Vertical Thrust
   minJetEnergy = "0.0";           //Afterburner can't be used if below this threshhold.
   jetEnergyDrain = "0.0";         //Energy use of the afterburners (low number is less drain...can be fractional)
   vertThrustMultiple = "200";      //Higher number means going up and down faster



   // Rigid body
   mass = "400";                   //Mass of the vehicle
   bodyFriction = "0";             //Don't mess with this.
   bodyRestitution = "0.5";        //When you hit the ground, how much you rebound. (between 0 and 1)
   minRollSpeed = "500";           //Don't mess with this.
   softImpactSpeed = "0";          //Sound hooks. This is the soft hit.
   hardImpactSpeed = "10";         //Sound hooks. This is the hard hit.

   // Ground Impact Damage (uses DamageType::Ground)
   minImpactSpeed = "2";         //If hit ground at speed above this then it's an impact. Meters/second
   speedDamageScale = "30";

   // Object Impact Damage (uses DamageType::Impact)
   collDamageThresholdVel = "2";
   collDamageMultiplier   = "30";
   collisionTol = "5.0";           // Collision distance tolerance
   contactTol = "5.0";             // Contact velocity tolerance
   
   // Sounds
   //engineSound             = RocketFlightSound;

/*
   damageEmitter[0]        = "HeliHeavyDamageEmitter";
   damageEmitter[1]        = "HeliLightDamageEmitter";
   damageEmitterOffset[0]  = "";
   damageLevelTolerance[0] = "0.7";
   damageLevelTolerance[1] = "0.9";
   numDmgEmitterAreas      = "1";
*/

   // vehicleData Smoke under the vehicle
   //dustEmitter = "HeliVehicleDustEmitter";
   //triggerDustHeight = "15";
   //dustHeight = "0.5";

  minTrailSpeed = 5; // The speed your contrail shows up at.
  TrailEmitter = CrossbowBoltEmitter;
  TrailEmitterOffset = "0.0 0.0 0.0";
  TrailEmitterHeight = 3.6;
  TrailEmitterFreqMod = 15.0;

   // Explosion
   explosion       = "CrossbowExplosion";  //This should be changed to an available explosion
   //debrisShapeName = "~/data/shapes/crossbow/debris.dts";
   //debris          = defaultHeliDebri;

   nameTag = "missile";
   

};



function MissileVehicleData::onCollision(%this,%obj,%col,%vec,%speed)
{
   // Collision with other objects, including items
   // need to set this up later

    // Apply damage to the object all shape base objects
   if ( %speed >= 20 )
   {
      if (%col.getType() & $TypeMasks::ShapeBaseObjectType)
      %col.damage(%obj,%pos,( 3 * %speed ), "MissileVehicle");
   }
}

function MissileVehicleData::onDamage(%this,%obj)
{
   %damageAmt = %obj.getDamageLevel();

   if (%damageAmt >= %this.destroyedLevel)
   {
         %obj.setDamageState(Destroyed);
   }
}

function MissileVehicleData::damage(%data, %myObj, %sourceObj, %position, %amount, %damageType, %momentum)
{
  %myObj.applyDamage(%amount);
}

//----------------------------------------------------------------------------
// Basic Vehicle Functions
//----------------------------------------------------------------------------
function VehicleData::onImpact(%data, %obj, %col, %vec, %vecLen)
{
   //error("VehicleData::onImpact(" SPC %data.getName() @", "@ %obj.getClassName() @", "@ %col @", "@ %vec @", "@ %vecLen SPC ")");

   if ( %vecLen > %data.minImpactSpeed )
      %obj.damage( 0, VectorAdd(%obj.getPosition(), %vec), %vecLen * %data.speedDamageScale, "Impact" );

   // associated "crash" sounds
   if(%vecLen > %data.hardImpactSpeed)
      %obj.playAudio(0, %data.hardImpactSound);
   else if(%vecLen > %data.softImpactSpeed)
      %obj.playAudio(0, %data.softImpactSound);
}


//----------------------------------------------------------------------------
// Missile Functions
//----------------------------------------------------------------------------
function missile::onAdd(%this,%obj)
{
   %obj.mountable = false;
   //%obj.playThread(0,"ambient");   //Used for animations if needed

   %obj.setEnergyLevel(%this.MaxEnergy);
   %obj.setRechargeRate(%this.rechargeRate);
}


function missile::onDestroyed(%data, %obj, %prevState)
{
  commandToServer('Unmountmissile');
  %obj.schedule(100, "delete");
}