//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//	Particles
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Projectile Object - There are no underwater particle params for projectiles
/*
datablock ProjectileData(JavelinProjectile)
{
   projectileShapeName = "~/data/shapes/crossbow/projectile.dts";   
   scale = "0.8 0.8 0.8";
   faceViewer = false;
   doDynamicClientHits = true;

   directDamage = 100;
   radiusDamage = 80;
   damageRadius = 8;
   areaImpulse  = 1200;
   damageType = "Javelin";
   kickBackStrength = 2000;


   explosion           = CrossbowExplosion;
   waterExplosion      = CrossbowWaterExplosion;


   particleEmitter = CrossbowBoltEmitter;
   particleWaterEmitter = CrossbowBoltBubbleEmitter;
   Splash = CrossbowSplash;

   muzzleVelocity = 100;
   velInheritFactor = 1;

   armingDelay = 0;
   lifetime = 3000;
   fadeDelay = 1500;

   isBallistic = false; // Causes the projectile to be affected by gravity.
   gravityMod = 1;

   bounceElasticity = 0;
   bounceFriction = 0;

   hasLight = true;
   lightRadius = 2.0;
   lightColor = "0 0 0.5 1.0";

   hasWaterLight = true;
   waterLightColor = "0.5 0.5 0.5 1.0";
};
*/
//-----------------------------------------------------------------------------
// Weapon Item.  This is the item that exists in the world, i.e. when it's
// been dropped, thrown or is acting as re-spawnable item.  When the weapon
// is mounted onto a shape, the RifleImage is used.

datablock ItemData(Javelin)
{
   // Mission editor category
   category = "Weapon";

   // Hook into Item Weapon class hierarchy. The weapon namespace
   // provides common weapon handling functions in addition to hooks
   // into the inventory system.
   className = "Weapon";

   // Basic Item properties
   shapeFile = "~/data/shapes/crossbow/weapon.dts";
   mass = 1;
   elasticity = 0.2;
   friction = 0.6;
   emap = true;

	// Dynamic properties defined by the scripts
   pickUpName = 'Javelin';
   image = JavelinImage;
};

//-----------------------------------------------------------------------------
// Ammo Item

datablock ItemData(JavelinAmmo)
{
   // Mission editor category
   category = "Ammo";

   // Add the Ammo namespace as a parent.  The ammo namespace provides
   // common ammo related functions and hooks into the inventory system.
   className = "Ammo";

   // Basic Item properties
   shapeFile = "~/data/shapes/crossbow/ammo.dts";
   mass = 1;
   elasticity = 0.2;
   friction = 0.6;

   // Dynamic properties defined by the scripts
   pickUpName = "Javelin Shell";
   maxInventory = 20;
};

//-----------------------------------------------------------------------------
// Rifle image which does all the work.  Images do not normally exist in
// the world, they can only be mounted on ShapeBase objects.

datablock ShapeBaseImageData(JavelinImage)
{
   className = "WeaponImage";
   shapeFile = "~/data/shapes/crossbow/weapon.dts";
   computeCRC = false;
   emap = true;
   cloakable = true;
   mass = 5;

   //---------------------------------- This code that may not work correctly or as desired...
   mountPoint = 0;
   //offset = "0 0 -0.02"; // L/R - F/B - T/B                 
   //rotation = "1 0 0 0";
   //1st val=left(-)/right(+), 2nd val=back(-)/fore(+), 3rd val=down(-)/up(+)
   eyeOffset = "0 0 0";
   //eyeRotation = "1 0 0 0";
   //useEyeOffset = false;
   //firstPerson = true;
   correctMuzzleVector = false;
   //armThread = rPistol1;
   //usesEnergy = false;
   //minEnergy = 50;
   //fireEnergy = 50;
   //accuFire = true;
   //------------------------------------

   // Projectile && Ammo.
   item = Javelin;
   ammo = JavelinAmmo;


   lightType = "NoLight"; // NoLight, ConstantLight, PulsingLight, WeaponFireLight.
   //lightColor = "0.800000 0.000000 0.000000 1.000000";
   //lightTime = 1000; // Indicates the time when the light effect started.
   //lightRadius = 2; // Extent of light.

   // Single-Shot FSM
   stateName[0]                     = "Preactivate";
   stateTransitionOnLoaded[0]       = "Activate";
   stateTransitionOnNoAmmo[0]       = "NoAmmo";

   // Activating the gun.  Called when the weapon is first
   // mounted and there is ammo.
   stateName[1]                     = "Activate";
   stateTransitionOnTimeout[1]      = "Ready";
   stateTimeoutValue[1]             = 0.1;
   stateSequence[1]                 = "Activate";

   // Ready to fire, just waiting for the trigger
   stateName[2]                     = "Ready";
   stateTransitionOnNoAmmo[2]       = "NoAmmo";
   stateTransitionOnTriggerDown[2]  = "Fire";

   // Fire the weapon. Calls the fire script which does 
   // the actual work.
   stateName[3]                     = "Fire";
   stateFire[3]                     = true;
   stateRecoil[3]                   = LightRecoil;
   stateAllowImageChange[3]         = false;
   stateSequence[3]                 = "Fire";
   stateScript[3]                   = "onFire";
   stateSound[3]                    = CrossbowFireSound;
   //stateEmitter[3]                  = "RocketFireEmitter"; 
   stateEjectShell[3]               = true;
   stateTransitionOnTimeout[3]      = "WaitForRelease";
   stateTimeoutValue[3]             = 0.1;

   // Should jam states until mouse is released...
   // Needs some work...
	 stateName[4]                     = "WaitForRelease";   //mp added for True Semi-Auto
   stateTransitionOnTriggerUp[4]    = "Reload";      
   stateSequence[4]                 = "WaitForRelease";

   // Play the relead animation, and transition into
   stateName[5]                     = "Reload";
   stateTransitionOnNoAmmo[5]       = "NoAmmo";
   stateTransitionOnTimeout[5]      = "Ready";
   stateTimeoutValue[5]             = 1; //w 0.8
   stateAllowImageChange[5]         = false;
   stateSequence[5]                 = "Reload";
   //stateSound[5]                    = ReloadSound;

   // No ammo in the weapon, just idle until something
   // shows up. Play the dry fire sound if the trigger is
   // pulled.
   stateName[6]                     = "NoAmmo";
   stateTransitionOnAmmo[6]         = "Reload";
   stateSequence[6]                 = "NoAmmo";
   stateTransitionOnTriggerDown[6]  = "DryFire";

   // No ammo dry fire
   stateName[7]                     = "DryFire";
   stateTransitionOnTriggerUp[7]    = "NoAmmo";
   //stateTimeoutValue[7]           = 0.9;
   //stateTransitionOnTimeout[7]    = "NoAmmo";
   stateSound[7]                    = CrossbowFireEmptySound;
};

//----------------------------------------------------------------------------
// Functions
//----------------------------------------------------------------------------
function JavelinImage::onFire(%this, %obj, %slot)
{
	// Decrease the weapons ammo on fire
	%obj.decInventory(%this.ammo,1);

   //echo("\c4JavelinImage::onFire Recoil = HighModerate");
   //%this.recoilType = "highmoderate";


   //fixme
   commandToServer('CreateMissile');
}

