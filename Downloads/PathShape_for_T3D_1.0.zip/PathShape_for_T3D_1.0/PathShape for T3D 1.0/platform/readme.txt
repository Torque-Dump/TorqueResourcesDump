add this to:
\Templates\Full\game\art\shapes