// heliPassengerMap.cs

if ( isObject( heliPassengerMap ) )
   heliPassengerMap.delete();
new ActionMap(heliPassengerMap);

//------------------------------------------------------------------------------
// Non-remapable binds
//------------------------------------------------------------------------------
function escapeFromGame()
{
   echo("heliPassengerMap");

   if ( $Server::ServerType $= "SinglePlayer" )
      MessageBoxYesNo( "Quit Mission", "Exit from this Mission?", "disconnect();", "");
   else
      MessageBoxYesNo( "Disconnect", "Disconnect from the server?", "disconnect();", "");
}

heliPassengerMap.bindCmd(keyboard, "escape", "", "escapeFromGame();");
heliPassengerMap.bindcmd(keyboard, "F2", "", "PlayerListGui.toggle();");

//------------------------------------------------------------------------------
// Message HUD functions
//------------------------------------------------------------------------------
heliPassengerMap.bind(keyboard, c, toggleMessageHud );
heliPassengerMap.bind(keyboard, "pageUp", pageMessageHudUp );
heliPassengerMap.bind(keyboard, "pageDown", pageMessageHudDown );
heliPassengerMap.bind(keyboard, "p", resizeMessageHud );

//------------------------------------------------------------------------------
// Demo recording functions
//------------------------------------------------------------------------------
heliPassengerMap.bind( keyboard, F3, startRecordingDemo );
heliPassengerMap.bind( keyboard, F4, stopRecordingDemo );

//------------------------------------------------------------------------------
// Helper Functions
//------------------------------------------------------------------------------
//heliPassengerMap.bind(keyboard, "F8", dropCameraAtPlayer);
//heliPassengerMap.bind(keyboard, "F7", dropPlayerAtCamera);

//------------------------------------------------------------------------------
// Misc.
//------------------------------------------------------------------------------

heliPassengerMap.bind(keyboard, tab, toggleFirstPerson );
heliPassengerMap.bindCmd(keyboard, "q", "commandToServer(\'FindNextFreeSeat\');", "");
heliPassengerMap.bindCmd(keyboard, "e", "commandToServer(\'DismountVehicle\');", "");
heliPassengerMap.bind(keyboard, "alt c", toggleCamera);
heliPassengerMap.bindCmd(keyboard, "ctrl k", "commandToServer('suicide');", "");

function mouseFire(%val)
{
   $mvTriggerCount0++;
}

moveMap.bind( mouse, button0, mouseFire );

