if ( isObject( heliDriverMap ) )
   heliDriverMap.delete();
new ActionMap(heliDriverMap);

//------------------------------------------------------------------------------
// Non-remapable binds
//------------------------------------------------------------------------------
function escapeFromGame()
{
   echo("heliDriverMap");

   if ( $Server::ServerType $= "SinglePlayer" )
      MessageBoxYesNo( "Quit Mission", "Exit from this Mission?", "disconnect();", "");
   else
      MessageBoxYesNo( "Disconnect", "Disconnect from the server?", "disconnect();", "");
}

heliDriverMap.bindCmd(keyboard, "escape", "", "escapeFromGame();");
heliDriverMap.bindcmd(keyboard, "F2", "", "PlayerListGui.toggle();");

//------------------------------------------------------------------------------
// Mouse Trigger
//------------------------------------------------------------------------------

function mouseFire(%val)
{
   $mvTriggerCount0++;
}

function altTrigger(%val)
{
   $mvTriggerCount1++;
}

function altTrigger2(%val)
{
   $mvTriggerCount5++;
}

heliDriverMap.bind( mouse, button0, mouseFire );
heliDriverMap.bind( mouse, button1, altTrigger );

//------------------------------------------------------------------------------
// Movement Keys
//------------------------------------------------------------------------------
function turnLeft(%val)
{
   $mvLeftAction = %val;
}

function turnRight(%val)
{
   $mvRightAction = %val;
}

//------------------------------------------------------------------------------
// Incremental Keys
//------------------------------------------------------------------------------
function yawLeft(%val)
{
   if(%val)
           $incYawid = schedule(100,0,"incYaw",-1);
        else
        {
           cancel($incYawid);  
           $mvYaw = 0;
        }    
 }

function yawRight(%val)
{
   if(%val)
           $incYawid = schedule(100,0,"incYaw",1);
        else
        {
           cancel($incYawid);  
           $mvYaw = 0;
        }    
}

function incYaw(%val)
{
    $mvYaw += %val;
   $incYawid = schedule(100,0,"incYaw",%val);
}


function pitchUp(%val)
{
   if(%val)
           $incPitchId = schedule(100,0,"incPitch",-1);
        else
        {
           cancel($incPitchId);  
           $mvPitch = 0;
        }    
}

function pitchDown(%val)
{
   if(%val)
           $incPitchId = schedule(100,0,"incPitch",1);
        else
        {
           cancel($incPitchId);  
           $mvPitch = 0;
        }    
}

function incPitch(%val)
{
     $mvPitch += %val;
   $incPitchId = schedule(100,0,"incPitch",%val);
}

//------------------------------------------------------------------------------
heliDriverMap.bind( keyboard, w, moveforward );
heliDriverMap.bind( keyboard, s, movebackward );
heliDriverMap.bind( mouse, xaxis, yaw );
heliDriverMap.bind( mouse, yaxis, pitch );
heliDriverMap.bind( keyboard, a, mouseJet );
heliDriverMap.bind( keyboard, d, mouseJetdn );

//------------------------------------------------------------------------------
// Message HUD functions
//------------------------------------------------------------------------------
heliDriverMap.bind(keyboard, c, toggleMessageHud );
heliDriverMap.bind(keyboard, "pageUp", pageMessageHudUp );
heliDriverMap.bind(keyboard, "pageDown", pageMessageHudDown );
heliDriverMap.bind(keyboard, "p", resizeMessageHud );

//------------------------------------------------------------------------------
// Demo recording functions
//------------------------------------------------------------------------------
heliDriverMap.bind( keyboard, F3, startRecordingDemo );
heliDriverMap.bind( keyboard, F4, stopRecordingDemo );

//------------------------------------------------------------------------------
// Helper Functions
//------------------------------------------------------------------------------
heliDriverMap.bind(keyboard, "F8", dropCameraAtPlayer);
heliDriverMap.bind(keyboard, "F7", dropPlayerAtCamera);

//------------------------------------------------------------------------------
// Misc.
//------------------------------------------------------------------------------
heliDriverMap.bind(keyboard, tab, toggleFirstPerson );
heliDriverMap.bindCmd(keyboard, "q", "commandToServer(\'FindNextFreeSeat\');", "");
heliDriverMap.bindCmd(keyboard, "ctrl k", "commandToServer('suicide');", "");
heliDriverMap.bind(keyboard, "alt c", toggleCamera);
heliDriverMap.bindCmd(keyboard, "m", "commandToServer(\'DismountVehicle\');", "");
heliDriverMap.bind( keyboard, z, toggleFreeLook );

//------------------------------------------------------------------------------
// Zoom and FOV functions
//------------------------------------------------------------------------------
if($Pref::player::CurrentFOV $= "")
   $Pref::player::CurrentFOV = 45;

function toggleZoom( %val )
{
   if ( %val )
   {
      $ZoomOn = true;
      setFov( $Pref::player::CurrentFOV );
   }
   else
   {
      $ZoomOn = false;
      setFov( $Pref::player::DefaultFov );
   }
}

heliDriverMap.bind(keyboard, e, toggleZoom);
