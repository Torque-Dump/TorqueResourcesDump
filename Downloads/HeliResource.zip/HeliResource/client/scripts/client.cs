//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Server Admin Commands
//-----------------------------------------------------------------------------

function SAD(%password)
{
   if (%password !$= "")
      commandToServer('SAD', %password);
}

function SADSetPassword(%password)
{
   commandToServer('SADSetPassword', %password);
}


//----------------------------------------------------------------------------
// Misc server commands
//----------------------------------------------------------------------------

function clientCmdSyncClock(%time)
{
   // Time update from the server, this is only sent at the start of a mission
   // or when a client joins a game in progress.
}

// Heli Resource Code Start //

//----------------------------------------------------------------------------
// Vehicle commands
//----------------------------------------------------------------------------

function clientCmdPopActionMap()
{
   echo("Popping Player action map " );
   movemap.pop();
}

function clientCmdPushActionMap()
{
   echo("Pushing Player action map " );
   movemap.push();
}
//----------------------------------------------------------------------------

function clientCmdPopActionMapHelicopterDriver()
{
   echo("Popping Helicopter Driver action map " );
      heliDriverMap.pop();
      }

function clientCmdPopActionMapHelicopterPassenger()//%vehicleType
{
   echo("Popping Helicopter Passenger action map " );
      heliPassengerMap.pop();
      }

//----------------------------------------------------------------------------

function clientCmdPushActionMapHelicopterDriver()
{
   echo("Pushing Helicopter Driver action map " );
      heliDriverMap.push();
}

function clientCmdPushActionMapHelicopterPassenger()
{
   echo("Pushing Helicopter Passenger action map " );
      heliPassengerMap.push();
}

// Heli Resource Code End //