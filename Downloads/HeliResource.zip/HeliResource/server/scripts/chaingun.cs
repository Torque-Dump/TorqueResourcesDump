//--------------------------------------
// Chaingun
//--------------------------------------
 datablock AudioDescription(ProjectileLooping3d)
{
   volume   = 1.0;
   isLooping= true;

   is3D     = true;
   minDistance= 5.0;
   MaxDistance= 20.0;
   type     = $SimAudioType;
};

datablock AudioProfile(blasterExpSound)
{
   filename    = "~/data/shapes/chaingun/audio/blaster_impact.wav";
   description = AudioClosest3d;
   preload = true;
   effect = ChaingunSwitchEffect;
};
//--------------------------------------------------------------------------
// Sounds
//--------------------------------------
datablock AudioProfile(ChaingunSwitchSound)
{
   filename    = "~/data/shapes/chaingun/audio/chaingun_activate.wav";
   description = AudioClosest3d;
   preload = true;
   effect = ChaingunSwitchEffect;
};

datablock AudioProfile(ChaingunFireSound)
{
   filename    = "~/data/shapes/chaingun/audio/chaingun_fire.wav";
   description = AudioDefaultLooping3d;
   preload = true;
   effect = ChaingunFireEffect;
};

datablock AudioProfile(ChaingunProjectile)
{
   filename    = "~/data/shapes/chaingun/audio/chaingun_projectile.wav";
   description = ProjectileLooping3d;
   preload = true;
};

datablock AudioProfile(ChaingunImpact)
{
   filename    = "~/data/shapes/chaingun/audio/chaingun_impact.WAV";
   description = AudioClosest3d;
   preload = true;
};

datablock AudioProfile(ChaingunSpinDownSound)
{
   filename    = "~/data/shapes/chaingun/audio/chaingun_spindown.wav";
   description = AudioClosest3d;
   preload = true;
   effect = ChaingunSpinDownEffect;
};

datablock AudioProfile(ChaingunSpinUpSound)
{
   filename    = "~/data/shapes/chaingun/audio/chaingun_spinup.wav";
   description = AudioClosest3d;
   preload = true;
   effect = ChaingunSpinUpEffect;
};

datablock AudioProfile(ChaingunDryFireSound)
{
   filename    = "~/data/shapes/chaingun/audio/chaingun_dryfire.wav";
   description = AudioClose3d;
   preload = true;
   effect = ChaingunDryFire;
};

//--------------------------------------------------------------------------
// Splash
//--------------------------------------------------------------------------

datablock ParticleData( ChaingunSplashParticle )
{
   dragCoefficient      = 1;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = -1.4;
   lifetimeMS           = 300;
   lifetimeVarianceMS   = 0;
   textureName          = "~/data/shapes/chaingun/textures/droplet";
   colors[0]     = "0.7 0.8 1.0 1.0";
   colors[1]     = "0.7 0.8 1.0 0.5";
   colors[2]     = "0.7 0.8 1.0 0.0";
   sizes[0]      = 0.05;
   sizes[1]      = 0.2;
   sizes[2]      = 0.2;
   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData( ChaingunSplashEmitter )
{
   ejectionPeriodMS = 4;
   periodVarianceMS = 0;
   ejectionVelocity = 3;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 50;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   orientParticles  = true;
   lifetimeMS       = 100;
   particles = "ChaingunSplashParticle";
};


datablock SplashData(ChaingunSplash)
{
   numSegments = 10;
   ejectionFreq = 10;
   ejectionAngle = 20;
   ringLifetime = 0.4;
   lifetimeMS = 400;
   velocity = 3.0;
   startRadius = 0.0;
   acceleration = -3.0;
   texWrap = 5.0;

   texture = "~/data/shapes/chaingun/textures/water2";

   emitter[0] = ChaingunSplashEmitter;

   colors[0] = "0.7 0.8 1.0 0.0";
   colors[1] = "0.7 0.8 1.0 1.0";
   colors[2] = "0.7 0.8 1.0 0.0";
   colors[3] = "0.7 0.8 1.0 0.0";
   times[0] = 0.0;
   times[1] = 0.4;
   times[2] = 0.8;
   times[3] = 1.0;
};

//--------------------------------------------------------------------------
// Particle Effects
//--------------------------------------
datablock ParticleData(ChaingunFireParticle)
{
   dragCoefficient      = 2.75;
   gravityCoefficient   = 0.1;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 550;
   lifetimeVarianceMS   = 0;
   textureName          = "~/data/shapes/chaingun/textures/particleTest";
   colors[0]     = "0.46 0.36 0.26 1.0";
   colors[1]     = "0.46 0.36 0.26 0.0";
   sizes[0]      = 0.25;
   sizes[1]      = 0.20;
};

datablock ParticleEmitterData(ChaingunFireEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 0;
   ejectionVelocity = 10;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 12;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance  = true;
   particles = "ChaingunFireParticle";
};

//--------------------------------------------------------------------------
// Explosions
//--------------------------------------
datablock ParticleData(ChaingunExplosionParticle1)
{
   dragCoefficient      = 0.65;
   gravityCoefficient   = 0.3;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 150;
   textureName          = "~/data/shapes/chaingun/textures/particleTest";
   colors[0]     = "0.56 0.36 0.26 1.0";
   colors[1]     = "0.56 0.36 0.26 0.0";
   sizes[0]      = 0.0625;
   sizes[1]      = 0.2;
};

datablock ParticleEmitterData(ChaingunExplosionEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 0.75;
   velocityVariance = 0.25;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   particles = "ChaingunExplosionParticle1";
};




datablock ParticleData(ChaingunImpactSmokeParticle)
{
   dragCoefficient      = 0.0;
   gravityCoefficient   = -0.2;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1000;
   lifetimeVarianceMS   = 200;
   useInvAlpha          = true;
   spinRandomMin        = -90.0;
   spinRandomMax        = 90.0;
   textureName          = "~/data/shapes/chaingun/textures/particleTest";
   colors[0]     = "0.7 0.7 0.7 0.0";
   colors[1]     = "0.7 0.7 0.7 0.4";
   colors[2]     = "0.7 0.7 0.7 0.0";
   sizes[0]      = 0.5;
   sizes[1]      = 0.5;
   sizes[2]      = 1.0;
   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(ChaingunImpactSmoke)
{
   ejectionPeriodMS = 8;
   periodVarianceMS = 1;
   ejectionVelocity = 1.0;
   velocityVariance = 0.5;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 35;
   overrideAdvances = false;
   particles = "ChaingunImpactSmokeParticle";
   lifetimeMS       = 50;
};


datablock ParticleData(ChaingunSparks)
{
   dragCoefficient      = 1;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 300;
   lifetimeVarianceMS   = 0;
   textureName          = "~/data/shapes/chaingun/textures/spark00";
   colors[0]     = "0.56 0.36 0.26 1.0";
   colors[1]     = "0.56 0.36 0.26 1.0";
   colors[2]     = "1.0 0.36 0.26 0.0";
   sizes[0]      = 0.6;
   sizes[1]      = 0.2;
   sizes[2]      = 0.05;
   times[0]      = 0.0;
   times[1]      = 0.2;
   times[2]      = 1.0;

};

datablock ParticleEmitterData(ChaingunSparkEmitter)
{
   ejectionPeriodMS = 4;
   periodVarianceMS = 0;
   ejectionVelocity = 4;
   velocityVariance = 2.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 50;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   orientParticles  = true;
   lifetimeMS       = 100;
   particles = "ChaingunSparks";
};


//datablock ExplosionData(ChaingunExplosion)
//{
//   soundProfile   = ChaingunImpact;

//   emitter[0] = ChaingunImpactSmoke;
//   emitter[1] = ChaingunSparkEmitter;

//   faceViewer           = false;
//};

datablock ParticleData(ScoutChaingunExplosionParticle1)
{
   dragCoefficient      = 2;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = -0.0;
   lifetimeMS           = 600;
   lifetimeVarianceMS   = 000;
   textureName          = "~/data/shapes/chaingun/textures/crescent4";
   colors[0] = "0.6 0.6 1.0 1.0";
   colors[1] = "0.6 0.3 1.0 1.0";
   colors[2] = "0.0 0.0 1.0 0.0";
   sizes[0]      = 0.25;
   sizes[1]      = 0.5;
   sizes[2]      = 1.0;
   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(ScoutChaingunExplosionEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 2;
   velocityVariance = 1.5;
   ejectionOffset   = 0.0;
   thetaMin         = 80;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   orientParticles  = true;
   lifetimeMS       = 200;
   particles = "ScoutChaingunExplosionParticle1";
};

datablock ExplosionData(ScoutChaingunExplosion)
{
   soundProfile   = blasterExpSound;
   emitter[0] = ScoutChaingunExplosionEmitter;
};


//--------------------------------------------------------------------------
// Particle effects
//--------------------------------------

datablock DebrisData(ShellDebris)
{
   shapeFile = "~/data/shapes/chaingun/weapon_chaingun_ammocasing.dts";

   lifetime = 3.0;

   minSpinSpeed = 300.0;
   maxSpinSpeed = 400.0;

   elasticity = 0.5;
   friction = 0.2;

   numBounces = 5;

   fade = true;
   staticOnMaxBounce = true;
   snapOnMaxBounce = false;
};             


//--------------------------------------------------------------------------
// Projectile
//--------------------------------------
datablock DecalData(ChaingunDecal1)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "~/data/shapes/chaingun/textures/bullethole1";
};
datablock DecalData(ChaingunDecal2 : ChaingunDecal1)
{
   textureName = "~/data/shapes/chaingun/textures/bullethole2";
};

datablock DecalData(ChaingunDecal3 : ChaingunDecal1)
{
   textureName = "~/data/shapes/chaingun/textures/bullethole3";
};
datablock DecalData(ChaingunDecal4 : ChaingunDecal1)
{
   textureName = "~/data/shapes/chaingun/textures/bullethole4";
};
datablock DecalData(ChaingunDecal5 : ChaingunDecal1)
{
   textureName = "~/data/shapes/chaingun/textures/bullethole5";
};
datablock DecalData(ChaingunDecal6 : ChaingunDecal1)
{
   textureName = "~/data/shapes/chaingun/textures/bullethole6";
};

// Projectile Explosion
datablock ParticleData(M60ExplosionParticle)
{
   dragCoefficient      = 2;
   gravityCoefficient   = 0.2;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 900;
   lifetimeVarianceMS   = 150;
   textureName          = "~/data/shapes/particles/smoke";

   colors[0]     = "0.56 0.36 0.26 1.0";
   colors[1]     = "0.56 0.36 0.26 1.0";
   colors[2]     = "0 0 0 0";

   sizes[0]      = 0.5;
   sizes[1]      = 1.0;
};

datablock ParticleEmitterData(M60ExplosionEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   ejectionVelocity = 1;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   particles = "M60ExplosionParticle";
};

datablock ExplosionData(M60Explosion)
{
   particleEmitter = ChainGunSparkEmitter;//M60ExplosionEmitter;
   particleDensity = 50;
   particleRadius = 0.2;

   emitter = ChaingunImpactSmoke;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;
};
datablock ExplosionData(ChaingunExplosion)
{
   soundProfile   = ChaingunImpact;

   //emitter[0] = ChaingunImpactSmoke;
   emitter[0] = ChaingunSparkEmitter;
   emitter[1] = ChaingunImpactSmoke;
   faceViewer           = false;
};
// Projectile trail emitter
datablock ParticleData(M60SmokeParticle)
{
   textureName          = "~/data/shapes/particles/smoke";

   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.2;  // rises
   inheritedVelFactor   = 0.00;

   lifetimeMS           = 300;   // time in ms
   lifetimeVarianceMS   = 150;   // ...more or less

   useInvAlpha = false;
   spinRandomMin = -30.0;
   spinRandomMax = 30.0;

   colors[0]     = "0.56 0.36 0.26 1.0";
   colors[1]     = "0.56 0.36 0.26 1.0";
   colors[2]     = "0 0 0 0";

   sizes[0]      = 0.1;
   sizes[1]      = 0.15;
   sizes[2]      = 0.3;

   times[0]      = 0.0;
   times[1]      = 0.3;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(M60SmokeEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;

   ejectionVelocity = 0.25;
   velocityVariance = 0.10;

   thetaMin         = 0.0;
   thetaMax         = 90.0;

   particles = M60SmokeParticle;
};

//--------------------------------------------------------------------------
// Projectile
//--------------------------------------
datablock ProjectileData(ChaingunBullet)
{
   projectileShapeName             = "~/data/shapes/chaingun/weapon_chaingun_ammocasing.dts";
   directDamage                    = 100;
   radiusDamage                    = 100;
   damageRadius                    = 0.5;
   areaImpulse         = 1800;
   explosion                       = M60Explosion;//ChaingunExplosion;
   splash                          = ChaingunSplash;
   particleEmitter                 = M60SmokeEmitter; //tracer
   particleWaterEmitter            = ChaingunSplashEmitter;

   sound 	                   = ChaingunProjectile;

   velInheritFactor                = 1.0;
   muzzleVelocity                  = 350;
   lifetimeMS                      = 3000;

   //armingDelay                   = 0;
   //lifetime                      = 5000;
   //fadeDelay                     = 5000;
   //bounceElasticity              = 0;
   //bounceFriction                = 0;
   //isBallistic                   = false;
   //gravityMod                    = 0;

   hasLight                        = true;
   lightRadius                     = 1;
   lightColor                      = "0.5 0.5 0.25";

   hasWaterLight                   = false;
   waterLightColor                 = "0 0.5 0.5";

   decals[0] = ChaingunDecal1;
   decals[1] = ChaingunDecal2;
   decals[2] = ChaingunDecal3;
   decals[3] = ChaingunDecal4;
   decals[4] = ChaingunDecal5;
   decals[5] = ChaingunDecal6;
};

function ChaingunBullet::onCollision(%this,%obj,%col,%fade,%pos,%normal)
{
   // Apply damage to the object all shape base objects
   if (%col.getType() & $TypeMasks::ShapeBaseObjectType)
      %col.damage(%obj,%pos,%this.directDamage,"ChaingunBullet");

   // Radius damage is a support scripts defined in radiusDamage.cs
   // Push the contact point away from the contact surface slightly
   // along the contact normal to derive the explosion center. -dbs
      //radiusDamage
     //(%obj, VectorAdd(%pos, VectorScale(%normal, 0.01)),
      //%this.damageRadius,%this.radiusDamage,"Radius", %this.areaImpulse);
//   if (%col.getClassName() $= "RigidShape"){
//   radiusDamage(%obj, %pos, %this.damageRadius, %this.radiusDamage, "Radius", %this.areaImpulse);}
radiusDamage(%obj, %pos, %this.damageRadius, %this.radiusDamage, "Radius", %this.areaImpulse);
}

//--------------------------------------------------------------------------
// Ammo
//--------------------------------------
datablock ItemData(ChaingunAmmo)
{
   className                       = "Ammo";
   category                        = "Ammo";
   shapeFile                       = "~/data/shapes/chaingun/ammo_chaingun.dts";
   mass                            = 1;
   elasticity                      = 0.2;
   friction                        = 0.6;
   pickupRadius                    = 2;
   pickUpName                      = "some chaingun ammo";

   //computeCRC                    = true;
   maxInventory                    = 1000;
};

//--------------------------------------------------------------------------
// Weapon
//--------------------------------------
datablock ItemData(Chaingun)
{
   className                       = "Weapon";
   category                        = "Weapon";
   shapeFile                       = "~/data/shapes/chaingun/weapon_chaingun.dts";
   image                           = ChaingunImage;
   mass                            = 1;
   elasticity                      = 0.2;
   friction                        = 0.6;
   pickupRadius                    = 2;
   pickUpName                      = "a chaingun";
 
   //computeCRC                    = true;
   emap                            = true;
};

datablock ShapeBaseImageData(ChaingunImage)//LHS OF HELI
{
   className                       = "WeaponImage";
   shapeFile                       = "~/data/shapes/chaingun/weapon_chaingun2.dts";
   mountPoint                      = 3;
   item                            = Chaingun;
   ammo                            = ChaingunAmmo;
   projectile                      = ChaingunBullet;
   projectileType                  = Projectile;
   emap                            = true;
   casing                          = ShellDebris;
   shellExitDir                    = "-1.0 0.3 1.0";//"1.0 0.3 1.0";
   shellExitOffset                 = "0.15 -0.56 -0.1";//"0.15 -0.56 -0.1";
   shellExitVariance               = 15.0;
   shellVelocity                   = 3.0;
   correctMuzzleVector             = true;
   projectileSpread                = 8.0 / 1000.0;
   isShotGun = false;

   lightType                       = "WeaponFireLight" ;
   lightColor                      = "0.25 0.20 0.0 1.0" ;
   lightTime                       = "200" ;
   lightRadius                     = "1.5" ;

   //--------------------------------------
   stateName[0]                    = "Activate";
   stateSequence[0]                = "Activate";
   stateSound[0]                   = ChaingunSwitchSound;
   stateAllowImageChange[0]        = false;
   //
   stateTimeoutValue[0]            = 0.5;
   stateTransitionOnTimeout[0]     = "Ready";
   stateTransitionOnNoAmmo[0]      = "NoAmmo";

   //--------------------------------------
   stateName[1]                    = "Ready";
   stateSpinThread[1]              = Stop;
   //
   stateTransitionOnTriggerDown[1] = "Spinup";
   stateTransitionOnNoAmmo[1]      = "NoAmmo";

   //--------------------------------------
   stateName[2]                    = "NoAmmo";
   stateTransitionOnAmmo[2]        = "Ready";
   stateSpinThread[2]              = Stop;
   stateTransitionOnTriggerDown[2] = "DryFire";

   //--------------------------------------
   stateName[3]                    = "Spinup";
   stateSpinThread[3]              = SpinUp;
   stateSound[3]                   = ChaingunSpinupSound;
   //
   stateTimeoutValue[3]            = 0.5;
   stateWaitForTimeout[3]          = false;
   stateTransitionOnTimeout[3]     = "Fire";
   stateEmitter[3]                 = ChaingunFireEmitter;//If emitter here then it will play once at start of fire
   stateEmitterTime[3]             = 0.12;               //How long emitter lasts
   stateTransitionOnTriggerUp[3]   = "Spindown";

   //--------------------------------------
   stateName[4]                    = "PreFire";//This is a hack to make sure the weapon light continues to loop
   stateTransitionOnTriggerDown[4] = "Fire";   //whilst the mouse button is held down.

   //--------------------------------------
   stateName[5]                    = "Fire";
   stateSequence[5]                = "Fire";
   stateSequenceRandomFlash[5]     = true;
   stateSpinThread[5]              = FullSpeed;
   stateSound[5]                   = ChaingunFireSound;
   //stateRecoil[5]                  = LightRecoil;
   stateAllowImageChange[5]        = false;
   stateScript[5]                  = "onFire";
   stateFire[5]                    = true;
   //
   //stateEmitter[5]               = ChaingunFireEmitter; //If emitter here then it will loop continueously
   //stateEmitterTime[5]           = 0.12;                //How long emitter lasts
   stateEjectShell[5]              = true;
   //
   stateTimeoutValue[5]            = 0.15;
   stateTransitionOnTimeout[5]     = "Fire";//Originally "Fire"; refer hack note above
   stateTransitionOnTriggerUp[5]   = "Spindown";
   stateTransitionOnNoAmmo[5]      = "EmptySpindown";

   //--------------------------------------
   stateName[6]                    = "Spindown";
   stateSound[6]                   = ChaingunSpinDownSound;
   stateSpinThread[6]              = SpinDown;
   //
   stateEmitter[6]                 = ChaingunImpactSmoke; //If emitter here then it will play at end of fire
   stateEmitterTime[6]             = 0.12;                //How long emitter lasts

   stateTimeoutValue[6]            = 1.0;
   stateWaitForTimeout[6]          = true;
   stateTransitionOnTimeout[6]     = "Ready";
   stateTransitionOnTriggerDown[6] = "Spinup";

   //--------------------------------------
   stateName[7]                    = "EmptySpindown";
   stateSound[7]                   = ChaingunSpinDownSound;
   stateSpinThread[7]              = SpinDown;
   //
   stateTimeoutValue[7]            = 0.5;
   stateTransitionOnTimeout[7]     = "NoAmmo";
   
   //--------------------------------------
   stateName[8]                    = "DryFire";
   stateSound[8]                   = ChaingunDryFireSound;
   stateTimeoutValue[8]            = 0.5;
   stateTransitionOnTimeout[8]     = "NoAmmo";
};

datablock ShapeBaseImageData(Chaingun2Image)//RHS OF HELI
{
   className                       = "WeaponImage";
   shapeFile                       = "~/data/shapes/chaingun/weapon_chaingun.dts";
   mountPoint                      = 2;
   item                            = Chaingun;
   ammo                            = ChaingunAmmo;
   projectile                      = ChaingunBullet;
   projectileType                  = Projectile;
   emap                            = true;

   casing                          = ShellDebris;
   shellExitDir                    = "1.0 0.3 1.0";
   shellExitOffset                 = "0.15 -0.56 -0.1";
   shellExitVariance               = 15.0;
   shellVelocity                   = 3.0;
   correctMuzzleVector             = true;
   projectileSpread                = 8.0 / 1000.0;
   isShotGun = false;

   lightType                       = "WeaponFireLight" ;
   lightColor                      = "0.25 0.20 0.0 1.0" ;
   lightTime                       = "200" ;
   lightRadius                     = "1.5" ;

   //--------------------------------------
   stateName[0]                    = "Activate";
   stateSequence[0]                = "Activate";
   stateSound[0]                   = ChaingunSwitchSound;
   stateAllowImageChange[0]        = false;
   //
   stateTimeoutValue[0]            = 0.5;
   stateTransitionOnTimeout[0]     = "Ready";
   stateTransitionOnNoAmmo[0]      = "NoAmmo";

   //--------------------------------------
   stateName[1]                    = "Ready";
   stateSpinThread[1]              = Stop;
   //
   stateTransitionOnTriggerDown[1] = "Spinup";
   stateTransitionOnNoAmmo[1]      = "NoAmmo";

   //--------------------------------------
   stateName[2]                    = "NoAmmo";
   stateTransitionOnAmmo[2]        = "Ready";
   stateSpinThread[2]              = Stop;
   stateTransitionOnTriggerDown[2] = "DryFire";

   //--------------------------------------
   stateName[3]                    = "Spinup";
   stateSpinThread[3]              = SpinUp;
   //stateSound[3]                   = ChaingunSpinupSound;
   //
   stateTimeoutValue[3]            = 0.5;
   stateWaitForTimeout[3]          = false;
   stateTransitionOnTimeout[3]     = "Fire";
   stateEmitter[3]                 = ChaingunFireEmitter;//If emitter here then it will play once at start of fire
   stateEmitterTime[3]             = 0.12;               //How long emitter lasts
   stateTransitionOnTriggerUp[3]   = "Spindown";

   //--------------------------------------
   stateName[4]                    = "PreFire";//This is a hack to make sure the weapon light continues to loop
   stateTransitionOnTriggerDown[4] = "Fire";   //whilst the mouse button is held down.

   //--------------------------------------
   stateName[5]                    = "Fire";
   stateSequence[5]                = "Fire";
   stateSequenceRandomFlash[5]     = true;
   stateSpinThread[5]              = FullSpeed;
   //stateSound[5]                   = ChaingunFireSound;
   //stateRecoil[5]                  = LightRecoil;
   stateAllowImageChange[5]        = false;
   stateScript[5]                  = "onFire";
   stateFire[5]                    = true;
   //
   //stateEmitter[5]               = ChaingunFireEmitter; //If emitter here then it will loop continueously
   //stateEmitterTime[5]           = 0.12;                //How long emitter lasts
   stateEjectShell[5]              = true;
   //
   stateTimeoutValue[5]            = 0.15;
   stateTransitionOnTimeout[5]     = "PreFire";//Originally "Fire"; refer hack note above
   stateTransitionOnTriggerUp[5]   = "Spindown";
   stateTransitionOnNoAmmo[5]      = "EmptySpindown";

   //--------------------------------------
   stateName[6]                    = "Spindown";
   //stateSound[6]                   = ChaingunSpinDownSound;
   stateSpinThread[6]              = SpinDown;
   //
   stateEmitter[6]                 = ChaingunImpactSmoke; //If emitter here then it will play at end of fire
   stateEmitterTime[6]             = 0.12;                //How long emitter lasts

   stateTimeoutValue[6]            = 1.0;
   stateWaitForTimeout[6]          = true;
   stateTransitionOnTimeout[6]     = "Ready";
   stateTransitionOnTriggerDown[6] = "Spinup";

   //--------------------------------------
   stateName[7]                    = "EmptySpindown";
   //stateSound[7]                   = ChaingunSpinDownSound;
   stateSpinThread[7]              = SpinDown;
   //
   stateTimeoutValue[7]            = 0.5;
   stateTransitionOnTimeout[7]     = "NoAmmo";
   
   //--------------------------------------
   stateName[8]                    = "DryFire";
   //stateSound[8]                   = ChaingunDryFireSound;
   stateTimeoutValue[8]            = 0.5;
   stateTransitionOnTimeout[8]     = "NoAmmo";
};

//datablock ShapeBaseImageData(Chaingun2Image : ChaingunImage)
//{
//   mountPoint = 1;
//};
function ChaingunImage::onFire(%data,%obj,%slot)
{
   Parent::onFire(%data,%obj,%slot);
   %obj.nextWeaponFire = 2;
   schedule(%data.fireTimeout, 0, "fireNextGun", %obj);   
}

function Chaingun2Image::onFire(%data,%obj,%slot)
{
   Parent::onFire(%data,%obj,%slot);
   %obj.nextWeaponFire = 0;
   schedule(%data.fireTimeout, 0, "fireNextGun", %obj);
}

function ChaingunImage::onTriggerDown(%this, %obj, %slot)
{
}

function ChaingunImage::onTriggerUp(%this, %obj, %slot)
{
}

function fireNextGun(%obj)
{
   if(%obj.fireWeapon)
   {
      if(%obj.nextWeaponFire == 0)
      {
         %obj.setImageTrigger(0, true);
         %obj.setImageTrigger(2, true);//false
      }
         else
         {
            %obj.setImageTrigger(0, true);//false
            %obj.setImageTrigger(2, true);
         }
   }
            else
            {
               %obj.setImageTrigger(0, false);
               %obj.setImageTrigger(2, false);
            }
}

function ShapeBaseImageData::onFire(%this, %obj, %slot)
{
   %projectile = %this.projectile;

   // Decrement inventory ammo. The image's ammo state is update
   // automatically by the ammo inventory hooks.
   %obj.decInventory(%this.ammo,1);

   // Get the weapons projectile spread and ensure it is never 0
   // (we need some spread direction even if it is extremely tiny)
   %spread = %this.projectileSpread;
   %spread = %spread $= "" ? 0.001 : %spread;
   %spread = %spread <= 0 ? 0.001 : %spread;

   // Determine if we are using a shotgun class weapon or not
   // If we are using a shotgun, set the number of projectiles we are going to fire to 12
   %shellcount = 1;
   if(%this.isShotGun) //if(%projectile.isShotGun)
   %shellcount = 12;

   // Create each projectile and send it on its way 
   for(%shell=0; %shell<%shellcount; %shell++)

   // Get the muzzle vector. This is the dead straight aiming point of the gun
   %vector = %obj.getMuzzleVector(%slot);

   // Get our players velocity. We must ensure that the players velocity is added 
   // onto the projectile
   %objectVelocity = %obj.getVelocity();

   // Determine scaled projectile vector. This is still in a straight line as
   // per the default example
   %vector1 = VectorScale(%vector, %projectile.muzzleVelocity);
   %vector2 = VectorScale(%objectVelocity, %projectile.velInheritFactor);
   %velocity = VectorAdd(%vector1,%vector2);

   // Determine our random x, y and z points in our spread circle and create
   // a spread matrix.
   %x = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
   %y = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
   %z = (getRandom() - 0.5) * 2 * 3.1415926 * %spread;
   %mat = MatrixCreateFromEuler(%x @ " " @ %y @ " " @ %z);

   // Alter our projectile vector with our spread matrix
   %velocity = MatrixMulVector(%mat, %velocity);

   // Create our projectile
   %p = new (%this.projectileType)()
   {
   dataBlock = %projectile;
   initialVelocity = %velocity;
   initialPosition = %obj.getMuzzlePoint(%slot);
   sourceObject = %obj;
   sourceSlot = %slot;
   client = %obj.client;
   };

   MissionCleanup.add(%p);
   return %p;
}
