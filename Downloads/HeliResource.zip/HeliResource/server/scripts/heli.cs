//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
$MaxHelicopters  = 3;
$HelicopterCount = 0;
//-----------------------------------------------------------------------------
datablock AudioDescription(HeliLooping3d)
{
   volume            = 1.0;
   isLooping         = true;
   loopCount         = 5;
   is3D              = true;
   ReferenceDistance = 25.0;
   MaxDistance       = 100.0;
   type              = $SimAudioType;
};

datablock AudioProfile(heliEngineSound)
{
   filename    = "~/data/shapes/iroquis/heli.ogg";
   description = HeliLooping3d;
   preload     = true;
};

datablock AudioProfile(heliExplosionSound)
{
filename    = "~/data/sound/crossbow_explosion.ogg";
description = AudioDefault3d;
preload     = true;
};

datablock ParticleData(HeliDustParticle)
{
   textureName          = "~/data/shapes/particles/smoke";
   dragCoefficient      = 2.0;
   gravityCoefficient   = -0.1;
   inheritedVelFactor   = 0.1;
   constantAcceleration = 0.0;
   lifetimeMS           = 1000;
   lifetimeVarianceMS   = 0;
   colors[0]            = "0.46 0.46 0.46 1.0";
   colors[1]            = "0.16 0.16 0.16 0.0";
   sizes[0]             = 1.50;
   sizes[1]             = 3.0;
};

datablock ParticleEmitterData(HeliDustEmittera)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 6;
   velocityVariance = 3.0;
   ejectionOffset   = 0.0;
   thetaMin         = 5;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   particles        = "HeliDustParticle";
};
datablock ParticleEmitterData(HeliDustEmitterb)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 6;
   velocityVariance = 3.0;
   ejectionOffset   = 0.0;
   thetaMin         = 5;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   particles        = "HeliDustParticle";
};
datablock ParticleEmitterData(HeliDustEmitterc)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 6;
   velocityVariance = 3.0;
   ejectionOffset   = 0.0;
   thetaMin         = 5;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   particles        = "HeliDustParticle";
};

datablock ParticleData(LightDamageParticle)
{
   textureName          = "~/data/shapes/particles/smoke";
   dragCoefficient      = 2.0;
   gravityCoefficient   = -0.1;
   inheritedVelFactor   = 0.1;
   constantAcceleration = 0.0;
   lifetimeMS           = 1000;
   lifetimeVarianceMS   = 0;
   colors[0]            = "0.46 0.46 0.46 1.0";
   colors[1]            = "0.16 0.16 0.16 0.0";
   sizes[0]             = 1.50;
   sizes[1]             = 3.0;
};

datablock ParticleEmitterData(LightDamageEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 6;
   velocityVariance = 3.0;
   ejectionOffset   = 0.0;
   thetaMin         = 5;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   particles        = "LightDamageParticle";
};

datablock ParticleData(HeavyDamageParticle)
{
   textureName          = "~/data/shapes/particles/smoke";
   dragCoefficient      = 2.0;
   gravityCoefficient   = -0.1;
   inheritedVelFactor   = 0.1;
   constantAcceleration = 0.0;
   lifetimeMS           = 2000;
   lifetimeVarianceMS   = 0.5;
   colors[0]            = "0.25 0.25 0.16 1.0";
   colors[1]            = "0.16 0.16 0.16 0.0";
   sizes[0]             = 2.50;
   sizes[1]             = 5.0;
};

datablock ParticleEmitterData(HeavyDamageEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 10;
   velocityVariance = 3.0;
   ejectionOffset   = 0.4;
   thetaMin         = 5;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   particles        = "HeavyDamageParticle";
};

datablock ParticleData(DefaultHeliExplosionParticle)
{
   dragCoefficient      = 2;
   gravityCoefficient   = 0.5;
   inheritedVelFactor   = 0.9;
   constantAcceleration = 0.0;
   lifetimeMS           = 900;
   lifetimeVarianceMS   = 200;
   textureName          = "~/data/shapes/particles/smoke";
   colors[0]            = "0.86 0.36 0.26 1.0";
   colors[1]            = "0.70 0.36 0.26 0.5";
   colors[2]            = "0.56 0.36 0.26 0.0";
   sizes[0]             = 8.5;
   sizes[1]             = 11.5;
   sizes[2]             = 17.0;
};

datablock ParticleEmitterData(DestroyedEmitter)
{
   ejectionPeriodMS = 50;
   periodVarianceMS = 0;
   ejectionVelocity = 10;
   velocityVariance = 3.0;
   ejectionOffset   = 0.4;
   thetaMin         = 5;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   particles        = "defaultHeliExplosionParticle";
};

datablock DebrisData(defaultHeliDebri)
{
   explodeOnMaxBounce = false;

   elasticity         = 0.15;
   friction           = 0.5;

   lifetime           = 30.0;
   lifetimeVariance   = 0.0;

   minSpinSpeed       = 40;
   maxSpinSpeed       = 600;

   numBounces         = 6;
   bounceVariance     = 2.3;

   staticOnMaxBounce  = true;
   gravModifier       = 1.0;

   useRadiusMass      = true;
   baseRadius         = 1;

   velocity           = 20.0;
   velocityVariance   = 12.0;
};

//-----------------------------------------------------------------------------
// Explosion Debris

// Debris "spark" explosion
datablock ParticleData(heliDebrisSpark)
{
   textureName          = "~/data/shapes/particles/fire";
   dragCoefficient      = 0;
   gravityCoefficient   = 0.0;
   windCoefficient      = 0;
   inheritedVelFactor   = 0.5;
   constantAcceleration = 0.0;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 50;
   spinRandomMin        = -90.0;
   spinRandomMax        =  90.0;
   useInvAlpha          = false;

   colors[0]            = "0.8 0.2 0 1.0";
   colors[1]            = "0.8 0.2 0 1.0";
   colors[2]            = "0 0 0 0.0";

   sizes[0]             = 0.2;
   sizes[1]             = 0.3;
   sizes[2]             = 0.1;

   times[0]             = 0.0;
   times[1]             = 0.5;
   times[2]             = 1.0;
};

datablock ParticleEmitterData(heliDebrisSparkEmitter)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.25;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   orientParticles  = false;
   lifetimeMS       = 300;
   particles        = "heliDebrisSpark";
};

datablock ExplosionData(heliDebrisExplosion)
{
   emitter[0]       = heliDebrisSparkEmitter;

   // Turned off..
   shakeCamera      = false;
   impulseRadius    = 0;
   lightStartRadius = 0;
   lightEndRadius   = 0;
};

// Debris smoke trail
datablock ParticleData(heliDebrisTrail)
{
   textureName          = "~/data/shapes/particles/fire";
   dragCoefficient      = 1;
   gravityCoefficient   = 0;
   inheritedVelFactor   = 0;
   windCoefficient      = 0;
   constantAcceleration = 0;
   lifetimeMS           = 800;
   lifetimeVarianceMS   = 100;
   spinSpeed            = 0;
   spinRandomMin        = -90.0;
   spinRandomMax        =  90.0;
   useInvAlpha          = true;

   colors[0]            = "0.8 0.3 0.0 1.0";
   colors[1]            = "0.1 0.1 0.1 0.7";
   colors[2]            = "0.1 0.1 0.1 0.0";

   sizes[0]             = 0.2;
   sizes[1]             = 0.3;
   sizes[2]             = 0.4;

   times[0]             = 0.1;
   times[1]             = 0.2;
   times[2]             = 1.0;
};

datablock ParticleEmitterData(heliDebrisTrailEmitter)
{
   ejectionPeriodMS = 30;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 170;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   //overrideAdvances = false;
   //orientParticles  = true;
   lifetimeMS       = 5000;
   particles        = "heliDebrisTrail";
};

// Debris object
datablock DebrisData(heliExplosionDebris)
{
   shapeFile          = "~/data/shapes/crossbow/debris.dts";
   emitters           = "heliDebrisTrailEmitter";
   explosion          = heliDebrisExplosion;
   
   elasticity         = 0.6;
   friction           = 0.5;
   numBounces         = 1;
   bounceVariance     = 1;
   explodeOnMaxBounce = true;
   staticOnMaxBounce  = false;
   snapOnMaxBounce    = false;
   minSpinSpeed       = 0;
   maxSpinSpeed       = 700;
   render2D           = false;
   lifetime           = 4;
   lifetimeVariance   = 0.4;
   velocity           = 10;
   velocityVariance   = 0.5;
   fade               = false;
   useRadiusMass      = true;
   baseRadius         = 0.3;
   gravModifier       = 0.9;
   terminalVelocity   = 6;
   ignoreWater        = true;
};

datablock ParticleData(heliExplosionSmoke)
{
   textureName          = "~/data/shapes/particles/smoke";
   dragCoeffiecient     = 100.0;
   gravityCoefficient   = 0;
   inheritedVelFactor   = 0.25;
   constantAcceleration = -0.30;
   lifetimeMS           = 1200;
   lifetimeVarianceMS   = 300;
   useInvAlpha          =  true;
   spinRandomMin        = -80.0;
   spinRandomMax        =  80.0;

   colors[0]            = "0.56 0.36 0.26 1.0";
   colors[1]            = "0.2 0.2 0.2 1.0";
   colors[2]            = "0.0 0.0 0.0 0.0";

   sizes[0]             = 4.0;
   sizes[1]             = 5;
   sizes[2]             = 6;

   times[0]             = 0.0;
   times[1]             = 0.5;
   times[2]             = 1.0;
};

datablock ParticleEmitterData(heliExplosionSmokeEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 4;
   velocityVariance = 0.5;
   thetaMin         = 0.0;
   thetaMax         = 180.0;
   lifetimeMS       = 250;
   particles        = "heliExplosionSmoke";
};

datablock ParticleData(heliExplosionFire)
{
   textureName          = "~/data/shapes/particles/fire";
   dragCoeffiecient     = 100.0;
   gravityCoefficient   = 0;
   inheritedVelFactor   = 0.25;
   constantAcceleration = 0.1;
   lifetimeMS           = 1200;
   lifetimeVarianceMS   = 300;
   useInvAlpha          =  false;
   spinRandomMin        = -80.0;
   spinRandomMax        =  80.0;

   colors[0]            = "0.8 0.4 0 0.8";
   colors[1]            = "0.2 0.0 0 0.8";
   colors[2]            = "0.0 0.0 0.0 0.0";

   sizes[0]             = 1.5;
   sizes[1]             = 3;
   sizes[2]             = 5;

   times[0]             = 0.0;
   times[1]             = 0.5;
   times[2]             = 1.0;
};

datablock ParticleEmitterData(heliExplosionFireEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;
   ejectionVelocity = 0.8;
   velocityVariance = 0.5;
   thetaMin         = 0.0;
   thetaMax         = 180.0;
   lifetimeMS       = 250;
   particles        = "heliExplosionFire";
};

datablock ParticleData(heliExplosionSparks)
{
   textureName          = "~/data/shapes/particles/spark";
   dragCoefficient      = 1;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 350;

   colors[0]            = "0.60 0.40 0.30 1.0";
   colors[1]            = "0.60 0.40 0.30 1.0";
   colors[2]            = "1.0 0.40 0.30 0.0";

   sizes[0]             = 0.25;
   sizes[1]             = 0.15;
   sizes[2]             = 0.15;

   times[0]             = 0.0;
   times[1]             = 0.5;
   times[2]             = 1.0;
};

datablock ParticleEmitterData(heliExplosionSparkEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 1;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   orientParticles  = true;
   lifetimeMS       = 100;
   particles        = "heliExplosionSparks";
};

datablock ExplosionData(heliSubExplosion1)
{
   offset     = 0;
   emitter[0] = heliExplosionSmokeEmitter;
   emitter[1] = heliExplosionSparkEmitter;
};

datablock ExplosionData(heliSubExplosion2)
{
   offset     = 1.0;
   emitter[0] = heliExplosionSmokeEmitter;
   emitter[1] = heliExplosionSparkEmitter;
};

datablock ExplosionData(heliExplosion)
{
   soundProfile           = heliExplosionSound;
   lifeTimeMS             = 1200;

   // Volume particles
   particleEmitter        = heliExplosionFireEmitter;
   particleDensity        = 300;
   particleRadius         = 8;

   // Point emission
   emitter[0]             = heliExplosionSmokeEmitter;
   emitter[1]             = heliExplosionSparkEmitter;

   // Sub explosion objects
   subExplosion[0]        = heliSubExplosion1;
   subExplosion[1]        = heliSubExplosion2;
   
   // Camera Shaking
   shakeCamera            = true;
   camShakeFreq           = "10.0 11.0 10.0";
   camShakeAmp            = "1.0 1.0 1.0";
   camShakeDuration       = 0.5;
   camShakeRadius         = 10.0;

   // Exploding debris
   debris = heliExplosionDebris;
   debrisThetaMin         = 0;
   debrisThetaMax         = 60;
   debrisPhiMin           = 0;
   debrisPhiMax           = 360;
   debrisNum              = 7;
   debrisNumVariance      = 5;
   debrisVelocity         = 0.8;
   debrisVelocityVariance = 0.4;
   
   // Impulse
   impulseRadius          = 20;
   impulseForce           = 40;

   // Dynamic light
   lightStartRadius       = 6;
   lightEndRadius         = 3;
   lightStartColor        = "0.5 0.5 0";
   lightEndColor          = "0 0 0";
};

//-----------------------------------------------------------------------------
datablock HeliVehicleData(DefaultHeli)
{
   vehicleType = "helicopter";
   category    = "Vehicles";
   shapeFile   = "~/data/shapes/iroquis/iroquis.dts";
   emap        = true;

   mountable     = true;
   maxMountSpeed = 40.0;
   mountDelay    = 0;
   dismountDelay = 10.5;

   stationaryThreshold = 0.5;
   maxDismountSpeed    = 10.0;
   numMountPoints      = 5;

   mountPose[0]             = "Sitting";
   mountPointTransform[0]   = "0 0 0 0 0 1 0";
   isProtectedMountPoint[0] = false;
   
   mountPose[1]             = "Sitting";
   mountPointTransform[1]   = "0 0 0 0 0 1 0";
   isProtectedMountPoint[1] = false;
   
   maxDamage      = 500.0;
   destroyedLevel = 450.0;

   // 3rd person camera settings
   cameraRoll = false;           // Roll the camera with the vehicle
   cameraMaxDist = 23;           // Far distance from vehicle
   cameraOffset = 9;             // Vertical offset from camera mount point
   cameraLag = 0.9;              // Velocity lag of camera
   cameraDecay = 0.75;           // Decay per sec. rate of velocity lag

   isShielded = true;

   maxEnergy = 250;              //Afterburner and any energy weapon pool
   rechargeRate = 0;

   minDrag = 500;                //Linear Drag (eventually slows you down when not thrusting...constant drag)
   rotationalDrag = 20;          //Anguler Drag (dampens the drift after you stop moving the mouse...also tumble drag)

   maxAutoSpeed = 15;            //Autostabilizer kicks in when less than this speed. (meters/second)
   autoAngularForce = 20;        //Angular stabilizer force (this force levels you out when autostabilizer kicks in) up & down force
   autoLinearForce = 20;         //Linear stabilzer force (this slows you down when autostabilizer kicks in)
   autoInputDamping = 0.95;      //Dampen control input so you don't` whack out at very slow speeds
   
   // Maneuvering
   maxSteeringAngle = 3.5;       //Max radiens you can rotate the wheel. Smaller number is more maneuverable.//5
   horizontalSurfaceForce =100;  //Horizontal center "wing" (provides "bite" into the wind for climbing/diving & turning)
   verticalSurfaceForce = 100;   //Vertical center "wing" (controls side slip. lower numbers make MORE slide.)
   maneuveringForce = 500;       //Horizontal jets (W,S,D,A key thrust)
   steeringForce = 2700;         //Steering jets (force applied when you move the mouse)
   steeringRollForce = 0.0;      //Steering jets (how much you heel over when you turn)
   rollForce = 800;              //Auto-roll (self-correction to right you after you roll/invert)
   flyingHeight = 4;             //Height off the ground at rest
   createflyingHeight = 5;       // Height off the ground when created

   // Turbo Jet
   jetForce = 8500;              //Afterburner thrust (this is in addition to normal thrust)
   minJetEnergy = 0.0;           //Afterburner can't be used if below this threshhold.
   jetEnergyDrain = 0.0;         //Energy use of the afterburners (low number is less drain...can be fractional)
   vertThrustMultiple = 50;      //Higher number means going up and down faster

   // Rigid body
   mass = 200;                   //Mass of the vehicle
   bodyFriction = 0;             //Don't mess with this.
   bodyRestitution = 0.5;        //When you hit the ground, how much you rebound. (between 0 and 1)
   minRollSpeed = 500;           //Don't mess with this.
   softImpactSpeed = 0;          //Sound hooks. This is the soft hit.
   hardImpactSpeed = 10;         //Sound hooks. This is the hard hit.

   // Ground Impact Damage (uses DamageType::Ground)
   minImpactSpeed = 0.5;         //If hit ground at speed above this then it's an impact. Meters/second
   speedDamageScale = 0.06;

   // Object Impact Damage (uses DamageType::Impact)
   collDamageThresholdVel = 20.0;
   collDamageMultiplier   = 0.02;
   collisionTol = 5.0;           // Collision distance tolerance
   contactTol = 5.0;             // Contact velocity tolerance
   // Sounds
   engineSound             = HeliEngineSound;

   damageEmitter[0]        = LightDamageEmitter;
   damageEmitter[1]        = HeavyDamageEmitter;
   damageEmitter[2]        = DestroyedEmitter;
   damageEmitterOffset[0]  = "0.0 -3.0 0.0 ";
   damageLevelTolerance[0] = 0.3;
   damageLevelTolerance[1] = 0.7;
   numDmgEmitterAreas      = 1;
   dustEmitter[0]          = HeliDustEmittera;
   dustEmitter[1]          = HeliDustEmitterb;
   dustEmitter[2]          = HeliDustEmitterc;
   dustEmitterOffset[0]    = "50.0 -3.0 0.0 ";
   dustEmitterOffset[1]    = "1.0 70.0 0.0 ";
   dustEmitterOffset[2]    = "0.0 0.0 100.0 ";
   //triggerDustHeight = true;
   //dustHeight = 0;

   // Explosion
   explosion       = heliExplosion;
   debrisShapeName = "~/data/shapes/crossbow/debris.dts";
   debris          = defaultHeliDebri;

   maxInv[Chaingun]           = 1;
   maxInv[Chaingun2]          = 1;
   maxInv[ChaingunAmmo]       = 10000;
   maxInv[Chaingun2Ammo]      = 10000;
   maxInv[RocketLauncher]     = 1;
   maxInv[RocketLauncherAmmo] = 1000;
};


//-----------------------------------------------------------------------------
function HeliVehicleData::create(%block)
{
   %obj = new heliVehicle(){
      dataBlock = %block;
   };

   return(%obj);
}

function HeliVehicleData::onAdd(%this,%obj)
{
   $HelicopterCount ++;

   %obj.mountable = true;
   %obj.playThread(0,"iflanim");

   %obj.setInventory(Chaingun, 1);
   %obj.setInventory(ChaingunAmmo, 10000);
   %obj.mountImage(ChaingunImage, 0);
   %obj.mountImage(Chaingun2Image, 2);

   %obj.setInventory(RocketLauncher, 1);
   %obj.setInventory(RocketLauncherAmmo, 1000);
   %obj.mountImage(RocketLauncherImage, 1);

   %obj.setEnergyLevel(%this.MaxEnergy);
   %obj.setRechargeRate(%this.rechargeRate);
}

function HeliVehicleData::onCollision(%this,%obj,%col,%vec,%speed)
{
   if (%col.getClassName() $= "Item")
   return;
}

function heliVehicleData::onDamage(%this,%obj)
{
   %damageAmt = %obj.getDamageLevel();

   if (%damageAmt >= %this.destroyedLevel)
   {
      %obj.setDamageState(Destroyed);
   }
}

function heliVehicleData::damage(%data, %myObj, %sourceObj, %position, %amount, %damageType, %momentum)
{
  %myObj.applyDamage(%amount);
}

function HeliVehicleData::onDestroyed(%data, %obj, %prevState)
{
  $HelicopterCount --;

  %obj.schedule(500, "delete");
}

//-----------------------------------------------------------------------------
// Weapon Setup
//-----------------------------------------------------------------------------
function DefaultHeli::onTrigger(%data, %obj, %trigger, %state)
{
   // data = datablock
   // obj = object number
   // trigger = 0 for "fire", 1 for "jump", 3 for "thrust"
   // state = 1 for firing, 0 for not firing
   if(%trigger == 0)
   {
      switch (%state) {
         case 0:
            %obj.fireWeapon = false;
            %obj.setImageTrigger(0, false);//false
            %obj.setImageTrigger(2, false);//false
         case 1:
            %obj.fireWeapon = true;
            if(%obj.nextWeaponFire == 2) {
               %obj.setImageTrigger(0, true);
               %obj.setImageTrigger(2, false);//false
            }
            else {
               %obj.setImageTrigger(0, false);
               %obj.setImageTrigger(2, true);//true
            }
      }
   }
}
