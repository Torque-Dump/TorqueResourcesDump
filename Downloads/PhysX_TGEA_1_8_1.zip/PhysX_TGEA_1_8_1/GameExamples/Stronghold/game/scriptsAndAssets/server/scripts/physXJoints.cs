// ============================================================
// Project            :  PhysX
// File               :  .\starter.fps\server\scripts\physXJoints.cs
// Copyright          :  
// Author             :  Shannon
// Created on         :  Tuesday, April 10, 2007 10:07 AM
//
// Editor             :  Codeweaver v. 1.2.2595.6430
//
// Description        :  
//                    :  
//                    :  
// ============================================================
datablock PhysXActorData(pxAirCrate) {
  // Mission editor category
  category = "Physics";
	
  pxShape = "box";
  friction = 0.1;
  mass = 20.0;
  elasticity = 0.1;
  shapeFile = "~/data/shapes/boxes/crate/crate.dts";
  materialBlock = pxMaterialBox;
  pxKinematicBody = true;
};
datablock PhysXActorData(pxJointPole) {
  // Mission editor category
  category = "Physics";
	
  pxShape = "trimesh";
  friction = 0.1;
  mass = 20.0;
  elasticity = 0.1;
  //shapeFile = "~/data/shapes/rocks/rock1.dts";
  shapeFile = "~/data/shapes/woodpole/woodPole.dts";
  materialBlock = pxMaterialBox;
  pxKinematicBody = false;
};

datablock PhysXSphericalJointData(pxJointTest) {
  pxBreakable = 0;
  pxMaxForce = 100.0;
  pxMaxTorque = 50.0;
  pxSwingLimit = 0.3;
  pxTwistLowSetting = -0.05;
  pxTwistHighSetting = 0.05;
};

datablock PhysXActorData(pxEndPlank) {
  // Mission editor category
  category = "Physics";
	
  pxShape = "trimesh";
  friction = 0.1;
  mass = 20.0;
  elasticity = 0.1;
  shapeFile = "~/data/shapes/plank/plank.dts";
  materialBlock = pxMaterialBox;
  pxKinematicBody = true;
};
datablock PhysXActorData(pxJointPlank) {
  // Mission editor category
  category = "Physics";
	
  pxShape = "trimesh";
  friction = 0.1;
  mass = 20.0;
  elasticity = 0.1;
  shapeFile = "~/data/shapes/plank/plank.dts";
  materialBlock = pxMaterialBox;
  pxKinematicBody = false;
};
datablock PhysXRevoluteJointData(pxJointPlankTest) {
  pxBreakable = 0;
  pxMaxForce = 200.0;
  pxMaxTorque = 100.0;
  pxLowLimit = -0.3;
  pxHighLimit = 0.3;
  pxJointAxis = "1 0 0"; // this is important for revolute joint
};
