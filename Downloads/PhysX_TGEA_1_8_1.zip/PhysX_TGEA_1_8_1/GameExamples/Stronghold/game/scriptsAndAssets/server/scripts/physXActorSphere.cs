// ============================================================
// Project      :   RedbackStudios
// File         :   .\auslan\server\scripts\pxActorSphere.cs
// Copyright    :   © 2006
// Author       :   
// Editor       :   Codeweaver 1.2.2199.34718
// 
// Description  :   
//              :   
//              :   
// ============================================================
datablock PhysXMaterialData(pxMaterialSphere)
{
	pxRestitution = 0.5;
	pxStaticFriction = 0.5;
	pxDynamicFriction = 0.5;
};

datablock PhysXActorData(pxSphere)
{
   // Mission editor category
   category = "Physics";

   pxShape = "sphere";
   pxRadius = "2";
   friction = 0.5;
   mass = 200.0;
   elasticity = 0.5;
   shapeFile = "~/data/shapes/boulder/boulder.dts";
   materialBlock = pxMaterialSphere;
};

function serverCmdpxsphere(%client)
{
	createpxSphere(%client);
}

function createpxSphere(%client)
{
  %pos = %client.getControlObject().getPosition();
  %actor = new PhysXActor()
  {
		position = %pos;
      rotation = "1 0 0 0";
      dataBlock = pxSphere;
	};
	MissionCleanup.add(%actor);
}