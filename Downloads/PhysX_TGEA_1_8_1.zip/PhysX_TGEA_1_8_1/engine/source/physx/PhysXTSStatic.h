//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// PhysXTSStatic.h
// Create by Shannon Scarvaci
//
// Description:
//   PhysXTSStatic is to create TSStatic collision data into the PhysX Engine.
//
//-----------------------------------------------------------------------------
#ifndef __PHYSX_TSSTATIC_H_
#define __PHYSX_TSSTATIC_H_

#ifndef _SIMBASE_H_
#include "console/simBase.h"
#endif

struct sNxActor;
class NxConvexMesh;
class NxVec3;
class TSStatic;
class PhysXTSStatic : public SimObject
{
private:
	typedef SimObject Parent;
	bool	mServer;

	S32						mNumTSStatic;
	NxConvexMesh *tsstaticMesh;
	NxTriangleMesh *mTriangleMesh;
	Vector<NxConvexShapeDesc*> convexShapeDesc;
	Vector<NxTriangleMeshDesc*> triangleMeshDesc;
	unsigned int	nbVerts;
	unsigned int		nbFaces;
	sNxActor	  *gTSStatic;
	NxVec3*		verts;
	unsigned int*		faces;

public:
	PhysXTSStatic();
	virtual ~PhysXTSStatic();

	// SimObject
	bool onAdd();
	void onRemove();

	void SetupCollision(bool server,TSStatic &);
	void SetupTriangleCollision(bool server,TSStatic &);

	DECLARE_CONOBJECT(PhysXTSStatic);
};

#endif