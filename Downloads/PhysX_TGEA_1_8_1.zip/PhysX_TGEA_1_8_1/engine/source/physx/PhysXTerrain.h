//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// PhysXTerrain.h
// Create by Shannon Scarvaci
//
// Description:
//   PhysXTerrain is to create terrain collision data into the PhysX Engine.
//   At the moment we only use 256x256 collision mesh due to PhysX Engine limit.
//   But in the future it will have chunk of meshes to match TGE's terrain mesh.
//
//-----------------------------------------------------------------------------
#ifndef __PHYSX_TERRAIN_H_
#define __PHYSX_TERRAIN_H_

#include "atlas/runtime/atlasInstanceTOC.h"
#include "atlas/resource/atlasResourceGeomTOC.h"
#include "util/frustrumCuller.h"

#ifndef _SIMBASE_H_
#include "console/simBase.h"
#endif

class NxTriangleMesh;
struct sNxActor;
class NxVec3;
class PhysXTerrData;
class PhysXTerrain : public SimObject
{
private:
	typedef SimObject Parent;
	bool	mServer;

	S32						mNumTerrain;
	NxTriangleMesh *terrainMesh;
	NxHeightField* heightField;
	unsigned int	nbVerts;
	unsigned int		nbFaces;
	sNxActor*	gTerrain; // legacy
	sNxActor*	gaTerrain; // atlas
	NxVec3*		verts;
	unsigned int*		faces;
	Vector <PhysXTerrData*> mTerrDataList;

public:
	PhysXTerrain();
	virtual ~PhysXTerrain();

	// SimObject
	bool onAdd();
	void onRemove();

	void SetupCollision(bool server);

	void SetupWholeTerrain(bool server);
	void SetupTerrainSection(bool server);
	void SetupHeightfield(bool server);
	void SetupAtlasTerrain(bool server);

	int  CountAtlasTriangles(AtlasInstance* terrain);

	DECLARE_CONOBJECT(PhysXTerrain);
};

#endif