//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// PhysXInterior.h
// Create by Shannon Scarvaci
//
// Description:
//   PhysXInterior is to create interior collision data into the PhysX Engine.
//
//-----------------------------------------------------------------------------
#ifndef __PHYSX_INTERIOR_H_
#define __PHYSX_INTERIOR_H_

#ifndef _SIMBASE_H_
#include "console/simBase.h"
#endif

class NxConvexMesh;
struct sNxActor;
class NxVec3;
class InteriorInstance;
class PhysXInterior : public SimObject
{
private:
	typedef SimObject Parent;
	bool	mServer;

	S32						mNumInterior;
	Vector<NxConvexShapeDesc*> convexShapeDesc;
	unsigned int	nbVerts;
	unsigned int		nbFaces;
	sNxActor*	gInterior;
	NxVec3*		verts;
	unsigned int*		faces;

public:
	PhysXInterior();
	virtual ~PhysXInterior();

	// SimObject
	bool onAdd();
	void onRemove();

	sNxActor* SetupCollision(bool server,InteriorInstance &);

	DECLARE_CONOBJECT(PhysXInterior);
};

#endif