//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// PhysXTerrain.cpp
// Create by Shannon Scarvaci
// See PhysXTerrain.h for more details
//-----------------------------------------------------------------------------
#include "physX/PhysX.h"
#include "physX/PhysXTerrain.h"
#include "physX/PhysXTerrData.h"
#include "physX/PhysXWorld.h"
#include "physX/PhysXStream.h"
#include "terrain/terrData.h"
#include "physX/PhysXActor.h"
#include "collision/concretePolyList.h"
#include "atlas/runtime/AtlasInstance2.h"
#include "atlas/runtime/atlasInstanceGeomTOC.h"
#include "atlas/runtime/atlasInstance2.h"
#include "atlas/resource/atlasConfigChunk.h"
#include "atlas/resource/atlasGeomCollision.h"
#include "atlas/runtime/atlasClipMapBatcher.h"
#include "atlas/resource/atlasGeomChunk.h"
#include "atlas/core/atlasBaseTOC.h"

IMPLEMENT_CONOBJECT(PhysXTerrain);

PhysXTerrain::PhysXTerrain()
{
	gTerrain = NULL;
	gaTerrain = NULL;
	terrainMesh = NULL;
	heightField = NULL;
	mNumTerrain = 1;
	nbVerts = 0;
	nbFaces = 0;
	verts = NULL;
	faces = NULL;
	VECTOR_SET_ASSOCIATION(mTerrDataList);
	mServer = false;
}

PhysXTerrain::~PhysXTerrain()
{
}

bool PhysXTerrain::onAdd()
{
	return Parent::onAdd();
}

void PhysXTerrain::onRemove()
{
	Parent::onRemove();
	PhysXWorld *PxWorld = PhysXWorld::getWorld(mServer);
	if (PxWorld && gTerrain)
	{
		PxWorld->RemoveActor(*gTerrain);
	}
}

void PhysXTerrain::SetupCollision(bool server)
{
	mServer = server;
#ifdef _WHOLE_TERRAIN_

	SetupAtlasTerrain(server);

	SetupWholeTerrain(server);

#else
	SetupHeightfield(server);
	//SetupTerrainSection(server); // not working correctly! :(
#endif
}

void PhysXTerrain::SetupWholeTerrain(bool server)
{
	if (gTerrain) return;


	PhysXWorld *PxWorld = PhysXWorld::getWorld(server);
	if (PxWorld) {

		//look for the TerrainBlock called "Terrain" here
		TerrainBlock *terrain = NULL;
		if (server)
		{
			terrain = dynamic_cast<TerrainBlock*>(Sim::findObject("Terrain"));
		}

		else
		{
			SimGroup *serverConnection = dynamic_cast<SimGroup*>(Sim::findObject("ServerConnection"));
			if (serverConnection)
			{
				for(SimGroup::iterator itr = serverConnection->begin(); itr != serverConnection->end(); itr++)
				{
					terrain = dynamic_cast<TerrainBlock*>(*itr);
					if(terrain)
					{
						Con::printf("***PHYSX*** - Found a Legacy Terrain");
						break;
					}
				}
			}
		}

		if(!terrain)
		{
			Con::printf("***PHYSX*** - No Legacy Terrain found");
			return;
		}


		NxF32 height;
		NxF32 cpx, cpy;

		S32 squareSize = terrain->getSquareSize();
		mNumTerrain = 1;
		NxI32 size = TerrainBlock::BlockSize;
		nbVerts = size*size;
		nbFaces = (size-1)*(size-1)*2;
		for (S32 t = 0; t < mNumTerrain; t++) {

			FrameTemp<NxVec3> verts(nbVerts/mNumTerrain);
			FrameTemp<NxU32> faces((nbFaces/mNumTerrain)*3);

			NxU32 subsize = size/mNumTerrain;
			NxU32 x = subsize*t;
			NxU32 xsize = subsize*(t+1);
			NxU32 ysize = subsize*(t+1);

			for(NxU32 y=0;y<size;y++)
			{
				for(x=0;x<xsize;x++)
				{
					cpx = NxF32(x)-(NxF32(size-1)*0.5f);
					cpy = NxF32(y)-(NxF32(size-1)*0.5f);
					terrain->getHeight(Point2F(x*squareSize,y*squareSize),&height);
					verts[x+y*xsize] = NxVec3(cpx,cpy,height/squareSize) * squareSize;
				}
			}

			NxU32 k = 0;

			for(NxU32 j=0;j<xsize-1;j++)
			{
				for(NxU32 i=0;i<ysize-1;i++)
				{
					// Create first triangle
					faces[k++] = i   + j*size;
					faces[k++] = i   + (j+1)*size;
					faces[k++] = i+1 + (j+1)*size;

					// Create second triangle
					faces[k++] = i   + j*size;
					faces[k++] = i+1 + (j+1)*size;
					faces[k++] = i+1 + j*size;
				}
			}

			// Build physical terrain
			NxTriangleMeshDesc terrainDesc;
			terrainDesc.numVertices					= nbVerts/mNumTerrain;
			terrainDesc.numTriangles				= nbFaces/mNumTerrain;
			terrainDesc.pointStrideBytes			= sizeof(NxVec3);
			terrainDesc.triangleStrideBytes			= 3*sizeof(NxU32);
			terrainDesc.points						= verts;
			terrainDesc.triangles					= faces;
			terrainDesc.flags						= NX_MF_FLIPNORMALS;

			terrainDesc.heightFieldVerticalAxis		= NX_Z;
			terrainDesc.heightFieldVerticalExtent	= -1000.0f;

			// cook it
			MemoryWriteBuffer buf;	
			NxInitCooking();
			NxCookingParams params;
			params.targetPlatform = PLATFORM_PC;
			params.skinWidth=0.0f;
			params.hintCollisionSpeed = false;
			NxSetCookingParams(params);
			bool status = NxCookTriangleMesh(terrainDesc, buf);
			NxCloseCooking();
			if(status == false)
				return;


			MemoryReadBuffer readBuffer(buf.data);
			terrainMesh = PxWorld->createTriangleMesh(readBuffer);

			//for the terrain material
			PhysXMaterialData * terrMatBlock = NULL;
			if (server)
				terrMatBlock = dynamic_cast<PhysXMaterialData*>(Sim::findObject("pxTerrainMaterial"));
			else
			{
				// this is the same as the server part since they should exist in both places
				SimDataBlockGroup *matGroup = Sim::getDataBlockGroup();
				bool bFoundTerrMatBlock = false;
				for(SimDataBlockGroup::iterator itr = matGroup->begin(); itr != matGroup->end(); itr++)
				{
					terrMatBlock = dynamic_cast<PhysXMaterialData*>(*itr);
					if(terrMatBlock)
					{
						if (dStrcmp(terrMatBlock->getName(),"pxTerrainMaterial"))
						{
							Con::printf("***PHYSX*** - Adding Client Material - '%s'", terrMatBlock->getName());
							bFoundTerrMatBlock = true;
							break;
						}
					}
				}
				if (!bFoundTerrMatBlock)
					terrMatBlock = NULL;
			}

			if (!terrMatBlock) Con::errorf("!!! PHYSX Error - No Terrain Material Datablock! (pxTerrainMaterial)");



			NxTriangleMeshShapeDesc terrainShapeDesc;
			terrainShapeDesc.meshData = terrainMesh;
			if (terrMatBlock)
				terrainShapeDesc.materialIndex = terrMatBlock->id;


			NxActorDesc ActorDesc;
			ActorDesc.shapes.pushBack(&terrainShapeDesc);
			gTerrain = PxWorld->AddActor(ActorDesc);
			NxVec3 tpos = NxVec3(terrain->getPosition());

			// why is this off like this??
			gTerrain->actor->setGlobalPosition(NxVec3( -squareSize/2, -squareSize/2, 0));

			if (server)
			{
				Con::printf("***PHYSX*** - Added Legacy Terrain on Server");
			}
			else
			{
				Con::printf("***PHYSX*** - Added Legacy Terrain on Client");
			}
		}
	}
}

void PhysXTerrain::SetupTerrainSection(bool server)
{
	PhysXWorld *PxWorld = PhysXWorld::getWorld(server);
	if (PxWorld) {

		//look for the TerrainBlock called "Terrain" here
		TerrainBlock *terrain = NULL;
		if (server)
		{
			terrain = dynamic_cast<TerrainBlock*>(Sim::findObject("Terrain"));
		}
		else
		{
			SimGroup *serverConnection = dynamic_cast<SimGroup*>(Sim::findObject("ServerConnection"));
			if (serverConnection) {
				for(SimGroup::iterator itr = serverConnection->begin(); itr != serverConnection->end(); itr++)
				{
					terrain = dynamic_cast<TerrainBlock*>(*itr);
					if(terrain)
					{
						break;
					}
				}
			}
		}
		if(!terrain)
		{
			Con::errorf("Terrain not found!");
			return;
		}

		S32 squareSize = terrain->getSquareSize();

		NxI32 size = TerrainBlock::BlockSize*squareSize;
		mNumTerrain = pow((F32)squareSize,2);
		nbVerts = size*size;
		nbFaces = (size-1)*(size-1)*2;

		S32 t = 0;

		for (S32 x = 0; x < mNumTerrain/2; x++)
		{
			for (S32 y = 0; y < mNumTerrain/2; y++)
			{
				PhysXTerrData *data = new PhysXTerrData();
				if (data)
				{
					if (data->SetupTerrainChunk(server,terrain,x,y,mNumTerrain,size,squareSize))
					{
						data->registerObject();
						mTerrDataList.push_front(data);
					}
					else
					{
						delete data;
						return;
					}
				}
				t++;
			}
		}
	}
}

void PhysXTerrain::SetupHeightfield(bool server)
{
	if (gTerrain) return;

	PhysXWorld *PxWorld = PhysXWorld::getWorld(server);
	if (PxWorld)
	{
		//look for the TerrainBlock called "Terrain" here
		TerrainBlock *terrain = NULL;
		if (server)
		{
			terrain = dynamic_cast<TerrainBlock*>(Sim::findObject("Terrain"));
		}
		else
		{
			SimGroup *serverConnection = dynamic_cast<SimGroup*>(Sim::findObject("ServerConnection"));
			if (serverConnection)
			{
				for(SimGroup::iterator itr = serverConnection->begin(); itr != serverConnection->end(); itr++)
				{
					terrain = dynamic_cast<TerrainBlock*>(*itr);
					if(terrain)
					{
						break;
					}
				}
			}
		}
		if(!terrain)
		{
			Con::printf("Terrain not found!");
			return;
		}
		else
			Con::printf("Terrain collision updated in PhysX");
		NxF32 height;
		NxF32 cpx, cpy;

		S32 squareSize = terrain->getSquareSize();
		NxI32 size = TerrainBlock::BlockSize;//*(TerrainBlock::BlockShift/shift);
		NxU32 xsize = size;
		NxU32 ysize = size;

		// Build physical heightfield
		NxHeightFieldDesc heightFieldDesc;    
		heightFieldDesc.nbColumns           = xsize;   
		heightFieldDesc.nbRows              = ysize;   
		heightFieldDesc.verticalExtent      = -100;   
		heightFieldDesc.convexEdgeThreshold = 0;    

		//Allocate storage for samples.    
		heightFieldDesc.samples             = new NxU32[xsize*ysize]; 
		heightFieldDesc.sampleStride        = sizeof(NxU32);   
		NxU8* currentByte = (NxU8*)heightFieldDesc.samples;   

		for (NxU32 row = 0; row < ysize; row++)        {  
			for (NxU32 column = 0; column < xsize; column++)            {  
				NxHeightFieldSample* currentSample = (NxHeightFieldSample*)currentByte;   
				cpx = NxF32(column)-(NxF32(size-1)*0.5f);
				cpy = NxF32(row)-(NxF32(size-1)*0.5f);
				terrain->getHeight(Point2F(column*squareSize,row*squareSize),&height);
				currentSample->height         = (height*100.0); //Desired height value. Signed 16 bit integer. 
				currentSample->tessFlag = 0;        
				currentByte += heightFieldDesc.sampleStride;     
			}   
		}   

		heightField = PxWorld->createHightfield(heightFieldDesc);  
		//Data has been copied therefore free the buffer. 
		delete[] heightFieldDesc.samples;

		NxHeightFieldShapeDesc heightFieldShapeDesc;  
		heightFieldShapeDesc.heightField     = heightField; 
		heightFieldShapeDesc.heightScale     = 0.01f;
		heightFieldShapeDesc.rowScale        = squareSize;  
		heightFieldShapeDesc.columnScale     = squareSize;  
		heightFieldShapeDesc.materialIndexHighBits = 0;   

		NxActorDesc ActorDesc;
		ActorDesc.shapes.pushBack(&heightFieldShapeDesc);
		ActorDesc.body = NULL;
		ActorDesc.globalPose.M.rotX(Float_Pi/2.0);
		gTerrain = PxWorld->AddActor(ActorDesc);
	}
}

void PhysXTerrain::SetupAtlasTerrain(bool server)
{
	//  see if there's a world and a atlas terrain (currently just checks for one Atlas Instance)
	//  You can change it to multiple if you want....
	AtlasInstance *terrain = NULL;
	PhysXWorld *PxWorld = PhysXWorld::getWorld(server);
	if (PxWorld) {

		if (server) {
			terrain = dynamic_cast<AtlasInstance*>(Sim::findObject("AtlasTerrain"));
		} else {
			SimGroup *serverConnection = dynamic_cast<SimGroup*>(Sim::findObject("ServerConnection"));
			if (serverConnection) {
				for(SimGroup::iterator itr = serverConnection->begin(); itr != serverConnection->end(); itr++)
				{
					terrain = dynamic_cast<AtlasInstance*>(*itr);
					if(terrain)
					{
						break;
					}
				}
			}
		}

		if(!terrain)
		{
			Con::errorf("!!! PHYSX - Atlas Terrain not found");
			return;
		}
		else
		{
			Con::printf("!!! PHYSX - Atlas Terrain Instance located...");
		}

	} else return; 

	//  for the terrain material
	//  you definately want a terrain material if you want it act like you expect
	PhysXMaterialData * terrMatBlock = dynamic_cast<PhysXMaterialData*>(Sim::findObject("pxTerrainMaterial"));
	if (!terrMatBlock)
	{
		Con::errorf("!!! PHYSX Error - No Terrain Material Datablock! (pxTerrainMaterial)");
		Con::errorf("!!! PHYSX Error - You need to make a physx material block called pxTerrainMaterial.");
		Con::errorf("!!! PHYSX Error - Just copy one of the other materials and change the settings");
		Con::errorf("!!! PHYSX Error - Atlas scan bailed since there's no material!");
		return;
	}

	int chunkCount = 0;
	int vertexTotalCount = 0;
	Box3F box = Box3F(Point3F( -10000000, -10000000, -10000000), Point3F( 10000000, 10000000, 10000000));
	MatrixF wmat = terrain->getWorldTransform();
	Point3F placePos = terrain->getPosition();

	// make our matrices into Quats... for the physx engine
	QuatF q(wmat);
	Point3F wpos;
	wmat.getColumn(3,&wpos);
	NxQuat quat;
	quat. setXYZW(q.x, q.y, q.z, q.w);

	// We need a stack...
	// stamp...
	//U32 waterMark = FrameAllocator::getWaterMark();
	FrameAllocatorMarker fm;
	AtlasInstanceGeomStub **stack = (AtlasInstanceGeomStub**)fm.alloc(sizeof(AtlasInstanceGeomStub*) * (terrain->mGeomTOC->mTreeDepth * 4 + 1));
	U32 stackDepth=0;

	// Push the root stub into the stack.
	stack[stackDepth++] = terrain->mGeomTOC->getStub(0, Point2I(0,0));

	// loop thru the stack
	while(stackDepth)
	{
		// Pop top item from the stack.
		AtlasInstanceGeomStub *s = stack[--stackDepth];

		// Recurse?
		if(s->hasChildren())
		{
			for(S32 i=0; i<4; i++)
				stack[stackDepth++] = s->mChildren[i];
			continue;
		}

		// Got a leaf, let's pass control on to it...
		AtlasResourceGeomStub *rs = terrain->mGeomTOC->getResourceStub(s);
		AssertFatal(rs->mChunk, "AtlasResourceGeomTOC::buildCollisionInfo - chunk not present for collision query!");

		//********************************************************************************************
		// this time it's the real deal
		if(rs->mChunk)
		{
			chunkCount++;

			const U32 triangleCount = rs->mChunk->mIndexCount / 3 ;

			FrameTemp<U8> triangleMarkers(triangleCount);
			dMemset(triangleMarkers, 0, sizeof(U8) * triangleCount);

			FrameTemp<U8> triangleMarkers2(triangleCount);
			dMemset(triangleMarkers2, 0, sizeof(U8) * triangleCount);

			// Figure the range of chunks this covers...
			const U32 colGridSize = BIT(rs->mChunk->mColTreeDepth-1);
			S32 xStart = 0;
			S32 yStart = 0;
			S32 xEnd   = colGridSize;
			S32 yEnd   = colGridSize;

			// clean up any unattached..  
			rs->mChunk->mConvexList.collectGarbage();

			// triangle counting....
			int triCount = 0;
			int totalTriangles = 0;

			//******************************* get triangle data *******************************************
			// now we get the actual triangle points and faces
			for(S32 i=xStart; i<xEnd; i++)
			{
				for(S32 j=yStart; j<yEnd; j++)
				{
					const Point2I pos(i,j);

					// Get the triangle list...
					// (did I have to use another allocation?... I just guessed - MH)
					U16 offset;
					U16 *triOffset = rs->mChunk->mColIndicesBuffer + rs->mChunk->mColIndicesOffsets[pos.x * colGridSize + pos.y];


					// so count 'em all
					while((offset = *triOffset) != 0xFFFF)
					{
						triOffset++;
						totalTriangles++;
						// Did we emit this triangle already?
						if(triangleMarkers[offset/3])
							continue;
						// otherwise...
						triangleMarkers[offset/3] = 1; // Mark we emitted it.
						triCount++;
					}
				}
			}

			nbVerts = (triCount)*3;
			nbFaces = (triCount);

			FrameTemp<NxVec3> verts(nbVerts);
			FrameTemp<NxU32> faces(nbFaces*3);

			int vertexCounter = 0; // 
			NxU32 k = 0;



			//******************************* get triangle data *******************************************
			// now we get the actual triangle points and faces
			for(S32 i=xStart; i<xEnd; i++)
			{
				for(S32 j=yStart; j<yEnd; j++)
				{
					const Point2I pos(i,j);

					// Get the triangle list...
					U16 offsetf;
					U16 *triOffsetf = rs->mChunk->mColIndicesBuffer + rs->mChunk->mColIndicesOffsets[pos.x * colGridSize + pos.y];

					while((offsetf = *triOffsetf) != 0xFFFF)
					{
						// Advance to the next triangle..
						triOffsetf++;

						// Did we emit this triangle already?
						if(triangleMarkers2[offsetf/3])
							continue;
						// otherwise...
						triangleMarkers2[offsetf/3] = 1; // Mark we emitted it.

						// Get the triangle information...
						Point3F a,b,c;

						a = rs->mChunk->mVert[rs->mChunk->mIndex[offsetf+0]].point;
						b = rs->mChunk->mVert[rs->mChunk->mIndex[offsetf+1]].point;
						c = rs->mChunk->mVert[rs->mChunk->mIndex[offsetf+2]].point;

						verts[vertexCounter] = NxVec3(a);
						vertexCounter++;
						verts[vertexCounter] = NxVec3(b);
						vertexCounter++;
						verts[vertexCounter] = NxVec3(c);
						vertexCounter++;
						vertexTotalCount = vertexTotalCount + 3;

						faces[k] = k;		
						faces[k+1] = k+1;	
						faces[k+2] = k+2;
						k=k+3;
					}
				} // for y
			} //for x

			//******************************* physx cook and add *******************************************
			// build the object
			NxTriangleMeshDesc terrainDesc;
			terrainDesc.numVertices					= nbVerts;
			terrainDesc.numTriangles				= nbFaces;
			terrainDesc.pointStrideBytes			= sizeof(NxVec3);
			terrainDesc.triangleStrideBytes			= 3*sizeof(NxU32);
			terrainDesc.points						= verts;
			terrainDesc.triangles					= faces;
			terrainDesc.flags						= NX_MF_FLIPNORMALS;
			terrainDesc.heightFieldVerticalAxis		= NX_Z;
			terrainDesc.heightFieldVerticalExtent	= -1000.0f;

			// cook it
			MemoryWriteBuffer buf;	
			NxInitCooking();
			NxCookingParams params;
			params.targetPlatform = PLATFORM_PC;
			params.skinWidth=0.0f;
			params.hintCollisionSpeed = false;
			NxSetCookingParams(params);
			bool status = NxCookTriangleMesh(terrainDesc, buf);
			NxCloseCooking();
			NxActorDesc actorDesc;

			if (status)
			{
				NxTriangleMesh* thismesh;
				MemoryReadBuffer readBuffer(buf.data);
				thismesh = PxWorld->createTriangleMesh(readBuffer);

				NxTriangleMeshShapeDesc terrainShapeDesc;
				terrainShapeDesc.meshData				= thismesh;
				terrainShapeDesc.materialIndex			= terrMatBlock->id;

				actorDesc.shapes.pushBack(&terrainShapeDesc);
			}
			else
			{
				Con::errorf("failed to cook");
			}


			actorDesc.body = NULL;
			gTerrain = PxWorld->AddActor(actorDesc);

			if (gTerrain->active)
			{
				//Con::errorf("***PHYSX*** - Atlas Chunk added with %i vertices and %i faces", nbFaces*3, nbFaces);
				gTerrain->actor->setGlobalOrientationQuat(quat);
				gTerrain->actor->setGlobalPosition( NxVec3(placePos) );
				gTerrain->actor->userData = (void*) static_cast<SimObject*>( this );
			}
			else
			{
				Con::errorf("***PHYSX*** - FAILED on terrain piece");
			}
		} // end chunk
	} // end while stack
	Con::printf("***PHYSX*** - Atlas Complete: %i vertices, %i faces, %i chunks", vertexTotalCount, vertexTotalCount/3, chunkCount);
}