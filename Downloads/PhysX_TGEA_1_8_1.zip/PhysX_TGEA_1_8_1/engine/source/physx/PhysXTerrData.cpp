//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// PhysXTerrData.cpp
// Create by Shannon Scarvaci
// See PhysXTerrData.h for more details
//-----------------------------------------------------------------------------
#include "physX/PhysX.h"
#include "physX/PhysXTerrData.h"
#include "physX/PhysXTerrain.h"
#include "physX/PhysXWorld.h"
#include "physX/PhysXStream.h"
#include "terrain/terrData.h"

IMPLEMENT_CONOBJECT(PhysXTerrData);

PhysXTerrData::PhysXTerrData()
{
	nbVerts = 0;
	nbFaces = 0;
	verts = NULL;
	faces = NULL;
	gTerrain = NULL;
}

PhysXTerrData::~PhysXTerrData()
{
}

bool PhysXTerrData::SetupTerrainChunk(bool server, TerrainBlock *terrain, int curTerrainX, int curTerrainY, int numTerrain, unsigned int size, float shift)
{
	PhysXWorld *PxWorld = PhysXWorld::getWorld(server);
	if (PxWorld) {
		S32 quadTerrain = numTerrain/2;
		NxF32 height;
		NxF32 cpx, cpy;
		NxVec3 test;
		NxU32 subsize = size/quadTerrain;
		nbVerts = subsize*subsize;
		nbFaces = (subsize-1)*(subsize-1)*2;
		verts = new NxVec3[nbVerts];
		NxU32 xsize = subsize*(curTerrainX+1);
		NxU32 y = subsize*curTerrainY;
		NxU32 ysize = subsize*(curTerrainY+1);
		for(int i_y=0;y<ysize;y++,i_y++)
		{
			NxU32 x = subsize*curTerrainX;
			for(int j_x=0;x<xsize;x++,j_x++)
			{
				cpx = NxF32(x)-(NxF32(size-1)*0.5f);
				cpy = NxF32(y)-(NxF32(size-1)*0.5f);
				terrain->getHeight(Point2F(x,y),&height);
				test = NxVec3(cpx,cpy,height);
				verts[j_x+i_y*subsize] = test;
			}
		}
		faces = new NxU32[((nbFaces)*3)];
		NxU32 k = 0;
		for(NxU32 j=0;j<subsize-1;j++)
		{
			for(NxU32 i=0;i<subsize-1;i++)
			{
				// Create first triangle
				faces[k++] = i   + j*subsize;
				faces[k++] = i   + (j+1)*subsize;
				faces[k++] = i+1 + (j+1)*subsize;

				// Create second triangle
				faces[k++] = i   + j*subsize;
				faces[k++] = i+1 + (j+1)*subsize;
				faces[k++] = i+1 + j*subsize;
			}
		}

		// Build physical terrain
		NxTriangleMeshDesc terrainDesc;
		terrainDesc.numVertices					= nbVerts;
		terrainDesc.numTriangles				= nbFaces;
		terrainDesc.pointStrideBytes			= sizeof(NxVec3);
		terrainDesc.triangleStrideBytes			= 3*sizeof(NxU32);
		terrainDesc.points						= verts;
		terrainDesc.triangles					= faces;
		terrainDesc.flags						= NX_MF_FLIPNORMALS;
		terrainDesc.heightFieldVerticalAxis		= NX_Z;
		terrainDesc.heightFieldVerticalExtent	= -1000.0f;

		// cook it
		MemoryWriteBuffer buf;	
		NxInitCooking();
		NxCookingParams params;
		params.targetPlatform = PLATFORM_PC;
		params.skinWidth=0.0f;
		params.hintCollisionSpeed = false;
		NxSetCookingParams(params);
		bool status = NxCookTriangleMesh(terrainDesc, buf);
		NxCloseCooking();

		if (!status) return false;
		MemoryReadBuffer readBuffer(buf.data);

		NxTriangleMeshShapeDesc terrainShapeDesc;
		terrainShapeDesc.meshData = PxWorld->createTriangleMesh(readBuffer);
		NxActorDesc ActorDesc;
		ActorDesc.shapes.pushBack(&terrainShapeDesc);
		gTerrain = PxWorld->AddActor(ActorDesc);
		return true;
	}
	return false;
}
