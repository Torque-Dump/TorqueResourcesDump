//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// PhysXJoint.h
// Create by Shannon Scarvaci
//
// Description:
//   This is GameBase object and it create during the script or in mission object.
//   This joint between each acotrs.
//
//-----------------------------------------------------------------------------
#ifndef _PHYSX_JOINT_H_
#define _PHYSX_JOINT_H_

#ifndef _SCENEOBJECT_H_
#include "sceneGraph/sceneObject.h"
#endif
#ifndef _NETOBJECT_H_
#include "sim/netObject.h"
#endif

//----------------------------------------------------------------------------
struct PhysXJointData: public SimDataBlock
{
	typedef SimDataBlock Parent;

	enum pxJointOptions
	{
		pxJointSpherical = 0,   
		pxJointRevolute,       
		pxJointPrismatic,          
		pxJointCylindrical,
		pxJointFixed,
		pxJointDistance,
		pxJointPointInPlane,
		pxJointPointOnLine,
		pxJointPulley
	};

	S32	 pxJoint;
	bool pxBreakable;
	F32  pxMaxForce;
	F32  pxMaxTorque;
	Point3F pxJointAxis;

public:
	DECLARE_CONOBJECT(PhysXJointData);
	PhysXJointData();
	~PhysXJointData();
	static void consoleInit();
	static void initPersistFields();
	bool preload(bool server, String &errorStr);
	virtual void packData(BitStream* stream);
	virtual void unpackData(BitStream* stream);
};

//----------------------------------------------------------------------------
struct PhysXSphericalJointData: public PhysXJointData {
	typedef PhysXJointData Parent;

	F32 pxSwingLimit;
	F32 pxTwistLowSetting;
	F32 pxTwistHighSetting;

public:
	DECLARE_CONOBJECT(PhysXSphericalJointData);
	PhysXSphericalJointData();
	~PhysXSphericalJointData();
	static void consoleInit();
	static void initPersistFields();
	bool preload(bool server, String &errorStr);
	void packData(BitStream* stream);
	void unpackData(BitStream* stream);
}; 

//----------------------------------------------------------------------------
struct PhysXRevoluteJointData: public PhysXJointData {
	typedef PhysXJointData Parent;

	F32 pxLowLimit;
	F32 pxHighLimit;

public:
	DECLARE_CONOBJECT(PhysXRevoluteJointData);
	PhysXRevoluteJointData();
	~PhysXRevoluteJointData();
	static void consoleInit();
	static void initPersistFields();
	bool preload(bool server, String &errorStr);
	void packData(BitStream* stream);
	void unpackData(BitStream* stream);
}; 

class PhysXActor;
class NxJoint;
class PhysXJoint : public NetObject
{
	typedef NetObject Parent;

private:
	PhysXJointData*		mDataBlock;
	bool  remoteClient;

protected:
	S32					mActor0ID;
	S32					mActor1ID;
	PhysXActor *mActor0;
	PhysXActor *mActor1;
	StringTableEntry mActor0_Node;
	StringTableEntry mActor1_Node;
	Point3F		  mLocalAnchor0;
	Point3F		  mLocalAnchor1;
	Point3F		  mGlobalAnchor;
	Point3F		  mGlobalAxis;

	bool			  mJointNow;

	// Distance Joint Setting
	F32					mMinDistance;
	F32					mMaxDistance;
	bool				mEnableMinDistance;
	bool				mEnableMaxDistance;
	bool				mEnableSpring;

	NxJoint			*mJoint;
public:
	DECLARE_CONOBJECT(PhysXJoint);

	enum NetMaskBits {
		DataBlockMask =     BIT(0),
		JointMask     = DataBlockMask << 1
	};

	PhysXJoint();
	virtual ~PhysXJoint();

	bool onAdd();
	void onRemove();
	static void initPersistFields();
	static void consoleInit();
	virtual bool  onNewDataBlock(PhysXJointData* dptr);
	bool          setDataBlock(PhysXJointData* dptr);
	PhysXJointData* getDataBlock()  { return mDataBlock; }

	U32  packUpdate(NetConnection *conn, U32 mask, BitStream *stream);
	void unpackUpdate(NetConnection *conn, BitStream *stream);
	void setTransform(const MatrixF& mat);
	void ConnectJoint();
};

#endif