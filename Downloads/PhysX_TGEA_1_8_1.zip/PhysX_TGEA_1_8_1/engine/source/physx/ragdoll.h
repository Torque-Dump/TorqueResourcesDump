// ===============================================================================
//						  AGEIA PHYSX SDK TRAINING PROGRAMS
//					            LESSON 404: RAGDOLLS
//
//						    Written by Bob Schade, 5-1-06
// ===============================================================================

#ifndef LESSON404_H
#define LESSON404_H

#include "CommonCode2.h"

void PrintControls();
int main(int argc, char** argv);

#endif  // LESSON404_H
