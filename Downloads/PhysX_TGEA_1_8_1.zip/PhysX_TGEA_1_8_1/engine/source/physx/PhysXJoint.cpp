//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// PhysXJoint.cpp
// Create by Shannon Scarvaci
// See PhysXJoint.h for more details
//-----------------------------------------------------------------------------
#include "physX/PhysX.h"
#include "physX/PhysXJoint.h"
#include "physX/PhysXWorld.h"
#include "physX/PhysXActor.h"
#include "physX/PhysXTerrain.h"
#include "console/consoleTypes.h"
#include "core/stream/bitStream.h"
#include "sim/netConnection.h"

IMPLEMENT_CO_DATABLOCK_V1(PhysXJointData);

PhysXJointData::PhysXJointData()
{
	pxJoint = pxJointFixed;
	pxBreakable = false;
	pxMaxForce = 2000.0f;
	pxMaxTorque = 100.0f;
}

PhysXJointData::~PhysXJointData()
{

}

void PhysXJointData::consoleInit()
{
	Parent::consoleInit();
}

static EnumTable::Enums pxJointEnums[] =
{
	{ PhysXJointData::pxJointSpherical, "spherical" },
	{ PhysXJointData::pxJointRevolute, "revolute" },
	{ PhysXJointData::pxJointPrismatic, "prismatic" },
	{ PhysXJointData::pxJointCylindrical, "cylindrical" },
	{ PhysXJointData::pxJointFixed, "fixed" },
	{ PhysXJointData::pxJointDistance, "distance" },
	{ PhysXJointData::pxJointPointInPlane, "pointInPlane" },
	{ PhysXJointData::pxJointPointOnLine, "pointOnLine" },
	{ PhysXJointData::pxJointPulley, "pulley" }
};
static EnumTable gPxJointTable(9, &pxJointEnums[0]);

void PhysXJointData::initPersistFields()
{
	Parent::initPersistFields();

	addGroup("PhysXJoint");		
	addField("pxBreakable", TypeBool, Offset(pxBreakable, PhysXJointData));
	addField("pxMaxForce", TypeF32, Offset(pxMaxForce, PhysXJointData));
	addField("pxMaxTorque", TypeF32, Offset(pxMaxTorque, PhysXJointData));
	addField("pxJointAxis", TypePoint3F, Offset(pxJointAxis, PhysXJointData));
	endGroup("PhysXJoint");		
}

bool PhysXJointData::preload(bool server, String &errorStr)
{
	return Parent::preload(server, errorStr);
}

void PhysXJointData::packData(BitStream* stream)
{
	Parent::packData(stream);
	stream->writeSignedInt(pxJoint,4);
	if (pxBreakable) {
		stream->writeFlag(true);
		stream->write(pxMaxForce);
		stream->write(pxMaxTorque);
		stream->writeCompressedPoint(pxJointAxis);
	} else
		stream->writeFlag(false);
}

void PhysXJointData::unpackData(BitStream* stream)
{
	Parent::unpackData(stream);
	pxJoint = stream->readSignedInt(4);
	pxBreakable = stream->readFlag();
	if (pxBreakable) {
		stream->read(&pxMaxForce);
		stream->read(&pxMaxTorque);
		stream->readCompressedPoint(&pxJointAxis);
	}
}

IMPLEMENT_CO_DATABLOCK_V1(PhysXSphericalJointData);

PhysXSphericalJointData::PhysXSphericalJointData()
{
	pxJoint = pxJointSpherical;
	pxSwingLimit = 0.3f;
	pxTwistLowSetting = -0.05f;
	pxTwistHighSetting = 0.05f;
}

PhysXSphericalJointData::~PhysXSphericalJointData()
{

}

void PhysXSphericalJointData::consoleInit()
{
	Parent::consoleInit();
}

void PhysXSphericalJointData::initPersistFields()
{
	Parent::initPersistFields();

	addGroup("PhysXSpherical");		
	addField("pxSwingLimit", TypeF32, Offset(pxSwingLimit, PhysXSphericalJointData));
	addField("pxTwistLowSetting", TypeF32, Offset(pxTwistLowSetting, PhysXSphericalJointData));
	addField("pxTwistHighSetting", TypeF32, Offset(pxTwistHighSetting, PhysXSphericalJointData));
	endGroup("PhysXSpherical");		
}

bool PhysXSphericalJointData::preload(bool server, String &errorStr)
{
	return Parent::preload(server, errorStr);
}

void PhysXSphericalJointData::packData(BitStream* stream)
{
	Parent::packData(stream);
	stream->write(pxSwingLimit);
	stream->write(pxTwistLowSetting);
	stream->write(pxTwistHighSetting);
}

void PhysXSphericalJointData::unpackData(BitStream* stream)
{
	Parent::unpackData(stream);
	stream->read(&pxSwingLimit);
	stream->read(&pxTwistLowSetting);
	stream->read(&pxTwistHighSetting);
}

IMPLEMENT_CO_DATABLOCK_V1(PhysXRevoluteJointData);

PhysXRevoluteJointData::PhysXRevoluteJointData()
{
	pxJoint = pxJointRevolute;
	pxLowLimit = -0.3f;
	pxHighLimit = 0.3f;
}

PhysXRevoluteJointData::~PhysXRevoluteJointData()
{

}

void PhysXRevoluteJointData::consoleInit()
{
	Parent::consoleInit();
}

void PhysXRevoluteJointData::initPersistFields()
{
	Parent::initPersistFields();

	addGroup("PhysXRevolute");		
	addField("pxLowLimit", TypeF32, Offset(pxLowLimit, PhysXRevoluteJointData));
	addField("pxHighLimit", TypeF32, Offset(pxHighLimit, PhysXRevoluteJointData));
	endGroup("PhysXRevolute");		
}

bool PhysXRevoluteJointData::preload(bool server, String &errorStr)
{
	return Parent::preload(server, errorStr);
}

void PhysXRevoluteJointData::packData(BitStream* stream)
{
	Parent::packData(stream);
	stream->write(pxLowLimit);
	stream->write(pxHighLimit);
}

void PhysXRevoluteJointData::unpackData(BitStream* stream)
{
	Parent::unpackData(stream);
	stream->read(&pxLowLimit);
	stream->read(&pxHighLimit);
}

IMPLEMENT_CO_NETOBJECT_V1(PhysXJoint);

PhysXJoint::PhysXJoint()
{
	mNetFlags.set(Ghostable | ScopeAlways);
	mDataBlock = 0;
	mActor0ID = -1;
	mActor1ID = -1;
	mActor0 = NULL;
	mActor1 = NULL;
	mActor0_Node = "";
	mActor1_Node = "";
	mLocalAnchor0 = Point3F(0,0,0);
	mLocalAnchor1 = Point3F(0,0,0);
	mGlobalAnchor = Point3F(0,0,0);
	mGlobalAxis = Point3F(1,0,0);
	mJointNow = false;

	// Distance Joint Setting
	mMaxDistance = 2.0f;
	mMinDistance = 1.0f;
	mEnableMinDistance = true;
	mEnableMaxDistance = true;
	mEnableSpring = false;

	mJoint = NULL;
	remoteClient = false;
}

PhysXJoint::~PhysXJoint()
{
}

bool PhysXJoint::onAdd()
{
	if(!Parent::onAdd() || !mDataBlock)
		return false;

	if (isClientObject()) {
		// Client datablock are initialized by the initial update
	}
	else {
		// Datablock must be initialized on the server
		if (!onNewDataBlock(mDataBlock))
			return false;
	}

	if (!isServerObject()) {
		PhysXWorld *pw = PhysXWorld::getWorld(true); // client side only
		if (!pw)
			remoteClient = true;
	}
	setMaskBits(JointMask);
	return true;
}

void PhysXJoint::onRemove()
{
	Parent::onRemove();
	PhysXWorld *PxWorld = PhysXWorld::getWorld(isServerObject());
	if (PxWorld && mJoint)
	{
		PxWorld->RemoveJoint(*mJoint);
	}
}

IMPLEMENT_CONSOLETYPE(PhysXJointData)
IMPLEMENT_GETDATATYPE(PhysXJointData)
IMPLEMENT_SETDATATYPE(PhysXJointData)

void PhysXJoint::initPersistFields()
{
	Parent::initPersistFields();
	addField("dataBlock", TypePhysXJointDataPtr, Offset(mDataBlock, PhysXJoint));
	addGroup("Actors");	
	addField("Actor0", TypeS32, Offset(mActor0ID, PhysXJoint));
	addField("Actor1", TypeS32, Offset(mActor1ID, PhysXJoint));
	addField("Actor0Node",   TypeCaseString, Offset(mActor0_Node,   PhysXJoint));
	addField("Actor1Node",   TypeCaseString, Offset(mActor1_Node,   PhysXJoint));
	addField("LocalAnchor0", TypePoint3F, Offset(mLocalAnchor0, PhysXJoint));
	addField("LocalAnchor1", TypePoint3F, Offset(mLocalAnchor1, PhysXJoint));
	addField("GlobalAnchor", TypePoint3F, Offset(mGlobalAnchor, PhysXJoint));
	addField("GlobalAxis", TypePoint3F, Offset(mGlobalAxis, PhysXJoint));
	endGroup("Actors");
	addGroup("Joints");
	addField("JointNow", TypeBool, Offset(mJointNow, PhysXJoint));
	// Spherical Joint

	// Distance Joint
	addField("MinDistance", TypeF32, Offset(mMinDistance, PhysXJoint));
	addField("MaxDistance", TypeF32, Offset(mMaxDistance, PhysXJoint));
	addField("EnableMinDistance", TypeBool, Offset(mEnableMinDistance, PhysXJoint));
	addField("EnableMaxDistance", TypeBool, Offset(mEnableMaxDistance, PhysXJoint));
	addField("EnableSpring", TypeBool, Offset(mEnableSpring, PhysXJoint));

	endGroup("Joints");
}

void PhysXJoint::consoleInit()
{
	Parent::consoleInit();
}

bool PhysXJoint::onNewDataBlock(PhysXJointData* dptr)
{
	mDataBlock = dynamic_cast<PhysXJointData*>(dptr);
	if (!mDataBlock)
		return false;

	setMaskBits(DataBlockMask);
	return true;
}

bool PhysXJoint::setDataBlock(PhysXJointData* dptr)
{
	if (isGhost() || isProperlyAdded()) {
		if (mDataBlock != dptr)
			return onNewDataBlock(dptr);
	}
	else
		mDataBlock = dptr;
	return true;
}

U32  PhysXJoint::packUpdate(NetConnection *conn, U32 mask, BitStream *stream)
{
	if (stream->writeFlag((mask & DataBlockMask) && mDataBlock != NULL)) {
		stream->writeRangedU32(mDataBlock->getId(),
			DataBlockObjectIdFirst,
			DataBlockObjectIdLast);
	}
	if (stream->writeFlag(mask & JointMask)) {
		stream->write(mActor0ID);
		stream->write(mActor1ID);
		stream->writeString(mActor0_Node);
		stream->writeString(mActor1_Node);
	}
	return 0;
}

void PhysXJoint::unpackUpdate(NetConnection *conn, BitStream *stream)
{
	if (stream->readFlag()) { // DataBlock
		PhysXJointData* dptr = 0;
		SimObjectId id = stream->readRangedU32(DataBlockObjectIdFirst,
			DataBlockObjectIdLast);

		if (!Sim::findObject(id,dptr) || !setDataBlock(dptr))
			conn->setLastError("Invalid packet PhysXJoint::unpackUpdate()");
	}
	if (stream->readFlag()) { // JointMask
		stream->read(&mActor0ID);
		stream->read(&mActor1ID);
		char buf[256];
		stream->readString(buf);
		mActor0_Node = StringTable->insert(buf);
		stream->readString(buf);
		mActor1_Node = StringTable->insert(buf);
	}
}

void PhysXJoint::setTransform(const MatrixF& mat)
{

}

void PhysXJoint::ConnectJoint()
{
	mActor0 = NULL;
	mActor1 = NULL;
	if (isServerObject()) {
		Con::printf("***PHYSX*** - Getting Joint's Actor (Server)...");
		SimSet *actorGroup = Sim::getGhostAlwaysSet();
		for(SimSet::iterator itr = actorGroup->begin(); itr != actorGroup->end(); itr++)
		{
			PhysXActor * pxAct = dynamic_cast<PhysXActor*>(*itr);
			if(pxAct)
			{
				if (pxAct->mActorID == mActor0ID) {
					mActor0 = pxAct;
					Con::printf("***PHYSX*** - Found Actor0 (Server) - '%s'", pxAct->getName());
				}
				if (pxAct->mActorID == mActor1ID) {
					mActor1 = pxAct;
					Con::printf("***PHYSX*** - Found Actor1 (Server) - '%s'", pxAct->getName());
				}
			}
		}
	} else// if (isClientObject()) 
	{
		NetConnection *conn = NetConnection::getConnectionToServer();
		if (conn) {
			Con::printf("***PHYSX*** - Getting Joint's Actor (Client)...");

			// server connection...
			SimGroup *serverConnection = dynamic_cast<SimGroup*>(Sim::findObject("ServerConnection"));

			Con::printf("***PHYSX*** - Getting PhysXJoints...");
			for(SimGroup::iterator itr = serverConnection->begin(); itr != serverConnection->end(); itr++)
			{
				PhysXActor * pxAct = dynamic_cast<PhysXActor*>(*itr);
				if(pxAct)
				{
					if (pxAct->mActorID == -1) continue;
					if (pxAct->mActorID == mActor0ID) {
						mActor0 = pxAct;
						Con::printf("***PHYSX*** - Found Actor0 (Client) - '%s'", pxAct->getName());
					}
					if (pxAct->mActorID == mActor1ID) {
						mActor1 = pxAct;
						Con::printf("***PHYSX*** - Found Actor1 (Client) - '%s'", pxAct->getName());
					}
				}
			}
		}
	}

	if (remoteClient || isServerObject())
	{
		if (mDataBlock->pxJoint == PhysXJointData::pxJointSpherical) { // Spherical Joint
			PhysXSphericalJointData *mJointData = dynamic_cast<PhysXSphericalJointData*>(mDataBlock);
			NxSphericalJointDesc jointDesc;
			bool bAct0 = false, bAct1 = false;
			if (mActor0) {
				jointDesc.actor[0] = mActor0->mActor->actor;
				Point3F mLocalAnchor0;
				if (mActor0->getNodeLocalPoint(mActor0_Node,mLocalAnchor0)) {
					jointDesc.localAnchor[0] = NxVec3(mLocalAnchor0.x,mLocalAnchor0.y,mLocalAnchor0.z);
					bAct0 = true;
				}
			} else
				jointDesc.actor[0] = 0;
			if (mActor1) {
				jointDesc.actor[1] = mActor1->mActor->actor;
				Point3F mLocalAnchor1;
				if (mActor1->getNodeLocalPoint(mActor1_Node,mLocalAnchor1)) {
					jointDesc.localAnchor[1] = NxVec3(mLocalAnchor1.x,mLocalAnchor1.y,mLocalAnchor1.z);
					bAct1 = true;
				}
			} else
				jointDesc.actor[1] = 0;

			// try use mount to make localanchor than using globalanchor
			if (!bAct0 || !bAct1)
				jointDesc.setGlobalAnchor(NxVec3(mGlobalAnchor.x,mGlobalAnchor.y,mGlobalAnchor.z));

			if (mJointData) {
				jointDesc.flags |= NX_SJF_SWING_LIMIT_ENABLED;
				jointDesc.swingLimit.value = mJointData->pxSwingLimit*NxPi;

				jointDesc.flags |= NX_SJF_TWIST_LIMIT_ENABLED;
				jointDesc.twistLimit.low.value = mJointData->pxTwistLowSetting*NxPi;
				jointDesc.twistLimit.high.value = mJointData->pxTwistHighSetting*NxPi;
			}
			if (mDataBlock->pxBreakable) {
				jointDesc.maxForce = mDataBlock->pxMaxForce;
				jointDesc.maxTorque = mDataBlock->pxMaxTorque;
			}

			PhysXWorld *PxWorld = PhysXWorld::getWorld(isServerObject());
			if (PxWorld)
				mJoint = PxWorld->AddJoint(jointDesc);
			if (!mJoint) 
				return;
		} else if (mDataBlock->pxJoint == PhysXJointData::pxJointRevolute) { // Revolute Joint
			PhysXRevoluteJointData *mJointData = dynamic_cast<PhysXRevoluteJointData*>(mDataBlock);
			NxRevoluteJointDesc jointDesc;
			bool bAct0 = false, bAct1 = false;
			if (mActor0) {
				jointDesc.actor[0] = mActor0->mActor->actor;
				Point3F mLocalAnchor0;
				if (mActor0->getNodeLocalPoint(mActor0_Node,mLocalAnchor0)) {
					jointDesc.localAnchor[0] = NxVec3(mLocalAnchor0.x,mLocalAnchor0.y,mLocalAnchor0.z);
					bAct0 = true;
				}
			} else
				jointDesc.actor[0] = 0;
			if (mActor1) {
				jointDesc.actor[1] = mActor1->mActor->actor;
				Point3F mLocalAnchor1;
				if (mActor1->getNodeLocalPoint(mActor1_Node,mLocalAnchor1)) {
					jointDesc.localAnchor[1] = NxVec3(mLocalAnchor1.x,mLocalAnchor1.y,mLocalAnchor1.z);
					bAct1 = true;
				}
			} else
				jointDesc.actor[1] = 0;

			// try use mount to make localanchor than using globalanchor
			if (!bAct0 || !bAct1) {
				jointDesc.setGlobalAnchor(NxVec3(mGlobalAnchor.x,mGlobalAnchor.y,mGlobalAnchor.z));
				if (mGlobalAnchor == Point3F(0,0,0)) {
					Con::errorf("***PHYSX*** - Joint Failed - No GlobalAnchor or two Nodes...");
				}
			}
			jointDesc.setGlobalAxis(NxVec3(mJointData->pxJointAxis.x,mJointData->pxJointAxis.y,mJointData->pxJointAxis.z));

			if (mJointData) {
				jointDesc.flags |= NX_RJF_LIMIT_ENABLED;
				jointDesc.limit.low.value = mJointData->pxLowLimit*NxPi;
				jointDesc.limit.high.value = mJointData->pxHighLimit*NxPi;
			}
			if (mDataBlock->pxBreakable) {
				jointDesc.maxForce = mDataBlock->pxMaxForce;
				jointDesc.maxTorque = mDataBlock->pxMaxTorque;
			}

			PhysXWorld *PxWorld = PhysXWorld::getWorld(isServerObject());
			if (PxWorld)
				mJoint = PxWorld->AddJoint(jointDesc);
			if (!mJoint) 
				return;
		}
	}
}
