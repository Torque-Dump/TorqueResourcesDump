//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// PhysXTerrData.h
// Create by Shannon Scarvaci
//
// Description:
//   PhysXTerrData is one of the chunk of terrain collision mesh for larger size
//   of TGE's terrain. (currently not working, can you help us?)
//
//-----------------------------------------------------------------------------
#ifndef __PHYSX_TERR_DATA_H_
#define __PHYSX_TERR_DATA_H_

#ifndef _SIMBASE_H_
#include "console/simBase.h"
#endif

class NxTriangleMesh;
struct sNxActor;
class NxVec3;
class TerrainBlock;
class PhysXTerrData : public SimObject
{
private:
	typedef SimObject Parent;
	sNxActor*	gTerrain;
	unsigned int	nbVerts;
	unsigned int		nbFaces;
	NxVec3*		verts;
	unsigned int*		faces;

public:
	PhysXTerrData();
	virtual ~PhysXTerrData();
	bool	SetupTerrainChunk(bool server, TerrainBlock *terrain, int curTerrainX, int curTerrainY, int numTerrain, unsigned int size, float shift);
	DECLARE_CONOBJECT(PhysXTerrData);
};

#endif