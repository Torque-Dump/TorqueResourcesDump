//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// PhysXWorld.cpp
// Create by Shannon Scarvaci
// See PhysXWorld.h for more details
//-----------------------------------------------------------------------------
#include "physX/PhysX.h"
#include "physX/PhysXWorld.h"
#include "physX/PhysXActor.h"
#include "physX/PhysXTerrain.h"
#include "physX/PhysXInterior.h"
#include "physX/PhysXTSStatic.h"
#include "physX/PhysXJoint.h"
#include "core/stream/bitStream.h"
#include "sim/netConnection.h"
#include "console/console.h"
#include "console/consoleTypes.h"
#include "interior/interiorInstance.h"
#include "T3D/tsstatic.h"

static F32 PhysicsStepTime = 1.0f/32.0f;

class MyOutputStream : public NxUserOutputStream
{
	void reportError (NxErrorCode code, const char *message, const char* file, int line)
	{
		//this should be routed to the application
		//specific error handling. If this gets hit
		//then you are in most cases using the SDK
		//wrong and you need to debug your code!
		//however, code may  just be a warning or
		//information.

		if (code < NXE_DB_INFO)
		{
			Platform::AlertOK(file, message);
		}
	}

	NxAssertResponse reportAssertViolation (const char *message, const char *file,int line)
	{
		//this should not get hit by
		// a properly debugged SDK!
		Platform::AlertOK("PhysX Error", message);
		return NX_AR_CONTINUE;
	}

	void print (const char *message)
	{
		Con::errorf(ConsoleLogEntry::General, "PhysX says: %s\n", message);
	}

} myOutputStream;

class MyContactReport : public NxUserContactReport
{
public:
	virtual void  onContactNotify(NxContactPair& pair, NxU32 events)
	{
		if (events == NX_NOTIFY_ON_TOUCH) {
			PhysXActor* pActor = (PhysXActor*)pair.actors[0]->userData;
			if (pActor) pActor->setActorCollided();
			pActor = (PhysXActor*)pair.actors[1]->userData;
			if (pActor) pActor->setActorCollided();
		}
	}

}gMyContactReport;

IMPLEMENT_CO_NETOBJECT_V1(PhysXWorld);

PhysXWorld *PhysXWorld::mPhysXWorldServer = NULL;
PhysXWorld *PhysXWorld::mPhysXWorldClient = NULL;
//------------------------------------------------------------------------------

PhysXWorld::PhysXWorld()
{
	mNetFlags.set(Ghostable | ScopeAlways);
	gPhysicsSDK = NULL;
	gScene = NULL;
	gSceneHW = NULL;
	gDefaultGravity = VectorF(0,0,-20.0);
	mRemoteClient = false;
	pxTerrain = NULL;
	mErrorReport = false;
	VECTOR_SET_ASSOCIATION(mInteriorList);
	VECTOR_SET_ASSOCIATION(mTSStaticList);
	mStartPhysX = false;
	onFirstServerCycle = true;
	onFirstClientCycle = true;
	physxTickCount = 0;
	physxTickCycle = 2;
	mProcessTick = true;
} 

//------------------------------------------------------------------------------

PhysXWorld* PhysXWorld::getWorld(bool bIsServer)
{
	if (bIsServer)
		return mPhysXWorldServer;
	else
		return mPhysXWorldClient;
}

//------------------------------------------------------------------------------

bool PhysXWorld::onAdd()
{

	// my connection
	NetConnection *conn = NetConnection::getLocalClientConnection();

	// check if this is a remote client side
	if (!isServerObject())
		mRemoteClient = (conn == NULL);

	// check if they already exist....
	if(isServerObject() && PhysXWorld::getServerObject())
	{
		Con::errorf(ConsoleLogEntry::General, "PhysXWorld::onAdd - PhysXWorld already instantiated!");
		return(false);
	}

	if(isClientObject() && PhysXWorld::getClientControlObject())
	{
		Con::errorf(ConsoleLogEntry::General, "PhysXWorld::onAdd - PhysXWorld already instantiated in client!");
		return(false);
	}

	Parent::onAdd();

	return(createWorld());
}

bool PhysXWorld::createWorld()
{
	// assign the client and server worlds
	if (isServerObject())
		mPhysXWorldServer = this;
	else {
		if (mPhysXWorldClient) return true;
		mPhysXWorldClient = this;
	}

	// Create PhysicsSDK here
	if (gPhysicsSDK) return false;

	if (isServerObject() || mRemoteClient) {

		// Create the physics SDK
		if (mErrorReport)
			gPhysicsSDK = NxCreatePhysicsSDK(NX_PHYSICS_SDK_VERSION, 0, &myOutputStream);
		else
			gPhysicsSDK = NxCreatePhysicsSDK(NX_PHYSICS_SDK_VERSION);
		AssertFatal(gPhysicsSDK,"Wrong PhysX DLL version?");

		// Create the scene
		NxSceneDesc sceneDesc;
		NxVec3 gGravity = NxVec3(gDefaultGravity.x,gDefaultGravity.y,gDefaultGravity.z);
		sceneDesc.gravity		= gGravity;

		sceneDesc.userContactReport		= &gMyContactReport;
		sceneDesc.simType = NX_SIMULATION_SW; // this is software support (need it for some object or if PPU not exist)
		gScene = gPhysicsSDK->createScene(sceneDesc);
		gScene->setTiming(PhysicsStepTime / 4.0f, 4, NX_TIMESTEP_FIXED);

		// Set the physics parameters
		gPhysicsSDK->setParameter(NX_SKIN_WIDTH,0.01f);

		Con::printf("");
		Con::printf("***PHYSX*** - Starting Physx System");
		updatePhysX(); // for remote client side

		if (isServerObject())
			setMaskBits(UpdateMask);
	}
	return true;
}

//------------------------------------------------------------------------------

void PhysXWorld::onRemove()
{
	if (pxTerrain)
		pxTerrain->deleteObject();
	for (int i = 0; i < mInteriorList.size(); i++)
		mInteriorList[i]->deleteObject();
	mInteriorList.clear();
	for (int i = 0; i < mTSStaticList.size(); i++)
		mTSStaticList[i]->deleteObject();
	mTSStaticList.clear();

	if (gScene )
	{
		gPhysicsSDK->releaseScene(*gScene);
	}

	if (gPhysicsSDK)
	{
		gPhysicsSDK->release();
	}

	mRemoteClient = false;
	mStartPhysX = false;

	if (isServerObject()) 
		mPhysXWorldServer = NULL;
	else
		mPhysXWorldClient = NULL;

	Parent::onRemove();
}

//------------------------------------------------------------------------------

void PhysXWorld::processTick()
{
		if (isServerObject())
		{
			if (mStartPhysX) 
			{
				if (onFirstServerCycle)
				{
					// only run this way first cycle
					ProcessInput();
					StartPhysics(PhysicsStepTime); 
					onFirstServerCycle = false;

					Con::errorf("***PHYSX*** - Server has run first cycle!");


				}else{
				
					// rest of the time reverse it
					GetPhysicsResults();
					ProcessInput();
					StartPhysics(PhysicsStepTime); // 32ms per tick (TGE's standard)
				}
			}
		
		} 
}

//------------------------------------------------------------------------------

void PhysXWorld::interpolateTick(F32 delta)
{

}

//------------------------------------------------------------------------------

void PhysXWorld::advanceTime(F32 dt)
{

}

//------------------------------------------------------------------------------

void PhysXWorld::initPersistFields()
{
	Parent::initPersistFields();

	addGroup("Physics");	
	addField("errorReport", TypeBool, Offset(mErrorReport, PhysXWorld));
	endGroup("Physics");	
}

//------------------------------------------------------------------------------

U32 PhysXWorld::packUpdate(NetConnection *conn, U32 mask, BitStream * stream)
{
	Parent::packUpdate(conn,mask,stream);
	if(stream->writeFlag(mask & UpdateMask))
	{
		stream->writeFlag(mErrorReport);
	}
	return(0);
}

//------------------------------------------------------------------------------

void PhysXWorld::unpackUpdate(NetConnection *conn, BitStream * stream)
{
	Parent::unpackUpdate(conn,stream);
	// ghost (initial) and regular updates share flag..
	if(stream->readFlag())
	{
		mErrorReport = stream->readFlag();
	}
}

//------------------------------------------------------------------------------

void PhysXWorld::StartPhysics(NxReal deltaTime)
{
	if (gScene) {
		gScene->simulate(deltaTime);
		gScene->flushStream();
	}
}

void PhysXWorld::GetPhysicsResults()
{
	if (!gScene) return;
	// Get results from gScene->simulate(deltaTime)
	while (!gScene->fetchResults(NX_RIGID_BODY_FINISHED, false));
}

void PhysXWorld::ProcessInput()
{ 

}

unsigned short PhysXWorld::createMaterial(NxMaterialDesc &material)
{
	if (gScene)
	{
		return gScene->createMaterial(material)->getMaterialIndex();
	}
	return 0;
}

unsigned short PhysXWorld::setMaterial(NxMaterialDesc &material, unsigned short id)
{
	if (gScene) {
		NxMaterial* mat = gScene->getMaterialFromIndex(id);
		if (mat) {
			mat->setRestitution(material.restitution);
			mat->setStaticFriction(material.staticFriction);
			mat->setDynamicFriction(material.dynamicFriction);
		} else {
			id = gScene->createMaterial(material)->getMaterialIndex();
		}
		return id;
	}
	return 0;
}

sNxActor* PhysXWorld::AddActor(const NxActorDescBase &actorDesc)
{
	if (!gScene) return NULL;
	while(!gScene->isWritable()){}
	sNxActor* actor = new sNxActor();
	actor->actor = gScene->createActor(actorDesc);
	if (!actor->actor)
	{
		actor->active = false;
		return actor;
	}
	actor->actor->userData = this;
	actor->active = true;
	return actor;
}

bool PhysXWorld::RemoveActor(sNxActor  &actor)
{
	if (!gScene) return false;
	if (isServerObject() || mRemoteClient) {
		gScene->releaseActor(*actor.actor);
		actor.active = false;
		return true;
	}
	return false;
}

NxJoint* PhysXWorld::AddJoint(const NxJointDesc &jointDesc)
{
	if (!gScene) return NULL;
	NxJoint* joint = gScene->createJoint(jointDesc);
	if (!joint) return NULL;
	joint->userData = this;
	return joint;
}

bool PhysXWorld::RemoveJoint(NxJoint &joint)
{
	if (!gScene) return false;
	if (isServerObject() || mRemoteClient) {
		gScene->releaseJoint(joint);
		return true;
	}
	return false;
}

bool PhysXWorld::updatePhysX()
{
	Con::printf("***PHYSX*** - Setting up system....");

	if (isServerObject()) {
		Con::printf("***PHYSX*** - Found Server World");
		Con::printf("***PHYSX*** - Getting Server Materials...");
		SimDataBlockGroup *matGroup = Sim::getDataBlockGroup();
		for(SimDataBlockGroup::iterator itr = matGroup->begin(); itr != matGroup->end(); itr++)
		{
			PhysXMaterialData * pxMat = dynamic_cast<PhysXMaterialData*>(*itr);
			if(pxMat)
			{
				pxMat->updatePhysX(isServerObject());
				Con::printf("***PHYSX*** - Adding Server Material - '%s'", pxMat->getName());
			}
		}

		return true;

	}
	else
	{
		Con::printf("***PHYSX*** - Found Client World");
		NetConnection *conn = NetConnection::getConnectionToServer();
		if (conn) {
			Con::printf("***PHYSX*** - Found Client Connection");
			Con::printf("***PHYSX*** - Getting Client Materials...");

			// this is the same as the server part since they should exist in both places
			SimDataBlockGroup *matGroup = Sim::getDataBlockGroup();
			for(SimDataBlockGroup::iterator itr = matGroup->begin(); itr != matGroup->end(); itr++)
			{
				PhysXMaterialData * pxMat = dynamic_cast<PhysXMaterialData*>(*itr);
				if(pxMat)
				{
					pxMat->updatePhysX(isServerObject());
					Con::printf("***PHYSX*** - Adding Client Material - '%s'", pxMat->getName());
				}
			}

			// now lets get the terrain.  it's already in the server, but the client needs it too
			Con::printf("***PHYSX*** - Adding Client Terrain");
			SetupTerrainCollision();

			// server connection...
			SimGroup *serverConnection = dynamic_cast<SimGroup*>(Sim::findObject("ServerConnection"));

			Con::printf("***PHYSX*** - Getting Client Objects...");
			for(SimGroup::iterator itr = serverConnection->begin(); itr != serverConnection->end(); itr++)
			{

				PhysXActor * pxAct = dynamic_cast<PhysXActor*>(*itr);
				if(pxAct && mRemoteClient)
				{
					pxAct->updatePhysX(false);
					Con::printf("***PHYSX*** - (SCAN) Adding Client Actor - '%s'", pxAct->mDataBlock->getName());
				}

				InteriorInstance * interior = dynamic_cast<InteriorInstance*>(*itr);
				if(interior)
				{
					Con::printf("***PHYSX*** - Adding Client Interior - '%s'", interior->getInteriorFileName());
					SetupInterior(*interior);
				}

				TSStatic * tsstatic = dynamic_cast<TSStatic*>(*itr);
				if(tsstatic)
				{
					Con::printf("***PHYSX*** - Adding Client Static - '%s'", tsstatic->getName());
					
					SetupTSStatic(*tsstatic);
				}
			}
		}
		return true;
	}
}

bool PhysXWorld::updateJoints()
{
	Con::printf("***PHYSX*** - Setting up Joints system....");

	if (isServerObject()) {
		Con::printf("***PHYSX*** - Joints - Found Server World");
		Con::printf("***PHYSX*** - Getting PhysXJoints...");
		SimSet *actorGroup = Sim::getGhostAlwaysSet();
		for(SimSet::iterator itr = actorGroup->begin(); itr != actorGroup->end(); itr++)
		{
			PhysXJoint * pxJ = dynamic_cast<PhysXJoint*>(*itr);
			if(pxJ)
			{
				pxJ->ConnectJoint();
				Con::printf("***PHYSX*** - Connecting Joint (Server) - '%s'", pxJ->getName());
			}
		}
		return true;

	}
	else
	{
		Con::printf("***PHYSX*** - Found Client World");
		NetConnection *conn = NetConnection::getConnectionToServer();
		if (conn) {
			Con::printf("***PHYSX*** - Joints - Found Client Connection");

			// server connection...
			SimGroup *serverConnection = dynamic_cast<SimGroup*>(Sim::findObject("ServerConnection"));

			Con::printf("***PHYSX*** - Getting PhysXJoints...");
			for(SimGroup::iterator itr = serverConnection->begin(); itr != serverConnection->end(); itr++)
			{
				PhysXJoint * pxJ = dynamic_cast<PhysXJoint*>(*itr);
				if(pxJ)
				{
					pxJ->ConnectJoint();
					Con::printf("***PHYSX*** - Connecting Joint (Client) - '%s'", pxJ->getName());
				}
			}
		}

		return true;

	}
}

NxTriangleMesh* PhysXWorld::createTriangleMesh(const NxStream& stream)
{
	if (gPhysicsSDK)
		return gPhysicsSDK->createTriangleMesh(stream);
	return NULL;
}

NxConvexMesh* PhysXWorld::createConvexMesh(const NxStream& stream)
{
	if (gPhysicsSDK)
		return gPhysicsSDK->createConvexMesh(stream);
	return NULL;
}

NxHeightField* PhysXWorld::createHightfield(const NxHeightFieldDesc& hightField)
{
	if (gPhysicsSDK)
		return gPhysicsSDK->createHeightField(hightField);
	return NULL;
}

void PhysXWorld::SetupTerrainCollision()
{
	if (mRemoteClient || isServerObject())
	{
		if (!pxTerrain) {
			pxTerrain = new PhysXTerrain(); 
			pxTerrain->registerObject();
		}
		pxTerrain->SetupCollision(isServerObject());
	}
}

sNxActor* PhysXWorld::AddShapeBase(ShapeBase *shape)
{
#ifdef _DONT_USE_SHAPEBASE_
	return NULL;
#endif

	if (shape) {
		// Add a single-shape actor to the scene
		NxActorDesc actorDesc;
		NxBodyDesc bodyDesc;

		Box3F objBox = shape->getObjBox();

		if (shape->getType() & PlayerObjectType)
		{
			NxCapsuleShapeDesc capsuleDesc;
			capsuleDesc.height = objBox.len_z()*0.5;
			capsuleDesc.radius = objBox.len_x()*0.75;

			if (shape->mDataBlock->mMaterialBlock)
			{
				capsuleDesc.materialIndex = shape->mDataBlock->mMaterialBlock->id;
			}

			actorDesc.shapes.pushBack(&capsuleDesc);
		}
		else
		{
			NxBoxShapeDesc boxDesc;
			F32 boxScale = 0.75;
			boxDesc.dimensions.set( objBox.len_x()*boxScale , objBox.len_y()*boxScale, objBox.len_z()*boxScale );

			if (shape->mDataBlock->mMaterialBlock){

				boxDesc.materialIndex = shape->mDataBlock->mMaterialBlock->id;

			}
			else
			{
				Con::errorf("PHYSX Error! - found a Physx (ShapeBase) object with missing 'material' in datablock!");
			}

			actorDesc.shapes.pushBack(&boxDesc);
		}

		if (shape->mDataBlock->mass)
		{
			bodyDesc.mass = shape->mDataBlock->mass; 
		}
		else
		{
			Con::errorf("PHYSX Error! - found a Physx (ShapeBase) object with missing 'mass' in datablock!");
			bodyDesc.mass = 1;		
		};

		actorDesc.body = &bodyDesc;

		Point3F pos;
		pos = shape->getPosition();		
		actorDesc.globalPose.t = NxVec3(pos.x,pos.y,pos.z);

		return AddActor(actorDesc);;
	}
	return NULL;
}

sNxActor* PhysXWorld::SetupInterior(InteriorInstance &interior)
{
	if (mRemoteClient || isServerObject())
	{
		PhysXInterior *pxInterior = new PhysXInterior();
		pxInterior->registerObject();
		mInteriorList.push_front(pxInterior);
		return pxInterior->SetupCollision(isServerObject(),interior);
	}
	return NULL;
}


void PhysXWorld::SetupTSStatic(TSStatic &tsstatic)
{
	if (mRemoteClient || isServerObject())
	{
		PhysXTSStatic *pxTSStatic = new PhysXTSStatic();
		pxTSStatic->registerObject();
		mTSStaticList.push_front(pxTSStatic);
		if(tsstatic.usesPolysoup())
		{
			pxTSStatic->SetupTriangleCollision(isServerObject(),tsstatic);
		}
		else
		{
			pxTSStatic->SetupCollision(isServerObject(),tsstatic);
		}
	}
}

void PhysXWorld::StartPhysX()
{
	// Connect all the joints before start
	updateJoints();

	mStartPhysX = true;
}

//-----------------------------------------------
ConsoleFunction(startPhysX, void, 1, 1, "()")
{
	if (PhysXWorld::getWorld(false)) {
		PhysXWorld::getWorld(false)->StartPhysX();
		Con::printf("***PHYSX*** - Activated Client world");
	}

	if (PhysXWorld::getWorld(true)) {
		PhysXWorld::getWorld(true)->StartPhysX();
		Con::printf("***PHYSX*** - Activated Server world");
	}
}

void PhysXWorld::debugPhysX()
{
	//Connect to the RemoteDebugger...
	if(isServerObject())
	{
		//Server debugger = port 5425
		Con::printf("***PHYSX*** - Connecting to RemoteDebugger (localhost, 5425)");
		gPhysicsSDK->getFoundationSDK().getRemoteDebugger()->connect ("localhost", 5425);
	}
	else
	{
		//Client debugger = port 5426
		Con::printf("***PHYSX*** - Connecting to RemoteDebugger (localhost, 5426)");
		gPhysicsSDK->getFoundationSDK().getRemoteDebugger()->connect ("localhost", 5426);
	}
}

ConsoleFunction(debugPhysX, void, 1, 1, "()")
{
	if (PhysXWorld::getWorld(false)) {
		PhysXWorld::getWorld(false)->debugPhysX();
	}
	else
	{
		PhysXWorld::getWorld(true)->debugPhysX();
	}
}