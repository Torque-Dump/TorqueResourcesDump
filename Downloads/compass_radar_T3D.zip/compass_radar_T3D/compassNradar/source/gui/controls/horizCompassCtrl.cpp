//-----------------------------------------------------------------------------
// TORQUE 3D
// Copyright (C) GarageGames.com, Inc.
//
// Horizontal compass by Stefan "Beffy" Moises
// The basic code (well, almost everything... ;-) for this compass gui
// was written by Xavier "eXoDuS" Amado.
//
// Ported to T3D by DeepScratch
//-----------------------------------------------------------------------------
#include "console/console.h"
#include "console/consoleTypes.h"
#include "gfx/gfxDevice.h"
#include "T3D/gameFunctions.h"
#include "T3D/gameBase/gameconnection.h"
#include "gfx/gfxDrawUtil.h"
#include "horizCompassCtrl.h"

IMPLEMENT_CONOBJECT(HorizCompassCtrl);

HorizCompassCtrl::HorizCompassCtrl(void)
{
  mOuterBitmapName = StringTable->insert("");
  mTextureHandle = NULL;
  mOuterTextureHandle = NULL;
  mFontWidth = 16.0f;
}

void HorizCompassCtrl::initPersistFields()
{
   Parent::initPersistFields();
   addField("OuterRingBitmap",	TypeFilename, Offset(mOuterBitmapName, HorizCompassCtrl));
   addField("FontWidth",	TypeF32, Offset(mFontWidth, HorizCompassCtrl));
   removeField("wrap");
   removeField("autosize");
   removeField("command");
   removeField("altcommand");
}
void HorizCompassCtrl::setFontWidth(const F32 width)
{
 mFontWidth = width;
}

bool HorizCompassCtrl::onWake()
{
   if (! Parent::onWake()) return false;

   setActive(true);
   setBitmap(mBitmapName);
   setOuterBitmap(mOuterBitmapName);
   setFontWidth(mFontWidth);

   return true;
}

void HorizCompassCtrl::onSleep()
{
   mTextureHandle = NULL;
   mOuterTextureHandle = NULL;
   Parent::onSleep();
}


void HorizCompassCtrl::setBitmap(const char *name, bool resize)
{
   mBitmapName = StringTable->insert(name);

   if (*mBitmapName)
	{
		mTextureHandle.set( mBitmapName, &GFXDefaultGUIProfile, avar("%s() - mTexHandle (line %d)", __FUNCTION__, __LINE__) );

      // Resize the control to fit the bitmap
      if( mTextureObject && resize )
      {
         setExtent(mTextureObject->getWidth(), mTextureObject->getHeight());
         updateSizing();
      }
   }
   else
      mTextureHandle = NULL;

   setUpdate();
}

void HorizCompassCtrl::setBitmap(GFXTexHandle handle, bool resize)
{
   mTextureHandle = handle;

   // Resize the control to fit the bitmap
   if (resize)
   {
      setExtent(mTextureObject->getWidth(), mTextureObject->getHeight());
      updateSizing();
   }
}

void HorizCompassCtrl::setOuterBitmap(const char *name)
{
   mOuterBitmapName = StringTable->insert(name);
   if (*mOuterBitmapName)
         mOuterTextureHandle.set( mOuterBitmapName, &GFXDefaultGUIProfile, avar("%s() - mTexHandle (line %d)", __FUNCTION__, __LINE__) );
   else
      mOuterTextureHandle = NULL;
   setUpdate();
}

void HorizCompassCtrl::setOuterBitmap(const GFXTexHandle &handle)
{
   mOuterTextureHandle = handle;
}


float Vector2dToOffset(Point3F vector)
{
    float offset;
    offset = atanf((1.0F * vector.x) / (-1.0F * vector.y)) * (180.0F / M_PI);
    if ((-1.0F * vector.y) < 0.0F){
		 return offset + 180.0f;
	 }
    else{
		 return offset;
    }
}

void HorizCompassCtrl::onRender(Point2I offset, const RectI &updateRect)
{
   if (mTextureHandle)
   {
		GFX->getDrawUtil()->clearBitmapModulation();

	  GFXTextureObject* texture = mTextureHandle;

	  // okay, so the "letters" graphic is placed 90px (=90 degrees) to the left initially
	  // also, the size of the letters (mFontWidth) is taken into account so that
	  // the letters and the graphic are exactly centered and in the correct position
 	  Point2I BorderOffset(getBounds().extent.x - texture->mBitmapSize.x - (mFontWidth/2) - 90, getBounds().extent.y - texture->mBitmapSize.y);

	  //struct CameraQuery query;
	  //GameProcessCameraQuery(&query);

	  GameConnection* connection = GameConnection::getConnectionToServer();

	  MatrixF cameraMatrix;

	  if(!connection)
		  return;

	  connection->getControlCameraTransform(0.032f, &cameraMatrix);

	  Point3F cameraRot;
	  cameraMatrix.getColumn(1, &cameraRot);
	  cameraRot.neg();
	  cameraRot.z = 0;

	  mOffset = Vector2dToOffset(cameraRot);
	  RectI dstRect(getBounds().point.x + BorderOffset.x/2 + mOffset, getBounds().point.y + BorderOffset.y/2,
					texture->mBitmapSize.x, texture->mBitmapSize.y);

	  GFX->getDrawUtil()->drawBitmapStretch(mTextureHandle, dstRect);
   }

   if(mOuterTextureHandle)
   {
	   GFXTextureObject* texture = mOuterTextureHandle;

	   //mBounds.extent.set(texture->mBitmapSize.x, texture->mBitmapSize.y);
       setExtent(texture->mBitmapSize.x, texture->mBitmapSize.y);

	   //RectI outerRect(offset, mBounds.extent);
	   RectI outerRect(offset, getBounds().extent);
	   GFX->getDrawUtil()->drawBitmapStretch(mOuterTextureHandle, outerRect);
   }

   if (mProfile->mBorder || !mTextureHandle && !mOuterTextureHandle)   
   {
//      RectI rect(offset.x, offset.y, mBounds.extent.x, mBounds.extent.y);
      RectI rect(offset.x, offset.y, getBounds().extent.x, getBounds().extent.y);
     GFX->getDrawUtil()->drawRect(rect, mProfile->mBorderColor);
   }

   renderChildControls(offset, updateRect);
}
