//-----------------------------------------------------------------------------
// TORQUE 3D
// Copyright (C) GarageGames.com, Inc.
// Ported to T3D by DeepScratch
//-----------------------------------------------------------------------------
#ifndef _GUIBITMAPCTRL_H_
#define _GUIBITMAPCTRL_H_

#ifndef _GUICONTROL_H_
#include "gui/core/guiControl.h"
#endif

/// Renders a bitmap.
class GuiRadarCtrl : public GuiControl
{
private:
	typedef GuiControl Parent;
	Point3F mMyCoords;

protected:
	// Radar
	StringTableEntry mRadarBitmapName;
	StringTableEntry mBlipUpName;
	StringTableEntry mBlipLevelName;
	StringTableEntry mBlipBelowName;

	GFXTexHandle mRadarTextureObject;
	GFXTexHandle mRadarDot;
	GFXTexHandle mRadarUp;
	GFXTexHandle mRadarDown;

	bool mShowRadar;

	bool mShowVehicles;
	bool mShowBots;
	bool mShowPlayers;
	bool mShowShapeBase;

	F32 mLevelRange;
	F32 mRadarRadiusRange;

	bool mHideAll;

	//Compass
	StringTableEntry mCompassBitmapName;
	GFXTexHandle mCompassTextureObject;

	bool mShowCompass;

	// 
	// Map
	StringTableEntry mMapBitmapName;
	GFXTexHandle mMapTextureObject;

	bool mShowMap;

	F32 mCompassRotation;
	// 

	Point2I startPoint;
	bool mWrap;

public:
	//creation methods
	DECLARE_CONOBJECT(GuiRadarCtrl);
	GuiRadarCtrl();
	static void initPersistFields();

	//Parental methods
	bool onWake();
	void onSleep();
	void inspectPostApply();

	void setRadarBitmap(const char *name, bool resize = false);
	void setRadarBitmap(GFXTexHandle handle, bool resize = false);

	void setRadarLevelBlipBitmap(const char *name);
	void setRadarUpBlipBitmap(const char *name);
	void setRadarBelowBlipBitmap(const char *name);

	void setCompassBitmap(const char *name, bool resize = false);
	void setCompassBitmap(GFXTexHandle handle, bool resize = false);

	void setMapBitmap(const char *name);

	void setRadius(const F32 newRange);
	void setLevelRange(const F32 newLevelRange);

	S32 getWidth() const       { return(mRadarTextureObject->getWidth()); }
	S32 getHeight() const      { return(mRadarTextureObject->getHeight()); }

	void setCompassRotation(const F32 rotation);

	void updateSizing();

	void onRender(Point2I offset, const RectI &updateRect);
	void setValue(S32 x, S32 y);
};

#endif
