//-----------------------------------------------------------------------------
// TORQUE 3D
// Copyright (C) GarageGames.com, Inc.
//
// Horizontal compass by Stefan "Beffy" Moises
// The basic code (well, almost everything... ;-) for this compass gui
// was written by Xavier "eXoDuS" Amado.
//
// Ported to T3D by DeepScratch
//-----------------------------------------------------------------------------
#ifndef _HORIZCOMPASSCTRL_H_
#define _HORIZCOMPASSCTRL_H_

#ifndef _GUIBITMAPCTRL_H_
#include "gui/controls/guiBitmapCtrl.h"
#endif

struct CameraQuery
{
   SimObject*  object;
   F32         nearPlane;
   F32         farPlane;
   F32         fov;
   MatrixF     cameraMatrix;
};

class HorizCompassCtrl : public GuiBitmapCtrl
{
private:
	typedef GuiBitmapCtrl Parent;
	F32 mOffset;

protected:
   StringTableEntry mOuterBitmapName;
   GFXTexHandle     mTextureHandle;
   GFXTexHandle     mOuterTextureHandle;
   F32              mFontWidth;

public:
	//creation methods
	DECLARE_CONOBJECT(HorizCompassCtrl);
	HorizCompassCtrl();
   static void initPersistFields();

   //Parental methods
   bool onWake();
   void onSleep();

   void setOuterBitmap(const char *name);
	// adjust graphic position in regard to the font/letter size of the compass
   void setFontWidth(const F32 width);
   void setOuterBitmap(const GFXTexHandle &handle);

   void setBitmap(const char *name, bool resize = false);
   void setBitmap(GFXTexHandle handle, bool resize = false);
   S32 getWidth() const       { return(mTextureObject->getWidth()); }
   S32 getHeight() const      { return(mTextureObject->getHeight()); }

   void onRender(Point2I offset, const RectI &updateRect);
};

#endif