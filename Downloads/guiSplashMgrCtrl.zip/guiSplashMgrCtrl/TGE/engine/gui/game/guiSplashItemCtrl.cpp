#include "console/consoleTypes.h"
#include "console/console.h"
#include "console/consoleInternal.h"
#include "console/codeBlock.h"
#include "platform/event.h"
#include "dgl/gBitmap.h"
#include "dgl/dgl.h"
#include "sim/actionMap.h"
#include "gui/core/guiCanvas.h"
#include "gui/core/guiControl.h"
#include "gui/core/guiDefaultControlRender.h"
#include "gui//editor/guiEditCtrl.h"
//#include "gfx/gfxDrawUtil.h"
#include "gui/game/guiSplashItemCtrl.h"
#include "gui/game/guiSplashMgrCtrl.h"




//********************************************
//Implement this class as a console object
//********************************************
IMPLEMENT_CONOBJECT(guiSplashItemCtrl);


//********************************************
//Constructor
//********************************************
guiSplashItemCtrl:: guiSplashItemCtrl ()
{
      showingSplash  = false;
	  mDone = false;
	  mOrigBounds = RectI(0,0,0,0);
}




//********************************************
//Public methods
//********************************************

//This method sets the field values with the values from the
//control defintion in the gui file
void guiSplashItemCtrl::initPersistFields()
{
	//Persit the parent fields first
	Parent::initPersistFields();

	//Add our fields here
	addGroup("1. Splash Item");
	addField( "done",     TypeBool, Offset( mDone, guiSplashItemCtrl ) );
	endGroup("1. Splash Item");
}


//Override the default GuiControls rendering to perform our own
//In most cases controls that inherit this class will not need to
//override this method.
void guiSplashItemCtrl::onRender(Point2I offset, const RectI &updateRect){
	if(!mVisible)
		return;


   RectI ctrlRect(offset, getExtent());

   // Render the control based on if the editor is active or not
   if(smDesignTime != true){
	   if(showingSplash == true){
			//The editor is not active. Determine if we already have the original bounds
		   if(mOrigBounds == RectI(0,0,0,0)){
				ctrlRect = calcNewBounds(offset);
			}

			//if opaque, fill the update rect with the fill color
			if (mProfile->mOpaque)
				
				dglDrawRectFill(ctrlRect, mProfile->mFillColor);

			//if there's a border, draw the border
			if (mProfile->mBorder)
				renderBorder(ctrlRect, mProfile);

			onRenderNormal(offset, updateRect);
	   }
   }
   else{
	   //Editor is active so determine if we need to go back to the original bounds
		if(mOrigBounds != RectI(0,0,0,0)){
			//Yep, need to set the bounds back
			resize(mOrigBounds.point,mOrigBounds.extent);
			mOrigBounds = RectI(0,0,0,0);
		}

		//if opaque, fill the update rect with the fill color
		if (mProfile->mOpaque)
			dglDrawRectFill(ctrlRect, mProfile->mFillColor);

		//if there's a border, draw the border
		if (mProfile->mBorder)
			renderBorder(ctrlRect, mProfile);

		onRenderDesignTime(offset, updateRect);
	   
   }


}




//Override the default GuiConrol onWake method
bool guiSplashItemCtrl::onWake(){
	if(!Parent::onWake())
		return false;

	setActive(true);
	
	return true;
}

//Override the default GuiConrol onSleep method
void guiSplashItemCtrl::onSleep(){
	Parent::onSleep();
}


//If there is a mouse down event pass it up to the splash manager to handle
void guiSplashItemCtrl::onMouseDown(const GuiEvent &event)
{
  	//Let the parent handle this event
	guiSplashMgrCtrl *mgr = static_cast<guiSplashMgrCtrl*>(getParent());
	mgr->onMouseDown(event);
}

//If we ccaptured a key down event pass it up to the splash manager
bool guiSplashItemCtrl::onKeyDown(const GuiEvent &event)
{
	//Let the parent handle the key press
	guiSplashMgrCtrl *mgr = static_cast<guiSplashMgrCtrl*>(getParent());
	return mgr->onKeyDown(event);
}


//This method is called in the onrender method when the editors are active.
//Override this in your own class if you want to change how the control renders
//with the editors active. Here we just render some text.
void guiSplashItemCtrl::onRenderDesignTime( Point2I offset, const RectI &updateRect){
	//Just draw some text
	dglDrawText(mProfile->mFont,offset,"Splash Item");
}

//This method is called in the onrender method when the editors are not active.
//Override this in your own class if you want to change how the control renders
//with the editors inactive. Here we just render some text.
void guiSplashItemCtrl::onRenderNormal( Point2I offset, const RectI &updateRect){
   dglDrawText(mProfile->mFont,offset,"Splash Item");
}

//This method is used to calc the new bounds to be used when the control is rendered
//from the onRenderNormal method. Override this in your class to fit your needs.
RectI guiSplashItemCtrl::calcNewBounds( Point2I offset){
	RectI ctrlRect(offset, getExtent());

	//Store the original bounds for when we enter edit mode in the gui designer
	mOrigBounds = RectI(getBounds().point,getBounds().extent);

	//The editors are not active so change the rendering to be the size of the image
	Point2I screenSize = Platform::getWindowSize();

	Point2I position = Point2I(0,0);
	//Ok, try to center it
	U32 left = ((screenSize.x/2) - (getBounds().extent.x/2));
	U32 top = ((screenSize.y/2) - (getBounds().extent.y/2));
	position.x = left;
	position.y = top;

	ctrlRect = RectI(position,getBounds().extent);

	resize(position,getBounds().extent);

	return ctrlRect;
}


//this method will show the splash if the editors are not active.
//Override this in your class if needed.
void guiSplashItemCtrl::ShowSplash(){
	showingSplash = true;
	setVisible(true);
}
void guiSplashItemCtrl::StopSplash(){
	showingSplash = false;
	mDone = true;
	setVisible(false);
}


//********************************************
//Protected methods
//********************************************




//********************************************
//Private methods
//********************************************




//********************************************
//Console methods
//********************************************
