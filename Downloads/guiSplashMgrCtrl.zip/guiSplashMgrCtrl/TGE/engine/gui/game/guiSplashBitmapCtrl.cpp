#ifndef _GUISPLASHBITMAP_H_
#define _GUISPLASHBITMAP_H_

#ifndef _GUICONTROL_H_
#include "gui/core/guiControl.h"
#endif

#include "console/consoleTypes.h"
#include "console/console.h"
#include "console/consoleInternal.h"
#include "console/codeBlock.h"
#include "platform/event.h"
#include "dgl/gBitmap.h"
#include "dgl/dgl.h"
#include "sim/actionMap.h"
#include "gui/core/guiCanvas.h"
#include "gui/core/guiControl.h"
#include "gui/core/guiDefaultControlRender.h"
#include "gui//editor/guiEditCtrl.h"
#include "gui/game/guiSplashItemCtrl.h"
#include "gui/game/guiSplashMgrCtrl.h"

class guiSplashMgrCtrl;

//-----------------------------------------------------------------------------
/// This control will manage our guiSplashBitmapCtrl controls.
class guiSplashBitmapCtrl : public guiSplashItemCtrl
{
	//********************************************
	//Declare fields
	//********************************************
	private:
	typedef GuiControl Parent;
	U32 wakeTime;
	U32 fadeinTime;
	U32 waitTime;
	U32 fadeoutTime;

	protected:
	StringTableEntry mBitmapName;
	TextureHandle mTextureObject;


	//********************************************
	//Declare methods
	//********************************************
	public:
	guiSplashBitmapCtrl();   //class constructor

	//Override base GuiControl methods
	bool onWake();
	void onSleep();
	void ShowSplash();
	static void initPersistFields(); 

	void onRenderDesignTime( Point2I, const RectI &);
	void onRenderNormal( Point2I, const RectI &);
	RectI calcNewBounds( Point2I offset);


	void setBitmap(const char *name);
	void setBitmap(TextureHandle handle);

	protected:
	static bool setBitmapName( void *obj, const char *data );
	static const char *getBitmapName( void *obj, const char *data );

	//********************************************
	//Declare this class as a console object
	//********************************************
	public:
	DECLARE_CONOBJECT(guiSplashBitmapCtrl);
};
//-----------------------------------------------------------------------------
#endif

//********************************************
//Implement this class as a console object
//********************************************
IMPLEMENT_CONOBJECT(guiSplashBitmapCtrl);

//********************************************
//Constructor
//********************************************
guiSplashBitmapCtrl:: guiSplashBitmapCtrl()
{
      wakeTime    = 0;
      fadeinTime  = 1000;
      waitTime    = 2000;
      fadeoutTime = 1000;

      showingSplash  = false;
	  mDone = false;
	  mOrigBounds = RectI(0,0,0,0);

	  mBitmapName = StringTable->insert("");
}


//********************************************
//Public methods
//********************************************

//This method sets the field values with the values from the
//control defintion in the gui file
void guiSplashBitmapCtrl::initPersistFields()
{
	//Persit the parent fields first
	Parent::initPersistFields();

	//Add our fields here
	addGroup("2. Bitmap Splash");
	addField("fadeinTime", TypeS32, Offset(fadeinTime, guiSplashBitmapCtrl));
	addField("waitTime", TypeS32, Offset(waitTime, guiSplashBitmapCtrl));
	addField("fadeoutTime", TypeS32, Offset(fadeoutTime, guiSplashBitmapCtrl));
	addProtectedField( "bitmap", TypeFilename, Offset( mBitmapName, guiSplashBitmapCtrl ), &setBitmapName, &defaultProtectedGetFn, "" );
	endGroup("2. Bitmap Splash");
}




//Override the default GuiConrol onWake method
bool guiSplashBitmapCtrl::onWake(){
	if(!Parent::onWake())
		return false;

	setActive(true);
	setBitmap(mBitmapName);
	
	return true;
}

//Override the default GuiConrol onSleep method
void guiSplashBitmapCtrl::onSleep(){
	mTextureObject = NULL;
	Parent::onSleep();
}



//This method is called in the onrender method when the editors are active.
//Here we just render some text.
void guiSplashBitmapCtrl::onRenderDesignTime( Point2I offset, const RectI &updateRect){
	//Just draw some text
	dglDrawText(mProfile->mFont,offset,"Splash Bitmap Item");
}

//This method is called in the onrender method when the editors are not active.
//Here we are fading an image in and out based on our settings
void guiSplashBitmapCtrl::onRenderNormal( Point2I offset, const RectI &updateRect){

   if (mProfile->mBorder || !mTextureObject)
   {
      RectI rect(offset.x, offset.y, getExtent().x, getExtent().y);
      dglDrawRect(rect, mProfile->mBorderColor);
   }

	U32 elapsed = Platform::getRealMilliseconds() - wakeTime;

      U32 alpha = 255;
      if (elapsed < fadeinTime)
      {
         // fade-in
         alpha = (U32)(255.0f * (1.0f - (F32(elapsed) / F32(fadeinTime))));
      }
      else if (elapsed < (fadeinTime+waitTime))
      {
         // wait
         alpha = 0;
      }
      else if (elapsed < (fadeinTime+waitTime+fadeoutTime))
      {
         // fade out
         elapsed -= (fadeinTime+waitTime);
         alpha = (U32)(255.0f * F32(elapsed) / F32(fadeoutTime));
      }
      else
      {
         // done state
         alpha = fadeoutTime ? 255 : 0;
		 mDone = true;
      }

		if (mTextureObject)
		{
			alpha = 255 - alpha;

			ColorI color(255,255,255,alpha);
			dglSetBitmapModulation(color);

			RectI rect(offset, getExtent());
			dglDrawBitmapStretch(mTextureObject, rect, GFlip_None);
		}


	  if(mDone){
         showingSplash = false;
		 guiSplashMgrCtrl *mgr = static_cast<guiSplashMgrCtrl*>(getParent());
		 mgr->onSplashItemDone();
	  }
	  dglClearBitmapModulation();
}




//This method is used to calc the new bounds to be used when the control is rendered
//from the onRenderNormal method. This overrides the base classes method
//to use the images size as the new bounds.
RectI guiSplashBitmapCtrl::calcNewBounds( Point2I offset){
	RectI ctrlRect(offset, getExtent());

	//Store the original bounds for when we enter edit mode in the gui designer
	mOrigBounds = RectI(getBounds().point,getBounds().extent);

	//The editors are not active so change the rendering to be the size of the image
	Point2I screenSize = Platform::getWindowSize();
	Point2I bitmapSize = Point2I(mTextureObject.getWidth(), mTextureObject.getHeight());
	Point2I position = Point2I(0,0);
	//Ok, try to center the image
	U32 left = ((screenSize.x/2) - (bitmapSize.x/2));
	U32 top = ((screenSize.y/2) - (bitmapSize.y/2));
	position.x = left;
	position.y = top;

	ctrlRect = RectI(position,bitmapSize);

	resize(position,bitmapSize);

	return ctrlRect;
}

//this method will show the splash if the editors are not active.
//This overrides the base classes method
void guiSplashBitmapCtrl::ShowSplash(){
	showingSplash = true;
	mDone = false;
	setVisible(true);
	wakeTime = Platform::getRealMilliseconds();
}






//********************************************
//setBitmap methods
//********************************************
void guiSplashBitmapCtrl::setBitmap(const char *name)
{
   mBitmapName = StringTable->insert(name);
   if (*mBitmapName)
	{
		mTextureObject = TextureHandle(mBitmapName, BitmapTexture, true);
   }
   else
      mTextureObject = NULL;

   setUpdate();
}
void guiSplashBitmapCtrl::setBitmap(TextureHandle handle)
{
   mTextureObject = handle;
}


//********************************************
//Protected methods
//********************************************
bool guiSplashBitmapCtrl::setBitmapName( void *obj, const char *data )
{
   // Prior to this, you couldn't do bitmap.bitmap = "foo.jpg" and have it work.
   // With protected console types you can now call the setBitmap function and
   // make it load the image.
   static_cast<guiSplashBitmapCtrl *>( obj )->setBitmap( data );

   // Return false because the setBitmap method will assign 'mBitmapName' to the
   // argument we are specifying in the call.
   return false;
}









//********************************************
//Private methods
//********************************************




//********************************************
//Console methods
//********************************************
ConsoleMethod( guiSplashBitmapCtrl, setBitmap, void, 2, 3, "(string filename)"
               "Set the bitmap displayed in the control.")
{
   char fileName[1024];
   Con::expandScriptFilename(fileName, sizeof(fileName), argv[2]);
   object->setBitmap(fileName);
}