#ifndef _GUISPLASHITEM_H_
#define _GUISPLASHITEM_H_

#ifndef _GUICONTROL_H_
#include "gui/core/guiControl.h"
#endif
class guiSplashMgrCtrl;

//-----------------------------------------------------------------------------
/// This control will manage our guiSplashItemCtrl controls.
class guiSplashItemCtrl : public GuiControl
{
	//********************************************
	//Declare fields
	//********************************************
	private:
	typedef GuiControl Parent;

	protected:
	bool showingSplash;
	RectI mOrigBounds;	//This will store our original bounds
	bool mDone;

	//********************************************
	//Declare methods
	//********************************************
	public:
	guiSplashItemCtrl();   //class constructor

	//Override base GuiControl methods
	bool onWake();
	void onSleep();
	virtual void onRender( Point2I, const RectI &);
	static void initPersistFields(); 
	void onMouseDown(const GuiEvent &);
	bool onKeyDown(const GuiEvent &);


	//New methods
	virtual void onRenderDesignTime( Point2I, const RectI &);
	virtual void onRenderNormal( Point2I, const RectI &);
	virtual RectI calcNewBounds( Point2I offset);
	virtual void ShowSplash();
	virtual void StopSplash();

	protected:

	//********************************************
	//Declare this class as a console object
	//********************************************
	public:
	DECLARE_CONOBJECT(guiSplashItemCtrl);
};
//-----------------------------------------------------------------------------
#endif