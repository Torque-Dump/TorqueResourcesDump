#ifndef _GUISPLASHMGR_H_
#define _GUISPLASHMGR_H_

#ifndef _GUICONTROL_H_
#include "gui/core/guiControl.h"
#endif
//class guiSplashItemCtrl;
#include "gui/game/guiSplashItemCtrl.h"

//-----------------------------------------------------------------------------
/// This control will manage our guiSplashItemCtrl controls.
class guiSplashMgrCtrl : public GuiControl
{
	public:
	enum ERenderMode
	{
		eSequential	= 0,
		eRandom	= 1
	};

	//********************************************
	//Declare fields
	//********************************************
	private:
	typedef GuiControl Parent;
	RectI mOrigBounds;	//This will store our original bounds
	guiSplashItemCtrl* mActiveItem;
	Vector<guiSplashItemCtrl*> mSplashItems;
	ERenderMode mRenderMode;
	bool mShuffled;
	MRandomLCG random;
	bool mAutoStart;
	


	//********************************************
	//Declare methods
	//********************************************
	public:
	guiSplashMgrCtrl();   //class constructor

	//Override base GuiControl methods
	bool onWake();
	void onSleep();
	virtual void onMouseDown(const GuiEvent &);
	virtual bool onKeyDown(const GuiEvent &);
	void onRender( Point2I, const RectI &);
	static void initPersistFields(); 
	void onChildRemoved( GuiControl* child );
	void onChildAdded( GuiControl *child );
	void onSplashItemDone();
	void startSplash();
	void stopSplash();
	void showRandomSplash();
	void showNextSplash();
	void showSplashAtIndex(U32 index);

	private:	
	void preStart();
	S32 getRandomSplashIndex();
	

	

	//********************************************
	//Declare this class as a console object
	//********************************************
	public:	
	DECLARE_CONOBJECT( guiSplashMgrCtrl );
	
};
#endif