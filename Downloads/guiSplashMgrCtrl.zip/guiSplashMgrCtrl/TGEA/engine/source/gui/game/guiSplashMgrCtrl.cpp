#include "console/consoleTypes.h"
#include "console/console.h"
#include "console/consoleInternal.h"
#include "console/codeBlock.h"
#include "platform/event.h"
#include "gfx/bitmap/gBitmap.h"
#include "sim/actionMap.h"
#include "gui/core/guiCanvas.h"
#include "gui/core/guiControl.h"
#include "gui/core/guiDefaultControlRender.h"
#include "gui//editor/guiEditCtrl.h"
#include "gfx/gfxDrawUtil.h"
#include "gui/game/guiSplashMgrCtrl.h"
#include "math/mRandom.h"


//********************************************
//Implement this class as a console object
//********************************************
IMPLEMENT_CONOBJECT( guiSplashMgrCtrl );

static EnumTable::Enums gRenderEnums[] =
{
	{ guiSplashMgrCtrl::eSequential,	"Sequential"},
	{ guiSplashMgrCtrl::eRandom,		"Random"}
};
static EnumTable gRenderTable( 2, gRenderEnums );

//********************************************
//Constructor
//********************************************
guiSplashMgrCtrl::guiSplashMgrCtrl()
{
	mOrigBounds = RectI(0,0,0,0);
	mActiveItem = NULL;
	VECTOR_SET_ASSOCIATION(mSplashItems);
	mSplashItems.reserve(12);
	mRenderMode = eSequential;
	mShuffled = false;
	mAutoStart = true;

	random = MRandomLCG(1376312589 * (U32)this);
}


//********************************************
//Public methods
//********************************************

//This method sets the field values with the values from the
//control defintion in the gui file
void guiSplashMgrCtrl::initPersistFields()
{
	//Persit the parent fields first
	Parent::initPersistFields();

	//Add our fields here
	addGroup("Misc");
	addField( "RenderMode",   TypeEnum, Offset( mRenderMode, guiSplashMgrCtrl ), 1, &gRenderTable );
	addField( "AutoStart",       TypeBool, Offset( mAutoStart, guiSplashMgrCtrl ) );
	endGroup("Misc");
}



//Override the default GuiControls rendering to perform our own
void guiSplashMgrCtrl::onRender(Point2I offset, const RectI &updateRect){
	//Default the rendering to the profiled location
	RectI ctrlRect(offset, getExtent());

	//Test to see if the editors are active
	if(smDesignTime != true){
		//The editor is not active. Determine if we already have the original bounds
		if(mOrigBounds == RectI(0,0,0,0)){
			//Store the original bounds for when we enter edit mode in the gui designer
			mOrigBounds = RectI(getBounds().point,getBounds().extent);

			//The editors are not active so change the rendering to be the full screen
			Point2I screenSize = GFX->getActiveRenderTarget()->getSize();
			ctrlRect = RectI(Point2I(0,0),screenSize);

			resize(Point2I(0,0),screenSize);
		}
	}
	else{
		//Editor is active so determine if we need to go back to the original bounds
		if(mOrigBounds != RectI(0,0,0,0)){
			//Yep, need to set the bounds back
			resize(mOrigBounds.point,mOrigBounds.extent);
			mOrigBounds = RectI(0,0,0,0);
		}
	}
   
	

   //if opaque, fill the update rect with the fill color
   if (getControlProfile()->mOpaque)
      GFX->getDrawUtil()->drawRectFill(ctrlRect, getControlProfile()->mFillColor);

   //if there's a border, draw the border
   if (getControlProfile()->mBorder)
      renderBorder(ctrlRect, getControlProfile());

   // Render Children
   renderChildControls(offset, updateRect);
}
//Override the default GuiControl onChildRemoved method
void guiSplashMgrCtrl::onChildRemoved( GuiControl* child )
{
   for (S32 i = 0; i < mSplashItems.size(); i++ )
   {
      guiSplashItemCtrl* splash = mSplashItems[i];
      if( splash == static_cast<guiSplashItemCtrl*>(child) )
      {
         if( splash == mActiveItem )
            mActiveItem = NULL;
         mSplashItems.erase( i );
         break;
      }
   }

   if( mSplashItems.empty() )
      mActiveItem = NULL;
   else if (mActiveItem == NULL )
      mActiveItem = static_cast<guiSplashItemCtrl*>(mSplashItems[0]);

}
//Override the default GuiControl onChildAdded method
void guiSplashMgrCtrl::onChildAdded( GuiControl *child )
{
   guiSplashItemCtrl* splash = dynamic_cast<guiSplashItemCtrl*>(child);
   if( !splash )
   {
		Con::warnf("guiSplashMgrCtrl::onChildAdded - attempting to add NON guiSplashItemCtrl as child");
		SimObject *simObj = reinterpret_cast<SimObject*>(child);
		removeObject( simObj );
		GuiControl *rent = getParent();
		if( rent )
			rent->addObject( simObj );

		return;
   }

   splash->StopSplash();

	mSplashItems.push_back(splash);
}






//Override the default GuiConrol onMouseDown method
void guiSplashMgrCtrl::onMouseDown(const GuiEvent &)
   {
      Con::executef(this, "click");
   }
//Override the default GuiConrol onKeyDown method
bool guiSplashMgrCtrl::onKeyDown(const GuiEvent &)
   {
      Con::executef(this, "click");
      return true;
   }

//Override the default GuiConrol onWake method
bool guiSplashMgrCtrl::onWake(){
	if (! Parent::onWake())
		return false;

	setActive(true);
	if(mAutoStart == true)
		startSplash();

   return true;
}

//Override the default GuiConrol onSleep method
void guiSplashMgrCtrl::onSleep(){
	Parent::onSleep();
}



//Begins the splash process
void guiSplashMgrCtrl::startSplash(){
	
	preStart();	

	if(mSplashItems.size() > 0){
		mActiveItem = mSplashItems[0];
		mActiveItem->ShowSplash();
	}
}


void guiSplashMgrCtrl::stopSplash(){
	iterator i;
	for(i = begin(); i != end(); i++)
	{
	  guiSplashItemCtrl *ctrl = dynamic_cast<guiSplashItemCtrl *>(*i);
	  ctrl->StopSplash();
	  ctrl->setActive(false);
	  ctrl->setVisible(false);
	}
}
//Shows a random splash item
void guiSplashMgrCtrl::showRandomSplash(){
	mActiveItem = NULL;
	//If we are showing random splashes we don't care about the active splash
	S32 iSplash = getRandomSplashIndex();
	mSplashItems[iSplash]->ShowSplash();

}

//Called when a splash item has finished
void guiSplashMgrCtrl::onSplashItemDone(){
	if(mActiveItem != NULL){
		mActiveItem->setActive(false);
		mActiveItem->setVisible(false);

		S32 itemCount = mSplashItems.size();
		if(itemCount > 1){
			for (S32 i = 0; i < itemCount; i++ ){
				guiSplashItemCtrl* splash = mSplashItems[i];
				if(splash == mActiveItem){
					if(i < (itemCount-1)){
						mActiveItem = mSplashItems[i+1];
					}
					else{
						mActiveItem = NULL;
					}
					break;
				}
			}
		}
	}

	if(mActiveItem != NULL){
		mActiveItem->setActive(true);
		mActiveItem->ShowSplash();
	}
	else{
		//We have no more splash itms so fire the script call back
		if(isMethod("onSplashCompleted")){
			Con::executef(this, "onSplashCompleted");
		}
	}
	return;
}

//Shows the next splash item if available
void guiSplashMgrCtrl::showNextSplash(){
	//We are going to cycle to the next splash screen if we can
	onSplashItemDone();
}

//Shows a splash item at the passed in index
void guiSplashMgrCtrl::showSplashAtIndex(U32 index){
	mActiveItem = NULL;
	if(index <= mSplashItems.size()){
		mSplashItems[index]->ShowSplash();
	}
}



//********************************************
//Private methods
//********************************************
//Determines if the splash items need to be randomized before being displayed
void guiSplashMgrCtrl::preStart(){
   AssertFatal(mAwake, "guiSplashMgrCtrl::preStart: control is not awake");
   if(!mAwake)
      return;

   mActiveItem = NULL;

	//If we have switch our rendering mode we need to fixup the vector
	if(mRenderMode == eSequential){
		if(mShuffled == true){
			mSplashItems.clear();

			iterator i;
			for(i = begin(); i != end(); i++)
			{
			  guiSplashItemCtrl *ctrl = dynamic_cast<guiSplashItemCtrl *>(*i);
			  ctrl->setActive(false);
			  ctrl->setVisible(false);
			  mSplashItems.push_back(ctrl);
			}
			mShuffled = false;
		}
	}
	else{
		if(mShuffled == false){
			Vector<S32> splashIndexes;
			S32 i;
			while(splashIndexes.size() != mSplashItems.size()){
				i = getRandomSplashIndex();
				if(splashIndexes.find_next(i) == -1){
					splashIndexes.push_back(i);
				}
			}

			Vector<guiSplashItemCtrl*> newSplashItems;
			for(i = 0; i < splashIndexes.size(); i++)
			{
				S32 iIndex = splashIndexes[i];
				newSplashItems.push_back(mSplashItems[iIndex]);
			}

			//mSplashItems = newSplashItems;
			for(i = 0; i < mSplashItems.size(); i++)
			{
				newSplashItems[i]->setActive(false);
				newSplashItems[i]->setVisible(false);
				mSplashItems[i] = newSplashItems[i];
			}

			mShuffled = true;
		}
	}

	mActiveItem = mSplashItems[0];
}

//Returns a random index to randomize the splash items
S32 guiSplashMgrCtrl::getRandomSplashIndex(){
	S32 returnIndex = -1;

	S32 splashSize = mSplashItems.size();
	if(splashSize > 1){
		returnIndex = random.randI(0,(splashSize-1));
	}
	else{
		returnIndex = 0;
	}

	return returnIndex;
}



//********************************************
//Console methods
//********************************************
ConsoleMethod(guiSplashMgrCtrl, startSplash, void, 0, 0, "Starts the splash manager.")
{
   object->startSplash();
}
ConsoleMethod(guiSplashMgrCtrl, stopSplash, void, 0, 0, "Stops the splash manager.")
{
   object->stopSplash();
}

ConsoleMethod(guiSplashMgrCtrl, showRandomSplash, void, 0, 0, "Shows a random splash item.")
{
   object->showRandomSplash();
}

ConsoleMethod(guiSplashMgrCtrl, showNextSplash, void, 0, 0, "Shows the next splash item if available.")
{
   object->showNextSplash();
}
ConsoleMethod(guiSplashMgrCtrl, showSplashAtIndex, void, 3, 3, "Shows a splash item at the passed in index.")
{
   object->showSplashAtIndex(dAtof(argv[2]));
}