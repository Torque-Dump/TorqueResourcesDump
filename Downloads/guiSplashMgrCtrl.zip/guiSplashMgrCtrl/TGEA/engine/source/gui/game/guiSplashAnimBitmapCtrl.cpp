#ifndef _GUISPLASHANIMBITMAP_H_
#define _GUISPLASHANIMBITMAP_H_

#ifndef _GUICONTROL_H_
#include "gui/core/guiControl.h"
#endif

#include "console/consoleTypes.h"
#include "console/console.h"
#include "console/consoleInternal.h"
#include "console/codeBlock.h"
#include "platform/event.h"
#include "gfx/bitmap/gBitmap.h"
#include "sim/actionMap.h"
#include "gui/core/guiCanvas.h"
#include "gui/core/guiControl.h"
#include "gui/core/guiDefaultControlRender.h"
#include "gui//editor/guiEditCtrl.h"
#include "materials/materialList.h"
#include "gfx/gfxDrawUtil.h"
#include "T3D/shapeBase.h"
#include "gui/game/guiSplashItemCtrl.h"
#include "gui/game/guiSplashMgrCtrl.h"

class guiSplashMgrCtrl;

#define MAX_NUM_SPLASH_IMAGES 30
//-----------------------------------------------------------------------------
/// This control will manage our guiSplashAnimBitmapCtrl controls.
class guiSplashAnimBitmapCtrl : public guiSplashItemCtrl
{
	//********************************************
	//Declare fields
	//********************************************
	private:
	typedef GuiControl Parent;
	U32 wakeTime;
	U32 fadeinTime;
	U32 waitTime;
	U32 fadeoutTime;

   	S32	mAnimationRate;
	S32	mCurrentImageIndex;
	F32	mNextFrameTime;
	S32	mNumTextures;
	bool mPlayAnimation;
	U32 mAnimationTimes[MAX_NUM_SPLASH_IMAGES];

	protected:
	StringTableEntry mBitmapName;
	GFXTexHandle mTextures[MAX_NUM_SPLASH_IMAGES];


	//********************************************
	//Declare methods
	//********************************************
	public:
	guiSplashAnimBitmapCtrl();   //class constructor

	//Override base GuiControl methods
	bool onWake();
	void onSleep();
	void ShowSplash();
	static void initPersistFields(); 

	void onRenderDesignTime( Point2I, const RectI &);
	void onRenderNormal( Point2I, const RectI &);
	RectI calcNewBounds( Point2I offset);


	void setBitmap(const char *name);
	void setAnimationRate(S32 value);
	void clearTextures();

	protected:
	static bool setBitmapName( void *obj, const char *data );
	static const char *getBitmapName( void *obj, const char *data );

	//********************************************
	//Declare this class as a console object
	//********************************************
	public:
	DECLARE_CONOBJECT(guiSplashAnimBitmapCtrl);
};
//-----------------------------------------------------------------------------
#endif

//********************************************
//Implement this class as a console object
//********************************************
IMPLEMENT_CONOBJECT(guiSplashAnimBitmapCtrl);

//********************************************
//Constructor
//********************************************
guiSplashAnimBitmapCtrl:: guiSplashAnimBitmapCtrl()
{
      wakeTime    = 0;
      fadeinTime  = 1000;
      waitTime    = 2000;
      fadeoutTime = 1000;

      showingSplash  = false;
	  mDone = false;
	  mOrigBounds = RectI(0,0,0,0);

	  mBitmapName = StringTable->insert("");

	  mCurrentImageIndex = 0;
	  mAnimationRate = 500;
	  mNextFrameTime = 0;
	  mNumTextures = 0;
	  mPlayAnimation = false;
}


//********************************************
//Public methods
//********************************************

//This method sets the field values with the values from the
//control defintion in the gui file
void guiSplashAnimBitmapCtrl::initPersistFields()
{
	//Persit the parent fields first
	Parent::initPersistFields();

	//Add our fields here
	addGroup("2. Animated Bitmap Splash");
	addField("fadeinTime", TypeS32, Offset(fadeinTime, guiSplashAnimBitmapCtrl));
	addField("waitTime", TypeS32, Offset(waitTime, guiSplashAnimBitmapCtrl));
	addField("fadeoutTime", TypeS32, Offset(fadeoutTime, guiSplashAnimBitmapCtrl));
	addField( "animationRate",	TypeS32, Offset(mAnimationRate, guiSplashAnimBitmapCtrl ) );
	//addProtectedField( "bitmap", TypeFilename, Offset( mBitmapName, guiSplashAnimBitmapCtrl ), &setBitmapName, &defaultProtectedGetFn, "" );
	addField( "bitmap",			TypeFilename, Offset(mBitmapName, guiSplashAnimBitmapCtrl ) ); 
	endGroup("2. Animated Bitmap Splash");
}




//Override the default GuiConrol onWake method
bool guiSplashAnimBitmapCtrl::onWake(){
	if(!Parent::onWake())
		return false;

	setActive(true);
	setBitmap(mBitmapName);
	
	return true;
}

//Override the default GuiConrol onSleep method
void guiSplashAnimBitmapCtrl::onSleep(){
	clearTextures();
	Parent::onSleep();
}



//This method is called in the onrender method when the editors are active.
//Here we just render some text.
void guiSplashAnimBitmapCtrl::onRenderDesignTime( Point2I offset, const RectI &updateRect){
	//Just draw some text
	GFX->getDrawUtil()->drawText(getControlProfile()->mFont,offset,"Splash Bitmap Item");
}

//This method is called in the onrender method when the editors are not active.
//Here we are fading an image in and out based on our settings
void guiSplashAnimBitmapCtrl::onRenderNormal( Point2I offset, const RectI &updateRect){
	// mAnimationTimes



	if(mPlayAnimation){
		F32 currentTime = Platform::getVirtualMilliseconds();
		if(mNextFrameTime == 0){
			//mNextFrameTime = currentTime + mAnimationRate;
			mNextFrameTime = currentTime + mAnimationTimes[mCurrentImageIndex];
		}

		if(mNextFrameTime < currentTime){
			//move to the next index
			mCurrentImageIndex++;
			//S32 mUpdateRate = mAnimationRate;
			S32 mUpdateRate = mAnimationTimes[mCurrentImageIndex];

			mNextFrameTime = currentTime + mUpdateRate;
		}
	}
	
	if(mCurrentImageIndex > (mNumTextures-1)){
		mCurrentImageIndex = (mNumTextures-1);
	}

	GFXTexHandle mTextureHandle = mTextures[mCurrentImageIndex];
	if(!mTextureHandle){
		mTextureHandle = mTextures[0];
		mCurrentImageIndex = 0;
	}

   if (mProfile->mBorder || !mTextureHandle)
   {
      RectI rect(offset.x, offset.y, getExtent().x, getExtent().y);
      GFX->getDrawUtil()->drawRect(rect, mProfile->mBorderColor);
   }

	U32 elapsed = Platform::getRealMilliseconds() - wakeTime;

      U32 alpha = 255;
      if (elapsed < fadeinTime)
      {
         // fade-in
         alpha = (U32)(255.0f * (1.0f - (F32(elapsed) / F32(fadeinTime))));
      }
      else if (elapsed < (fadeinTime+waitTime))
      {
         // wait
         alpha = 0;
      }
      else if (elapsed < (fadeinTime+waitTime+fadeoutTime))
      {
         // fade out
         elapsed -= (fadeinTime+waitTime);
         alpha = (U32)(255.0f * F32(elapsed) / F32(fadeoutTime));
      }
      else
      {
         // done state
         alpha = fadeoutTime ? 255 : 0;
		 mDone = true;
      }

		if (mTextureHandle)
		{
			alpha = 255 - alpha;

			ColorI color(255,255,255,alpha);
			GFX->getDrawUtil()->setBitmapModulation(color);

			RectI rect(offset, getExtent());
			GFX->getDrawUtil()->drawBitmapStretch(mTextureHandle, rect, GFXBitmapFlip_None, GFXTextureFilterLinear);
		}


	  if(mDone){
         showingSplash = false;
		 guiSplashMgrCtrl *mgr = static_cast<guiSplashMgrCtrl*>(getParent());
		 mgr->onSplashItemDone();
	  }
	  GFX->getDrawUtil()->clearBitmapModulation();
}




//This method is used to calc the new bounds to be used when the control is rendered
//from the onRenderNormal method. This overrides the base classes method
//to use the images size as the new bounds.
RectI guiSplashAnimBitmapCtrl::calcNewBounds( Point2I offset){
	RectI ctrlRect(offset, getExtent());

	//Store the original bounds for when we enter edit mode in the gui designer
	mOrigBounds = RectI(getBounds().point,getBounds().extent);

	//The editors are not active so change the rendering to be the size of the image
	Point2I screenSize = GFX->getActiveRenderTarget()->getSize();
	Point2I bitmapSize = Point2I(mTextures[0].getWidth(), mTextures[0].getHeight());
	
	Point2I position = Point2I(0,0);
	//Ok, try to center the image
	U32 left = ((screenSize.x/2) - (bitmapSize.x/2));
	U32 top = ((screenSize.y/2) - (bitmapSize.y/2));
	position.x = left;
	position.y = top;

	ctrlRect = RectI(position,bitmapSize);

	resize(position,bitmapSize);

	return ctrlRect;
}

//this method will show the splash if the editors are not active.
//This overrides the base classes method
void guiSplashAnimBitmapCtrl::ShowSplash(){
	mCurrentImageIndex = 0;
	showingSplash = true;
	mDone = false;
	setVisible(true);
	wakeTime = Platform::getRealMilliseconds();
}


void guiSplashAnimBitmapCtrl::setAnimationRate(S32 value){
   mAnimationRate = value;
}
//********************************************
//setBitmap methods
//********************************************
void guiSplashAnimBitmapCtrl::setBitmap(const char *name)
{
	//Clear any previous textures
	clearTextures();

   S32 x;
   mNumTextures = 0;
   Stream *stream = gResourceManager->openStream(name);
   if(stream){
       MaterialList mMaterialList;
       mMaterialList.read(*stream);
       gResourceManager->closeStream(stream);

       char path[1024];
	   dStrcpy(path, name);

       mMaterialList.load(path);
       for(x = 0; x < mMaterialList.size(); ++x){
           if(mMaterialList.getMaterial(x)){
               mTextures[mNumTextures] = mMaterialList.getMaterial(x);
			   mAnimationTimes[mNumTextures] = mAnimationRate;
			   //Does the file name contain an animation rate?
			   U32 ar = mMaterialList.getMaterialName(x).find("_ar",String::NoCase);
			   if(String::NPos != ar){
					//Seems like we do so get the rate
				   U32 point = mMaterialList.getMaterialName(x).find(".",ar,String::NoCase);
					if(String::NPos != point){
						ar += 3;
						U32 len = point - (ar);
						String s = mMaterialList.getMaterialName(x).substr((ar),len);

						mAnimationTimes[mNumTextures] = dAtoi(s);
					}
			   }
               mNumTextures++;
		   }
	   }
   }

   if(mNumTextures == 0){
       mBitmapName = StringTable->insert(name);
       if (*mBitmapName) {
           GFXTexHandle mTextureHandle = GFXTexHandle(mBitmapName, &GFXDefaultStaticDiffuseProfile,"splashItemImage");

           if(mTextureHandle){
               mTextures[0] = mTextureHandle;
			   mAnimationTimes[0] = mAnimationRate;
               mNumTextures++;
		   }
	   }
       else{
           mTextures[0] = NULL;
	   }
   }

   mPlayAnimation = (mNumTextures > 1);

   setUpdate();
}



void guiSplashAnimBitmapCtrl::clearTextures(){
	for(S32 i=0;i<MAX_NUM_SPLASH_IMAGES;i++){
		mTextures[i] = NULL;
		mAnimationTimes[i] = 0;
	}
}


//********************************************
//Protected methods
//********************************************
bool guiSplashAnimBitmapCtrl::setBitmapName( void *obj, const char *data )
{
   // Prior to this, you couldn't do bitmap.bitmap = "foo.jpg" and have it work.
   // With protected console types you can now call the setBitmap function and
   // make it load the image.
   static_cast<guiSplashAnimBitmapCtrl *>( obj )->setBitmap( data );

   // Return false because the setBitmap method will assign 'mBitmapName' to the
   // argument we are specifying in the call.
   return false;
}

//********************************************
//Private methods
//********************************************




//********************************************
//Console methods
//********************************************
ConsoleMethod( guiSplashAnimBitmapCtrl, setBitmap, void, 2, 3, "(string filename)"
               "Set the bitmap displayed in the control.")
{
   char fileName[1024];
   Con::expandScriptFilename(fileName, sizeof(fileName), argv[2]);
   object->setBitmap(fileName);
}

ConsoleMethod(guiSplashAnimBitmapCtrl, setAnimationRate, void, 3, 3, "Sets the default animation rate of the splash.")
{
   object->setAnimationRate(dAtoi(argv[2]));
}