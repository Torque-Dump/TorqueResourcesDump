//-----------------------------------------------------------------------------
// Torque Game Engine Advanced
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "sceneGraph/sceneState.h"
#include "sceneGraph/sceneGraph.h"
#include "sceneGraph/lightInfo.h"
#include "sceneGraph/lightManager.h"
#include "console/consoleTypes.h"
#include "console/typeValidators.h"
#include "core/resourceManager.h"
#include "core/stream/bitStream.h"
#include "T3D/fx/explosion.h"
#include "T3D/shapeBase.h"
#include "ts/tsShapeInstance.h"
#include "T3D/projectile.h"
#include "sfx/sfxSystem.h"
#include "math/mathUtils.h"
#include "math/mathIO.h"
#include "sim/netConnection.h"
#include "T3D/fx/particleEmitter.h"
#include "terrain/waterBlock.h"
#include "T3D/fx/splash.h"
#include "T3D/tsStatic.h"
#include "materials/materialManager.h"
#include "T3D/player.h"
#include "T3D/vehicles/vehicle.h"
#include "sceneGraph/decalManager.h"

#include "T3D/gameProcess.h"
#include "terrain/terrData.h"
//WindEffect
#include "terrain/sky.h"

//#include "T3D/bgcliffs/tsBGCliffStatic.h" //Uncomment if you are using the BG Cliff Kit

IMPLEMENT_CO_DATABLOCK_V1(ProjectileData);
IMPLEMENT_CO_NETOBJECT_V1(Projectile);

const U32 Projectile::csmStaticCollisionMask =  AtlasObjectType   | 
                                                TerrainObjectType    |
                                                InteriorObjectType   |
												StaticObjectType; //Comment this line and uncomment the following if using the BG Cliff Kit
												/*
                                                StaticObjectType     |
												BGCliffObjectType;
												*/

const U32 Projectile::csmDynamicCollisionMask = PlayerObjectType        |
                                                VehicleObjectType       |
                                                // phdana turrets ->
                                                //TurretObjectType       | //Uncomment if using Turrets resource
                                                // <- phdana turrets 
                                                DamagableItemObjectType;

const U32 Projectile::csmDamageableMask = Projectile::csmDynamicCollisionMask;

U32 Projectile::smProjectileWarpTicks = 5;


//--------------------------------------------------------------------------
//
ProjectileData::ProjectileData()
{
   projectileShapeName = NULL;

   sound = NULL;
   soundId = 0;

   bloodExplosion = NULL;
   bloodExplosionId = 0;

   waterExplosion = NULL;
   waterExplosionId = 0;

   hasLight = false;
   lightRadius = 1;
   lightColor.set(1, 1, 1);

   faceViewer = false;
   scale.set( 1.0f, 1.0f, 1.0f );

   isBallistic = false;

   //Guided or Seeker Projectiles
   isGuided = false;
   isHeatSeeker = false;
   sweepRadius = 10.0f;
   precision = 0;
   trackDelay = 0;

   /// Terrain following is off by default.
   /// If turned on though, its other defaults
   /// lead to strong and obvious behavior.
   /// Good for people who are cluelessly
   /// experimenting.
   isTerrainFollowing = false;
   minTerrainHeight = 5;
   maxTerrainHeight = 5;
   speedTerrainFollowing = 100;
   
   isSidewinder = false;
   crazyness  = 1000; //BSK 1000 less 10 more
   sideDelay  = 10;
   multiplier = 25;

   //Water explosion and stopping
   explodeOnWater = false;
   stoppedByWater = false;

   //Ballistic Coefficients
   ballisticCoefficient = 1.0; // completely frictionless

   //Wind
   useWind = false;
   windEffect = 0.0f;

   // Explode on explodetime expiration - T_F -Cozz
   explodeOnExplodeTime = false;
   velInheritFactor = 1.0f;
   muzzleVelocity = 50;

   //Piercing Projectile variables
   mPierceWidth = 0.0003f;
   mPlayerRearScanDist = 5.0f;
   
   armingDelay = 0;
   fadeDelay = 20000 / 32;
   lifetime = 20000 / 32;
   explodetime = 10000 / 32;

   activateSeq = -1;
   maintainSeq = -1;

   gravityMod = 1.0;
   bounceElasticity = 0.999f;
   bounceFriction = 0.3f;

   particleEmitter = NULL;
   particleEmitterId = 0;

   particleWaterEmitter = NULL;
   particleWaterEmitterId = 0;

   splash = NULL;
   splashId = 0;

   for (U32 a = 0; a < NumFX; a++)
   {
      explosionSetOne[a] = NULL;
      explosionIdOne[a] = 0;
   }
   for (U32 b = 0; b < NumFX; b++)
   {
      explosionSetTwo[b] = NULL;
      explosionIdTwo[b] = 0;
   }
   for (U32 c = 0; c < NumFX; c++)
   {
      explosionSetThree[c] = NULL;
      explosionIdThree[c] = 0;
   }
   for (U32 d = 0; d < NumFX; d++)
   {
      explosionSetFour[d] = NULL;
      explosionIdFour[d] = 0;
   }
   for (U32 e = 0; e < NumFX; e++)
   {
      explosionSetFive[e] = NULL;
      explosionIdFive[e] = 0;
   }
   for (U32 f = 0; f < NumFX; f++)
   {
      explosionSetSix[f] = NULL;
      explosionIdSix[f] = 0;
   }
 
   for (U32 h = 0; h < NumFX; h++)
   {
      decalSetOne[h] = NULL;
      decalIdOne[h] = 0;
   }
   for (U32 j = 0; j < NumFX; j++)
   {
      decalSetTwo[j] = NULL;
      decalIdTwo[j] = 0;
   }
   for (U32 k = 0; k < NumFX; k++)
   {
      decalSetThree[k] = NULL;
      decalIdThree[k] = 0;
   }
   for (U32 l = 0; l < NumFX; l++)
   {
      decalSetFour[l] = NULL;
      decalIdFour[l] = 0;
   }
   for (U32 m = 0; m < NumFX; m++)
   {
      decalSetFive[m] = NULL;
      decalIdFive[m] = 0;
   }
   for (U32 n = 0; n < NumFX; n++)
   {
      decalSetSix[n] = NULL;
      decalIdSix[n] = 0;
   }
   for (U32 u = 0; u < NumFX; u++)
   {
      bloodSplatter[u] = NULL;
	  bloodSplatterId[u] = 0;
   }
}

//--------------------------------------------------------------------------
IMPLEMENT_CONSOLETYPE(ProjectileData)
IMPLEMENT_GETDATATYPE(ProjectileData)
IMPLEMENT_SETDATATYPE(ProjectileData)

void ProjectileData::initPersistFields()
{
   Parent::initPersistFields();

   addNamedField(particleEmitter,  TypeParticleEmitterDataPtr, ProjectileData);
   addNamedField(particleWaterEmitter, TypeParticleEmitterDataPtr, ProjectileData);

   addNamedField(projectileShapeName, TypeFilename, ProjectileData);
   addNamedField(scale, TypePoint3F, ProjectileData);

   addNamedField(sound, TypeSFXProfilePtr, ProjectileData);

   addNamedField(bloodExplosion, TypeExplosionDataPtr, ProjectileData);
   addField("bloodSplatter", TypeDecalDataPtr, Offset(bloodSplatter, ProjectileData), NumFX); //RJN

   addNamedField(waterExplosion, TypeExplosionDataPtr, ProjectileData);

   addNamedField(splash, TypeSplashDataPtr, ProjectileData);
   addField("decalSetOne", TypeDecalDataPtr, Offset(decalSetOne, ProjectileData), NumFX);
   addField("decalSetTwo", TypeDecalDataPtr, Offset(decalSetTwo, ProjectileData), NumFX);
   addField("decalSetThree", TypeDecalDataPtr, Offset(decalSetThree, ProjectileData), NumFX);
   addField("decalSetFour", TypeDecalDataPtr, Offset(decalSetFour, ProjectileData), NumFX);
   addField("decalSetFive", TypeDecalDataPtr, Offset(decalSetFive, ProjectileData), NumFX);
   addField("decalSetSix", TypeDecalDataPtr, Offset(decalSetSix, ProjectileData), NumFX);

   addField("explosionSetOne", TypeExplosionDataPtr, Offset(explosionSetOne, ProjectileData), NumFX);
   addField("explosionSetTwo", TypeExplosionDataPtr, Offset(explosionSetTwo, ProjectileData), NumFX);
   addField("explosionSetThree", TypeExplosionDataPtr, Offset(explosionSetThree, ProjectileData), NumFX);
   addField("explosionSetFour", TypeExplosionDataPtr, Offset(explosionSetFour, ProjectileData), NumFX);
   addField("explosionSetFive", TypeExplosionDataPtr, Offset(explosionSetFive, ProjectileData), NumFX);
   addField("explosionSetSix", TypeExplosionDataPtr, Offset(explosionSetSix, ProjectileData), NumFX);

   addNamedField(hasLight, TypeBool, ProjectileData);
   addNamedFieldV(lightRadius, TypeF32, ProjectileData, new FRangeValidator(1, 20));
   addNamedField(lightColor, TypeColorF, ProjectileData);
	
   addNamedField(explodeOnExplodeTime, TypeBool, ProjectileData); // -Cozz
   addNamedField(isBallistic, TypeBool, ProjectileData);
   addNamedFieldV(ballisticCoefficient, TypeF32, ProjectileData, new FRangeValidator(0, 1));

   addNamedFieldV(velInheritFactor, TypeF32, ProjectileData, new FRangeValidator(0, 1));
   addNamedFieldV(muzzleVelocity, TypeF32, ProjectileData, new FRangeValidator(0, 10000));

   addField("pierceWidthOffset",  TypeF32, Offset(mPierceWidth, ProjectileData));
   addField("playerRearScanDist",  TypeF32, Offset(mPlayerRearScanDist, ProjectileData));

   addNamedFieldV(lifetime, TypeS32, ProjectileData, new IRangeValidatorScaled(TickMs, 0, Projectile::MaxLivingTicks));
   addNamedFieldV(explodetime, TypeS32, ProjectileData, new IRangeValidatorScaled(TickMs, 0, Projectile::MaxLivingTicks)); // -Cozz
   addNamedFieldV(armingDelay, TypeS32, ProjectileData, new IRangeValidatorScaled(TickMs, 0, Projectile::MaxLivingTicks));
   addNamedFieldV(fadeDelay, TypeS32, ProjectileData, new IRangeValidatorScaled(TickMs, 0, Projectile::MaxLivingTicks));

   addNamedFieldV(bounceElasticity, TypeF32, ProjectileData, new FRangeValidator(0, 0.999f));
   addNamedFieldV(bounceFriction, TypeF32, ProjectileData, new FRangeValidator(0, 1));
   addNamedFieldV(gravityMod, TypeF32, ProjectileData, new FRangeValidator(0, 1));
   
   addNamedField(useWind, TypeBool, ProjectileData);
   addNamedField(windEffect, TypeF32, ProjectileData);

   //Water explosion and stopping
   addNamedField(explodeOnWater, TypeBool, ProjectileData);
   addNamedField(stoppedByWater, TypeBool, ProjectileData);

   //Guided or Seeker Projectiles
   addNamedField(isGuided, TypeBool, ProjectileData);  
   addNamedField(isHeatSeeker, TypeBool, ProjectileData);
   addNamedFieldV(sweepRadius, TypeF32, ProjectileData, new FRangeValidator(1, 1000));
   addNamedFieldV(precision, TypeF32, ProjectileData, new FRangeValidator(0, 100));
   addNamedFieldV(trackDelay, TypeS32, ProjectileData, new FRangeValidator(0, 100000)); 

   addNamedField(isTerrainFollowing, TypeBool, ProjectileData);
   addNamedFieldV(minTerrainHeight, TypeF32, ProjectileData, new FRangeValidator(-5000, 5000));
   addNamedFieldV(maxTerrainHeight, TypeF32, ProjectileData, new FRangeValidator(-5000, 5000));
   addNamedFieldV(speedTerrainFollowing, TypeF32, ProjectileData, new FRangeValidator(0, 10000)); 
   
   //Sidewinder stuff
   addNamedField(isSidewinder, TypeBool, ProjectileData);
   addNamedFieldV(crazyness, TypeF32, ProjectileData, new FRangeValidator(0, 500));
   addNamedFieldV(sideDelay, TypeS32, ProjectileData, new IRangeValidatorScaled(TickMs, 0, Projectile::MaxLivingTicks));
   addNamedFieldV(multiplier, TypeF32, ProjectileData, new FRangeValidator(0, 500));
}


//--------------------------------------------------------------------------
bool ProjectileData::onAdd()
{
   if(!Parent::onAdd())
      return false;

   for (U32 a = 0; a < NumFX; a++)
   {
	   if (!decalSetOne[a] && decalIdOne[a] != 0)
		   if (Sim::findObject(decalIdOne[a], decalSetOne[a]) == false)
			   Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(decalSetOne[%d]): %d", a, decalIdOne[a]);
   }

   for (U32 b = 0; b < NumFX; b++)
   {
	   if (!decalSetTwo[b] && decalIdTwo[b] != 0)
		   if (Sim::findObject(decalIdTwo[b], decalSetTwo[b]) == false)
			   Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(decalSetTwo[%d]): %d", b, decalIdTwo[b]);
   }

   for (U32 c = 0; c < NumFX; c++)
   {
	   if (!decalSetThree[c] && decalIdThree[c] != 0)
		   if (Sim::findObject(decalIdThree[c], decalSetThree[c]) == false)
			   Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(decalSetThree[%d]): %d", c, decalIdThree[c]);
   }

   for (U32 d = 0; d < NumFX; d++)
   {
	   if (!decalSetFour[d] && decalIdFour[d] != 0)
		   if (Sim::findObject(decalIdFour[d], decalSetFour[d]) == false)
			   Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(decalSetFour[%d]): %d", d, decalIdFour[d]);
   }

   for (U32 e = 0; e < NumFX; e++)
   {
	   if (!decalSetFive[e] && decalIdFive[e] != 0)
		   if (Sim::findObject(decalIdFive[e], decalSetFive[e]) == false)
			   Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(decalSetFive[%d]): %d", e, decalIdFive[e]);
   }

   for (U32 f = 0; f < NumFX; f++)
   {
	   if (!decalSetSix[f] && decalIdSix[f] != 0)
		   if (Sim::findObject(decalIdSix[f], decalSetSix[f]) == false)
			   Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(decalSetSix[%d]): %d", f, decalIdSix[f]);
   }

   for (U32 g = 0; g < NumFX; g++)
   {
	   if (!explosionSetOne[g] && explosionIdOne[g] != 0)
		   if (Sim::findObject(explosionIdOne[g], explosionSetOne[g]) == false)
			   Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(explosionSetOne[%d]): %d", g, explosionIdOne[g]);
   }

   for (U32 h = 0; h < NumFX; h++)
   {
	   if (!explosionSetTwo[h] && explosionIdTwo[h] != 0)
		   if (Sim::findObject(explosionIdTwo[h], explosionSetTwo[h]) == false)
			   Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(explosionSetTwo[%d]): %d", h, explosionIdTwo[h]);
   }

   for (U32 i = 0; i < NumFX; i++)
   {
	   if (!explosionSetThree[i] && explosionIdThree[i] != 0)
		   if (Sim::findObject(explosionIdThree[i], explosionSetThree[i]) == false)
			   Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(explosionSetThree[%d]): %d", i, explosionIdThree[i]);
   }

   for (U32 j = 0; j < NumFX; j++)
   {
	   if (!explosionSetFour[j] && explosionIdFour[j] != 0)
		   if (Sim::findObject(explosionIdFour[j], explosionSetFour[j]) == false)
			   Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(explosionSetFour[%d]): %d", j, explosionIdFour[j]);
   }

   for (U32 k = 0; k < NumFX; k++)
   {
	   if (!explosionSetFive[k] && explosionIdFive[k] != 0)
		   if (Sim::findObject(explosionIdFive[k], explosionSetFive[k]) == false)
			   Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(explosionSetFive[%d]): %d", k, explosionIdFive[k]);
   }

   for (U32 l = 0; l < NumFX; l++)
   {
	   if (!explosionSetSix[l] && explosionIdSix[l] != 0)
		   if (Sim::findObject(explosionIdSix[l], explosionSetSix[l]) == false)
			   Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(explosionSetSix[%d]): %d", l, explosionIdSix[l]);
   }

   for (U32 m = 0; m < NumFX; m++)
   {
	   if (!bloodSplatter[m] && bloodSplatterId[m] != 0)
		   if (Sim::findObject(bloodSplatterId[m], bloodSplatter[m]) == false)
			   Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(bloodSplatter[%d]): %d", m, bloodSplatterId[m]);
   }


   if (!particleEmitter && particleEmitterId != 0)
      if (Sim::findObject(particleEmitterId, particleEmitter) == false)
         Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(particleEmitter): %d", particleEmitterId);

   if (!particleWaterEmitter && particleWaterEmitterId != 0)
      if (Sim::findObject(particleWaterEmitterId, particleWaterEmitter) == false)
         Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(particleWaterEmitter): %d", particleWaterEmitterId);

   if (!bloodExplosion && bloodExplosionId != 0)
      if (Sim::findObject(bloodExplosionId, bloodExplosion) == false)
         Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(bloodExplosion): %d", bloodExplosionId);

   if (!waterExplosion && waterExplosionId != 0)
      if (Sim::findObject(waterExplosionId, waterExplosion) == false)
         Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(waterExplosion): %d", waterExplosionId);

   if (!splash && splashId != 0)
      if (Sim::findObject(splashId, splash) == false)
         Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockId(splash): %d", splashId);

   if (!sound && soundId != 0)
      if (Sim::findObject(soundId, sound) == false)
         Con::errorf(ConsoleLogEntry::General, "ProjectileData::onAdd: Invalid packet, bad datablockid(sound): %d", soundId);

   lightColor.clamp();

   return true;
}


bool ProjectileData::preload(bool server, String &errorStr)
{
   if (Parent::preload(server, errorStr) == false)
      return false;

   if (projectileShapeName && projectileShapeName[0] != '\0')
   {
      projectileShape = ResourceManager::get().load(projectileShapeName);
      if (bool(projectileShape) == false)
      {
         errorStr = String::ToString("ProjectileData::load: Couldn't load shape \"%s\"", projectileShapeName);
         return false;
      }
      activateSeq = projectileShape->findSequence("activate");
      maintainSeq = projectileShape->findSequence("maintain");
   }

   if (bool(projectileShape)) // create an instance to preload shape data
   {
      TSShapeInstance* pDummy = new TSShapeInstance(projectileShape, !server);
      delete pDummy;
   }

   return true;
}

//--------------------------------------------------------------------------
void ProjectileData::packData(BitStream* stream)
{
   Parent::packData(stream);

   stream->writeString(projectileShapeName);
   stream->writeFlag(faceViewer);
   if(stream->writeFlag(scale.x != 1 || scale.y != 1 || scale.z != 1))
   {
      stream->write(scale.x);
      stream->write(scale.y);
      stream->write(scale.z);
   }
   
   stream->write(mPierceWidth); //RJN
   stream->write(mPlayerRearScanDist); //RJN

   if (stream->writeFlag(particleEmitter != NULL))
      stream->writeRangedU32(particleEmitter->getId(), DataBlockObjectIdFirst,
                                                   DataBlockObjectIdLast);

   if (stream->writeFlag(particleWaterEmitter != NULL))
      stream->writeRangedU32(particleWaterEmitter->getId(), DataBlockObjectIdFirst,
                                                   DataBlockObjectIdLast);
   if (stream->writeFlag(bloodExplosion != NULL))
      stream->writeRangedU32(bloodExplosion->getId(), DataBlockObjectIdFirst,
                                                 DataBlockObjectIdLast);

   if (stream->writeFlag(waterExplosion != NULL))
      stream->writeRangedU32(waterExplosion->getId(), DataBlockObjectIdFirst,
                                                      DataBlockObjectIdLast);

   if (stream->writeFlag(splash != NULL))
      stream->writeRangedU32(splash->getId(), DataBlockObjectIdFirst,
                                              DataBlockObjectIdLast);

   if (stream->writeFlag(sound != NULL))
      stream->writeRangedU32(sound->getId(), DataBlockObjectIdFirst,
                                             DataBlockObjectIdLast);

   for (U32 a = 0; a < NumFX; a++)
      if (stream->writeFlag(decalSetOne[a] != NULL))
         stream->writeRangedU32(decalSetOne[a]->getId(), DataBlockObjectIdFirst,
                                                 DataBlockObjectIdLast);

   for (U32 b = 0; b < NumFX; b++)
      if (stream->writeFlag(decalSetTwo[b] != NULL))
         stream->writeRangedU32(decalSetTwo[b]->getId(), DataBlockObjectIdFirst,
                                                 DataBlockObjectIdLast);

   for (U32 c = 0; c < NumFX; c++)
      if (stream->writeFlag(decalSetThree[c] != NULL))
         stream->writeRangedU32(decalSetThree[c]->getId(), DataBlockObjectIdFirst,
                                                 DataBlockObjectIdLast);

   for (U32 d = 0; d < NumFX; d++)
      if (stream->writeFlag(decalSetFour[d] != NULL))
         stream->writeRangedU32(decalSetFour[d]->getId(), DataBlockObjectIdFirst,
                                                 DataBlockObjectIdLast);

   for (U32 e = 0; e < NumFX; e++)
      if (stream->writeFlag(decalSetFive[e] != NULL))
         stream->writeRangedU32(decalSetFive[e]->getId(), DataBlockObjectIdFirst,
                                                 DataBlockObjectIdLast);

   for (U32 f = 0; f < NumFX; f++)
      if (stream->writeFlag(decalSetSix[f] != NULL))
         stream->writeRangedU32(decalSetSix[f]->getId(), DataBlockObjectIdFirst,
                                                 DataBlockObjectIdLast);

   for (U32 g = 0; g < NumFX; g++)
      if (stream->writeFlag(explosionSetOne[g] != NULL))
         stream->writeRangedU32(explosionSetOne[g]->getId(), DataBlockObjectIdFirst,
                                                 DataBlockObjectIdLast);

   for (U32 h = 0; h < NumFX; h++)
      if (stream->writeFlag(explosionSetTwo[h] != NULL))
         stream->writeRangedU32(explosionSetTwo[h]->getId(), DataBlockObjectIdFirst,
                                                 DataBlockObjectIdLast);

   for (U32 i = 0; i < NumFX; i++)
      if (stream->writeFlag(explosionSetThree[i] != NULL))
         stream->writeRangedU32(explosionSetThree[i]->getId(), DataBlockObjectIdFirst,
                                                 DataBlockObjectIdLast);

   for (U32 j = 0; j < NumFX; j++)
      if (stream->writeFlag(explosionSetFour[j] != NULL))
         stream->writeRangedU32(explosionSetFour[j]->getId(), DataBlockObjectIdFirst,
                                                 DataBlockObjectIdLast);

   for (U32 k = 0; k < NumFX; k++)
      if (stream->writeFlag(explosionSetFive[k] != NULL))
         stream->writeRangedU32(explosionSetFive[k]->getId(), DataBlockObjectIdFirst,
                                                 DataBlockObjectIdLast);

   for (U32 l = 0; l < NumFX; l++)
      if (stream->writeFlag(explosionSetSix[l] != NULL))
         stream->writeRangedU32(explosionSetSix[l]->getId(), DataBlockObjectIdFirst,
                                                 DataBlockObjectIdLast);

   for (U32 m = 0; m < NumFX; m++)
      if (stream->writeFlag(bloodSplatter[m] != NULL))
         stream->writeRangedU32(bloodSplatter[m]->getId(), DataBlockObjectIdFirst,
                                                 DataBlockObjectIdLast);

   if(stream->writeFlag(hasLight))
   {
      stream->writeFloat(lightRadius/20.0, 8);
      stream->writeFloat(lightColor.red,7);
      stream->writeFloat(lightColor.green,7);
      stream->writeFloat(lightColor.blue,7);
   }

   stream->write(lifetime);
   stream->write(explodetime);
   stream->write(armingDelay);
   stream->write(fadeDelay);

   if(stream->writeFlag(isBallistic))
   {
      stream->write(gravityMod);
	  stream->write(ballisticCoefficient);
      stream->write(bounceElasticity);
      stream->write(bounceFriction);
   }

   //Guided or Seeker Projectiles
   if(stream->writeFlag(isGuided))
   {
	   stream->writeFlag(isHeatSeeker);
	   stream->write(sweepRadius);
	   stream->write(precision);
	   stream->write(trackDelay); 
   }
   
   //Terrain Following
   if(stream->writeFlag(isTerrainFollowing))
   {
	   stream->write(minTerrainHeight);
	   stream->write(maxTerrainHeight);
	   stream->write(speedTerrainFollowing);
   }
   
   //Sidewinder stuff
   if(stream->writeFlag(isSidewinder))
   {
	   stream->write(crazyness);
	   stream->write(sideDelay);
   }

   //Water explosion and stopping
   stream->writeFlag(explodeOnWater);
   stream->writeFlag(stoppedByWater);  

   if (stream->writeFlag(useWind))
	   stream->write(windEffect);

  // Explode on explodetime - T_F -Cozz
  stream->writeFlag(explodeOnExplodeTime);
}

void ProjectileData::unpackData(BitStream* stream)
{
   Parent::unpackData(stream);

   projectileShapeName = stream->readSTString();

   faceViewer = stream->readFlag();
   if(stream->readFlag())
   {
      stream->read(&scale.x);
      stream->read(&scale.y);
      stream->read(&scale.z);
   }
   else
      scale.set(1,1,1);
   
   stream->read(&mPierceWidth); //RJN
   stream->read(&mPlayerRearScanDist); //RJN

   if (stream->readFlag())
      particleEmitterId = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   if (stream->readFlag())
      particleWaterEmitterId = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   if (stream->readFlag())
      bloodExplosionId = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   if (stream->readFlag())
      waterExplosionId = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);
   
   if (stream->readFlag())
      splashId = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);
   
   if (stream->readFlag())
      soundId = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   for (U32 a = 0; a < NumFX; a++)
      if (stream->readFlag())
         decalIdOne[a] = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   for (U32 b = 0; b < NumFX; b++)
      if (stream->readFlag())
         decalIdTwo[b] = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   for (U32 c = 0; c < NumFX; c++)
      if (stream->readFlag())
         decalIdThree[c] = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   for (U32 d = 0; d < NumFX; d++)
      if (stream->readFlag())
         decalIdFour[d] = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   for (U32 e = 0; e < NumFX; e++)
      if (stream->readFlag())
         decalIdFive[e] = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   for (U32 f = 0; f < NumFX; f++)
      if (stream->readFlag())
         decalIdSix[f] = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   for (U32 g = 0; g < NumFX; g++)
      if (stream->readFlag())
         explosionIdOne[g] = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   for (U32 h = 0; h < NumFX; h++)
      if (stream->readFlag())
         explosionIdTwo[h] = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   for (U32 i = 0; i < NumFX; i++)
      if (stream->readFlag())
         explosionIdThree[i] = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   for (U32 j = 0; j < NumFX; j++)
      if (stream->readFlag())
         explosionIdFour[j] = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   for (U32 k = 0; k < NumFX; k++)
      if (stream->readFlag())
         explosionIdFive[k] = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   for (U32 l = 0; l < NumFX; l++)
      if (stream->readFlag())
         explosionIdSix[l] = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   for (U32 m = 0; m < NumFX; m++)
      if (stream->readFlag())
         bloodSplatterId[m] = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);

   hasLight = stream->readFlag();
   if(hasLight)
   {
      lightRadius = stream->readFloat(8) * 20;
      lightColor.red = stream->readFloat(7);
      lightColor.green = stream->readFloat(7);
      lightColor.blue = stream->readFloat(7);
   }

   stream->read(&lifetime);
   stream->read(&explodetime);
   stream->read(&armingDelay);
   stream->read(&fadeDelay);

   isBallistic = stream->readFlag();
   if(isBallistic)
   {
      stream->read(&gravityMod);
	  stream->read(&ballisticCoefficient);
      stream->read(&bounceElasticity);
      stream->read(&bounceFriction);
   }

   //Guided or Seeker Projectiles
   isGuided = stream->readFlag(); 
   if(isGuided)
   {
	   isHeatSeeker = stream->readFlag();
	   stream->read(&sweepRadius);
	   stream->read(&precision);
	   stream->read(&trackDelay);
   }
   
   //Terrain Following
   isTerrainFollowing = stream->readFlag();
   if(isTerrainFollowing)
   {
	   stream->read(&minTerrainHeight);
	   stream->read(&maxTerrainHeight);
	   stream->read(&speedTerrainFollowing);
   }
   
   //Sidewinder Stuff
   isSidewinder = stream->readFlag();
   if(isSidewinder)
   {
	   stream->read(&crazyness);
	   stream->read(&sideDelay);
   }


   //Water explosion and stopping
   explodeOnWater = stream->readFlag();
   stoppedByWater = stream->readFlag();

   useWind = stream->readFlag();
   if (useWind)
	   stream->read(&windEffect);

  // Explode on explodetime expiration - T_F -Cozz
  explodeOnExplodeTime = stream->readFlag();
}


//--------------------------------------------------------------------------
//--------------------------------------
//
Projectile::Projectile()
{
   // Todo: ScopeAlways?
   mNetFlags.set(Ghostable);
   mTypeMask |= ProjectileObjectType;

   mCurrPosition.set(0, 0, 0);
   mInitialPosition.set(0, 0, 0);
   mCurrVelocity.set(0, 0, 1);

   mSourceObjectId = -1;
   mSourceObjectSlot = -1;

   mCurrTick         = 0;

   mParticleEmitter   = NULL;
   mParticleWaterEmitter = NULL;

   mSound = NULL;

   mProjectileShape   = NULL;
   mActivateThread    = NULL;
   mMaintainThread    = NULL;

   //Guided or Seeker Projectiles
   mTarget = NULL;
   mTargetId = -1;

   mCollideHitType   = 0;

   mHidden           = false;
   mFadeValue        = 1.0;

   mLight = gClientSceneGraph->getLightManager()->createLightInfo();
   
   pMatType          = 0;
   mBloodRearPosition.set(0, 0, 0);
   mBloodObjPosition.set(0, 0, 0);
   mBloodVelocity.set(0, 0, 0);
   armorPiercing = false;
   mWrappedDecals = false;
   mControlClient = 0;
   
   addPierce = false;
   mPiercePoint.set(0.0f,0.0f,0.0f);;
   mPierceNormal.set(0.0f,0.0f,0.0f);;
   mPierceINormal.set(0.0f,0.0f,0.0f);;

   useDecal = false;
   transDecal = false;
   transObjectId = -1;
   transObject = NULL;
}

Projectile::~Projectile()
{
   SAFE_DELETE(mLight);
   delete mProjectileShape;
   mProjectileShape = NULL;
}

//--------------------------------------------------------------------------
void Projectile::initPersistFields()
{
   Parent::initPersistFields();

   addGroup("Physics");
   addField("initialPosition",  TypePoint3F, Offset(mInitialPosition, Projectile));
   addField("initialVelocity", TypePoint3F, Offset(mCurrVelocity, Projectile));
   addField("bloodRearPosition",  TypePoint3F, Offset(mBloodRearPosition, Projectile));
   addField("bloodObjPosition",  TypePoint3F, Offset(mBloodObjPosition, Projectile));
   addField("bloodVelocity", TypePoint3F, Offset(mBloodVelocity, Projectile));
   endGroup("Physics");

   addGroup("Source");
   addField("sourceObject",     TypeS32,     Offset(mSourceObjectId, Projectile));
   addField("sourceSlot",       TypeS32,     Offset(mSourceObjectSlot, Projectile));
   endGroup("Source");

   addGroup("Flags");
   addField("isArmorPiercing",     TypeBool,     Offset(armorPiercing, Projectile));
   addField("wrappedDecalsMode",     TypeBool,     Offset(mWrappedDecals, Projectile));
   endGroup("Flags");

   addGroup("ControlClient");
   addField("client",     TypeS32,     Offset(mControlClient, Projectile));
   endGroup("ControlClient");

   //Guided or Seeker Projectiles
   addField("target",            TypeS32,        Offset(mTargetId, Projectile));
}

bool Projectile::calculateImpact(float,
                                 Point3F& pointOfImpact,
                                 float&   impactTime)
{
   Con::warnf(ConsoleLogEntry::General, "Projectile::calculateImpact: Should never be called");

   impactTime = 0;
   pointOfImpact.set(0, 0, 0);
   return false;
}


//--------------------------------------------------------------------------
F32 Projectile::getUpdatePriority(CameraScopeQuery *camInfo, U32 updateMask, S32 updateSkips)
{
   F32 ret = Parent::getUpdatePriority(camInfo, updateMask, updateSkips);
   // if the camera "owns" this object, it should have a slightly higher priority
   if(mSourceObject == camInfo->camera)
      return ret + 0.2;
   return ret;
}

bool Projectile::onAdd()
{
   if(!Parent::onAdd())
      return false;

   if (isServerObject())
   {
      mCurrPosition = mInitialPosition;   
      ShapeBase* ptr;
      if (Sim::findObject(mSourceObjectId, ptr))
         mSourceObject = ptr;
      else
      {
         if (mSourceObjectId != -1)
            Con::errorf(ConsoleLogEntry::General, "Projectile::onAdd: mSourceObjectId is invalid");
         mSourceObject = NULL;
      }

	  ShapeBase* tptr; 
	  mTarget = NULL;
	  if(mTargetId != -1)
		  if(Sim::findObject(mTargetId, tptr)) 
			  mTarget = tptr;

      // If we're on the server, we need to inherit some of our parent's velocity
      //
      mCurrTick = 0;
   }
   else
   {
      if (bool(mDataBlock->projectileShape))
      {
         mProjectileShape = new TSShapeInstance(mDataBlock->projectileShape, isClientObject());

         if (mDataBlock->activateSeq != -1)
         {
            mActivateThread = mProjectileShape->addThread();
            mProjectileShape->setTimeScale(mActivateThread, 1);
            mProjectileShape->setSequence(mActivateThread, mDataBlock->activateSeq, 0);
         }
      }
      if (mDataBlock->particleEmitter != NULL)
      {
         ParticleEmitter* pEmitter = new ParticleEmitter;
         pEmitter->onNewDataBlock(mDataBlock->particleEmitter);
         if (pEmitter->registerObject() == false)
         {
            Con::warnf(ConsoleLogEntry::General, "Could not register particle emitter for particle of class: %s", mDataBlock->getName());
            delete pEmitter;
            pEmitter = NULL;
         }
         mParticleEmitter = pEmitter;
      }

      if (mDataBlock->particleWaterEmitter != NULL)
      {
         ParticleEmitter* pEmitter = new ParticleEmitter;
         pEmitter->onNewDataBlock(mDataBlock->particleWaterEmitter);
         if (pEmitter->registerObject() == false)
         {
            Con::warnf(ConsoleLogEntry::General, "Could not register particle emitter for particle of class: %s", mDataBlock->getName());
            delete pEmitter;
            pEmitter = NULL;
         }
         mParticleWaterEmitter = pEmitter;
      }

      if (mDataBlock->hasLight == true)
         Sim::getLightSet()->addObject(this);
   }
   if (bool(mSourceObject))
      processAfter(mSourceObject);

   // Setup our bounding box
   if (bool(mDataBlock->projectileShape) == true)
      mObjBox = mDataBlock->projectileShape->bounds;
   else
      mObjBox = Box3F(Point3F(0, 0, 0), Point3F(0, 0, 0));
   resetWorldBox();
   addToScene();

   return true;
}


void Projectile::onRemove()
{
   if( !mParticleEmitter.isNull() )
   {
      mParticleEmitter->deleteWhenEmpty();
      mParticleEmitter = NULL;
   }

   if( !mParticleWaterEmitter.isNull() )
   {
      mParticleWaterEmitter->deleteWhenEmpty();
      mParticleWaterEmitter = NULL;
   }

   SFX_DELETE( mSound );

   removeFromScene();
   Parent::onRemove();
}


bool Projectile::onNewDataBlock(GameBaseData* dptr)
{
   mDataBlock = dynamic_cast<ProjectileData*>(dptr);
   if (!mDataBlock || !Parent::onNewDataBlock(dptr))
      return false;

   if ( isGhost() )
   {
      // Create the sound ahead of time.  This reduces runtime
      // costs and makes the system easier to understand.

      SFX_DELETE( mSound );

      if ( mDataBlock->sound )
         mSound = SFX->createSource( mDataBlock->sound );
   }

   return true;
}


//--------------------------------------------------------------------------


void Projectile::registerLights(LightManager * lightManager, bool lightingScene)
{
   if(lightingScene)
      return;

   if (mDataBlock->hasLight && mHidden == false)
   {
      mLight->mType = LightInfo::Point;
      getRenderTransform().getColumn(3, &mLight->mPos);
      mLight->mRadius = mDataBlock->lightRadius;
      mLight->mColor  = mDataBlock->lightColor;
      lightManager->registerGlobalLight(mLight, this, false);
   }
}

//----------------------------------------------------------------------------
void Projectile::waterSurfaceExplosionCheck(const Point3F& from, const Point3F& to)
{
    bool fromWater = pointInWater(from);
   bool toWater   = pointInWater(to);

   if (!fromWater && toWater)     // entering water
   {
      // cast the ray to get the surface point of the water
      RayInfo rInfo;
      if (gClientContainer.castRay(from, to, WaterObjectType, &rInfo))
      {
		  if(isClientObject())
		  {
			  Explosion* pExplosion;
			  pExplosion = new Explosion;
			  pExplosion->onNewDataBlock(mDataBlock->waterExplosion);
			  pExplosion->mControlClient = mControlClient;
			  
			  MatrixF xform(true);
			  xform.setPosition(rInfo.point);
			  pExplosion->setTransform(xform);
			  pExplosion->setInitialState(rInfo.point, rInfo.normal);
			  pExplosion->setCollideType( WaterObjectType );
			  if (pExplosion->registerObject() == false)
			  {
				  Con::errorf(ConsoleLogEntry::General, "Projectile(%s)::explode: couldn't register explosion", mDataBlock->getName() );
				  delete pExplosion;
				  pExplosion = NULL;
			  }
		  }
		  else
			  onCollision(rInfo.point, rInfo.normal, NULL);
      }
   }
}

//----------------------------------------------------------------------------

bool Projectile::pointInWater(const Point3F &point)
{
   SimpleQueryList sql;
   if (isServerObject())
      gServerSceneGraph->getWaterObjectList(sql);
   else
      gClientSceneGraph->getWaterObjectList(sql);

   for (U32 i = 0; i < sql.mList.size(); i++)
   {
      WaterBlock* pBlock = dynamic_cast<WaterBlock*>(sql.mList[i]);

      if (pBlock)// && pBlock->getLiquidType() == WaterBlock::eWater )
      {
         if (pBlock->isUnderwater( point ))
            return true;
      }

   }

   return false;
}

//----------------------------------------------------------------------------

void Projectile::emitParticles(const Point3F& from, const Point3F& to, const Point3F& vel, const U32 ms)
{
   if( mHidden )
      return;

   Point3F axis = -vel;

   if( axis.isZero() )
      axis.set( 0.0, 0.0, 1.0 );
   else
      axis.normalize();

   bool fromWater = pointInWater(from);
   bool toWater   = pointInWater(to);

   if (!fromWater && !toWater && bool(mParticleEmitter))                                        // not in water
      mParticleEmitter->emitParticles(from, to, axis, vel, ms);
   else if (fromWater && toWater && bool(mParticleWaterEmitter))                                // in water
      mParticleWaterEmitter->emitParticles(from, to, axis, vel, ms);
   else if (!fromWater && toWater && mDataBlock->splash)     // entering water
   {
      // cast the ray to get the surface point of the water
      RayInfo rInfo;
      if (gClientContainer.castRay(from, to, WaterObjectType, &rInfo))
      {
         MatrixF trans = getTransform();
         trans.setPosition(rInfo.point);

         Splash *splash = new Splash();
         splash->onNewDataBlock(mDataBlock->splash);
         splash->setTransform(trans);
         splash->setInitialState(trans.getPosition(), Point3F(0.0, 0.0, 1.0));
         if (!splash->registerObject())
         {
            delete splash;
            splash = NULL;
         }

         // create an emitter for the particles out of water and the particles in water
         if (mParticleEmitter)
            mParticleEmitter->emitParticles(from, rInfo.point, axis, vel, ms);

         if (mParticleWaterEmitter)
            mParticleWaterEmitter->emitParticles(rInfo.point, to, axis, vel, ms);
      }
   }
   else if (fromWater && !toWater && mDataBlock->splash)     // leaving water
   {
      // cast the ray in the opposite direction since that point is out of the water, otherwise
      //  we hit water immediately and wont get the appropriate surface point
      RayInfo rInfo;
      if (gClientContainer.castRay(to, from, WaterObjectType, &rInfo))
      {
         MatrixF trans = getTransform();
         trans.setPosition(rInfo.point);

         Splash *splash = new Splash();
         splash->onNewDataBlock(mDataBlock->splash);
         splash->setTransform(trans);
         splash->setInitialState(trans.getPosition(), Point3F(0.0, 0.0, 1.0));
         if (!splash->registerObject())
         {
            delete splash;
            splash = NULL;
         }

         // create an emitter for the particles out of water and the particles in water
         if (mParticleEmitter)
            mParticleEmitter->emitParticles(rInfo.point, to, axis, vel, ms);

         if (mParticleWaterEmitter)
            mParticleWaterEmitter->emitParticles(from, rInfo.point, axis, vel, ms);
      }
   }
}


//----------------------------------------------------------------------------

class ObjectDeleteEvent : public SimEvent
{
public:
   void process(SimObject *object)
   {
      object->deleteObject();
   }
};

void Projectile::explode(const Point3F& p, const Point3F& n, const Point3F &impactNormal, const U32 collideType, U32 pMatType, bool transDec, SceneObject* transObj )
{
   // Make sure we don't explode twice...
   if (mHidden == true)
      return;

   mHidden = true;

   // drm - improved decals
   mImpactNormal = impactNormal;

   bool goreMode = Con::getBoolVariable("$pref::Player::GoreOn");

   if (isServerObject()) {
      // Do what the server needs to do, damage the surrounding objects, etc.
      mExplosionPosition = p + (n*0.01f);
      mExplosionNormal = n;
      mCollideHitType  = collideType;
	  transDecal = transDec;
	  transObject = transObj;
	  pMatType = pMatType;
	  mImpactNormal = impactNormal;

      char buffer[128];
      dSprintf(buffer, sizeof(buffer),  "%g %g %g", mExplosionPosition.x,
                                                    mExplosionPosition.y,
                                                    mExplosionPosition.z);
      Con::executef(mDataBlock, "onExplode", scriptThis(), buffer, Con::getFloatArg(mFadeValue));

      setMaskBits(ExplosionMask);
		Sim::postEvent(this, new ObjectDeleteEvent, Sim::getCurrentTime() + DeleteWaitTime);
   } else 
   {
      if(pMatType == 6)
         return;
      // Client just plays the explosion at the right place...
      //
      Explosion* pExplosion = NULL;
	  
      if (mDataBlock->waterExplosion && collideType & U32(WaterObjectType))
      {
         pExplosion = new Explosion;
         pExplosion->onNewDataBlock(mDataBlock->waterExplosion);
		 
		 if( pExplosion )
		 {
			 MatrixF xform(true);
			 xform.setPosition(p);
			 pExplosion->setTransform(xform);
			 pExplosion->setInitialState(p, n);
			 pExplosion->setCollideType( collideType );
			 if (pExplosion->registerObject() == false)
			 {
				 Con::errorf(ConsoleLogEntry::General, "Projectile(%s)::explode: couldn't register explosion",
					 mDataBlock->getName() );
				 delete pExplosion;
				 pExplosion = NULL;
			 }
		 }
	  }
	  else if(collideType & (PlayerObjectType))
	  {
		  if(goreMode)
		  {
			  pExplosion = new Explosion;
			  pExplosion->onNewDataBlock(mDataBlock->bloodExplosion);
			  
			  MatrixF xform(true);
			  xform.setPosition(p);
			  pExplosion->setTransform(xform);
			  pExplosion->setInitialState(p, n);
			  pExplosion->setCollideType( collideType );
			  pExplosion->mControlClient = mControlClient;
			  if (pExplosion->registerObject() == false)
			  {
				  Con::errorf(ConsoleLogEntry::General, "Projectile(%s)::explode: couldn't register explosion", mDataBlock->getName() );
				  delete pExplosion;
				  pExplosion = NULL;
			  }
		  }
	  }
	  else 
	  {
		  DecalManager *decalMngr = gClientSceneGraph->getCurrentDecalManager();
		  U32 idx = (U32)(mCeil(mDataBlock->NumFX * Platform::getRandom()) - 1.0f);
		  if(pMatType == 0)
		  {
			  pExplosion = new Explosion;
			  pExplosion->onNewDataBlock(mDataBlock->explosionSetOne[idx]);
			  
			  MatrixF xform(true);
			  xform.setPosition(p);
			  pExplosion->setTransform(xform);
			  pExplosion->setInitialState(p, n);
			  pExplosion->setCollideType( collideType );
			  pExplosion->mControlClient = mControlClient;
			  if (pExplosion->registerObject() == false)
			  {
				  Con::errorf(ConsoleLogEntry::General, "Projectile(%s)::explode: couldn't register explosion", mDataBlock->getName() );
				  delete pExplosion;
				  pExplosion = NULL;
			  }
			  
			  if(mDataBlock->decalSetOne[idx] != NULL)
			  {
				  if(useDecal)
				  {
					  if(transDec)
					  {
						  if(mWrappedDecals)
							  decalMngr->addObjectWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetOne[idx], transObj);
						  else
							  decalMngr->addObjectDecal(p, n, mDataBlock->decalSetOne[idx], transObj);
					  }
					  else
					  {
						  if(mWrappedDecals)
							  decalMngr->addWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetOne[idx]);
						  else
							  decalMngr->addDecal(p, n, mDataBlock->decalSetOne[idx]);
					  }
				  }
			  }
		  }
		  else if(pMatType == 1)
		  {
			  pExplosion = new Explosion;
			  pExplosion->onNewDataBlock(mDataBlock->explosionSetTwo[idx]);
			  
			  MatrixF xform(true);
			  xform.setPosition(p);
			  pExplosion->setTransform(xform);
			  pExplosion->setInitialState(p, n);
			  pExplosion->setCollideType( collideType );
			  pExplosion->mControlClient = mControlClient;
			  if (pExplosion->registerObject() == false)
			  {
				  Con::errorf(ConsoleLogEntry::General, "Projectile(%s)::explode: couldn't register explosion", mDataBlock->getName() );
				  delete pExplosion;
				  pExplosion = NULL;
			  }
			  
			  if(mDataBlock->decalSetTwo[idx] != NULL)
			  {
				  if(useDecal)
				  {
					  if(transDec)
					  {
						  if(mWrappedDecals)
							  decalMngr->addObjectWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetTwo[idx], transObj);
						  else
							  decalMngr->addObjectDecal(p, n, mDataBlock->decalSetTwo[idx], transObj);
					  }
					  else
					  {
						  if(mWrappedDecals)
							  decalMngr->addWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetTwo[idx]);
						  else
							  decalMngr->addDecal(p, n, mDataBlock->decalSetTwo[idx]);
					  }
				  }
			  }
		  }
		  else if(pMatType == 2)
		  {
			  pExplosion = new Explosion;
			  pExplosion->onNewDataBlock(mDataBlock->explosionSetThree[idx]);
			  
			  MatrixF xform(true);
			  xform.setPosition(p);
			  pExplosion->setTransform(xform);
			  pExplosion->setInitialState(p, n);
			  pExplosion->setCollideType( collideType );
			  pExplosion->mControlClient = mControlClient;
			  if (pExplosion->registerObject() == false)
			  {
				  Con::errorf(ConsoleLogEntry::General, "Projectile(%s)::explode: couldn't register explosion", mDataBlock->getName() );
				  delete pExplosion;
				  pExplosion = NULL;
			  }
			  
			  if(mDataBlock->decalSetThree[idx] != NULL)
			  {
				  if(useDecal)
				  {
					  if(transDec)
					  {
						  if(mWrappedDecals)
							  decalMngr->addObjectWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetThree[idx], transObj);
						  else
							  decalMngr->addObjectDecal(p, n, mDataBlock->decalSetThree[idx], transObj);
					  }
					  else
					  {
						  if(mWrappedDecals)
							  decalMngr->addWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetThree[idx]);
						  else
							  decalMngr->addDecal(p, n, mDataBlock->decalSetThree[idx]);
					  }
				  }
			  }
		  }
		  else if(pMatType == 3)
		  {
			  pExplosion = new Explosion;
			  pExplosion->onNewDataBlock(mDataBlock->explosionSetFour[idx]);
			  
			  MatrixF xform(true);
			  xform.setPosition(p);
			  pExplosion->setTransform(xform);
			  pExplosion->setInitialState(p, n);
			  pExplosion->setCollideType( collideType );
			  pExplosion->mControlClient = mControlClient;
			  if (pExplosion->registerObject() == false)
			  {
				  Con::errorf(ConsoleLogEntry::General, "Projectile(%s)::explode: couldn't register explosion", mDataBlock->getName() );
				  delete pExplosion;
				  pExplosion = NULL;
			  }
			  
			  if(mDataBlock->decalSetFour[idx] != NULL)
			  {
				  if(useDecal)
				  {
					  if(transDec)
					  {
						  if(mWrappedDecals)
							  decalMngr->addObjectWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetFour[idx], transObj);
						  else
							  decalMngr->addObjectDecal(p, n, mDataBlock->decalSetFour[idx], transObj);
					  }
					  else
					  {
						  if(mWrappedDecals)
							  decalMngr->addWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetFour[idx]);
						  else
							  decalMngr->addDecal(p, n, mDataBlock->decalSetFour[idx]);
					  }
				  }
			  }
		  }
		  else if(pMatType == 4)
		  {
			  pExplosion = new Explosion;
			  pExplosion->onNewDataBlock(mDataBlock->explosionSetFive[idx]);
			  
			  MatrixF xform(true);
			  xform.setPosition(p);
			  pExplosion->setTransform(xform);
			  pExplosion->setInitialState(p, n);
			  pExplosion->setCollideType( collideType );
			  pExplosion->mControlClient = mControlClient;
			  if (pExplosion->registerObject() == false)
			  {
				  Con::errorf(ConsoleLogEntry::General, "Projectile(%s)::explode: couldn't register explosion", mDataBlock->getName() );
				  delete pExplosion;
				  pExplosion = NULL;
			  }
			  
			  if(mDataBlock->decalSetFive[idx] != NULL)
			  {
				  if(useDecal)
				  {
					  if(transDec)
					  {
						  if(mWrappedDecals)
							  decalMngr->addObjectWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetFive[idx], transObj);
						  else
							  decalMngr->addObjectDecal(p, n, mDataBlock->decalSetFive[idx], transObj);
					  }
					  else
					  {
						  if(mWrappedDecals)
							  decalMngr->addWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetFive[idx]);
						  else
							  decalMngr->addDecal(p, n, mDataBlock->decalSetFive[idx]);
					  }
				  }
			  }
		  }
		  else if(pMatType == 5)
		  {
			  pExplosion = new Explosion;
			  pExplosion->onNewDataBlock(mDataBlock->explosionSetSix[idx]);
			  
			  MatrixF xform(true);
			  xform.setPosition(p);
			  pExplosion->setTransform(xform);
			  pExplosion->setInitialState(p, n);
			  pExplosion->setCollideType( collideType );
			  pExplosion->mControlClient = mControlClient;
			  if (pExplosion->registerObject() == false)
			  {
				  Con::errorf(ConsoleLogEntry::General, "Projectile(%s)::explode: couldn't register explosion", mDataBlock->getName() );
				  delete pExplosion;
				  pExplosion = NULL;
			  }
			  
			  if(mDataBlock->decalSetSix[idx] != NULL)
			  {
				  if(useDecal)
				  {
					  if(transDec)
					  {
						  if(mWrappedDecals)
							  decalMngr->addObjectWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetSix[idx], transObj);
						  else
							  decalMngr->addObjectDecal(p, n, mDataBlock->decalSetSix[idx], transObj);
					  }
					  else
					  {
						  if(mWrappedDecals)
							  decalMngr->addWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetSix[idx]);
						  else
							  decalMngr->addDecal(p, n, mDataBlock->decalSetSix[idx]);
					  }
				  }
			  }
		  }
	  }

      // Client object
      updateSound();
   }
}

//I realize this seems like a ton of extra code, but it is actually the only reliable method I could do since the explosion code is was clears the projectile from
//the scene.
void Projectile::addPierceDecal(const Point3F& p, const Point3F& n, const Point3F &impactNormal, const U32 collideType, U32 pMatType )
{
   if (isServerObject()) 
   {
	   mPiercePoint = p;
	   mPierceNormal = n;
	   mPierceINormal = impactNormal;
	   mCollideHitType  = collideType;
	   pMatType = pMatType;

	   addPierce = true;
   }
   else
   {
      if(pMatType == 6)
         return;

	   U32 idx = (U32)(mCeil(mDataBlock->NumFX * Platform::getRandom()) - 1.0f);
	   DecalManager *decalMngr = gClientSceneGraph->getCurrentDecalManager();
	   if(decalMngr)
	   {
		   if(collideType & (PlayerObjectType))
		   {
			   if(mDataBlock->bloodSplatter[idx] != NULL)
			   {
				   if(mWrappedDecals)
					   decalMngr->addWrapDecal(p, n, mImpactNormal, mDataBlock->bloodSplatter[idx]);
				   else
					   decalMngr->addDecal(p, n, mDataBlock->bloodSplatter[idx]);
			   }
		   }
		   else
		   {
			   if(pMatType == 0)
			   {
				   if(mDataBlock->decalSetOne[idx] != NULL)
				   {
					   if(mWrappedDecals)
						   decalMngr->addWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetOne[idx]);
					   else
						   decalMngr->addDecal(p, n, mDataBlock->decalSetOne[idx]);
				   }
			   }
			   else if(pMatType == 1)
			   {
				   if(mDataBlock->decalSetTwo[idx] != NULL)
				   {
					   if(mWrappedDecals)
						   decalMngr->addWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetTwo[idx]);
					   else
						   decalMngr->addDecal(p, n, mDataBlock->decalSetTwo[idx]);
				   }
			   }
			   else if(pMatType == 2)
			   {
				   if(mDataBlock->decalSetThree[idx] != NULL)
				   {
					   if(mWrappedDecals)
						   decalMngr->addWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetThree[idx]);
					   else
						   decalMngr->addDecal(p, n, mDataBlock->decalSetThree[idx]);
				   }
			   }
			   else if(pMatType == 3)
			   {
				   if(mDataBlock->decalSetFour[idx] != NULL)
				   {
					   if(mWrappedDecals)
						   decalMngr->addWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetFour[idx]);
					   else
						   decalMngr->addDecal(p, n, mDataBlock->decalSetFour[idx]);
				   }
			   }
			   else if(pMatType == 4)
			   {
				   if(mDataBlock->decalSetFive[idx] != NULL)
				   {
					   if(mWrappedDecals)
						   decalMngr->addWrapDecal(p, n, mImpactNormal, mDataBlock->decalSetFive[idx]);
					   else
						   decalMngr->addDecal(p, n, mDataBlock->decalSetFive[idx]);
				   }
			   }
		   }
	   }
   }
}

void Projectile::updateSound()
{
   if (!mDataBlock->sound)
      return;

   if ( mHidden && mSound )
      mSound->stop();

   else if ( !mHidden && mSound )
   {
      if ( !mSound->isPlaying() )
         mSound->play();

      mSound->setVelocity( getVelocity() );
      mSound->setTransform( getRenderTransform() );
   }
}

Point3F Projectile::getVelocity() const
{
   return mCurrVelocity;
}

void Projectile::processTick(const Move* move)
{
   Parent::processTick(move);

   mCurrTick++;
   if(mSourceObject && mCurrTick > SourceIdTimeoutTicks)
   {
      mSourceObject = 0;
      mSourceObjectId = 0;
   }

   // See if we can get out of here the easy way ...
   if (isServerObject() && mCurrTick >= mDataBlock->lifetime)
   {
      deleteObject();
      return;
   }
   else if (mHidden == true)
      return;

   // ... otherwise, we have to do some simulation work.
   RayInfo rInfo;
   RayInfo pierceInfo;
   RayInfo playerRearInfo;
   TriRayInfo rTriInfo;

   Point3F oldPosition;
   Point3F newPosition;

   Point3F secPoint;
   Point3F secNormal;
   Point3F secImpactNormal;

   oldPosition = mCurrPosition;

   F32 dT = F32(TickMs) * 0.001f; // 1/1000.0 division avoidance
   newPosition = oldPosition + mCurrVelocity * dT;

   Point3F savedOldPosition = oldPosition;
   Point3F savedCurrVelocity = mCurrVelocity;
   
   // If CurrentTick > than explodetime && explodeInExplodeTime is true then blow it up -Cozz
   //------------------------------------------------------------------------------------------------------
   if(isServerObject() && mCurrTick >= mDataBlock->explodetime && mDataBlock->explodeOnExplodeTime == true)
   {
     onCollision(newPosition, Point3F(0.0, 0.0, 1.0), this);
     explode(newPosition, Point3F(0.0, 0.0, 1.0), Point3F(0.0, 0.0, 0.0),NULL, 0, false, NULL );
     return;
   }
   //------------------------------------------------------------------------------------------------------

   if(mDataBlock->explodeOnWater && !mDataBlock->stoppedByWater)
	   waterSurfaceExplosionCheck(oldPosition, newPosition);  
 
	//Guided or Seeker Projectiles
	if(mDataBlock->isGuided && !mDataBlock->isSidewinder) 
	{
		//Do a sweep for flares
		if(mDataBlock->isHeatSeeker)
		{
			GameBase * sweepTgt = NULL;
			Box3F queryBox(newPosition, Point3F(mDataBlock->sweepRadius,mDataBlock->sweepRadius,mDataBlock->sweepRadius));
			SimpleQueryList queryFlareList;
			
			getContainer()->findObjects(queryBox, GameBaseObjectType, SimpleQueryList::insertionCallback, &queryFlareList);
			
			for (U32 i = 0; i < queryFlareList.mList.size(); i++) 
			{
				sweepTgt = static_cast<GameBase*>(queryFlareList.mList[i]);
				if(sweepTgt)
					if(sweepTgt->heatSignature >= 2000.0f) //2000 deg F is the standard temperature of a countermeasures flare
						mTarget = sweepTgt;
			}
		}
		Vehicle* targetVehicle = static_cast<Vehicle*>(mTarget);
		if(targetVehicle && !mDataBlock->isHeatSeeker)
		{
			if(targetVehicle->getJammerPresent() && targetVehicle->getJammerActive())
				mTarget = NULL;
		}
		// Only process if there is a target and the projectile is locked on
		if((bool)mTarget && mCurrTick > mDataBlock->trackDelay) 
		{
			// Be sure to update clients on changes  
			setMaskBits(GuideMask); 
			// Set up variables
			F32 speed;
			Point3F targetDir;
			Point3F targetPos;
			// Get target position 
			targetPos = mTarget->getPosition();
			// Adjust z to hit middle of target's bounding box
			targetPos.z += (mTarget->getObjBox().len_z()/2);
			// Remember current speed
			speed = mCurrVelocity.len();
			// Calculate direction change necessary to get to target
			targetDir = targetPos - mCurrPosition;
			// Normalize target direction
			targetDir.normalize();
			// Normalize current direction
			mCurrVelocity.normalize();
			// Adjust target direction based on precision
			targetDir *= mDataBlock->precision;
			// Adjust current direction based on precision
			mCurrVelocity *= (100 - mDataBlock->precision);
			// Combine directions
			targetDir += mCurrVelocity;
			// Normalize current direction
			targetDir.normalize();
			// Scale new velocity to remembered speed
			targetDir *= speed;
			// Set current velocity to new velocity
			mCurrVelocity = targetDir;
		}
	}

	//Terrain Following
    if(mDataBlock->isTerrainFollowing && !mDataBlock->isSidewinder)
	{
		F32 maxcorrection = mDataBlock->speedTerrainFollowing * (F32(TickMs)/1000.0f); 
		Point2F projectileshadow;
		projectileshadow.x = newPosition.x;
		projectileshadow.y = newPosition.y;
		F32 terrainheight = getTerrainHeight(projectileshadow);
		if(newPosition.z > mDataBlock->maxTerrainHeight + terrainheight)
		{
			if(newPosition.z > mDataBlock->maxTerrainHeight + terrainheight + maxcorrection)
				newPosition.z -= maxcorrection;
			else
				newPosition.z = mDataBlock->maxTerrainHeight + terrainheight;
		}
		if(newPosition.z < mDataBlock->minTerrainHeight + terrainheight)
		{
			if(newPosition.z < mDataBlock->minTerrainHeight + terrainheight - maxcorrection)
				newPosition.z += maxcorrection;
			else
				newPosition.z = mDataBlock->minTerrainHeight + terrainheight;
		}
	}
	
	//Sidewinder Stuff
   //All else is ignored unless the setting is on
   if(mDataBlock->isSidewinder && !mDataBlock->isGuided && !mDataBlock->isTerrainFollowing)
   {
		if(mCurrTick > mDataBlock->sideDelay)
        {
			F32 Randm; //Set a temporary random variable

			Randm = (rand() * mDataBlock->crazyness/(RAND_MAX +1)); //This makes the crazyness setting in the datablock 
                                                                    //the controller for how random the projectiles are

			//Effect the projectiles Y velocity
			mCurrVelocity.y += cos(mCurrVelocity.y * tan(oldPosition.x) * Randm) * mDataBlock->multiplier;
			//Effect the X velocity
			mCurrVelocity.x += cos(mCurrVelocity.x * sin(oldPosition.z) * Randm) * mDataBlock->multiplier;
			//Effect the Z velocity
			mCurrVelocity.z += cos(mCurrVelocity.z * sin(oldPosition.y) * Randm) * mDataBlock->multiplier;
        }
   }

   if( mDataBlock->isBallistic )
   {
	   // modified to account for drag coefficient or form factor
	   F32 dV = (1-mDataBlock->ballisticCoefficient) * dT;
	   Point3F d(mCurrVelocity.x * dV,mCurrVelocity.y * dV, 9.81f * mDataBlock->gravityMod * dT+ mCurrVelocity.z * dV);
	   mCurrVelocity -= d;
   }

    //Affected by wind
    if(mDataBlock->useWind)
	{
		Sky* pSky = mSceneManager->getCurrentSky();
		if (pSky)
		{
			Point3F windvel = pSky->getWindVelocity();
			mCurrVelocity += windvel * mDataBlock->windEffect * dT;
		}
	}

   // disable the source objects collision reponse while we determine
   // if the projectile is capable of moving from the old position
   // to the new position, otherwise we'll hit ourself
   if (bool(mSourceObject))
      mSourceObject->disableCollision();

   // Determine if the projectile is going to hit any object between the previous
   // position and the new position. This code is executed both on the server
   // and on the client (for prediction purposes). It is possible that the server
   // will have registered a collision while the client prediction has not. If this
   // happens the client will be corrected in the next packet update.

   //Water explosion and stopping
   U32 colMask;
   if(mDataBlock->explodeOnWater && mDataBlock->stoppedByWater) 
	   colMask = csmDynamicCollisionMask | csmStaticCollisionMask | WaterObjectType;
   else
	   colMask = csmDynamicCollisionMask | csmStaticCollisionMask;

   if (getContainer()->castRay(oldPosition, newPosition, colMask, &rInfo))  
   {
      // make sure the client knows to bounce
      if(isServerObject() && (rInfo.object->getType() & csmStaticCollisionMask) == 0)
         setMaskBits(BounceMask);

      // Next order of business: do we explode on this hit?
      if(mCurrTick > mDataBlock->armingDelay)
      {
         MatrixF xform(true);
         xform.setColumn(3, rInfo.point);
         setTransform(xform);
         mCurrPosition    = rInfo.point;
         mCurrVelocity    = Point3F(0, 0, 0);

         // Get the object type before the onCollision call, in case
         // the object is destroyed.
         U32 objectType = rInfo.object->getType();

         // re-enable the collision response on the source object since
         // we need to process the onCollision and explode calls
         if(mSourceObject)
            mSourceObject->enableCollision();

         // Ok, here is how this works:
         // onCollision is called to notify the server scripts that a collision has occured, then
         // a call to explode is made to start the explosion process. The call to explode is made
         // twice, once on the server and once on the client.
         // The server process is responsible for two things:
         //    1) setting the ExplosionMask network bit to guarantee that the client calls explode
         //    2) initiate the explosion process on the server scripts
         // The client process is responsible for only one thing:
         //    1) drawing the appropriate explosion

         // It is possible that during the processTick the server may have decided that a hit
         // has occured while the client prediction has decided that a hit has not occured.
         // In this particular scenario the client will have failed to call onCollision and
         // explode during the processTick. However, the explode function will be called
         // during the next packet update, due to the ExplosionMask network bit being set.
         // onCollision will remain uncalled on the client however, therefore no client
         // specific code should be placed inside the function!
         Point3F impactNormal(mCurrPosition);
		 impactNormal-=savedOldPosition;
		 //impactNormal-=oldPosition;
		 impactNormal.normalize();

		 secPoint = Point3F(0, 0, 0);
		 secNormal = Point3F(0, 0, 0);
		 secImpactNormal = Point3F(0, 0, 0);

		 Point3F mPosition = rInfo.point;
		 Point3F mNormal = rInfo.normal;

		 transDecal = false;
		 
		 MatInstance* matInst = dynamic_cast< MatInstance* >(rInfo.material);
		 ShapeBase * rayShape = dynamic_cast<ShapeBase *>(rInfo.object);
		 
		 if (matInst != NULL)
		 {
			 pMatType = matInst->getMaterial()->bulletDecal;
			 if(pMatType < 0)
				 pMatType = 0;
			 if(pMatType > 6)
				 pMatType = 6;

			 useDecal = true;

			 if(rayShape)
			 {
				 if(rayShape->getDataBlock()->mUsePolysoup && rayShape->getDataBlock()->allowTransDecal)
					 transDecal = true;
				 else
					 useDecal = false;
			 }
		 }
		 else
		 {
			 if(rayShape)//Try again with a TriRay cast
			 {
				 Point3F triEnd = mCurrPosition;
				 triEnd += savedCurrVelocity;
				 if(rayShape->castRay(mCurrPosition, triEnd, &rTriInfo))
				 {
					 if(rTriInfo.distance > 0)
						 rInfo.point = rInfo.point + (rInfo.normal * rTriInfo.distance);
					 
					 matInst = dynamic_cast< MatInstance* >(rTriInfo.material);
					 if (matInst != NULL)
					 {
						 pMatType = matInst->getMaterial()->bulletDecal;
						 if(pMatType < 0)  
							 pMatType = 0;
						 if(pMatType > 6)
							 pMatType = 6;

						 useDecal = true;
						 
						 if(rayShape->getDataBlock()->mUsePolysoup && rayShape->getDataBlock()->allowTransDecal)
							 transDecal = true;
						 else
							 useDecal = false;
					 }
				 }
			 }
			 
			 //Lets try a TriRay cast in case it is a TSStatic not using PolySoup
			 else if( rInfo.object->getTypeMask() & StaticTSObjectType )
			 {
				 TSStatic * rayStatic = dynamic_cast<TSStatic *>(rInfo.object);
				 if(rayStatic)
				 {
					 if(rayStatic->castRay(savedOldPosition, newPosition, &rTriInfo))
					 {
						 matInst = dynamic_cast< MatInstance* >(rTriInfo.material);
						 if (matInst != NULL)
						 {
							 pMatType = matInst->getMaterial()->bulletDecal;

							 if(pMatType < 0)
								 pMatType = 0;
							 if(pMatType > 6)
								 pMatType = 6;

							 useDecal = true;
						 }
					 }
				 }
			 }
		 }

		 if( rInfo.object->getTypeMask() & (InteriorObjectType | StaticShapeObjectType | StaticTSObjectType))
		 {
			 if(armorPiercing)
			 {
				 Point3F velocityNormal = savedCurrVelocity;
				 velocityNormal.normalize();

				 Point3F mPiercePosition = mCurrPosition + velocityNormal * mDataBlock->mPierceWidth;

				 if (getContainer()->castRay(mPiercePosition, mCurrPosition, InteriorObjectType | StaticObjectType, &pierceInfo) == true)
				 {
					 MatInstance* matInstP = dynamic_cast< MatInstance* >(pierceInfo.material);
					 if(matInstP != NULL)
					 {
						 U32 pierceMatType = matInstP->getMaterial()->bulletDecal;
						 if(pierceMatType < 0)
							 pierceMatType = 0;
						 if(pMatType > 6)
							 pMatType = 6;

						 if(pierceMatType != 6)
						 {
							 addPierceDecal(pierceInfo.point, pierceInfo.normal, impactNormal, objectType, pierceMatType);
							 onPierce(pierceInfo.point, savedCurrVelocity);
						 }
					 }
				 }
			 }
		 }
		 else if( rInfo.object->getTypeMask() & PlayerObjectType )
		 {
			 //Thanks to help from Phillip O'Shea
			 Player * playerShape = dynamic_cast<Player *>(rInfo.object);
			 Point3F velocityNormal = savedCurrVelocity;
			 velocityNormal.normalize();
			 
			 const Box3F playerBox = playerShape->getObjBox();
			 const Point3F playerBoxSize(playerBox.len_x(), playerBox.len_y(), playerBox.len_z());
			 Point3F positionOffset = playerBoxSize;
			 positionOffset.convolve(velocityNormal);
			 mBloodRearPosition = mCurrPosition + positionOffset;
			 
			 mBloodObjPosition = mBloodRearPosition + velocityNormal * mDataBlock->mPlayerRearScanDist;

			 bool goreMode = Con::getBoolVariable("$pref::Player::GoreOn");
           
			 if (getContainer()->castRay(mBloodRearPosition, mBloodObjPosition, csmStaticCollisionMask, &playerRearInfo) == true)
			 {
				 Point3F secImpactNormal(playerRearInfo.point);
				 secImpactNormal-=mBloodRearPosition;
				 secImpactNormal.normalize();

				 if(goreMode)
					 addPierceDecal(playerRearInfo.point, playerRearInfo.normal, secImpactNormal, PlayerObjectType, pMatType);
			 }
		 }
		 onCollision(mPosition, mNormal, rInfo.object);
		 explode(mPosition, mNormal, impactNormal, objectType, pMatType, transDecal, rInfo.object);
      }
      else
      {
         if(mDataBlock->isBallistic)
         {
            // Otherwise, this represents a bounce.  First, reflect our velocity
            //  around the normal...
            Point3F bounceVel = mCurrVelocity - rInfo.normal * (mDot( mCurrVelocity, rInfo.normal ) * 2.0);;
            mCurrVelocity = bounceVel;

            // Add in surface friction...
            Point3F tangent = bounceVel - rInfo.normal * mDot(bounceVel, rInfo.normal);
            mCurrVelocity  -= tangent * mDataBlock->bounceFriction;

            // Now, take elasticity into account for modulating the speed of the grenade
            mCurrVelocity *= mDataBlock->bounceElasticity;

            F32 timeLeft = 1.0f - rInfo.t;
            oldPosition = rInfo.point + rInfo.normal * 0.05f;
            newPosition = oldPosition + (mCurrVelocity * ((timeLeft/1000.0f) * TickMs));
         }
      }
   }

   // re-enable the collision response on the source object now
   // that we are done processing the ballistic movment
   if (bool(mSourceObject))
      mSourceObject->enableCollision();
   
   if(isClientObject())
   {
      emitParticles(mCurrPosition, newPosition, mCurrVelocity, TickMs);
      updateSound();
   }

   mCurrDeltaBase = newPosition;
   mCurrBackDelta = mCurrPosition - newPosition;
   mCurrPosition = newPosition;

   MatrixF xform(true);
   xform.setColumn(3, mCurrPosition);
   setTransform(xform);
}


void Projectile::advanceTime(F32 dt)
{
   Parent::advanceTime(dt);

   if (mHidden == true || dt == 0.0)
      return;

   if (mActivateThread &&
         mProjectileShape->getDuration(mActivateThread) > mProjectileShape->getTime(mActivateThread) + dt)
   {
      mProjectileShape->advanceTime(dt, mActivateThread);
   }
   else
   {

      if (mMaintainThread)
      {
         mProjectileShape->advanceTime(dt, mMaintainThread);
      }
      else if (mActivateThread && mDataBlock->maintainSeq != -1)
      {
         mMaintainThread = mProjectileShape->addThread();
         mProjectileShape->setTimeScale(mMaintainThread, 1);
         mProjectileShape->setSequence(mMaintainThread, mDataBlock->maintainSeq, 0);
         mProjectileShape->advanceTime(dt, mMaintainThread);
      }
   }
}

void Projectile::interpolateTick(F32 delta)
{
   Parent::interpolateTick(delta);

   if(mHidden == true)
      return;

   Point3F interpPos = mCurrDeltaBase + mCurrBackDelta * delta;
   Point3F dir = mCurrVelocity;
   if(dir.isZero())
      dir.set(0,0,1);
   else
      dir.normalize();

   MatrixF xform(true);
	xform = MathUtils::createOrientFromDir(dir);
   xform.setPosition(interpPos);
   setRenderTransform(xform);

   // fade out the projectile image
   S32 time = (S32)(mCurrTick - delta);
   if(time > mDataBlock->fadeDelay)
   {
      F32 fade = F32(time - mDataBlock->fadeDelay);
      mFadeValue = 1.0 - (fade / F32(mDataBlock->lifetime));
   }
   else
      mFadeValue = 1.0;

   updateSound();
}



//--------------------------------------------------------------------------
void Projectile::onCollision(const Point3F& hitPosition, const Point3F& hitNormal, SceneObject* hitObject)
{
   // No client specific code should be placed or branched from this function
   if(isClientObject())
      return;

   if (hitObject != NULL && isServerObject())
   {
      char *posArg = Con::getArgBuffer(64);
      char *normalArg = Con::getArgBuffer(64);

      dSprintf(posArg, 64, "%g %g %g", hitPosition.x, hitPosition.y, hitPosition.z);
      dSprintf(normalArg, 64, "%g %g %g", hitNormal.x, hitNormal.y, hitNormal.z);

      Con::executef(mDataBlock, "onCollision",
         scriptThis(),
         Con::getIntArg(hitObject->getId()),
         Con::getFloatArg(mFadeValue),
         posArg,
         normalArg);
   }
}

void Projectile::onPierce(const Point3F& startPos, const Point3F& startVel)
{
   // No client specific code should be placed or branched from this function
   if(isClientObject())
      return;

   if (isServerObject())
   {
	  char *posArg = Con::getArgBuffer(64);
      char *velArg = Con::getArgBuffer(64);

      dSprintf(posArg, 64, "%g %g %g", startPos.x, startPos.y, startPos.z);
      dSprintf(velArg, 64, "%g %g %g", startVel.x, startVel.y, startVel.z);

	  Con::executef(mDataBlock, "onPierce",
         scriptThis(),
         posArg,
         velArg);
   }
}
//RJN Stop
//--------------------------------------------------------------------------
U32 Projectile::packUpdate(NetConnection* con, U32 mask, BitStream* stream)
{
   U32 retMask = Parent::packUpdate(con, mask, stream);

   // Initial update
   if (stream->writeFlag(mask & GameBase::InitialUpdateMask))
   {
      Point3F pos;
      getTransform().getColumn(3, &pos);
      stream->writeCompressedPoint(pos);
	  stream->write(armorPiercing); //RJN
	  stream->write(mWrappedDecals); //RJN 
      F32 len = mCurrVelocity.len();

      if(stream->writeFlag(len > 0.02))
	  {
         Point3F outVel = mCurrVelocity;
         outVel *= 1 / len;
         stream->writeNormalVector(outVel, 10);
         len *= 32.0; // 5 bits for fraction
         if(len > 8191)
            len = 8191;
         stream->writeInt((S32)len, 13);
      }

      stream->writeRangedU32(mCurrTick, 0, MaxLivingTicks);
      if (bool(mSourceObject))
      {
         // Potentially have to write this to the client, let's make sure it has a
         //  ghost on the other side...
         S32 ghostIndex = con->getGhostIndex(mSourceObject);
         if (stream->writeFlag(ghostIndex != -1))
         {
            stream->writeRangedU32(U32(ghostIndex), 0, NetConnection::MaxGhostCount);
            stream->writeRangedU32(U32(mSourceObjectSlot),
                                   0, ShapeBase::MaxMountedImages - 1);
         }
         else // havn't recieved the ghost for the source object yet, try again later
            retMask |= GameBase::InitialUpdateMask;
      }
      else
         stream->writeFlag(false);
   }
   
   stream->write(pMatType);
   stream->write(mCollideHitType);
   mathWrite(*stream, mPiercePoint);
   mathWrite(*stream, mPierceNormal);
   mathWrite(*stream, mPierceINormal);
   stream->writeFlag(addPierce);  
   stream->writeFlag(useDecal);  

   // explosion update
   if (stream->writeFlag((mask & ExplosionMask) && mHidden))
   {
      mathWrite(*stream, mExplosionPosition);
      mathWrite(*stream, mExplosionNormal);
      mathWrite(*stream,mImpactNormal); 
	  stream->writeFlag(armorPiercing);
	  stream->writeFlag(mWrappedDecals); 
	  stream->write(mControlClient);
	  stream->writeFlag(transDecal);
	  stream->write(con->getGhostIndex(transObject));
   }

   // bounce update
   if (stream->writeFlag(mask & BounceMask))
   {
      // Bounce against dynamic object
      mathWrite(*stream, mCurrPosition);
      mathWrite(*stream, mCurrVelocity);
   }

   //Guided or Seeker Projectiles
   if (stream->writeFlag(mask & GuideMask))
   {
      mathWrite(*stream, mCurrPosition);
      mathWrite(*stream, mCurrVelocity);
   }

   return retMask;
}

void Projectile::unpackUpdate(NetConnection* con, BitStream* stream)
{
   Parent::unpackUpdate(con, stream);

   // initial update
   if (stream->readFlag())
   {
      Point3F pos;
      stream->readCompressedPoint(&pos);
	  stream->read(&armorPiercing); 
	  stream->read(&mWrappedDecals); 

      if(stream->readFlag())
      {
         stream->readNormalVector(&mCurrVelocity, 10);
         mCurrVelocity *= stream->readInt(13) / 32.0f;
   }
      else
         mCurrVelocity.set(0, 0, 0);

      mCurrDeltaBase = pos;
      mCurrBackDelta = mCurrPosition - pos;
      mCurrPosition  = pos;
      setPosition(mCurrPosition);

      mCurrTick = stream->readRangedU32(0, MaxLivingTicks);
      if (stream->readFlag())
      {
         mSourceObjectId   = stream->readRangedU32(0, NetConnection::MaxGhostCount);
         mSourceObjectSlot = stream->readRangedU32(0, ShapeBase::MaxMountedImages - 1);

         NetObject* pObject = con->resolveGhost(mSourceObjectId);
         if (pObject != NULL)
            mSourceObject = dynamic_cast<ShapeBase*>(pObject);
      }
      else
      {
         mSourceObjectId   = -1;
         mSourceObjectSlot = -1;
         mSourceObject     = NULL;
      }
   }

   stream->read(&pMatType); 
   stream->read(&mCollideHitType);
   mathRead(*stream, &mPiercePoint); 
   mathRead(*stream, &mPierceNormal); 
   mathRead(*stream, &mPierceINormal); 
   addPierce = stream->readFlag(); 
   if(addPierce == true)
   {
	   addPierceDecal(mPiercePoint, mPierceNormal, mPierceINormal, mCollideHitType, pMatType);
   }
   useDecal = stream->readFlag(); 

   // explosion update
   if (stream->readFlag())
   {
      Point3F explodePoint;
      Point3F explodeNormal;
      mathRead(*stream, &explodePoint);
      mathRead(*stream, &explodeNormal);
      
      mathRead(*stream, &mImpactNormal); 
	  armorPiercing = stream->readFlag(); 
	  mWrappedDecals = stream->readFlag(); 
	  stream->read(&mControlClient);
	  transDecal = stream->readFlag(); 
	  stream->read(&transObjectId);

	  if(transObjectId != -1 && transDecal)
	  {
		  NetObject* tObject = con->resolveGhost(transObjectId);
		  if (tObject != NULL)
			  transObject = dynamic_cast<SceneObject*>(tObject);
		  else
		  {
			  transObject = NULL;
		  }
	  }
	  else
	  {
		  transObject = NULL;
	  }

      // start the explosion visuals
      explode(explodePoint, explodeNormal, mImpactNormal, mCollideHitType, pMatType, transDecal, transObject); //RJN
   }

   // bounce update
   if (stream->readFlag())
   {
      mathRead(*stream, &mCurrPosition);
      mathRead(*stream, &mCurrVelocity);
   }

   //Guided or Seeker Projectiles
   if (stream->readFlag())
   {
      mathRead(*stream, &mCurrPosition);
      mathRead(*stream, &mCurrVelocity);
   }
}

//--------------------------------------------------------------------------
bool Projectile::prepRenderImage(SceneState* state, const U32 stateKey,
                                       const U32 /*startZone*/, const bool /*modifyBaseState*/)
{
   if (isLastState(state, stateKey))
      return false;
   setLastState(state, stateKey);

   if (mHidden == true || mFadeValue <= (1.0/255.0))
      return false;

   // This should be sufficient for most objects that don't manage zones, and
   //  don't need to return a specialized RenderImage...
   if (state->isObjectRendered(this))
   {
      prepBatchRender( state );
   }

   return false;
}

void Projectile::prepBatchRender(SceneState* state)
{
   //  New code for TSE
   MatrixF proj = GFX->getProjectionMatrix();

   RectI viewport = GFX->getViewport();

   // hack until new scenegraph in place
   MatrixF world = GFX->getWorldMatrix();
   TSMesh::setCamTrans( world );
   TSMesh::setSceneState( state );
   TSMesh::setObject(this);   // <--- here's what I added

   //  Uncomment below if projectiles support refraction.  Don't forget
   // to uncomment the code in ::prepRenderImage()
   // TSMesh::setRefract( image->sortType == SceneRenderImage::Refraction );


   GFX->pushWorldMatrix();

   MatrixF mat = getRenderTransform();
   mat.scale( mObjScale );
   GFX->setWorldMatrix( mat );

   if(mProjectileShape)
   {
      AssertFatal(mProjectileShape != NULL,
                  "Projectile::renderObject: Error, projectile shape should always be present in renderObject");
      mProjectileShape->selectCurrentDetail();
      mProjectileShape->animate();

      mProjectileShape->render();
   }


   GFX->popWorldMatrix();

   GFX->setProjectionMatrix( proj );
   GFX->setViewport( viewport );
}
