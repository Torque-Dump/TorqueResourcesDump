//-----------------------------------------------------------------------------
// guiAnimatedCrosshairHud.cpp
// 
// Description: Animated crosshair
//
// Author: Matt Huston (matthuston@gmail.com)
// Date: June 30th, 2007
//
//-----------------------------------------------------------------------------

#include "gui/controls/guiBitmapCtrl.h"
#include "gui/shiny/guiTickCtrl.h"
#include "gui/3d/guiTSControl.h"
#include "console/consoleTypes.h"
#include "sceneGraph/sceneGraph.h"
#include "T3D/shapeBase.h"
#include "T3D/player.h"
#include "T3D/vehicles/vehicle.h"
#include "T3D/gameConnection.h"

class GuiAnimatedCrosshairHud : public GuiTickCtrl
{
private:
	typedef GuiControl Parent;

protected:

	StringTableEntry mBitmapName;

	GFXTexHandle mTextureHandle_Crosshair;
	GFXTexHandle mTextureHandle_Reticle;
	GFXTexHandle mTextureHandle_LockonReticle;

	bool mAiming;
	Point3F mPlayerPos;
	Point3F mCamPos;

	F32	mScale;
	F32 mAlpha;
	F32 mReticleSpeed;

	bool mLockedOn;
	bool lockonMode;
	bool heatSeekerMode;
	F32 maxLockonRange;
	F32 minHeatSignature;
	bool teamMode;
	S32 clientTeam;
    U32 detectionMode;

	U32 mTicks;
	U32 mAimAtObject;

public:
	DECLARE_CONOBJECT( GuiAnimatedCrosshairHud );

	GuiAnimatedCrosshairHud();

	static void initPersistFields();

	bool getAim() { return mAiming; };
	void setAim(bool aim) { mAiming = aim; };

	void setLockingSpeed(F32 speed) { mReticleSpeed = speed; }
	void setMinHeatSignature(F32 temp) { minHeatSignature = temp; }
	void setMaxLockonRange(F32 range) { maxLockonRange = range; }
	void setLockonMode(bool flag) { lockonMode = flag; }
	void setHeatSeekMode(bool flag) { heatSeekerMode = flag; }
	void setTeamMode(bool team) { teamMode = team; }
	void setClientTeam(S32 team) { clientTeam = team; }
    void setDetectionMode(U32 type) { detectionMode = type; }
	bool getLockonStatus();
	S32 getTarget();

	virtual void setBitmap(const char *name, bool resize = false);
	void renderCrossHair(GFXTexHandle &textureHandle, Point2I offset, const RectI &updateRect);
	void renderReticle(GFXTexHandle &textureHandle, Point2I offset, const RectI &updateRect);

	bool onWake();
	void onSleep();	
	void onRender( Point2I, const RectI &);

	void advanceTime( F32 timeDelta );
};

IMPLEMENT_CONOBJECT( GuiAnimatedCrosshairHud );

GuiAnimatedCrosshairHud::GuiAnimatedCrosshairHud()
{
	mBitmapName = StringTable->insert("");

	mAiming = true;

	mScale = 1.0f;
	mAlpha = 0.0f;
	mReticleSpeed = 0.02f;

	mTicks = 0;

	mLockedOn = false;
	lockonMode = false;
	heatSeekerMode = false;
	detectionMode = 2;
	minHeatSignature = 110.0f;
	maxLockonRange = 1000.0f;
	
	clientTeam = -1;
	teamMode = false;
}

void GuiAnimatedCrosshairHud::initPersistFields()
{
	Parent::initPersistFields();
	
	addField( "bitmap", TypeFilename, Offset(mBitmapName, GuiAnimatedCrosshairHud) );
}

bool GuiAnimatedCrosshairHud::onWake()
{
	if (! Parent::onWake())
		return false;
	
	setBitmap(mBitmapName);

	return true;
}

void GuiAnimatedCrosshairHud::onSleep()
{
	mTextureHandle_Crosshair = NULL;
	mTextureHandle_Reticle  = NULL;
	mTextureHandle_LockonReticle  = NULL;
	
	Parent::onSleep();
}

void GuiAnimatedCrosshairHud::setBitmap(const char *name, bool resize )
{
	if (*mBitmapName)
	{
		char buffer[1024];
		char *p;
		
		dStrcpy(buffer, name);
		p = buffer + dStrlen(buffer);
		
		dStrcpy(p, "_crosshair");		
		mTextureHandle_Crosshair = GFXTexHandle(buffer, &GFXDefaultGUIProfile, avar("%s() - mTextureObject (line %d)", __FUNCTION__, __LINE__));
		
		dStrcpy(p, "_reticle");		
		mTextureHandle_Reticle = GFXTexHandle(buffer, &GFXDefaultGUIProfile, avar("%s() - mTextureObject (line %d)", __FUNCTION__, __LINE__));

		dStrcpy(p, "_lockonreticle");		
		mTextureHandle_LockonReticle = GFXTexHandle(buffer, &GFXDefaultGUIProfile, avar("%s() - mTextureObject (line %d)", __FUNCTION__, __LINE__));
	}
	else
	{   
		mTextureHandle_Crosshair = NULL;
		mTextureHandle_Reticle  = NULL;
		mTextureHandle_LockonReticle  = NULL;
	}
	setUpdate();
}

void GuiAnimatedCrosshairHud::renderCrossHair(GFXTexHandle &textureHandle, Point2I offset, const RectI &updateRect)
{
	if (textureHandle)
	{
		GFX->getDrawUtil()->clearBitmapModulation();
		RectI destRect(Point2I(offset.x + (getBounds().extent.x / 2) - (textureHandle->getBitmapWidth() / 2),
							   offset.y + (getBounds().extent.y / 2) - (textureHandle->getBitmapHeight() / 2)),
							   Point2I(textureHandle->getBitmapWidth(), textureHandle->getBitmapHeight()));

		RectI srcRect(Point2I(0,0), Point2I(textureHandle->getBitmapWidth(), 
											textureHandle->getBitmapHeight()));

		
		GFX->getDrawUtil()->drawBitmapStretchSR(textureHandle, destRect, srcRect);
	}
	
	if (mProfile->mBorder || !textureHandle)
	{
		RectI rect(offset.x, offset.y, getBounds().extent.x, getBounds().extent.y);
		GFX->getDrawUtil()->drawRect(rect, mProfile->mBorderColor);
	}
}

void GuiAnimatedCrosshairHud::renderReticle(GFXTexHandle &textureHandle, Point2I offset, const RectI &updateRect)
{
	if (textureHandle)
	{
		GFX->getDrawUtil()->clearBitmapModulation();

		Point2I extent(48 + (getBounds().extent.x - 48) * mScale,
					   48 + (getBounds().extent.y - 48) * mScale);

		
		RectI destRect(Point2I(offset.x + (getBounds().extent.x / 2) - extent.x / 2,
							   offset.y + (getBounds().extent.y / 2) - extent.y / 2),
							   Point2I(extent.x, extent.y));

		RectI srcRect(Point2I(0,0), Point2I(extent.x, extent.y));
		
		ColorI color(255, 255, 255, mAlpha * 255);
		GFX->getDrawUtil()->setBitmapModulation(color);
		GFX->getDrawUtil()->drawBitmapStretch(textureHandle, destRect);		
	}
	
	if (mProfile->mBorder || !textureHandle)
	{
		RectI rect(offset.x, offset.y, getBounds().extent.x, getBounds().extent.y);
		GFX->getDrawUtil()->drawRect(rect, mProfile->mBorderColor);
	}

	
}

void GuiAnimatedCrosshairHud::advanceTime( F32 timeDelta ) 
{
	if(mAiming)
	{
		mScale -= mReticleSpeed;
		mAlpha += mReticleSpeed;

		if(mScale <= 0.0f && mAlpha >= 1.0f)
		{
			mScale	= 0;
			mAlpha	= 1;
		}
	}
	else
	{
		mScale += mReticleSpeed;
		mAlpha -= mReticleSpeed;

		if(mScale >= 1.0f && mAlpha <= 0.0f)
		{
			mScale	= 1;
			mAlpha	= 0;
			mLockedOn = false;
			mAimAtObject = 0;
		}
	}

	if(mTicks > 1)
	{
		// Collision info. We're going to be running LOS tests and we don't 
		// want to collide with the control object, terrain or interiors.
		static U32 ObjectMask;
		if(detectionMode == 0)
			ObjectMask = PlayerObjectType;
		else if(detectionMode == 1)
			ObjectMask = VehicleObjectType;
		else
			ObjectMask = PlayerObjectType | VehicleObjectType;

		// Must have a connection and player control object
		GameConnection* conn = GameConnection::getConnectionToServer();
		if (!conn)
			return;

		ShapeBase* control = dynamic_cast<ShapeBase*>(conn->getControlObject());
		if (!control || !(control->getType() & ObjectMask))
			return;

		MatrixF cam;
		Point3F camPos;
		conn->getControlCameraTransform(0, &cam);
		cam.getColumn(3, &camPos);
		
		// Extend the camera vector to create an endpoint for our ray
		Point3F endPos;
		cam.getColumn(1, &endPos);
		endPos *= gClientSceneGraph->getVisibleDistance();
		endPos += camPos;
		
		control->disableCollision();
		
		RayInfo info;
		if (gClientContainer.castRay(camPos, endPos, ObjectMask, &info))
		{
			if (info.object->getTypeMask() & PlayerObjectType)
			{
				mAimAtObject = info.object->getId();

				mAiming = true;
				
				mLockedOn = true;
				Player *targetPlayer = static_cast<Player*>(info.object);
				
				//Prevent locking on if target heat signature too low
				if(lockonMode && heatSeekerMode && targetPlayer->heatSignature < minHeatSignature)
					mLockedOn = false;
				
				//Prevent locking on if target out of range
				if(lockonMode && (info.point - camPos).len() > maxLockonRange)
					mLockedOn = false;
				
				//Prevent locking on to team controlled players
				if(lockonMode && teamMode)
				{
					if(targetPlayer->getControllingClient() != 0)
					{
						S32 targetTeam = targetPlayer->getControllingClient()->getTeamID();
						if(clientTeam == targetTeam)
							mLockedOn = false;
					}
				}
			}
			else if (info.object->getTypeMask() & VehicleObjectType)
			{
				mAimAtObject = info.object->getId();
				
				mAiming = true;
				if(mScale <= 0.0f && mAlpha >= 1.0f)
					mLockedOn = true;
				
				Vehicle *targetVehicle = static_cast<Vehicle*>(info.object);
				if(targetVehicle)
				{
					//Prevent radar locking on to vehicles with an active radar jammer
					if(targetVehicle->getJammerPresent() && targetVehicle->getJammerActive() && lockonMode && !heatSeekerMode)
						mLockedOn = false;
					
					//ASHES ONLY
					//Prevent radar locking on to motorcycles - they don't have radar
					if(targetVehicle->getDataBlock()->isBike && lockonMode && !heatSeekerMode)
						mLockedOn = false;
					//ASHES ONLY

					//Prevent locking on if target heat signature too low
					if(lockonMode && heatSeekerMode && targetVehicle->heatSignature < minHeatSignature)
						mLockedOn = false;
					
					//Prevent locking on to team controlled vehicles
					if(lockonMode && teamMode)
					{
						if(targetVehicle->getControllingClient() != 0)
						{
							S32 targetTeam = targetVehicle->getControllingClient()->getTeamID();
							if(clientTeam == targetTeam)
								mLockedOn = false;
						}
					}
				}
				//Prevent locking on if target out of range
				if(lockonMode && (info.point - camPos).len() > maxLockonRange)
					mLockedOn = false;
				
			}
			else
			{
				mLockedOn = false;
				mAiming = false;
				mAimAtObject = 0;
			}
		}
		else
		{
			mAiming = false;
		}

		mCamPos = camPos;
		mTicks = 0;

		// Restore control object collision
		control->enableCollision();
	}

	mTicks++;
}

void GuiAnimatedCrosshairHud::onRender(Point2I offset, const RectI &updateRect)
{
	static U32 ObjectMask;
	if(detectionMode == 0)
		ObjectMask = PlayerObjectType;
	else if(detectionMode == 1)
		ObjectMask = VehicleObjectType;
	else
		ObjectMask = PlayerObjectType | VehicleObjectType;

	// Must have a connection and player control object
	GameConnection* conn = GameConnection::getConnectionToServer();
	
	if (!conn)
		return;
	
	ShapeBase* control = dynamic_cast<ShapeBase*>(conn->getControlObject());
	if (!control || !(control->getType() & ObjectMask))
		return;

	renderCrossHair(mTextureHandle_Crosshair, offset, updateRect);
	if(mLockedOn && lockonMode)
		renderReticle(mTextureHandle_LockonReticle, offset, updateRect);
	else
		renderReticle(mTextureHandle_Reticle, offset, updateRect);
}

S32 GuiAnimatedCrosshairHud::getTarget()
{
	return mAimAtObject;
}

bool GuiAnimatedCrosshairHud::getLockonStatus()
{
	return mLockedOn;
}

ConsoleMethod( GuiAnimatedCrosshairHud, getAim, bool, 2, 2, "Is player aiming?")
{
	return object->getAim();
}

ConsoleMethod( GuiAnimatedCrosshairHud, setAim, void, 3, 3, "Sets player to aim")
{
	object->setAim(dAtob(argv[2]));
}

// example -
// Crosshair.setBitmap("~gameSpecific/client/ui/weapon");
ConsoleMethod( GuiAnimatedCrosshairHud, setBitmap, void, 3, 4, "(string filename, bool resize=false)"
               "Set the bitmap displayed in the control. Note that it is limited in size, to 256x256.")
{
   char fileName[1024];
   Con::expandScriptFilename(fileName, sizeof(fileName), argv[2]);
   object->setBitmap(fileName, argc > 3 ? dAtob( argv[3] ) : false );
}

ConsoleMethod( GuiAnimatedCrosshairHud, setLockingSpeed, void, 3, 3, "(float locking speed)")
{
   F32 speed = dAtof(argv[2]);
   object->setLockingSpeed(speed);
}

ConsoleMethod( GuiAnimatedCrosshairHud, setMaxLockonRange, void, 3, 3, "(float max range)")
{
   F32 range = dAtof(argv[2]);
   object->setMaxLockonRange(range);
}

ConsoleMethod( GuiAnimatedCrosshairHud, setMinHeatSignature, void, 3, 3, "(float temperature)")
{
   F32 temp = dAtof(argv[2]);
   object->setMinHeatSignature(temp);
}

ConsoleMethod(GuiAnimatedCrosshairHud, setHeatSeekMode, void, 3, 3, "GuiAnimatedCrosshairHud.setHeatSeekMode(bool) - Sets heatSeeker mode")
{
    object->setHeatSeekMode(dAtob(argv[2]));
}

ConsoleMethod(GuiAnimatedCrosshairHud, setLockonMode, void, 3, 3, "GuiAnimatedCrosshairHud.setLockonMode(bool) - Sets lockon mode")
{
    object->setLockonMode(dAtob(argv[2]));
}

ConsoleMethod(GuiAnimatedCrosshairHud, getTarget, S32, 2, 2, "getTarget()")
{
   return object->getTarget();
}

ConsoleMethod(GuiAnimatedCrosshairHud, getLockonStatus, S32, 2, 2, "getLockonStatus()")
{
   return object->getLockonStatus();
}

ConsoleMethod( GuiAnimatedCrosshairHud, setClientTeam, void, 3, 3, "obj.setClientTeam( team# )")
{
	object->setClientTeam( dAtoi( argv[2] ));
}

ConsoleMethod(GuiAnimatedCrosshairHud, setTeamMode, void, 3, 3, "GuiAnimatedCrosshairHud.setTeamMode(bool) - Sets teeam game mode")
{
    object->setTeamMode(dAtob(argv[2]));
}

ConsoleMethod(GuiAnimatedCrosshairHud, setDetectionMode, void, 3, 3, "GuiAnimatedCrosshairHud.setDetectionMode(U32) - Sets detection mode")
{
    object->setDetectionMode( dAtoi( argv[2] ));
}