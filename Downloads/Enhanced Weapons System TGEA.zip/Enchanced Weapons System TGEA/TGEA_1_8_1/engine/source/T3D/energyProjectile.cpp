#include "console/consoleTypes.h"   
#include "core/stream/bitStream.h"   
#include "sceneGraph/sceneState.h"   
#include "sceneGraph/sceneGraph.h"   
#include "T3D/shapeBase.h"   
#include "T3D/player.h"   
#include "ts/tsShapeInstance.h"   
#include "gfx/primBuilder.h"   
#include "gfx/gfxDevice.h"   
#include "gfx/gfxTransformSaver.h"   
#include "math/mRandom.h"   
#include "math/mathIO.h"   
#include "math/mathUtils.h"   
#include "renderInstance/renderPassManager.h"   
#include "T3D/projectile.h"   
#include "T3D/tsStatic.h"

class ExplosionData;   
class ShapeBase;   
class TSShapeInstance;   
class TSThread;   
  
  
//--------------------------------------------------------------------------   
class EnergyProjectileData : public ProjectileData   
{   
    typedef ProjectileData Parent;   
         
public:   
  
    bool beamEnabled;   
    bool beamPulse;   
    bool updateToMuzzle;   
    F32 beamStartRadius;   
    F32 beamMidRadius;   
    F32 beamEndRadius;   
    F32 beamFrontSegmentLength;   
    F32 beamBackSegmentLength;   
    StringTableEntry beamMaterialList;   
  
    bool sparkEnabled;   
    StringTableEntry sparkMaterialList;   
    F32 sparkRadius;   
    F32 sparkStep;   
    F32 sparkRotationStep;   
  
    S32 interval;   
  
    EnergyProjectileData();   
  
    void packData(BitStream*);   
    void unpackData(BitStream*);   
  
    static void initPersistFields();   
    DECLARE_CONOBJECT(EnergyProjectileData);   
};   
DECLARE_CONSOLETYPE(EnergyProjectileData)   
  
//--------------------------------------------------------------------------   
class EnergyProjectile : public Projectile   
{   
    typedef Projectile Parent;   
    EnergyProjectileData* mDataBlock;   
  
protected:   
    GFXTexHandle  mBeamTextureHandles[20];   
    MaterialList  mBeamMaterialList;   
    GFXTexHandle  mSparkTextureHandles[20];   
    MaterialList  mSparkMaterialList;   
    S32           mBeamNumTextures;   
    S32           mBeamIndex;   
    S32           mSparkNumTextures;   
    S32           mSparkIndex;   
    F32           mSparkRadius;   
  
    S32           mLastTime;   
    F32           mRange;   
  
    F32           mSparkRotation;   
  
    Point3F       mEndPosition;   
    Point3F       mMuzzlePosition;   
    Point3F       mMuzzleVector;   
    Point3F       mMuzzleVelocity;   
  
    void loadDml();   
  
    bool onAdd();   
    bool onNewDataBlock(GameBaseData*);   
    U32  packUpdate  (NetConnection *conn, U32 mask, BitStream *stream);   
    void unpackUpdate(NetConnection *conn,           BitStream *stream);   
  
    void processTick(const Move* move);   
    bool prepRenderImage(SceneState*, const U32, const U32, const bool);   
    void renderObject(ObjectRenderInst *ri, BaseMatInstance*);   
    void RenderBeamSegment( Point3F pStart, Point3F pEnd, F32 startRadius, F32 endRadius, F32 vStart, F32 vEnd );   
  
    GFXStateBlockRef  mBlendInvSrcAlphaSB;   
    GFXStateBlockRef  mBlendSB;   
  
    ObjectRenderInst::RenderDelegate mRenderDelegate;   
public:   
  
    static void initPersistFields();   
  
    EnergyProjectile();   
    ~EnergyProjectile();   
  
    DECLARE_CONOBJECT(EnergyProjectile);   
};   
  
IMPLEMENT_CO_DATABLOCK_V1(EnergyProjectileData);   
IMPLEMENT_CO_NETOBJECT_V1(EnergyProjectile);   
  
  
//--------------------------------------------------------------------------   
//   
EnergyProjectileData::EnergyProjectileData()   
{   
   ProjectileData::ProjectileData();   
  
   beamEnabled = false;   
   beamPulse = true;
   updateToMuzzle = false;
   beamStartRadius = 0.0;   
   beamMidRadius = 0.0;   
   beamEndRadius = 0.0;   
   beamFrontSegmentLength = 0.0;   
   beamBackSegmentLength = 0.0;   
   beamMaterialList = NULL;   
  
   sparkEnabled = false;   
   sparkMaterialList = NULL;   
   sparkRadius = 0.0;   
   sparkStep = 0.0;   
   sparkRotationStep = 0.0f;   
  
   interval = 0;   
}   
  
//--------------------------------------------------------------------------   
IMPLEMENT_CONSOLETYPE(EnergyProjectileData)   
IMPLEMENT_GETDATATYPE(EnergyProjectileData)   
IMPLEMENT_SETDATATYPE(EnergyProjectileData)   
  
void EnergyProjectileData::initPersistFields()   
{   
   Parent::initPersistFields();   
  
   addNamedField(beamEnabled, TypeBool, EnergyProjectileData);   
   addNamedField(beamPulse, TypeBool, EnergyProjectileData);
   addNamedField(updateToMuzzle, TypeBool, EnergyProjectileData);   
   addNamedField(beamStartRadius, TypeF32, EnergyProjectileData);   
   addNamedField(beamMidRadius, TypeF32, EnergyProjectileData);   
   addNamedField(beamEndRadius, TypeF32, EnergyProjectileData);   
   addNamedField(beamFrontSegmentLength, TypeF32, EnergyProjectileData);   
   addNamedField(beamBackSegmentLength, TypeF32, EnergyProjectileData);   
   addNamedField(beamMaterialList, TypeFilename, EnergyProjectileData);   
  
   addNamedField(sparkEnabled, TypeBool, EnergyProjectileData);   
   addNamedField(sparkMaterialList, TypeFilename, EnergyProjectileData);   
   addNamedField(sparkRadius, TypeF32, EnergyProjectileData);   
   addNamedField(sparkStep, TypeF32, EnergyProjectileData);   
   addNamedField(sparkRotationStep, TypeF32, EnergyProjectileData);   
      
   addNamedField(interval, TypeS32, EnergyProjectileData);   
}   
  
//--------------------------------------------------------------------------   
void EnergyProjectileData::packData(BitStream* stream)   
{   
   Parent::packData(stream);   
  
   stream->writeFlag(beamEnabled);   
   stream->writeFlag(beamPulse);   
   stream->writeFlag(updateToMuzzle); 
   stream->writeFloat(beamStartRadius/20.0, 8);   
   stream->writeFloat(beamMidRadius/20.0, 8);   
   stream->writeFloat(beamEndRadius/20.0, 8);   
   stream->writeFloat(beamFrontSegmentLength/20.0, 8);   
   stream->writeFloat(beamBackSegmentLength/20.0, 8);   
   stream->writeString(beamMaterialList);   
  
   stream->writeFlag(sparkEnabled);   
   stream->writeString(sparkMaterialList);   
   stream->writeFloat(sparkRadius/20.0, 8);   
   stream->writeFloat(sparkStep, 8);   
   stream->writeFloat(sparkRotationStep, 8);   
  
   stream->writeInt(interval, 32);   
}   
  
void EnergyProjectileData::unpackData(BitStream* stream)   
{   
   Parent::unpackData(stream);   
  
   beamEnabled = stream->readFlag();   
   beamPulse = stream->readFlag(); 
   updateToMuzzle = stream->readFlag(); 
   beamStartRadius = stream->readFloat(8) * 20;   
   beamMidRadius = stream->readFloat(8) * 20;   
   beamEndRadius = stream->readFloat(8) * 20;   
   beamFrontSegmentLength = stream->readFloat(8) * 20;   
   beamBackSegmentLength = stream->readFloat(8) * 20;   
   beamMaterialList = StringTable->insert(stream->readSTString());   
  
   sparkEnabled = stream->readFlag();   
   sparkMaterialList = StringTable->insert(stream->readSTString());   
   sparkRadius = stream->readFloat(8) * 20;   
   sparkStep = stream->readFloat(8);   
   sparkRotationStep = stream->readFloat(8);   
  
   interval = stream->readInt(32);   
}   
  
  
//--------------------------------------------------------------------------   
EnergyProjectile::EnergyProjectile()   
{   
   mLastTime = 0;   
   mBeamIndex = 0;   
   mSparkIndex = 0;   
   mSparkRadius = 0.0;   
   mSparkRotation = 0.0;   
   mRange = 0;   
  
   mRenderDelegate.bind(this, &EnergyProjectile::renderObject);   
}   
  
EnergyProjectile::~EnergyProjectile()   
{   
}   
  
//--------------------------------------------------------------------------   
void EnergyProjectile::initPersistFields()   
{   
   Parent::initPersistFields();   
   addField("range", TypeF32, Offset(mRange, EnergyProjectile));   
}   
  
//--------------------------------------------------------------------------   
U32 EnergyProjectile::packUpdate(NetConnection* con, U32 mask, BitStream* stream)   
{   
   U32 retMask = Parent::packUpdate(con, mask, stream);   
  
   if (stream->writeFlag(mask & GameBase::InitialUpdateMask))   
   {   
      // Initial update   
      stream->write(mRange);   
   }   
   return retMask;   
}   
  
void EnergyProjectile::unpackUpdate(NetConnection* con, BitStream* stream)   
{   
   Parent::unpackUpdate(con, stream);   
  
   if (stream->readFlag())   
   {   
      // initial update   
      stream->read(&mRange);   
   }   
}   
  
//--------------------------------------------------------------------------   
void EnergyProjectile::loadDml()   
{   
    S32 x;   
    mBeamNumTextures = 0;         
    mSparkNumTextures = 0;    
  
    FileStream  *stream = NULL;   
  
    if (mDataBlock->beamEnabled && mDataBlock->beamMaterialList[0])   
    {   
        stream = FileStream::createAndOpen( mDataBlock->beamMaterialList, Torque::FS::File::Read );   
        if(stream)   
        {   
            char path[1024], *p;   
            dStrcpy(path, mDataBlock->beamMaterialList);   
            if ((p = dStrrchr(path, '/')) != NULL)   
                *p = 0;   
  
            mBeamMaterialList.read(*stream);   
            stream->close();   
            delete stream;   
  
            mBeamMaterialList.load(path);   
            for(x = 0; x < mBeamMaterialList.size(); ++x, ++mBeamNumTextures)   
                mBeamTextureHandles[x] = mBeamMaterialList.getMaterial(x);    
        }   
    }   
  
    if (mDataBlock->sparkEnabled && mDataBlock->sparkMaterialList[0])   
    {   
        stream = FileStream::createAndOpen( mDataBlock->sparkMaterialList, Torque::FS::File::Read );   
        if(stream)   
        {   
            char path[1024], *p;   
            dStrcpy(path, mDataBlock->sparkMaterialList);   
            if ((p = dStrrchr(path, '/')) != NULL)   
                *p = 0;   
  
            mSparkMaterialList.read(*stream);   
            stream->close();   
            delete stream;   
  
            mSparkMaterialList.load(path);   
            for(x = 0; x < mSparkMaterialList.size(); ++x, ++mSparkNumTextures)   
                mSparkTextureHandles[x] = mSparkMaterialList.getMaterial(x);    
        }   
    }   
}   
  
//--------------------------------------------------------------------------   
bool EnergyProjectile::onAdd()   
{   
   if(!Parent::onAdd())   
      return false;   
  
   if (!isServerObject())   
   {   
      loadDml();   
  
      mSparkRadius = mDataBlock->sparkRadius;   
      mMuzzlePosition = mInitialPosition;   
      mMuzzleVelocity = mCurrVelocity;   
   }   
         
   return true;   
}   
  
bool EnergyProjectile::onNewDataBlock(GameBaseData* dptr)   
{   
   mDataBlock = dynamic_cast<EnergyProjectileData*>(dptr);   
   if (!mDataBlock || !Parent::onNewDataBlock(dptr))   
      return false;   
  
   return true;   
}   
  
void EnergyProjectile::processTick(const Move* move)   
{   
   GameBase::processTick(move);   
  
   mCurrTick++;   
   // See if we can get out of here the easy way ...   
   if (isServerObject() && mCurrTick >= mDataBlock->lifetime)   
   {   
      deleteObject();   
      return;   
   }   
   else if (mHidden == true)   
      return;   
  
    if (mDataBlock->beamEnabled && mDataBlock->beamPulse)   
    {   
        if (mSourceObject)   
        {   
            MatrixF muzzleTrans;   
            mSourceObject->getMuzzleTransform(mSourceObjectSlot, &muzzleTrans);   
            muzzleTrans.getColumn(3, &mMuzzlePosition);   
  
            muzzleTrans.getColumn(1, &mMuzzleVector);   
            mEndPosition = mMuzzleVector * mRange;   
            mEndPosition += mMuzzlePosition;   
  
            mSourceObject->disableCollision();   
  
            RayInfo rInfo;   
            if (getContainer()->castRay(mMuzzlePosition, mEndPosition, csmDynamicCollisionMask | csmStaticCollisionMask, &rInfo) == true)    
            {   
                mEndPosition = rInfo.point;   
            }   
            mSourceObject->enableCollision();   
  
            mMuzzleVelocity = mMuzzleVector * mDataBlock->muzzleVelocity;;   
        }   
        mCurrPosition = mMuzzlePosition + mMuzzleVelocity * (F32(mCurrTick) * (F32(TickMs) / 1000.0f));   
        mCurrVelocity = mMuzzleVelocity;   
    }   
  
   // ... otherwise, we have to do some simulation work.   
   RayInfo rInfo;
   RayInfo pierceInfo;
   RayInfo playerRearInfo;
   TriRayInfo rTriInfo;

   Point3F oldPosition;
   Point3F newPosition;

   Point3F secPoint;
   Point3F secNormal;
   Point3F secImpactNormal;

   oldPosition = mCurrPosition;

   F32 dT = F32(TickMs) * 0.001f; // 1/1000.0 division avoidance
   newPosition = oldPosition + mCurrVelocity * dT;

   Point3F savedOldPosition = oldPosition;
   Point3F savedCurrVelocity = mCurrVelocity;  
   if (bool(mSourceObject))   
      mSourceObject->disableCollision();   
  
   if (getContainer()->castRay(oldPosition, newPosition, csmDynamicCollisionMask | csmStaticCollisionMask, &rInfo) == true)   
   {   
      if(isServerObject() && (rInfo.object->getType() & csmStaticCollisionMask) == 0)   
         setMaskBits(BounceMask);   
  
      if(mCurrTick > mDataBlock->armingDelay)   
      {   
         MatrixF xform(true);   
         xform.setColumn(3, rInfo.point);   
         setTransform(xform);   
         mCurrPosition    = rInfo.point;   
         mCurrVelocity    = Point3F(0, 0, 0); 

         Point3F impactNormal(mCurrPosition);
		 impactNormal -= savedOldPosition;
		 impactNormal.normalize();
  
         U32 objectType = rInfo.object->getType();   

		 transDecal = false;

  		 MatInstance* matInst = dynamic_cast< MatInstance* >(rInfo.material);
		 ShapeBase * rayShape = dynamic_cast<ShapeBase *>(rInfo.object);
		 
		 if (matInst != NULL)
		 {
			 pMatType = matInst->getMaterial()->bulletDecal;
			 if(pMatType < 0)
				 pMatType = 0;

			 useDecal = true;

			 if(rayShape)
				 transDecal = true;
		 }
		 else
		 {
			 if(rayShape)
			 {
				 Point3F triEnd = mCurrPosition;
				 triEnd += savedCurrVelocity;
				 if(rayShape->castRay(mCurrPosition, triEnd, &rTriInfo))
				 {
					 if(rTriInfo.distance > 0)
						 rInfo.point = rInfo.point + (rInfo.normal * rTriInfo.distance);
					 
					 matInst = dynamic_cast< MatInstance* >(rTriInfo.material);
					 if (matInst != NULL)
					 {
						 pMatType = matInst->getMaterial()->bulletDecal;
						 if(pMatType < 0)  
							 pMatType = 0;
						 
						 transDecal = false;
						 useDecal = false;
					 }
				 }
			 }
			 
			 //Lets try a TriRay cast in case it is a TSStatic not using PolySoup
			 else if( rInfo.object->getTypeMask() & StaticTSObjectType )
			 {
				 TSStatic * rayStatic = dynamic_cast<TSStatic *>(rInfo.object);
				 if(rayStatic)
				 {
					 if(rayStatic->castRay(savedOldPosition, newPosition, &rTriInfo))
					 {
						 matInst = dynamic_cast< MatInstance* >(rTriInfo.material);
						 if (matInst != NULL)
						 {
							 pMatType = matInst->getMaterial()->bulletDecal;

							 if(pMatType < 0)
								 pMatType = 0;

							 useDecal = true;
						 }
					 }
				 }
			 }
		 }

		 if( rInfo.object->getTypeMask() & (InteriorObjectType | StaticShapeObjectType | StaticTSObjectType))
		 {
			 if(armorPiercing)
			 {
				 Point3F velocityNormal = savedCurrVelocity;
				 velocityNormal.normalize();

				 Point3F mPiercePosition = mCurrPosition + velocityNormal * mDataBlock->mPierceWidth;

				 if (getContainer()->castRay(mPiercePosition, mCurrPosition, InteriorObjectType | StaticObjectType, &pierceInfo) == true)
				 {
					 MatInstance* matInstP = dynamic_cast< MatInstance* >(pierceInfo.material);
					 if(matInstP != NULL)
					 {
						 U32 pierceMatType = matInstP->getMaterial()->bulletDecal;
						 if(pierceMatType < 0)
							 pierceMatType = 0;
						 if(pierceMatType != 6)
						 {
							 addPierceDecal(pierceInfo.point, pierceInfo.normal, impactNormal, objectType, pierceMatType);
							 onPierce(pierceInfo.point, savedCurrVelocity);
						 }
					 }
				 }
			 }
		 }
		 else if( rInfo.object->getTypeMask() & PlayerObjectType )
		 {
			 //Thanks to help from Phillip O'Shea
			 Player * playerShape = dynamic_cast<Player *>(rInfo.object);
			 Point3F velocityNormal = savedCurrVelocity;
			 velocityNormal.normalize();
			 
			 const Box3F playerBox = playerShape->getObjBox();
			 const Point3F playerBoxSize(playerBox.len_x(), playerBox.len_y(), playerBox.len_z());
			 Point3F positionOffset = playerBoxSize;
			 positionOffset.convolve(velocityNormal);
			 mBloodRearPosition = mCurrPosition + positionOffset;
			 
			 mBloodObjPosition = mBloodRearPosition + velocityNormal * mDataBlock->mPlayerRearScanDist;

			 bool goreMode = Con::getBoolVariable("$pref::Player::GoreOn");
           
			 if (getContainer()->castRay(mBloodRearPosition, mBloodObjPosition, csmStaticCollisionMask, &playerRearInfo) == true)
			 {
				 Point3F secImpactNormal(playerRearInfo.point);
				 secImpactNormal-=mBloodRearPosition;
				 secImpactNormal.normalize();

				 if(goreMode)
					 addPierceDecal(playerRearInfo.point, playerRearInfo.normal, secImpactNormal, PlayerObjectType, pMatType);
			 }
		 }
         if(mSourceObject)   
            mSourceObject->enableCollision();   
  
         onCollision(rInfo.point, rInfo.normal, rInfo.object);   
         explode(rInfo.point, rInfo.normal, impactNormal, objectType, pMatType, transDecal, rInfo.object );   
      }   
      else  
      {   
         if(mDataBlock->isBallistic)   
         {   
            Point3F bounceVel = mCurrVelocity - rInfo.normal * (mDot( mCurrVelocity, rInfo.normal ) * 2.0);;   
            mCurrVelocity = bounceVel;   
  
            Point3F tangent = bounceVel - rInfo.normal * mDot(bounceVel, rInfo.normal);   
            mCurrVelocity  -= tangent * mDataBlock->bounceFriction;   
  
            mCurrVelocity *= mDataBlock->bounceElasticity;   
  
            F32 timeLeft = 1.0f - rInfo.t;   
            oldPosition = rInfo.point + rInfo.normal * 0.05f;   
            newPosition = oldPosition + (mCurrVelocity * ((timeLeft/1000.0f) * TickMs));   
         }   
      }   
   }   
  
  if (bool(mSourceObject))   
     mSourceObject->enableCollision();   
  
   if(isClientObject())   
   {   
      emitParticles(mCurrPosition, newPosition, mCurrVelocity, TickMs);   
      updateSound();   
   }   
  
   mCurrDeltaBase = newPosition;   
   mCurrBackDelta = mCurrPosition - newPosition;   
   mCurrPosition = newPosition;   
  
   MatrixF xform(true);   
   xform.setColumn(3, mCurrPosition);   
   setTransform(xform);   
}   
  
//--------------------------------------------------------------------------   
bool EnergyProjectile::prepRenderImage(SceneState* state, const U32 stateKey,   
                                       const U32 /*startZone*/, const bool /*modifyBaseState*/)   
{   
   // Return if last state.   
   if (isLastState(state, stateKey)) return false;   
   // Set Last State.   
   setLastState(state, stateKey);   
  
   if (mHidden == true || mFadeValue <= (1.0/255.0))   
      return false;   
  
   // Is Object Rendered?   
   if (state->isObjectRendered(this))   
   {   
        ObjectRenderInst *ri = gRenderInstManager->allocInst<ObjectRenderInst>();   
        ri->mRenderDelegate = mRenderDelegate;   
        ri->state = state;   
        ri->type = RenderPassManager::RIT_ObjectTranslucent;   
        ri->translucent = true;   
        ri->calcSortPoint(this, state->getCameraPosition());   
        gRenderInstManager->addInst( ri );   
   }   
  
   return false;   
  
}   
  
void EnergyProjectile::renderObject(ObjectRenderInst *ri, BaseMatInstance* overrideMat)   
{
	if (mDataBlock->updateToMuzzle)
	{
		MatrixF muzzleTrans;
		mSourceObject->getMuzzleTransform(mSourceObjectSlot, &muzzleTrans);
		muzzleTrans.getColumn(3, &mMuzzlePosition);
	}
	
	//SceneState* state = ri->state;   
    MatrixF projection = GFX->getProjectionMatrix();   
    RectI viewport = GFX->getViewport();   
  
    GFX->setViewport(viewport);   
    GFX->setProjectionMatrix(projection);   
  
    // set up the graphics   
    if (mBlendInvSrcAlphaSB.isNull())   
    {   
        GFXStateBlockDesc desc;   
        desc.setCullMode( GFXCullNone );   
        desc.setZEnable(false);   
        desc.zWriteEnable = false;   
        desc.samplersDefined = true;   
        desc.samplers[0].textureColorOp = GFXTOPModulate;   
        desc.samplers[1].textureColorOp = GFXTOPDisable;   
        desc.setBlend(true, GFXBlendSrcAlpha, GFXBlendInvSrcAlpha);   
        mBlendInvSrcAlphaSB = GFX->createStateBlock(desc);   
  
        desc.samplers[0].textureColorOp = GFXTOPDisable;   
        mBlendSB = GFX->createStateBlock(desc);   
    }   
    GFX->setStateBlock(mBlendInvSrcAlphaSB);   
  
    S32 thisTime = Sim::getCurrentTime();   
    S32 timeDelta = thisTime - mLastTime;   
    if (timeDelta > mDataBlock->interval)   
    {   
        if (mBeamNumTextures > 0)   
        {   
            mBeamIndex ++;   
            if (mBeamIndex >= mBeamNumTextures)   
                mBeamIndex = 0;   
        }   
  
        if (mSparkNumTextures > 0)   
        {   
            mSparkIndex ++;   
            if (mSparkIndex >= mSparkNumTextures)   
                mSparkIndex = 0;   
        }   
        mSparkRadius += mDataBlock->sparkStep;   
        mSparkRotation += mDataBlock->sparkRotationStep;   
  
        mLastTime = thisTime;   
    }   
  
    // Select the objects' texture.   
    GFX->disableShaders();   
    GFX->setupGenericShaders( GFXDevice::GSModColorTexture );   
  
    if (mDataBlock->beamEnabled && mBeamNumTextures > 0)   
    {   
        // Set Colour/Alpha.   
        GFX->setTexture(0, mBeamTextureHandles[mBeamIndex]);   
  
        if (mDataBlock->beamPulse)   
        {   
            RenderBeamSegment(mMuzzlePosition, mCurrPosition, mDataBlock->beamStartRadius, mDataBlock->beamMidRadius, 0.0, 0.5 );   
            RenderBeamSegment(mCurrPosition, mEndPosition, mDataBlock->beamMidRadius, mDataBlock->beamEndRadius, 0.5, 1.0 );   
        }   
        else  
        {   
            Point3F dirV = mCurrVelocity;   
            dirV.normalize();   
  
            F32 clientDist = (mInitialPosition - mCurrPosition).len();   
            F32 beamFrontLength = mDataBlock->beamFrontSegmentLength;   
            if (beamFrontLength > clientDist)   
                beamFrontLength = clientDist;   
            F32 beamBackLength = mDataBlock->beamBackSegmentLength;   
            if (beamBackLength > clientDist)   
                beamBackLength = clientDist;   
  
            Point3F posFrontMod = dirV * beamFrontLength;   
            Point3F posBackMod = dirV * beamBackLength;   
  
            RenderBeamSegment(mCurrPosition - posBackMod, mCurrPosition, mDataBlock->beamStartRadius, mDataBlock->beamMidRadius, 0.0, 0.5 );   
            RenderBeamSegment(mCurrPosition, mCurrPosition + posFrontMod, mDataBlock->beamMidRadius, mDataBlock->beamEndRadius, 0.5, 1.0 );   
        }   
  
    }   
  
    if (mDataBlock->sparkEnabled && mSparkNumTextures > 0 && mSparkRadius > 0.0f)   
    {   
        // Initialize points with basic info   
        Point3F points[4];   
        points[0] = Point3F(-mSparkRadius, 0.0, -mSparkRadius);   
        points[1] = Point3F( mSparkRadius, 0.0, -mSparkRadius);   
        points[2] = Point3F( mSparkRadius, 0.0,  mSparkRadius);   
        points[3] = Point3F(-mSparkRadius, 0.0,  mSparkRadius);   
  
        GFX->setTexture(0, mSparkTextureHandles[mSparkIndex]);   
        // Get info we need to adjust points   
        MatrixF camView = GFX->getWorldMatrix();   
        camView.transpose();   
  
        F32 sy, cy;   
        mSinCos(mDegToRad(mSparkRotation), sy, cy);   
  
        // Finalize points   
        for(int i = 0; i < 4; i++)   
        {   
            // rotate   
            points[i].set(cy * points[i].x - sy * points[i].z, 0.0, sy * points[i].x + cy * points[i].z);   
            // align with camera   
            camView.mulP(points[i]);   
            // offset   
            points[i] += mCurrPosition;   
        }   
  
        PrimBuild::color4f(1,1,1,1);   
        PrimBuild::begin( GFXTriangleFan, 4 );   
        PrimBuild::texCoord2f(0, 0);   
        PrimBuild::vertex3fv(points[0]);   
        PrimBuild::texCoord2f(1, 0);   
        PrimBuild::vertex3fv(points[1]);   
        PrimBuild::texCoord2f(1, 1);   
        PrimBuild::vertex3fv(points[2]);   
        PrimBuild::texCoord2f(0, 1);   
        PrimBuild::vertex3fv(points[3]);   
        PrimBuild::end();   
    }   
  
    GFX->disableShaders();   
}   
  
  
void EnergyProjectile::RenderBeamSegment( Point3F pStart, Point3F pEnd, F32 startRadius, F32 endRadius, F32 vStart, F32 vEnd )   
{   
    Point3F dirV = mCurrVelocity;   
    dirV.normalize();   
  
    MatrixF orient = MathUtils::createOrientFromDir( dirV );   
       
    Point3F sPt1, sPt2, ePt1, ePt2;   
  
    PrimBuild::color4f(1,1,1,1);   
  
    {   
        sPt1 = Point3F(startRadius,0,0);   
        sPt2 = Point3F(-startRadius,0,0);   
  
        orient.mulV( sPt1 );   
        sPt1 += pStart;   
        orient.mulV( sPt2 );   
        sPt2 += pStart;   
  
        ePt1 = Point3F(endRadius,0,0);   
        ePt2 = Point3F(-endRadius,0,0);   
  
        orient.mulV( ePt1 );   
        ePt1 += pEnd;   
        orient.mulV( ePt2 );   
        ePt2 += pEnd;   
  
        PrimBuild::begin(GFXTriangleFan, 4);   
        PrimBuild::texCoord2f(0, vStart);   
        PrimBuild::vertex3f(sPt1.x, sPt1.y, sPt1.z);   
        PrimBuild::texCoord2f(1, vStart);   
        PrimBuild::vertex3f(sPt2.x, sPt2.y, sPt2.z);   
        PrimBuild::texCoord2f(1, vEnd);   
        PrimBuild::vertex3f(ePt2.x, ePt2.y, ePt2.z);   
        PrimBuild::texCoord2f(0, vEnd);   
        PrimBuild::vertex3f(ePt1.x, ePt1.y, ePt1.z);   
        PrimBuild::end();   
    }   
  
    {   
        sPt1 = Point3F(0,0,startRadius);   
        sPt2 = Point3F(0,0,-startRadius);   
  
        orient.mulV( sPt1 );   
        sPt1 += pStart;   
        orient.mulV( sPt2 );   
        sPt2 += pStart;   
  
        ePt1 = Point3F(0,0,endRadius);   
        ePt2 = Point3F(0,0,-endRadius);   
  
        orient.mulV( ePt1 );   
        ePt1 += pEnd;   
        orient.mulV( ePt2 );   
        ePt2 += pEnd;   
  
        PrimBuild::begin(GFXTriangleFan, 4);   
        PrimBuild::texCoord2f(0, vStart);   
        PrimBuild::vertex3f(sPt1.x, sPt1.y, sPt1.z);   
        PrimBuild::texCoord2f(1, vStart);   
        PrimBuild::vertex3f(sPt2.x, sPt2.y, sPt2.z);   
        PrimBuild::texCoord2f(1, vEnd);   
        PrimBuild::vertex3f(ePt2.x, ePt2.y, ePt2.z);   
        PrimBuild::texCoord2f(0, vEnd);   
        PrimBuild::vertex3f(ePt1.x, ePt1.y, ePt1.z);   
        PrimBuild::end();   
    }   
  
  
    {   
        sPt1 = Point3F(startRadius,0,startRadius);   
        sPt2 = Point3F(-startRadius,0,-startRadius);   
  
        orient.mulV( sPt1 );   
        sPt1 += pStart;   
        orient.mulV( sPt2 );   
        sPt2 += pStart;   
  
        ePt1 = Point3F(endRadius,0,endRadius);   
        ePt2 = Point3F(-endRadius,0,-endRadius);   
  
        orient.mulV( ePt1 );   
        ePt1 += pEnd;   
        orient.mulV( ePt2 );   
        ePt2 += pEnd;   
  
        PrimBuild::begin(GFXTriangleFan, 4);   
        PrimBuild::texCoord2f(0, vStart);   
        PrimBuild::vertex3f(sPt1.x, sPt1.y, sPt1.z);   
        PrimBuild::texCoord2f(1, vStart);   
        PrimBuild::vertex3f(sPt2.x, sPt2.y, sPt2.z);   
        PrimBuild::texCoord2f(1, vEnd);   
        PrimBuild::vertex3f(ePt2.x, ePt2.y, ePt2.z);   
        PrimBuild::texCoord2f(0, vEnd);   
        PrimBuild::vertex3f(ePt1.x, ePt1.y, ePt1.z);   
        PrimBuild::end();   
    }   
  
    {   
        sPt1 = Point3F(startRadius,0,-startRadius);   
        sPt2 = Point3F(-startRadius,0,startRadius);   
  
        orient.mulV( sPt1 );   
        sPt1 += pStart;   
        orient.mulV( sPt2 );   
        sPt2 += pStart;   
  
        ePt1 = Point3F(endRadius,0,-endRadius);   
        ePt2 = Point3F(-endRadius,0,endRadius);   
  
        orient.mulV( ePt1 );   
        ePt1 += pEnd;   
        orient.mulV( ePt2 );   
        ePt2 += pEnd;   
  
        PrimBuild::begin(GFXTriangleFan, 4);   
        PrimBuild::texCoord2f(0, vStart);   
        PrimBuild::vertex3f(sPt1.x, sPt1.y, sPt1.z);   
        PrimBuild::texCoord2f(1, vStart);   
        PrimBuild::vertex3f(sPt2.x, sPt2.y, sPt2.z);   
        PrimBuild::texCoord2f(1, vEnd);   
        PrimBuild::vertex3f(ePt2.x, ePt2.y, ePt2.z);   
        PrimBuild::texCoord2f(0, vEnd);   
        PrimBuild::vertex3f(ePt1.x, ePt1.y, ePt1.z);   
        PrimBuild::end();   
    }   
}
