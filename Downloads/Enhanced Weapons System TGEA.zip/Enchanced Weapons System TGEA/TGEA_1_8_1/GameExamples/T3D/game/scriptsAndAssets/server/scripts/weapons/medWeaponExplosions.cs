//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//Medium Sized Weapon explosions for use in all weapons
//-----------------------------------------------------------------------------

datablock ParticleData(medSplashMist)
{
   detectCollisions = false;
   killedByCollision = false;
   colDetectDistAdj = 1.0;
   elasticity = 0.8;
   friction = 0.5;
   dragCoefficient      = 2.0;
   gravityCoefficient   = -0.05;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 400;
   lifetimeVarianceMS   = 100;
   useInvAlpha          = false;
   spinRandomMin        = -90.0;
   spinRandomMax        = 500.0;
   textureName          = "~/data/shapes/weapons/crossbow/splash";
   
   colors[0]     = "0.7 0.8 1.0 1.0";
   colors[1]     = "0.7 0.8 1.0 0.5";
   colors[2]     = "0.7 0.8 1.0 0.0";
   
   sizes[0]      = 0.5;
   sizes[1]      = 0.5;
   sizes[2]      = 0.8;
   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(medSplashMistEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;
   ejectionVelocity = 3.0;
   velocityVariance = 2.0;
   ejectionOffset   = 0.0;
   thetaMin         = 85;
   thetaMax         = 85;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   lifetimeMS       = 250;
   particles = "medSplashMist";
};

datablock ParticleData( medSplashParticle )
{
   detectCollisions = false;
   killedByCollision = false;
   colDetectDistAdj = 1.0;
   elasticity = 0.8;
   friction = 0.5;
   dragCoefficient      = 1;
   gravityCoefficient   = 0.2;
   inheritedVelFactor   = 0.2;
   constantAcceleration = -0.0;
   lifetimeMS           = 600;
   lifetimeVarianceMS   = 0;
   colors[0]     = "0.7 0.8 1.0 1.0";
   colors[1]     = "0.7 0.8 1.0 0.5";
   colors[2]     = "0.7 0.8 1.0 0.0";
   sizes[0]      = 0.5;
   sizes[1]      = 0.5;
   sizes[2]      = 0.5;
   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData( medSplashEmitter )
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 3;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 60;
   thetaMax         = 80;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles  = true;
   lifetimeMS       = 100;
   particles = "medSplashParticle";
};

datablock SplashData(medSplash)
{
   numSegments = 15;
   ejectionFreq = 15;
   ejectionAngle = 40;
   ringLifetime = 0.5;
   lifetimeMS = 300;
   velocity = 4.0;
   startRadius = 0.0;
   acceleration = -3.0;
   texWrap = 5.0;

   sizeX = 1.0;
   sizeY = 1.0;

   texture = "~/data/shapes/weapons/crossbow/splash";

   emitter[0] = medSplashEmitter;
   emitter[1] = medSplashMistEmitter;

   colors[0] = "0.7 0.8 1.0 0.0";
   colors[1] = "0.7 0.8 1.0 0.3";
   colors[2] = "0.7 0.8 1.0 0.7";
   colors[3] = "0.7 0.8 1.0 0.0";
   times[0] = 0.0;
   times[1] = 0.4;
   times[2] = 0.8;
   times[3] = 1.0;
};

datablock ParticleData(medAmmoParticle)
{
   detectCollisions = false;
   killedByCollision = false;
   colDetectDistAdj = 1.0;
   elasticity = 0.8;
   friction = 0.5;
   textureName          = "~/data/shapes/particles/smoke";
   dragCoefficient     = 0.0;
   gravityCoefficient   = -0.1;   // rises slowly
   inheritedVelFactor   = 0.0;
   lifetimeMS           = 150;
   lifetimeVarianceMS   = 10;   // ...more or less
   useInvAlpha = false;
   spinRandomMin = -30.0;
   spinRandomMax = 30.0;

   colors[0]     = "0.1 0.1 0.1 1.0";
   colors[1]     = "0.1 0.1 0.1 1.0";
   colors[2]     = "0.1 0.1 0.1 0";

   sizes[0]      = 0.15;
   sizes[1]      = 0.20;
   sizes[2]      = 0.25;

   times[0]      = 0.0;
   times[1]      = 0.3;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(medAmmoEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;

   ejectionVelocity = 0.10;
   velocityVariance = 0.10;

   thetaMin         = 0.0;
   thetaMax         = 90.0;  

   particles = medAmmoParticle;
};

//Bubble particles
//-----------------------------------------------------------------------------
datablock ParticleData(medBubbleParticle)
{
   detectCollisions = false;
   killedByCollision = false;
   colDetectDistAdj = 1.0;
   elasticity = 0.8;
   friction = 0.5;
   textureName          = "~/data/shapes/particles/bubble";
   dragCoefficient      = 0.0;
   gravityCoefficient   = -0.25;   // rises slowly
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1500;
   lifetimeVarianceMS   = 600;    // ...more or less
   useInvAlpha          = false;
   spinRandomMin        = -100.0;
   spinRandomMax        = 100.0;

   colors[0]     = "0.7 0.8 1.0 0.4";
   colors[1]     = "0.7 0.8 1.0 1.0";
   colors[2]     = "0.7 0.8 1.0 0.0";

   sizes[0]      = 0.2;
   sizes[1]      = 0.2;
   sizes[2]      = 0.2;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(medAmmoBubbleEmitter)
{
   ejectionPeriodMS = 9;
   periodVarianceMS = 0;

   ejectionVelocity = 1.0;
   ejectionOffset   = 0.1;
   velocityVariance = 0.5;

   thetaMin         = 0.0;
   thetaMax         = 80.0;

   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;  

   particles = medBubbleParticle;
};

//Explosion Debris
//-----------------------------------------------------------------------------

// Debris "spark" explosion
datablock ParticleData(medDebrisSpark)
{
   detectCollisions = false;
   killedByCollision = false;
   colDetectDistAdj = 1.0;
   elasticity = 0.8;
   friction = 0.5;
   textureName          = "~/data/shapes/particles/fire";
   dragCoefficient      = 0;
   gravityCoefficient   = 0.0;
   windCoefficient      = 0;
   inheritedVelFactor   = 0.5;
   constantAcceleration = 0.0;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 50;
   spinRandomMin = -90.0;
   spinRandomMax =  90.0;
   useInvAlpha   = false;

   colors[0]     = "0.8 0.2 0 1.0";
   colors[1]     = "0.8 0.2 0 1.0";
   colors[2]     = "0 0 0 0.0";

   sizes[0]      = 0.2;
   sizes[1]      = 0.3;
   sizes[2]      = 0.1;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(medDebrisSparkEmitter)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 0;
   ejectionVelocity = 0.5;
   velocityVariance = 0.25;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles  = false;
   lifetimeMS       = 300;
   particles = "medDebrisSpark";
};

datablock ExplosionData(medDebrisExplosion)
{
   emitter[0] = medDebrisSparkEmitter;

   // Turned off..
   shakeCamera = false;
   impulseRadius = 0;
   lightStartRadius = 0;
   lightEndRadius = 0;
};

// Debris smoke trail
datablock ParticleData(medDebrisTrail)
{
   detectCollisions = false;
   killedByCollision = false;
   colDetectDistAdj = 1.0;
   elasticity = 0.8;
   friction = 0.5;
   textureName          = "~/data/shapes/particles/fire";
   dragCoefficient      = 1;
   gravityCoefficient   = 0;
   inheritedVelFactor   = 0;
   windCoefficient      = 0;
   constantAcceleration = 0;
   lifetimeMS           = 800;
   lifetimeVarianceMS   = 100;
   spinSpeed     = 0;
   spinRandomMin = -90.0;
   spinRandomMax =  90.0;
   useInvAlpha   = true;

   colors[0]     = "0.8 0.3 0.0 1.0";
   colors[1]     = "0.1 0.1 0.1 0.7";
   colors[2]     = "0.1 0.1 0.1 0.0";

   sizes[0]      = 0.2;
   sizes[1]      = 0.3;
   sizes[2]      = 0.4;

   times[0]      = 0.1;
   times[1]      = 0.2;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(medDebrisTrailEmitter)
{
   ejectionPeriodMS = 30;
   periodVarianceMS = 0;
   ejectionVelocity = 0.0;
   velocityVariance = 0.0;
   ejectionOffset   = 0.0;
   thetaMin         = 170;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   //overrideAdvance = false;
   //orientParticles  = true;
   lifetimeMS       = 5000;
   particles = "medDebrisTrail";
};

// Debris object
datablock DebrisData(medExplosionDebris)
{
   shapeFile = "~/data/shapes/weapons/crossbow/debris.dts";
   //emitters = "medDebrisTrailEmitter";
   //explosion = medDebrisExplosion;
   
   elasticity = 0.6;
   friction = 0.5;
   numBounces = 1;
   bounceVariance = 1;
   explodeOnMaxBounce = true;
   staticOnMaxBounce = false;
   snapOnMaxBounce = false;
   minSpinSpeed = 0;
   maxSpinSpeed = 700;
   render2D = false;
   lifetime = 4;
   lifetimeVariance = 0.4;
   velocity = 5;
   velocityVariance = 0.5;
   fade = false;
   useRadiusMass = true;
   baseRadius = 0.3;
   gravModifier = 0.5;
   terminalVelocity = 6;
   ignoreWater = true;
};
datablock DebrisData(medGlassDebris)
{
   shapeFile = "~/data/shapes/weapons/crossbow/debris.dts";
   //emitters = "medDebrisTrailEmitter";
   //explosion = medDebrisExplosion;
   
   elasticity = 0.6;
   friction = 0.5;
   numBounces = 1;
   bounceVariance = 1;
   explodeOnMaxBounce = true;
   staticOnMaxBounce = false;
   snapOnMaxBounce = false;
   minSpinSpeed = 0;
   maxSpinSpeed = 700;
   render2D = false;
   lifetime = 4;
   lifetimeVariance = 0.4;
   velocity = 5;
   velocityVariance = 0.5;
   fade = false;
   useRadiusMass = true;
   baseRadius = 0.3;
   gravModifier = 0.2;
   terminalVelocity = 6;
   ignoreWater = true;
};
//Ammo Explosion
//-----------------------------------------------------------------------------
datablock ParticleData(medExplosionSmoke)
{
   detectCollisions = false;
   killedByCollision = false;
   colDetectDistAdj = 1.0;
   elasticity = 0.8;
   friction = 0.5;
   textureName          = "~/data/shapes/particles/smoke";
   dragCoeffiecient     = 100.0;
   gravityCoefficient   = 0;
   inheritedVelFactor   = 0.25;
   constantAcceleration = -0.30;
   lifetimeMS           = 1200;
   lifetimeVarianceMS   = 300;
   useInvAlpha =  true;
   spinRandomMin = -80.0;
   spinRandomMax =  80.0;

   colors[0]     = "0.56 0.36 0.26 1.0";
   colors[1]     = "0.2 0.2 0.2 1.0";
   colors[2]     = "0.0 0.0 0.0 0.0";

   sizes[0]      = 4.0;
   sizes[1]      = 2.5;
   sizes[2]      = 1.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(medExplosionSmokeEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 4;
   velocityVariance = 0.5;
   thetaMin         = 0.0;
   thetaMax         = 180.0;
   lifetimeMS       = 250;
   particles = "medExplosionSmoke";
};

datablock ParticleData(medExplosionBubble)
{
   detectCollisions = false;
   killedByCollision = false;
   colDetectDistAdj = 1.0;
   elasticity = 0.8;
   friction = 0.5;
   textureName          = "~/data/shapes/particles/bubble";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.25;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1500;
   lifetimeVarianceMS   = 600;
   useInvAlpha          = false;
   spinRandomMin        = -100.0;
   spinRandomMax        =  100.0;

   colors[0]     = "0.7 0.8 1.0 0.4";
   colors[1]     = "0.7 0.8 1.0 0.4";
   colors[2]     = "0.7 0.8 1.0 0.0";

   sizes[0]      = 0.3;
   sizes[1]      = 0.3;
   sizes[2]      = 0.3;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};


datablock ParticleEmitterData(medExplosionBubbleEmitter)
{
   ejectionPeriodMS = 9;
   periodVarianceMS = 0;
   ejectionVelocity = 1;
   ejectionOffset   = 0.1;
   velocityVariance = 0.5;
   thetaMin         = 0.0;
   thetaMax         = 80.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "medExplosionBubble";
};

datablock ParticleData(medExplosionSparks)
{
   detectCollisions = false;
   killedByCollision = false;
   colDetectDistAdj = 1.0;
   elasticity = 0.8;
   friction = 0.5;
   textureName          = "~/data/shapes/particles/spark";
   dragCoefficient      = 1;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 350;

   colors[0]     = "0.60 0.40 0.30 1.0";
   colors[1]     = "0.60 0.40 0.30 1.0";
   colors[2]     = "1.0 0.40 0.30 0.0";

   sizes[0]      = 0.25;
   sizes[1]      = 0.15;
   sizes[2]      = 0.15;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};


datablock ParticleEmitterData(medExplosionSparkEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 1;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles  = true;
   lifetimeMS       = 100;
   particles = "medExplosionSparks";
};

datablock ParticleData(medExplosionWaterSparks)
{
   detectCollisions = false;
   killedByCollision = false;
   colDetectDistAdj = 1.0;
   elasticity = 0.8;
   friction = 0.5;
   textureName          = "~/data/shapes/particles/bubble";
   dragCoefficient      = 0;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 350;

   colors[0]     = "0.4 0.4 1.0 1.0";
   colors[1]     = "0.4 0.4 1.0 1.0";
   colors[2]     = "0.4 0.4 1.0 0.0";

   sizes[0]      = 0.5;
   sizes[1]      = 0.5;
   sizes[2]      = 0.5;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(medExplosionWaterSparkEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 0;
   ejectionVelocity = 4;
   velocityVariance = 4;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   orientParticles  = true;
   lifetimeMS       = 200;
   particles = "medExplosionWaterSparks";
};

datablock ExplosionData(medSubExplosion1)
{
   offset = 0;
   emitter[0] = medExplosionSmokeEmitter;
   emitter[1] = medExplosionSparkEmitter;
};

datablock ExplosionData(medSubExplosion2)
{
   offset = 1.0;
   emitter[0] = medExplosionSmokeEmitter;
   emitter[1] = medExplosionSparkEmitter;
};

datablock ExplosionData(medSubWaterExplosion1)
{
   delayMS   = 100;
   offset    = 1.2;
   playSpeed = 1.5;

   emitter[0] = medExplosionBubbleEmitter;
   emitter[1] = medExplosionWaterSparkEmitter;
   
   sizes[0] = "0.75 0.75 0.75";
   sizes[1] = "1.0 1.0 1.0";
   sizes[2] = "0.5 0.5 0.5";
   times[0] = 0.0;
   times[1] = 0.5;
   times[2] = 1.0;
};

datablock ExplosionData(medSubWaterExplosion2)
{
   delayMS   = 50;
   offset    = 1.2;
   playSpeed = 0.75;

   emitter[0] = medExplosionBubbleEmitter;
   emitter[1] = medExplosionWaterSparkEmitter;

   sizes[0] = "1.5 1.5 1.5";
   sizes[1] = "1.5 1.5 1.5";
   sizes[2] = "1.0 1.0 1.0";
   times[0] = 0.0;
   times[1] = 0.5;
   times[2] = 1.0;
};



//Water Explosions
//-----------------------------------------------------------------------------
datablock ExplosionData(medWaterExplosion)
{
   soundProfile = medExplosionSound;

   // Volume particles
   particleEmitter = medExplosionBubbleEmitter;
   particleDensity = 375;
   particleRadius = 2;


   // Point emission
   emitter[0] = medExplosionBubbleEmitter;
   emitter[1] = medExplosionWaterSparkEmitter;


   // Sub explosion objects
   subExplosion[0] = medSubWaterExplosion1;
   subExplosion[1] = medSubWaterExplosion2;
   
   // Camera Shaking
   shakeCamera = true;
   camShakeFreq = "8.0 9.0 7.0";
   camShakeAmp = "3.0 3.0 3.0";
   camShakeDuration = 1.3;
   camShakeRadius = 20.0;

   // Exploding debris
   debris = medExplosionDebris;
   debrisThetaMin = 0;
   debrisThetaMax = 60;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisNum = 6;
   debrisNumVariance = 2;
   debrisVelocity = 0.5;
   debrisVelocityVariance = 0.2;
   
   // Impulse
   impulseRadius = 10;
   impulseForce = 15;

   // Dynamic light
   //lightStartRadius = 6;
   //lightEndRadius = 3;
   //lightStartColor = "0 0.5 0.5";
   //lightEndColor = "0 0 0";
};


//Metal Explosions
//-----------------------------------------------------------------------------
datablock ExplosionData(medMetalExplosion)
{
   soundProfile = medExplosionSound;
   lifeTimeMS = 1200;

   // Volume particles
   //particleEmitter = medExplosionFireEmitter;
   //particleDensity = 75;
   //particleRadius = 2;

   // Point emission
   //emitter[0] = medExplosionSmokeEmitter;
   //emitter[1] = medExplosionSparkEmitter;

   // Sub explosion objects
   //subExplosion[0] = medSubExplosion1;
   //subExplosion[1] = medSubExplosion2;
   
   // Camera Shaking
   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Exploding debris
   debris = medExplosionDebris;
   debrisThetaMin = 0;
   debrisThetaMax = 60;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisNum = 6;
   debrisNumVariance = 2;
   debrisVelocity = 1;
   debrisVelocityVariance = 0.5;
   
   // Impulse
   impulseRadius = 10;
   impulseForce = 15;

   // Dynamic light
   //lightStartRadius = 6;
   //lightEndRadius = 3;
   //lightStartColor = "0.5 0.5 0";
   //lightEndColor = "0 0 0";
};
//Wood Explosions
//-----------------------------------------------------------------------------


//Glass Explosions
//-----------------------------------------------------------------------------
datablock ExplosionData(medGlassExplosion)
{
   soundProfile = medGlassShatterSound;
   lifeTimeMS = 1200;

   // Volume particles
   //particleEmitter = medExplosionFireEmitter;
   //particleDensity = 75;
   //particleRadius = 2;

   // Point emission
   //emitter[0] = medExplosionSmokeEmitter;
   //emitter[1] = medExplosionSparkEmitter;

   // Sub explosion objects
   //subExplosion[0] = medSubExplosion1;
   //subExplosion[1] = medSubExplosion2;
   
   // Camera Shaking
   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Exploding debris
   debris = medGlassDebris;
   debrisThetaMin = 0;
   debrisThetaMax = 60;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisNum = 6;
   debrisNumVariance = 2;
   debrisVelocity = 1;
   debrisVelocityVariance = 0.5;
   
   // Impulse
   impulseRadius = 10;
   impulseForce = 15;

   // Dynamic light
   //lightStartRadius = 6;
   //lightEndRadius = 3;
   //lightStartColor = "0.5 0.5 0";
   //lightEndColor = "0 0 0";
};
//Human Explosions
//-----------------------------------------------------------------------------
datablock ParticleData(medBloodParticle)
{
   detectCollisions = false;
   killedByCollision = false;
   colDetectDistAdj = 1.0;
   elasticity = 0.8;
   friction = 0.5;
   dragCoefficient = 0.0;
   gravityCoefficient = 0.7; // makes the particles fall fairly fast illusion of drip 
   inheritedVelFactor = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS = 300; // short don't need blood gush forever
   lifetimeVarianceMS = 50;
   useInvAlpha = true;
   spinRandomMin = -90.0;
   spinRandomMax = 90.0;
   textureName = "~/data/shapes/particles/spark";
   colors[0] = "0.5 0.0 0.0 0.0"; // This goes Red, Green , Blue, Alpha
   colors[1] = "0.5 0.0 0.0 0.4";
   colors[2] = "0.5 0.0 0.0 0.0";
   sizes[0] = 0.5; //Kept the size fairly small. Make it big if it's a rocket :)
   sizes[1] = 0.5;
   sizes[2] = 1.2;
   times[0] = 0.0;
   times[1] = 0.5;
   times[2] = 1.0;
};

datablock ParticleEmitterData(medPlayerImpactBlood)
{
   ejectionPeriodMS = 50;
   periodVarianceMS = 1;
   ejectionVelocity = 1.0;
   velocityVariance = 0.5;
   ejectionOffset = 0.0;
   thetaMin = 0;
   thetaMax = 35;
   overrideAdvance = false;
   particles = "medBloodParticle";
   lifetimeMS = 350; // Again no need to keep it going forever
};

datablock ExplosionData(medBloodExplosion)
{
   //soundProfile = medGlassShatterSound;
   lifeTimeMS = 1200;

   // Volume particles
   particleEmitter = medPlayerImpactBlood;
   particleDensity = 1;
   particleRadius = 0.01;

   // Point emission
   //emitter[0] = medExplosionSmokeEmitter;
   //emitter[1] = medExplosionSparkEmitter;

   // Sub explosion objects
   //subExplosion[0] = medSubExplosion1;
   //subExplosion[1] = medSubExplosion2;
   
   // Camera Shaking
   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Exploding debris
   //debris = medGlassDebris;
   //debrisThetaMin = 0;
   //debrisThetaMax = 60;
   //debrisPhiMin = 0;
   //debrisPhiMax = 360;
   //debrisNum = 6;
   //debrisNumVariance = 2;
   //debrisVelocity = 1;
   //debrisVelocityVariance = 0.5;
   
   // Impulse
   impulseRadius = 10;
   impulseForce = 15;

   // Dynamic light
   //lightStartRadius = 6;
   //lightEndRadius = 3;
   //lightStartColor = "0.5 0.5 0";
   //lightEndColor = "0 0 0";
};
//Terrain Explosions
//-----------------------------------------------------------------------------
