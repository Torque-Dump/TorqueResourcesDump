In this thread,

http://www.garagegames.com/community/forums/viewthread/94977

eb (via Logan) shared a bunch of max source files that can help serve as a Rosetta Stone for exporting complex max files into Torque (the same max files used in the Realm Wars demos, etc.)

When trying to export the buggy files as is in Max 9, you get the following vertex mismatch error:

http://www.mediabreeze.com/images/vertexmismatch.jpg

So I simply deleted the MultiRes modifier on all of the meshes in the file, and now it exports. 

Of course, since this car is around 3,000 polys, you will need some LOD for the mesh if you're doing a multiplayer game, which you can implement yourself. 

Any further suggestions are welcome. 

You can email me at: 
nmuta1@gmail.com

with any other helpful stuff or questions regarding this. 



