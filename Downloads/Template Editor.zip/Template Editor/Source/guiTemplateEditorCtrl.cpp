//-----------------------------------------------------------------------------
// Torque 3D
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "platform/platform.h"
#include "guiTemplateEditorCtrl.h"

#include "console/consoleTypes.h"
#include "sceneGraph/sceneGraph.h"
#include "collision/collision.h"
#include "math/util/frustum.h"
#include "gfx/gfxPrimitiveBuffer.h"
#include "gfx/gfxTextureHandle.h"
#include "gfx/gfxTransformSaver.h"
#include "gfx/gfxDrawUtil.h"
#include "gfx/primBuilder.h"
#include "T3D/gameConnection.h"
#include "gui/core/guiCanvas.h"
#include "gui/buttons/guiButtonCtrl.h"
#include "gui/worldEditor/undoActions.h"
#include "materials/materialDefinition.h"

#include "gfx/gfxDrawUtil.h"  


IMPLEMENT_CONOBJECT(GuiTemplateEditorCtrl);


GuiTemplateEditorCtrl::GuiTemplateEditorCtrl()
{
   mIsDirty = false;
}

GuiTemplateEditorCtrl::~GuiTemplateEditorCtrl()
{
   // nothing to do
}

void GuiTemplateEditorUndoAction::undo()
{
}

bool GuiTemplateEditorCtrl::onAdd()
{
   if( !Parent::onAdd() )
      return false;

   return true;
}

void GuiTemplateEditorCtrl::initPersistFields()
{
   Parent::initPersistFields();
}

void GuiTemplateEditorCtrl::onSleep()
{
   Parent::onSleep();
}

void GuiTemplateEditorCtrl::get3DCursor( GuiCursor *&cursor, 
                                       bool &visible, 
                                       const Gui3DMouseEvent &event_ )
{
   //cursor = mAddNodeCursor;
   //visible = false;
   
   cursor = NULL;
   visible = false;

   GuiCanvas *root = getRoot();
   if ( !root )
      return;

   S32 currCursor = PlatformCursorController::curArrow;

   if ( root->mCursorChanged == currCursor )
      return;

   PlatformWindow *window = root->getPlatformWindow();
   PlatformCursorController *controller = window->getCursorController();
   
   // We've already changed the cursor, 
   // so set it back before we change it again.
   if( root->mCursorChanged != -1)
      controller->popCursor();

   // Now change the cursor shape
   controller->pushCursor(currCursor);
   root->mCursorChanged = currCursor;   
}

void GuiTemplateEditorCtrl::on3DMouseDown(const Gui3DMouseEvent & event)
{
   if ( !isFirstResponder() )
      setFirstResponder();
}

void GuiTemplateEditorCtrl::on3DRightMouseDown(const Gui3DMouseEvent & event)
{
   //mIsPanning = true;
}

void GuiTemplateEditorCtrl::on3DRightMouseUp(const Gui3DMouseEvent & event)
{
   //mIsPanning = false;
}

void GuiTemplateEditorCtrl::on3DMouseUp(const Gui3DMouseEvent & event)
{

}

void GuiTemplateEditorCtrl::on3DMouseMove(const Gui3DMouseEvent & event)
{
}

void GuiTemplateEditorCtrl::on3DMouseDragged(const Gui3DMouseEvent & event)
{   
}

void GuiTemplateEditorCtrl::on3DMouseEnter(const Gui3DMouseEvent & event)
{
   // nothing to do
}

void GuiTemplateEditorCtrl::on3DMouseLeave(const Gui3DMouseEvent & event)
{
   // nothing to do
}

bool GuiTemplateEditorCtrl::onKeyDown(const GuiEvent& event)
{
	return false;
}

void GuiTemplateEditorCtrl::updateGuiInfo()
{
   // nothing to do
}
      
void GuiTemplateEditorCtrl::onRender( Point2I offset, const RectI &updateRect )
{
   PROFILE_SCOPE( GuiTemplateEditorCtrl_OnRender );

   Parent::onRender( offset, updateRect );
   return;
}
      
void GuiTemplateEditorCtrl::renderScene(const RectI & updateRect)
{
} 


void GuiTemplateEditorCtrl::setMode( String mode, bool sourceShortcut = false )
{
   mMode = mode;

	if( sourceShortcut )
		Con::executef( this, "paletteSync", mode );
}

void GuiTemplateEditorCtrl::submitUndo( const UTF8 *name )
{
   // Grab the mission editor undo manager.
   UndoManager *undoMan = NULL;
   if ( !Sim::findObject( "TemplateEUndoManager", undoMan ) )
   {
      Con::errorf( "GuiTemplateEditorCtrl::submitUndo() - TemplateEUndoManager not found!" );
      return;           
   }
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////  Place Console Methods Here  //////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////

