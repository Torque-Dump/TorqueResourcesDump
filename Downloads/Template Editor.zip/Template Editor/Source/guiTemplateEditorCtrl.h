//-----------------------------------------------------------------------------
// Torque 3D
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _GUITemplateEDITORCTRL_H_
#define _GUITemplateEDITORCTRL_H_

#ifndef _EDITTSCTRL_H_
#include "gui/worldEditor/EditTSCtrl.h"
#endif
#ifndef _UNDO_H_
#include "util/undo.h"
#endif
#ifndef _DECALROAD_H_
#endif

class GameBase;


class GuiTemplateEditorCtrl : public EditTSCtrl
{
   typedef EditTSCtrl Parent;

   public:
   
       friend class GuiTemplateEditorUndoAction;
		
      GuiTemplateEditorCtrl();
      ~GuiTemplateEditorCtrl();

      DECLARE_CONOBJECT(GuiTemplateEditorCtrl);

      // SimObject
      bool onAdd();
      static void initPersistFields();

      // GuiControl
      virtual void onSleep();
      virtual void onRender(Point2I offset, const RectI &updateRect);

      // EditTSCtrl      
		bool onKeyDown(const GuiEvent& event);
      void get3DCursor( GuiCursor *&cursor, bool &visible, const Gui3DMouseEvent &event_ );
      void on3DMouseDown(const Gui3DMouseEvent & event);
      void on3DMouseUp(const Gui3DMouseEvent & event);
      void on3DMouseMove(const Gui3DMouseEvent & event);
      void on3DMouseDragged(const Gui3DMouseEvent & event);
      void on3DMouseEnter(const Gui3DMouseEvent & event);
      void on3DMouseLeave(const Gui3DMouseEvent & event);
      void on3DRightMouseDown(const Gui3DMouseEvent & event);
      void on3DRightMouseUp(const Gui3DMouseEvent & event);
      void updateGuiInfo();      
      void renderScene(const RectI & updateRect);

	  void setMode( String mode, bool sourceShortcut );
      String getMode() { return mMode; }

  protected:
      void submitUndo( const UTF8 *name );

      bool mSavedDrag;
      bool mIsDirty;

      String mMode;

      GFXStateBlockRef mZDisableSB;
      GFXStateBlockRef mZEnableSB;
};

class GuiTemplateEditorUndoAction : public UndoAction
{
   public:

      GuiTemplateEditorUndoAction( const UTF8* actionName ) : UndoAction( actionName )
      {
      }

      GuiTemplateEditorCtrl *mTemplateEditor;

      virtual void undo();
      virtual void redo() { undo(); }
};

#endif