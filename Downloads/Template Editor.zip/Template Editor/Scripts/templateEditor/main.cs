//-----------------------------------------------------------------------------
// Copyright (C) Sickhead Games, LLC
//-----------------------------------------------------------------------------

function initializeTemplateEditor()
{
   echo( " - Initializing Template Editor" );
   
   exec( "./TemplateEditor.cs" );
   exec( "./TemplateEditorGui.gui" );
   exec( "./TemplateEditorToolbar.gui");
   exec( "./TemplateEditorGui.cs" );
   
   // Add ourselves to EditorGui, where all the other tools reside
   TemplateEditorGui.setVisible( false ); 
   TemplateEditorToolbar.setVisible( false );
   TemplateEditorOptionsWindow.setVisible( false );
   TemplateEditorTreeWindow.setVisible( false );
   
   EditorGui.add( TemplateEditorGui );
   EditorGui.add( TemplateEditorToolbar );
   EditorGui.add( TemplateEditorOptionsWindow );
   EditorGui.add( TemplateEditorTreeWindow );
   
   new ScriptObject( TemplateEditorPlugin )
   {
      superClass = "EditorPlugin";
   };
   
   %map = new ActionMap();
   %map.bindCmd( keyboard, "backspace", "TemplateEditorGui.onDeleteKey();", "" );
   %map.bindCmd( keyboard, "delete", "TemplateEditorGui.onDeleteKey();", "" );  
   %map.bindCmd( keyboard, "1", "TemplateEditorGui.prepSelectionMode();", "" );  
   %map.bindCmd( keyboard, "2", "ToolsPaletteArray->TemplateEditorAction1Mode.performClick();", "" );  
   %map.bindCmd( keyboard, "4", "ToolsPaletteArray->TemplateEditorAction2Mode.performClick();", "" );  
   %map.bindCmd( keyboard, "5", "ToolsPaletteArray->TemplateEditorAction3Mode.performClick();", "" );  
   %map.bindCmd( keyboard, "-", "ToolsPaletteArray->TemplateEditorAction4Mode.performClick();", "" );  
   %map.bindCmd( keyboard, "=", "ToolsPaletteArray->TemplateEditorAction5Mode.performClick();", "" );  
   %map.bindCmd( keyboard, "z", "TemplateEditorShowThing1Btn.performClick();", "" );  
   %map.bindCmd( keyboard, "x", "TemplateEditorShowThing2Btn.performClick();", "" );  
   %map.bindCmd( keyboard, "c", "TemplateEditorShowThing3Btn.performClick();", "" ); 
   
    TemplateEditorPlugin.map = %map;
   
   TemplateEditorPlugin.initSettings();
}

function destroyTemplateEditor()
{
}

function TemplateEditorPlugin::onWorldEditorStartup( %this )
{  
   // Add ourselves to the window menu.
   %accel = EditorGui.addToEditorsMenu( "Template Editor", "", TemplateEditorPlugin );      
   
   // Add ourselves to the ToolsToolbar
   %tooltip = "Site Configuration (" @ %accel @ ")";   
   EditorGui.addToToolsToolbar( "TemplateEditorPlugin", "TemplateEditorPalette", expandFilename("tools/worldEditor/images/toolbar/road-path-editor"), %tooltip );
   
   //connect editor windows
   AttachWindows( TemplateEditorOptionsWindow, TemplateEditorTreeWindow);
   
   // Add ourselves to the Editor Settings window
   exec( "./TemplateEditorSettingsTab.gui" );
   ESettingsWindow.addTabPage( ETemplateEditorSettingsPage );
    
}

function TemplateEditorPlugin::onActivated( %this )
{
   %this.readSettings();
   
   ToolsPaletteArray->TemplateEditorAction3Mode.performClick(); 
   EditorGui.bringToFront( TemplateEditorGui );
   
   TemplateEditorGui.setVisible( true );
   TemplateEditorGui.makeFirstResponder( true );
   TemplateEditorToolbar.setVisible( true );   
   
   TemplateEditorOptionsWindow.setVisible( true );
   TemplateEditorTreeWindow.setVisible( true );
   
   TemplateTreeView.open(ServerDecalRoadSet,true);
   
   %this.map.push();

   // Set the status bar here until all tool have been hooked up
   EditorGuiStatusBar.setInfo("Template editor.");
   EditorGuiStatusBar.setSelection("");
   
   Parent::onActivated(%this);
}

function TemplateEditorPlugin::onDeactivated( %this )
{
   %this.writeSettings();
   
   TemplateEditorGui.setVisible( false );
   TemplateEditorToolbar.setVisible( false );   
   TemplateEditorOptionsWindow.setVisible( false );
   TemplateEditorTreeWindow.setVisible( false );
   %this.map.pop();
   
   Parent::onDeactivated(%this);
}

function TemplateEditorPlugin::handleEscape( %this )
{
   return TemplateEditorGui.onEscapePressed();  
}

function ESiteConfditorPlugin::isDirty( %this )
{
   return TemplateEditorGui.isDirty;
}

function TemplateEditorPlugin::onSaveMission( %this, %missionFile )
{
   if( TemplateEditorGui.isDirty )
   {
      MissionGroup.save( %missionFile );
      TemplateEditorGui.isDirty = false;
   }
}

function TemplateEditorPlugin::setEditorFunction( %this )
{
   %terrainExists = parseMissionGroup( "TerrainBlock" );

   if( %terrainExists == false )
      MessageBoxYesNoCancel("No Terrain","Would you like to create a New Terrain?", "Canvas.pushDialog(CreateNewTerrainGui);");
   
   return %terrainExists;
}

//-----------------------------------------------------------------------------
// Settings
//-----------------------------------------------------------------------------

function TemplateEditorPlugin::initSettings( %this )
{
   EditorSettings.beginGroup( "TemplateEditor", true );
   
   EditorSettings.setDefaultValue(  "Value1",         "Some Value 1" );
   EditorSettings.setDefaultValue(  "Value2",     "Some Value 2" );
   EditorSettings.setDefaultValue(  "Value3",  "Some Value 3" );

   EditorSettings.endGroup();
  }

function TemplateEditorPlugin::readSettings( %this )
{
   EditorSettings.beginGroup( "TemplateEditor", true );
   
   TemplateEditorGui.Value1         = EditorSettings.value("Value1");
   TemplateEditorGui.Value2     = EditorSettings.value("Value2");
   TemplateEditorGui.Value3  = EditorSettings.value("Value3");

   EditorSettings.endGroup();  
}

function TemplateEditorPlugin::writeSettings( %this )
{
   EditorSettings.beginGroup( "TemplateEditor", true );
   
   EditorSettings.setValue( "Value1",           TemplateEditorGui.Value1 );
   EditorSettings.setValue( "Value2",       TemplateEditorGui.Value2 );
   EditorSettings.setValue( "Value3",    TemplateEditorGui.Value3 );

   EditorSettings.endGroup();
}