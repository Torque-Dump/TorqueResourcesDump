
function TemplateEditorGui::onWake( %this )
{   
}

function TemplateEditorGui::onSleep( %this )
{
}

function TemplateEditorGui::paletteSync( %this, %mode )
{
   %evalShortcut = "ToolsPaletteArray-->" @ %mode @ ".setStateOn(1);";
   eval(%evalShortcut);
}  

function TemplateEditorGui::onDeleteKey( %this )
{
   echo( "On Delete Key Pressed" );
}

function TemplateEditorGui::onEscapePressed( %this )
{
   echo( "On Escape Key Pressed" );
}

function TemplateEditorGui::onBrowseClicked( %this )
{
   //%filename = RETextureFileCtrl.getText();
         
   %dlg = new OpenFileDialog()
   {
      Filters        = "All Files (*.*)|*.*|";
      DefaultPath    = TemplateEditorGui.lastPath;
      DefaultFile    = %filename;
      ChangePath     = false;
      MustExist      = true;
   };
         
   %ret = %dlg.Execute();
   if(%ret)
   {
      TemplateEditorGui.lastPath = filePath( %dlg.FileName );
      %filename = %dlg.FileName;
      TemplateEditorGui.setTextureFile( %filename );
      RETextureFileCtrl.setText( %filename );
   }
   
   %dlg.delete();
}

function TemplateInspector::inspect( %this, %obj )
{
   %name = "";
   if ( isObject( %obj ) )
      %name = %obj.getName();   
   else
      TemplateFieldInfoControl.setText( "" );
   
   //InspectorNameEdit.setValue( %name );
   Parent::inspect( %this, %obj );  
}

function TemplateInspector::onInspectorFieldModified( %this, %object, %fieldName, %arrayIndex, %oldValue, %newValue )
{
   // Same work to do as for the regular WorldEditor Inspector.
   Inspector::onInspectorFieldModified( %this, %object, %fieldName, %arrayIndex, %oldValue, %newValue );   
}

function TemplateInspector::onFieldSelected( %this, %fieldName, %fieldTypeStr, %fieldDoc )
{
   TemplateFieldInfoControl.setText( "<font:ArialBold:14>" @ %fieldName @ "<font:ArialItalic:14> (" @ %fieldTypeStr @ ") " NL "<font:Arial:14>" @ %fieldDoc );
}

function TemplateTreeView::onInspect(%this, %obj)
{
   TemplateInspector.inspect(%obj);   
}

function TemplateTreeView::onSelect(%this, %obj)
{
}

function TemplateEditorGui::prepSelectionMode( %this )
{
   ToolsPaletteArray-->TemplateEditorAction0Mode.setStateOn(1);
}
//------------------------------------------------------------------------------
function TemplateDefaultWidthSliderCtrlContainer::onWake(%this)
{
   ////TemplateDefaultWidthSliderCtrlContainer-->slider.setValue(TemplateDefaultWidthTextEditContainer-->textEdit.getText());
}