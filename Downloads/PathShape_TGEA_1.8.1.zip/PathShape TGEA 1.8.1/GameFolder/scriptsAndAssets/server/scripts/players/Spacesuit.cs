//-----------------------------------------------------------------------------
// Torque Game Engine Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

// No need to load a TSShapeConstructor for this mesh since it
// already has the animations saved into it

datablock PlayerData(SpacesuitData : DefaultPlayerData)
{
   renderFirstPerson = false;
   emap = true;
   
   jumpTowardsNormal = false;
   airControl = 0.3;
   
   jetJumpForce       = 8.3 * 10;
   jetJumpEnergyDrain = 0.6;
   jetMinJumpEnergy   = 0;
   
   rechargeRate = 0.35;

   className = Armor;
   shapeFile = "~/data/shapes/players/Spacesuit/Spacesuit.dts";
};

function Armor::onMovableSurface(%this,%obj,%col)
{
 error("i'm on Pathshape! :"@%col);
if (%col.getClassName() $= "PathShape") %col.attachchild(%obj);
}

PlayerDatasGroup.add(SpacesuitData);