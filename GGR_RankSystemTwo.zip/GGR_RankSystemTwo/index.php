<?php

   include("RSA.php");
   
   $user = "YourUserHere";
   $pw = "YourPWHere";
   $db = "YourDBHere";

   $mode = $_POST["mode"];
   $target = $_POST["guid"];
   
   $con = mysql_connect("localhost",$user, $pw) or die("$"."INTERNAL_ERROR\n");
   mysql_select_db($db, $con);
   $row2 = mysql_fetch_array(mysql_query("SELECT * FROM Admin")) or die("$"."INTERNAL_ERROR");

   if(strcmp($mode, "send") == 0) {
      $exp1 = $_POST["data1"];
      //update/add
      $added = 0;
      //
      $result = mysql_query("SELECT * FROM Data") or die("$"."INTERNAL_ERROR");
      while($row = mysql_fetch_array($result)) {   
         $rowGUID = $row["GUID"];  
         if(strcmp($target, $rowGUID) == 0) {    
            $added = 1;
            mysql_query("UPDATE Data SET Data1='$exp1' WHERE GUID='$target'");
            die("$"."RANKUPDATE");
         }
      }
      if($added == 0) {
         //new guy
         mysql_query("INSERT INTO Data (GUID, Data1) VALUES ('$target', '$exp1')");
         die("$"."RANKUPDATE");
      }      
   }
   else if(strcmp($mode, "request") == 0) {
      $rsa = new Crypt_RSA();
      $rsa->setSignatureMode(CRYPT_RSA_SIGNATURE_PKCS1);
      
      $rsa->loadKey($row2[RSAPUBLIC_EXP]);
      $data = $rsa->modulus->toHex();
      
      $rsa->loadKey($row2[RSAPRIVATE_EXP]);
      $sig = $rsa->sign($data);
      
      $result = mysql_query("SELECT * FROM Data WHERE GUID='$target'") or die("$"."INTERNAL_ERROR");
      while($row = mysql_fetch_array($result)) {
         //got it!
         echo("$"."OUTKEY"." ".$data);
         //
         echo("\n$"."RNKOUT1"." ".bin2hex($sig).":".$row[Data1]);
      } 
      die("$"."ERROR_NSP");
   }
   else {
      die("$"."GEN_ERROR");
   }

?>
