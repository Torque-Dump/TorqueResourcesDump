<?php

//RSA KEYPAIR GENERATION
//Phantom139, for Battlelord

//This file will run a check when new data is recieved to see if it is time to generate a new
//keypair, keypairs are generated once every 24. hrs to keep the data secure and to prevent players
//from generating invalid rank files using hacked data. This file handles the encryption and decryption
//of data sent to PGD from the game's client.

//The server keeps the time this script was last executed in the database to prevent any spam
//bots from attempting to crash us by spamming usage of this file. Once per 24 hours... no
//exceptions...

ini_set('max_execution_time', 0); //clear the max_execute_time due to large time requirements on RSA-keypair generation

include("RSA.php");

function getUTC() {
   return time();
}

function generateBLRSAKey() {
   $user = "YourUserHere";
   $pw = "YourPWHere";
   $db = "YourDBHere";

   $con = mysql_connect("localhost",$user, $pw) or die("$"."INTERNAL_ERROR\n");
   mysql_select_db($db, $con);
   
   $theRow = mysql_fetch_array(mysql_query("SELECT * FROM Admin")) or die("$"."INTERNAL_ERROR");
   $lastExecuteTime = $theRow[LASTUTC];
   $time = time();
   if(($time - $lastExecuteTime) < (23 * 59 * 10)) {
      echo("<html><head><title>Ha!Ha!Ha!</title></head><body>Nice try... no overload hacking for you...</body></html>");
      die("bye now...");
   }

   $rsa = new Crypt_RSA();  
   extract($rsa->createKey(1024));

   $rsa->loadKey($privatekey); 
   mysql_query("UPDATE Admin SET RSAPRIVATE_EXP='$privatekey' WHERE index='1'");
   $rsa->loadKey($publickey); 
   mysql_query("UPDATE Admin SET RSAPUBLIC_EXP='$publickey' WHERE index='1'");
   

   mysql_query("UPDATE Admin SET LASTUTC='$time' WHERE index='1'");
   
   die("Key Update Successful...");
}

generateBLRSAKey();

?>
