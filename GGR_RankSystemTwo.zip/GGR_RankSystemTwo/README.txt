The files:

BigInteger.php, Hash.php, Random.php, and RSA.php belong to the PhpSecLib Library, and are not mine.
All agreements to these files belong only to this library, and if any, can be found at the following link:

http://phpseclib.sourceforge.net/

The other two files, index.php, and rsaKey.php however, are mine. They are free to use without license and warranty.
