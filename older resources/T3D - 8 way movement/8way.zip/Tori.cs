
singleton TSShapeConstructor(ToriDae)
{
   baseShape = "./Tori.dae";
/*   sequence0 = "art/shapes/actors/Male/root/TM_Adam_root.dsq root";
   sequence1 = "art/shapes/actors/Male/root/TM_Adam_idle.dsq idle";
   sequence2 = "art/shapes/actors/Male/root/TM_Adam_rootDamage_1.dsq rootdamage" ;
	
   sequence3 = "art/shapes/actors/Male/run/TM_Adam_back.dsq back";
   sequence4 = "art/shapes/actors/Male/run/TM_Adam_run_1.dsq run";
   sequence5 = "art/shapes/actors/Male/run/TM_Adam_runDamaged_1.dsq rundamage";
   sequence6 = "art/shapes/actors/Male/side/TM_Adam_side.dsq side";

   sequence7 = "art/shapes/actors/Male/jump/TM_Adam_jump.dsq jump";

   sequence8 = "art/shapes/actors/Male/jump/TM_Adam_fall.dsq fall";
   sequence9 = "art/shapes/actors/Male/jump/TM_Adam_land.dsq land";
   sequence10 = "art/shapes/actors/Male/jump/TM_Adam_standJump_1.dsq standjump";
   sequence11 = "art/shapes/actors/Male/walk/TM_Adam_walk_1.dsq walk";
   sequence12 = "art/shapes/actors/Male/walk/TM_Adam_walkDamaged_3.dsq walkdamage";
	sequence13 = "art/shapes/actors/Male/climb/TM_Adam_climb.dsq climb";
	
   sequence14 = "art/shapes/actors/Male/crouch/TM_Adam_crouchForward.dsq crouchforward" ;
   sequence15 = "art/shapes/actors/Male/crouch/TM_Adam_crouchRoot.dsq crouchroot";
   sequence16 = "art/shapes/actors/Male/crawl/TM_Adam_crawlForward.dsq crawlforward";
   sequence17 = "art/shapes/actors/Male/crawl/TM_Adam_crawlRoot.dsq crawlroot";
   sequence18 = "art/shapes/actors/Male/swim/TM_Adam_swimRoot.dsq swim_root";
   sequence19 = "art/shapes/actors/Male/swim/TM_Adam_swimForward.dsq SwimForwardAnim,";
   sequence20 = "art/shapes/actors/Male/swim/TM_Adam_swimRoot.dsq swim_backward";
   sequence21 = "art/shapes/actors/Male/swim/TM_Adam_swimRoot.dsq swim_left";
   sequence22 = "art/shapes/actors/Male/swim/TM_Adam_swimRoot.dsq swim_right";
   sequence23 = "art/shapes/actors/Male/other/TM_Adam_win.dsq win";
   sequence24 = "art/shapes/actors/Male/death/TM_Adam_die_front.dsq death1";
   sequence25 = "art/shapes/actors/player_dance.dsq dance";*/
   loadLights = "0";
};


function ToriDae::onLoad(%this)
{
   //root
   %this.addSequence("art/shapes/actors/RPG_Animations/Root_0.dae", "Root_0");
   %this.addSequence("art/shapes/actors/RPG_Animations/Root_45.dae", "Root_45");
   %this.addSequence("art/shapes/actors/RPG_Animations/Root_90.dae", "Root_90");
   %this.addSequence("art/shapes/actors/RPG_Animations/Root_135.dae", "Root_135");
   %this.addSequence("art/shapes/actors/RPG_Animations/Root_180.dae", "Root_180");
   %this.addSequence("art/shapes/actors/RPG_Animations/Root_225.dae", "Root_225");
   %this.addSequence("art/shapes/actors/RPG_Animations/Root_270.dae", "Root_270");
   %this.addSequence("art/shapes/actors/RPG_Animations/Root_315.dae", "Root_315");
   //run
   %this.addSequence("art/shapes/actors/RPG_Animations/Run_0.dae", "Run_0");
   %this.addSequence("art/shapes/actors/RPG_Animations/Run_45.dae", "Run_45");
   %this.addSequence("art/shapes/actors/RPG_Animations/Run_90.dae", "Run_90");
   %this.addSequence("art/shapes/actors/RPG_Animations/Run_135.dae", "Run_135");
   %this.addSequence("art/shapes/actors/RPG_Animations/Run_180.dae", "Run_180");
   %this.addSequence("art/shapes/actors/RPG_Animations/Run_225.dae", "Run_225");
   %this.addSequence("art/shapes/actors/RPG_Animations/Run_270.dae", "Run_270");
   %this.addSequence("art/shapes/actors/RPG_Animations/Run_315.dae", "Run_315");
   //swim
   %this.addSequence("art/shapes/actors/RPG_Animations/SwimRoot_0.dae", "SwimRoot_0");
   %this.addSequence("art/shapes/actors/RPG_Animations/SwimRoot_45.dae", "SwimRoot_45");
   %this.addSequence("art/shapes/actors/RPG_Animations/SwimRoot_90.dae", "SwimRoot_90");
   %this.addSequence("art/shapes/actors/RPG_Animations/SwimRoot_135.dae", "SwimRoot_135");
   %this.addSequence("art/shapes/actors/RPG_Animations/SwimRoot_180.dae", "SwimRoot_180");
   %this.addSequence("art/shapes/actors/RPG_Animations/SwimRoot_225.dae", "SwimRoot_225");
   %this.addSequence("art/shapes/actors/RPG_Animations/SwimRoot_270.dae", "SwimRoot_270");
   %this.addSequence("art/shapes/actors/RPG_Animations/SwimRoot_315.dae", "SwimRoot_315");
   //swim
   %this.addSequence("art/shapes/actors/RPG_Animations/Swim_0.dae", "Swim_0");
   %this.addSequence("art/shapes/actors/RPG_Animations/Swim_45.dae", "Swim_45");
   %this.addSequence("art/shapes/actors/RPG_Animations/Swim_90.dae", "Swim_90");
   %this.addSequence("art/shapes/actors/RPG_Animations/Swim_135.dae", "Swim_135");
   %this.addSequence("art/shapes/actors/RPG_Animations/Swim_180.dae", "Swim_180");
   %this.addSequence("art/shapes/actors/RPG_Animations/Swim_225.dae", "Swim_225");
   %this.addSequence("art/shapes/actors/RPG_Animations/Swim_270.dae", "Swim_270");
   %this.addSequence("art/shapes/actors/RPG_Animations/Swim_315.dae", "Swim_315");
   //Crouch
   %this.addSequence("art/shapes/actors/RPG_Animations/Crouch_0.dae", "Crouch_0");
   %this.addSequence("art/shapes/actors/RPG_Animations/Crouch_45.dae", "Crouch_45");
   %this.addSequence("art/shapes/actors/RPG_Animations/Crouch_90.dae", "Crouch_90");
   %this.addSequence("art/shapes/actors/RPG_Animations/Crouch_135.dae", "Crouch_135");
   %this.addSequence("art/shapes/actors/RPG_Animations/Crouch_180.dae", "Crouch_180");
   %this.addSequence("art/shapes/actors/RPG_Animations/Crouch_225.dae", "Crouch_225");
   %this.addSequence("art/shapes/actors/RPG_Animations/Crouch_270.dae", "Crouch_270");
   %this.addSequence("art/shapes/actors/RPG_Animations/Crouch_315.dae", "Crouch_315");
   //Crouch
   %this.addSequence("art/shapes/actors/RPG_Animations/CrouchWalk_0.dae", "CrouchWalk_0");
   %this.addSequence("art/shapes/actors/RPG_Animations/CrouchWalk_45.dae", "CrouchWalk_45");
   %this.addSequence("art/shapes/actors/RPG_Animations/CrouchWalk_90.dae", "CrouchWalk_90");
   %this.addSequence("art/shapes/actors/RPG_Animations/CrouchWalk_135.dae", "CrouchWalk_135");
   %this.addSequence("art/shapes/actors/RPG_Animations/CrouchWalk_180.dae", "CrouchWalk_180");
   %this.addSequence("art/shapes/actors/RPG_Animations/CrouchWalk_225.dae", "CrouchWalk_225");
   %this.addSequence("art/shapes/actors/RPG_Animations/CrouchWalk_270.dae", "CrouchWalk_270");
   %this.addSequence("art/shapes/actors/RPG_Animations/CrouchWalk_315.dae", "CrouchWalk_315");
   //Jump
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_0.dae", "Jump_0");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_45.dae", "Jump_45");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_90.dae", "Jump_90");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_135.dae", "Jump_135");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_180.dae", "Jump_180");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_225.dae", "Jump_225");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_270.dae", "Jump_270");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_315.dae", "Jump_315");
   //Fall
   %this.addSequence("art/shapes/actors/RPG_Animations/Fall_0.dae", "Fall_0");
   %this.addSequence("art/shapes/actors/RPG_Animations/Fall_45.dae", "Fall_45");
   %this.addSequence("art/shapes/actors/RPG_Animations/Fall_90.dae", "Fall_90");
   %this.addSequence("art/shapes/actors/RPG_Animations/Fall_135.dae", "Fall_135");
   %this.addSequence("art/shapes/actors/RPG_Animations/Fall_180.dae", "Fall_180");
   %this.addSequence("art/shapes/actors/RPG_Animations/Fall_225.dae", "Fall_225");
   %this.addSequence("art/shapes/actors/RPG_Animations/Fall_270.dae", "Fall_270");
   %this.addSequence("art/shapes/actors/RPG_Animations/Fall_315.dae", "Fall_315");
   //Land
   %this.addSequence("art/shapes/actors/RPG_Animations/Land_0.dae", "Land_0");
   %this.addSequence("art/shapes/actors/RPG_Animations/Land_45.dae", "Land_45");
   %this.addSequence("art/shapes/actors/RPG_Animations/Land_90.dae", "Land_90");
   %this.addSequence("art/shapes/actors/RPG_Animations/Land_135.dae", "Land_135");
   %this.addSequence("art/shapes/actors/RPG_Animations/Land_180.dae", "Land_180");
   %this.addSequence("art/shapes/actors/RPG_Animations/Land_225.dae", "Land_225");
   %this.addSequence("art/shapes/actors/RPG_Animations/Land_270.dae", "Land_270");
   %this.addSequence("art/shapes/actors/RPG_Animations/Land_315.dae", "Land_315");
   //StandJump
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_0.dae", "StandJump_0");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_45.dae", "StandJump_45");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_90.dae", "StandJump_90");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_135.dae", "StandJump_135");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_180.dae", "StandJump_180");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_225.dae", "StandJump_225");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_270.dae", "StandJump_270");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jump_315.dae", "StandJump_315");
   //ProneRoot
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneRoot_0.dae", "ProneRoot_0");
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneRoot_45.dae", "ProneRoot_45");
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneRoot_90.dae", "ProneRoot_90");
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneRoot_135.dae", "ProneRoot_135");
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneRoot_180.dae", "ProneRoot_180");
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneRoot_225.dae", "ProneRoot_225");
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneRoot_270.dae", "ProneRoot_270");
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneRoot_315.dae", "ProneRoot_315");
   //ProneWalk
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneWalk_0.dae", "ProneWalk_0");
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneWalk_45.dae", "ProneWalk_45");
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneWalk_90.dae", "ProneWalk_90");
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneWalk_135.dae", "ProneWalk_135");
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneWalk_180.dae", "ProneWalk_180");
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneWalk_225.dae", "ProneWalk_225");
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneWalk_270.dae", "ProneWalk_270");
   %this.addSequence("art/shapes/actors/RPG_Animations/ProneWalk_315.dae", "ProneWalk_315");
   //Jet
   %this.addSequence("art/shapes/actors/RPG_Animations/Jet_0.dae", "Jet_0");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jet_45.dae", "Jet_45");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jet_90.dae", "Jet_90");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jet_135.dae", "Jet_135");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jet_180.dae", "Jet_180");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jet_225.dae", "Jet_225");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jet_270.dae", "Jet_270");
   %this.addSequence("art/shapes/actors/RPG_Animations/Jet_315.dae", "Jet_315");
}
