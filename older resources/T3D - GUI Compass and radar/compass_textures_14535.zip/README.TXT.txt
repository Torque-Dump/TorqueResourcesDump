COMPASS AND NEEDLE PACK #1

2 Quality Compasses to enhance your Games GUI.  Ideal for games engines such as Torque.
Please note that this pack does not contain any source code required to make your compass work.

Included in this pack:

Old and Distressed style compass designs.
2 Compasses exported in PNG format with transparent background, PSD layered artwork source included.
1 Compass needle in PNG format with transparent background.

EULA (End User Licence Agreement)

You may use this artwork pack in as many games as you like, however you may not modify or redistribute/resell this pack or artwork contained within this pack in part or whole without the express permission of Something2Play Limited. You will be required to purchase a Commercial Licence if your game sales that contain any part of this pack reach $100k.


(c) 2005-2008. Something2Play Limited
Support: helpdesk@something2play.com
Website: www.something2play.com