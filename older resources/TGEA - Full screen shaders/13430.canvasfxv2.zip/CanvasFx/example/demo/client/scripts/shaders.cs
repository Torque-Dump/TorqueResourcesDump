//*****************************************************************************
// Shaders  ( For Custom Materials )
//*****************************************************************************

//-----------------------------------------------------------------------------
// Lightmap with light-normal and bump maps
//-----------------------------------------------------------------------------
new ShaderData( LmapBump )
{
   DXVertexShaderFile   = "shaders/BaseInteriorV.hlsl";
   DXPixelShaderFile    = "shaders/BaseInteriorP.hlsl";
   pixVersion = 1.1;
};

//-----------------------------------------------------------------------------
// Reflect cubemap
//-----------------------------------------------------------------------------
new ShaderData( Cubemap )
{
   DXVertexShaderFile   = "shaders/lmapCubeV.hlsl";
   DXPixelShaderFile    = "shaders/lmapCubeP.hlsl";
   pixVersion = 1.1;
};

//-----------------------------------------------------------------------------
// Bump reflect cubemap
//-----------------------------------------------------------------------------
new ShaderData( BumpCubemap )
{
   DXVertexShaderFile   = "shaders/bumpCubeV.hlsl";
   DXPixelShaderFile    = "shaders/bumpCubeP.hlsl";
   pixVersion = 1.1;
};

//-----------------------------------------------------------------------------
// Diffuse + Bump
//-----------------------------------------------------------------------------
new ShaderData( DiffuseBump )
{
   DXVertexShaderFile   = "shaders/diffBumpV.hlsl";
   DXPixelShaderFile    = "shaders/diffBumpP.hlsl";
   pixVersion = 1.1;
};

//-----------------------------------------------------------------------------
// Diffuse + Fog
//-----------------------------------------------------------------------------
new ShaderData( DiffuseFog )
{
   DXVertexShaderFile   = "shaders/diffuseFogV.hlsl";
   DXPixelShaderFile    = "shaders/diffuseFogP.hlsl";
   pixVersion = 1.1;
};

//-----------------------------------------------------------------------------
// Bump reflect cubemap with diffuse texture
//-----------------------------------------------------------------------------
new ShaderData( BumpCubeDiff )
{
   DXVertexShaderFile   = "shaders/bumpCubeDiffuseV.hlsl";
   DXPixelShaderFile    = "shaders/bumpCubeDiffuseP.hlsl";
   pixVersion = 2.0;
};


//-----------------------------------------------------------------------------
// Fog Test
//-----------------------------------------------------------------------------
new ShaderData( FogTest )
{
   DXVertexShaderFile   = "shaders/fogTestV.hlsl";
   DXPixelShaderFile    = "shaders/fogTestP.hlsl";
   pixVersion = 1.1;
};

//-----------------------------------------------------------------------------
// Planar Reflection
//-----------------------------------------------------------------------------
new ShaderData( ReflectBump )
{
   DXVertexShaderFile   = "shaders/planarReflectBumpV.hlsl";
   DXPixelShaderFile    = "shaders/planarReflectBumpP.hlsl";
   pixVersion = 2.0;
};

new ShaderData( Reflect )
{
   DXVertexShaderFile   = "shaders/planarReflectV.hlsl";
   DXPixelShaderFile    = "shaders/planarReflectP.hlsl";
   pixVersion = 1.4;
};

//-----------------------------------------------------------------------------
// Vertex refraction
//-----------------------------------------------------------------------------
new ShaderData( RefractVert )
{
   DXVertexShaderFile   = "shaders/refractVertV.hlsl";
   DXPixelShaderFile    = "shaders/refractVertP.hlsl";
   pixVersion = 2.0;
};

//-----------------------------------------------------------------------------
// Custom shaders for blob
//-----------------------------------------------------------------------------
new ShaderData( BlobRefractVert )
{
   DXVertexShaderFile   = "shaders/blobRefractVertV.hlsl";
   DXPixelShaderFile    = "shaders/blobRefractVertP.hlsl";
   pixVersion = 2.0;
};

new ShaderData( BlobRefractVert1_1 )
{
   DXVertexShaderFile   = "shaders/blobRefractVertV1_1.hlsl";
   DXPixelShaderFile    = "shaders/blobRefractVertP1_1.hlsl";
   pixVersion = 1.1;
};

new ShaderData( BlobRefractPix )
{
   DXVertexShaderFile   = "shaders/blobRefractPixV.hlsl";
   DXPixelShaderFile    = "shaders/blobRefractPixP.hlsl";
   pixVersion = 2.0;
};

//-----------------------------------------------------------------------------
// Custom shader for reflective sphere
//-----------------------------------------------------------------------------
new ShaderData( ReflectSphere )
{
   DXVertexShaderFile   = "shaders/reflectSphereV.hlsl";
   DXPixelShaderFile    = "shaders/reflectSphereP.hlsl";
   pixVersion = 2.0;
};

new ShaderData( ReflectSphere1_1 )
{
   DXVertexShaderFile   = "shaders/reflectSphereV1_1.hlsl";
   DXPixelShaderFile    = "shaders/reflectSphereP1_1.hlsl";
   pixVersion = 1.1;
};

new ShaderData( TendrilShader )
{
   DXVertexShaderFile   = "shaders/tendrilV.hlsl";
   DXPixelShaderFile    = "shaders/tendrilP.hlsl";
   pixVersion = 2.0;
};

new ShaderData( TendrilShader1_1 )
{
   DXVertexShaderFile   = "shaders/tendrilV1_1.hlsl";
   DXPixelShaderFile    = "shaders/tendrilP1_1.hlsl";
   pixVersion = 1.1;
};

//-----------------------------------------------------------------------------
// Blank shader - to draw to z buffer before rendering rest of scene
//-----------------------------------------------------------------------------
new ShaderData( BlankShader )
{
   DXVertexShaderFile   = "shaders/blankV.hlsl";
   pixVersion = 1.1;
};

//-----------------------------------------------------------------------------
// Outer Knot
//-----------------------------------------------------------------------------
new ShaderData( OuterKnotShader )
{
   DXVertexShaderFile   = "shaders/outerKnotV.hlsl";
   DXPixelShaderFile    = "shaders/outerKnotP.hlsl";
   pixVersion = 2.0;
};

new ShaderData( OuterKnotShader1_1 )
{
   DXVertexShaderFile   = "shaders/outerKnotV1_1.hlsl";
   DXPixelShaderFile    = "shaders/outerKnotP1_1.hlsl";
   pixVersion = 1.1;
};

//-----------------------------------------------------------------------------
// Waves
//-----------------------------------------------------------------------------
new ShaderData( Waves )
{
   DXVertexShaderFile   = "shaders/wavesV.hlsl";
   DXPixelShaderFile    = "shaders/wavesP.hlsl";
   pixVersion = 2.0;
};

//-----------------------------------------------------------------------------
// Terrain Shaders
//-----------------------------------------------------------------------------
new ShaderData( TerrShader )
{
   DXVertexShaderFile   = "shaders/legacyTerrain/terrainV.hlsl";
   DXPixelShaderFile    = "shaders/legacyTerrain/terrainP.hlsl";
   pixVersion = 1.1;
};

new ShaderData( TerrBlender20Shader )
{
   DXVertexShaderFile     = "shaders/legacyTerrain/terrainBlenderPS20V.hlsl";
   DXPixelShaderFile      = "shaders/legacyTerrain/terrainBlenderPS20P.hlsl";
   pixVersion = 2.0;
};

new ShaderData( TerrBlender11AShader )
{
   DXVertexShaderFile     = "shaders/legacyTerrain/terrainBlenderPS11AV.hlsl";
   DXPixelShaderFile      = "shaders/legacyTerrain/terrainBlenderPS11AP.hlsl";
   pixVersion = 1.1;
};

new ShaderData( TerrBlender11BShader )
{
   DXVertexShaderFile     = "shaders/legacyTerrain/terrainBlenderPS11BV.hlsl";
   DXPixelShaderFile      = "shaders/legacyTerrain/terrainBlenderPS11BP.hlsl";
   pixVersion = 1.1;
};

//-----------------------------------------------------------------------------
// Terrain Shaders
//-----------------------------------------------------------------------------

new ShaderData( AtlasShader2 )
{
   DXVertexShaderFile   = "shaders/atlas/atlasSurfaceV2.hlsl";
   DXPixelShaderFile    = "shaders/atlas/atlasSurfaceP2.hlsl";
   pixVersion = 1.1;
};

new ShaderData( AtlasShader3 )
{
   DXVertexShaderFile   = "shaders/atlas/atlasSurfaceV3.hlsl";
   DXPixelShaderFile    = "shaders/atlas/atlasSurfaceP3.hlsl";
   pixVersion = 1.1;
};

new ShaderData( AtlasShader4 )
{
   DXVertexShaderFile   = "shaders/atlas/atlasSurfaceV4.hlsl";
   DXPixelShaderFile    = "shaders/atlas/atlasSurfaceP4.hlsl";
   pixVersion = 1.1;
};

new ShaderData( AtlasShaderFog )
{
   DXVertexShaderFile   = "shaders/atlas/atlasFogV.hlsl";
   DXPixelShaderFile    = "shaders/atlas/atlasFogP.hlsl";
   pixVersion = 1.1;
};

new ShaderData( AtlasShaderDetail )
{
   DXVertexShaderFile   = "shaders/atlas/atlasDetailV.hlsl";
   DXPixelShaderFile    = "shaders/atlas/atlasDetailP.hlsl";
   pixVersion = 1.1;
};

new ShaderData( AtlasBlender20Shader )
{
   DXVertexShaderFile   = "shaders/atlas/atlasBlenderPS20V.hlsl";
   DXPixelShaderFile    = "shaders/atlas/atlasBlenderPS20P.hlsl";
   pixVersion = 2.0;
};

new ShaderData( AtlasBlender11AShader )
{
   DXVertexShaderFile     = "shaders/atlas/atlasBlenderPS11VA.hlsl";
   DXPixelShaderFile      = "shaders/atlas/atlasBlenderPS11PA.hlsl";
   pixVersion = 1.1;
};

new ShaderData( AtlasBlender11BShader )
{
   DXVertexShaderFile     = "shaders/atlas/atlasBlenderPS11VB.hlsl";
   DXPixelShaderFile      = "shaders/atlas/atlasBlenderPS11PB.hlsl";
   pixVersion = 1.1;
};

//-----------------------------------------------------------------------------
// Water
//-----------------------------------------------------------------------------
new ShaderData( WaterFres1_1 )
{
   DXVertexShaderFile   = "shaders/water/WaterFresV1_1.hlsl";
   DXPixelShaderFile    = "shaders/water/WaterFresP1_1.hlsl";
   pixVersion = 1.1;
};

new ShaderData( WaterBlend )
{
   DXVertexShaderFile   = "shaders/water/WaterBlendV.hlsl";
   DXPixelShaderFile    = "shaders/water/WaterBlendP.hlsl";
   pixVersion = 1.1;
};

new ShaderData( Water1_1 )
{
   DXVertexShaderFile   = "shaders/water/WaterV1_1.hlsl";
   DXPixelShaderFile    = "shaders/water/WaterP1_1.hlsl";
   pixVersion = 1.1;
};

new ShaderData( WaterCubeReflectRefract )
{
   DXVertexShaderFile   = "shaders/water/WaterCubeReflectRefractV.hlsl";
   DXPixelShaderFile    = "shaders/water/WaterCubeReflectRefractP.hlsl";
   pixVersion = 2.0;
};

new ShaderData( WaterReflectRefract )
{
   DXVertexShaderFile   = "shaders/water/WaterReflectRefractV.hlsl";
   DXPixelShaderFile    = "shaders/water/WaterReflectRefractP.hlsl";
   pixVersion = 2.0;
};

new ShaderData( WaterUnder2_0 )
{
   DXVertexShaderFile   = "shaders/water/WaterUnderV2_0.hlsl";
   DXPixelShaderFile    = "shaders/water/WaterUnderP2_0.hlsl";
   pixVersion = 2.0;
};

// FxCanvas shader utility functions
new ShaderData( DefaultCanvasFxShader )
{
	DXVertexShaderFile	= "shaders/canvasfx/defaultV.hlsl";
	DXPixelShaderFile	= "shaders/canvasfx/defaultP.hlsl";
	pixVersion 			= 1.1;
};

new ShaderData( SepiaCanvasFxShader )
{
	DXVertexShaderFile	= "shaders/canvasfx/defaultV.hlsl";
	DXPixelShaderFile	= "shaders/canvasfx/sepiaP.hlsl";
	pixVersion 			= 2.0;
};

$sepiaFxVars[0] = "1 0.9 0.5 0";
$sepiaFxVars[1] = "0.2 0.05 0 0";
$sepiaFxVars[2] = "0.3 0.59 0.11 0";
$sepiaFxVars[3] = "1 0.5 0 0";

function doFxSepia()
{
	canvas.setCanvasFxVars($sepiaFxVars[0] SPC $sepiaFxVars[1] SPC $sepiaFxVars[2] SPC $sepiaFxVars[3]);
	canvas.setCanvasFx(SepiaCanvasFxShader);
	canvas.startCanvasFx();
}

new ShaderData( HotSpotFxShader )
{
	DXVertexShaderFile	= "shaders/canvasfx/hotSpotV.hlsl";
	DXPixelShaderFile	= "shaders/canvasfx/hotSpotP.hlsl";
	pixVersion 			= 2.0;
};

$spotFxVars[0] = "0.1 5 0 0";
$spotFxVars[1] = "0.1 0.1 0.1 1";
$spotFxVars[2] = "0 0 0 0";
$spotFxVars[3] = "0 0 0 0";

function doFxSpot()
{
	canvas.setCanvasFxVars($spotFxVars[0] SPC $spotFxVars[1] SPC $spotFxVars[2] SPC $spotFxVars[3]);
	canvas.setCanvasFx(HotSpotFxShader);
	canvas.startCanvasFx();
}

new ShaderData( WaveFxShader )
{
	DXVertexShaderFile	= "shaders/canvasfx/waveV.hlsl";
	DXPixelShaderFile	= "shaders/canvasfx/waveP.hlsl";
	pixVersion 			= 1.4;
};

$waveFxVars[0] = "10 0.01 0.001 0";
$waveFxVars[1] = "10 0.01 0.001 0";
$waveFxVars[2] = "0 0 0 0";
$waveFxVars[3] = "0 0 0 0";

function doFxWave()
{
	canvas.setCanvasFxVars($waveFxVars[0] SPC $waveFxVars[1] SPC $waveFxVars[2] SPC $waveFxVars[3]);
	canvas.setCanvasFx(WaveFxShader);
	canvas.startCanvasFx();
}

function canvasFxUpdateVars()
{
	canvas.setCanvasFxVars($canvasFxVars[0] SPC $canvasFxVars[1] SPC $canvasFxVars[2] SPC $canvasFxVars[3]);
}


function stopFx()
{
	canvas.stopcanvasfx();
}
