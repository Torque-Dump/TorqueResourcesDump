//-----------------------------------------------------------------------------
// Torque Game Engine Advanced
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "T3D/gameTSCtrl.h"
#include "console/consoleTypes.h"
#include "T3D/gameBase.h"
#include "T3D/gameConnection.h"
#include "T3D/shapeBase.h"
#include "T3D/gameFunctions.h"

//---------------------------------------
//  fullscreen shader effects
//---------------------------------------
#include "sceneGraph/sceneGraph.h"
#include "../../game/shaders/shdrConsts.h"
#include "gfx/primBuilder.h"
#include "core/frameAllocator.h"
#include "console/consoleTypes.h"
#include "shaderGen/shaderGenVars.h"
//---------------------------------------

// ShaderPool Mod
#include <vector>

//---------------------------------------------------------------------------
// Debug stuff:
Point3F lineTestStart = Point3F(0, 0, 0);
Point3F lineTestEnd =   Point3F(0, 1000, 0);
Point3F lineTestIntersect =  Point3F(0, 0, 0);
bool gSnapLine = false;

//----------------------------------------------------------------------------
// Class: GameTSCtrl
//----------------------------------------------------------------------------
IMPLEMENT_CONOBJECT(GameTSCtrl);

GameTSCtrl::GameTSCtrl()
{
	effectMode		= -1;
	mFilterColor	= ColorF(1,1,1,1);

	GFXVideoMode vm;
	const String resString = Con::getVariable("$pref::Video::mode");
	vm.parseFromString(resString);
	for (int i =0; i < 3; i++)
		mSurface[i].set( vm.resolution.x, vm.resolution.y, GFXFormatR8G8B8A8, &GFXDefaultRenderTargetProfile, avar("%s() - mSurface[i] (line %d)", __FUNCTION__, __LINE__), 1 );
}

GameTSCtrl::~GameTSCtrl()
{
	// ShaderPool Mod
	shaderPool.clear();
}


//---------------------------------------------------------------------------
bool GameTSCtrl::processCameraQuery(CameraQuery *camq)
{
   GameUpdateCameraFov();
   return GameProcessCameraQuery(camq);
}

//---------------------------------------------------------------------------
void GameTSCtrl::renderWorld(const RectI &updateRect)
{
	// ShaderPool Mod
	// we have an active shader
	if(effectMode >= 0)
	{
		// check if we're in range
		if(effectMode > shaderPool.size())
		{
			char errorMessage[256];
			sprintf_s(errorMessage, sizeof(errorMessage), "The effectMode parameter is out of range! effectMode = %d", effectMode);
			AssertFatal(false, errorMessage);
		}

		renderWorldEffect(updateRect, shaderPool.at(effectMode), NULL, GFXFillSolid);
	}
	else
	{
		GameRenderWorld();
	}

	GFXVideoMode vm;
	const String resString = Con::getVariable("$pref::Video::mode");
	vm.parseFromString(resString);
	for (int i =0; i < 3; i++)
		mSurface[i].set( vm.resolution.x, vm.resolution.y, GFXFormatR8G8B8A8, &GFXDefaultRenderTargetProfile, avar("%s() - mSurface[i] (line %d)", __FUNCTION__, __LINE__), 1 );
}

void GameTSCtrl::renderWorldEffect(const RectI &updateRect, CustomShader *mEffectShader, U32 objMask, GFXFillMode fMode)
{
	FrameAllocator::setWaterMark(0);

	mRenderTarget = GFX->allocRenderToTextureTarget();

	// rectangle points for calcs later
	Point2I a = updateRect.point;
	Point2I b = updateRect.point + updateRect.extent;

	GFXStateBlockDesc desc;

	desc.setZEnable( true );
	desc.stencilFunc = GFXCmpLessEqual;
	GFXStateBlockRef block;
	block = GFX->createStateBlock(desc);

	// Update the dynamic cubemaps on reflective objects
	SimSet *reflectSet = dynamic_cast<SimSet*>( Sim::findObject( "reflectiveSet" ) );

	for( SimSetIterator itr(reflectSet); *itr; ++itr )
	{
		if( *itr )
		{
			SceneObject *obj = (SceneObject*) *itr;
			obj->updateReflection();
		}
	}

	desc.setCullMode( GFXCullNone );
	desc.fillMode = fMode ;
	block = GFX->createStateBlock(desc);
	GFX->pushActiveRenderTarget();

	// Set a starting texture so we can bind w/o any nulls.
	mRenderTarget->attachTexture(GFXTextureTarget::Color0, mSurface[0]);
	mRenderTarget->attachTexture(GFXTextureTarget::DepthStencil, GFXTextureTarget::sDefaultDepthStencil);
	GFX->setActiveRenderTarget(mRenderTarget);

	// if it's wireframe we have to clear every frame
	if (fMode == GFXFillWireframe)
	{
		GFX->clear( GFXClearTarget, ColorI(0.5,0.5,0.5,0.5), 1.0f, 0 );
	}

	// assign the render mask if one came in
	if (objMask)
	{
		gClientSceneGraph->renderScene( objMask );
	}
	else
	{
		gClientSceneGraph->renderScene( );
	}

	desc.fillMode = GFXFillSolid ;
	block = GFX->createStateBlock(desc);

	// TGEA 1.8 MOD - Begin
	mRenderTarget->attachTexture(GFXTextureTarget::Color0, NULL);
	mRenderTarget->attachTexture(GFXTextureTarget::DepthStencil, NULL);
	GFX->popActiveRenderTarget();
	// TGEA 1.8 MOD - End

	// set the clip
	GFX->setClipRect(updateRect);

	// turn off z clipping
	desc.setZEnable(false);
	block = GFX->createStateBlock(desc);

	//************************************
	//************************************
	//************************************
	mModelViewProj = mEffectShader->Shader->mShader->getShaderConstHandle(ShaderGenVars::modelview);

	//after this is all surfaces
	//**************************************

	// set ortho projection matrix
	// this makes ur view of the effect appears as directly above
	MatrixF proj = GFX->getProjectionMatrix();
	MatrixF newMat(true);
	GFX->setProjectionMatrix( newMat );
	GFX->pushWorldMatrix();
	GFX->setWorldMatrix( newMat );
	mEffectShader->ConstBuffer->set(mModelViewProj, newMat);

	GFX->setStateBlock(block);

	//**********************************

	// ortho geometry
	GFXVertexBuffer *vb=NULL;
	PrimBuild::color4f( mFilterColor.red , mFilterColor.green , mFilterColor.blue, mFilterColor.alpha );
	PrimBuild::beginToBuffer( GFXTriangleFan, 4 );
	PrimBuild::texCoord2f( 0.0, 1.0 );
	PrimBuild::vertex3f( -1.0 , -1.0 , 0.0 );
	PrimBuild::texCoord2f( 0.0, 0.0 );
	PrimBuild::vertex3f( -1.0 , 1.0 , 0.0 );
	PrimBuild::texCoord2f( 1.0, 0.0 );
	PrimBuild::vertex3f( 1.0 , 1.0 , 0.0 );
	PrimBuild::texCoord2f( 1.0, 1.0 );
	PrimBuild::vertex3f( 1.0 , -1.0 , 0.0 );
	U32 numPrims;
	vb = PrimBuild::endToBuffer( numPrims );

	mEffectShader->Shader->mShader->process();
	GFX->setShaderConstBuffer(mEffectShader->ConstBuffer);

	GFX->setTexture( 0, mSurface[0] );
	GFX->setVertexBuffer( vb );
	GFX->drawPrimitive( GFXTriangleFan, 0, 2 );
	GFX->disableShaders();

	//**********************************************

	desc.alphaTestEnable = false ;
	desc.setCullMode( GFXCullNone );
	desc.ffLighting = false ;
	desc.zWriteEnable = true ;
	desc.samplers[0].textureColorOp = GFXTOPDisable ;
	block = GFX->createStateBlock(desc);
	GFX->setStateBlock(block);
	GFX->disableShaders();
	GFX->popWorldMatrix();

	FrameAllocator::setWaterMark(0); 
}

static void SetEffectMode(SimObject *obj, S32, const char **argv)
{
	GameTSCtrl *ctrl = static_cast<GameTSCtrl*>(obj);
	S32 modeIn = (dAtof(argv[2]));

	ctrl->effectMode = modeIn;
}

static void ToggleEffectMode(SimObject *obj, S32, const char **argv)
{
	GameTSCtrl *ctrl = static_cast<GameTSCtrl*>(obj);

	if (ctrl->effectMode < 2)
	{
		ctrl->effectMode = ctrl->effectMode + 1;
	}
	else
	{
		ctrl->effectMode = 0;
	}
}

static void ResetEffectMode(SimObject *obj, S32, const char **argv)
{
	GameTSCtrl *ctrl = static_cast<GameTSCtrl*>(obj);

	// set the effect mode to 0 (normal rendering)
	ctrl->effectMode = 0;
}

static int GetEffectMode(SimObject *obj, S32, const char **argv)
{
	GameTSCtrl *ctrl = static_cast<GameTSCtrl*>(obj);

	// return the effect mode integer
	return ctrl->effectMode;
}

// ShaderPool Mod
static void LoadEffectByName(SimObject* obj, S32, const char** argv)
{
	GameTSCtrl *ctrl						= static_cast<GameTSCtrl*>(obj);
	std::vector<CustomShader*>* shaderPool	= &ctrl->shaderPool;
	S32 poolSize							= (S32)shaderPool->size();
	const char* shaderName					= argv[2];
	bool activateEffect						= (dAtob(argv[3]));
	bool foundEffect						= false;
	
	// Look for shader name
	ctrl->effectMode = -1;
	for(S32 i = 0; i < poolSize; i++)
	{
		// Found it?
		if(strcmp(shaderPool->at(i)->Name, shaderName) == 0)
		{
			// should we activate the effect?
			if(activateEffect) ctrl->effectMode = i;

			// yes we found an effect
			foundEffect = true;
			break;
		}
	}

	// We haven't found the shader yet, try to create one
	if(ctrl->effectMode == -1)
	{
		// attempt to get the shaderName's shader data
		ShaderData* shaderData = static_cast<ShaderData*>(Sim::findObject( shaderName ) );

		// we has found one?
		if(shaderData)
		{
			// create new custom shader
			CustomShader* cs = new CustomShader();

			// set properties
			cs->Shader = shaderData;
			sprintf_s(cs->Name, sizeof(cs->Name), "%s", shaderName);
			cs->Id = (S32)shaderPool->size();
			cs->ConstBuffer = cs->Shader->mShader->allocConstBuffer();
			if (cs->ConstBuffer) cs->Shader->mapSamplerNames(cs->ConstBuffer);

			// add the new customshader to the shaderpool
			shaderPool->push_back(cs);

			// set effectMode if we have to activate it
			if(activateEffect) ctrl->effectMode = cs->Id;

			// we found an effect :)
			foundEffect = true;
		}
	}

	// if we didn't find an effect..
	if(!foundEffect)
	{
		char errorMessage[256];
		sprintf_s(errorMessage, sizeof(errorMessage), "\"%s\" is not a valid full screen shader name.", shaderName);
		AssertFatal((ctrl->effectMode != -1), errorMessage);
	}
}

void GameTSCtrl::consoleInit()
{
	Con::addCommand("GameTSCtrl", "toggleEffectMode",	ToggleEffectMode,   "GameTSCtrl.setEffectMode(value)",		3, 3);
	Con::addCommand("GameTSCtrl", "setEffectMode",		SetEffectMode,		"GameTSCtrl.setEffectMode(value)",		3, 3);
	Con::addCommand("GameTSCtrl", "resetEffectMode",	ResetEffectMode,	"GameTSCtrl.resetEffectMode(value)",	3, 3);
	Con::addCommand("GameTSCtrl", "getEffectMode",		GetEffectMode,		"GameTSCtrl.getEffectMode(value)",		3, 3);

	// ShaderPool Mod
	Con::addCommand("GameTSCtrl", "loadEffectByName",	LoadEffectByName,	"GameTSCtrl.setEffectModeByName(string effectName, bool makeActive)",4, 4);
}

//---------------------------------------------------------------------------
void GameTSCtrl::onMouseMove(const GuiEvent &evt)
{
   if(gSnapLine)
      return;

   MatrixF mat;
   Point3F vel;
   if ( GameGetCameraTransform(&mat, &vel) )
   {
      Point3F pos;
      mat.getColumn(3,&pos);
      Point3F screenPoint((F32)evt.mousePoint.x, (F32)evt.mousePoint.y, -1.0f);
      Point3F worldPoint;
      if (unproject(screenPoint, &worldPoint)) {
         Point3F vec = worldPoint - pos;
         lineTestStart = pos;
         vec.normalizeSafe();
         lineTestEnd = pos + vec * 1000;
      }
   }
}

void GameTSCtrl::onRender(Point2I offset, const RectI &updateRect)
{
   // check if should bother with a render
   GameConnection * con = GameConnection::getConnectionToServer();
   bool skipRender = !con || (con->getWhiteOut() >= 1.f) || (con->getDamageFlash() >= 1.f) || (con->getBlackOut() >= 1.f);

   if(!skipRender || true)
      Parent::onRender(offset, updateRect);

   GFX->setViewport( updateRect );
   CameraQuery camq;
   if(GameProcessCameraQuery(&camq))
      GameRenderFilters(camq);
}

//--------------------------------------------------------------------------
ConsoleFunction( snapToggle, void, 1, 1, "()" )
{
   gSnapLine = !gSnapLine;
}
