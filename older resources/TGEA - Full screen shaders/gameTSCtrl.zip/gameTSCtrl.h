//-----------------------------------------------------------------------------
// Torque Game Engine Advanced
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _GAMETSCTRL_H_
#define _GAMETSCTRL_H_

#ifndef _GAME_H_
#include "app/game.h"
#endif

#ifndef _GUITSCONTROL_H_
#include "gui/3d/guiTSControl.h"
#endif

// ShaderPool Mod
#ifndef _VECTOR_
#include <vector>
#endif

//---------------------------------------
//  fullscreen shader effects
//---------------------------------------
#ifndef _SHADERDATA_H_
#include "materials/shaderData.h"
#endif
//---------------------------------------


class ProjectileData;
class GameBase;
class GFXTextureTarget;

// ShaderPool Mod
class CustomShader
{
public:
	CustomShader()
	{
		Shader = NULL;
		for(U32 i = 0; i < sizeof(Name); i++)
			Name[i] = 0;
		Id = 0;
		ConstBuffer = 0;
	}

	~CustomShader()
	{
	}

	ShaderData*				Shader;
	char					Name[64];
	S32						Id;
	GFXShaderConstBufferRef	ConstBuffer;
};

//----------------------------------------------------------------------------
class GameTSCtrl : public GuiTSCtrl
{
private:
   typedef GuiTSCtrl Parent;

   Point2F						offsetConsts[4];
   Point4F						offsets;
   ColorF						mFilterColor;
   GFXTexHandle					mSurface[3];
   GFXTexHandle					mBitmapObject;
   StringTableEntry				mBitmapName;
   GFXShaderConstHandle*		mModelViewProj;
   GFXTextureTarget*			mRenderTarget;

public:
   GameTSCtrl();
   ~GameTSCtrl();

   S32							effectMode;
   void							renderWorldEffect(const RectI &updateRect, CustomShader *mEffectShader, U32 objMask, GFXFillMode fMode);
   bool							processCameraQuery(CameraQuery *query);
   void							renderWorld(const RectI &updateRect);

   void							onMouseMove(const GuiEvent &evt);
   void							onRender(Point2I offset, const RectI &updateRect);
   static void					consoleInit();

   // ShaderPool Mod
   std::vector<CustomShader*> shaderPool;

   DECLARE_CONOBJECT(GameTSCtrl);
};

#endif
