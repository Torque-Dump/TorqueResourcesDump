// phdana droids ->
// code adapted from xXX given to me by vinci_smurf

//
// Built from Logic and code found in Player class
//
//	Filename : Turret.cc
#include "turret.h"
#include "console/console.h"
#include "console/consoleTypes.h"
#include "console/consoleInternal.h"
#include "T3D/gameConnection.h"
#include "core/stream/bitStream.h"
#include "core/resourceManager.h"
#include "ts/tsShapeInstance.h"
#include "T3D/moveManager.h" 

static U32 sDirtySetMask = PlayerObjectType     |
						   TurretObjectType     |
                           VehicleObjectType;

static U32 sClientCollisionMask = 
      TerrainObjectType    | InteriorObjectType       |
      PlayerObjectType     | StaticShapeObjectType    |
      VehicleObjectType    | VehicleBlockerObjectType |
	  TurretObjectType     | StaticTSObjectType;

IMPLEMENT_CO_DATABLOCK_V1(TurretData);


void TurretData::initPersistFields()
{
   Parent::initPersistFields();

   addField("activateTime", TypeF32, Offset(activateTime, TurretData));
   addField("maxPitchSpeed", TypeF32,  Offset(maxPitchSpeed, TurretData));
   addField("maxYawSpeed", TypeF32,  Offset(maxYawSpeed, TurretData));
   addField("minPitch", TypeF32, Offset(minPitch, TurretData));
   addField("maxPitch", TypeF32, Offset(maxPitch, TurretData));
   addField("minYaw", TypeF32, Offset(minYaw, TurretData));
   addField("maxYaw", TypeF32, Offset(maxYaw, TurretData));
}

void TurretData::consoleInit()
{

}

void TurretData::packData(BitStream* stream)
{
	Parent::packData(stream);

   stream->write(maxPitchSpeed);
   stream->write(maxYawSpeed);
   stream->write(activateTime);
   stream->write(minPitch);
   stream->write(maxPitch);
   stream->write(minYaw);
   stream->write(maxYaw);
}

void TurretData::unpackData(BitStream* stream)
{
	Parent::unpackData(stream);
   stream->read(&maxPitchSpeed);
   stream->read(&maxYawSpeed);
   stream->read(&activateTime);
   stream->read(&minPitch);
   stream->read(&maxPitch);
   stream->read(&minYaw);
   stream->read(&maxYaw);
}

bool TurretData::preload(bool server, String &errorBuffer)
{
   if (!Parent::preload(server, errorBuffer))
      return false;
   if (shapeName && shapeName[0])
   {
      // Resolve shapename
      shapeResource = ResourceManager::get().load(shapeName);
      if (!bool(shapeResource))
      {
         // dSprintf(errorBuffer, 256, "TankData: Couldn't load shape \"%s\"",shapeName);
         errorBuffer = String::ToString("TankData: Couldn't load shape \"%s\"", shapeName);
         return false;
      }
      if(!server && !shapeResource->preloadMaterialList(shapeResource.getPath()) && NetConnection::filesWereDownloaded())
         return false;
   }

   TSShapeInstance * si = new TSShapeInstance(shapeResource,false);

   /*
   // collisions
   numCollDetails = 0;
   for (S32 i=0; i<MaxCollisionShapes; i++)
   {
      char buff[128];
      dSprintf(buff,sizeof(buff),"Collision-%i",i+1);
      collDetails[i] = shapeResource->findDetail(buff);
      if (collDetails[i]>=0)
         ++numCollDetails;
      else
         break;
   }
   */


   // get nodes from shape
   turretNode = shapeResource->findNode("codeTurret");
   weaponNode = shapeResource->findNode("codeWeapon");

   delete si;
   si = NULL;

	return true;
}

TurretData::TurretData()
{
   turretNode = -1;
   weaponNode = -1;

   activateTime = 2.0;   // seconds
   maxPitchSpeed = 90.0; // degrees/second 
   maxYawSpeed = 90.0;   // degrees/second 
   minPitch = -90;
   maxPitch = 90;
   minYaw = -180;   // we speak of the constraints on yaw as if it's range
   maxYaw = 180;    // were -180/180 even tho it's actually stored as 0..360
}

TurretData::~TurretData()
{

}

IMPLEMENT_CO_NETOBJECT_V1(Turret);

void Turret::initPersistFields()
{
   Parent::initPersistFields();
}


bool Turret::onAdd()
{
   return onAdd(true);
}
bool Turret::onAdd(bool callScript)
{
	if(!Parent::onAdd() || !mDataBlock)
		return false;

	addToScene(); 

	if (isServerObject())
   {
     if (callScript)
	     scriptOnAdd();
      // old code...this is T2 stuff that is no longer in engine
      // does not help to add to these sets
	   //add to missile targeting
      //Sim::getServerTargetSet()->addObject(this);
	   //Sim::getClientTargetSet()->addObject(this);
    }
	return true;
}

void Turret::onRemove()
{
   onRemove(true);
}
void Turret::onRemove(bool callScript)
{
	setControlObject(0);
   if (callScript)
	   scriptOnRemove();
	removeFromScene();

	Parent::onRemove();
}

bool Turret::onNewDataBlock(GameBaseData *dptr)
{
   return onNewDataBlock(dptr,true);
}
bool Turret::onNewDataBlock(GameBaseData *dptr, bool callScript)
{
	mDataBlock = dynamic_cast<TurretData*>(dptr);
	if (!mDataBlock || !Parent::onNewDataBlock(dptr))
		return false;

   // rid us of old shape instance...
   delete mShapeInstance;
   mShapeInstance = NULL;

   // load new shape instance...
   AssertFatal(bool(getDataBlock()->shapeResource),
      "SpaceVehicle::onNewDataBlock: no shape resource");
   mShapeInstance = new TSShapeInstance(getDataBlock()->shapeResource, isClientObject());

   // mark callback nodes (for turret/weapon control)
   mShapeInstance->setNodeAnimationState(getDataBlock()->turretNode,TSShapeInstance::MaskNodeHandsOff);
   mShapeInstance->setNodeAnimationState(getDataBlock()->weaponNode,TSShapeInstance::MaskNodeHandsOff);

	TSShape const* shape =mShapeInstance->getShape();
	S32 activateSeq = shape->findSequence("activate");
	if(activateSeq != -1){
	Con::printf("ACTIVATE sequence found");
	mActivateThread = mShapeInstance->addThread();

		mShapeInstance->setPos( mActivateThread, 0 );
		mShapeInstance->setTimeScale( mActivateThread, 0 );
		mShapeInstance->setSequence( mActivateThread, activateSeq, 0 );
	
	}
	else
		mActivateThread = 0;

   // this sets the bounding box...why isn't this a function
   // call rather than messing with a parent variable (which
   // also happens to have it's effect via side-effect)?
   // Because this is Torque, get used to it.
   // Note: this is done in onNewDataBlock because this info
   // normally comes from the data block (either from a shape
   // in the data block or the data block explicitly).
   //mObjBox = getDataBlock()->objectBox;


   // we initialize this turret's data from the datablock
   // (it can be changed later on as desired)
   // really we only need to do this on the server
   // because the client will get these values from packUpdate
   if (isServerObject())
      resetTurretOptions();
 
   // leaf classes must call this...one annoying side-effect
   // is that if we derive from Tank we get two calls to
   // the script onAdd method.
   if (callScript)
      scriptOnNewDataBlock();
   return true;
}

void Turret::updateLookAnimation()
{

   if (mActivateThread)
   {
      U32 now = Sim::getCurrentTime();
      if (startActive > 0 && now < (startActive+mActivateTime))
      {
         F32 t = (F32)(now-startActive)/(F32)(mActivateTime);
         if (!isActive)
             t = 1.0 - t;
   	   mShapeInstance->setPos(mActivateThread,t);
       }
       else
       {
   	   mShapeInstance->setPos(mActivateThread,isActive?1.0:0.0);
       }
	 }

   // set turret...
   S32 node = getDataBlock()->turretNode;
   MatrixF * mat = &mShapeInstance->mNodeTransforms[node];
   Point3F defaultPos = getDataBlock()->shapeResource->defaultTranslations[node];
   mat->set(EulerF(0,0,mRot.z));
   mat->setColumn(3,defaultPos);

   // set weapon...
   node = getDataBlock()->weaponNode;
   mat = &mShapeInstance->mNodeTransforms[node];
   defaultPos = getDataBlock()->shapeResource->defaultTranslations[node];
   mat->set(EulerF(mRot.x,0,0));
   mat->setColumn(3,defaultPos);

   mShapeInstance->setDirty(TSShapeInstance::TransformDirty);
   mShapeInstance->animate();
}

// manually set a move that will be used at next processTick()
void Turret::setNextMove(const Move *move)
{
   nextSetMove = &nextSetMoveBuffer;
   *nextSetMove = *move;
}

// utility code to determine whether to take the shortest path to the given new yaw
bool Turret::takeClosestYaw(F32 currYaw, F32 newYaw)
{
   // if we are controlled then we are unfettered
   if (mControlObject)
      return true;

   // if we are unfettered then always take closest
   if (mMinYaw == -M_PI && mMaxYaw == M_PI)
      return true;

   // if new yaw is inside illegal zone...then take closest
   // (it will be stopped at limits of course)
   if (newYaw > mMaxYaw || newYaw < mMinYaw)
      return true;

   // if new and old on same side...take closest
   if (currYaw <= 0 && newYaw <= 0)
      return true;
   if (currYaw >= 0 && newYaw >= 0)
      return true;

   // if closest crosses the no-no land then dont do it!
   if (currYaw > (M_PI/2.0) && newYaw < (-M_PI/2.0))
      return false;
   if (currYaw < (-M_PI/2.0) && newYaw > (M_PI/2.0))
      return false;

   // it dont cross the no-no land
   return true;
}

// utility code to limit the pitch and yaw on a move
void Turret::limitMoveAngles(Move* move, bool clientControlled)
{
   // start with move as is
   F32 pitch = move->pitch;
   F32 yaw = move->yaw;

   // it looks like this code is never executing because
   // moves are already restricted to this range....

   // if we have limits then right now restrict to -PI/PI
   if (mMinYaw != -M_PI || mMaxYaw != M_PI)
   {
      if (yaw < -M_PI)
         while (yaw < -M_PI)
            yaw += M_2PI;
      else if (yaw > M_PI)
         while (yaw > M_PI)
            yaw -= M_2PI;
   }
   
   // put newYaw and oldYaw into -PI/PI range from 0..PI range
   F32 oldYaw = mRot.z;
   F32 newYaw = mRot.z + yaw;

   if (newYaw > M_PI)
      newYaw -= M_2PI;
   else if (newYaw < -M_PI)
      newYaw += M_2PI;

   if (oldYaw > M_PI)
      oldYaw -= M_2PI;
   else if (oldYaw < -M_PI)
      oldYaw += M_2PI;

   // should we take the closest yaw?
   //bool closestYaw = clientControlled?true:takeClosestYaw(oldYaw, newYaw);
   bool closestYaw = takeClosestYaw(oldYaw, newYaw);

   // limit Yaw by angles
   if (mMinYaw != -M_PI || mMaxYaw != M_PI)
   {
     // limit yaw...
     if (newYaw < mMinYaw)
       yaw -= (newYaw - mMinYaw);
     else if (newYaw > mMaxYaw)
       yaw -= (newYaw - mMaxYaw);
   }

   // now make sure we take the short way around the circle
   if (closestYaw)
   {
      if( yaw > M_PI )
         yaw -= M_2PI;
      else if( yaw < -M_PI )
         yaw += M_2PI;
   }

   // limit yaw by angular speed (unless we are controlled)
   // we may want an option in future to limit ang speeds even when controlled
   if (!clientControlled)
   {
      if (yaw > mMaxYawSpeed)
         yaw = mMaxYawSpeed;
      else if (yaw < -mMaxYawSpeed)
         yaw = -mMaxYawSpeed;

      // limit pitch
      if (pitch > mMaxPitchSpeed)
         pitch = mMaxPitchSpeed;
      else if (pitch < -mMaxPitchSpeed)
         pitch = -mMaxPitchSpeed;
   }

   // save back out now limited;
   move->yaw = yaw;
   move->pitch = pitch;
}

// normally dervied classes implement this...but we also put some
// behaviour here as well..this code generates moves to return
// pitch/yaw to zero upon deactivation and to process manually set "next" moves
bool Turret::getAIMove(Move* movePtr)
{
   // if someone has manually set a "next move" then return that move
   if (nextSetMove != NULL)
   {
      *movePtr = *nextSetMove;
      nextSetMove = NULL;

      limitMoveAngles(movePtr);
      return true;
   }

   // if we are deactivating then return pitch/yaw to normal
   // by generating the appropriate moves...
   if (isDeactivating() && (mRot.x != 0 || mRot.z != 0))
   {      
      // generate moves to return us to pitch/yaw of 0,0
      *movePtr = NullMove;

      // just set
      movePtr->yaw = -mRot.z;
      movePtr->pitch = -mRot.x;

      // now limit		 
      limitMoveAngles(movePtr);

      // do this move!!!
      return true;
      
   }

   return false;
}   

void Turret::processTick(const Move* move)
{
   // If we're not being controlled by a client, let the
   // AI sub-module get a chance at producing a move.
   // Note that the code to return pitch/yaw to zero values
   // on deactivate is implemented here as well as code
   // to process "next moves" that have been set manually
   Move aiMove;
   if (!move)
   {
      if (getAIMove(&aiMove))
         move = &aiMove;
   }
   else
   {
      // even limit when controlled by client
      aiMove = *move;
      move = &aiMove;
      limitMoveAngles(&aiMove,true);
   }

	//Con::printf("processTick called");
	//Con::printf("move is %d", move);
	//Move pMove,cMove;
	if(move) 
	{
		setImageTriggerState(0,move->trigger[0]);
		setImageTriggerState(1,move->trigger[1]);
	}
	if(mControlObject)
	{
		if(!move)
			mControlObject->processTick(0);
		else 
		{
		//	pMove = NullMove;
			//cMove = *move;
			if(isMounted())
			{
			}

		}
	}

	Parent::processTick(move);

		// Warp to catch up to server
   if (delta.warpTicks > 0) {
      delta.warpTicks--;

      // for now this is pointless since we dont
      // calculate the offset values in unpackUpdate()
      // the way player.cc does

      // Set new pos.
      //getTransform().getColumn(3,&delta.pos);
      //delta.pos += delta.warpOffset;
      //delta.rot += delta.rotOffset;
      //setPosition(delta.pos,delta.rot);

      delta.rotVec += delta.rotOffset;

      //setRenderPosition(delta.pos,delta.rot);
      //updateDeathOffsets();
      updateLookAnimation();

      // Backstepping
      //delta.posVec.x = -delta.warpOffset.x;
      //delta.posVec.y = -delta.warpOffset.y;
      //delta.posVec.z = -delta.warpOffset.z;
      //delta.rotVec.x = -delta.rotOffset.x;
      //delta.rotVec.y = -delta.rotOffset.y;
      //delta.rotVec.z = -delta.rotOffset.z;

      // backstep the turret values too
      delta.rotVec.x = -delta.rotOffset.x;
      delta.rotVec.z = -delta.rotOffset.y;
   }
   else {
      // If there is no move, the player is either an
      // unattached player on the server, or a player's
      // client ghost.
      if (!move) {
         if (isGhost()) {
            // If we haven't run out of prediction time,
            // predict using the last known move. 
            if (mPredictionCount-- <= 0)
            {
               
               return;
            }
            move = &delta.move;
         }
         else
            move = &NullMove;
      }

      if (isMounted()) {
         MatrixF mat;
         mMount.object->getMountTransform(mMount.node,&mat);
         Parent::setTransform(mat);
         Parent::setRenderTransform(mat);
      }

	  //if (!isGhost())
       //  updateAnimation(TickSec);

	  if(isServerObject() || (didRenderLastRender() || getControllingClient()))
      {
		  updateMove(move);
        updateLookAnimation();


        // for now turning just uses same mask as moving...
        setMaskBits(MoveMask);
      }
	}
}

void Turret::interpolateTick(F32 dt)
{
	if (mControlObject)
		mControlObject->interpolateTick(dt);
//Con::printf("interpolateTick called");
	// Client side interpolation
	Parent::interpolateTick(dt);

   if (isMounted()) {
      MatrixF mat;
      mMount.object->getRenderMountTransform(mMount.node,&mat);
      Parent::setRenderTransform(mat);
   }

   if(dt != 0.0f)
     mRot = delta.rot + delta.rotVec * dt;
   else
     mRot = delta.rot;

	updateLookAnimation();
   delta.dt = dt;
}

void Turret::advanceTime(F32 dt)
{
	Parent::advanceTime(dt);
}

void Turret::resetTurretOptions()
{
   // set from datablock data
   setTurretOptions(
      mDataBlock->maxYawSpeed, mDataBlock->maxPitchSpeed, 
      mDataBlock->activateTime, 
      mDataBlock->minYaw, mDataBlock->maxYaw, mDataBlock->minPitch,mDataBlock->maxPitch
   );
}

void Turret::setTurretOptions(F32 maxYawSpeed, F32 maxPitchSpeed, F32 activateTime, F32 minYaw, F32 maxYaw, F32 minPitch, F32 maxPitch)
{
   // convert from degrees/sec to radians/server tick
   mMaxYawSpeed = maxYawSpeed * (M_PI/180.0) * TickSec;
   mMaxPitchSpeed = maxPitchSpeed * (M_PI/180.0) * TickSec;

   // convert from sec to millisec
   mActivateTime = (U32) (activateTime * 1000.0);

   // don't allow nonsensical values
   if (minYaw > 0)
      minYaw = 0;
   if (maxYaw < 0)
      maxYaw = 0;

   // convert from degrees to radians
   // make sure if at min/max then it's exact
   // because we look for == M_PI later on...
   if (minYaw <= -180.0)
      mMinYaw = -M_PI;
   else
      mMinYaw = minYaw * M_PI / 180.0;

   if (maxYaw >= 180.0)
      mMaxYaw = M_PI;
   else
      mMaxYaw = maxYaw * M_PI / 180.0;

   // don't allow nonsensical values
   if (minPitch > 0)
      minPitch = 0;
   if (maxPitch < 0)
      maxPitch = 0;
   if (minPitch < -90.0)
      mMinPitch = -M_PI/2.0;
   else
      mMinPitch = minPitch * M_PI / 180.0;
   if (maxPitch > 90.0)
      mMaxPitch = M_PI/2.0;
   else
      mMaxPitch = maxPitch * M_PI / 180.0;

   if (isServerObject())
      setMaskBits(OptionsMask);
}


void Turret::onCameraScopeQuery(NetConnection *connection, CameraScopeQuery *query)
{
	if(mControlObject.isNull() || mControlObject == mMount.object)
		Parent::onCameraScopeQuery(connection, query);
	else
	{
		connection->objectInScope(this);
		if(isMounted())
			connection->objectInScope(mMount.object);
		mControlObject->onCameraScopeQuery(connection, query);
	}
}

void Turret::writePacketData(GameConnection *con, BitStream *stream)
{
  Parent::writePacketData(con, stream);

  stream->write(mRot.x); 
  stream->write(mRot.z);
  stream->writeFlag(isActive);
    
  return;
}

void Turret::readPacketData(GameConnection *con, BitStream *stream)
{
	Parent::readPacketData(con, stream);

 	stream->read(&mRot.x);
   stream->read(&mRot.z);
   setActive(stream->readFlag());

   delta.rot = mRot;
}

U32  Turret::packUpdate(NetConnection *con, U32 mask, BitStream *stream)
{
	U32 retMask = Parent::packUpdate(con, mask, stream);

   if (stream->writeFlag(mask & OptionsMask))
   {
      stream->write(mMaxPitchSpeed);
      stream->write(mMaxYawSpeed);
      stream->write(mActivateTime);
      stream->write(mMinYaw);
      stream->write(mMaxYaw);
      stream->write(mMinPitch);
      stream->write(mMaxPitch);
   }

   // The rest of the data is part of the control object packet update.
   // If we're controlled by this client, we don't need to send it.
   // we only need to send it if this is the initial update - in that case,
   // the client won't know this is the control object yet.
   if(stream->writeFlag(getControllingClient() == con && !(mask & InitialUpdateMask)))
      return(retMask);

   if (stream->writeFlag(mask & ActionMask))
   {		
     stream->writeFlag(isActive);
   }

   if (stream->writeFlag(mask & MoveMask))
   {		
		stream->writeAffineTransform(mObjToWorld);
      stream->write(mRot.x);
      stream->write(mRot.z);
	}
	

	return retMask;
}

void Turret::unpackUpdate(NetConnection *con, BitStream *stream)
{
	Parent::unpackUpdate(con,stream);

   // options
   if (stream->readFlag())
   {
      stream->read(&mMaxPitchSpeed);
      stream->read(&mMaxYawSpeed);
      stream->read(&mActivateTime);
      stream->read(&mMinYaw);
      stream->read(&mMaxYaw);
      stream->read(&mMinPitch);
      stream->read(&mMaxPitch);
   }

   // controlled by the client?
   if(stream->readFlag())
      return;

   // action?
   if (stream->readFlag())
   {
      setActive(stream->readFlag());
   }

   // move (or turret turn)
	if(stream->readFlag()) 
	{
		MatrixF ObjectMatrix;
		stream->readAffineTransform(&ObjectMatrix);
		setTransform(ObjectMatrix);

      // here is where we would setup warp ticks
      // easiest way would be to send the ang velocity
      // down the pipe and compared that to the ang
      // velocity at this and and using the ratio between them
      // to setup warp ticks the same way player does for lin velocity
      stream->read(&mRot.x);
      stream->read(&mRot.z);      

      delta.rot = mRot;
      delta.rotVec = VectorF(0,0,0);
	}
}

void Turret::setControllingClient(GameConnection* client)
{
	Parent::setControllingClient(client);
	if(mControlObject)
		mControlObject->setControllingClient(client);
}

// Object control
void Turret::setControlObject(ShapeBase *obj)
{
	if(mControlObject)
	{
		mControlObject->setControllingObject(0);
		mControlObject->setControllingClient(0);
	}
	if(obj == this || obj == 0)
		mControlObject = 0;
	else
	{
		if(ShapeBase* coo = obj->getControllingObject())
			coo->setControlObject(0);
		if(GameConnection* con = obj->getControllingClient())
			con->setControlObject(0);

		mControlObject = obj;
		mControlObject->setControllingObject(this);
		mControlObject->setControllingClient(getControllingClient());
	}
}

void Turret::disableCollision()
{
	Parent::disableCollision();
	for(ShapeBase* ptr = getMountList(); ptr; ptr = ptr->getMountLink())
		ptr->disableCollision();
}

void Turret::enableCollision()
{
	Parent::enableCollision();
	for (ShapeBase* ptr = getMountList(); ptr; ptr = ptr->getMountLink())
		ptr->enableCollision();
}

// this is called when player mounts object
// when player unmounts object this is dectected
// in script and a call is made to setActivate(false
// from that point in script
void Turret::mountObject(ShapeBase* obj, U32 node)
{
	Con::printf("player mounted turret");
	Parent::mountObject(obj, node);

   setActive(true);

	//mShapeInstance->setPos( mActivateThread, 0.5 );

	//setControlObject(obj);

	// Clear objects off the working list that are from objects mounted to us.
	//  (This applies mostly to players...)
//	for(CollisionWorkingList* itr = mConvex.getWorkingList().wLink.mNext; itr != &mConvex.getWorkingList(); itr = itr->wLink.mNext)
//	{
//		if(itr->mConvex->getObject() == obj) 
//		{
//			CollisionWorkingList* cl = itr;
//			itr = itr->wLink.mPrev;
//			cl->free();
//		}
//	}
}

// this is not called when we dismount...
// we call setActive(false) from script on dismount...
void Turret::unmountObject(ShapeBase* obj)
{
	Con::printf("player Unmounted OBJECT (turret)");
	Parent::unmountObject(obj);

   setActive(false);
}

// this is also not called when we dismount...
// we call setActive(false) from script on dismount...
void Turret::onUnmount(ShapeBase* obj)
{
	Con::printf("player Unmounted turret");
	Parent::unmountObject(obj);

//	mShapeInstance->setPos( mActivateThread, 0 );
		
	//setControlObject(obj);

	// Clear objects off the working list that are from objects mounted to us.
	//  (This applies mostly to players...)
//	for(CollisionWorkingList* itr = mConvex.getWorkingList().wLink.mNext; itr != &mConvex.getWorkingList(); itr = itr->wLink.mNext)
//	{
//		if(itr->mConvex->getObject() == obj) 
//		{
//			CollisionWorkingList* cl = itr;
//			itr = itr->wLink.mPrev;
//			cl->free();
//		}
//	}
}

bool Turret::mountImage(ShapeBaseImageData* imageData,U32 imageSlot,bool loaded,NetStringHandle &skinNameHandle)
{
  //Con::printf("barrell mounted turret");
 // Con::printf("image slot is %d" , imageSlot); 
  return Parent::mountImage(imageData, imageSlot,loaded,skinNameHandle);

}
void Turret::setPosition(const Point3F& pos,const Point3F& rot)
{
   MatrixF mat;
   if (isMounted()) {
      // Use transform from mounted object
      MatrixF nmat,zrot;
      mMount.object->getMountTransform(mMount.node,&nmat);
      //zrot.set(EulerF(0, 0, rot.z));
      zrot.set(EulerF(0, 0, 0));
      mat.mul(nmat,zrot);
   }
   else {
      //mat.set(EulerF(0, 0, rot.z));
      mat.set(EulerF(0, 0, 0));
      mat.setColumn(3,pos);
   }
   Parent::setTransform(mat);
   //mRot = rot;
}

void Turret::setRenderPosition(const Point3F& pos, const Point3F& rot)
{
   MatrixF mat;
   if (isMounted()) {
      // Use transform from mounted object
      MatrixF nmat,zrot;
      mMount.object->getRenderMountTransform(mMount.node,&nmat);
      //zrot.set(EulerF(0, 0, rot.z));
      zrot.set(EulerF(0, 0, 0));
      mat.mul(nmat,zrot);
   }
   else {
      EulerF   orient(0, 0, 0);
      //EulerF   orient(0, 0, rot.z);
      
      mat.set(orient);
      mat.setColumn(3, pos);
   }
   Parent::setRenderTransform(mat);
}

void Turret::setTransform(const MatrixF& newMat)
{
   Parent::setTransform(newMat);

   //Point3F pos,vec;
   //newMat.getColumn(1,&vec);
   //newMat.getColumn(3,&pos);
   //Point3F rot(0,0,-mAtan(-vec.x,vec.y));
   //setPosition(pos,rot);
   //setMaskBits(MoveMask | NoWarpMask);
   //setControlDirty();
}

bool Turret::buildPolyList(AbstractPolyList* polyList, const Box3F& box, const SphereF& sphere)
{
	return Parent::buildPolyList(polyList, box, sphere);
/*	Point3F pos;
	getTransform().getColumn(3,&pos);
	IMat.setColumn(3,pos);
	polyList->setTransform(&IMat, Point3F(1,1,1));
	polyList->setObject(this);
	polyList->addBox(mObjBox);
	return true;*/
}

void Turret::buildConvex(const Box3F& box, Convex* convex)
{
	Parent::buildConvex(box, convex);
/*   if (mShapeInstance == NULL)
      return;

   // These should really come out of a pool
   mConvexList->collectGarbage();

   Box3F realBox = box;
   mWorldToObj.mul(realBox);
   realBox.min.convolveInverse(mObjScale);
   realBox.max.convolveInverse(mObjScale);

   if (realBox.isOverlapped(getObjBox()) == false)
      return;

   Convex* cc = 0;
   CollisionWorkingList& wl = convex->getWorkingList();
   for (CollisionWorkingList* itr = wl.wLink.mNext; itr != &wl; itr = itr->wLink.mNext) {
      if (itr->mConvex->getType() == BoxConvexType &&
          itr->mConvex->getObject() == this) {
         cc = itr->mConvex;
         break;
      }
   }
   if (cc)
      return;

   // Create a new convex.
   BoxConvex* cp = new OrthoBoxConvex;
   mConvexList->registerObject(cp);
   convex->addToWorkingList(cp);
   cp->init(this);

   mObjBox.getCenter(&cp->mCenter);
   cp->mSize.x = mObjBox.len_x() / 2.0f;
   cp->mSize.y = mObjBox.len_y() / 2.0f;
   cp->mSize.z = mObjBox.len_z() / 2.0f;
*/
}



ShapeBase* Turret::getControlObject()
{
	return mControlObject;
}

Turret::Turret()
{
	mTypeMask |= TurretObjectType;
	mControlObject		= 0;
	mDataBlock			= 0;
	mActivateThread		= 0;

   delta.rotOffset = Point3F(0,0,0);
   delta.rotVec = VectorF(0,0,0);
   delta.warpTicks = 0;
   delta.dt = 1;
   delta.move = NullMove;

   mRot = delta.rot;

   // defaults
   mRot.x = 0.0;
   mRot.z = 0.0;

   isActive = false;
   startActive = 0;

   nextSetMove = NULL;
}


Turret::~Turret()
{

}

void Turret::consoleInit()
{
	Parent::initPersistFields();
}

void Turret::updateMove(const Move* move) 
{ 
   if(move)
	{
	  delta.rotVec =mRot;

	  F32 p = move->pitch;
     //if (p != 0.0)
     //  Con::printf("pitch moved %f",p);

	  if(p>M_PI)
        p -= M_2PI;
	  mRot.x = mClampF(mRot.x + p, mMinPitch, mMaxPitch);

     F32 y  = move->yaw;
     //if (y != 0.0)
     //  Con::printf("yaw moved %f",y);

     // get new yaw value
	  if(y>M_PI)
        y -= M_2PI;
     mRot.z = mRot.z + y;
     
     delta.rotVec -= mRot;

     // this was the other part of choppiness
     // i was doing this bounds check too early 
     // and it was screwing up delta.rotVec
     if (mRot.z < 0)
         mRot.z += M_2PI;
     if (mRot.z > M_2PI)
         mRot.z -= M_2PI;
     delta.rot = mRot;
   }
}

void Turret::setActive(bool activeFlag)
{
   if (isActive == activeFlag)
      return;

   isActive = activeFlag;

   // start of activity or inactivity
   startActive = Sim::getCurrentTime();

   setMaskBits(ActionMask);
}

bool Turret::getActive()
{
   return isActive;
}

bool Turret::isActivating()
{
   if (!isActive)
      return false;

   U32 now = Sim::getCurrentTime();
   if (startActive > 0 && now < (startActive+mActivateTime))
      return true;

   return false;
}

bool Turret::isActivated()
{
   if (!isActive)
      return false;

   U32 now = Sim::getCurrentTime();
   if (startActive > 0 && now < (startActive+mActivateTime))
      return false;

   return true;
}

bool Turret::isDeactivating()
{
   if (isActive)
      return false;

   U32 now = Sim::getCurrentTime();
   if (startActive > 0 && now < (startActive+mActivateTime))
      return true;

   return false;
}

bool Turret::isDeactivated()
{
   if (isActive)
      return false;

   U32 now = Sim::getCurrentTime();
   if (startActive > 0 && now < (startActive+mActivateTime))
      return false;

   return true;
}

/**
 * Activate/Deactive the turret
 */
ConsoleMethod( Turret, setActive, void, 3, 3, "turret.setActive( %activeFlag );" )
{
   Turret *turret = static_cast<Turret *>( object );
   turret->setActive(dAtob(argv[2]));
}

/**
 * Get turret active state
 */
ConsoleMethod( Turret, getActive, bool, 2, 2, "turret.getActive( );" )
{
   Turret *turret = static_cast<Turret *>( object );
   return turret->getActive();
}

/**
 * Is turret Activating?
 */
ConsoleMethod( Turret, isActivating, bool, 2, 2, "turret.isActivating();" )
{
   Turret *turret = static_cast<Turret *>( object );
   return turret->isActivating();
}


/**
 * Is turret Activated?
 */
ConsoleMethod( Turret, isActivated, bool, 2, 2, "turret.isActivated();" )
{
   Turret *turret = static_cast<Turret *>( object );
   return turret->isActivated();
}

/**
 * Is turret Deactivating?
 */
ConsoleMethod( Turret, isDeactivating, bool, 2, 2, "turret.isDeactivating();" )
{
   Turret *turret = static_cast<Turret *>( object );
   return turret->isDeactivating();
}


/**
 * Is turret Deactivated?
 */
ConsoleMethod( Turret, isDeactivated, bool, 2, 2, "turret.isDeactivated();" )
{
   Turret *turret = static_cast<Turret *>( object );
   return turret->isDeactivated();
}

/**
 * reset turret options to default values from datablock
 */
ConsoleMethod( Turret, resetTurretOptions, void, 2, 2, "turret.resetTurretOptions();" )
{
   Turret *turret = static_cast<Turret *>( object );
   turret->resetTurretOptions();
}


/**
 * set turret options to specific values
 */
ConsoleMethod( Turret, setTurretOptions, void, 9, 9, 
   "turret.setTurretOptions(maxYawSpeed,maxPitchSpeed,activateTime,minYaw,maxYaw,minPitch,maxPitch);" )
{
   Turret *turret = static_cast<Turret *>( object );
   if (argc >= 9)
   {
      turret->setTurretOptions(dAtof(argv[2]),dAtof(argv[3]),dAtof(argv[4]),
         dAtof(argv[5]),dAtof(argv[6]),dAtof(argv[7]),dAtof(argv[8]));
   }
}


// <- phdana droids
