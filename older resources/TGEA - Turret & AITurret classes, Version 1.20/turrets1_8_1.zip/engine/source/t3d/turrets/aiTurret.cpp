// phdana droids ->
//-----------------------------------------------------------------------------
// Torque Game Engine
// 
// Copyright (c) 2001 GarageGames.Com
// Portions Copyright (c) 2001 by Sierra Online, Inc.
//-----------------------------------------------------------------------------
#include "aiTurret.h"
#include "console/consoleInternal.h"
#include "math/mMatrix.h"
#include "math/mathUtils.h"
#include "math/mMathFn.h"
#include "console/console.h"
#include "console/consoleTypes.h"
#include "console/consoleInternal.h"
#include "T3D/gameConnection.h"
#include "T3D/moveManager.h" 
#include "core/stream/bitStream.h"
#include "core/resourceManager.h"

namespace {

// the rest of methods are done below using "ConsoleMethod"
// this done here because of reserved name "delete"
void cAITurretDelete(SimObject* obj, S32, const char** argv)
{
   AssertFatal(dynamic_cast<AITurret*>(obj) != NULL, "Error, how did a non-AITurret get here?");
   AITurret* trigger = static_cast<AITurret*>(obj);

   trigger->preDelete();
   trigger->deleteObject();
} 


} // namespace {}

//----------------------------------------------------------------------------

IMPLEMENT_CO_DATABLOCK_V1(AITurretData);

AITurretData::AITurretData()
{
   triggerPeriodMS = 96;  // 3 server ticks (roughly 1/10th of a second)
   triggerRadius = 100.0;  // 100 meters
   thinkPeriodMS = 0;      // default to NO periodic thinking

   missRadius = 0;
   projectileInheritVelocity = 0;
   projectileVelocity = -1;
   projectileGravityMod = 0;
   projectileBallistic = false;
   imageSeeks = false;
}

void AITurretData::consoleInit()
{
}


void AITurretData::initPersistFields()
{
   Parent::initPersistFields();

   addField("triggerPeriodMS", TypeS32,  Offset(triggerPeriodMS, AITurretData));
   addField("thinkPeriodMS", TypeS32,  Offset(thinkPeriodMS, AITurretData));
   addField("triggerRadius", TypeF32,  Offset(triggerRadius, AITurretData));

   addField("missRadius", TypeF32,  Offset(missRadius, AITurretData));
   addField("projectileInheritVelocity", TypeF32,  Offset(projectileInheritVelocity, AITurretData));
   addField("projectileVelocity", TypeF32,  Offset(projectileVelocity, AITurretData));
   addField("projectileGravityMod", TypeF32,  Offset(projectileGravityMod, AITurretData));
   addField("projectileBallistic", TypeBool,  Offset(projectileBallistic, AITurretData));
   addField("imageSeeks", TypeBool,  Offset(imageSeeks, AITurretData));
}

void AITurretData::packData(BitStream* stream)
{
   Parent::packData(stream);
   stream->write(triggerPeriodMS);
   stream->write(thinkPeriodMS);
   stream->write(triggerRadius);

   stream->write(missRadius);
   stream->write(projectileInheritVelocity);
   stream->write(projectileVelocity);
   stream->write(projectileGravityMod);
   stream->writeFlag(projectileBallistic);
   stream->writeFlag(imageSeeks);
}

void AITurretData::unpackData(BitStream* stream)
{
   Parent::unpackData(stream);
   stream->read(&triggerPeriodMS);
   stream->read(&thinkPeriodMS);
   stream->read(&triggerRadius);

   stream->read(&missRadius);
   stream->read(&projectileInheritVelocity);
   stream->read(&projectileVelocity);
   stream->read(&projectileGravityMod);
   projectileBallistic = stream->readFlag();
   imageSeeks = stream->readFlag();
}

//--------------------------------------------------------------------------
IMPLEMENT_CO_NETOBJECT_V1(AITurret);

/**
 * Constructor
 */
AITurret::AITurret()
{
   // now we have a trigger object
   // created for us which will call
   // into our potentialEnterObject() 
   //mTypeMask |= TriggerObjectType;

   mDataBlock = NULL;

   mTrigger = NULL;

   mLastThinkingThink = 0;
   mCurrThinkingTick  = 0;
   mLastTriggerThink = 0;
   mCurrTriggerTick  = 0;

   mAimObject = 0;
   mAimLocationSet = false;
   mTargetInLOS = false;
}

/**
 * Destructor
 */
AITurret::~AITurret()
{
}


//-----------------------------------------------------------------------------

void AITurret::initPersistFields()
{
   Parent::initPersistFields();
}


void AITurret::consoleInit()
{
   // the rest of methods are done below using "ConsoleMethod"
   // this done here because of reserved name "delete"
   Con::addCommand("AITurret", "delete",  cAITurretDelete,  "[AITurret].delete()",            2, 2);
}

void AITurret::writePacketData(GameConnection *con, BitStream *stream)
{
  Parent::writePacketData(con, stream);

  return;
}

void AITurret::readPacketData(GameConnection *con, BitStream *stream)
{
	Parent::readPacketData(con, stream);

   //
   delta.rot = mRot;
}

U32  AITurret::packUpdate(NetConnection *con, U32 mask, BitStream *stream)
{
	U32 retMask = Parent::packUpdate(con, mask, stream);

   if (stream->writeFlag(mask & OptionsMask))
   {
      stream->write(mMissRadius);
      stream->write(mProjectileInheritVelocity);
      stream->write(mProjectileVelocity);
      stream->write(mProjectileGravityMod);
      stream->writeFlag(mProjectileBallistic);
      stream->writeFlag(mImageSeeks);
   }

   // no client controlling specific info...no need to write flag...

	return retMask;
}

void AITurret::unpackUpdate(NetConnection *con, BitStream *stream)
{
	Parent::unpackUpdate(con,stream);

   // options
   if (stream->readFlag())
   {
      stream->read(&mMissRadius);
      stream->read(&mProjectileInheritVelocity);
      stream->read(&mProjectileVelocity);
      stream->read(&mProjectileGravityMod);
      mProjectileBallistic = stream->readFlag();
      mImageSeeks = stream->readFlag();
   }

   // no client controlling specific info...no need to read flag...
}

//--------------------------------------------------------------------------
void AITurret::setTrigger(Trigger *trigger)
{
  mTrigger = trigger;
}

Trigger *AITurret::getTrigger()
{
   return mTrigger;
}

//--------------------------------------------------------------------------

// since turret also calls script for onAdd,onRemove, and onNewDataBlock
// doing it here means it is getting done twice...but it dont work unless
// we do...does this mean that in SCRIPT we should NOT be calling on the
// parent since we already do it in the C++ code?

bool AITurret::onAdd()
{
   // make sure turret dont call on script cause we are going to
	if(!Parent::onAdd(false) || !mDataBlock)
		return false;

	if (isServerObject())
	  scriptOnAdd();
	return true;
}

void AITurret::onRemove()
{
	scriptOnRemove();

   // we call script so make sure turret don't
	Parent::onRemove(false);
}

bool AITurret::onNewDataBlock(GameBaseData* dptr)
{
   // we call script so make sure turret class does not
   mDataBlock = dynamic_cast<AITurretData*>(dptr);
   if (!mDataBlock || !Parent::onNewDataBlock(dptr,false))
      return false;

   // we can initialize this turret's data from the datablock
   // (it can be changed later on as desired)
   // really this only needs doing on the server
   if (isServerObject())
      resetAITurretOptions();

   scriptOnNewDataBlock();
   return true;
}

void AITurret::resetAITurretOptions()
{
   // set from datablock data
   setAITurretOptions(mDataBlock->missRadius, mDataBlock->projectileInheritVelocity, mDataBlock->projectileVelocity,
      mDataBlock->projectileGravityMod, mDataBlock->projectileBallistic, mDataBlock->imageSeeks);
}

void AITurret::setAITurretOptions(F32 missRadius, F32 inheritVelocity, F32 velocity, F32 gravityMod, bool ballistic, bool imageSeeks)
{
   mMissRadius = missRadius;
   mProjectileInheritVelocity = inheritVelocity;
   mProjectileVelocity = velocity;
   mProjectileGravityMod = gravityMod;
   mProjectileBallistic = ballistic;
   mImageSeeks = imageSeeks;
   // we reuse same mask as turret does...this is ok it just
   // means that whenever either this or setTurretOptions() is
   // called all the data from both is sent...
   if (isServerObject())
      setMaskBits(OptionsMask);
}

void AITurret::onDeleteNotify(SimObject* obj)
{
   GameBase* pScene = dynamic_cast<GameBase*>(obj);
   if (pScene != NULL)
   {
      if (isTarget(pScene))
      {
         setTarget(NULL);
         throwCallback( "onTargetDeleted" );      
      }

      // is this one of the objects in the trigger zone?
      // send an object a leave trigger before it gets deleted
      for (U32 i = 0; i < mObjects.size(); i++) {
         if (pScene == mObjects[i]) {
            mObjects.erase(i);
            Con::executef(mDataBlock, "onLeaveTrigger", scriptThis(), Con::getIntArg(pScene->getId()));
            break;
         }
      }
   }

   Parent::onDeleteNotify(obj);
}

void AITurret::removeAllObjects()
{
   for (U32 i = 0; i < mObjects.size(); i++)
   {
      GameBase* remove = mObjects[i];
      mObjects.erase(i);
      clearNotify(remove);

      // this will call onTargetLost() for this object
      if (isTarget(remove))
         setTarget(NULL);

      Con::executef(mDataBlock, "onLeaveTrigger", scriptThis(), remove->scriptThis());
   }
}

// this is generally not needed because an object is usually
// deleted becase it is destroyed...however...if for some
// reason a turret is deleted this will cause all the objects
// curently in it's zone to receive a leave event.
void AITurret::preDelete()
{
   //Con::printf("AITurret DELETED...calling removeAllObjects");
   removeAllObjects();
}

// often an object is hidden instead of being deleted. Hidden objects
// will not be found in container searches, so once an object is hidden
// it will no longer cause enter events etc. However...if there were objets
// in it's zone at the time it is hidden then we want those objects
// to all get a leave event
void AITurret::setHidden(bool hidden)
{
   Parent::setHidden(hidden);

   if (mTrigger != NULL)
      mTrigger->setHidden(hidden);

   if (hidden)
   {
      if (mAimObject != NULL)
      {
         setAimObject(NULL);
      }

      if (mObjects.size() > 0)
      {
         //Con::printf("AITurret HIDDEN...calling removeAllObjects");
         removeAllObjects();
      }
   }
}


//--------------------------------------------------------------------------

bool AITurret::testObject(GameBase* enter)
{
   F32 triggerRadiusSquared = mDataBlock->triggerRadius*mDataBlock->triggerRadius;
 
   // if we are mounted to this object (or mounted to something mounted to this object)
   // then we dont ever consider it to be in the zone
   GameBase *mount = static_cast<GameBase*>(getObjectMount());
   if (mount != NULL)
   {
      if (enter == static_cast<GameBase*>(getObjectMount()) ||
          enter == static_cast<GameBase*>(getObjectMount()->getObjectMount()))
          return false;

      // beffy turret improvement ->
      // for muli-passenger vehicles, iterate over all the mount points to make sure
      // none of the mounted players is considered a target and gets shot...
      for(S32 mounts = 0; mounts < getObjectMount()->getMountedObjectCount(); mounts++)
      {
        GameBase *submount = static_cast<GameBase*>(getObjectMount()->getMountedObject(mounts));
        if(enter == submount)
          return false;
      }
      // <- beffy turret improvement
   }   


   // if this aiobject has been destroyed then
   // we are not inside its zone...this will prevent us from
   // entering the zone of a destroyed object but also
   // will cause an onLeaveTrigger() to be sent to each object
   // in the zone when it gets destoryed
   if (isDestroyed() || getDamageState() == Disabled)
      return false;

   // if this object has been destroyed then discount it
   if (enter->getTypeMask() & ShapeBaseObjectType)
   {
      ShapeBase *obj = static_cast<ShapeBase *>(enter);
      if (obj->isDestroyed() || obj->getDamageState() == Disabled)
         return false;
   }

   // we must be within think radius to trigger...
   // we must also be in line-of-sight and at some reachable angle
   Point3F delta = enter->getPosition() - getPosition();
   F32 squareDist = delta.x*delta.x + delta.y*delta.y + delta.z*delta.z;
   if (squareDist <= triggerRadiusSquared)
   {
      if (isInLOS(enter) && isReachableAngle(enter))
         return true;
   }

   return false;
}


void AITurret::potentialEnterObject(GameBase* enter)
{
   AssertFatal(isServerObject(), "Error, should never be called on the client!");

   for (U32 i = 0; i < mObjects.size(); i++) {
      if (mObjects[i] == enter)
         return;
   }

   if (testObject(enter) == true) {
      mObjects.push_back(enter);
      deleteNotify(enter);

      Con::executef(mDataBlock, "onEnterTrigger", scriptThis(), Con::getIntArg(enter->getId()));
   }
}

void AITurret::processTick(const Move* move)
{
   Parent::processTick(move);

   if (isClientObject())
      return;

   // slave the trigger position to be the same as ours
   if (mTrigger != NULL)
   {
      Point3F sizeVec(mDataBlock->triggerRadius,mDataBlock->triggerRadius,mDataBlock->triggerRadius);
      mTrigger->setPosition(getPosition()-sizeVec);
   }

   // periodic thinking...
   if (mDataBlock->thinkPeriodMS > 0)
   {
      if (mLastThinkingThink + mDataBlock->thinkPeriodMS < mCurrThinkingTick)
      {
         mCurrThinkingTick  = 0;
         mLastThinkingThink = 0;

         Con::executef(mDataBlock, "onThink", scriptThis());
      }
      else
      {
         mCurrThinkingTick += TickMs;
      }
   }

   // trigger thinking....
   if (mObjects.size() == 0 || mDataBlock->triggerPeriodMS <= 0)
      return;

   if (mLastTriggerThink + mDataBlock->triggerPeriodMS < mCurrTriggerTick) {
      mCurrTriggerTick  = 0;
      mLastTriggerThink = 0;

      for (S32 i = S32(mObjects.size() - 1); i >= 0; i--) {
         if (testObject(mObjects[i]) == false) {
            GameBase* remove = mObjects[i];
            mObjects.erase(i);
            clearNotify(remove);
            if (isTarget(remove))
               setTarget(NULL);
            Con::executef(mDataBlock, "onLeaveTrigger", scriptThis(), remove->scriptThis());
         }
      }

      if (mObjects.size() != 0)
         Con::executef(mDataBlock, "onTickTrigger", scriptThis());
   } else {
      mCurrTriggerTick += TickMs;
   }
}

// utility method to create a random vector of a given length
static Point3F randVec(F32 length)
{
   Point3F p(1.0-Platform::getRandom()*2.0,1.0-Platform::getRandom()*2.0,1.0-Platform::getRandom()*2.0);
   F32 len = Platform::getRandom()*length;
   p *= len;
   return p;
}

/**
 * This method returns true if the given object is in LOS.
 *
 * @param obj the object to test
 */
bool AITurret::isInLOS(GameBase *obj)
{
   // NOTE: this code assumes a weapon is mounted in slot 0!!!!

   // Test for object in sight. The LOS is run from the muzzle point
   // to the center of the target bounding box.
   Point3F location;
   getMuzzlePoint(0,&location);
   Point3F targetLoc = obj->getBoxCenter();

   // This ray ignores non-static shapes. Cast Ray returns true
   // if it hit something.
   RayInfo dummy;
   if (getContainer()->castRay( location, targetLoc,
         InteriorObjectType | StaticShapeObjectType | StaticObjectType |
         TerrainObjectType, &dummy))
   {
      return false;
   }

   return true;
}

/**
 * This method calculates the pitch and yaw values that would
 * cause the turret to point at the given location. This method
 * will take into account the turrets current orientation and does
 * not assume that the turrets local Z axis points up.
 *
 * @param loc the world location we want to "point" to
 * @param newYaw receives the calculated yaw
 * @param newPitch receives the calculated pitch
 */
void AITurret::getAnglesFromAimLocation(VectorF &loc, VectorF &velocity, F32 &newYaw, F32 &newPitch)
{
   // NOTE: this code assumes a weapon is mounted in slot 0!!!!

   // get muzzle point location and target location in 
   // the turret's local space
   MatrixF invTrans = getWorldTransform();
   Point3F location;
   getMuzzlePoint(0,&location);
   invTrans.mulP(location);

   // transform target location to local space of turret
   Point3F aimLocation;
   invTrans.mulP(loc,&aimLocation);

  	// dir to target
	Point3F targetDir = aimLocation - location;

	// guess ahead only if we're not a seeker
	F32 ballisticPitch;
	bool useBallisticPitch = false;
	if(!mImageSeeks && mProjectileVelocity != -1)
	{
	  F32 distance = targetDir.len();	  

     // determine actual projectile velocity
     F32 projectileSpeed = mProjectileVelocity;
     if (mProjectileInheritVelocity > 0.0)
     {
        // get try muzzle vec
        Point3F turretVelocity = this->getVelocity();
        Point3F muzzleVelocity(0.0,mProjectileVelocity,0.0);
        muzzleVelocity += turretVelocity * mProjectileInheritVelocity;
        projectileSpeed = muzzleVelocity.len();
     }

	  // time it takes projectile to travel the distance	  
	  F32 time = (1.0/projectileSpeed) * distance;	  
	  VectorF targetVelocity = velocity * time;  // gives us distance	  
	  aimLocation += targetVelocity;	  
	  targetDir = aimLocation - location; // new target dir
	  if(mProjectileBallistic)
	  {
        // this only works if turret is upright...
        // this code should be re-worked to look in direction of "down"
        // in relative space...compute the angular diff needed in that "down"
        // direction and produce a new aimLocation and then a new targetDir
        // and then fallthrough and let it use the new targetDir
		  F32 zDiff = aimLocation.z - location.z;

		  F32 x = distance;
		  F32 y = zDiff;
		  F32 g = -9.81*mProjectileGravityMod; 
		  F32 V = mProjectileVelocity;

		  ballisticPitch = -atan(V*V * ((-x + mSqrt(x*x - (g*g)*(x*x*x*x)/(V*V*V*V) + 2*g*x*x*y/(V*V)))/(g*x*x)));

		  useBallisticPitch = true;
	  }
	}

   // calc output values
   F32 yawAng,pitchAng;
   MathUtils::getAnglesFromVector(targetDir,yawAng,pitchAng);
   newYaw = yawAng;

   // remember this part DOES assume local Z axis is aligned with world Z axis (up is up)
	if(useBallisticPitch)
		newPitch = ballisticPitch;
   else
      newPitch = -pitchAng;
}

/**
 * This method returns true if the given object is at an angle
 * that is reachable by this turret (given its rotational constraints)
 *
 * @param obj the object to test
 */
bool AITurret::isReachableAngle(GameBase *obj)
{
   F32 pitch,yaw;
   Point3F targetLoc = obj->getBoxCenter();
   getAnglesFromAimLocation(targetLoc,obj->getVelocity(),yaw,pitch);

   // if yaw is 0...2PI adjust it
   if (yaw > M_PI)
      yaw -= M_2PI;

   // if both are inside range we are good
   if (pitch >= mMinPitch && pitch <= mMaxPitch &&
       yaw >= mMinYaw && yaw <= mMaxYaw)
   {
      return true;
   }

   // otherwise not!
   return false;
}

/**
 * This method calculates the moves for the AI turret
 *
 * @param movePtr Pointer to move the move list into
 */
bool AITurret::getAIMove(Move *movePtr)
{
   *movePtr = NullMove;

   // Orient towards the aim point, aim object, or towards
   // our destination.
   // NOTE: you must change the protection these data members
   // of AITurret from private to protected to get this
   // to compile...
   if (mAimObject || mAimLocationSet)
   {
      // Update the aim position if we're aiming for an object
      Point3F targetVelocity(0, 0, 0);
	   if(mAimObject)
	   {
        mAimLocation = mAimObject->getBoxCenter();
		  targetVelocity = mAimObject->getVelocity();
	   }

      // amount to miss by
      if (mMissRadius > 0.0)
         mAimLocation += randVec(mMissRadius);

      // our own rotation values are always in local space
      F32 curYaw = mRot.z;
      F32 curPitch = mRot.x;

      // get new local space pitch and yaw that point at target
      F32 newYaw, newPitch;
      getAnglesFromAimLocation(mAimLocation,targetVelocity,newYaw,newPitch);
         
      // create a move that is the difference
      movePtr->yaw = newYaw - curYaw;
      movePtr->pitch = newPitch - curPitch;

      // now limit appropriately
      limitMoveAngles(movePtr);
   }
   else
   {
      // if we are not generating moves then see if
      // the base class would like to do so. It generates
      // moves when deactivated to return turret to 0 pitch/yaw
      // and also when someone has manually set "next moves"
      Parent::getAIMove(movePtr);
   }

   // Test for target location in sight if it's an object. 
   if (mAimObject)
   {
      if (isInLOS(mAimObject))
      {
         if (!mTargetInLOS) {
            throwCallback( "onTargetEnterLOS" );
            mTargetInLOS = true;
         }
      }
      else
      {
         if (mTargetInLOS) {
            throwCallback( "onTargetExitLOS" );
            mTargetInLOS = false;
         }
      }
   }

   // Replicate the trigger state into the move so that
   // triggers can be controlled from scripts.
   for( int i = 0; i < MaxTriggerKeys; i++ )
      movePtr->trigger[i] = getImageTriggerState(i);

   // we generate null moves all the time
   // need to test returning false if no move generated
   // and/or if Parent::getAIMove() returns false
   return true;
}

/**
 * Sets the object the turret is targeting
 *
 * @param targetObject The object to target
 */
void AITurret::setAimObject( GameBase *targetObject )
{   
   if (mAimObject == targetObject)
      return;

   if (mAimObject != NULL)
   {
      clearNotify(mAimObject);
      if (targetObject == NULL)
         Con::executef(mDataBlock, "onTargetLost", scriptThis(), mAimObject->scriptThis());
      else
         Con::executef(mDataBlock, "onTargetChanged", scriptThis(), mAimObject->scriptThis(), targetObject->scriptThis());
   }
   else
   {
      Con::executef(mDataBlock, "onTargetAquired", scriptThis(), targetObject->scriptThis());
   }

   mAimObject = targetObject;
   if (mAimObject != NULL)
      deleteNotify(mAimObject);

   mTargetInLOS = false;
}

/**
 * Sets the location for the turret to aim at
 * 
 * @param location Point to aim at
 */
void AITurret::setAimLocation( const Point3F &location )
{
   setAimObject(NULL);
   mAimLocationSet = true;
   mAimLocation = location;
}

/**
 * Clears the aim location and object
 */
void AITurret::clearAim() 
{
   setAimObject(NULL);
   mAimLocationSet = false;
}

/**
 * Fires a ShapeBaseImage mounted on turret
 */
void AITurret::fire( U32 imageSlot )
{
   // fire it
   setImageTriggerState(imageSlot,true);
   setImageTriggerState(imageSlot,false);
}

/**
 * Pick a target from among objects in zone.
 */
bool AITurret::pickTarget()
{
   Point3F pos = this->getBoxCenter();

   // we pick closest target that is
   // in LOS and is at reachable angle
   GameBase *chosen = NULL;
   F32 dist = 1000000.0;
   for (U32 i = 0; i < mObjects.size(); i++)
   {
      GameBase* obj = mObjects[i];
      Point3F delta = pos - obj->getBoxCenter();
      F32 thisDist = delta.len();
      if (thisDist < dist && isInLOS(obj) && isReachableAngle(obj))
      {
         chosen = obj;
         dist = thisDist;
      }
   }

   setTarget(chosen);

   return chosen != NULL;
}


/**
 * Utility function to throw callbacks. Callbacks always occure
 * on the datablock class.
 *
 * @param name Name of script function to call
 */
void AITurret::throwCallback( const char *name )
{
   Con::executef(getDataBlock(), name, scriptThis());
}

// --------------------------------------------------------------------------------------------
// Console Functions
// --------------------------------------------------------------------------------------------

/**
 * Tells the AI to fire a given ShapeBaseImage
 */
ConsoleMethod( AITurret, fire, void, 3, 3, "ai.fire( %slot );" )
{
   AITurret *ai = static_cast<AITurret *>( object );
   ai->fire( dAtoi(argv[2]) );
}

/**
 * Tells the AI to aim at the location provided
 */
ConsoleMethod( AITurret, setAimLocation, void, 3, 3, "ai.setAimLocation( \"x y z\" );" )
{
   AITurret *ai = static_cast<AITurret *>( object );
   Point3F v( 0.0f,0.0f,0.0f );
   dSscanf( argv[2], "%f %f %f", &v.x, &v.y, &v.z );

   ai->setAimLocation( v );
}

/**
 * Returns the point the AI is aiming at
 */
ConsoleMethod( AITurret, getAimLocation, const char *, 2, 2, "ai.getAimLocation();" )
{
   AITurret *ai = static_cast<AITurret *>( object );
   Point3F aimPoint = ai->getAimLocation();

   char *returnBuffer = Con::getReturnBuffer( 256 );
   dSprintf( returnBuffer, 256, "%f %f %f", aimPoint.x, aimPoint.y, aimPoint.z );

   return returnBuffer;
}

/**
 * Sets the turrets target object
 */
ConsoleMethod( AITurret, setAimObject, void, 3, 3, "ai.setAimObject( obj );" )
{
   AITurret *ai = static_cast<AITurret *>( object );
   
   // Find the target
   GameBase *targetObject;
   if( Sim::findObject( argv[2], targetObject ) )
      ai->setAimObject( targetObject );
   else
      ai->setAimObject( 0 );
}

/**
 * Gets the object the AI is targeting
 */
ConsoleMethod( AITurret, getAimObject, S32, 2, 2, "ai.getAimObject();" )
{
   AITurret *ai = static_cast<AITurret *>( object );
   GameBase* obj = ai->getAimObject();
   return obj? obj->getId(): -1;
}

/**
 * Stop the turret aiming
 */
ConsoleMethod( AITurret, clearAim, void, 2, 2, "ai.clearAim();" )
{
   AITurret *ai = static_cast<AITurret *>( object );
   ai->clearAim();
}

/**
 * get number of objects in trigger zone
 */
ConsoleMethod( AITurret, getNumObjects, S32, 2, 2, "ai.getNumObjects();" )
{
   AITurret *ai = static_cast<AITurret *>( object );
   return ai->getNumTriggeringObjects();
}

/**
 * get an object in trigger zone by index
 */
ConsoleMethod( AITurret, getObject, S32, 3, 3, "ai.getObject(%index);" )
{
   AITurret *ai = static_cast<AITurret *>( object );
   S32 index = dAtoi(argv[2]);

   if (index >= ai->getNumTriggeringObjects() || index < 0)
      return -1;
   else
      return ai->getObject(U32(index))->getId();
}


/**
 * Set target explicitly
 */
ConsoleMethod( AITurret, setTarget, void, 3, 3, "ai.setTarget(%target);" )
{
   AITurret *ai = static_cast<AITurret *>( object );

   // Find the target
   GameBase *targetObject;
   if( Sim::findObject( argv[2], targetObject ) )
      ai->setTarget( targetObject );
   else
      ai->setTarget( NULL );
}

/**
 * Get target explicitly
 */
ConsoleMethod( AITurret, getTarget, S32, 2, 2, "ai.getTarget();" )
{
   AITurret *ai = static_cast<AITurret *>( object );
   GameBase* obj = ai->getTarget();
   return obj? obj->getId(): -1;
}

/**
 * is this object the target?
 */
ConsoleMethod( AITurret, isTarget, bool, 3,3, "ai.isTarget(%target);" )
{
   AITurret *ai = static_cast<AITurret *>( object );

   // Find the target
   GameBase *targetObject;
   if( Sim::findObject( argv[2], targetObject ) )
      return ai->isTarget( targetObject );
   return false;
}

/**
 * Do we have a target?
 */
ConsoleMethod( AITurret, hasTarget, bool, 2,2, "ai.hasTarget();" )
{
   AITurret *ai = static_cast<AITurret *>( object );
   return ai->hasTarget();
}


/**
 * clear any targets
 */
ConsoleMethod( AITurret, clearTarget, void, 2,2, "ai.clearTarget();" )
{
   AITurret *ai = static_cast<AITurret *>( object );
   ai->clearTarget();
}


/**
 * Pick a target from object in our trigger zone
 */
ConsoleMethod( AITurret, pickTarget, bool, 2,2, "ai.pickTarget();" )
{
   AITurret *ai = static_cast<AITurret *>( object );
   return ai->pickTarget();
}

/**
 * reset turret options to default values from datablock
 */
ConsoleMethod( AITurret, resetAITurretOptions, void, 2, 2, "turret.resetAITurretOptions();" )
{
   AITurret *turret = static_cast<AITurret *>( object );
   turret->resetAITurretOptions();
}


/**
 * set turret options to specific values
 */
ConsoleMethod( AITurret, setAITurretOptions, void, 8, 8, 
   "turret.setAITurretOptions(missRadius, projectileInheritVelocity, projectileVelocity, projectileGravityMod, projectileBallistic, imageSeeks);" )
{
   AITurret *turret = static_cast<AITurret *>( object );
   if (argc >= 9)
   {
      turret->setAITurretOptions(dAtof(argv[2]),dAtof(argv[3]),dAtof(argv[4]),
         dAtof(argv[5]),dAtob(argv[6]),dAtob(argv[7]));
   }
}

/**
 * set trigger to be used for this ai object
 */
ConsoleMethod( AITurret, setTrigger, void, 3, 3, "turret.setTrigger(trigger);" )
{
   AITurret *turret = static_cast<AITurret *>( object );
   if (argc > 2)
   {
      Trigger *trigger;
      if (Sim::findObject(argv[2],trigger))
         turret->setTrigger(trigger);
   }
}
ConsoleMethod( AITurret, getTrigger, S32, 2, 2, "turret.getTrigger();" )
{
   AITurret *turret = static_cast<AITurret *>( object );
   Trigger *trigger = turret->getTrigger();
   return trigger->getId();
} 
