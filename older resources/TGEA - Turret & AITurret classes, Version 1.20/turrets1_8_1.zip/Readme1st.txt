Turrets for TGEA 1.8.1 - Joseph Reilly

Credits - To those that did all the heavy lifting:
    Paul Dana - Turret & AITurret classes - http://www.garagegames.com/community/resources/view/4116
    Brian Howard - Turret & AITurret classes, Version 1.20 - http://www.garagegames.com/community/resource/view/5345 
    Andy Hawkins - TGEA 1.8.1 port - http://www.garagegames.com/community/resources/view/5345/6#comment-113453 

    This was tested with the TGEA Stronghold game example.

Contents
    Readme1st.txt = Credits, simple instructions
    Readme.txt = Original Readme.txt
    copyturrets.bat = Copies new and modified files over the standard TGEA 1.8.1 installation.
        If you uncomment the lines in copyturrets.bat and run it from the same folder it will copy the files to the default TGEA 1.8.1. 
        This will overlay any changes you may have made so use with caution. 
    source and data files

Instructions
    **** MOST IMPORTANT **** -> Make a backup of your existing TGEA 1.8.1 installation!!!
    Merge changes from the zip file into your TGEA 1.8.1 installation. 
    Add a new filter/folder called turrets to your project under T3D.
    Add the two .cpp files(turret.cpp and aiTurret.cpp) as existing items to the filter/folder you just added.
    Rebuild the engine.
    Read the original Readme.txt for instructions on adding turrets to a mission. 

Gotchas
    If you add a turret to a mission, use the mission editor to set the value of the dynamic field "locked" to either true or false.
    Otherwise the engine will crash if you execute a dump() method on the turret object in the console. 
