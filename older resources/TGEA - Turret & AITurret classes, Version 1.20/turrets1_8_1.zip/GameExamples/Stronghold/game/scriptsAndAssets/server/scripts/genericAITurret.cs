// phdana turrets ->

// This turret demonstrates how you can use the default AITurretData scripts
// as is and get all your behaviour from the datablock. To see an example of
// overriding the default scripts see AnotherAITurret.cs

datablock AITurretData(GenericAITurret)
{
	category						= "Turrets";
	shapeFile						= "~/data/shapes/turrets/smallTurret.dts";
    maxDamage                       = 110;
    explosion                       = CrossbowExplosion;
    destroyedLevel                  = 110;
    debrisShapeName                 = "~/data/shapes/turrets/smallTurret.dts";
    debris                          = TurretDebris;
    renderWhenDestroyed             = false;
	numMountPoints					= 1;
	isProtectedMountPoint[0]		= true;
	maxEnergy						= 280;
 
    barrel                          = SmallTurretGun;
    barrelMountPoint                = 0;
    
	cameraMaxDist					= 10;
	cameraOffset					= 2.5;

    // AI stuff
    thinkPeriodMS                   = 0;   // no periodic thinking (the default anyway)
    triggerPeriodMS                 = 96; // trigger thinking is aprox 1/10 sec (the default anyway)
    triggerRadius                   = 200; // target objects this close

    maxYawSpeed                     = 720; // degrees/sec....720 can track fast moving things
    maxPitchSpeed                   = 720; // degrees/sec....720 can track fast moving things

    projectileInheritVelocity       = 1;
    //projectileVelocity              = 100;  // fill this stuff in to describe the projectile you firing
    projectileVelocity              = 300;  // for testing very fast
    projectileGravityMod            = 0;
    projectileBallistic             = false;
    imageSeeks                      = false;

    // turret specific stuff
    //minYaw = -90.0;
    //maxYaw = 90;

    // in script only
    firstFireDelay                  = 2.0; // fire this soon after aquiring target...
    firstFireDelayVariance          = 0.3; // .. plus or minus this amount
    fireRate                        = 4.0; // fire every N seconds after that...
    fireRateVariance                = 1.0; // ...plus or minus this amount
};
// <- phdana turrets
