// phdana turrets ->
function TurretData::create(%data)
{
	// The mission editor invokes this method when it wants to create
	// an object of the given datablock type.  For the mission editor
	%obj = new Turret() {
		dataBlock = %data;
	};
	%obj.mountable = true;

	return %obj;
}

function TurretData::onTrigger(%this, %obj, %triggerNum, %val)
{
  //echo("TurretData::onTriggerr");
}

function TurretData::onAdd(%this,%obj)
{
    //Parent::onAdd(%this,%obj);
    echo("TurretData::onAdd()");
	%obj.setEnergyLevel(%this.MaxEnergy);
    // mount the barrel if one is specified
    if (%this.barrel !$= "")
    {
        echo("TurretData::onAdd() - Mounted Default Barrel on Turret");
	    %obj.mountImage(%this.barrel,%this.barrelSlot);
    }
}

function TurretData::onRemove(%this,%obj)
{
   //Parent::onRemove(%this,%obj);
   echo("TurretData::onRemove");
}

function TurretData::onNewDatablock(%this,%obj)
{
   //Parent::onNewDatablock(%this,%obj);
   echo("TurretData::onNewDataBlock");
}

function TurretData::onDamage(%this,%obj,%amount)
{
   //called when damage level is changed
   //echo("TurretData::onDamage()");
   %damage = %obj.getDamageLevel();
   //

   %healthLeft = %this.maxDamage - %damage;
   //echo("TurretData::onDamage() - The Turret's health is " @ %healthLeft);
  //if (%damage >= %this.destroyedLevel)
  //GUI should show maxDamage - damageLevel
    if(%damage >= %this.maxDamage)
   {
      if(%obj.getDamageState() !$= "Destroyed")
      {
         if(%obj.respawnTime !$= "")
            %obj.marker.schedule = %obj.marker.data.schedule(%obj.respawnTime, "respawn", %obj.marker);
         %obj.setDamageState(Destroyed);
      }
   }
   else
   {
      if(%obj.getDamageState() !$= "Enabled")
         %obj.setDamageState(Enabled);
   }
}


function TurretData::onDestroyed(%data, %obj, %prevState)
{
    if(%obj.lastDamagedBy)
    {
        %destroyer = %obj.lastDamagedBy;
        //game.vehicleDestroyed(%obj, %destroyer);
		messageAll('TurretDestruction', '%1 Destroyed a %2 with a %3', %destroyer, %data.className, %obj.lastDamageType);
        //error("turretDestroyed( "@ %obj @", "@ %destroyer @")");
    }

   // dont delete...
   //%data.deleteAllMounted(%obj);
   //%obj.schedule(2000, "delete");
   //MissionCleanup.add(%obj);

   // instead of delete we hide the object. NOTE that we dont need
   // to do this for visual reasons because renderWhenDestroyed is false
   // and so the model itself instantly dissappears when its destroyed.
   // However...we dont want anything to COLLIDE with this object either
   // so we must actually hide it as well
   // schedule it to be hidden in 1.5 secs
   %obj.schedule(1500, "hide",true);
}

function TurretData::damage(%this,%obj,%sourceObj,%vel,%damage, %damageType)
{
  //echo("TurretData::damage");

  %obj.applyDamage(%damage);
  if(%obj.getDamageState() $= "Destroyed" )
   {
      %client = %sourceObj.client;
      if (%client)
        %client.incScore(%this.numPoints);
   }

   Parent::damage(%this, %obj);
}

function TurretData::playerMounted(%data, %obj, %player, %node)
{
   echo("TurretData::playerMounted()");
}

function TurretData::playerDismounted(%data, %obj, %player, %node)
{
   echo("TurretData::playerDismounted()");

   %player.unmount();

   // we are dismounting so deactivate
   %obj.setActive(false);
}

// <- phdana turrets

