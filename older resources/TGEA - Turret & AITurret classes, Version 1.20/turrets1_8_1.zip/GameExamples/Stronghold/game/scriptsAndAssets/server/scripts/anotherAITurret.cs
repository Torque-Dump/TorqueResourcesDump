// phdana turrets ->

//
// This turret is just like GenericAITurret except it shows that you
// can define your own behaviour by defining the standard methods in
// your own namesapce and overriding and/or calling parent class as
// you desire.
//
// In this example we do not specify a "barrel" in the datablock
// so no weapon will be mounted by default. Instead we override the
// onAdd() method and mount a weapon manually
//

datablock AITurretData(AnotherAITurret)
{
	category						= "Turrets";
	shapeFile						= "~/data/shapes/turrets/smallTurret.dts";
    maxDamage                       = 110;
    explosion                       = CrossbowExplosion;
    destroyedLevel                  = 110;
    debrisShapeName                 = "~/data/shapes/turrets/smallTurret.dts";
    debris                          = TurretDebris;
    renderWhenDestroyed             = false;
	numMountPoints					= 1;
	isProtectedMountPoint[0]		= true;
	maxEnergy						= 280;
 
    // these are purposely commented out here to demonstrate
    // overriding standard methods in our own namespace...we define
    // our own onAdd() below...
    //barrel                          = SmallTurretGun;
    //barrelMountPoint                = 0;
    
	cameraMaxDist					= 10;
	cameraOffset					= 2.5;

    // AI stuff
    thinkPeriodMS                   = 0;   // no periodic thinking (the default anyway)
    triggerPeriodMS                 = 96; // trigger thinking is aprox 1/10 sec (the default anyway)
    triggerRadius                   = 200; // target objects this close

    maxYawSpeed                     = 720; // degrees/sec....720 can track fast moving things
    maxPitchSpeed                   = 720; // degrees/sec....720 can track fast moving things

    //projectileVelocity              = 100;  // fill this stuff in to describe the projectile you firing
    projectileVelocity              = 300;  // for testing very fast
    projectileGravityMod            = 0;
    projectileBallistic             = false;
    imageSeeks                      = false;

    // in script only
    firstFireDelay                  = 2.0; // fire this soon after aquiring target...
    firstFireDelayVariance          = 0.3; // .. plus or minus this amount
    fireRate                        = 4.0; // fire every N seconds after that...
    fireRateVariance                = 1.0; // ...plus or minus this amount
};

function AnotherAITurret::onAdd(%this,%obj)
{
    echo("AnotherAITurret::onAdd()");

    // we dont have a barrel specified in this
    // turret so this method will not mount a weapon
    // in fact we can even decide not to call it
    // Parent::onAdd(%this,%obj);
    
    // but we can mount it ourself here...
	%obj.setEnergyLevel(%this.MaxEnergy);
    %obj.mountImage(SmallTurretGun,0);
}

// redefining the above onAdd() method is all
// we need to demonstrate overriding script functions...
// ...but as a further example we override all the standard
// script methods below and echo each one as we do so
// this demonstrates calling on the parent to get default behaviour
function AnotherAITurret::onTargetDeleted(%this,%obj)
{
   // the aim object just got deleted
   echo("AnotherAITurret::onTargetDeleted()");
   Parent::onTargetDeleted(%this,%obj);
}

function AnotherAITurret::onThink(%this,%obj)
{
   echo("AnotherAITurret::onThink()");
   Parent::onThink(%this,%obj);
}

function AnotherAITurret::onEnterTrigger(%this,%turret,%obj)
{
   echo("AnotherAITurret::onEnterTrigger()");
   Parent::onEnterTrigger(%this,%turret,%obj);
}

function AnotherAITurret::onTickTrigger(%this,%turret)
{
   echo("AnotherAITurret::onTickTrigger()");
   Parent::onTickTrigger(%this,%turret);
}

function AnotherAITurret::onLeaveTrigger(%this,%turret,%obj)
{
   echo("AnotherAITurret::onLeaveTrigger()");
   Parent::onLeaveTrigger(%this,%turret,%obj);
}

function AnotherAITurret::onTargetAquired(%this,%turret, %target)
{
   echo("AnotherAITurret::onTargetAquired()");
   Parent::onTargetAquired(%this,%turret,%target);
}

function AnotherAITurret::onTargetChanged(%this,%turret, %oldTarget, %newTarget)
{
   echo("AnotherAITurret::onTargetChanged()");
   Parent::onTargetChanged(%this,%turret,%oldTarget,%newTarget);
}

function AnotherAITurret::onTargetLost(%this,%turret, %target)
{
   echo("AnotherAITurret::onTargetLost()");
   Parent::onTargetLost(%this,%turret,%target);
}
// <- phdana turrets
