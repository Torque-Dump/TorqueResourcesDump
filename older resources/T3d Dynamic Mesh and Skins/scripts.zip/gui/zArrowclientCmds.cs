//===========================================================//
// <HONG> 03/20/2010
// client side commands.
// It is the place where all the server commands arrive for
// my game.
//=============================================================================//

//-------------------------------------------------------------------------//
//**LOG In functions
//--------------------------------------------------------------------------//
function clientCmdRequestPW(%nonce)
{
   zArrowLoginDlg.checkAuth(%nonce);
}

function clientCmdOnLoginSuccess(%playerData)
{
   Canvas.popDialog(zArrowLoginDlg);

   //If this player hasn't set up appearance, open up the customization gui
   %openCustomGui  = getWord(%playerData,0);
   if(%openCustomGui $="0")
      Canvas.setContent(zArrowCustomizationGui);
   else
      Canvas.setContent(zArrowCustomizationResultGui); 
   
   //Update the Gui data.
   updateCustomGuiData( %playerData );  
}

function clientCmdLoginFailed(%message)
{
   MessageBoxOK("Login Failure", %message, "showLoginDlg();");
}

//--------------------------------------------------------------------------//
//** Inventory
//---------------------------------------------------------------------------//
function clientCmdPopulateInventory(%slot1, %slot2, %slot3, %slot4, %slot5, %slot6)
{
   //The parameters passed from the game server are object names.
   setInventorySlots(%slot1, %slot2, %slot3, %slot4, %slot5, %slot6);
}

function clientCmdUpdateInventory(%slotName, %itemNo, %turnOff)
{
   updateSelectedSlot(%slotName, %itemNo, %turnOff);
}

//-----------------------------------------------------------------------------//
//** Achievements
//-----------------------------------------------------------------------------//
function clientCmdPopulatedAchiev(%no,%id,%hp,%kc,%kp,%dc,%dp,%jf)
{
   populateAchievementGui(%no,%id,%hp,%kc,%kp,%dc,%dp,%jf);
}

//----------------------------------------------------------------------------//
//** Nickname error
//-----------------------------------------------------------------------------//
function clientCmdCusomizatioResult(%success, %message)
{
   if(%success)
   {
      showCustomizationResult(%message);
   }
   else
   {
      MessageBoxOK("Registraion Failure", %message, "showCustomGui();");
   }
}

//----------------------------------------------------------------------------//
//** Customization 
//-----------------------------------------------------------------------------//
function clientCmdInitHeadMaterialGuiValues(%currentMeshIdx,%meshCount, %countBaseTex)
{
   headShape_f.setMaxIndex(%meshCount);
   headShape_f.setCurrentIndex(%currentMeshIdx);
   updateHeadShapeButtons();
   
   headBaseSkin_f.setMaxIndex(%countBaseTex);
   headBaseSkin_f.setCurrentIndex(0);
   updateHeadBaseButtons();
}

function clientCmdInitFaceMaterialGuiValues(%meshCount, %countBaseTex,%countMark1,%countMark2,%countMark3)
{
   faceShape_f.setMaxIndex(%meshCount);
   faceShape_f.setCurrentIndex(0);
   updateFaceShapeButtons();
   

   faceBaseSkin_f.setMaxIndex(%countBaseTex);
   faceSkin_f0.setMaxIndex(%countMark1);
   faceSkin_f1.setMaxIndex(%countMark2);
   faceSkin_f2.setMaxIndex( %countMark3);
   
   faceBaseSkin_f.setCurrentIndex(0);
   faceSkin_f0.setCurrentIndex(0);
   faceSkin_f1.setCurrentIndex(0);
   faceSkin_f2.setCurrentIndex(0);
   
   updateFaceBaseButtons();
   updateFaceMarkButtons1();
   updateFaceMarkButtons2();
   updateFaceMarkButtons3();
}

function clientCmdInitTorsoMaterialGuiValues(%currentMeshIdx, %meshCount, 
                                          %countBaseTex,%countMark1,%countMark2)
{
   torsoShape_f.setMaxIndex(%meshCount);
   torsoShape_f.setCurrentIndex(%currentMeshIdx);
   updateTorsoShapeButtons();
   
   torsoBaseSkin_f.setMaxIndex(%countBaseTex);
   torsoSkin_f0.setMaxIndex(%countMark1);
   torsoSkin_f1.setMaxIndex(%countMark2);
   
   torsoBaseSkin_f.setCurrentIndex(0);
   torsoSkin_f0.setCurrentIndex(0);
   torsoSkin_f1.setCurrentIndex(0);
   
   updateTorsoBaseButtons();
   updateTorsoMarkButtons1();
   updateTorsoMarkButtons2();
}

function clientCmdInitLegMaterialGuiValues(%currentMeshIdx,%meshCount, %countBaseTex)
{
   LegShape_f.setMaxIndex(%meshCount);
   LegShape_f.setCurrentIndex(%currentMeshIdx);
   updateLegShapeButtons();
   
   LegBaseSkin_f.setMaxIndex(%countBaseTex);
   legSkin_f0.setCurrentIndex(0);
   updateLegBaseButtons();
}