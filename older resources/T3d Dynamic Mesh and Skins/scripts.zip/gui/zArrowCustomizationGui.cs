//===========================================================//
// <HONG> 03/07/2010
// zArrowCustomizationGui.cs
//============================================================//

//------------------------------------------//
//**indices
//------------------------------------------//

//HEAD
//$HeadMeshIdx   = -1;
//$HeadSkinIdx0  = 0;    //base texture
//$HeadSkinIdx1  = 0;    //Mark 1
//
////FACE
//$FaceMeshIdx   = -1;
//$FaceSkinIdx0  = 0;   
//$FaceSkinIdx1  = 0;
//$FaceSkinIdx2  = 0; 
//$FaceSkinIdx3  = 0; 
//
////TORSO
//$TorsoMeshIdx  = -1;
//$TorsoSkinIdx0 = 0;     
//$TorsoSkinIdx1 = 0;
//$TorsoSkinIdx2 = 0; 
//
////LEG
//$LegMeshIdx    = -1;
//$LegSkinIdx0   = 0;
//$LegSkinIdx1   = 0;


function zArrowCustomizationGui::onWake(%this)
{
   $enableDirectInput = "1";
   activateDirectInput();
   MoveMap.pop();
   
   commandToServer('dropCameraAtPlayer');
   rotateCamera(0);       //Reset Camera
   
   %this.updateCustomButtons();
}

//Activate/deactivate buttons according to their current indices.
function zArrowCustomizationGui::updateCustomButtons(%this)
{
   //mesh related buttons
   %this.updateMeshButtons();
   
   //base material buttons
   %this.updateBaseMetrialButtons();
   
   //Mark1
   %this.updateMark1Buttons();
   
   //Mark2
   %this.updateMark2Buttons();
   
   //Mark3
   %this.updateMark3Buttons();
}

function zArrowCustomizationGui::updateMeshButtons(%this)
{
   updateHeadShapeButtons();
   updateFaceShapeButtons();
   updateTorsoShapeButtons();
   updateLegShapeButtons();
}
function zArrowCustomizationGui::updateBaseMetrialButtons(%this)
{
   updateHeadBaseButtons();
   updateFaceBaseButtons();
   updateTorsoBaseButtons();
   updateLegBaseButtons();
}
function zArrowCustomizationGui::updateMark1Buttons(%this)
{
   updateHeadMarkButtons1();
   updateFaceMarkButtons1();
   updateTorsoMarkButtons1();
   updateLegMarkButtons1();
}
function zArrowCustomizationGui::updateMark2Buttons(%this)
{
   updateFaceMarkButtons2();
   updateTorsoMarkButtons2();
}
function zArrowCustomizationGui::updateMark3Buttons(%this)
{
   updateFaceMarkButtons3();
}

//-------------------------------------------------------------//
//** Camera Rotation **
//-------------------------------------------------------------//
function rotateCamera(%dir)     
{
   //Defines some local variables here instead of global.
   %moveDirection  = %dir;
   %camMoveStep    = 5;        //In Degree
   %camDistanceFromTarget = 2;  
   
   commandToServer('RotateCamera', %moveDirection, %camMoveStep, %camDistanceFromTarget);  
}

//-------------------------------------------------------------//
//** zoom **
//-------------------------------------------------------------//
function zoom(%zoomIn)
{
   commandToServer('Zoom',%zoomIn);
}


//------------------------------------------------------------//
//** go back to lobby
//** Someone will not need this function.
//------------------------------------------------------------//
function goBackToStartMenu()
{
   // Delete the connection if it's still there.
   if (isObject(ServerConnection))
      ServerConnection.delete();
   disconnectedCleanup();

   // Call destroyServer in case we're hosting
   destroyServer();
   
   // Back to the launch screen
   Canvas.setContent(startMissionGui);
   
   //showMainMenuBttnControls(true);
   //if(zArrowCustomizationGui.isAwake()) 
   //  Canvas.popDialog(zArrowLoginDlg);
}

//----------------------------------------------------------------//
//** In my game, every player has one nick name per his/her user id.
//** This nick name has to be unique and fulfill some criteria such as
//** its length.
//** When nick name is valid, it is saved onto DB in my case. All the
//** changed look information is saved too. But as this is beyond 
//** this resource, I'm not going to handle this any further here.
//----------------------------------------------------------------//
function checkToSaveChangedLookInfo()
{
   %nick = nick_name_input.getText();
   %nickLength = strlen(%nick);
   if(%nickLength == 0){
      MessageBoxOK("Warning", "Please enter your nickname.");
      return;
   }else if(%nickLength < 6 || %nickLength > 16){
      MessageBoxOK("Warning", "Your nick name should be between 6 and 16 in length.");
      return;
   }else
      MessageBoxOKCancel("Confirm", "Are you sure to save this data?", "AskToSaveLookInfo(" @ %nick @ ");");     
}

//-----------------------------------------------------------//
//**Ask the server to save changed data**
//------------------------------------------------------------//
function AskToSaveLookInfo(%nick)
{
   commandToServer('ReqToSaveLookInfo',%nick);
}

//-----------------------------------------------------------//
//**Cancel all the customization procedure and return to initial
//**state.
//------------------------------------------------------------//
function AskToResetLookInfo()
{
   //As initial look is same for every same type of character,
   //just ask server without any additional information.
   commandToServer('ReqToResetLookInfo');
}


//-----------------------------------------------------------//
//**Show customization result message.
//------------------------------------------------------------//
function showCustomResult(%message)
{  
   if(%message $="")
      %message = "Customization is done successfully.";
      
   MessageBoxOK("Message", %message);
   
   %nick = nick_name_input.getText();
   if(%nick !$="")
      setNickname(%nick);      
}

function showCustomGui(%show)
{
   if(%show)
   {
      if(!zArrowCustomizationGui.isAwake())
         Canvas.setContent(zArrowCustomizationGui);
   }
   else
   {
      if(!PlayGui.isAwake())
         Canvas.setContent(PlayGui);
   }
}

//--------------------------------------------------------------//
//** Update Meshes.
//---------------------------------------------------------------// 
function updateMeshes(%meshType, %searching)
{
   
   //mesh type=> 0: head, 1:face, 2:torso, 3: leg
   if(%meshType < 0 || %meshType >= 4)
      return;
      
   switch (%meshType)
   {
    case 0:
      updateHeadMesh(%searching);
      
    case 1:
      updateFaceMesh(%searching);
      
    case 2:
      updateTorsoMesh(%searching);
      
    case 3:
      updateLegMesh(%searching);   
   }
}

//==============================================================================//
// mESH CHANGE HANDLING
//==============================================================================//

//
//** HEAD MESH -----------------------------------------------------------------//
//
function updateHeadMesh(%searching)
{
   %idx = headShape_f.getCurrentIndex() + %searching;
   %max = headShape_f.getMaxIndex();
   if(%idx < 0 || %idx > %max)  //I have just two meshes for head.
      return;
   else
      headShape_f.setCurrentIndex(%idx);
   
   //Update related buttons
   //updateHeadShapeButtons();
   
   //Ask server to update changed look
   commandToServer('ReqUpdateMesh', 0, %idx);
}

//
//** FACE MESH -----------------------------------------------------------------//
//
function updateFaceMesh(%searching)
{
   %idx = faceShape_f.getCurrentIndex() + %searching;
   %max = faceShape_f.MaxIndex;
   
   //I dont't have face meshes at this moment. So, I disabled buttons.
   if(%idx < 0 || %idx > %max)  
      return;
   else
      faceShape_f.setCurrentIndex(%idx);
   
   //updateFaceShapeButtons();
   commandToServer('ReqUpdateMesh', 1, %idx);
}

//
//** TORSO MESH ---------------------------------------------------------------//
//
function updateTorsoMesh(%searching)
{
   %idx = torsoShape_f.getCurrentIndex() + %searching;
   %max = torsoShape_f.getMaxIndex();
   
   if(%idx < 0 || %idx > %max)    //I have three meshes for torso
      return;
   else
      torsoShape_f.setCurrentIndex(%idx);
   
   //updateTorsoShapeButtons();
   commandToServer('ReqUpdateMesh', 2, %idx);
}

//
//** LEG MESH -----------------------------------------------------------------//
//
function updateLegMesh(%searching)
{
   %idx = legShape_f.getCurrentIndex() + %searching;
   %max = legShape_f.getMaxIndex();
   
   if(%idx < 0 || %idx > 1)  
      return;
   else
      legShape_f.setCurrentIndex(%idx);
   
   //updateLegShapeButtons();
   commandToServer('ReqUpdateMesh', 3, %idx);
}


//==============================================================================//
// MATERIAL CHANGE HANDLING ----------------------------------------------------//
//==============================================================================//
 
//
//** HEAD MATERIAL Related functions-------------------------------------------//
//
function updateHeadMaterial(%targetIdx, %value)
{  
   if(%targetIdx == 0)
      updateHeadBase(%targetIdx,%value);
   else if(%targetIdx == 1)
      updateHeadMark1(%targetIdx,%value);
}

function updateHeadBase(%targetIdx,%value)
{
      %idx = headBaseSkin_f.getCurrentIndex() + %value;
      %max = headBaseSkin_f.getMaxIndex();
      if(%idx < 0 || %idx > %max)  //I have just two meshes for head.
         return;
      else
         headBaseSkin_f.setCurrentIndex(%idx);
      
      updateHeadBaseButtons();
      commandToServer('ReqUpdateHeadMaterial', %targetIdx, %idx); 
}

function updateHeadMark1(%targetIdx,%value)
{
      %idx = headSkin_f0.getCurrentIndex() + %value;
      %max = headSkin_f0.getMaxIndex();
      if(%idx < 0 || %idx > %max)  //I have just two meshes for head.
         return;
      else
         headSkin_f0.setCurrentIndex(%idx);
         
      updateHeadMarkButtons1();         
      commandToServer('ReqUpdateHeadMaterial', %targetIdx, %idx);
}

//
//** FACE MATERIAL -------------------------------------------------------------//
//
function updateFaceMaterial(%targetIdx, %value)
{  
   if(%targetIdx == 0)
      updateFaceBase(%targetIdx,%value);
   else if(%targetIdx == 1)
      updateFaceMark1(%targetIdx,%value);
   else if(%targetIdx == 2)
      updateFaceMark2(%targetIdx,%value);  
   else if(%targetIdx == 3)
      updateFaceMark3(%targetIdx,%value);
}

function updateFaceBase(%targetIdx,%value)
{
      %idx = faceBaseSkin_f.getCurrentIndex() + %value;
      %max = faceBaseSkin_f.getMaxIndex();
      if(%idx < 0 || %idx > %max)  //I have just two meshes for head.
         return;
      else
         faceBaseSkin_f.setCurrentIndex(%idx);
         
      updateFaceBaseButtons();
      commandToServer('ReqUpdateFaceMaterial', %targetIdx, %idx); 
}

function updateFaceMark1(%targetIdx,%value)
{
      %idx = faceSkin_f0.getCurrentIndex() + %value;
      %max = faceSkin_f0.getMaxIndex();
      if(%idx < 0 || %idx > %max)  //I have just two meshes for head.
         return;
      else
         faceSkin_f0.setCurrentIndex(%idx);
      
      updateFaceMarkButtons1();
      commandToServer('ReqUpdateFaceMaterial', %targetIdx, %idx);
}

function updateFaceMark2(%targetIdx,%value)
{
      %idx = faceSkin_f1.getCurrentIndex() + %value;
      %max = faceSkin_f1.getMaxIndex();
      if(%idx < 0 || %idx > %max)  //I have just two meshes for head.
         return;
      else
         faceSkin_f1.setCurrentIndex(%idx);
         
      updateFaceMarkButtons2();
      commandToServer('ReqUpdateFaceMaterial', %targetIdx, %idx);
}

function updateFaceMark3(%targetIdx,%value)
{
      %idx = faceSkin_f2.getCurrentIndex() + %value;
      %max = faceSkin_f2.getMaxIndex();
      if(%idx < 0 || %idx > %max)  //I have just two meshes for head.
         return;
      else
         faceSkin_f2.setCurrentIndex(%idx);
         
      updateFaceMarkButtons3();
      commandToServer('ReqUpdateFaceMaterial', %targetIdx, %idx);
}
    
//
//** TORSO MATERIAL Related functions------------------------------------------//
//
function updateTorsoMaterial(%targetIdx, %value)
{   
   if(%targetIdx == 0)
      updateTorsoBase(%targetIdx,%value);
   else if(%targetIdx == 1)
      updateTorsoMark1(%targetIdx,%value);
   else if(%targetIdx == 2)
      updateTorsoMark2(%targetIdx,%value);  
}

function updateTorsoBase(%targetIdx,%value)
{
      %idx = torsoBaseSkin_f.getCurrentIndex() + %value;
      %max = torsoBaseSkin_f.getMaxIndex();
      if(%idx < 0 || %idx > %max)  //I have just two meshes for head.
         return;
      else
         torsoBaseSkin_f.setCurrentIndex(%idx);
         
      updateTorsoBaseButtons();    
      commandToServer('ReqUpdateTorsoMaterial', %targetIdx, %idx); 
}

function updateTorsoMark1(%targetIdx,%value)
{
      %idx = torsoSkin_f0.getCurrentIndex() + %value;
      %max = torsoSkin_f0.getMaxIndex();
      if(%idx < 0 || %idx > %max)  //I have just two meshes for head.
         return;
      else
         torsoSkin_f0.setCurrentIndex(%idx);
         
      updateTorsoMarkButtons1();      
      commandToServer('ReqUpdateTorsoMaterial', %targetIdx, %idx);
}

function updateTorsoMark2(%targetIdx,%value)
{
      %idx = torsoSkin_f1.getCurrentIndex() + %value;
      %max = torsoSkin_f1.getMaxIndex();
      if(%idx < 0 || %idx > %max)  //I have just two meshes for head.
         return;
      else
         torsoSkin_f1.setCurrentIndex(%idx);
      
      updateTorsoMarkButtons2();
      commandToServer('ReqUpdateTorsoMaterial', %targetIdx, %idx);
}

//
//** LEG MATERIAL -------------------------------------------------------------//
//** NOT For use at this moment.
//
function updateLegMaterial(%targetIdx, %value)
{
   if(%targetIdx == 0)
      updateLegBase(%targetIdx,%value);
   else if(%targetIdx == 1)
      updateLegMark1(%targetIdx,%value);
}

function updateLegBase(%targetIdx,%value)
{
      %idx = legBaseSkin_f.getCurrentIndex()+ %value;
      %max = legBaseSkin_f.getMaxIndex();
      if(%idx < 0 || %idx > %max)  //I have just two meshes for head.
         return;
      else
         legBaseSkin_f.setCurrentIndex(%idx);
         
      updateLegBaseButtons();
      commandToServer('ReqUpdateLegMaterial', %targetIdx, $LegSkinIdx0); 
}

function updateLegMark1(%targetIdx,%value)
{
      %idx = legSkin_f0.getCurrentIndex() + %value;
      %max = legSkin_f0.getMaxIndex();
      if(%idx < 0 || %idx > %max)  //I have just two meshes for head.
         return;
      else
         legSkin_f0.setCurrentIndex(%idx);
         
      updateLegMarkButtons1();
      commandToServer('ReqUpdateLegMaterial', %targetIdx, %idx);
}
//==============================================================================//
//init mesh/material buttons------------------------------//
//==============================================================================//

function updateHeadShapeButtons()
{
     %currentIdx = headShape_f.getCurrentIndex();
      %maxIdx = headShape_f.getMaxIndex();

      if(%currentIdx <= 0)
         headShape_b.setActive(false);
      else
         headShape_b.setActive(true);

      //Mesh doesn't have place holder like materials. So decrease by 1.
      if(%currentIdx >= %maxIdx-1)    
         headShape_f.setActive(false);
      else
         headShape_f.setActive(true);
}

function updateHeadBaseButtons()
{
      //if(%idx <= -1)
      //  HeadBaseSkin_b.setActive(false);
      //else if(%idx >= 0)    //Just one base texture at this moment.
      //  HeadBaseSkin_f.setActive(false);
      //else{
         HeadBaseSkin_b.setActive(false);
         HeadBaseSkin_f.setActive(false);
         
      //   headBaseSkin_f.CurrentIndex = %idx;
      //}
}

function updateHeadMarkButtons1()
{
      //if(%idx <= 0)
      //  headSkin_b0.setActive(false);
      //else if(%idx >= 0)
      //  headSkin_f0.setActive(false);
      //else
      //{
         headSkin_b0.setActive(false);
         headSkin_f0.setActive(false);
         
      //  
      //}
}

//
//**FACE ----------------------------------------------------------------------//
//
function updateFaceShapeButtons()
{      
      %currentIdx = faceShape_f.getCurrentIndex();
      %maxIdx = faceShape_f.getMaxIndex();

      if(%currentIdx <= 0)
         faceShape_b.setActive(false);
      else
         faceShape_b.setActive(true);

      if(%currentIdx >= %maxIdx-1)
         faceShape_f.setActive(false);
      else
         faceShape_f.setActive(true);
}

function updateFaceBaseButtons()
{     
     %currentIdx = faceBaseSkin_f.getCurrentIndex();
      %maxIdx = faceBaseSkin_f.getMaxIndex();
      
      if(%currentIdx <= 0)
         faceBaseSkin_b.setActive(false);
      else
         faceBaseSkin_b.setActive(true);

      if(%currentIdx >= %maxIdx)
         faceBaseSkin_f.setActive(false);
      else
         faceBaseSkin_f.setActive(true);
}

function updateFaceMarkButtons1()
{     
      %currentIdx = faceSkin_f0.getCurrentIndex();
      %maxIdx = faceSkin_f0.getMaxIndex();
      
      if(%currentIdx <= 0)
         faceSkin_b0.setActive(false);
      else
         faceSkin_b0.setActive(true);

      if(%currentIdx >= %maxIdx)
         faceSkin_f0.setActive(false);
      else
         faceSkin_f0.setActive(true);
}
function updateFaceMarkButtons2()
{
      %currentIdx = faceSkin_f1.getCurrentIndex();
      %maxIdx = faceSkin_f1.getMaxIndex();

      if(%currentIdx <= 0)
         faceSkin_b1.setActive(false);
      else
         faceSkin_b1.setActive(true);

      if(%currentIdx >= %maxIdx)
         faceSkin_f1.setActive(false);
      else
         faceSkin_f1.setActive(true);
}

function    updateFaceMarkButtons3()
{
      %currentIdx = faceSkin_f2.getCurrentIndex();
      %maxIdx = faceSkin_f2.getMaxIndex();

      if(%currentIdx <= 0)
         faceSkin_b2.setActive(false);
      else
         faceSkin_b2.setActive(true);

      if(%currentIdx >= %maxIdx)
         faceSkin_f2.setActive(false);
      else
         faceSkin_f2.setActive(true);   
}


//
//**Torso-----------------------------------------------------------------------//
//
function    updateTorsoShapeButtons()
{
      %currentIdx = torsoShape_f.getCurrentIndex();
      %maxIdx = torsoShape_f.getMaxIndex();

      if(%currentIdx <= 0)
         torsoShape_b.setActive(false);
      else
         torsoShape_b.setActive(true);

      if(%currentIdx >= %maxIdx-1)
         torsoShape_f.setActive(false);
      else
         torsoShape_f.setActive(true);
}

function    updateTorsoBaseButtons()
{
      //if(%idx <= 0)
      //  torsoBaseSkin_b.setActive(false);
      //else if(%idx >= 0)
      //  torsoBaseSkin_f.setActive(false);
      //else
      //{
         torsoBaseSkin_b.setActive(false);
         torsoBaseSkin_f.setActive(false);
      //}
}
function updateTorsoMarkButtons1()
{     
      %currentIdx = torsoSkin_f0.getCurrentIndex();
      %maxIdx = torsoSkin_f0.getMaxIndex();
      
      if(%currentIdx <= 0)
         torsoSkin_b0.setActive(false);
      else
         torsoSkin_b0.setActive(true);

      if(%currentIdx >= %maxIdx)
         torsoSkin_f0.setActive(false);
      else
         torsoSkin_f0.setActive(true);
         
}
function    updateTorsoMarkButtons2()
{
      %currentIdx = TorsoSkin_f1.getCurrentIndex();
      %maxIdx = TorsoSkin_f1.getMaxIndex();
      
      if(%currentIdx <= 0)
         TorsoSkin_b1.setActive(false);
      else
         TorsoSkin_b1.setActive(true);

      if(%currentIdx >= %maxIdx)
         TorsoSkin_f1.setActive(false);
      else
         TorsoSkin_f1.setActive(true);
}

//
//**LEG -----------------------------------------------------------------------//
//
function   updateLegShapeButtons()
{
      %currentIdx = legShape_f.getCurrentIndex();
      %maxIdx = legShape_f.getMaxIndex();

      if(%currentIdx <= 0)
         legShape_b.setActive(false);
      else
         legShape_b.setActive(true);

      if(%currentIdx >= %maxIdx-1)
         legShape_f.setActive(false);
      else
         legShape_f.setActive(true);
}

function    updateLegBaseButtons(%idx,%value)
{
      //if(%idx <= -1)
        //legBaseSkin_b.setActive(false);
      //else if(%idx >= 0)    //Just one base texture at this moment.
        //LegBaseSkin_f.setActive(false);
      //else
      //{
         LegBaseSkin_b.setActive(false);
         LegBaseSkin_f.setActive(false);
      //}
}

function updateLegMarkButtons1(%idx,%value)
{
      //if(%idx <= -1)
        //LegSkin_b0.setActive(false);
      //else if(%idx >= 0)
        //LegSkin_f0.setActive(false);
      //else
      //{
         LegSkin_b0.setActive(false);
         LegSkin_f0.setActive(false); 
      //}
}