//===========================================================//
// HJ: 10/05/2009
// zArrowCustomizationLook.cs
// Handles every player customization request.
// Clients have minimum information about this. All the information
// about player customization is on the server side. 
//============================================================//


//
//** In the end, every client will have their own customization sets. 
//** And then, we can get the related information from the DB.
//** But that is beyond topic of this resource. I just decided to declare 
//** them here.
//

//** Appropriate mesh and texture number for all the slots of customization gui on client side.
//FACE
$Face     = new ScriptObject(FaceObj)
                  {
                     meshObjectArray   = "";
                     
                     //Defines base textures in the array. It will be used for diffuseMap[0]
                     baseTexArray = "f01 f02 f03"; 
                     
                     //Each base texture can have 3 types of marks.
                     //The following is the marks for f01       
                     FirstMarkArray0  = "c0 f11";
                     SecondMarkArray0 = "c0 f12";
                     ThirdMarkArray0  = "c0 f21 f22";
                     
                     //We can define another marks like this.
                     //The following is for f02 even though they are same as above at this moment.
                     FirstMarkArray1  = "c0 f11";
                     SecondMarkArray1 = "c0 f12";
                     ThirdMarkArray1  = "c0 f21 f22";
                     
                     //Commonly used marks. 
                     FirstCommonMarkArray  = "c0 f11";
                     SecondCommonMarkArray =  "c0 f12";
                     ThirdCommonMarkArray  = "c0 f21 f22";                     
                  };


//TORSO
$Torso     = new ScriptObject(TorsoObj)
                  {
                     meshObjectArray   = "upper heavyarmor_a01_ body";
                     
                     //Base textures for mesh 'upper'. When the client request to change
                     //mesh object, base texture and mark arrays should be changed accordingly.
                     baseTexArray = "playerUniform"; 
                        
                     FirstMarkArray0  = "c0 b11 b12";
                     SecondMarkArray0 = "c0 b21";

                     FirstCommonMarkArray  = "c0 b11 b12";
                     SecondCommonMarkArray =  "c0 b21";
                  };
                  
//HEAD
$Head     = new ScriptObject(HeadObj)
                  {
                     meshObjectArray   = "player_hair helmet";
                     
                     //Defines base textures for the first mesh object in the
                     //meshObject.  
                     baseTexArray     = "helmet";
                     
                     //Marks
                     FirstMarkArray0   = "c0 b11 b12";
                     
                     //Commonly used marks.
                     FirstCommonMarkArray  = "c0 b11 b12";
                  };

//LEG
$Leg    =  new ScriptObject(LegObj)
                  {
                     meshObjectArray   = "lower heavyarmor_b01_";
                     
                     //Base textures for mesh 'upper'. When the client request to change
                     //mesh object, base texture array should be changed accordingly.
                     baseTexArray = "playerPants"; 
                        
                     FirstMarkArray0  = "c0 ";
                     SecondMarkArray0 = "c0 ";

                     FirstCommonMarkArray  = "c0 b11 b12";
                     SecondCommonMarkArray =  "c0 b21";
                  };


//========================//======================//===========================//
//** Mesh changing related functions
//=========================//=====================//===========================//

//
//** show default player mesh set. ---------------------------//
//
function GameConnection::showDefaultPlayerMesh(%this)
{
   %this.player.setAllMeshesHidden(true);
   %this.UpdateMesh(0, 0);  //Head
   %this.updateMesh(1, 1);  //I don't have face meshes at this moment.
   %this.UpdateMesh(2, 0);         //'Upper' mesh
   %this.UpdateMesh(3, 0);         //'Lower' mesh
}

function GameConnection::UpdateMesh(%this, %partToUpdate, %meshIdx)
{
   switch$(%partToUpdate)
   {
      case "0":
         %this.showHeadPlayerMesh(%meshIdx);
      case "1":
         %this.showFacePlayerMesh(%meshIdx);
      case "2":
         %this.showTorsoPlayerMesh(%meshIdx);
      case "3":
         %this.showLegPlayerMesh(%meshIdx);
   }
}


//
//** change Head mesh-------------------- ---------------------------//
//
function GameConnection::showHeadPlayerMesh(%this, %headMeshNo)
{  
   %player = %this.player;
   
   %meshArray = HeadObj.meshObjectArray;
   %selectedMesh = getWord(%meshArray, %headMeshNo);
   
   if(%this.HeadMesh $= %selectedMesh)
      return;
      
   if(%player.getMountedImage(1) == 0)
      %player.MountImage(%selectedMesh, 1);
   else
   {
      %player.UnmountImage(1);
      %player.MountImage(%selectedMesh, 1);
   }
      
   //Save the upated information
   %this.HeadMesh = %selectedMesh;
   
   if(%selectedMesh $= "")
      %this.HeadMat = "H_None_0___";
   else
      %this.HeadMat = "H_" @ %selectedMesh @ "_0___";
   
   %this.InitHeadMeshMaterialGui(%selectedMesh);
}

function GameConnection::showFacePlayerMesh(%this, %meshNo)
{
   %currentMesh = %this.FaceMesh;
   %meshArray = FaceObj.meshObjectArray;
   %selectedMesh = getWord(%meshArray, %meshNo);
   
   if(%currentMesh $= %selectedMesh)
      //return;    //As I don't have face mesh, both value will be "".
   
   %player = %this.player;
   
   if(%currentMesh !$="")
      %player.setMeshHidden(%currentMesh, true);
   if(%selectedMesh!$="")
      %player.setMeshHidden(%selectedMesh, false);
   
   //Save the latest head mesh
   %this.FaceMesh = %selectedMesh;
   
   if(%selectedMesh $= "")
      %this.FaceMat = "T_None_0___";
   else
      %this.FaceMat = "T_" @ %selectedMesh @ "_0___";
      
   %this.InitFaceMeshMaterialGui(%selectedMesh);
}

//
//** change Torso mesh-------------------- ---------------------------//
//
function GameConnection::showTorsoPlayerMesh(%this, %meshNo)
{
   %currentMesh = %this.TorsoMesh;
   %meshArray = TorsoObj.meshObjectArray;
   %selectedMesh = getWord(%meshArray, %meshNo);
   if(%currentMesh $= %selectedMesh)
      return;
   
   %player = %this.player;
   %player.setMeshHidden(%currentMesh, true);
   %player.setMeshHidden(%selectedMesh, false);
   
   //Save the latest head mesh
   %this.TorsoMesh = %selectedMesh;
   
   if(%selectedMesh $= "")
      %this.TorsoMat = "T_None_0___";
   else
      %this.TorsoMat = "T_" @ %selectedMesh @ "_0___";
   
   %this.InitTorsoMeshMaterialGui(%selectedMesh);
}

//
//** change Torso mesh-------------------- ---------------------------//
//
function GameConnection::showLegPlayerMesh(%this, %meshNo)
{
   %currentMesh = %this.LegMesh;
   %meshArray = LegObj.meshObjectArray;
   %selectedMesh = getWord(%meshArray, %meshNo);
   if(%currentMesh $= %selectedMesh)
      return;
   
   %player = %this.player;
   %player.setMeshHidden(%currentMesh, true);
   %player.setMeshHidden(%selectedMesh, false);
   
   //Save the latest head mesh
   %this.LegMesh = %selectedMesh;
   
   if(%selectedMesh $= "")
      %this.LegMat = "L_None_0___";
   else
      %this.LegMat = "L_" @ %selectedMesh @ "_0___";
   
   %this.InitLegMeshMaterialGui(%selectedMesh);
}


//========================//======================//===========================//
//** Skin related functions
//=========================//=====================//===========================//

//
//** Head skins and marks-------------------------- ---------------------------//
//
function GameConnection::updateHeadSkins(%this, %targetIdx, %value)
{
   %currentMat  = %this.HeadMat;
   
   
   if(%targetIdx == 0)     //Base Texture
      %texName = getWord(HeadObj.baseTexArray, %value);
   else if(%targetIdx == 1) //Mark1
      %texName = getWord(HeadObj.FirstMarkArray0, %value);

   %Pos = getTargetPosToChange(%currentMat,%targetIdx);
   %Len = strlen(%currentMat);
   if(getSubstr(%currentMat, %Pos, 1) $= "_"){
      %newMatName = getSubstr(%currentMat, 0, %value) @ %value @
                    getSubstr(%currentMat, %value, %Len-%value);
   }
   else
   {
      %newMatName = getSubstr(%currentMat, 0, %value) @ %value @
                    getSubstr(%currentMat, %value+1, %Len-%value);
   }   
   if(%currentMat $= %newMatName)
      return;
   
   %texFullPath  = "art/shapes/actors/arrow/"@ %texName;
   
   singleton Material(%newMatName);
   %newMatName.assignFieldsFrom(%currentMat);
   %newMatName.setFieldValue("diffuseMap[" @ %targetIdx @"]", %texFullPath);
      
   //Change this to fit your model
   if(%this.HeadMesh $= "helmet")
      %mapTo = "helmet";
   else if(%this.HeadMesh $= "player_hair")
      %mapTo = "playerHair";     
   
   %player = %this.player;
   %player.changeMaterial(%mapTo, %currentMat, %newMatName);
   
   //Save the change
   %this.HeadMat = %newMatName;
}


//
//** Face skins and marks-------------------------- ---------------------------//
//
function GameConnection::updateFaceSkins(%this, %targetIdx, %value)
{
   %currentMat  = %this.FaceMat;
   %texName = getFaceTextureName(%targetIdx, %value);
   
   %Pos = getTargetPosToChange(%currentMat,%targetIdx);
   %Len = strlen(%currentMat);
   if(%texName $= ""){
      %value = ""; 
      %texFullPath  = "art/shapes/actors/arrow/c0";
   }else
      %texFullPath  = "art/shapes/actors/arrow/"@ %texName;
   
   if(getSubstr(%currentMat, %Pos, 1) $= "_"){
      %newMatName = getSubstr(%currentMat, 0, %Pos) @ %value @
                    getSubstr(%currentMat, %Pos, %Len-%Pos);
   }else {
      %newMatName = getSubstr(%currentMat, 0, %Pos) @ %value @
                    getSubstr(%currentMat, %Pos+1, %Len-%Pos);
   }  
   
   if(%currentMat $= %newMatName)
      return;
   
   if(!isObject(%newMatName))
   {  
      %this.createNewMaterial(%currentMat,%newMatName, %targetIdx, %texFullPath);
   }
   else
   {
      setMaterialFieldValues(%newMatName, %targetIdx, %texFullPath);
   }
   
   %player = %this.player;
   %mapTo = "face";
   %player.changeMaterial(%mapTo, %currentMat, %newMatName);
   
   //Save the change
   %this.faceMat = %newMatName;
}


//
//** Torso Skins and marks-------------------------- ---------------------------//
//
function GameConnection::updateTorsoSkins(%this, %targetIdx, %value)
{
   %currentMat  = %this.TorsoMat;
   
   %texName = getTorsoTextureName(%targetIdx, %value);
   %Pos = getTargetPosToChange(%currentMat,%targetIdx);
   %Len = strlen(%currentMat);
   if(%texName $= ""){
      %value = ""; 
      %texFullPath  = "art/shapes/actors/arrow/c0";
   }else
      %texFullPath  = "art/shapes/actors/arrow/"@ %texName;
   
   if(getSubstr(%currentMat, %Pos, 1) $= "_"){
      %newMatName = getSubstr(%currentMat, 0, %Pos) @ %value @
                    getSubstr(%currentMat, %Pos, %Len-%Pos);
   } else {
      %newMatName = getSubstr(%currentMat, 0, %Pos) @ %value @
                    getSubstr(%currentMat, %Pos+1, %Len-%Pos);
   }   
   
   if(%currentMat $= %newMatName)
      return;
   
   if(!isObject(%newMatName)) 
      %this.createNewMaterial(%currentMat,%newMatName, %targetIdx, %texFullPath);
   
   //Change this to fit your model
   if(%this.TorsoMesh $= "heavyarmor_a01_")
      %mapTo = "armor ";
   else if(%this.TorsoMesh $= "player_body")
      %mapTo = "player_body";
   else if(%this.TorsoMesh $= "upper")
      %mapTo = "player_uniform";
      
   if(%mapTo $= "")
      return;
   
   %player = %this.player;
   %player.changeMaterial(%mapTo, %currentMat, %newMatName);
   
   //Save the change
   %this.TorsoMat = %newMatName;
}

//
//** Leg Skins and marks-------------------------- ---------------------------//
//
function GameConnection::updateLegSkins(%this, %targetIdx, %value)
{
   %currentMat  = %this.LegMat;
   
    %texName = getLegTextureName(%targetIdx, %value);
   %Pos = getTargetPosToChange(%currentMat,%targetIdx);
   %Len = strlen(%currentMat);
   if(%texName $= ""){
      %value = ""; 
      %texFullPath  = "art/shapes/actors/arrow/c0";
   }else
      %texFullPath  = "art/shapes/actors/arrow/"@ %texName;
   
   if(getSubstr(%currentMat, %Pos, 1) $= "_"){
      %newMatName = getSubstr(%currentMat, 0, %Pos) @ %value @
                    getSubstr(%currentMat, %Pos, %Len-%Pos);
   } else {
      %newMatName = getSubstr(%currentMat, 0, %Pos) @ %value @
                    getSubstr(%currentMat, %Pos+1, %Len-%Pos);
   }   
   
   if(%currentMat $= %newMatName)
      return;
   
   if(!isObject(%newMatName))
      %this.createNewMaterial(%currentMat,%newMatName, %targetIdx, %texFullPath);
   
   if(%this.LegMesh $= "heavyarmor_b1_")
      %mapTo = "leg";
   else if(%this.LegMesh $= "lower")
      %mapTo = "player_pants";
      
   
   %player = %this.player;
   %player.changeMaterial(%mapTo, %currentMat, %newMatName);
   
   //Save the change
   %this.LegMat = %newMatName;
}

//------------------------------------------------------------------------------//
function GameConnection::createNewMaterial(%this, %currentMat,%newMatName, %targetIdx, %texFullPath)
{
      new Material(%newMatName)
      {
         diffuseMap[0] = %currentMat.diffuseMap[0];
         diffuseMap[1] = %currentMat.diffuseMap[1];
         diffuseMap[2] = %currentMat.diffuseMap[2];
         diffuseMap[3] = %currentMat.diffuseMap[3];
      };
      
      //It seems like below two functions have some problem. At least, it doesn't 
      //work for me. "diffuseMap[" @ %targetIdx @ "]" doesn't work for me either. 
      //%newMatName.assignFieldsFrom(%currentMat);
      //%newMatName.setFieldValue("diffuseMap"@ %targetIdx, %texFullPath);
      setMaterialFieldValues(%newMatName, %targetIdx, %texFullPath);
}

function GameConnection::InitHeadMeshMaterialGui(%this, %selectedMesh)
{
   //Reset base texture array for the selected mesh.
   %currentMeshIdx = 0; 
   if(%selectedMesh $= "player_hair"){
      HeadObj.baseTexArray      = "playerHair";
   } else if(%selectedMesh $= "helmet"){
      HeadObj.baseTexArray      = "helmet";
      %currentMeshIdx = 1;
   }
   
   %meshCount    = getWordCount(HeadObj.meshObjectArray);
   %baseTexCount = getWordCount(HeadObj.baseTexArray )-1;
   commandToClient(%this, 'InitHeadMaterialGuiValues',%currentMeshIdx, %meshCount, 
                                                      %baseTexCount); 
}

//Not available at this moment as I don't have face meshes yet.
function GameConnection::InitFaceMeshMaterialGui(%this, %selectedMesh)
{
   %meshCount    = getWordCount(FaceObj.meshObjectArray);
   %countBaseTex = getWordCount(FaceObj.baseTexArray )-1;
   %countMark1 = getWordCount(FaceObj.FirstMarkArray0 )-1;
   %countMark2 = getWordCount(FaceObj.SecondMarkArray0 )-1;
   %countMark3 = getWordCount(FaceObj.ThirdMarkArray0 )-1;
   commandToClient(%this, 'InitFaceMaterialGuiValues', %meshCount,%countBaseTex,%countMark1,%countMark2,%countMark3); 
   
}

function GameConnection::InitTorsoMeshMaterialGui(%this, %selectedMesh)
{   
   %currentMeshIdx = 0;                 
   if(%selectedMesh $= "upper")
   { 
      TorsoObj.baseTexArray     = "playerUniform"; 
      TorsoObj.FirstMarkArray0  = "c0 b11 b12";
      TorsoObj.SecondMarkArray0 = "c0 b21";
   }
   else if(%selectedMesh $= "heavyarmor_a01_")
   {
      TorsoObj.baseTexArray      = "b01";
      TorsoObj.FirstMarkArray0  = "c0 b41 b42";
      TorsoObj.SecondMarkArray0 = "c0 b61";
      
      %currentMeshIdx = 1;
   }
   else if(%selectedMesh $= "body")
   {
      TorsoObj.baseTexArray      = "playerBody";
      TorsoObj.FirstMarkArray0  = "c0 b41 b42";
      TorsoObj.SecondMarkArray0 = "c0 b61";
      
      %currentMeshIdx = 2;
   }
   %meshCount    = getWordCount(TorsoObj.meshObjectArray);
   %countBaseTex = getWordCount(TorsoObj.baseTexArray )-1;
   %countMark1 = getWordCount(TorsoObj.FirstMarkArray0 )-1;
   %countMark2 = getWordCount(TorsoObj.SecondMarkArray0 )-1;
   commandToClient(%this, 'InitTorsoMaterialGuiValues', 
                  %currentMeshIdx, %meshCount,%countBaseTex,%countMark1,%countMark2); 
}

function GameConnection::InitLegMeshMaterialGui(%this, %selectedMesh)
{
   %currentMeshIdx = 0; 
   if(%selectedMesh $= "lower")
   { 
      LegObj.baseTexArray      = "playerPants";
      //HeadObj.FirstMarkArray0   = "c0 b11 b12";
      //HeadObj.FirstCommonMarkArray  = "c0 b11 b12";
   }
   else if(%selectedMesh $= "heavyarmor_b01_")
   {
      LegObj.baseTexArray      = "leg";
      %currentMeshIdx = 1; 
   }
   
   %meshCount    = getWordCount(LegObj.meshObjectArray);
   %countBaseTex = getWordCount(LegObj.baseTexArray )-1;
   commandToClient(%this, 'InitLegMaterialGuiValues', %currentMeshIdx, %meshCount,%countBaseTex); 
}

//
//HELPER FUNCTION ------------------------------------------------------------//
//
function getTargetPosToChange(%MatName, %targetIdx)
{
   %startPos =  strpos(%MatName, "_", 2);
   
   %loop = %startPos+%targetIdx;
   for(%i = %startPos; %i < %loop; %i++)
   {
      %startPos = strpos(%MatName, "_", %startPos+1);
   }
   return %startPos+1;
}

function getHeadTextureName(%targetIdx, %value)
{
   if(%targetIdx == 0)     //Base Texture
      %texName = getWord(HeadObj.baseTexArray, %value);
   else if(%targetIdx == 1) //Mark1
      %texName = getWord(HeadObj.FirstMarkArray0, %value);
   
   return %texName;
}

function getFaceTextureName(%targetIdx, %value)
{
   if(%targetIdx == 0)     //Base Texture
      %texName = getWord(FaceObj.baseTexArray, %value);
   else if(%targetIdx == 1) //Mark1
      %texName = getWord(FaceObj.FirstMarkArray0, %value);
   else if(%targetIdx == 2) //Mark2
      %texName = getWord(FaceObj.SecondMarkArray0, %value);
   else if(%targetIdx == 3) //Mark3
      %texName = getWord(FaceObj.ThirdMarkArray0, %value);
   
   return %texName;
}

function getTorsoTextureName(%targetIdx, %value)
{
   if(%targetIdx == 0)     //Base Texture
      %texName = getWord(TorsoObj.baseTexArray, %value);
   else if(%targetIdx == 1) //Mark1
      %texName = getWord(TorsoObj.FirstMarkArray0, %value);
   else if(%targetIdx == 2) //Mark2
      %texName = getWord(TorsoObj.SecondMarkArray0, %value);
   
   return %texName;
}

function getLegTextureName(%targetIdx, %value)
{
   if(%targetIdx == 0)     //Base Texture
      %texName = getWord(LegObj.baseTexArray, %value);
   else if(%targetIdx == 1) //Mark1
      %texName = getWord(LegObj.FirstMarkArray0, %value);
   
   return %texName;
}

function setMaterialFieldValues(%newMatName, %targetIdx, %texFullPath)
{
   if(%targetIdx==0)
   {
      %newMatName.diffuseMap[0] = "";
      %newMatName.diffuseMap[0] = %texFullPath;
   }
   else if(%targetIdx==1)
   {
      %newMatName.diffuseMap[1] = "";
      %newMatName.diffuseMap[1] = %texFullPath;
   }
   else if(%targetIdx==2)
   {
      %newMatName.diffuseMap[2] = "";
      %newMatName.diffuseMap[2] = %texFullPath;
   }
   else if(%targetIdx==3)
   {
      %newMatName.diffuseMap[3] = "";
      %newMatName.diffuseMap[3] = %texFullPath;
   }
}