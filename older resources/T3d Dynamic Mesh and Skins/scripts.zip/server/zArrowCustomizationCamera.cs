//===========================================================//
// <HONG>
// Date: 03/07/2010
// zArrowCustomizationCamera.cs
//============================================================//
  
// 
//** Camera Rotation ---------------------------------------------------------//
//
$lastCamAngle_Horizontal = 0;
$HeightThreshold   = 0.4;
function GameConnection::RotateCamera(%this, %dir, %speed, %camDistance)
{
   if(%dir == 0)                  //Initial camera position.
      %this.viewFront(%camDistance);
   else
      %this.rotateCameraByDirection(%dir, %speed);   
}

function GameConnection::viewFront(%this, %camDistance)
{
   //%spawnPoint = pickCustomizationObserverPoint(%this, true);
   %player = %this.Player;
   %eyeVector = %player.getEyeVector();
   %eyeRotationAngle = getWord(%player.getEyeTransform(),6);
   
   %camVector = VectorScale(%eyeVector,%camDistance);
   %camPosVector = VectorAdd(%player.getEyePoint(), %camVector);
   %camAngle = %eyeRotationAngle + mDegToRad(180);    //Opposite direction
   %camRotation = "0 0 1" SPC %camAngle;
   
   %camTransform = %camPosVector SPC %camRotation;
   %this.camera.setTransform(%camTransform); 
   
   $lastCamAngle_Horizontal = %camAngle; 
   //$latestVerCamAngle = 3.141592;
}

function GameConnection::rotateCameraByDirection(%this, %dir, %rotationSpeed)
{
   //We need to rotate the camera around the player. So the vector we rotate 
   //have to be from the player to Camera.
   %eyePosVector   = %this.Player.getEyePoint();
   %currentEyeToCamVector = VectorSub(%this.Camera.getPosition(), %eyePosVector);
         
   //%rotational Direction
   // 1: left, 2: right, 3: up, 4: down, 0: Center
   if(%dir == 1)
   {
      %rotX = 0;
      %rotY = 0;
      %rotZ = (-1) * mDegToRad(%rotationSpeed);
      %camRotationAngleToLookAtTarget = (-1)*%rotZ;
      %matrix = MatrixCreateFromEuler( %rotX SPC %rotY SPC %rotZ);
      
      %resultVec = MatrixMulVector( %matrix, %currentEyeToCamVector);
      %newCamPos = VectorAdd(%eyePosVector, %resultVec); 
   }
   else if(%dir == 2)
   {
      %rotX = 0;
      %rotY = 0;
      %rotZ = mDegToRad(%rotationSpeed);
      %camRotationAngleToLookAtTarget = (-1)*%rotZ;
      %matrix = MatrixCreateFromEuler( %rotX SPC %rotY SPC %rotZ);
      
      %resultVec = MatrixMulVector( %matrix, %currentEyeToCamVector);
      %newCamPos = VectorAdd(%eyePosVector, %resultVec); 
   }
   else if(%dir == 3)
   {
      %goUp = true;
      %camDistance = VectorLen(%currentEyeToCamVector);
      %height = %camDistance * mTan(mDegToRad(%rotationSpeed));
      %upVector = "0 0" SPC %height;
      
      //This will be longer than the final vector we want. So we need to
      //adjust its length.
      %newEyeToCamDirectionVector = VectorAdd(%currentEyeToCamVector, %upVector);
      
      %normVector = VectorNormalize(%newEyeToCamDirectionVector);
      %newEyeToCamAdjustedVector = VectorScale(%normVector,%camDistance);
      %newCamPos = VectorAdd(%eyePosVector, %newEyeToCamAdjustedVector);
   }
   else
   {
      %goUp = false;
      %camDistance = VectorLen(%currentEyeToCamVector);
      %height = %camDistance * mTan(mDegToRad(-1* %rotationSpeed));
      %upVector = "0 0" SPC %height;
      
      //This will be longer than the final vector we want. So we need to
      //adjust its length.
      %newEyeToCamDirectionVector = VectorAdd(%currentEyeToCamVector, %upVector);
      
      %normVector = VectorNormalize(%newEyeToCamDirectionVector);
      %newEyeToCamAdjustedVector = VectorScale(%normVector,%camDistance);
      %newCamPos = VectorAdd(%eyePosVector, %newEyeToCamAdjustedVector);
   }

   //Move it to the new position
   if(%rotationDirection < 3)
      %this.updateCamPosition(%newCamPos, %camRotationAngleToLookAtTarget);
   else
      %this.updateCamVerticalPosition(%newCamPos, %goUp, %rotationSpeed);
}

//Handles horizontal position updates.
function GameConnection::updateCamPosition(%this, %newPos,%camRotAngleToLookAt)
{
   %currentCamAngle = $lastCamAngle_Horizontal;
   %angle   = %currentCamAngle + %camRotAngleToLookAt;//%angleBetween;
   if(%angle > mDegToRad(360))
      %angle -= mDegToRad(360);

   %rotation = "0 0 1" SPC %angle;
   %camPositionVector = %newPos;
   %camNewTransform = %camPositionVector SPC %rotation;
   %this.Camera.setTransform(%camNewTransform);

   $lastCamAngle_Horizontal = %angle;
}

//Handles vertical position updates.
function GameConnection::updateCamVerticalPosition(%this, %newPos, %goUp, %goUpSpeed)
{
   //Camera vertical movement limitation setting
   //NOTICE: Limitation value is not set globally.
   %verticalLimitation = 0.5;
   %eyePosZ = getWord(%this.Player.getEyePoint(),2);
   %eyeToCamVerticalDifference = %eyePosZ - getWord(%newPos,2);
   if(%eyeToCamVerticalDifference > %verticalLimitation ||
       %eyeToCamVerticalDifference < (-1)* %verticalLimitation)
       return;
       
   %rotation = getWords(%this.Camera.getTransform(),3,6);
   %camTransform = %newPos SPC %rotation;
   %this.Camera.setTransform(%camTransform);
   //$latestVerCamAngle = $mvPitch;
}

//Zoom In 
function  GameConnection::ZoomIn(%this)
{
   //NOTICE : Instead of setting global variables, I set the needed variable values 
   //locally here. It is because I don't like abusive use of global variables.
   %zoomInStep = 0.2;
   %zoomInLimit = 1.0;  
   
   %eyePos = %this.Player.getEyePoint();
   %eyeToCamVector = VectorSub(%this.Camera.getPosition(),%eyePos);
   
   %currentEyeToCamLength = VectorLen(%eyeToCamVector);
   %currentEyeToCamLength -= %zoomInStep;
   if(%currentEyeToCamLength < %zoomInLimit)
     return;
     
   %normalVector = VectorNormalize(%eyeToCamVector);
   %newEyeToCamVector = VectorScale(%normalVector, %currentEyeToCamLength);
   %camWorldPosVector = VectorAdd(%eyePos, %newEyeToCamVector);
   
   %newCamTransform = %camWorldPosVector SPC getWords(%this.Camera.getTransform(),3,6);
   %this.Camera.setTransform(%newCamTransform);   
}

//Zoom Out
function  GameConnection::ZoomOut(%this)
{
   //NOTICE : Instead of setting global variables, I set the needed variable values 
   //locally here. It is because I don't like abusive use of global variables.
   %zoomOutStep = 0.2;
   %zoomOutLimit = 3.0;  
   
   %eyePos = %this.Player.getEyePoint();
   %eyeToCamVector = VectorSub(%this.Camera.getPosition(),%eyePos);
   
   %currentEyeToCamLength = VectorLen(%eyeToCamVector);
   %currentEyeToCamLength += %zoomOutStep;
   if(%currentEyeToCamLength > %zoomOutLimit)
     return;
     
   %normalVector = VectorNormalize(%eyeToCamVector);
   %newEyeToCamVector = VectorScale(%normalVector, %currentEyeToCamLength);
   %camWorldPosVector = VectorAdd(%eyePos, %newEyeToCamVector);
   
   %newCamTransform = %camWorldPosVector SPC getWords(%this.Camera.getTransform(),3,6);
   %this.Camera.setTransform(%newCamTransform);
}

//Helper function to get the angle between two vectors
//Returns radian value between given two values.
function getAngleBetweenTwoVector(%vecA,%vecB, %isHorizontal)
{
   if(%isHorizontal)
   {
      //Angle between the two vectors
     %vecAPosX = GetWord(%vecA, 0);
     %vecBPosX = GetWord(%vecB, 0);
     %vecAPosY = GetWord(%vecA, 1);
     %vecBPosY = GetWord(%vecB, 1);
   
     %newVecA = %vecAPosX SPC %vecAPosY SPC "0";
     %newVecB = %vecBPosX SPC %vecBPosY SPC "0";
   }
   else
   {
      //Angle between the two vectors
     %vecAPosZ = GetWord(%vecA, 2);
     %vecBPosZ = GetWord(%vecB, 2);
     %vecAPosY = GetWord(%vecA, 1);
     %vecBPosY = GetWord(%vecB, 1);
     
     %newVecA = "0" SPC %vecAPosY SPC %vecAPosZ;
     %newVecB = "0" SPC %vecBPosY SPC %vecBPosZ;
   }

   %vecALength = VectorLen(%newVecA);
   %vecBLength = VectorLen(%newVecB);
   %multiplied = %vecALength * %vecBLength;

   //get dot product of these vectors
   %dotProduct = VectorDot(%newVecA, %newVecB);

   %radians = mAcos(%dotProduct / %multiplied);
   
   return %radians;
}

function GameConnection::pickCustomizationObserverPoint(%this)
{
   %client = %this;
   %groupName = "MissionGroup/CustomizationDropPoint";
   %group = nameToID(%groupName);

   %spawn = %group.getObject(0);
      return %spawn.getTransform();   
}
