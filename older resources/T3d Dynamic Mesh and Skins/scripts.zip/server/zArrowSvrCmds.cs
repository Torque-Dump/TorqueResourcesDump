//===========================================================//
// <HONG>
// Date: 03/07/2010
// It is the entrance point of all the commands from clients.
// Instead of commands.cs, I decided to use this file to clearly
// separate mine from existed. 
//=============================================================================//


//
//**Customization : Functions for camera rotation.------------------------------//
//
function serverCmdRotateCamera(%client, %direction, %moveStep, %cameraDistance)
{
   %rotationDirection = %direction;
   %rotationSpeed = %moveStep;
   %camDistance = %cameraDistance;
   %client.rotateCamera(%rotationDirection, %rotationSpeed, %camDistance);
}

//
//Functions for camera zoom in/out. --------------------------------------------//
//
function serverCmdZoom(%client, %isZoomIn)
{
   if(%isZoomIn)
      %client.zoomIn();
   else
      %client.zoomOut();
}

//
//Function for change meshes ---------------------------------------------------//
//
function serverCmdReqUpdateMesh(%client, %partToUpdate, %meshIdx)
{
   %client.UpdateMesh(%partToUpdate, %meshIdx);
}

//=============================================================================='//
//**Functions for change skin -----------------------------------------------------//
//===============================================================================//

//
//HEAD --------------------- ---------------------------------------------------//
//
function serverCmdReqUpdateHeadMaterial(%client, %targetIdx, %value)
{
   %client.updateHeadSkins(%targetIdx, %value);
}

//
//FACE --------------------- ---------------------------------------------------//
//
function serverCmdReqUpdateFaceMaterial(%client, %targetIdx, %value)
{
   %client.updateFaceSkins(%targetIdx, %value);
}

//
//Torso --------------------- ---------------------------------------------------//
//
function serverCmdReqUpdateTorsoMaterial(%client, %targetIdx, %value)
{
   %client.updateTorsoSkins(%targetIdx, %value);
}

//
//Leg --------------------- ---------------------------------------------------//
//
function serverCmdReqUpdateLegMaterial(%client, %targetIdx, %value)
{
   %client.updateLegSkins(%targetIdx, %value);
}

//
//**A client requested to save his/her customization data ----------------------//
//
function serverCmdReqToSaveLookInfo(%client, %nickName)
{
  %client.savePlayerCustomizationData(%nickName); 
}