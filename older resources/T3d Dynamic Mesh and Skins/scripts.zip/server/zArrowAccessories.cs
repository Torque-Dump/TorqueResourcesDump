//===========================================================//
// <HONG> 03/10/2010
// zArrowAccessories.cs
// Defines objects that can be mounted
//===========================================================//
datablock ShapeBaseImageData(Helmet)
{
   // Basic Item properties
   shapeFile = "art/shapes/actors/arrow/helmet.dts";
   mountPoint= 1;
   offset    = "0 0 0.1";
};

datablock ShapeBaseImageData(Hair)
{
   // Basic Item properties
   shapeFile = "art/shapes/actors/arrow/player_hair.dts";
   mountPoint = 1;
   offset    = "0 0 0.1";
};
