#include "loaddll.h"
#include "console/simBase.h"
#include "stdlib.h"
#include "windows.h"
#include "stdio.h"

const int maxDLLHandles = 10;
HINSTANCE DLLHandle[maxDLLHandles];

EntryPointPtr0  entryPoint0;
EntryPointPtr1  entryPoint1;
EntryPointPtr2  entryPoint2;
EntryPointPtr3  entryPoint3;
EntryPointPtr4  entryPoint4;
EntryPointPtr5  entryPoint5;
EntryPointPtr6  entryPoint6;
EntryPointPtr7  entryPoint7;
EntryPointPtr8  entryPoint8;
EntryPointPtr9  entryPoint9;
EntryPointPtr10 entryPoint10;

ConsoleFunction(loadDLL, int, 3,3,"Load a DLL - parameters: DLLFilename, DLLHandleNumber")
{
	const char* DLLName = Con::getReturnBuffer(dStrlen(argv[1]+1));
	DLLName = argv[1];

	int hNum = atoi(argv[2]);

	FreeLibrary(DLLHandle[hNum]);
	DLLHandle[hNum] = LoadLibraryA(DLLName);
	return 1;
}

ConsoleFunction(unloadDLL,int, 2,2,"unload a DLL - parameter: DLLHandleNumber")
{
	int hNum = atoi(argv[1]);
	FreeLibrary(DLLHandle[hNum]);

	return 1;
}

ConsoleFunction(executeFunc,const char*, 2,12,"execute a DLL Function - parameters: Name of the DLL-Function and additional Parameters (max 10)")
{
	const char* result;
	int DLLCounter = 0;
	result = "";

	const char* funcName = Con::getReturnBuffer(dStrlen(argv[1]+1));
	funcName = argv[1];

	const char* values[10]; // 10 = max number of parameters for the dll function

	int numArgs = argc;

	for (int i=0; i<numArgs; i++)
	{
		if (i > 1)  // the first 2 arguments are the name of the Console Function and the name of the DLL-Function
		{
			values[i-2] = Con::getReturnBuffer(dStrlen(argv[i]+1));
			values[i-2] = argv[i];
		}
	}

	if (numArgs == 2) // pass 0 paramters to the DLL-Function
	{
		entryPoint0 = (EntryPointPtr0)GetProcAddress( DLLHandle[DLLCounter],funcName);
		while (!entryPoint0 && DLLCounter < maxDLLHandles-1)
		{
			DLLCounter +=1;
			entryPoint0 = (EntryPointPtr0)GetProcAddress( DLLHandle[DLLCounter],funcName);
		}

		if (entryPoint0)
		{
			result = entryPoint0();
		}
	}


	if (numArgs == 3) // pass 1 parameter to the DLL-Function
	{
		entryPoint1 = (EntryPointPtr1)GetProcAddress( DLLHandle[DLLCounter],funcName);
		while (!entryPoint1 && DLLCounter < maxDLLHandles-1)
		{
			DLLCounter +=1;
			entryPoint1 = (EntryPointPtr1)GetProcAddress( DLLHandle[DLLCounter],funcName);
		}
		if (entryPoint1)
		{
			result = entryPoint1(values[0]);
		}
	}

	if (numArgs == 4) // pass 2 parameters to the DLL-Function
	{
		entryPoint2 = (EntryPointPtr2)GetProcAddress( DLLHandle[DLLCounter],funcName);
		while (!entryPoint2 && DLLCounter < maxDLLHandles-1)
		{
			DLLCounter +=1;
			entryPoint2 = (EntryPointPtr2)GetProcAddress( DLLHandle[DLLCounter],funcName);
		}
		if (entryPoint2)
		{
			result = entryPoint2(values[0], values[1]);
		}
	}
	
	if (numArgs == 5) // pass 3 parameters to the DLL-Function
	{
		entryPoint3 = (EntryPointPtr3)GetProcAddress( DLLHandle[DLLCounter],funcName);
		while (!entryPoint3 && DLLCounter < maxDLLHandles-1)
		{
			DLLCounter +=1;
			entryPoint3 = (EntryPointPtr3)GetProcAddress( DLLHandle[DLLCounter],funcName);
		}
		if (entryPoint3)
		{
			result = entryPoint3(values[0], values[1], values[2]);
		}
	}

	if (numArgs == 6) // pass 4 parameters to the DLL-Function
	{
		entryPoint4 = (EntryPointPtr4)GetProcAddress( DLLHandle[DLLCounter],funcName);
		while (!entryPoint4 && DLLCounter < maxDLLHandles-1)
		{
			DLLCounter +=1;
			entryPoint4 = (EntryPointPtr4)GetProcAddress( DLLHandle[DLLCounter],funcName);
		}
		if (entryPoint4)
		{
			result = entryPoint4(values[0], values[1], values[2], values[3]);
		}
	}

	if (numArgs == 7) // pass 5 parameters to the DLL-Function
	{
		entryPoint5 = (EntryPointPtr5)GetProcAddress( DLLHandle[DLLCounter],funcName);
		while (!entryPoint5 && DLLCounter < maxDLLHandles-1)
		{
			DLLCounter +=1;
			entryPoint5 = (EntryPointPtr5)GetProcAddress( DLLHandle[DLLCounter],funcName);
		}
		if (entryPoint5)
		{
			result = entryPoint5(values[0], values[1], values[2], values[3], values[4]);
		}
	}

	if (numArgs == 8) // pass 6 parameters to the DLL-Function
	{
		entryPoint6 = (EntryPointPtr6)GetProcAddress( DLLHandle[DLLCounter],funcName);
		while (!entryPoint6 && DLLCounter < maxDLLHandles-1)
		{
			DLLCounter +=1;
			entryPoint6 = (EntryPointPtr6)GetProcAddress( DLLHandle[DLLCounter],funcName);
		}
		if (entryPoint6)
		{
			result = entryPoint6(values[0], values[1], values[2], values[3], values[4], values[5]);
		}
	}

	if (numArgs == 9) // pass 7 parameters to the DLL-Function
	{
		entryPoint7 = (EntryPointPtr7)GetProcAddress( DLLHandle[DLLCounter],funcName);
		while (!entryPoint7 && DLLCounter < maxDLLHandles-1)
		{
			DLLCounter +=1;
			entryPoint7 = (EntryPointPtr7)GetProcAddress( DLLHandle[DLLCounter],funcName);
		}
		if (entryPoint7)
		{
			result = entryPoint7(values[0], values[1], values[2], values[3], values[4], values[5], values[6]);
		}
	}

	if (numArgs == 10) // pass 8 parameters to the DLL-Function
	{
		entryPoint8 = (EntryPointPtr8)GetProcAddress( DLLHandle[DLLCounter],funcName);
		while (!entryPoint8 && DLLCounter < maxDLLHandles-1)
		{
			DLLCounter +=1;
			entryPoint8 = (EntryPointPtr8)GetProcAddress( DLLHandle[DLLCounter],funcName);
		}
		if (entryPoint8)
		{
			result = entryPoint8(values[0], values[1], values[2], values[3], values[4], values[5], values[6], values[7]);
		}
	}

	if (numArgs == 11) // pass 9 parameters to the DLL-Function
	{
		entryPoint9 = (EntryPointPtr9)GetProcAddress( DLLHandle[DLLCounter],funcName);
		while (!entryPoint9 && DLLCounter < maxDLLHandles-1)
		{
			DLLCounter +=1;
			entryPoint9 = (EntryPointPtr9)GetProcAddress( DLLHandle[DLLCounter],funcName);
		}
		if (entryPoint9)
		{
			result = entryPoint9(values[0], values[1], values[2], values[3], values[4], values[5], values[6], values[7], values[8]);
		}
	}

	if (numArgs == 12) // pass 10 parameters to the DLL-Function
	{
		entryPoint10 = (EntryPointPtr10)GetProcAddress( DLLHandle[DLLCounter],funcName);
		while (!entryPoint10 && DLLCounter < maxDLLHandles-1)
		{
			DLLCounter +=1;
			entryPoint10 = (EntryPointPtr10)GetProcAddress( DLLHandle[DLLCounter],funcName);
		}
		if (entryPoint10)
		{
			result = entryPoint10(values[0], values[1], values[2], values[3], values[4], values[5], values[6], values[7], values[8], values[9]);
		}
	}
	
	return result;
}
