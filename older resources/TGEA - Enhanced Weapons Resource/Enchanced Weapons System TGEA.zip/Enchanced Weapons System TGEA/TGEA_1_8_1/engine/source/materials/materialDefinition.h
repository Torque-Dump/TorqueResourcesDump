//-----------------------------------------------------------------------------
// Torque Shader Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
#ifndef _MATERIALDEFINITION_H_
#define _MATERIALDEFINITION_H_

#ifndef _BASEMATERIALDEFINITION_H_
#include "materials/baseMaterialDefinition.h"
#endif

#ifndef _MATERIALFEATUREDATA_H_
#include "materials/materialFeatureData.h"
#endif

#include "gfx/gfxTextureHandle.h"
#include "gfx/gfxStructs.h"
#include "gfx/gfxCubemap.h"

class CubemapData;
class SFXProfile;
struct SceneGraphData;

class MaterialSoundProfile;
class MaterialPhysicsProfile;

//Enhanced Projectiles
#define MAX_MAT_FX 10
//Enhanced Projectiles
//**************************************************************************
// Basic Material
//**************************************************************************
class Material : public BaseMaterialDefinition
{
   typedef BaseMaterialDefinition Parent;
public:
   static GFXCubemap *getNormalizeCube();

   //-----------------------------------------------------------------------
   // Enums
   //-----------------------------------------------------------------------
   enum Constants
   {
      MAX_TEX_PER_PASS = 8,         ///< Number of textures per pass
      MAX_STAGES = 4,
      NUM_EFFECT_COLOR_STAGES = 2,  ///< Number of effect color definitions for transitioning effects.
   };

   enum TexType
   {
      NoTexture = 0,
      Standard = 1,
      Detail,
      Bump,
      Env,
      Cube,
      SGCube,  // scene graph cube - probably dynamic
      Lightmap,
      NormLightmap,
      Mask,
      Fog,
      BlackFog,
      BackBuff,
      ReflectBuff,
      Misc,
      DynamicLight,
      DynamicLight2,
      DynamicLight3,
      DynamicLight4,
      DynamicLightSecondary,
      DynamicLightMask,
      NormalizeCube
   };

   enum BlendOp
   {
      None = 0,
      Mul,
      Add,
      AddAlpha,      // add modulated with alpha channel
      Sub,
      LerpAlpha,     // linear interpolation modulated with alpha channel
      NumBlendTypes
   };

   enum AnimType
   {
      Scroll = 1,
      Rotate = 2,
      Wave   = 4,
      Scale  = 8,
      Sequence = 16,
   };

   enum WaveType
   {
      Sin = 0,
      Triangle,
      Square,
   };

   struct StageData
   {
      GFXTexHandle      mTex[GFXMaterialFeatureData::NumFeatures];
      GFXCubemap *      mCubemap;

      StageData()
      {
         mCubemap = NULL;
      }
   };
public:

   //Enhanced Projectiles
   U32               bulletDecal;
   U32               materialFX;
   //Enhanced Projectiles

   //-----------------------------------------------------------------------
   // Data
   //-----------------------------------------------------------------------
   FileName mBaseTexFilename[MAX_STAGES];
   FileName mDetailFilename[MAX_STAGES];
   FileName mBumpFilename[MAX_STAGES];
   FileName mEnvFilename[MAX_STAGES];
   StageData mStages[MAX_STAGES];   
   ColorF mDiffuse[MAX_STAGES];
   ColorF mSpecular[MAX_STAGES];
   ColorF mColorMultiply[MAX_STAGES];
   F32 mSpecularPower[MAX_STAGES];
   bool mPixelSpecular[MAX_STAGES];
   bool mVertexSpecular[MAX_STAGES];

   /// Per stage control over the repetition scale of the
   /// detail texture over the base texture.
   F32 mDetailScale[MAX_STAGES];

   // yes this should be U32 - we test for 2 or 4...
   U32 mExposure[MAX_STAGES];

   U32 mAnimFlags[MAX_STAGES];
   Point2F mScrollDir[MAX_STAGES];
   F32 mScrollSpeed[MAX_STAGES];
   Point2F mScrollOffset[MAX_STAGES];

   F32 mRotSpeed[MAX_STAGES];
   Point2F mRotPivotOffset[MAX_STAGES];
   F32 mRotPos[MAX_STAGES];
   
   F32 mWavePos[MAX_STAGES];
   F32 mWaveFreq[MAX_STAGES];
   F32 mWaveAmp[MAX_STAGES];
   U32 mWaveType[MAX_STAGES];
   
   F32 mSeqFramePerSec[MAX_STAGES];
   F32 mSeqSegSize[MAX_STAGES];
   
   bool mGlow[MAX_STAGES];          // entire stage glows
   bool mEmissive[MAX_STAGES];

   bool mDoubleSided;

   String mCubemapName;
   CubemapData* mCubemapData;
   bool mDynamicCubemap;

   bool mTranslucent;   
   BlendOp mTranslucentBlendOp;
   bool mTranslucentZWrite;

   bool mAlphaTest;
   U32 mAlphaRef;

   bool mPlanarReflection;

   ///@{
   /// Behavioral properties.

   bool mShowFootprints;            ///< If true, show footprints when walking on surface with this material.  Defaults to false.
   bool mShowDust;                  ///< If true, show dust emitters (footpuffs, hover trails, etc) when on surface with this material.  Defaults to false.

   /// Color to use for particle effects and such when located on this material.
   ColorF mEffectColor[ NUM_EFFECT_COLOR_STAGES ];

   /// Footstep sound to play when walking on surface with this material.
   /// Numeric ID of footstep sound defined on player datablock (0 == soft,
   /// 1 == hard, 2 == metal, 3 == snow).
   /// Defaults to -1 which deactivates default sound.
   /// @see mFootstepSoundCustom
   S32 mFootstepSoundId;
   S32 mImpactSoundId;

   /// Sound effect to play when walking on surface with this material.
   /// If defined, overrides mFootstepSoundId.
   /// @see mFootstepSoundCustom
   SFXProfile* mFootstepSoundCustom;
   SFXProfile* mImpactSoundCustom;

   F32 mFriction;                   ///< Friction coefficient when moving along surface.

   ///@}
   
   String mMapTo; // map Material to this texture name
  
   ///
   /// Material interface
   ///
   Material();

   /// Allocates and returns a BaseMatInstance for this material.  Caller is responsible
   /// for freeing the instance
   virtual BaseMatInstance* createMatInstance();      
   virtual bool isIFL() const { return mIsIFL; }      
   virtual bool isTranslucent() const { return mTranslucent; }   
   virtual bool isDoubleSided() const { return mDoubleSided; }
   const String &getPath() const { return mPath; }

   /// Called to update time based parameters for a material.  Ensures that it only happens
   /// once per tick.
   void updateTimeBasedParams();

   ///
   /// SimObject interface
   ///
   virtual bool onAdd();
   virtual void onRemove();

   //
   // ConsoleObject interface
   //
   static void initPersistFields();

   DECLARE_CONOBJECT(Material);
protected:

   // Per material animation parameters
   U32 mLastUpdateTime;

   bool mIsIFL;
   String mPath;

   static EnumTable mBlendOpTable;
   static EnumTable mWaveTypeTable;

   virtual void _mapMaterial();
private:
   static GFXCubemapHandle normalizeCube;
};

#endif _MATERIAL_H_
