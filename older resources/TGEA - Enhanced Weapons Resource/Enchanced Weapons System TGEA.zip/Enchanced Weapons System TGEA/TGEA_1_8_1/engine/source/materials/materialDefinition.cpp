//-----------------------------------------------------------------------------
// Torque Shader Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "console/consoleTypes.h"
#include "math/mathTypes.h"

#include "materials/materialDefinition.h"
#include "materials/materialManager.h"
#include "sceneData.h"
#include "gfx/sim/cubemapData.h"
#include "gfx/gfxCubemap.h"
#include "math/mathIO.h"
#include "materials/matInstance.h"
#include "sfx/sfxSystem.h"
#include "core/util/safeDelete.h"

//--------------------------------------------------------------------------
// getNormalizeCube - static method, returns a normalization cubemap
//--------------------------------------------------------------------------
GFXCubemap * Material::getNormalizeCube()
{
   if(normalizeCube)
      return normalizeCube;
   normalizeCube = GFX->createCubemap();
   normalizeCube->initNormalize(64);
   return normalizeCube;
}

//****************************************************************************
// Material
//****************************************************************************
IMPLEMENT_CONOBJECT(Material);

static EnumTable::Enums gBlendOpEnums[] =
{
   { Material::None,         "None" },
   { Material::Mul,          "Mul" },
   { Material::Add,          "Add" },
   { Material::AddAlpha,     "AddAlpha" },
   { Material::Sub,          "Sub" },
   { Material::LerpAlpha,    "LerpAlpha" }
};
EnumTable Material::mBlendOpTable( 6, gBlendOpEnums );

static EnumTable::Enums gWaveTypeEnums[] =
{
   { Material::Sin,          "Sin" },
   { Material::Triangle,     "Triangle" },
   { Material::Square,       "Square" },
};
EnumTable Material::mWaveTypeTable( 3, gWaveTypeEnums );

GFXCubemapHandle Material::normalizeCube;

//----------------------------------------------------------------------------
// Constructor
//----------------------------------------------------------------------------
Material::Material()
{
   for( U32 i=0; i<MAX_STAGES; i++ )
   {
      mDiffuse[i].set( 1.0, 1.0, 1.0, 0.0 );
      mSpecular[i].set( 1.0, 1.0, 1.0, 1.0 );
      mColorMultiply[i].set(0.0f, 0.0f, 0.0f, 0.0f);
      mSpecularPower[i] = 8;
      mPixelSpecular[i] = false;
      mVertexSpecular[i] = false;
      mExposure[i] = 1;
      mGlow[i] = false;
      mEmissive[i] = false;
      mDetailScale[i] = 2;
   }

   mIsIFL = false;

   mDoubleSided = false;

   mTranslucent = false;
   mTranslucentBlendOp = LerpAlpha;
   mTranslucentZWrite = false;

   //Enhanced Projectiles
   bulletDecal = 0;
   materialFX = 0;
   //Enhanced Projectiles

   mAlphaTest = true;
   mAlphaRef = 1;

   mPlanarReflection = false;

   mCubemapData = NULL;
   mDynamicCubemap = NULL;

   dMemset( mAnimFlags, 0, sizeof( mAnimFlags ) );
   dMemset( mScrollOffset, 0, sizeof( mScrollOffset ) );

   dMemset( mRotSpeed,   0, sizeof( mRotSpeed ) );
   dMemset( mRotPivotOffset,  0, sizeof( mRotPivotOffset ) );
   dMemset( mRotPos,     0, sizeof( mRotPos ) );

   dMemset( mWavePos,    0, sizeof( mWavePos ) );
   dMemset( mWaveFreq,   0, sizeof( mWaveFreq ) );
   dMemset( mWaveAmp,    0, sizeof( mWaveAmp ) );
   dMemset( mWaveType,   0, sizeof( mWaveType ) );

   dMemset( mSeqFramePerSec,   0, sizeof( mSeqFramePerSec ) );
   dMemset( mSeqSegSize,       0, sizeof( mSeqSegSize ) );

   mLastUpdateTime = 0;

   mShowDust = false;
   mShowFootprints = false;

   dMemset( mEffectColor,     0, sizeof( mEffectColor ) );

   mFootstepSoundId = -1;     mImpactSoundId = -1;
   mFootstepSoundCustom = 0;  mImpactSoundCustom = 0;
   mFriction = 0.0;
}

//--------------------------------------------------------------------------
// Init fields
//--------------------------------------------------------------------------
void Material::initPersistFields()
{
   Parent::initPersistFields();

   addField("diffuse",        TypeColorF,    Offset(mDiffuse, Material),        MAX_STAGES);
   addField("colorMultiply",  TypeColorF,    Offset(mColorMultiply, Material),  MAX_STAGES);
   addField("specular",       TypeColorF,    Offset(mSpecular, Material),       MAX_STAGES);
   addField("specularPower",  TypeF32,       Offset(mSpecularPower, Material),  MAX_STAGES);
   addField("pixelSpecular",  TypeBool,      Offset(mPixelSpecular, Material),  MAX_STAGES);

   addField("exposure",       TypeS32,       Offset(mExposure, Material),       MAX_STAGES);

   addField("glow",           TypeBool,      Offset(mGlow, Material),           MAX_STAGES);
   addField("emissive",       TypeBool,      Offset(mEmissive, Material),       MAX_STAGES);

   addField("translucent",          TypeBool,   Offset(mTranslucent,          Material));
   addField("translucentBlendOp",   TypeEnum,   Offset(mTranslucentBlendOp,   Material), 1, &mBlendOpTable);
   addField("translucentZWrite",    TypeBool,   Offset(mTranslucentZWrite,    Material));
   
	//Enhanced Projectiles
   addField("bulletDecal",          TypeS32, Offset(bulletDecal,          Material));
   addField("materialFX",          TypeS32, Offset(materialFX,          Material));
	//Enhanced Projectiles

   addField("alphaTest",      TypeBool,      Offset(mAlphaTest,  Material));
   addField("alphaRef",       TypeS32,       Offset(mAlphaRef,   Material));

   addField("planarReflection",     TypeBool,   Offset(mPlanarReflection,  Material));
   
   addField("doubleSided",    TypeBool,      Offset(mDoubleSided,   Material));

   addField("scrollDir",      TypePoint2F,   Offset(mScrollDir,   Material),    MAX_STAGES);
   addField("scrollSpeed",    TypeF32,       Offset(mScrollSpeed,   Material),  MAX_STAGES);

   addField("rotSpeed",       TypeF32,       Offset(mRotSpeed,  Material),      MAX_STAGES);
   addField("rotPivotOffset", TypePoint2F,   Offset(mRotPivotOffset, Material), MAX_STAGES);

   addField("animFlags",   TypeS32,          Offset(mAnimFlags,   Material),    MAX_STAGES );

   addField("waveType",    TypeEnum,         Offset(mWaveType,  Material),      MAX_STAGES, &mWaveTypeTable );
   addField("waveFreq",    TypeF32,          Offset(mWaveFreq,  Material),      MAX_STAGES);
   addField("waveAmp",     TypeF32,          Offset(mWaveAmp,   Material),      MAX_STAGES);

   addField("sequenceFramePerSec",     TypeF32,    Offset(mSeqFramePerSec,  Material),   MAX_STAGES);
   addField("sequenceSegmentSize",     TypeF32,    Offset(mSeqSegSize,  Material),       MAX_STAGES);

   // textures
   addField("baseTex",     TypeStringFilename,     Offset(mBaseTexFilename, Material),   MAX_STAGES);
   addField("detailTex",   TypeStringFilename,     Offset(mDetailFilename, Material),    MAX_STAGES);
   addField("bumpTex",     TypeStringFilename,     Offset(mBumpFilename, Material),      MAX_STAGES);
   addField("envTex",      TypeStringFilename,     Offset(mEnvFilename, Material),       MAX_STAGES);

   addField("detailScale", TypeF32,          Offset(mDetailScale,  Material),   MAX_STAGES);

   // cubemap
   addField("cubemap",        TypeRealString,      Offset(mCubemapName, Material));
   addField("dynamicCubemap", TypeBool,            Offset(mDynamicCubemap, Material));

   // behavioral properties
   addField( "showFootprints",   TypeBool,         Offset( mShowFootprints, Material ) );
   addField( "showDust",         TypeBool,         Offset( mShowDust, Material ) );
   addField( "effectColor",   TypeColorF,          Offset( mEffectColor, Material ), NUM_EFFECT_COLOR_STAGES );
   addField( "footstepSoundId",  TypeS32,          Offset( mFootstepSoundId, Material ) );
   addField( "customFootstepSound", TypeSFXProfilePtr,   Offset( mFootstepSoundCustom, Material ) );
   addField( "impactSoundId",  TypeS32,          Offset( mImpactSoundId, Material ) );
   addField( "customImpactSound", TypeSFXProfilePtr,   Offset( mImpactSoundCustom, Material ) );
   addField( "friction",      TypeF32,           Offset( mFriction, Material ) );

   addField("mapTo",       TypeRealString,         Offset(mMapTo, Material));
}

//--------------------------------------------------------------------------
// On add - verify data settings
//--------------------------------------------------------------------------
bool Material::onAdd()
{
   if (Parent::onAdd() == false)
      return false;

   mCubemapData = dynamic_cast<CubemapData*>(Sim::findObject( mCubemapName ) );

   if( mTranslucentBlendOp >= NumBlendTypes || mTranslucentBlendOp < 0 )
   {
      Con::errorf( "Invalid blend op in material: %s", getName() );
      mTranslucentBlendOp = LerpAlpha;
   }

   SimSet *matSet = MaterialManager::get()->getMaterialSet();
   if( matSet )
      matSet->addObject( (SimObject*)this );

   // save the current script path for texture lookup later
   const String  scriptFile = Con::getVariable("$Con::File");  // current script file - local materials.cs

   String::SizeType  slash = scriptFile.find( '/', scriptFile.length(), String::Right );

   AssertFatal( slash != String::NPos, "Invalid value for $Con::File - missing '/'" );

   mPath = scriptFile.substr( 0, slash + 1 );

   _mapMaterial();

   return true;
}

//--------------------------------------------------------------------------
// On remove
//--------------------------------------------------------------------------
void Material::onRemove()
{
   SAFE_DELETE( normalizeCube );

   Parent::onRemove();
}

//--------------------------------------------------------------------------
// Update time
//--------------------------------------------------------------------------

void Material::updateTimeBasedParams()
{
   U32 lastTime = MaterialManager::get()->getLastUpdateTime();
   F32 dt = MaterialManager::get()->getDeltaTime();
   if (mLastUpdateTime != lastTime)
   {
      for (U32 i = 0; i < MAX_STAGES; i++)
      {
         mScrollOffset[i] += mScrollDir[i] * mScrollSpeed[i] * dt;
         mRotPos[i] += mRotSpeed[i] * dt;
         mWavePos[i] += mWaveFreq[i] * dt;
      }
      mLastUpdateTime = lastTime;
   }
}

//--------------------------------------------------------------------------
// Map this material to the texture specified in the "mapTo" data variable
//--------------------------------------------------------------------------
void Material::_mapMaterial()
{
   if( String(getName()).isEmpty() )
   {
      Con::warnf( "[Material::mapMaterial] - Cannot map unnamed Material" );
      return;
   }

   // If mapTo not defined in script, try to use the base texture name instead
   if( mMapTo.isEmpty() )
   {
      mIsIFL = false;

      if( mBaseTexFilename[0].isEmpty() )
      {
         Con::warnf( "Could not map material: %s to a texture name, need to specify 'mapTo' or 'baseTex[0]' parameter", getName() );
         return;
      }
      else
      {
         // extract filename from base texture
         U32 slashPos = mBaseTexFilename[0].find('/',0,String::Right);
         if (slashPos == String::NPos)
            // no '/' character, must be no path, just the filename
            mMapTo = mBaseTexFilename[0];
         else
            // use everything after the last slash
            mMapTo = mBaseTexFilename[0].substr(slashPos+1, mBaseTexFilename[0].length() - slashPos - 1);
      }
   }
   else
   {
      mIsIFL = String::NPos != mMapTo.find(".ifl", String::NoCase);
   }

   // add mapping
   MaterialManager::get()->mapMaterial(mMapTo,getName());
}

BaseMatInstance* Material::createMatInstance()
{
   return new MatInstance(*this);
}
