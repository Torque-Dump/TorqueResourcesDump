// ////////////////////////////////////////////////////////////////////////////
// GuiReticleHud
// Heavily modified GuiReticleHud by Ron Nelson 
// Based upon the work of Matt Huston, Martin Schultz, Decane, and TSK (TSK@TSKGames.com)
//-----------------------------------------------------------------------------

#include "gui/shiny/guiTickCtrl.h"
#include "gui/core/guiControl.h"
#include "gui/3d/guiTSControl.h"
#include "console/consoleTypes.h"
#include "sceneGraph/sceneGraph.h"
#include "T3D/shapeBase.h"
#include "T3D/gameConnection.h"

class GuiReticleHud : public GuiTickCtrl
{
	typedef GuiControl Parent;
	
	S32 mOffset;

	ColorF mTextColor;
	ColorF mTextOutlineColor;
	ColorF mTextFillColor;

    ColorF   mFillColorDefault;
    ColorF   mFillColorSelected;

    ShapeBase* target;

	bool teamMode;
	S32 clientTeam;
	bool cntrdTgtsOnly;
	U32 detectionMode;
	bool mLockedOn;
	bool mAutoTarget;

protected:
	void drawTargetingRect( const Point2I &a, const Point2I &b, F32 offset, const ColorI &color );
	void drawName( Point2I offset, const char *buf, F32 opacity);

public:
	DECLARE_CONOBJECT( GuiReticleHud );

	GuiReticleHud();
    void selectNextTarget();
    void selectPreviousTarget();
    void selectClosestTarget();
	bool getLockonStatus();
	void setCTgtsOnly(bool flag) { cntrdTgtsOnly = flag; }
	void setTeamMode(bool team) { teamMode = team; }
	void setClientTeam(S32 team) { clientTeam = team; }
	void setDetectionMode(U32 type) { detectionMode = type; }
	void setAutoTargeting(bool flag) { mAutoTarget = flag; }
	S32 getTarget();

	static void initPersistFields();
	bool onWake();
	void onSleep();	
	void onRender( Point2I, const RectI &);
	void advanceTime( F32 timeDelta );
};

IMPLEMENT_CONOBJECT( GuiReticleHud );

GuiReticleHud::GuiReticleHud()
{
	mOffset = 10.0f;

	mTextColor.set(0.2f, 0.2f, 0.2f, 1.0f);
	mTextOutlineColor.set(0.0f, 1.0f, 0.0f, 1.0f);
	mTextFillColor.set(0.8f, 0.8f, 0.8f, 0.8f);

    mFillColorDefault.set( 1.0f, 0.0f, 0.0f, 0.25f );
    mFillColorSelected.set( 1.0f, 1.0f, 0.0f, 0.85f );

    target = NULL;

	clientTeam = -1;
	teamMode = false;
	cntrdTgtsOnly = true;
	detectionMode = 2;
	mLockedOn = false;
	mAutoTarget = false;
}

void GuiReticleHud::initPersistFields()
{
	Parent::initPersistFields();

	addField( "Offset",			  TypeS32,	  Offset( mOffset,			 GuiReticleHud ) );
	addField( "TextColor",		  TypeColorF, Offset( mTextColor,		 GuiReticleHud ) );
	addField( "TextOutlineColor", TypeColorF, Offset( mTextOutlineColor, GuiReticleHud ) );
	addField( "TextFillColor",	  TypeColorF, Offset( mTextFillColor,	 GuiReticleHud ) );

    addGroup("Colors");
    addField("fillColorDefault",  TypeColorF, Offset(mFillColorDefault, GuiReticleHud));
    addField("fillColorSelected",  TypeColorF, Offset(mFillColorSelected, GuiReticleHud));
    endGroup("Colors");
}

bool GuiReticleHud::onWake()
{
	if (! Parent::onWake())
		return false;

	return true;
}

void GuiReticleHud::onSleep()
{
	Parent::onSleep();
}

void GuiReticleHud::advanceTime( F32 timeDelta ) 
{
	if(mAutoTarget)
		selectClosestTarget();
}

void GuiReticleHud::onRender(Point2I offset, const RectI &updateRect)
{
	if(!target)	
		return;

	// Must have a connection and player control object
	GameConnection* conn = GameConnection::getConnectionToServer();
	if (!conn)
		return;
	
   GameBase * control = dynamic_cast<GameBase*>(conn->getControlObject());
   if (!control) return;
	
	GuiTSCtrl *parent = dynamic_cast<GuiTSCtrl*>(getParent());
	if (!parent) 
		return;

	// Parent render.
	Parent::onRender(offset, updateRect);
	// Get control camera info
	MatrixF cam;
	Point3F camPos;
	VectorF camDir;
	conn->getControlCameraTransform(0, &cam);
	cam.getColumn(3, &camPos);

	F32 camFov;
	conn->getControlCameraFov(&camFov);
	camFov = mDegToRad(camFov) / 2;
	
	// Extend the camera vector to create an endpoint for our ray
	F32 visDist = gClientSceneGraph->getVisibleDistance();
	Point3F endPos;
	cam.getColumn(1, &endPos);
	endPos *= visDist;
	endPos += camPos;
	
	// Collision info. We're going to be running LOS tests and we don't 
	// want to collide with the control object, terrain or interiors.
	static U32 losMask = TerrainObjectType | InteriorObjectType | ShapeBaseObjectType;
	control->disableCollision();

	// selected or normal color?
	ColorF mRenderColor = mFillColorDefault;
	
	RayInfo info;
	if (gClientContainer.castRay(camPos, endPos, losMask, &info))
	{
		if (ShapeBase* obj = dynamic_cast<ShapeBase*>(info.object)) 
		{
			if (obj && obj->getId()) 
			{
				if (obj == target)
				{
					mLockedOn = true;
					mRenderColor = mFillColorSelected;
				}
				else
				{
					mLockedOn = false;
				}
			}
		}
	}
	
	Box3F bounds = target->getRenderWorldBox();
	
	// Generate the 8 bounding points of the box.
	Point3F pts[8];
	U32 i = 0;
	
	pts[i].x = bounds.minExtents.x;
	pts[i].y = bounds.minExtents.y;
	pts[i].z = bounds.minExtents.z;
	i++;
	pts[i].x = bounds.minExtents.x;
	pts[i].y = bounds.minExtents.y;
	pts[i].z = bounds.maxExtents.z;
	i++;
	pts[i].x = bounds.minExtents.x;
	pts[i].y = bounds.maxExtents.y;
	pts[i].z = bounds.minExtents.z;
	i++;
	pts[i].x = bounds.minExtents.x;
	pts[i].y = bounds.maxExtents.y;
	pts[i].z = bounds.maxExtents.z;
	i++;
	pts[i].x = bounds.maxExtents.x;
	pts[i].y = bounds.minExtents.y;
	pts[i].z = bounds.minExtents.z;
	i++;
	pts[i].x = bounds.maxExtents.x;
	pts[i].y = bounds.minExtents.y;
	pts[i].z = bounds.maxExtents.z;
	i++;
	pts[i].x = bounds.maxExtents.x;
	pts[i].y = bounds.maxExtents.y;
	pts[i].z = bounds.minExtents.z;
	i++;
	pts[i].x = bounds.maxExtents.x;
	pts[i].y = bounds.maxExtents.y;
	pts[i].z = bounds.maxExtents.z;
	i++;
	
	Point3F boxCenter;
	bounds.getCenter(&boxCenter);
	Point3F rectCenter;
	
	parent->project(boxCenter, &rectCenter);
	
	RectI rect(rectCenter.x, rectCenter.y, 1, 1);
	Point3F pt;
	for(S32 i = 0 ; i < 8; i++)
	{
		parent->project(pts[i], &pt);
		
		if (pt.x < rect.point.x)
		{
			rect.point.x = pt.x;
		}
		if (pt.y < rect.point.y)
		{
			rect.point.y = pt.y;
		}
	}
	
	for(S32 i = 0 ; i < 8 ; i++)
	{
		parent->project(pts[i], &pt);
		
		if (pt.x > rect.point.x + rect.extent.x)
		{
			rect.extent.x = pt.x - rect.point.x;
		}
		if (pt.y > rect.point.y + rect.extent.y)
		{
			rect.extent.y = pt.y - rect.point.y;
		}
	}
	
	// Draw box
	Point3F tgtPos;
	MatrixF tgtSrtMat = target->getRenderTransform();
	tgtSrtMat.getColumn(3, &tgtPos);
	
	VectorF tgtDir = tgtPos - camPos;
	F32 tgtDist = tgtDir.len();
	F32 adjVar = 10.0f/tgtDist;
	if(tgtDist < 10.0f)
		adjVar = 1.0f;
	F32 retOffset = 25.0f * adjVar;

	drawTargetingRect(rect.point, Point2I(rect.extent.x + rect.point.x - 1, rect.extent.y + rect.point.y - 1), retOffset, mRenderColor);
	
	//drawName(Point2I(rect.point.x, rect.point.y), obj->getShapeName(), 1.0f);
	
	// Restore control object collision
	control->enableCollision();
}

void GuiReticleHud::drawName(Point2I offset, const char *name, F32 opacity)
{
	offset.x += 5.0f;
	offset.y += 5.0f;

	// Text outline rectangle
	GFX->getDrawUtil()->drawRect(Point2I(offset.x, offset.y),
		          Point2I(offset.x + mProfile->mFont->getStrWidth((const UTF8 *)name) + mOffset, 
						  offset.y + mProfile->mFont->getHeight()),
				  mTextOutlineColor);

	// Text outline fill rectangle
	GFX->getDrawUtil()->drawRectFill(Point2I(offset.x + 1.0f, offset.y + 1.0f),
		          Point2I(offset.x + mProfile->mFont->getStrWidth((const UTF8 *)name) + mOffset - 1.0f, 
						  offset.y + mProfile->mFont->getHeight() - 1.0f),
				  mTextFillColor);

	// Position text in the rectangle and draw
	offset.x = offset.x + (mOffset / 2);
	
	GFX->getDrawUtil()->setBitmapModulation(mTextColor);
	GFX->getDrawUtil()->drawText(mProfile->mFont, offset, name);
	GFX->getDrawUtil()->clearBitmapModulation();
}

void GuiReticleHud::drawTargetingRect( const Point2I &a, const Point2I &b, F32 offset, const ColorI &color ) 
{
	// NorthWest and NorthEast facing offset vectors
	Point2F l(-0.5f, -0.5f);
	Point2F r(+0.5f, -0.5f);
	
	for(int i = 0 ; i < 4  ; i++)
	{
		GFXVertexBufferHandle<GFXVertexPC> verts (GFX, 8, GFXBufferTypeVolatile );
		verts.lock();

		switch(i)
		{
			// Top Left Corner
			case 0:
				verts[0].point.set( a.x, a.y - l.y, 0.0f );
				verts[1].point.set( a.x, a.y + l.y, 0.0f );
				verts[2].point.set( a.x + offset, a.y + r.y, 0.0f );
				verts[3].point.set( a.x + offset, a.y - r.y, 0.0f );
				verts[4].point.set( a.x - l.x, a.y, 0.0f );
				verts[5].point.set( a.x + l.x, a.y, 0.0f );
				verts[6].point.set( a.x + r.x, a.y + offset, 0.0f );
				verts[7].point.set( a.x - r.x, a.y + offset, 0.0f );
				break;
			// Top Right Corner
			case 1:
				verts[0].point.set(  b.x, a.y - l.y, 0.0f );
				verts[1].point.set(  b.x, a.y + l.y, 0.0f );
				verts[2].point.set( b.x - offset, a.y + r.y, 0.0f );
				verts[3].point.set( b.x - offset, a.y - r.y, 0.0f );				
				verts[4].point.set( b.x - l.x, a.y, 0.0f );
				verts[5].point.set( b.x + l.x, a.y, 0.0f );
				verts[6].point.set( b.x + r.x, a.y + offset, 0.0f );
				verts[7].point.set( b.x - r.x, a.y + offset, 0.0f );
				break;
			// Bottom Left Corner
			case 2:
				verts[0].point.set( a.x, b.y - l.y, 0.0f );
				verts[1].point.set( a.x, b.y + l.y, 0.0f );
				verts[2].point.set( a.x + offset, b.y + r.y, 0.0f );
				verts[3].point.set( a.x + offset, b.y - r.y, 0.0f );
				verts[4].point.set( a.x - l.x, b.y, 0.0f );				
				verts[5].point.set( a.x + l.x, b.y, 0.0f );
				verts[6].point.set( a.x + r.x, b.y - offset, 0.0f );
				verts[7].point.set( a.x - r.x, b.y - offset, 0.0f );
				break;
			// Bottom Right Corner
			case 3:
				verts[0].point.set( b.x, b.y - l.y, 0.0f );
				verts[1].point.set( b.x, b.y + l.y, 0.0f );
				verts[2].point.set( b.x - offset, b.y + r.y, 0.0f );
				verts[3].point.set( b.x - offset, b.y - r.y, 0.0f );
				verts[4].point.set( b.x - l.x, b.y, 0.0f );
				verts[5].point.set( b.x + l.x, b.y, 0.0f );
				verts[6].point.set( b.x + r.x, b.y - offset, 0.0f );
				verts[7].point.set( b.x - r.x, b.y - offset, 0.0f );
				break;
		}

		for (int j = 0 ; j < 8 ; j++)
			verts[j].color = color;
		
		verts.unlock();
		
      
		GFX->setVertexBuffer( verts );
		GFX->drawPrimitive( GFXTriangleStrip, 0, 6 );
	}
}

void GuiReticleHud::selectPreviousTarget()
{
	if(mAutoTarget)
		return;

	// Must have a connection and control object
	GameConnection* conn = GameConnection::getConnectionToServer();
	if (!conn)
		return;

	GameBase* control = conn->getControlObject();
	if (!control)
		return;

	// Get control camera info
	MatrixF cam;
	Point3F camPos;
	VectorF camDir;
	conn->getControlCameraTransform(0,&cam);
	cam.getColumn(3, &camPos);
	cam.getColumn(1, &camDir);

	F32 camFov;
	conn->getControlCameraFov(&camFov);
	camFov = mDegToRad(camFov) / 2;

	F32 visDistance = gClientSceneGraph->getVisibleDistance();
	F32 visDistanceSqr = visDistance * visDistance;

	static U32 ObjectMask;
	if(detectionMode == 0)
		ObjectMask = PlayerObjectType ;
	else if(detectionMode == 1)
		ObjectMask = VehicleObjectType ;
	else
		ObjectMask = PlayerObjectType | VehicleObjectType ;


	// check if we have any target
	if (!target)
	{
		//Con::errorf("Backward: no target set, search for last in list");

		// select now the last target in the list as target.
		ShapeBase* lastShape = NULL;
		for (SimSetIterator itr(conn); *itr; ++itr) 
		{
			if ((*itr)->getType() & ObjectMask) 
			{
				ShapeBase* shape = static_cast<ShapeBase*>(*itr);
				if (shape != control && shape->getShapeName()) 
				{
					if(cntrdTgtsOnly == true)
						if(shape->getControllingClient() == 0)
							continue;
					
					//Target Enemies only
					if(teamMode == true)
					{
						if(shape->getControllingClient() != 0)
						{
							S32 targetTeam = shape->getControllingClient()->getTeamID();
							if(clientTeam == targetTeam)
								continue;
						}
					}

					Point3F shapePos;
					MatrixF srtMat = shape->getRenderTransform();
					srtMat.getColumn(3, &shapePos);

					VectorF shapeDir = shapePos - camPos;

					// Test to see if it's in range
					F32 shapeDist = shapeDir.lenSquared();
					if (shapeDist == 0 || shapeDist > visDistanceSqr)
						continue;

					// Test to see if it's within our viewcone, this test doesn't
					// actually match the viewport very well, should consider
					// projection and box test.
					shapeDir.normalize();
					F32 dot = mDot(shapeDir, camDir);
					if (dot < camFov)
						continue;

					lastShape = shape;
				}
			}
		}
		if (NULL != lastShape)
		{
			target = lastShape;
			//Con::errorf("Backward: last shape taken %d", lastShape->getId());
			return;
		}
		else
		{
			//Con::errorf("Backward: no shape in view");
			return;
		}
	}
	else
	{
		//Con::errorf("Backward: target reverse search with target %d", target->getId());

		// select now the last target in the list as target.
		ShapeBase* previousShape = NULL;
		bool shapeFound = false;
		U32 shapeCounter = 0;
		ShapeBase* firstShapeInList = NULL;
		for (SimSetIterator itr(conn); *itr; ++itr) 
		{
			if ((*itr)->getType() & ObjectMask) 
			{
				ShapeBase* shape = static_cast<ShapeBase*>(*itr);
				
				if (shape != control && shape->getShapeName()) 
				{
					if(cntrdTgtsOnly == true)
						if(shape->getControllingClient() == 0)
							continue;
					
					//Target Enemies only
					if(teamMode == true)
					{
						if(shape->getControllingClient() != 0)
						{
							S32 targetTeam = shape->getControllingClient()->getTeamID();
							if(clientTeam == targetTeam)
								continue;
						}
					}

					if (shapeCounter == 0)
					{
						firstShapeInList = shape;
					}
					shapeCounter++;

					Point3F shapePos;
					MatrixF srtMat = shape->getRenderTransform();
					srtMat.getColumn(3, &shapePos);

					VectorF shapeDir = shapePos - camPos;

					// Test to see if it's in range
					F32 shapeDist = shapeDir.lenSquared();
					if (shapeDist == 0 || shapeDist > visDistanceSqr)
						continue;

					// Test to see if it's within our viewcone, this test doesn't
					// actually match the viewport very well, should consider
					// projection and box test.
					shapeDir.normalize();
					F32 dot = mDot(shapeDir, camDir);
					if (dot < camFov)
						continue;

					if (target == shape)
					{
						if (NULL != shape)
						{
							//Con::errorf("Backward: target id: %d", shape->getId());
						}
						if (NULL != previousShape)
						{
							//Con::errorf("Backward: previous: %d", previousShape->getId());
						}
						if (NULL == previousShape)
						{
							target = NULL;
							selectPreviousTarget();
						}
						else
							target = previousShape;
						shapeFound = true;
						return;
					}

					previousShape = shape;
				}
			}
		}
		
		if (!shapeFound)
		{
			//Con::errorf("Backward: no shape found!");
			target = NULL;
			return;
		}
	}
	return;
}


void GuiReticleHud::selectNextTarget()
{
	if(mAutoTarget)
		return;

	// Must have a connection and control object
	GameConnection* conn = GameConnection::getConnectionToServer();
	if (!conn)
		return;

	GameBase* control = conn->getControlObject();
	if (!control)
		return;

	// Get control camera info
	MatrixF cam;
	Point3F camPos;
	VectorF camDir;
	conn->getControlCameraTransform(0,&cam);
	cam.getColumn(3, &camPos);
	cam.getColumn(1, &camDir);

	F32 camFov;
	conn->getControlCameraFov(&camFov);
	camFov = mDegToRad(camFov) / 2;

	F32 visDistance = gClientSceneGraph->getVisibleDistance();
	F32 visDistanceSqr = visDistance * visDistance;

	bool selectNext = false;
	bool shapeFound = false;
	U32 shapeCounter = 0;
	ShapeBase* firstShape = NULL;

	static U32 ObjectMask;
	if(detectionMode == 0)
		ObjectMask = PlayerObjectType ;
	else if(detectionMode == 1)
		ObjectMask = VehicleObjectType ;
	else
		ObjectMask = PlayerObjectType | VehicleObjectType ;

	for (SimSetIterator itr(conn); *itr; ++itr) 
	{
		if ((*itr)->getType() & ObjectMask) 
		{
			ShapeBase* shape = static_cast<ShapeBase*>(*itr);
			if (shape != control && shape->getShapeName()) 
			{
				if(cntrdTgtsOnly == true)
					if(shape->getControllingClient() == 0)
						continue;

				//Target Enemies only
				if(teamMode == true)
				{
					if(shape->getControllingClient() != 0)
					{
						S32 targetTeam = shape->getControllingClient()->getTeamID();
						if(clientTeam == targetTeam)
							continue;
					}
				}

				if (shapeCounter == 0)
				{
					firstShape = shape;
				}
				shapeCounter++;

				Point3F shapePos;
				MatrixF srtMat = shape->getRenderTransform();
				srtMat.getColumn(3, &shapePos);

				VectorF shapeDir = shapePos - camPos;

				// Test to see if it's in range
				F32 shapeDist = shapeDir.lenSquared();
				if (shapeDist == 0 || shapeDist > visDistanceSqr)
					continue;

				// Test to see if it's within our viewcone, this test doesn't
				// actually match the viewport very well, should consider
				// projection and box test.
				shapeDir.normalize();
				F32 dot = mDot(shapeDir, camDir);
				if (dot < camFov)
					continue;

				//Con::errorf("Forward: Found target id: %d", shape->getId());

				// we don't have any target, mostly because it was never selected. So select the first one.
				if (!target)
				{
					//Con::errorf("Forward: No target was initially selected, selecting first in list with id %d.", shape->getId());
					target = shape;
					shapeFound = true;
					return;
				}

				// the previous shape was the target before and now in this turn this
				// shape is next in the list and is the new target.
				if (selectNext)
				{
					target = shape;
					//Con::errorf("Forward: selectNext id.", shape->getId());
					shapeFound = true;
					return;
				}
				// Select the current shape as target
				if (shape == target)
				{
					selectNext = true;
				}
			}
		}
	}
	// We haven't found any next shape in the list so we need to select the first one again.
	if (!shapeFound && shapeCounter > 0)
	{
		//Con::errorf("Forward: firstShape id.", firstShape->getId());
		target = firstShape;
		return;
	}
	return;
}

void GuiReticleHud::selectClosestTarget()
{
	// Must have a connection and player control object
	GameConnection* conn = GameConnection::getConnectionToServer();
	if (!conn)
		return;
	
   GameBase * control = dynamic_cast<GameBase*>(conn->getControlObject());
   if (!control)
	   return;

	// Get control camera info
	MatrixF cam;
	Point3F camPos;
	Point3F camDir;
	conn->getControlCameraTransform(0,&cam);
	cam.getColumn(3, &camPos);
	cam.getColumn(1, &camDir);

	F32 camFov;
	conn->getControlCameraFov(&camFov);
	camFov = mDegToRad(camFov) / 2;

	F32 visDistance = gClientSceneGraph->getVisibleDistance();

	U32 shapeCounter = 0;
	ShapeBase* savedShape = NULL;
	F32 savedShapeDist = 0.0f;

	static U32 ObjectMask;
	if(detectionMode == 0)
		ObjectMask = PlayerObjectType ;
	else if(detectionMode == 1)
		ObjectMask = VehicleObjectType ;
	else
		ObjectMask = PlayerObjectType | VehicleObjectType ;

	for (SimSetIterator itr(conn); *itr; ++itr) 
	{
		if ((*itr)->getType() & ObjectMask) 
		{
			ShapeBase* shape = static_cast<ShapeBase*>(*itr);
			if (shape != control && shape->getId()) 
			{
				if(cntrdTgtsOnly == true)
					if(shape->getControllingClient() == 0)
						continue;

				//Target Enemies only
				if(teamMode == true)
				{
					if(shape->getControllingClient() != 0)
					{
						S32 targetTeam = shape->getControllingClient()->getTeamID();
						if(clientTeam == targetTeam)
							continue;
					}
					else
						continue;
				}

				Point3F shapePos;
				MatrixF srtMat = shape->getRenderTransform();
				srtMat.getColumn(3, &shapePos); 

				VectorF shapeDir = shapePos - camPos;

				// Test to see if it's in range
				F32 shapeDist = shapeDir.len();
				if (shapeDist == 0 || shapeDist > visDistance)
					continue;

				shapeDir.normalize();
				F32 dot = mDot(shapeDir, camDir);
				if (dot < camFov)
					continue;

				// Test to see if it's behind something, and we want to
				// ignore anything it's mounted on when we run the LOS.
				static U32 losMask = TerrainObjectType | InteriorObjectType | StaticObjectType;
				RayInfo info;
				shape->disableCollision();

				ShapeBase *mount = shape->getObjectMount();				
				if (mount)
					mount->disableCollision();

				bool los = gClientContainer.castRay(camPos, shapePos,losMask, &info);
				
				shape->enableCollision();
				if (mount)
					mount->enableCollision();
				
				if (los)
					continue;

				if (shapeCounter == 0)
				{
					savedShape = shape;
					savedShapeDist = shapeDist;
					shapeCounter++;
					continue;
				}

				if (savedShapeDist > shapeDist)
				{
					savedShape = shape;
				}
			}
		}
	}
	target = savedShape;
}

bool GuiReticleHud::getLockonStatus()
{
	return mLockedOn;
}

S32 GuiReticleHud::getTarget()
{
	if(target)
		return target->getId();
	else
		return 0;
}

ConsoleMethod(GuiReticleHud, getTarget, S32, 2, 2, "getTarget()")
{
   return object->getTarget();
}

ConsoleMethod( GuiReticleHud, setClientTeam, void, 3, 3, "obj.setClientTeam( team# )")
{
	object->setClientTeam( dAtoi( argv[2] ));
}

ConsoleMethod(GuiReticleHud, setTeamMode, void, 3, 3, "GuiReticleHud.setTeamMode(bool) - Sets team game mode")
{
    object->setTeamMode(dAtob(argv[2]));
}

ConsoleMethod(GuiReticleHud, setControlledTargetsOnly, void, 3, 3, "GuiReticleHud.setControlledTargetsOnly(bool) - Used for testing")
{
    object->setCTgtsOnly(dAtob(argv[2]));
}

ConsoleMethod(GuiReticleHud, getLockonStatus, S32, 2, 2, "getLockonStatus()")
{
   return object->getLockonStatus();
}

ConsoleMethod(GuiReticleHud, setAutoTargeting, void, 3, 3, "GuiReticleHud.setAutoTargeting(bool) - Sets auto targeting mode")
{
    object->setAutoTargeting(dAtob(argv[2]));
}

ConsoleMethod(GuiReticleHud, setDetectionMode, void, 3, 3, "GuiReticleHud.setDetectionMode(U32) - Sets detection mode")
{
    object->setDetectionMode( dAtoi( argv[2] ));
}

ConsoleMethod(GuiReticleHud, selectNextTarget, void, 1, 1, "selectNextTarget()")
{
   object->selectNextTarget();
}

ConsoleMethod(GuiReticleHud, selectPreviousTarget, void, 1, 1, "selectPreviousTarget()")
{
   object->selectPreviousTarget();
}