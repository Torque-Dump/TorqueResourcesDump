//-----------------------------------------------------------------------------
// Torque Game Engine Advanced
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _TSMESH_H_
#define _TSMESH_H_

#ifndef _PLATFORM_H_
#include "platform/platform.h"
#endif
#ifndef _STREAM_H_
#include "core/stream/stream.h"
#endif
#ifndef _MMATH_H_
#include "math/mMath.h"
#endif
#ifndef _TVECTOR_H_
#include "core/util/tVector.h"
#endif
#ifndef _ABSTRACTPOLYLIST_H_
#include "collision/abstractPolyList.h"
#endif

#ifndef _GFXDEVICE_H_
#include "gfx/gfxDevice.h"
#endif

#ifndef _GFXPRIMITIVEBUFFER_H_
#include "gfx/gfxPrimitiveBuffer.h"
#endif

#include "sceneGraph/sceneObject.h"//Enhanced Projectiles

#ifdef TORQUE_OPCODE
namespace Opcode { class Model; }
#endif

class Convex;

class TSMeshLightPlugin;
class SceneState;
class SceneObject;

struct MeshRenderInst;

// when working with 3dsmax, we want some things to be vectors that otherwise
// are pointers to non-resizeable blocks of memory
#if defined(TORQUE_MAX_LIB)
#define FixedVector Vector
#else
template<class A> class FixedVector
{
   public:
      A * addr;
      U32 sz;
      U32 size() const { return sz; }
      bool empty() const { return sz==0; }
      A & operator[](U32 idx) { return addr[idx]; }
      A const & operator[](U32 idx) const { return addr[idx]; }
      A * address() { return addr; }
      void set(void * _addr, U32 _sz) { addr = (A*)_addr; sz = _sz; }

      FixedVector() { addr = NULL; sz = 0; }
};
#endif

class TSMaterialList;
class TSShapeInstance;
struct RayInfo;
class ConvexFeature;
class ShapeBase;

struct TSDrawPrimitive
{
   enum
   {
      Triangles    = 0 << 30, ///< bits 30 and 31 index element type
      Strip        = 1 << 30, ///< bits 30 and 31 index element type
      Fan          = 2 << 30, ///< bits 30 and 31 index element type
      Indexed      = BIT(29), ///< use glDrawElements if indexed, glDrawArrays o.w.
      NoMaterial   = BIT(28), ///< set if no material (i.e., texture missing)
      MaterialMask = ~(Strip|Fan|Triangles|Indexed|NoMaterial),
      TypeMask     = Strip|Fan|Triangles
   };

   U16 start;
   U16 numElements;
   S32 matIndex;    ///< holds material index & element type (see above enum)
};

class TSMesh
{
   friend class TSShape;
  protected:
   U32 meshType;
   Box3F mBounds;
   Point3F mCenter;
   F32 mRadius;
   F32 mVisibility;
   bool mDynamic;

   static F32 overrideFadeVal;
   static MatrixF smCamTrans;
   static SceneState * smSceneState;
   static SceneObject * smObject;
   static GFXCubemap * smCubemap;
   static bool smGlowPass;
   static bool smRefractPass;

   GFXVertexBufferHandle<GFXVertexPNTTB> mVB;
   GFXPrimitiveBufferHandle mPB;

  public:

   enum
   {
      /// types...
      StandardMeshType = 0,
      SkinMeshType     = 1,
      DecalMeshType    = 2,
      SortedMeshType   = 3,
      NullMeshType     = 4,
      TypeMask = StandardMeshType|SkinMeshType|DecalMeshType|SortedMeshType|NullMeshType,

      /// flags (stored with meshType)...
      Billboard = BIT(31), HasDetailTexture = BIT(30),
      BillboardZAxis = BIT(29), UseEncodedNormals = BIT(28),
      FlagMask = Billboard|BillboardZAxis|HasDetailTexture|UseEncodedNormals
   };

   U32 getMeshType() { return meshType & TypeMask; }
   void setFlags(U32 flag) { meshType |= flag; }
   void clearFlags(U32 flag) { meshType &= ~flag; }
   U32 getFlags(U32 flag = 0xFFFFFFFF) { return meshType & flag; }

   const Point3F * getNormals(S32 firstVert);

   S32 parentMesh; ///< index into shapes mesh list
   S32 numFrames;
   S32 numMatFrames;
   S32 vertsPerFrame;

   FixedVector<Point3F> verts;
   FixedVector<Point3F> norms;
   FixedVector<Point2F> tverts;
   FixedVector<TSDrawPrimitive> primitives;
   FixedVector<U8> encodedNorms;
   FixedVector<U16> indices;

   Vector<Point3F> initialTangents;
   Vector<Point4F> tangents;

   /// billboard data
   Point3F billboardAxis;

   /// @name Convex Hull Data
   /// Convex hulls are convex (no angles >= 180�) meshes used for collision
   /// @{

   Vector<Point3F> planeNormals;
   Vector<F32>     planeConstants;
   Vector<U32>     planeMaterials;
   S32 planesPerFrame;
   U32 mergeBufferStart;
   /// @}

   /// @name Render Methods
   /// @{

   virtual void render();
   virtual void render(S32 frame, S32 matFrame, TSMaterialList *);
   /// @}


   /// @name Scene state methods
   /// @{
   static void setCamTrans( const MatrixF &trans ){ smCamTrans = trans; }
   static void setSceneState( SceneState *state ){ smSceneState = state; }
   static void setCubemap( GFXCubemap *cm ){ smCubemap = cm; }
   static void setObject( SceneObject *obj ){ smObject = obj; }
   static void setGlow( bool glow ){ smGlowPass = glow; }
   static void setRefract( bool refract ){ smRefractPass = refract; }

   static const MatrixF& getCamTrans() { return smCamTrans; }
   /// @}

   /// @name Material Methods
   /// @{
   static void setMaterial(S32 matIndex, TSMaterialList *);
   void setFade(F32 fade) { mVisibility = fade; }
   void clearFade() { setFade(1.0f); }
   static void setOverrideFade(F32 fadeValue){ overrideFadeVal = fadeValue; }
   static F32  getOverrideFade(){ return overrideFadeVal; }

   /// @}

   /// @name Lighting plug-in methods
   /// @{
protected:
   static TSMeshLightPlugin* smLightPlugin;
public:
   static void registerLightPlugin(TSMeshLightPlugin* mlp);
   static void unregisterLightPlugin(TSMeshLightPlugin* mlp);
   /// @}

   /// @name Collision Methods
   /// @{
   virtual bool buildPolyList(S32 frame, AbstractPolyList * polyList, U32 & surfaceKey, TSMaterialList* materials);
   virtual bool getFeatures(S32 frame, const MatrixF&, const VectorF&, ConvexFeature*, U32& surfaceKey);
   virtual void support(S32 frame, const Point3F& v, F32* currMaxDP, Point3F* currSupport);
   virtual bool castRay(S32 frame, const Point3F & start, const Point3F & end, RayInfo * rayInfo, TSMaterialList* materials);
   virtual bool buildConvexHull(); ///< returns false if not convex (still builds planes)
   bool addToHull(U32 idx0, U32 idx1, U32 idx2);
   /// @}

   /// @name Bounding Methods
   /// calculate and get bounding information
   /// @{

   void computeBounds();
   virtual void computeBounds(MatrixF & transform, Box3F & bounds, S32 frame = 0, Point3F * center = NULL, F32 * radius = NULL);
   void computeBounds(Point3F *, S32 numVerts, MatrixF & transform, Box3F & bounds, Point3F * center, F32 * radius);

   Box3F & getBounds() { return mBounds; }
   Point3F & getCenter() { return mCenter; }
   F32 getRadius() { return mRadius; }

   virtual S32 getNumPolys();

   U8 encodeNormal(const Point3F & normal);
   const Point3F & decodeNormal(U8 ncode);
   /// @}

   /// persist methods...
   virtual void assemble(bool skip);
   static TSMesh * assembleMesh(U32 meshType, bool skip);
   virtual void disassemble();

   // this function allows subclasses to override where there vertex and primitive buffers come from.
   // note that this function returns a reference, allowing the caller to modify the buffers.
   virtual GFXVertexBufferHandle<GFXVertexPNTTB>& getVertexBuffer() { return mVB; };

   void createVBIB();
   void createTangents();
   void findTangent( U32 index1, 
                     U32 index2, 
                     U32 index3, 
                     Point3F *tan0, 
                     Point3F *tan1 );

   /// on load...optionally convert primitives to other form
   static bool smUseTriangles;
   static bool smUseOneStrip;
   static S32  smMinStripSize;
   static bool smUseEncodedNormals;

   /// convert primitives on load...
   void convertToTris(S16 * primitiveDataIn, S32 * primitiveMatIn, S16 * indicesIn,
                      S32 numPrimIn, S32 & numPrimOut, S32 & numIndicesOut,
                      S32 * primitivesOut, S16 * indicesOut);
   void convertToSingleStrip(S16 * primitiveDataIn, S32 * primitiveMatIn, S16 * indicesIn,
                             S32 numPrimIn, S32 & numPrimOut, S32 & numIndicesOut,
                             S32 * primitivesOut, S16 * indicesOut);
   void leaveAsMultipleStrips(S16 * primitiveDataIn, S32 * primitiveMatIn, S16 * indicesIn,
                              S32 numPrimIn, S32 & numPrimOut, S32 & numIndicesOut,
                              S32 * primitivesOut, S16 * indicesOut);

   /// methods used during assembly to share vertex and other info
   /// between meshes (and for skipping detail levels on load)
   S32 * getSharedData32(S32 parentMesh, S32 size, S32 ** source, bool skip);
   S8  * getSharedData8 (S32 parentMesh, S32 size, S8  ** source, bool skip);

   /// @name Assembly Variables
   /// variables used during assembly (for skipping mesh detail levels
   /// on load and for sharing verts between meshes)
   /// @{

   static Vector<Point3F*> smVertsList;
   static Vector<Point3F*> smNormsList;
   static Vector<U8*>      smEncodedNormsList;
   static Vector<Point2F*> smTVertsList;
   static Vector<bool>     smDataCopied;

   static const Point3F smU8ToNormalTable[];
   /// @}


   TSMesh() : meshType(StandardMeshType) {
      VECTOR_SET_ASSOCIATION(planeNormals);
      VECTOR_SET_ASSOCIATION(planeConstants);
      VECTOR_SET_ASSOCIATION(planeMaterials);
      parentMesh = -1;

      #ifdef TORQUE_OPCODE
         mOptTree = NULL;
      #endif

      mDynamic = false;
      mVisibility = 1.0f;
   }
   virtual ~TSMesh();

   #ifdef TORQUE_OPCODE
   
      Opcode::Model *mOptTree;

      void           prepOpcodeCollision();
      virtual bool   buildPolyListOpcode(const S32 od, AbstractPolyList * polyList, const Box3F &nodeBox, TSMaterialList* materials);
      bool           buildConvexOpcode(const MatrixF &mat, const Box3F &bounds, Convex *c, Convex *list);
      bool           buildSBConvexOpcode(const MatrixF &mat, const Box3F &bounds, Convex *c, Convex *list);
      virtual bool   castRayOpcode(const Point3F & start, const Point3F & end, RayInfo * rayInfo, TSMaterialList* materials);

   #endif

   static const F32 VISIBILITY_EPSILON; 
};

inline const Point3F & TSMesh::decodeNormal(U8 ncode) { return smU8ToNormalTable[ncode]; }

class TSSkinMesh : public TSMesh
{
public:
   typedef TSMesh Parent;

   /// vectors that define the vertex, weight, bone tuples
   FixedVector<F32> weight;
   FixedVector<S32> boneIndex;
   FixedVector<S32> vertexIndex;

   /// vectors indexed by bone number
   FixedVector<S32> nodeIndex;
   FixedVector<MatrixF> initialTransforms;

   /// initial values of verts and normals
   /// these get transformed into initial bone space,
   /// from there into world space relative to current bone
   /// pos, and then weighted by bone weights...
   FixedVector<Point3F> initialVerts;
   FixedVector<Point3F> initialNorms;

   // overrides from TSMesh
   GFXVertexBufferHandle<GFXVertexPNTTB>& getVertexBuffer();

   // render methods..
   void render(S32 frame, S32 matFrame, TSMaterialList *);

   // collision methods...
   bool buildPolyList(S32 frame, AbstractPolyList * polyList, U32 & surfaceKey, TSMaterialList* materials);
   bool castRay(S32 frame, const Point3F & start, const Point3F & end, RayInfo * rayInfo, TSMaterialList* materials);
   bool buildConvexHull(); // does nothing, skins don't use this

   void computeBounds(MatrixF & transform, Box3F & bounds, S32 frame, Point3F * center, F32 * radius);

   /// persist methods...
   void assemble(bool skip);
   void disassemble();

   /// variables used during assembly (for skipping mesh detail levels
   /// on load and for sharing verts between meshes)
   static Vector<MatrixF*> smInitTransformList;
   static Vector<S32*>     smVertexIndexList;
   static Vector<S32*>     smBoneIndexList;
   static Vector<F32*>     smWeightList;
   static Vector<S32*>     smNodeIndexList;

   TSSkinMesh()
   {
      meshType = SkinMeshType;
      mDynamic = true;
   }

private:
   /// set verts and normals...
   void updateSkin();
};

//
// Allows the lighting system to process the mesh before submission to the Render Instance manager
//
class TSMeshLightPlugin
{
public:   
   virtual ~TSMeshLightPlugin() {}
   
   // Is passed the current mesh and a list of render instances corresponding to each primitive. 
   // The plug-in is responsible for submitting the render instances to the render instance manager.
   virtual void processRI(TSMesh* mesh, Vector<MeshRenderInst*>& list) = 0;
};


#endif
