//-----------------------------------------------------------------------------
// Torque Game Engine Advanced
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _DECALMANAGER_H_
#define _DECALMANAGER_H_

#ifndef _SCENEOBJECT_H_
#include "sceneGraph/sceneObject.h"
#endif

#ifndef _RENDERPASSMANAGER_H_
#include "renderInstance/renderPassManager.h"
#endif

#ifndef _DEPTHSORTLIST_H_
#include "collision/depthSortList.h"
#endif

#include "gfx/gfxTextureHandle.h"
#include "T3D/gameBase.h"

struct DecalExData
{
   MatrixF mTransform;
   Vector<DepthSortList::Poly> mPartition;
   Vector<Point3F> mPartitionVerts;
   Vector<Point2F> mPartitionTVerts;
   GFXVertexBufferHandle<GFXVertexPCT> mWrapDecalBuffer;
};

/// DataBlock implementation for decals.
class DecalData : public GameBaseData
{
   typedef GameBaseData Parent;

   //-------------------------------------- Console set variables
  public:
   F32               sizeX;
   F32               sizeY;
   StringTableEntry  textureName;
   
   bool selfIlluminated;
   U32 lifeSpan;

   //-------------------------------------- load set variables
  public:
   GFXTexHandle textureHandle;

  public:
   DecalData();
   ~DecalData();
	
   void packData(BitStream*);
   void unpackData(BitStream*);
   bool preload(bool server, String &errorStr);

   DECLARE_CONOBJECT(DecalData);
   static void initPersistFields();
};

DECLARE_CONSOLETYPE(DecalData)

/// Store an instance of a decal.
struct DecalInstance
{
   DecalData* decalData;
   Point3F    point[4];
   Point3F    position;
   Point3F    normal;
   Point3F    impactNormal;

   DecalExData       *exData;

   void buildWrapDecal();
   static DepthSortList smDepthSortList;
   static U32 smDecalMask;
   static void collisionCallback(SceneObject * obj, void* thisPtr);

   //Dynamic Transfom Decals
   bool dynamic;
   SceneObject * decObject;

   U32 ownerId;

   U32            allocTime;
   F32            fade;
   DecalInstance* next;

   DecalInstance();
   ~DecalInstance();
};

/// Manage decals in the world.
class DecalManager : public SceneObject
{
   typedef SceneObject Parent;

   friend struct DecalInstance;

   Vector<DecalInstance*> mDecalQueue;
   bool                   mQueueDirty;

   Vector<DecalInstance*> mWrapDecalQueue;//RJN
   bool                   mWrapQueueDirty;//RJN

public:
   void addDecal(const Point3F& pos,
                 const Point3F& rot,
                 Point3F normal,
                 const Point3F& scale,
                 DecalData*, U32);
   void ageDecal(U32);
   void ageWrapDecal(U32);//RJN
   void clearDecalsInArea(Point3F, F32, F32, F32);//RJN
   void findSpace();
   void findWrapSpace();//RJN
   
   static U32             smMaxNumDecals;
   static U32             smDecalTimeout;

   static bool sgThisIsSelfIlluminated;
   static bool sgLastWasSelfIlluminated;

   static const U32          csmFreePoolBlockSize;
   Vector<DecalInstance*>    mFreePoolBlocks;
   DecalInstance*            mFreePool;

   GFXStateBlockRef  mDefaultSB;
   GFXStateBlockRef  mSelfIlluminatedSB;
   static const U32          csmFreeWrapPoolBlockSize;//RJN
   Vector<DecalInstance*>    mFreeWrapPoolBlocks;//RJN
   DecalInstance*            mFreeWrapPool;//RJN

  protected:
   bool prepRenderImage(SceneState *state, const U32 stateKey, const U32 startZone, const bool modifyBaseZoneState);

   ObjectRenderInst::RenderDelegate mRenderDelegate;
   void renderObject(ObjectRenderInst *, BaseMatInstance*);

   DecalInstance* allocateDecalInstance();
   DecalInstance* allocateWrapDecalInstance();//RJN
   void freeDecalInstance(DecalInstance*);

   void freeWrapDecalInstance(DecalInstance*);//RJN

  public:
   DecalManager();
   ~DecalManager();

   static void consoleInit();

   /// @name Decal Addition
   ///
   /// These functions allow you to add new decals to the world.
   /// @{
   void addDecal(const Point3F& pos,
                 const Point3F& rot,
                 Point3F normal,
                 const Point3F& scale,
                 DecalData*);
   void addDecal(const Point3F& pos,
                 const Point3F& rot,
                 Point3F normal,
                 DecalData*);
   void addDecal(const Point3F& pos,
                 Point3F normal,
                 DecalData*);
   void addWrapDecal(const Point3F& pos,
                 Point3F normal,
                 Point3F impactNormal,
                 DecalData*);
   void addObjectWrapDecal(const Point3F& pos,
                 Point3F normal,
                 Point3F impactNormal,
                 DecalData*, SceneObject*);
   void addObjectDecal(const Point3F& pos,
                 Point3F normal,
                 DecalData*, SceneObject*);
   void addSkidDecal(const Point3F& pos,
                 const Point3F& rot,
                 Point3F normal,
				 const Point3F& oldPos,
				 const Point3F& oldRot,
				 Point3F oldNormal,
                 const Point3F& scale,
                 DecalData*);
   /// @}//RJN

    void wrapDataDeleted(DecalData *data);//RJN
   void dataDeleted(DecalData *data);

   void renderWrapDecal();//RJN
   void renderDecal();
   DECLARE_CONOBJECT(DecalManager);

   static bool smDecalsOn;
};

extern DecalManager* gDecalManager;

#endif // _H_DecalManager
