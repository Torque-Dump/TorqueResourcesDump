datablock EnergyProjectileData(LightningProjectile)
{
   //*****************************************
   //EnergyProjectile Stuff
   //*****************************************
   beamEnabled = true;      
   beamPulse = true;
   updateToMuzzle = false;      
   beamStartRadius = 0.2;      
   beamMidRadius = 0.3;      
   beamEndRadius = 0.2;      
   beamFrontSegmentLength = 5;      
   beamBackSegmentLength = 10;  
   beamMaterialList = "~/data/weaponFX/energy/lightning/lightningProj.dml";
   
   sparkEnabled = false;
   sparkMaterialList = "";
   sparkRadius = 0.3;
   sparkStep =0.0 ;
   sparkRotationStep = 0.0;
   interval = 5;

   //*****************************************
   //Regular Projectile Stuff
   //*****************************************
   projectileShapeName = "~/data/shapes/weapons/SwarmGun/projectile.dts";
   directDamage        = 30;
   radiusDamage        = 0;
   damageRadius        = 0.25;

   areaImpulse         = 90;

   bloodExplosion      = medBloodExplosion;
   waterExplosion      = CrossbowWaterExplosion;

   //Metal
   explosionSetOne[0] = CrossbowExplosion;
   explosionSetOne[1] = CrossbowExplosion;
   explosionSetOne[2] = CrossbowExplosion;
   explosionSetOne[3] = CrossbowExplosion;
   explosionSetOne[4] = CrossbowExplosion;
   explosionSetOne[5] = CrossbowExplosion;

   decalSetOne[0] = medMetalDecal1;
   decalSetOne[1] = medMetalDecal1;
   decalSetOne[2] = medMetalDecal1;
   decalSetOne[3] = medMetalDecal1;
   decalSetOne[4] = medMetalDecal1;
   decalSetOne[5] = medMetalDecal1;

   //Glass
   explosionSetTwo[0] = CrossbowExplosion;
   explosionSetTwo[1] = CrossbowExplosion;
   explosionSetTwo[2] = CrossbowExplosion;
   explosionSetTwo[3] = CrossbowExplosion;
   explosionSetTwo[4] = CrossbowExplosion;
   explosionSetTwo[5] = CrossbowExplosion;

   decalSetTwo[0] = medGlassDecal1;
   decalSetTwo[1] = medGlassDecal1;
   decalSetTwo[2] = medGlassDecal1;
   decalSetTwo[3] = medGlassDecal1;
   decalSetTwo[4] = medGlassDecal1;
   decalSetTwo[5] = medGlassDecal1;

   //Wood
   explosionSetThree[0] = CrossbowExplosion;
   explosionSetThree[1] = CrossbowExplosion;
   explosionSetThree[2] = CrossbowExplosion;
   explosionSetThree[3] = CrossbowExplosion;
   explosionSetThree[4] = CrossbowExplosion;
   explosionSetThree[5] = CrossbowExplosion;

   decalSetThree[0] = medWoodDecal1;
   decalSetThree[1] = medWoodDecal1;
   decalSetThree[2] = medWoodDecal1;
   decalSetThree[3] = medWoodDecal1;
   decalSetThree[4] = medWoodDecal1;
   decalSetThree[5] = medWoodDecal1;

   //Concrete/Stone/Rock/Asphault
   explosionSetFour[0] = CrossbowExplosion;
   explosionSetFour[1] = CrossbowExplosion;
   explosionSetFour[2] = CrossbowExplosion;
   explosionSetFour[3] = CrossbowExplosion;
   explosionSetFour[4] = CrossbowExplosion;
   explosionSetFour[5] = CrossbowExplosion;

   decalSetFour[0] = medConcreteDecal1;
   decalSetFour[1] = medConcreteDecal1;
   decalSetFour[2] = medConcreteDecal1;
   decalSetFour[3] = medConcreteDecal1;
   decalSetFour[4] = medConcreteDecal1;
   decalSetFour[5] = medConcreteDecal1;

   //Terrain
   explosionSetFive[0] = CrossbowExplosion;
   explosionSetFive[1] = CrossbowExplosion;
   explosionSetFive[2] = CrossbowExplosion;
   explosionSetFive[3] = CrossbowExplosion;
   explosionSetFive[4] = CrossbowExplosion;
   explosionSetFive[5] = CrossbowExplosion;

   decalSetFive[0] = medTerrainDecal1;
   decalSetFive[1] = medTerrainDecal1;
   decalSetFive[2] = medTerrainDecal1;
   decalSetFive[3] = medTerrainDecal1;
   decalSetFive[4] = medTerrainDecal1;
   decalSetFive[5] = medTerrainDecal1;

   //Generic
   explosionSetSix[0] = CrossbowExplosion;
   explosionSetSix[1] = CrossbowExplosion;
   explosionSetSix[2] = CrossbowExplosion;
   explosionSetSix[3] = CrossbowExplosion;
   explosionSetSix[4] = CrossbowExplosion;
   explosionSetSix[5] = CrossbowExplosion;
   
   decalSetSix[0] = medGenericDecal1;
   decalSetSix[1] = medGenericDecal1;
   decalSetSix[2] = medGenericDecal1;
   decalSetSix[3] = medGenericDecal1;
   decalSetSix[4] = medGenericDecal1;
   decalSetSix[5] = medGenericDecal1;

   bloodSplatter[0] = wrapTestDecal;
   bloodSplatter[1] = wrapTestDecal;
   bloodSplatter[2] = wrapTestDecal;
   bloodSplatter[3] = wrapTestDecal;
   bloodSplatter[4] = wrapTestDecal;
   bloodSplatter[5] = wrapTestDecal;

   particleEmitter     = CrossbowBoltEmitter;
   particleWaterEmitter= CrossbowBoltBubbleEmitter;

   splash              = CrossbowSplash;

   muzzleVelocity      = 100;
   
   
   velInheritFactor    = 1;

   armingDelay         = 0;
   lifetime            = 10000;
   fadeDelay           = 10000;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   waterSurfaceExplode    = true;
   stoppedByWater    = true;
   nonMeshDeforming    = true;
   isBallistic         = true;
   gravityMod = 0.10;
   
   hasLight    = true;
   lightRadius = 1.5;
   lightColor  = "0.5 0.5 0.5";

   hasWaterLight     = true;
   waterLightColor   = "0 0.5 0.5";

   //Variables for Piercing rounds
   pierceWidthOffset   = 0.0003; 
   playerRearScanDist  = 5.0;

   ballisticCoefficient = 1.0; // 0 - horrid drag, 1 - no drag

   //Guided or Seeker projectiles
   isGuided            = false;
   isHeatSeeker        = false; 
   sweepRadius         = 15;
   // Precision is how acurately the projectile tracks the target.
   // 0 is no tracking (same as not guided) 
   // 100 is exact tracking
   precision           = 5;
   // TrackDelay is the number of milliseconds after firing to begin tracking
   trackDelay          = 40;
   
   //Terrain Following
   isTerrainFollowing = false;
   minTerrainHeight = 5;
   maxTerrainHeight = 5;
   //Formula for creating speedTerrainFollowing  = secondsUntilCrash * gravityMod * 9.8
   speedTerrainFollowing = 14.7;
   
   //Sidewinder Projectile code
   isSidewinder        = false;
   crazyness        = 500;
   sideDelay        = 300;
   multiplier       = 27;
   
   //Explode/Stopped by water    
   explodeOnWater = false;
   stoppedByWater = false;
   
   //Affected by Wind
   useWind = false;
   windEffect = 10;
};

function LightningProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
{
   // Apply damage to the object all shape base objects
   if (%col.getType() & $TypeMasks::ShapeBaseObjectType)
      %col.damage(%obj,%pos,%this.directDamage,"LightningProjectile" );

   // Radius damage is a support scripts defined in radiusDamage.cs
   // Push the contact point away from the contact surface slightly
   // along the contact normal to derive the explosion center. -dbs

   %impulseVec = VectorSub(%col.getWorldBoxCenter(), %obj.getWorldBoxCenter());
   %impulseVec = VectorNormalize(%impulseVec);
   %impulseVec = VectorScale(%impulseVec, %this.areaImpulse);
   
   if(%col.getType() & $TypeMasks::ShapeBaseObjectType)
   {
      %col.applyImpulse(%pos, %impulseVec);
   }
 }
