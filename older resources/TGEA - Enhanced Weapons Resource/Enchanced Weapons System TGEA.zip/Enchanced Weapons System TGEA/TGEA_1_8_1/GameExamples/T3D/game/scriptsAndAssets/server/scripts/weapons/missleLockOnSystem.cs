function serverCmdSetCrosshairTarget(%client, %clientGhostId, %locked)
{
   if (%clientGhostId != 0)
   {
      %reticleServerTargetId = %client.ResolveGhost(%clientGhostId);
      //error("Server reticle target id: " @ %reticleServerTargetId @ " / clientGhostId: " @ %clientGhostId);
      if(%locked == true)
      {
         %client.targetedObject = %reticleServerTargetId;
      }
      else
      {
         %client.targetedObject = %reticleServerTargetId;
      }
      if (!%client.isAIControlled()) // send only to humans
      {
      	 // these are events sent to the reticle target and to the one that actually locks the target. 
      	 // Can be used to play weapon lock / warning sounds and alike.
      	 commandToClient(%reticleServerTargetId.client, 'MissileLockOn', %locked);
      	 commandToClient(%client, 'TargetLockedOn', %locked);
      }
   }
   else
   {
      //error("Server reticle target = 0!");
      %client.targetedObject = 0;
   }   
}