//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Bullet Material Identifiers
//-----------------------------------------------------------------------------
//0 = Metal
//1 = Glass
//2 = Wood
//3 = Concrete/Stone/Rock/Asphault
//4 = Dirt Terrain
//5 = Generic
//6 = None

//-----------------------------------------------------------------------------
// Custom Materials
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Materials
//-----------------------------------------------------------------------------
new Material( GunRangeGlass )
{
   mapTo = "glass";
   baseTex[0] = "scriptsAndAssets/data/interiors/gunrange/glass.png";
   translucent = true;
   //pixelSpecular[0] = true; //whether the pixels shine from the sun or light
   //specular[0] = "1.0 1.0 1.0 0.1"; //I think this refers to direction of light reflection?
   //specularPower[0] = 2.0; //how much shine,2/4/8/16 or 32
   translucentBlendOp = LerpAlpha; //as above
   //translucentZWrite = true; //as above
   alphaTest = true; // default value would be true
   alphaRef = 0; // anything below this number is not visible and is not written to zbuffer
   //emissive[0] = true;
   bulletDecal = 1;
   friction = 1;
};

new Material( GunRangeBrick01 )
{
   mapTo = "brick01";
   baseTex[0] = "scriptsAndAssets/data/interiors/gunrange/brick01.jpg";
   bumpTex[0] = "scriptsAndAssets/data/interiors/gunrange/brick01_NRM.png";
   bulletDecal = 3;
   friction = 1;
};

new Material( GunRangeBrick02 )
{
   mapTo = "brick02";
   baseTex[0] = "scriptsAndAssets/data/interiors/gunrange/brick02.jpg";
   bumpTex[0] = "scriptsAndAssets/data/interiors/gunrange/brick02_NRM.png";
   bulletDecal = 3;
   friction = 1;
};

new Material( GunRangeCONC_F )
{
   mapTo = "CONC_F";
   baseTex[0] = "scriptsAndAssets/data/interiors/gunrange/CONC_F.png";
   bumpTex[0] = "scriptsAndAssets/data/interiors/gunrange/CONC_F_NRM.png";
   bulletDecal = 3;
   friction = 1;
};

new Material( GunRangeConcrete )
{
   mapTo = "concrete";
   baseTex[0] = "scriptsAndAssets/data/interiors/gunrange/concrete.jpg";
   bumpTex[0] = "scriptsAndAssets/data/interiors/gunrange/concrete_NRM.png";
   bulletDecal = 3;
   friction = 1;
};

new Material( GunRangeHeavyMetal )
{
   mapTo = "heavymet";
   baseTex[0] = "scriptsAndAssets/data/interiors/gunrange/heavymet.jpg";
   bumpTex[0] = "scriptsAndAssets/data/interiors/gunrange/heavymet_NRM.png";
   bulletDecal = 0;
   friction = 1;
};

new Material( GunRangeLightMetal )
{
   mapTo = "lightmet";
   baseTex[0] = "scriptsAndAssets/data/interiors/gunrange/lightmet.jpg";
   bumpTex[0] = "scriptsAndAssets/data/interiors/gunrange/lightmet_NRM.png";
   bulletDecal = 0;
   friction = 1;
};

new Material( GunRangeMarble )
{
   mapTo = "marble01";
   baseTex[0] = "scriptsAndAssets/data/interiors/gunrange/marble01.jpg";
   bumpTex[0] = "scriptsAndAssets/data/interiors/gunrange/marble01_NRM.png";
   bulletDecal = 3;
   friction = 1;
};

new Material( GunRangeWallPaper )
{
   mapTo = "wallp012";
   baseTex[0] = "scriptsAndAssets/data/interiors/gunrange/wallp012.jpg";
   bumpTex[0] = "scriptsAndAssets/data/interiors/gunrange/wallp012_NRM.png";
   bulletDecal = 5;
   friction = 1;
};

new Material( GunRangeLightWood01 )
{
   mapTo = "wood01";
   baseTex[0] = "scriptsAndAssets/data/interiors/gunrange/wood01.jpg";
   bumpTex[0] = "scriptsAndAssets/data/interiors/gunrange/wood01_NRM.png";
   bulletDecal = 2;
   friction = 1;
};






