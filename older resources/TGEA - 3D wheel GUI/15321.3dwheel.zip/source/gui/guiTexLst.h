//-----------------------------------------------------------------------------
// Torque Game Engine Advanced
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _GuiTexLst_H_
#define _GuiTexLst_H_

#include "gui/gui3DView.h"
#include "gfx/gfxTextureHandle.h"

class GuiTexLst : public SimObject
{
private:
	typedef SimObject Parent;
	enum {
		MAX_TEXTURES = 16
	};

protected:
	StringTableEntry mTextureName[MAX_TEXTURES];
	GFXTexHandle mTexture[MAX_TEXTURES];

public:
	DECLARE_CONOBJECT(GuiTexLst);

	GuiTexLst();
	~GuiTexLst();

	virtual void setTexture(UTF8* name, U32 id);
	GFXTexHandle getTexture(U32 id);

private:
};

#endif
