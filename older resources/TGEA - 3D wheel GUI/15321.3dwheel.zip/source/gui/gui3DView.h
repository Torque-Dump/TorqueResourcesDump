//-----------------------------------------------------------------------------
// Torque Game Engine Advanced
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _Gui3DView_H_
#define _Gui3DView_H_

#include "gui/3d/guiTSControl.h"

class LightInfo;

class Gui3DView : public GuiTSCtrl
{
private:
	typedef GuiTSCtrl Parent;

protected:
	enum MouseState
	{
		None,
		Rotating,
		Zooming,
		Disable
	};

	MouseState  mMouseState;

	Point3F     mCameraPos;
	MatrixF     mCameraMatrix;
	EulerF      mCameraRot;
	Point3F     mOrbitPos;

	S32         mLastRenderTime;
	S32		   mDeltaTime;
	Point2I     mLastMousePoint;

	LightInfo*  mFakeSun;

	F32         mMaxOrbitDist;
	F32         mMinOrbitDist;
	F32         mOrbitDist;


public:
	bool onWake();

	void onMouseEnter(const GuiEvent &event);
	void onMouseLeave(const GuiEvent &event);
	void onMouseDown(const GuiEvent &event);
	void onMouseUp(const GuiEvent &event);
	void onMouseDragged(const GuiEvent &event);
	void onRightMouseDown(const GuiEvent &event);
	void onRightMouseUp(const GuiEvent &event);
	void onRightMouseDragged(const GuiEvent &event);

	/// Sets the distance at which the camera orbits the object. Clamped to the
	/// acceptable range defined in the class by min and max orbit distances.
	///
	/// \param distance The distance to set the orbit to (will be clamped).
	void setOrbitDistance(F32 distance);

	bool processCameraQuery(CameraQuery *query);
	void renderWorld(const RectI &updateRect);

	virtual void on3DRender(const RectI &updateRect) {};

	DECLARE_CONOBJECT(Gui3DView);

	Gui3DView();
	~Gui3DView();

private:
};

#endif
