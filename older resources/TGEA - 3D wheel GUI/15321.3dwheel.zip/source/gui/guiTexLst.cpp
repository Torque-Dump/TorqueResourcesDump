//------------------------------------------------------------------------------
// Torque Game Engine Advanced
// Copyright (C) GarageGames.com, Inc.
//------------------------------------------------------------------------------

#include "gui/guiTexLst.h"

//-----------------------------------------------------------------------------
// GuiTexLst
//-----------------------------------------------------------------------------
IMPLEMENT_CONOBJECT(GuiTexLst);

GuiTexLst::GuiTexLst()
{
	for(U32 i = 0; i < MAX_TEXTURES; i++) {
		mTexture[i] = NULL;
		mTextureName[i] = StringTable->insert("");
	}
}

GuiTexLst::~GuiTexLst()
{
	for(U32 i = 0; i < MAX_TEXTURES; i++) {
		mTexture[i] = NULL;
		mTextureName[i] = StringTable->insert("");
	}
}

GFXTexHandle GuiTexLst::getTexture(U32 id)
{
	if(id < MAX_TEXTURES) return mTexture[id];
	return NULL;
}

void GuiTexLst::setTexture(UTF8* name, U32 id)
{
	if(id>=MAX_TEXTURES) {
		Con::warnf("[GuiTexLst] Setting too much texture (%d / %d)", id, MAX_TEXTURES);
		return;
	}
	mTextureName[id] = StringTable->insert(name);
	mTexture[id].set(mTextureName[id], &GFXDefaultGUIProfile);
}

ConsoleMethod(GuiTexLst, setTexture, void, 4, 4, "(name, id)"
			  " Set texture name for id")
{
	object->setTexture((UTF8*)argv[2], dAtoi(argv[3]));
}
