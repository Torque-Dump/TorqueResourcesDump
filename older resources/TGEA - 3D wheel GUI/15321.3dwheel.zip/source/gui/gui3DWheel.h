//-----------------------------------------------------------------------------
// Torque Game Engine Advanced
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _Gui3DWheel_H_
#define _Gui3DWheel_H_

#include "gui/gui3DView.h"

class GuiTexLst;

class Gui3DWheel : public Gui3DView
{
	typedef Gui3DView Parent;
public:
	enum {
		Horizontal,
		Vertical
	};

protected:
	S32 mOrientation;
	F32 mSpeed;
	F32 mAngOff;
	S32 mSeg;
	F32 mSegWidth;
	F32 mSegHeight;
	F32 mRadius;
	F32 mFar;
	F32 mRotationSpeed;
	F32 mTilt;
	ColorI mSelected;
	ColorI mUnselected;
	GuiTexLst *mTexture;

public:
	bool onWake();

	void onMouseUp(const GuiEvent &event);
	void onMouseMove(const GuiEvent &event);
	void on3DRender(const RectI &updateRect);
	U32 getSelection(F32 offset = 0);
	void setTextureLst(GuiTexLst *lst);
	void setSpin(F32 speed);

	DECLARE_CONOBJECT(Gui3DWheel);

	Gui3DWheel();
	~Gui3DWheel();
	static void initPersistFields();

private:
};

#endif
