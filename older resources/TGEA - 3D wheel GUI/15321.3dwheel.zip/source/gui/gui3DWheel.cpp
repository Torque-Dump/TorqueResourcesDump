//------------------------------------------------------------------------------
// Torque Game Engine Advanced
// Copyright (C) GarageGames.com, Inc.
//------------------------------------------------------------------------------

#include "console/consoleTypes.h"
#include "gui/gui3DWheel.h"
#include "gui/guiTexLst.h"
#include "gfx/primBuilder.h"

//-----------------------------------------------------------------------------
// Gui3DWheel
//-----------------------------------------------------------------------------
IMPLEMENT_CONOBJECT(Gui3DWheel);

Gui3DWheel::Gui3DWheel() : Parent()
{
	mMouseState = Disable;
	mOrientation = Horizontal;
	mSpeed = 0;
	mAngOff = 0;
	mSeg = 6;
	mSegWidth = 10;
	mSegHeight = 10;
	mRadius = 2 * (mSeg + 1) * mSegWidth / (M_PI * 2);
	mFar = 0.2f;
	mRotationSpeed = 45.f;
	mOrbitDist = (2 + mFar) * mRadius;
	mMaxOrbitDist = mOrbitDist*2;
	mTilt = 10;
	mTexture = NULL;
	mSelected.set(255,255,255);
	mUnselected.set(64,64,64);
}

Gui3DWheel::~Gui3DWheel()
{
}

static const EnumTable::Enums orientEnums[] =
{
	{ Gui3DWheel::Horizontal,      "Horizontal"     },
	{ Gui3DWheel::Vertical,        "Vertical"     }
};
static const EnumTable gOrientTable(2, &orientEnums[0]);

void Gui3DWheel::initPersistFields()
{
	Parent::initPersistFields();
	addGroup("3DWheel");
	addField("Orientation",		TypeEnum,		Offset(mOrientation,	Gui3DWheel), 1, &gOrientTable);
	addField("AngularSpeed",	TypeF32,		Offset(mRotationSpeed,	Gui3DWheel));
	addField("SquareWidth",		TypeF32,		Offset(mSegWidth,		Gui3DWheel));
	addField("SquareHeight",	TypeF32,		Offset(mSegHeight,		Gui3DWheel));
	addField("Distance",		TypeF32,		Offset(mFar,			Gui3DWheel));
	addField("Tilt",			TypeF32,		Offset(mTilt,			Gui3DWheel));
	addField("NbElements",		TypeS32,		Offset(mSeg,			Gui3DWheel));
	addField("SelectedColor",	TypeColorI,		Offset(mSelected,		Gui3DWheel));
	addField("Unselectedcolor",	TypeColorI,		Offset(mUnselected,		Gui3DWheel));
	endGroup("3DWheel");
}

bool Gui3DWheel::onWake()
{
	if (!Parent::onWake())
	{
		return(false);
	}

	// Set orientation according to selection
	mOrbitDist = (2 + mFar) * mRadius;
	mMaxOrbitDist = mOrbitDist*2;
	if(mOrientation == Horizontal) mCameraRot.set(mTilt*M_PI/180.0,0,0);
	else mCameraRot.set(mTilt*M_PI/180.0,M_PI/2,0);

	return(true);
}

void Gui3DWheel::onMouseMove(const GuiEvent &event)
{
	RectI bounds = getBounds();
	Point2I center = getExtent() / 2;
	
	// Look at x or y position depending on orientation
	Point2I pos = globalToLocalCoord(event.mousePoint);
	F32 delta;
	if(mOrientation == Horizontal) delta = (pos.x - center.x) * 200.0 / (getWidth()/2.0);
	else delta = (pos.y - center.y) * 200.0 / (getHeight()/2.0);
	
	mSpeed = (delta < -200) ? 200 : (delta > 200) ? 200 : (mFabs(delta) < 20) ? 0 : delta;
}

void Gui3DWheel::setSpin(F32 speed)
{
	mSpeed = speed;
}

U32 Gui3DWheel::getSelection(F32 offset)
{
	// Check AngPos is in which segment
	F32 angsync = 2*M_PI/(F32)mSeg;
	F32 delta = offset + mAngOff; if(delta>2*M_PI) delta -= 2*M_PI;
	delta += angsync * 0.5; if(delta>2*M_PI) delta -= 2*M_PI;
	delta /= angsync;
	return (U32) (delta);
}

void Gui3DWheel::onMouseUp(const GuiEvent &event)
{
	Con::executef(this, "onSelection", Con::getIntArg(getSelection()));
	mouseUnlock();
}

void Gui3DWheel::on3DRender(const RectI &updateRect)
{
	// No texture, draw noyhing
	if(!mTexture) return;

	// Set rendering state
	GFX->setLightingEnable( false );
	GFX->setAlphaBlendEnable( true );
	GFX->setSrcBlend( GFXBlendSrcAlpha );
	GFX->setDestBlend( GFXBlendInvSrcAlpha );
	GFX->setTextureStageColorOp( 0, GFXTOPModulate );
	GFX->setTextureStageColorOp( 1, GFXTOPDisable );
	GFX->setupGenericShaders( GFXDevice::GSModColorTexture );
	GFX->setTextureStageMinFilter(0, GFXTextureFilterAnisotropic);
	GFX->setTextureStageMagFilter(0, GFXTextureFilterAnisotropic);

	//
	// Render a circle of photos

	// 1. Compute offset for the circle
	mAngOff -= mDeltaTime * (mRotationSpeed * 0.001 * M_PI / 180.0f) * mSpeed / 100.0 ;
	if(mAngOff > 2 * M_PI) mAngOff -= 2 * M_PI;
	if(mAngOff < 0) mAngOff += 2 * M_PI;

	// 2. We need to order all the photos from the farther to the closest (for Z test) - from -PI/2 to PI/2
	S32 * id = (S32 *) dMalloc(sizeof(S32)*mSeg); if(!id) return;
	F32 * ang = (F32 *) dMalloc(sizeof(F32)*mSeg); if(!ang) return;
	F32 * ang2 = (F32 *) dMalloc(sizeof(F32)*mSeg); if(!ang2) return;
	U32 pos = 0; S32 tmpId = 0;

	// Compute angular position, id and also angular position from -PI/2 to PI/2
	for(F32 angPos = 0; angPos < 2*M_PI && pos < mSeg; angPos += 2*M_PI/(F32)mSeg, pos++, tmpId--) {
		if(tmpId < 0) tmpId = mSeg-1;
		if(tmpId >= mSeg) tmpId = 0;
		id[pos] = tmpId;
		ang[pos] = angPos+mAngOff-M_PI/2;
		ang2[pos] = ang[pos];

		// Convert angle from [0, 2PI] to [-PI/2,PI/2]
		if(ang2[pos] < 0) ang2[pos] += M_PI * 2;
		if(ang2[pos] > 2 * M_PI) ang2[pos] -= M_PI * 2;
		// To [-PI, PI]
		if(ang2[pos] > M_PI) ang2[pos] -= M_PI * 2;
		// To [-PI/2, PI/2]
		if(ang2[pos] > M_PI/2) ang2[pos] = M_PI - ang2[pos];
		if(ang2[pos] < -M_PI/2) ang2[pos] = -M_PI - ang2[pos];
	}

	// 3. Sort array ang (and also keep its id,ang ordered) - bubble sort
	for(U32 i = 0; i < mSeg; i++) {
		for(U32 j = i+1; j < mSeg; j++ ) {
			if(ang2[j] > ang2[i]) {
				F32 tmpAng2 = ang2[j]; ang2[j] = ang2[i]; ang2[i] = tmpAng2;
				F32 tmpAng = ang[j]; ang[j] = ang[i]; ang[i] = tmpAng;
				S32 tmpId = id[j]; id[j] = id[i]; id[i] = tmpId;
			}
		}
	}

	// 5. Display the bitmap now thanks to previous ordering
	for(U32 i = 0; i < mSeg; i++ ) {
		Point3F posa, posb;
		GFXTexHandle tex = mTexture->getTexture(id[i]);
		if(!tex) continue;
		posa.x = mRadius * mCos(ang[i]) + mSegWidth * mSin(ang[i]);
		posb.x = mRadius * mCos(ang[i]) - mSegWidth * mSin(ang[i]);
		posa.y = mRadius * mSin(ang[i]) - mSegWidth * mCos(ang[i]);
		posb.y = mRadius * mSin(ang[i]) + mSegWidth * mCos(ang[i]);

		GFXVertexBufferHandle<GFXVertexPCT> verts(GFX, 4, GFXBufferTypeVolatile);
		verts.lock();
		const F32 fillConv = GFX->getFillConventionOffset();
		verts[0].point.set( posa.x - fillConv, posa.y    - fillConv,  mSegHeight );
		verts[1].point.set( posb.x - fillConv, posb.y    - fillConv,  mSegHeight );
		verts[2].point.set( posa.x - fillConv, posa.y    - fillConv, -mSegHeight );
		verts[3].point.set( posb.x - fillConv, posb.y    - fillConv, -mSegHeight );

		// Select correct rendering overlay color
		if(id[i] == getSelection())
			verts[0].color = verts[1].color = verts[2].color = verts[3].color = mSelected;
		else
			verts[0].color = verts[1].color = verts[2].color = verts[3].color = mUnselected;

		// Select correct texture position according to wheel position
		if(mOrientation == Horizontal) {
			verts[0].texCoord.set( 0,  0 );
			verts[1].texCoord.set( 1, 0 );
			verts[2].texCoord.set( 0,  1 );
			verts[3].texCoord.set( 1, 1 );
		} else {
			verts[0].texCoord.set( 1,  0 );
			verts[1].texCoord.set( 1, 1 );
			verts[2].texCoord.set( 0,  0 );
			verts[3].texCoord.set( 0, 1 );
		}
		verts.unlock();

		// display vertex buffer
		GFX->setVertexBuffer( verts );
		GFX->setTexture( 0, tex );
		GFX->setupGenericShaders( GFXDevice::GSModColorTexture );
		GFX->drawPrimitive( GFXTriangleStrip, 0, 2 );
	}

	// Free memeory
	dFree(ang);
	dFree(id);
}

void Gui3DWheel::setTextureLst(GuiTexLst *lst)
{
	mTexture = lst;
}

ConsoleMethod(Gui3DWheel, setTextureLst, void, 3, 3, "(texLst)"
			  "Set texture lst class")
{
	GuiTexLst * texLst = dynamic_cast<GuiTexLst*> (Sim::findObject(dAtoi(argv[2])));
	object->setTextureLst(texLst);
}

ConsoleMethod(Gui3DWheel, setSpin, void, 3, 3, "(speed)"
			  "Set wheel spin speed (in percent)")
{
	object->setSpin(dAtof(argv[2]));
}
