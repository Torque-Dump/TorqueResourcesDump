//------------------------------------------------------------------------------
// Torque Game Engine Advanced
// Copyright (C) GarageGames.com, Inc.
//------------------------------------------------------------------------------

#include "gui/gui3DView.h"
#include "renderInstance/renderInstMgr.h"
#include "sceneGraph/lightManager.h"
#include "sceneGraph/lightInfo.h"

//-----------------------------------------------------------------------------
// Gui3DView
//-----------------------------------------------------------------------------

Gui3DView::Gui3DView()
:  mMaxOrbitDist(5.0f),
mMinOrbitDist(0.0f),
mOrbitDist(5.0f),
mMouseState(None),
mLastMousePoint(0, 0),
mLastRenderTime(0),
mDeltaTime(0),
mFakeSun(NULL)
{
	mActive = true;

	mCameraMatrix.identity();
	mCameraRot.set(0.0f, 0.0f, 0.0f);
	mCameraPos.set(0.0f, 0.0f, 0.0f);
	mCameraMatrix.setColumn(3, mCameraPos);
	mOrbitPos.set(0.0f, 0.0f, 0.0f);
}

Gui3DView::~Gui3DView()
{
	SAFE_DELETE(mFakeSun);
}

bool Gui3DView::onWake()
{
	if (!Parent::onWake())
	{
		return(false);
	}

	LightManager* lm = gClientSceneGraph->getLightManager();
	if (!mFakeSun)
	{
		mFakeSun = lm->createLightInfo();   
	}
	mFakeSun->mColor.set(1.0f, 1.0f, 1.0f);
	mFakeSun->mAmbient.set(0.5f, 0.5f, 0.5f);
	mFakeSun->mDirection.set(0.f, 0.707f, -0.707f);   

	return(true);
}

void Gui3DView::onMouseDown(const GuiEvent &event)
{
	if (!mActive || !mVisible || !mAwake)
	{
		return;
	}

	if(mMouseState == Disable) return;

	mMouseState = Rotating;
	mLastMousePoint = event.mousePoint;
	mouseLock();
}

void Gui3DView::onMouseUp(const GuiEvent &event)
{
	if(mMouseState == Disable) return;

	mouseUnlock();
	mMouseState = None;
}

void Gui3DView::onMouseDragged(const GuiEvent &event)
{
	if (mMouseState != Rotating)
	{
		return;
	}

	if(mMouseState == Disable) return;

	Point2I delta = event.mousePoint - mLastMousePoint;
	mLastMousePoint = event.mousePoint;

	mCameraRot.x += (delta.y * 0.01f);
	mCameraRot.z += (delta.x * 0.01f);
}

void Gui3DView::onRightMouseDown(const GuiEvent &event)
{
	if(mMouseState == Disable) return;

	mMouseState = Zooming;
	mLastMousePoint = event.mousePoint;
	mouseLock();
}

void Gui3DView::onRightMouseUp(const GuiEvent &event)
{
	if(mMouseState == Disable) return;

	mouseUnlock();
	mMouseState = None;
}

void Gui3DView::onRightMouseDragged(const GuiEvent &event)
{
	if(mMouseState == Disable) return;

	if (mMouseState != Zooming)
	{
		return;
	}

	S32 delta = event.mousePoint.y - mLastMousePoint.y;
	mLastMousePoint = event.mousePoint;

	mOrbitDist += (delta * 0.01f);
}

bool Gui3DView::processCameraQuery(CameraQuery* query)
{
	// Adjust the camera so that we are still facing the model:
	Point3F vec;
	MatrixF xRot, yRot, zRot;
	xRot.set(EulerF(mCameraRot.x, 0.0f, 0.0f));
	yRot.set(EulerF(0.0f, mCameraRot.y, 0.0f));
	zRot.set(EulerF(0.0f, 0.0f, mCameraRot.z));

	MatrixF mat;
	mat.mul(yRot, xRot);
	mCameraMatrix.mul(zRot, mat);
	mCameraMatrix.getColumn(1, &vec);
	vec *= mOrbitDist;
	mCameraPos = mOrbitPos - vec;

	query->farPlane = 2100.0f;
	query->nearPlane = query->farPlane / 5000.0f;
	query->fov = 45.0f;
	mCameraMatrix.setColumn(3, mCameraPos);
	query->cameraMatrix = mCameraMatrix;

	return true;
}

void Gui3DView::onMouseEnter(const GuiEvent & event)
{
	Con::executef(this, "onMouseEnter");
}

void Gui3DView::onMouseLeave(const GuiEvent & event)
{
	Con::executef(this, "onMouseLeave");
}

void Gui3DView::renderWorld(const RectI &updateRect)
{
	S32 time = Platform::getVirtualMilliseconds();
	mDeltaTime = time - mLastRenderTime;
	mLastRenderTime = time;

	gClientSceneGraph->buildFogTexture(NULL);

	LightManager* lm = gClientSceneGraph->getLightManager();
	lm->setSpecialLight(LightManager::slSunLightType, mFakeSun);

	GFX->setZEnable(true);
	GFX->setZWriteEnable(true);
	GFX->setZFunc(GFXCmpLessEqual);
	GFX->setCullMode(GFXCullNone);

	on3DRender(updateRect);

	gRenderInstManager.sort();
	gRenderInstManager.render();
	gRenderInstManager.clear();
}

void Gui3DView::setOrbitDistance(F32 distance)
{
	// Make sure the orbit distance is within the acceptable range
	mOrbitDist = mClampF(distance, mMinOrbitDist, mMaxOrbitDist);
}

//-----------------------------------------------------------------------------
// Console stuff (Gui3DView)
//-----------------------------------------------------------------------------

IMPLEMENT_CONOBJECT(Gui3DView);

ConsoleMethod(Gui3DView, setOrbitDistance, void, 3, 3,
			  "(float distance)\n"
			  "Sets the distance at which the camera orbits the scene. Clamped to the acceptable range defined in the class by min and max orbit distances.\n\n"
			  "\\param distance The distance to set the orbit to (will be clamped).")
{
	argc;
	object->setOrbitDistance(dAtof(argv[2]));
}
