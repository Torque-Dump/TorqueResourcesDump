

function RPG_Editor::LoadSpecials(%this)
{
   SPC_Specials_LST.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select SpecialID, Name from Specials;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      $SpecialGUI::SpecialID=%result;
      while (!sqlite.endOfResult(%result))
      {
         %Specialname = sqlite.getColumn(%result, "Name");
         SPC_Specials_LST.addItem(%Specialname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}



function RPG_Editor::Open_PopUP_Specials(%this, %SpecialID){

   RPG_EDITOR_MAIN.setVisible(false);
   %this.displayPopupEditor("Specials");
   
   %this.loadClassTypeList("SPCEDT_Classes_LST");
   %this.loadStatusTypesList("SPCEDT_StatusBoost_LST");
   %this.loadArcanaTypesList("SPCEDT_Arcana_LST");
   %this.loadStatusEffectTypesList("SPCEDT_StatusEffect_LST");
   %this.loadTargetsTypesSelection("SPCEDT_Target_SEL");
   
   
   if(%SpecialID==0){
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=true;
      $RPG_EDITOR_POPUP_SAVE_ID=0;
      SPCEDT_Name.setText("");
      SPCEDT_POWER.setText("");
      SPCEDT_LEVEL.setText("");
      SPCEDT_COST.setText("");
      SPCEDT_SELL.setText("");
      SPCEDT_MPCOST.setText("");
      SPCEDT_CASTTIME.setText("");
      SPCEDT_CASTTURN.setText("");
      SPCEDT_ICON.setText("");
      SPCEDT_ANIMATION.setText("");
      SPCEDT_PARTICAL.setText("");
      SPCEDT_DESC.setText("");
      SPCEDT_Classes_LST.clearSelection();
      SPCEDT_StatusBoost_LST.clearSelection();
      SPCEDT_Arcana_LST.clearSelection();
      SPCEDT_StatusEffect_LST.clearSelection();
      SPCEDT_Target_SEL.setFirstSelected();
      SPCEDT_AUTO_LEARN.setStateOn(false);
   }else{
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=false;
      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      // create a new simple table for demonstration purposes
      %query = "select Name,POWER,LEVEL,COST,SELL,MPCOST,CASTTIME,CASTTURNS,ICON,ANIMATION,PARTICAL,DESC,Classes,StatusBoost,Arcana,StatusEffect,Target_SEL,AUTO_LEARN from Specials where SpecialID="@%SpecialID@";";
      
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Specials table.");
      }else{
         // attempt to retrieve result data
         $RPG_EDITOR_POPUP_SAVE_ID=%SpecialID;
      SPCEDT_Name.setText(sqlite.getColumn(%result, "Name"));
      SPCEDT_POWER.setText(sqlite.getColumn(%result, "POWER"));
      SPCEDT_LEVEL.setText(sqlite.getColumn(%result, "LEVEL"));
      SPCEDT_COST.setText(sqlite.getColumn(%result, "COST"));
      SPCEDT_SELL.setText(sqlite.getColumn(%result, "SELL"));
      SPCEDT_MPCOST.setText(sqlite.getColumn(%result, "MPCOST"));
      SPCEDT_CASTTIME.setText(sqlite.getColumn(%result, "CASTTIME"));
      SPCEDT_CASTTURN.setText(sqlite.getColumn(%result, "CASTTURNS"));
      SPCEDT_ICON.setText(sqlite.getColumn(%result, "ICON"));
      SPCEDT_ANIMATION.setText(sqlite.getColumn(%result, "ANIMATION"));
      SPCEDT_PARTICAL.setText(sqlite.getColumn(%result, "PARTICAL"));
      SPCEDT_DESC.setText(sqlite.getColumn(%result, "DESC"));
      
      
      %List=sqlite.getColumn(%result, "Classes");
         for(%i=0; %i<getWordCount(%List);%i++){
            %_id=getWord(%List,%i);
            %query = "select Name from Classes where ClassID="@%_id@";";
            %results = sqlite.query(%query, 0);  
            if(%results == 0){
               echo("Could Not Find Class ID: "@%_id);
            }else{
               SPCEDT_Classes_LST.setCurSel(SPCEDT_Classes_LST.findItemText(sqlite.getColumn(%results, "Name")));
            }
         }
      
      
      %List=sqlite.getColumn(%result, "StatusBoost");
         for(%i=0; %i<getWordCount(%List);%i++){
            %_id=getWord(%List,%i);
            %query = "select Name from StatusBoosts where StatusBoostID="@%_id@";";
            %results = sqlite.query(%query, 0);  
            if(%results == 0){
               echo("Could Not Find StatusBoost ID: "@%_id);
            }else{
               SPCEDT_StatusBoost_LST.setCurSel(SPCEDT_StatusBoost_LST.findItemText(sqlite.getColumn(%results, "Name")));
            }
         }
         
      
      
      
      %List=sqlite.getColumn(%result, "Arcana");
         for(%i=0; %i<getWordCount(%List);%i++){
            %_id=getWord(%List,%i);
            %query = "select Name from Arcana where ArcanaID="@%_id@";";
            %results = sqlite.query(%query, 0);  
            if(%results == 0){
               echo("Could Not Find Arcana ID: "@%_id);
            }else{
               SPCEDT_Arcana_LST.setCurSel(SPCEDT_Arcana_LST.findItemText(sqlite.getColumn(%results, "Name")));
            }
         }
      
      
      
      
      %List=sqlite.getColumn(%result, "StatusEffect");
         for(%i=0; %i<getWordCount(%List);%i++){
            %_id=getWord(%List,%i);
            %query = "select Name from StatusEffects where StatusEffectID="@%_id@";";
            %results = sqlite.query(%query, 0);  
            if(%results == 0){
               echo("Could Not Find StatusEffect ID: "@%_id);
            }else{
               SPCEDT_StatusEffect_LST.setCurSel(SPCEDT_StatusEffect_LST.findItemText(sqlite.getColumn(%results, "Name")));
            }
         }
      
      SPCEDT_Target_SEL.setSelected(sqlite.getColumn(%result, "Target_SEL"));
      SPCEDT_AUTO_LEARN.setStateOn(sqlite.getColumn(%result, "AUTO_LEARN"));
      }
   sqlite.closeDatabase();
   sqlite.delete();
   }

}



function RPG_Editor::LoadSelectedSpecial(%this){
   // attempt to retrieve result data
   %count=SPC_Specials_LST.getSelectedItem();

   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select SpecialID from Specials;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Specials table.");
   }else{
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      %SpecialID = sqlite.getColumn(%result, "SpecialID");
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.Open_PopUP_Specials(%SpecialID);
}
   

function RPG_Editor::NewSpecial(%this)
{
   %this.Open_PopUP_Specials(0);
}


function RPG_Editor::DeleteSpecial(%this)
{
   // attempt to retrieve result data
   %count=SPC_Specials_LST.getSelectedItem();
      
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select SpecialID from Specials;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Specials table.");
   }else{
      // attempt to retrieve result data
      $SpecialGUI::SpecialID=%result;
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         %SAVEID = sqlite.getColumn(%result, "SpecialID");
         %query = "Delete from Specials where SpecialID="@%SAVEID@";";
         %result = sqlite.query(%query, 0);
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.LoadSpecials();
}



function RPG_Editor::SaveSpecials(%this)
{

      %Name=SPCEDT_Name.getText();
      
      if((%Name $= "") == 1) return;
      %POWER=SPCEDT_POWER.getText();
      %LEVEL=SPCEDT_LEVEL.getText();
      %COST=SPCEDT_COST.getText();
      %SELL=SPCEDT_SELL.getText();
      %MPCOST=SPCEDT_MPCOST.getText();
      %CASTTIME=SPCEDT_CASTTIME.getText();
      %CASTTURNS=SPCEDT_CASTTURN.getText();
      %ICON=SPCEDT_ICON.getText();
      %ANIMATION=SPCEDT_ANIMATION.getText();
      %PARTICAL=SPCEDT_PARTICAL.getText();
      %DESC=SPCEDT_DESC.getText();
            
      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      %Count = SPCEDT_Classes_LST.getSelCount();
      %IDs = SPCEDT_Classes_LST.getSelectedItems();
      for(%i =0;%i < %Count ; %i++){
         %temp=getWord(%IDs, %i);
         %Name1=SPCEDT_Classes_LST.getItemText(%temp);
         %query = "select ClassID from Classes where Name='"@%Name1@"';";
         %result = sqlite.query(%query, 0);   
         if (%result == 0)
         {
            echo("Class Name Not Found");
         }else{
            %REALID = sqlite.getColumn(%result, "ClassID");
            if(%i==0){            
               %Classes=%REALID;
            }else{
               %Classes=%Classes@" "@%REALID;
            }
         }
      }
      
      
      
            
      %Count = SPCEDT_StatusBoost_LST.getSelCount();
      %IDs = SPCEDT_Classes_LST.getSelectedItems();
      for(%i =0;%i < %Count ; %i++){
         %temp=getWord(%IDs, %i);
         %Name2=SPCEDT_StatusBoost_LST.getItemText(%temp);
         %query = "select StatusBoostID from StatusBoosts where Name='"@%Name2@"';";
         %result = sqlite.query(%query, 0);   
         if (%result == 0)
         {
            echo("Class Name Not Found");
         }else{
            %REALID = sqlite.getColumn(%result, "StatusBoostID");
            if(%i==0){            
               %StatusBoost=%REALID;
            }else{
               %StatusBoost=%StatusBoost@" "@%REALID;
            }
         }
      }
      
     
            
      %Count = SPCEDT_Arcana_LST.getSelCount();
      %IDs = SPCEDT_Arcana_LST.getSelectedItems();
      for(%i =0;%i < %Count ; %i++){
         %temp=getWord(%IDs, %i);
         %Name3=SPCEDT_Arcana_LST.getItemText(%temp);
         %query = "select ArcanaID from Arcana where Name='"@%Name3@"';";
         %result = sqlite.query(%query, 0);   
         if (%result == 0)
         {
            echo("Class Name Not Found");
         }else{
            %REALID = sqlite.getColumn(%result, "ArcanaID");
            if(%i==0){            
               %Arcana=%REALID;
            }else{
               %Arcana=%Arcana@" "@%REALID;
            }
         }
      }
     
     
     
     
     
            
      %Count = SPCEDT_StatusEffect_LST.getSelCount();
      %IDs = SPCEDT_StatusEffect_LST.getSelectedItems();
      for(%i =0;%i < %Count ; %i++){
         %temp=getWord(%IDs, %i);
         %Name4=SPCEDT_StatusEffect_LST.getItemText(%temp);
         %query = "select StatusEffectID from StatusEffects where Name='"@%Name4@"';";
         %result = sqlite.query(%query, 0);   
         if (%result == 0)
         {
            echo("Class Name Not Found");
         }else{
            %REALID = sqlite.getColumn(%result, "StatusEffectID");
            if(%i==0){            
               %StatusEffect=%REALID;
            }else{
               %StatusEffect=%StatusEffect@" "@%REALID;
            }
         }
      }
     
           
      %Target_SEL=SPCEDT_Target_SEL.getSelected();
      %AUTO_LEARN=SPCEDT_AUTO_LEARN.isStateOn();
      
      
      // create a new simple table for demonstration purposes
      if($RPG_EDITOR_POPUP_SAVE_STATE_NEW==false){
         %SpecialID=$RPG_EDITOR_POPUP_SAVE_ID;
         %query = "Update Specials set Name='"@%Name@"',POWER='"@%POWER@"',LEVEL='"@%LEVEL@"',COST='"@%COST@"',SELL='"@%SELL@"',MPCOST='"@%MPCOST@"',CASTTIME='"@%CASTTIME@"',CASTTURNS='"@%CASTTURNS@"',ICON='"@%ICON@"',ANIMATION='"@%ANIMATION@"',PARTICAL='"@%PARTICAL@"',DESC='"@%DESC@"',Classes='"@%Classes@"',StatusBoost='"@%StatusBoost@"',Arcana='"@%Arcana@"',StatusEffect='"@%StatusEffect@"',Target_SEL='"@%Target_SEL@"',AUTO_LEARN='"@%AUTO_LEARN@"' where SpecialID="@%SpecialID@";";
      }else{                           
         %query = "Insert into Specials(Name,POWER,LEVEL,COST,SELL,MPCOST,CASTTIME,CASTTURNS,ICON,ANIMATION,PARTICAL,DESC,Classes,StatusBoost,Arcana,StatusEffect,Target_SEL,AUTO_LEARN) Values('"@%Name@"','"@%POWER@"','"@%LEVEL@"','"@%COST@"','"@%SELL@"','"@%MPCOST@"','"@%CASTTIME@"','"@%CASTTURNS@"','"@%ICON@"','"@%ANIMATION@"','"@%PARTICAL@"','"@%DESC@"','"@%Classes@"','"@%StatusBoost@"','"@%Arcana@"','"@%StatusEffect@"','"@%Target_SEL@"','"@%AUTO_LEARN@"');";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Specials table.");
      }else{   

      SPCEDT_Name.setText("");
      SPCEDT_POWER.setText("");
      SPCEDT_LEVEL.setText("");
      SPCEDT_COST.setText("");
      SPCEDT_SELL.setText("");
      SPCEDT_MPCOST.setText("");
      SPCEDT_CASTTIME.setText("");
      SPCEDT_CASTTURN.setText("");
      SPCEDT_ICON.setText("");
      SPCEDT_ANIMATION.setText("");
      SPCEDT_PARTICAL.setText("");
      SPCEDT_DESC.setText("");
      SPCEDT_Classes_LST.clearItems();
      SPCEDT_StatusBoost_LST.clearItems();
      SPCEDT_Arcana_LST.clearItems();
      SPCEDT_StatusEffect_LST.clearItems();
      SPCEDT_Target_SEL.setFirstSelected();
      SPCEDT_AUTO_LEARN.setStateOn(false);
         %this.displayMainEditor();
         %this.SetMainPanel("Specials");
         %this.LoadSpecials();
      }
   sqlite.closeDatabase();
   sqlite.delete();
}


function RPG_Editor::CancelSpecials(%this){

      SPCEDT_Name.setText("");
      SPCEDT_POWER.setText("");
      SPCEDT_LEVEL.setText("");
      SPCEDT_COST.setText("");
      SPCEDT_SELL.setText("");
      SPCEDT_MPCOST.setText("");
      SPCEDT_CASTTIME.setText("");
      SPCEDT_CASTTURN.setText("");
      SPCEDT_ICON.setText("");
      SPCEDT_ANIMATION.setText("");
      SPCEDT_PARTICAL.setText("");
      SPCEDT_DESC.setText("");
      SPCEDT_Classes_LST.clearItems();
      SPCEDT_StatusBoost_LST.clearItems();
      SPCEDT_Arcana_LST.clearItems();
      SPCEDT_StatusEffect_LST.clearItems();
      SPCEDT_Target_SEL.setFirstSelected();
      SPCEDT_AUTO_LEARN.setStateOn(false);
         %this.displayMainEditor();
         %this.SetMainPanel("Specials");
         %this.LoadSpecials();
}