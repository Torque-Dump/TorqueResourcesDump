

function RPG_Editor::LoadSummons(%this)
{
   SMN_Summons_LST2.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select SummonID, Name from Summons;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      $SummonGUI::SummonID=%result;
      while (!sqlite.endOfResult(%result))
      {
         %Summonname = sqlite.getColumn(%result, "Name");
         SMN_Summons_LST2.addItem(%Summonname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}



function RPG_Editor::Open_PopUP_Summons(%this, %SummonID){

   RPG_EDITOR_MAIN.setVisible(false);
   %this.displayPopupEditor("Summons");
   
   %this.loadGradesSelection("SMEDT_ATK_SEL");
   %this.loadGradesSelection("SMEDT_DEF_SEL");
   %this.loadGradesSelection("SMEDT_MATK_SEL");
   %this.loadGradesSelection("SMEDT_MDEF_SEL");
   %this.loadGradesSelection("SMEDT_VIT_SEL");
   %this.loadGradesSelection("SMEDT_MAG_SEL");
   %this.loadGradesSelection("SMEDT_EVA_SEL");
   %this.loadGradesSelection("SMEDT_ACC_SEL");
   %this.loadArcanaTypesSelection("SMEDT_Arcana_EHN_SEL");
   	
   if(%SummonID==0){
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=true;
      $RPG_EDITOR_POPUP_SAVE_ID=0;
      SMEDT_Name.setText("");
      SMEDT_LEVEL.setText("");
      SMEDT_SHAPE.setText("");
      SMEDT_CASTANIMATION.setText("");
      SMEDT_SPC_ANIMATION.setText("");
      SMEDT_PARTICAL.setText("");
      SMEDT_ATK.setText("");
      SMEDT_DEF.setText("");
      SMEDT_MATK.setText("");
      SMEDT_MDEF.setText("");
      SMEDT_VIT.setText("");
      SMEDT_MAG.setText("");
      SMEDT_EVA.setText("");
      SMEDT_ACC.setText("");
      SMEDT_ATK_SEL.setFirstSelected();
      SMEDT_DEF_SEL.setFirstSelected();
      SMEDT_MATK_SEL.setFirstSelected();
      SMEDT_MDEF_SEL.setFirstSelected();
      SMEDT_VIT_SEL.setFirstSelected();
      SMEDT_MAG_SEL.setFirstSelected();
      SMEDT_EVA_SEL.setFirstSelected();
      SMEDT_ACC_SEL.setFirstSelected();
      SMEDT_Arcana_EHN_SEL.setFirstSelected();
   
   }else{
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=false;
      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      // create a new simple table for demonstration purposes
      %query = "select Name,LEVEL,SHAPE,CASTANIMATION,SPC_ANIMATION,PARTICAL,ATK,DEF,MATK,MDEF,VIT,MAG,EVA,ACC,ATK_GRD,DEF_GRD,MATK_GRD,MDEF_GRD,VIT_GRD,MAG_GRD,EVA_GRD,ACC_GRD,ARCANA_ENH from Summons where SummonID="@%SummonID@";";
      
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Summons table.");
      }else{
         // attempt to retrieve result data
         $RPG_EDITOR_POPUP_SAVE_ID=%SummonID;
      SMEDT_Name.setText(sqlite.getColumn(%result, "Name"));
      SMEDT_LEVEL.setText(sqlite.getColumn(%result, "LEVEL"));
      SMEDT_SHAPE.setText(sqlite.getColumn(%result, "SHAPE"));
      SMEDT_CASTANIMATION.setText(sqlite.getColumn(%result, "CASTANIMATION"));
      SMEDT_SPC_ANIMATION.setText(sqlite.getColumn(%result, "SPC_ANIMATION"));
      SMEDT_PARTICAL.setText(sqlite.getColumn(%result, "PARTICAL"));
      SMEDT_ATK.setText(sqlite.getColumn(%result, "ATK"));
      SMEDT_DEF.setText(sqlite.getColumn(%result, "DEF"));
      SMEDT_MATK.setText(sqlite.getColumn(%result, "MATK"));
      SMEDT_MDEF.setText(sqlite.getColumn(%result, "MDEF"));
      SMEDT_VIT.setText(sqlite.getColumn(%result, "VIT"));
      SMEDT_MAG.setText(sqlite.getColumn(%result, "MAG"));
      SMEDT_EVA.setText(sqlite.getColumn(%result, "EVA"));
      SMEDT_ACC.setText(sqlite.getColumn(%result, "ACC"));
      SMEDT_ATK_SEL.setSelected(sqlite.getColumn(%result, "ATK_GRD"));
      SMEDT_DEF_SEL.setSelected(sqlite.getColumn(%result, "DEF_GRD"));
      SMEDT_MATK_SEL.setSelected(sqlite.getColumn(%result, "MATK_GRD"));
      SMEDT_MDEF_SEL.setSelected(sqlite.getColumn(%result, "MDEF_GRD"));
      SMEDT_VIT_SEL.setSelected(sqlite.getColumn(%result, "VIT_GRD"));
      SMEDT_MAG_SEL.setSelected(sqlite.getColumn(%result, "MAG_GRD"));
      SMEDT_EVA_SEL.setSelected(sqlite.getColumn(%result, "EVA_GRD"));
      SMEDT_ACC_SEL.setSelected(sqlite.getColumn(%result, "ACC_GRD"));
      SMEDT_Arcana_EHN_SEL.setSelected(sqlite.getColumn(%result, "ARCANA_ENH"));
      
         
      }
   sqlite.closeDatabase();
   sqlite.delete();
   }

}




function RPG_Editor::LoadSelectedSummon(%this){
   // attempt to retrieve result data
   %count=SMN_Summons_LST2.getSelectedItem();

   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select SummonID from Summons;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Summons table.");
   }else{
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      %SummonID = sqlite.getColumn(%result, "SummonID");
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.Open_PopUP_Summons(%SummonID);
}
 

function RPG_Editor::NewSummon(%this)
{
   %this.Open_PopUP_Summons(0);
}


function RPG_Editor::DeleteSummon(%this)
{
   // attempt to retrieve result data
   %count=SMN_Summons_LST2.getSelectedItem();
      
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select SummonID from Summons;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Summons table.");
   }else{
      // attempt to retrieve result data
      $SummonGUI::SummonID=%result;
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         %SAVEID = sqlite.getColumn(%result, "SummonID");
         %query = "Delete from Summons where SummonID="@%SAVEID@";";
         %result = sqlite.query(%query, 0);
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.LoadSummons();
}



function RPG_Editor::SaveSummons(%this)
{

      %SMEDT_Name=SMEDT_Name.getText();
      
      if((%SMEDT_Name $= "") == 1) return;
      %SMEDT_LEVEL=SMEDT_LEVEL.getText();
      %SMEDT_SHAPE=SMEDT_SHAPE.getText();
      %SMEDT_CASTANIMATION=SMEDT_CASTANIMATION.getText();
      %SMEDT_SPC_ANIMATION=SMEDT_SPC_ANIMATION.getText();
      %SMEDT_PARTICAL=SMEDT_PARTICAL.getText();
      %SMEDT_ATK=SMEDT_ATK.getText();
      %SMEDT_DEF=SMEDT_DEF.getText();
      %SMEDT_MATK=SMEDT_MATK.getText();
      %SMEDT_MDEF=SMEDT_MDEF.getText();
      %SMEDT_VIT=SMEDT_VIT.getText();
      %SMEDT_MAG=SMEDT_MAG.getText();
      %SMEDT_EVA=SMEDT_EVA.getText();
      %SMEDT_ACC=SMEDT_ACC.getText();
      %SMEDT_ATK_SEL=SMEDT_ATK_SEL.getSelected();
      %SMEDT_DEF_SEL=SMEDT_DEF_SEL.getSelected();
      %SMEDT_MATK_SEL=SMEDT_MATK_SEL.getSelected();
      %SMEDT_MDEF_SEL=SMEDT_MDEF_SEL.getSelected();
      %SMEDT_VIT_SEL=SMEDT_VIT_SEL.getSelected();
      %SMEDT_MAG_SEL=SMEDT_MAG_SEL.getSelected();
      %SMEDT_EVA_SEL=SMEDT_EVA_SEL.getSelected();
      %SMEDT_ACC_SEL=SMEDT_ACC_SEL.getSelected();
      
      %SMEDT_Arcana_EHN_SEL=SMEDT_Arcana_EHN_SEL.getSelected();
      

      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      
      // create a new simple table for demonstration purposes
      if($RPG_EDITOR_POPUP_SAVE_STATE_NEW==false){
         %SummonID=$RPG_EDITOR_POPUP_SAVE_ID;
         %query = "Update Summons set Name='"@%SMEDT_Name@"',LEVEL='"@%SMEDT_LEVEL@"',SHAPE='"@%SMEDT_SHAPE@"',CASTANIMATION='"@%SMEDT_CASTANIMATION@"',SPC_ANIMATION='"@%SMEDT_SPC_ANIMATION@"',PARTICAL='"@%SMEDT_PARTICAL@"',ATK='"@%SMEDT_ATK@"',DEF='"@%SMEDT_DEF@"',MATK='"@%SMEDT_MATK@"',MDEF='"@%SMEDT_MDEF@"',VIT='"@%SMEDT_VIT@"',MAG='"@%SMEDT_MAG@"',EVA='"@%SMEDT_EVA@"',ACC='"@%SMEDT_ACC@"',ATK_GRD='"@%SMEDT_ATK_SEL@"',DEF_GRD='"@%SMEDT_DEF_SEL@"',MATK_GRD='"@%SMEDT_MATK_SEL@"',MDEF_GRD='"@%SMEDT_MDEF_SEL@"',VIT_GRD='"@%SMEDT_VIT_SEL@"',MAG_GRD='"@%SMEDT_MAG_SEL@"',EVA_GRD='"@%SMEDT_EVA_SEL@"',ACC_GRD='"@%SMEDT_ACC_SEL@"',ARCANA_ENH='"@%SMEDT_Arcana_EHN_SEL@"' where SummonID="@%SummonID@";";
      }else{
         %query = "Insert into Summons(Name,LEVEL,SHAPE,CASTANIMATION,SPC_ANIMATION,PARTICAL,ATK,DEF,MATK,MDEF,VIT,MAG,EVA,ACC,ATK_GRD,DEF_GRD,MATK_GRD,MDEF_GRD,VIT_GRD,MAG_GRD,EVA_GRD,ACC_GRD,ARCANA_ENH) Values('"@%SMEDT_Name@"','"@%SMEDT_LEVEL@"','"@%SMEDT_SHAPE@"','"@%SMEDT_CASTANIMATION@"','"@%SMEDT_SPC_ANIMATION@"','"@%SMEDT_PARTICAL@"','"@%SMEDT_ATK@"','"@%SMEDT_DEF@"','"@%SMEDT_MATK@"','"@%SMEDT_MDEF@"','"@%SMEDT_VIT@"','"@%SMEDT_MAG@"','"@%SMEDT_EVA@"','"@%SMEDT_ACC@"','"@%SMEDT_ATK_SEL@"','"@%SMEDT_DEF_SEL@"','"@%SMEDT_ATK_SEL@"','"@%SMEDT_MDEF_SEL@"','"@%SMEDT_VIT_SEL@"','"@%SMEDT_MAG_SEL@"','"@%SMEDT_EVA_SEL@"','"@%SMEDT_ACC_SEL@"','"@%SMEDT_Arcana_EHN_SEL@"');";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Summons table.");
      }else{   
         
         SMEDT_Name.setText("");
         SMEDT_LEVEL.setText("");
         SMEDT_SHAPE.setText("");
         SMEDT_CASTANIMATION.setText("");
         SMEDT_SPC_ANIMATION.setText("");
         SMEDT_PARTICAL.setText("");
         SMEDT_ATK.setText("");
         SMEDT_DEF.setText("");
         SMEDT_MATK.setText("");
         SMEDT_MDEF.setText("");
         SMEDT_VIT.setText("");
         SMEDT_MAG.setText("");
         SMEDT_EVA.setText("");
         SMEDT_ACC.setText("");
         SMEDT_ATK_SEL.setFirstSelected();
         SMEDT_DEF_SEL.setFirstSelected();
         SMEDT_MATK_SEL.setFirstSelected();
         SMEDT_MDEF_SEL.setFirstSelected();
         SMEDT_VIT_SEL.setFirstSelected();
         SMEDT_MAG_SEL.setFirstSelected();
         SMEDT_EVA_SEL.setFirstSelected();
         SMEDT_ACC_SEL.setFirstSelected();
         SMEDT_Arcana_EHN_SEL.setFirstSelected();
         %this.displayMainEditor();
         %this.SetMainPanel("Summons");
         %this.LoadSummons();
      }
   sqlite.closeDatabase();
   sqlite.delete();
}



function RPG_Editor::CancelSummons(%this){
         SMEDT_Name.setText("");
         SMEDT_LEVEL.setText("");
         SMEDT_SHAPE.setText("");
         SMEDT_CASTANIMATION.setText("");
         SMEDT_SPC_ANIMATION.setText("");
         SMEDT_PARTICAL.setText("");
         SMEDT_ATK.setText("");
         SMEDT_DEF.setText("");
         SMEDT_MATK.setText("");
         SMEDT_MDEF.setText("");
         SMEDT_VIT.setText("");
         SMEDT_MAG.setText("");
         SMEDT_EVA.setText("");
         SMEDT_ACC.setText("");
         SMEDT_ATK_SEL.setFirstSelected();
         SMEDT_DEF_SEL.setFirstSelected();
         SMEDT_MATK_SEL.setFirstSelected();
         SMEDT_MDEF_SEL.setFirstSelected();
         SMEDT_VIT_SEL.setFirstSelected();
         SMEDT_MAG_SEL.setFirstSelected();
         SMEDT_EVA_SEL.setFirstSelected();
         SMEDT_ACC_SEL.setFirstSelected();
         SMEDT_Arcana_EHN_SEL.setFirstSelected();
         %this.displayMainEditor();
         %this.SetMainPanel("Summons");
         %this.LoadSummons();
}


function RPG_Editor::UpdateSummonCalc(%this){

   %level=SMEDT_LEVEL.getText();
   %atk=HEDT_ATK.getText();
   %def=HEDT_DEF.getText();
   %matk=HEDT_MATK.getText();
   %mdef=HEDT_MDEF.getText();
   %vit=HEDT_VIT.getText();
   %mag=HEDT_MAG.getText();
   %eva=HEDT_EVA.getText();
   %acc=HEDT_ACC.getText();
   
   %_ATK=SMEDT_ATK_SEL.getSelected();
   %_DEF=SMEDT_DEF_SEL.getSelected();
   %_MATK=SMEDT_MATK_SEL.getSelected();
   %_MDEF=SMEDT_MDEF_SEL.getSelected();
   %_VIT=SMEDT_VIT_SEL.getSelected();
   %_MAG=SMEDT_MAG_SEL.getSelected();
   %_EVA=SMEDT_EVA_SEL.getSelected();
   %_ACC=SMEDT_ACC_SEL.getSelected();

   %Attack=mFloor((((%_ATK+%atk)*(%level))/1000)*999);
   %Defense=mFloor((((%_DEF+%def)*(%level))/1000)*999);
   %MagicAttack=mFloor((((%_MATK+%matk)*(%level))/1000)*999);
   %MagicDefense=mFloor((((%_MDEF+%mdef)*(%level))/1000)*999);
   %Vitality=mFloor((((%_VIT+%vit)*(%level))/1000)*999);
   %Magic=mFloor((((%_MAG+%mag)*(%level))/1000)*999);
   %Evasion=mFloor((((%_EVA+%eva)*(%level))/1000)*999);
   %Accuracy=mFloor((((%_ACC+%acc)*(%level))/1000)*999);
                      
   %MaxHP=%Vitality*12;
   %MaxMP=%Magic*12;
   %MaxKP=%level*12;
      
   SMEDT_HP_CAL.setText(%MaxHP);
   SMEDT_MP_CAL.setText(%MaxMP);
   SMEDT_TP_CAL.setText(%MaxKP);
   SMEDT_ATK_CAL.setText(%Attack);
   SMEDT_DEF_CAL.setText(%Defense);
   SMEDT_MATK_CAL.setText(%MagicAttack);
   SMEDT_MDEF_CAL.setText(%MagicDefense);
   SMEDT_VIT_CAL.setText(%Vitality);
   SMEDT_MAG_CAL.setText(%Magic);
   SMEDT_EVA_CAL.setText(%Evasion);
   SMEDT_ACC_CAL.setText(%Accuracy);
      
}
