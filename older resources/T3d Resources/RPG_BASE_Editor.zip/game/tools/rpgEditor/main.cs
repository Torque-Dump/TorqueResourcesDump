//-----------------------------------------------------------------------------
// Copyright (C) Sickhead Games, LLC
//-----------------------------------------------------------------------------
/*
function initializeRPGEditor()
{
   echo(" % - Initializing RPG Editor");
   
   exec( "./init.cs" );
   
   // Add ourselves to EditorGui, where all the other tools reside
   RPG_Editor.setVisible( false ); 
   
   EditorGui.add( RPG_Editor );

   new ScriptObject( RPGEditorPlugin )
   {
      superClass = "RPGPlugin";
   };
}
function loadRPGEditorInterface()
{
   EditorGui.bringToFront( RPG_Editor );
   
   RPG_Editor.setVisible( true );
   
   EditorGuiStatusBar.setInfo("RPG Editor.");
   EditorGuiStatusBar.setSelection("");
   %this.loadPrefs();
}

function RPGEditorPlugin::onWorldEditorStartup( %this )
{      
   // Add ourselves to the window menu.
   %accel = EditorGui.addToEditorsMenu( "RPG Editor", "", RPGEditorPlugin );   
   
   // Add ourselves to the ToolsToolbar
   %tooltip = "RPG Editor (" @ %accel @ ")";   
   
   %button = new GuiBitmapButtonCtrl() {
      canSaveDynamicFields = "0";
      internalName = "FilterEditorPalette";
      Enabled = "1";
      isContainer = "0";
      Profile = "GuiButtonProfile";
      HorizSizing = "right";
      VertSizing = "bottom";
      position = "180 0";
      Extent = "25 19";
      MinExtent = "8 2";
      canSave = "1";
      Visible = "1";
      Command = "loadRPGEditorInterface();";
      tooltipprofile = "GuiToolTipProfile";
      ToolTip = %tooltip;
      hovertime = "750";
      bitmap = "tools/rpgEditor/Icon";
      buttonType = "PushButton";
      groupNum = "0";
      useMouseEvents = "0";
   };
   ToolsToolbarArray.add(%button);
   //connect editor windows   
   //AttachWindows( DecalEditorWindow, DecalPreviewWindow );
   
   //set initial palette setting
   //%this.paletteSelection = "AddDecalMode";
}

function RPGEditorPlugin::onActivated( %this )
{
   EditorGui.bringToFront( RPG_Editor );
   
   RPG_Editor.setVisible( true );
   
   EditorGuiStatusBar.setInfo("RPG Editor.");
   EditorGuiStatusBar.setSelection("");
   %this.loadPrefs();
   Parent::onActivated(%this);
}
function RPGEditorPlugin::onDeactivated( %this )
{
   RPG_Editor.setVisible( false );   
   Parent::onDeactivated(%this);
}*/
//-----------------------------------------------------------------------------
// Copyright (C) Sickhead Games, LLC
//-----------------------------------------------------------------------------

function initializeRPGEditor()
{
   echo(" % - Initializing Mesh Road Editor");
     
   exec( "./init.cs" );
   
   RPG_Editor.setVisible( false );  
   
   EditorGui.add( RPG_Editor );
   
   new ScriptObject( RPGEditorPlugin )
   {
      superClass = "EditorPlugin";
      editorGui = RPG_Editor;
   };
   /*
   %map = new ActionMap();
   %map.bindCmd( keyboard, "backspace", "RPG_Editor.deleteNode();", "" );
   %map.bindCmd( keyboard, "1", "RPG_Editor.prepSelectionMode();", "" );  
   %map.bindCmd( keyboard, "2", "ToolsPaletteArray->RPGEditorMoveMode.performClick();", "" );  
   %map.bindCmd( keyboard, "3", "ToolsPaletteArray->RPGEditorRotateMode.performClick();", "" );  
   %map.bindCmd( keyboard, "4", "ToolsPaletteArray->RPGEditorScaleMode.performClick();", "" );  
   %map.bindCmd( keyboard, "5", "ToolsPaletteArray->RPGEditorAddRoadMode.performClick();", "" );  
   %map.bindCmd( keyboard, "-", "ToolsPaletteArray->RPGEditorInsertPointMode.performClick();", "" );  
   %map.bindCmd( keyboard, "=", "ToolsPaletteArray->RPGEditorRemovePointMode.performClick();", "" );  
   %map.bindCmd( keyboard, "z", "RPGEditorShowSplineBtn.performClick();", "" );  
   %map.bindCmd( keyboard, "x", "RPGEditorWireframeBtn.performClick();", "" );  
   %map.bindCmd( keyboard, "c", "RPGEditorShowRoadBtn.performClick();", "" );  
   RPGEditorPlugin.map = %map;
   */
   RPGEditorPlugin.initSettings();
}

function destroyRPGEditor()
{
}

function RPGEditorPlugin::onWorldEditorStartup( %this )
{     
   // Add ourselves to the window menu.
   %accel = EditorGui.addToEditorsMenu( "RPG Editor", "", RPGEditorPlugin );
   
   // Add ourselves to the ToolsToolbar
   %tooltip = "RPG Editor (" @ %accel @ ")";   
   EditorGui.addToToolsToolbar( "RPGEditorPlugin", "RPGEditorPalette", expandFilename("tools/rpgEditor/Icon"), %tooltip );

   //connect editor windows
   //GuiWindowCtrl::attach( RPGEditorOptionsWindow, RPGEditorTreeWindow);
   
   // Add ourselves to the Editor Settings window
   //exec( "./RPGEditorSettingsTab.gui" );
   //ESettingsWindow.addTabPage( ERPGEditorSettingsPage );
}

function RPGEditorPlugin::onActivated( %this )
{
  // %this.readSettings();
   
   ToolsPaletteArray->RPGEditorAddRoadMode.performClick();
   EditorGui.bringToFront( RPG_Editor );
   RPG_Editor.setVisible( true );
   RPG_Editor.makeFirstResponder( true );
  // RPGEditorOptionsWindow.setVisible( true );
  // RPGEditorToolbar.setVisible( true );  
  // RPGEditorTreeWindow.setVisible( true );
 //  RPGTreeView.open(ServerRPGSet,true);
 //  %this.map.push();
   
   // Store this on a dynamic field
   // in order to restore whatever setting
   // the user had before.
   %this.prevGizmoAlignment = GlobalGizmoProfile.alignment;
   
   // The DecalEditor always uses Object alignment.
   GlobalGizmoProfile.alignment = "Object";
   
   // Set the status bar here until all tool have been hooked up
   EditorGuiStatusBar.setInfo("RPG editor.");
   EditorGuiStatusBar.setSelection("");
   
   Parent::onActivated(%this);
}

function RPGEditorPlugin::onDeactivated( %this )
{   
   //%this.writeSettings();
   
   RPG_Editor.setVisible( false );
  // RPGEditorOptionsWindow.setVisible( false );
   //RPGEditorToolbar.setVisible( false );  
 //  RPGEditorTreeWindow.setVisible( false );
 //  %this.map.pop();
   
   // Restore the previous Gizmo
   // alignment settings.
   GlobalGizmoProfile.alignment = %this.prevGizmoAlignment; 
   
   Parent::onDeactivated(%this);  
}

function RPGEditorPlugin::onEditMenuSelect( %this, %editMenu )
{
/*   %hasSelection = false;
   
   if( isObject( RPG_Editor.road ) )
      %hasSelection = true;
      
   %editMenu.enableItem( 3, false ); // Cut
   %editMenu.enableItem( 4, false ); // Copy
   %editMenu.enableItem( 5, false ); // Paste  
   %editMenu.enableItem( 6, %hasSelection ); // Delete
   %editMenu.enableItem( 8, false ); // Deselect   */
}

function RPGEditorPlugin::handleDelete( %this )
{
   RPG_Editor.deleteNode();
}

function RPGEditorPlugin::handleEscape( %this )
{
   return RPG_Editor.onEscapePressed();  
}

function RPGEditorPlugin::isDirty( %this )
{
   return RPG_Editor.isDirty;
}

function RPGEditorPlugin::onSaveMission( %this, %missionFile )
{
   if( RPG_Editor.isDirty )
   {
      MissionGroup.save( %missionFile );
      RPG_Editor.isDirty = false;
   }
}

//-----------------------------------------------------------------------------
// Settings
//-----------------------------------------------------------------------------

function RPGEditorPlugin::initSettings( %this )
{
  /* EditorSettings.beginGroup( "RPGEditor", true );
   
   EditorSettings.setDefaultValue(  "DefaultWidth",         "10" );
   EditorSettings.setDefaultValue(  "DefaultDepth",         "5" );
   EditorSettings.setDefaultValue(  "DefaultNormal",        "0 0 1" );
   EditorSettings.setDefaultValue(  "HoverSplineColor",     "255 0 0 255" );
   EditorSettings.setDefaultValue(  "SelectedSplineColor",  "0 255 0 255" );
   EditorSettings.setDefaultValue(  "HoverNodeColor",       "255 255 255 255" ); //<-- Not currently used
   
   EditorSettings.endGroup();*/
}

function RPGEditorPlugin::readSettings( %this )
{
  /* EditorSettings.beginGroup( "RPGEditor", true );
   
   RPG_Editor.DefaultWidth         = EditorSettings.value("DefaultWidth");
   RPG_Editor.DefaultDepth         = EditorSettings.value("DefaultDepth");
   RPG_Editor.DefaultNormal        = EditorSettings.value("DefaultNormal");
   RPG_Editor.HoverSplineColor     = EditorSettings.value("HoverSplineColor");
   RPG_Editor.SelectedSplineColor  = EditorSettings.value("SelectedSplineColor");
   RPG_Editor.HoverNodeColor       = EditorSettings.value("HoverNodeColor");
   
   EditorSettings.endGroup();  */
}

function RPGEditorPlugin::writeSettings( %this )
{
 /*  EditorSettings.beginGroup( "RPGEditor", true );
   
   EditorSettings.setValue( "DefaultWidth",           RPG_Editor.DefaultWidth );
   EditorSettings.setValue( "DefaultDepth",           RPG_Editor.DefaultDepth );
   EditorSettings.setValue( "DefaultNormal",          RPG_Editor.DefaultNormal );
   EditorSettings.setValue( "HoverSplineColor",       RPG_Editor.HoverSplineColor );
   EditorSettings.setValue( "SelectedSplineColor",    RPG_Editor.SelectedSplineColor );
   EditorSettings.setValue( "HoverNodeColor",         RPG_Editor.HoverNodeColor );

   EditorSettings.endGroup();*/
}
