$RPG_EDITOR_PREV_PANEL = "";
$RPG_EDITOR_POPUP = "";
$RPG_EDITOR_POPUP_SAVE_STATE_NEW = 0;
$RPG_EDITOR_POPUP_SAVE_ID = 0;
/*
singleton GuiControlProfile( EPGEditorProfile )
{
   canKeyFocus = true;
   opaque = true;
   fillColor = "192 192 192 192";
   category = "Editor";
};

singleton GuiControlProfile (GuiSimpleBorderProfile)
{
   opaque = false;   
   border = 1;   
   category = "Editor";
};
 */
function RPG_Editor::onAdd(%this)
{

}

/// Callback when the control wakes up.
function RPG_Editor::onWake(%this)
{

}


function RPG_Editor::loadPrefs(%this)
{
   RPG_EDITOR_MAIN.setVisible(true);
   %this.SetMainPanel("Events");
}

function RPG_Editor::switchTabs(%this, %tab)
{

}

function RPG_Editor::SetMainPanel(%this, %switchPanel){

 if(($RPG_EDITOR_PREV_PANEL $= "") == 0){
   ("RPG_" @ $RPG_EDITOR_PREV_PANEL @ "_PLT").setVisible(false);
 }
 
 if((%switchPanel $= "") == 0){
    $RPG_EDITOR_PREV_PANEL=%switchPanel;
   ("RPG_" @ %switchPanel @ "_PLT").setVisible(true);
   %this.LoadMainList(%switchPanel);
 }else{
    echo("SetMainPanel requires a string pased for the panel name.");
 }
}


function RPG_Editor::LoadMainList(%this, %loadList){

 if((%loadList $= "") == 0){
    switch$(%loadList){
      case "Classes":
         %this.LoadClasses();
      case "Items":
         %this.LoadItems();
      case "Armors":
         %this.LoadArmors();
      case "Heros":
         %this.LoadPlayers();
      case "Monsters":
         %this.LoadMonsters();
      case "Weapons":
         %this.LoadWeapons();
      case "MGroups":
         %this.LoadMGroups();
      case "Specials":
         %this.LoadSpecials();
      case "Spells":
         %this.LoadSpells();
      case "Summons":
         %this.LoadSummons();
      case "Maps":
         %this.LoadMaps();
    }
   //("RPG_" @ %switchPanel @ "_PLT").setVisible(true);
 }else{
    echo("SetMainPanel requires a string pased for the panel name.");
 }
}


function RPG_Editor::displayPopupEditor(%this, %editorName){
 if((%editorName $= "") == 0){
    $RPG_EDITOR_POPUP=%editorName;
   ("RPG_" @ %editorName @ "_EDT").setVisible(true);
 }else{
    echo("displayPopupEditor requires a string pased for the panel name.");
 }
}

function RPG_Editor::loadGradesSelection(%this, %selObject){
   (%selObject).clear();
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select GradeLetter, GradeMod from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "GradeLetter");
         %classmod =  sqlite.getColumn(%result, "GradeMod");
         (%selObject).add(%classname,%classmod);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   
}


function RPG_Editor::loadItemTypesSelection(%this, %selObject){
   (%selObject).clear();
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name from ItemTypes;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %typename = sqlite.getColumn(%result, "Name");
         (%selObject).add(%typename);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   
}



function RPG_Editor::loadArcanaTypesSelection(%this, %selObject){
   (%selObject).clear();
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name from Arcana;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %typename = sqlite.getColumn(%result, "Name");
         (%selObject).add(%typename);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   
}



function RPG_Editor::loadStatusTypesSelection(%this, %selObject){
   (%selObject).clear();
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name from StatusEffects;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %typename = sqlite.getColumn(%result, "Name");
         (%selObject).add(%typename);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   
}


function RPG_Editor::loadBoostTypesSelection(%this, %selObject){
   (%selObject).clear();
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name from StatusBoosts;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %typename = sqlite.getColumn(%result, "Name");
         (%selObject).add(%typename);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   
}

function RPG_Editor::loadTargetsTypesSelection(%this, %selObject){
   (%selObject).clear();
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name, TargetID from Targets;";
   %result = sqlite.query(%query, 0);   
   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         %id = sqlite.getColumn(%result, "TargetID");
         (%selObject).add(%name,%id);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   
}




function RPG_Editor::loadSpellSelection(%this, %selObject){
   (%selObject).clear();
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name, SpellID from Spells;";
   %result = sqlite.query(%query, 0);   
   
   (%selObject).add("NONE",0);
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         %id = sqlite.getColumn(%result, "SpellID");
         (%selObject).add(%name,%id);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   
}


function RPG_Editor::loadSpecialsSelection(%this, %selObject){
   (%selObject).clear();
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name, SpecialID from Specials;";
   %result = sqlite.query(%query, 0);   
   
   (%selObject).add("NONE",0);
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         %id = sqlite.getColumn(%result, "SpecialID");
         (%selObject).add(%name,%id);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   
}
function RPG_Editor::loadSummonSelection(%this, %selObject){
   (%selObject).clear();
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name, SummonID from Summons;";
   %result = sqlite.query(%query, 0);   
   
   (%selObject).add("NONE",0);
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         %id = sqlite.getColumn(%result, "SummonID");
         (%selObject).add(%name,%id);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   
}


function RPG_Editor::loadArmorTypesSelection(%this, %selObject){
   (%selObject).clear();
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name, ArmorTypeID from ArmorTypes;";
   %result = sqlite.query(%query, 0);   
   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         %id = sqlite.getColumn(%result, "ArmorTypeID");
         (%selObject).add(%name,%id);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   
}

function RPG_Editor::loadClassTypeList(%this, %selObject){
   (%selObject).clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name from Classes;";
   %result = sqlite.query(%query, 0);
   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         (%selObject).addItem(%name);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   
}


function RPG_Editor::loadClassTypesSelection(%this, %listObject){
   (%listObject).clear();
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name, ClassID from Classes;";
   %result = sqlite.query(%query, 0);   
   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         %id = sqlite.getColumn(%result, "ClassID");
         (%listObject).add(%name,%id);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   
}


function RPG_Editor::loadSpecialsList(%this, %listObject){
         (%listObject).clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name from Specials;";
   %result = sqlite.query(%query, 0);
   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         (%listObject).addItem(%name);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}


function RPG_Editor::loadAITaticsSelection(%this, %selObject){

   (%selObject).clear();
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name, AITaticsID from AITatics;";
   %result = sqlite.query(%query, 0);   
   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         %id = sqlite.getColumn(%result, "AITaticsID");
         (%selObject).add(%name,%id);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}
function RPG_Editor::loadItemList(%this, %listObject){
          (%listObject).clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name from Items;";
   %result = sqlite.query(%query, 0);
   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         (%listObject).addItem(%name);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}
function RPG_Editor::loadSpellList(%this, %listObject){
          (%listObject).clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name from Spells;";
   %result = sqlite.query(%query, 0);
   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         (%listObject).addItem(%name);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}
function RPG_Editor::loadAISpecialActivationSelection(%this, %selObject){

   (%selObject).clear();
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name, AISpecialActivationID from AISpecialActivation;";
   %result = sqlite.query(%query, 0);   
   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         %id = sqlite.getColumn(%result, "AISpecialActivationID");
         (%selObject).add(%name,%id);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}
   	
	

function RPG_Editor::loadStatusTypesList(%this, %listObject){
          (%listObject).clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name from StatusBoosts;";
   %result = sqlite.query(%query, 0);
   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         (%listObject).addItem(%name);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}	
	
		

function RPG_Editor::loadStatusEffectTypesList(%this, %listObject){
          (%listObject).clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name from StatusEffects;";
   %result = sqlite.query(%query, 0);
   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         (%listObject).addItem(%name);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}	
	
	
	

function RPG_Editor::loadArcanaTypesList(%this, %listObject){
          (%listObject).clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name from Arcana;";
   %result = sqlite.query(%query, 0);
   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         (%listObject).addItem(%name);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}	
	
		
function RPG_Editor::loadMAPSelection(%this, %selObject){

   (%selObject).clear();
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name, MapID from Maps;";
   %result = sqlite.query(%query, 0);   
   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         %id = sqlite.getColumn(%result, "MapID");
         (%selObject).add(%name,%id);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}
   	
	

	

function RPG_Editor::loadMonsterList(%this, %listObject){
          (%listObject).clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name from Monsters;";
   %result = sqlite.query(%query, 0);
   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         (%listObject).addItem(%name);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}	
	
		
function RPG_Editor::loadWeaponTypesSelection(%this, %selObject){

   (%selObject).clear();
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }

   // create a new simple table for demonstration purposes
   %query = "select Name, WeaponTypeID from WeaponTypes;";
   %result = sqlite.query(%query, 0);   
   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         %id = sqlite.getColumn(%result, "MapID");
         (%selObject).add(%name,%id);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}
   	
		
	
	
	