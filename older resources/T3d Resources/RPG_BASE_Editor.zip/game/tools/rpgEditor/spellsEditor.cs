

function RPG_Editor::LoadSpells(%this)
{
   SPL_Spells_LST.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select SpellID, Name from Spells;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      $SpellGUI::SpellID=%result;
      while (!sqlite.endOfResult(%result))
      {
         %Spellname = sqlite.getColumn(%result, "Name");
         SPL_Spells_LST.addItem(%Spellname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}



function RPG_Editor::Open_PopUP_Spells(%this, %SpellID){

   RPG_EDITOR_MAIN.setVisible(false);
   %this.displayPopupEditor("Spells");
   
   %this.loadClassTypeList("SPLEDT_Classes_LST");
   %this.loadStatusTypesList("SPLEDT_StatusBoost_LST");
   %this.loadArcanaTypesList("SPLEDT_Arcana_LST");
   %this.loadStatusEffectTypesList("SPLEDT_StatusEffect_LST");
   %this.loadTargetsTypesSelection("SPLEDT_Target_SEL");
   
   
   if(%SpellID==0){
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=true;
      $RPG_EDITOR_POPUP_SAVE_ID=0;
      SPLEDT_Name.setText("");
      SPLEDT_POWER.setText("");
      SPLEDT_LEVEL.setText("");
      SPLEDT_COST.setText("");
      SPLEDT_SELL.setText("");
      SPLEDT_MPCOST.setText("");
      SPLEDT_CASTTIME.setText("");
      SPLEDT_CASTTURNS.setText("");
      SPLEDT_ICON.setText("");
      SPLEDT_ANIMATION.setText("");
      SPLEDT_PARTICAL.setText("");
      SPLEDT_DESC.setText("");
      SPLEDT_Classes_LST.clearSelection();
      SPLEDT_StatusBoost_LST.clearSelection();
      SPLEDT_Arcana_LST.clearSelection();
      SPLEDT_StatusEffect_LST.clearSelection();
      SPLEDT_Target_SEL.setFirstSelected();
      SPLEDT_AUTO_LEARN.setStateOn(false);
   }else{
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=false;
      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      // create a new simple table for demonstration purposes
      %query = "select Name,POWER,LEVEL,COST,SELL,MPCOST,CASTTIME,CASTTURNS,ICON,ANIMATION,PARTICAL,DESC,Classes,StatusBoost,Arcana,StatusEffect,Target,AUTO_LEARN from Spells where SpellID="@%SpellID@";";
      
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Spells table.");
      }else{
         // attempt to retrieve result data
         $RPG_EDITOR_POPUP_SAVE_ID=%SpellID;
      SPLEDT_Name.setText(sqlite.getColumn(%result, "Name"));
      SPLEDT_POWER.setText(sqlite.getColumn(%result, "POWER"));
      SPLEDT_LEVEL.setText(sqlite.getColumn(%result, "LEVEL"));
      SPLEDT_COST.setText(sqlite.getColumn(%result, "COST"));
      SPLEDT_SELL.setText(sqlite.getColumn(%result, "SELL"));
      SPLEDT_MPCOST.setText(sqlite.getColumn(%result, "MPCOST"));
      SPLEDT_CASTTIME.setText(sqlite.getColumn(%result, "CASTTIME"));
      SPLEDT_CASTTURNS.setText(sqlite.getColumn(%result, "CASTTURNS"));
      SPLEDT_ICON.setText(sqlite.getColumn(%result, "ICON"));
      SPLEDT_ANIMATION.setText(sqlite.getColumn(%result, "ANIMATION"));
      SPLEDT_PARTICAL.setText(sqlite.getColumn(%result, "PARTICAL"));
      SPLEDT_DESC.setText(sqlite.getColumn(%result, "DESC"));
      
      
      %List=sqlite.getColumn(%result, "Classes");
         for(%i=0; %i<getWordCount(%List);%i++){
            %_id=getWord(%List,%i);
            %query = "select Name from Classes where ClassID="@%_id@";";
            %results = sqlite.query(%query, 0);  
            if(%results == 0){
               echo("Could Not Find Class ID: "@%_id);
            }else{
               SPLEDT_Classes_LST.setCurSel(SPLEDT_Classes_LST.findItemText(sqlite.getColumn(%results, "Name")));
            }
         }
      
      
      %List=sqlite.getColumn(%result, "StatusBoost");
         for(%i=0; %i<getWordCount(%List);%i++){
            %_id=getWord(%List,%i);
            %query = "select Name from StatusBoosts where StatusBoostID="@%_id@";";
            %results = sqlite.query(%query, 0);  
            if(%results == 0){
               echo("Could Not Find StatusBoost ID: "@%_id);
            }else{
               SPLEDT_StatusBoost_LST.setCurSel(SPLEDT_StatusBoost_LST.findItemText(sqlite.getColumn(%results, "Name")));
            }
         }
         
      
      
      
      %List=sqlite.getColumn(%result, "Arcana");
         for(%i=0; %i<getWordCount(%List);%i++){
            %_id=getWord(%List,%i);
            %query = "select Name from Arcana where ArcanaID="@%_id@";";
            %results = sqlite.query(%query, 0);  
            if(%results == 0){
               echo("Could Not Find Arcana ID: "@%_id);
            }else{
               SPLEDT_Arcana_LST.setCurSel(SPLEDT_Arcana_LST.findItemText(sqlite.getColumn(%results, "Name")));
            }
         }
      
      
      
      
      %List=sqlite.getColumn(%result, "StatusEffect");
         for(%i=0; %i<getWordCount(%List);%i++){
            %_id=getWord(%List,%i);
            %query = "select Name from StatusEffects where StatusEffectID="@%_id@";";
            %results = sqlite.query(%query, 0);  
            if(%results == 0){
               echo("Could Not Find StatusEffect ID: "@%_id);
            }else{
               SPLEDT_StatusEffect_LST.setCurSel(SPLEDT_StatusEffect_LST.findItemText(sqlite.getColumn(%results, "Name")));
            }
         }
      
      SPLEDT_Target_SEL.setSelected(sqlite.getColumn(%result, "Target"));
      SPLEDT_AUTO_LEARN.setStateOn(sqlite.getColumn(%result, "AUTO_LEARN"));
      }
   sqlite.closeDatabase();
   sqlite.delete();
   }

}



function RPG_Editor::LoadSelectedSpell(%this){
   // attempt to retrieve result data
   %count=SPL_Spells_LST.getSelectedItem();

   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select SpellID from Spells;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Spells table.");
   }else{
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      %SpellID = sqlite.getColumn(%result, "SpellID");
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.Open_PopUP_Spells(%SpellID);
}
   

function RPG_Editor::NewSpell(%this)
{
   %this.Open_PopUP_Spells(0);
}


function RPG_Editor::DeleteSpell(%this)
{
   // attempt to retrieve result data
   %count=SPL_Spells_LST.getSelectedItem();
      
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select SpellID from Spells;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Spells table.");
   }else{
      // attempt to retrieve result data
      $SpellGUI::SpellID=%result;
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         %SAVEID = sqlite.getColumn(%result, "SpellID");
         %query = "Delete from Spells where SpellID="@%SAVEID@";";
         %result = sqlite.query(%query, 0);
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.LoadSpells();
}



function RPG_Editor::SaveSpells(%this)
{

      %SPLEDT_Name=SPLEDT_Name.getText();
      
      if((%SPLEDT_Name $= "") == 1) return;
      %POWER=SPLEDT_POWER.getText();
      %LEVEL=SPLEDT_LEVEL.getText();
      %COST=SPLEDT_COST.getText();
      %SELL=SPLEDT_SELL.getText();
      %MPCOST=SPLEDT_MPCOST.getText();
      %CASTTIME=SPLEDT_CASTTIME.getText();
      %CASTTURNS=SPLEDT_CASTTURNS.getText();
      %ICON=SPLEDT_ICON.getText();
      %ANIMATION=SPLEDT_ANIMATION.getText();
      %PARTICAL=SPLEDT_PARTICAL.getText();
      %DESC=SPLEDT_DESC.getText();
            
      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      %Count = SPLEDT_Classes_LST.getSelCount();
      %IDs = SPLEDT_Classes_LST.getSelectedItems();
      for(%i =0;%i < %Count ; %i++){
         %temp=getWord(%IDs, %i);
         %Name1=SPLEDT_Classes_LST.getItemText(%temp);
         %query = "select ClassID from Classes where Name='"@%Name1@"';";
         %result = sqlite.query(%query, 0);   
         if (%result == 0)
         {
            echo("Class Name Not Found");
         }else{
            %REALID = sqlite.getColumn(%result, "ClassID");
            if(%i==0){            
               %Classes=%REALID;
            }else{
               %Classes=%Classes@" "@%REALID;
            }
         }
      }
      
      
      
            
      %Count = SPLEDT_StatusBoost_LST.getSelCount();
      %IDs = SPLEDT_Classes_LST.getSelectedItems();
      for(%i =0;%i < %Count ; %i++){
         %temp=getWord(%IDs, %i);
         %Name2=SPLEDT_StatusBoost_LST.getItemText(%temp);
         %query = "select StatusBoostID from StatusBoosts where Name='"@%Name2@"';";
         %result = sqlite.query(%query, 0);   
         if (%result == 0)
         {
            echo("Class Name Not Found");
         }else{
            %REALID = sqlite.getColumn(%result, "StatusBoostID");
            if(%i==0){            
               %StatusBoost=%REALID;
            }else{
               %StatusBoost=%StatusBoost@" "@%REALID;
            }
         }
      }
      
     
            
      %Count = SPLEDT_Arcana_LST.getSelCount();
      %IDs = SPLEDT_Arcana_LST.getSelectedItems();
      for(%i =0;%i < %Count ; %i++){
         %temp=getWord(%IDs, %i);
         %Name3=SPLEDT_Arcana_LST.getItemText(%temp);
         %query = "select ArcanaID from Arcana where Name='"@%Name3@"';";
         %result = sqlite.query(%query, 0);   
         if (%result == 0)
         {
            echo("Class Name Not Found");
         }else{
            %REALID = sqlite.getColumn(%result, "ArcanaID");
            if(%i==0){            
               %Arcana=%REALID;
            }else{
               %Arcana=%Arcana@" "@%REALID;
            }
         }
      }
     
     
     
     
     
            
      %Count = SPLEDT_StatusEffect_LST.getSelCount();
      %IDs = SPLEDT_StatusEffect_LST.getSelectedItems();
      for(%i =0;%i < %Count ; %i++){
         %temp=getWord(%IDs, %i);
         %Name4=SPLEDT_StatusEffect_LST.getItemText(%temp);
         %query = "select StatusEffectID from StatusEffects where Name='"@%Name4@"';";
         %result = sqlite.query(%query, 0);   
         if (%result == 0)
         {
            echo("Class Name Not Found");
         }else{
            %REALID = sqlite.getColumn(%result, "StatusEffectID");
            if(%i==0){            
               %StatusEffect=%REALID;
            }else{
               %StatusEffect=%StatusEffect@" "@%REALID;
            }
         }
      }
     
           
      %Target_SEL=SPLEDT_Target_SEL.getSelected();
      %AUTO_LEARN=SPLEDT_AUTO_LEARN.isStateOn();
      
      // create a new simple table for demonstration purposes
      if($RPG_EDITOR_POPUP_SAVE_STATE_NEW==false){
         %SpellID=$RPG_EDITOR_POPUP_SAVE_ID;
         %query = "Update Spells set Name='"@%SPLEDT_Name@"',POWER='"@%POWER@"',LEVEL='"@%LEVEL@"',COST='"@%COST@"',SELL='"@%SELL@"',MPCOST='"@%MPCOST@"',CASTTIME='"@%CASTTIME@"',CASTTURNS='"@%CASTTURNS@"',ICON='"@%ICON@"',ANIMATION='"@%ANIMATION@"',PARTICAL='"@%PARTICAL@"',DESC='"@%DESC@"',Classes='"@%Classes@"',StatusBoost='"@%StatusBoost@"',Arcana='"@%Arcana@"',StatusEffect='"@%StatusEffect@"',Target='"@%Target_SEL@"',AUTO_LEARN='"@%AUTO_LEARN@"' where SpellID="@%SpellID@";";
      }else{
         %query = "Insert into Spells(Name,POWER,LEVEL,COST,SELL,MPCOST,CASTTIME,CASTTURNS,ICON,ANIMATION,PARTICAL,DESC,Classes,StatusBoost,Arcana,StatusEffect,Target,AUTO_LEARN) Values('"@%SPLEDT_Name@"','"@%POWER@"','"@%LEVEL@"','"@%COST@"','"@%SELL@"','"@%MPCOST@"','"@%CASTTIME@"','"@%CASTTURNS@"','"@%ICON@"','"@%ANIMATION@"','"@%PARTICAL@"','"@%DESC@"','"@%Classes@"','"@%StatusBoost@"','"@%Arcana@"','"@%StatusEffect@"','"@%Target_SEL@"','"@%AUTO_LEARN@"');";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Spells table.");
      }else{   

      SPLEDT_Name.setText("");
      SPLEDT_POWER.setText("");
      SPLEDT_LEVEL.setText("");
      SPLEDT_COST.setText("");
      SPLEDT_SELL.setText("");
      SPLEDT_MPCOST.setText("");
      SPLEDT_CASTTIME.setText("");
      SPLEDT_CASTTURNS.setText("");
      SPLEDT_ICON.setText("");
      SPLEDT_ANIMATION.setText("");
      SPLEDT_PARTICAL.setText("");
      SPLEDT_DESC.setText("");
      SPLEDT_Classes_LST.clearItems();
      SPLEDT_StatusBoost_LST.clearItems();
      SPLEDT_Arcana_LST.clearItems();
      SPLEDT_StatusEffect_LST.clearItems();
      SPLEDT_Target_SEL.setFirstSelected();
      SPLEDT_AUTO_LEARN.setStateOn(false);
         %this.displayMainEditor();
         %this.SetMainPanel("Spells");
         %this.LoadSpells();
      }
   sqlite.closeDatabase();
   sqlite.delete();
}


function RPG_Editor::CancelSpells(%this){

      SPLEDT_Name.setText("");
      SPLEDT_POWER.setText("");
      SPLEDT_LEVEL.setText("");
      SPLEDT_COST.setText("");
      SPLEDT_SELL.setText("");
      SPLEDT_MPCOST.setText("");
      SPLEDT_CASTTIME.setText("");
      SPLEDT_CASTTURNS.setText("");
      SPLEDT_ICON.setText("");
      SPLEDT_ANIMATION.setText("");
      SPLEDT_PARTICAL.setText("");
      SPLEDT_DESC.setText("");
      SPLEDT_Classes_LST.clearItems();
      SPLEDT_StatusBoost_LST.clearItems();
      SPLEDT_Arcana_LST.clearItems();
      SPLEDT_StatusEffect_LST.clearItems();
      SPLEDT_Target_SEL.setFirstSelected();
      SPLEDT_AUTO_LEARN.setStateOn(false);
         %this.displayMainEditor();
         %this.SetMainPanel("Spells");
         %this.LoadSpells();
}