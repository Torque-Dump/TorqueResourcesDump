

function RPG_Editor::LoadWeapons(%this)
{
   WPN_Weapons_LST.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select WeaponID, Name from Weapons;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         WPN_Weapons_LST.addItem(%name);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}



function RPG_Editor::Open_PopUP_Weapons(%this, %WeaponID){

   RPG_EDITOR_MAIN.setVisible(false);
   %this.displayPopupEditor("Weapons");
   
	%this.loadWeaponTypesSelection("WPN_EDT_Type");
	%this.loadClassTypeList("WPN_EDT_Classes_LST");
   
   if(%WeaponID==0){
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=true;
      $RPG_EDITOR_POPUP_SAVE_ID=0;      
      WPN_EDT_Name.setText("");
      WPN_EDT_ATK.setText("");
      WPN_EDT_DEF.setText("");
      WPN_EDT_MATK.setText("");
      WPN_EDT_MDEF.setText("");
      WPN_EDT_VIT.setText("");
      WPN_EDT_MAG.setText("");
      WPN_EDT_EVA.setText("");
      WPN_EDT_ACC.setText("");
      WPN_EDT_Type.setFirstSelected();
      WPN_EDT_ICON.setText("");
      WPN_EDT_MESH.setText("");
      WPN_EDT_DESC.setText("");
      WPN_EDT_FIRE_ENH.setText("");
      WPN_EDT_WATER_ENH.setText("");
      WPN_EDT_EARTH_ENH.setText("");
      WPN_EDT_WIND_ENH.setText("");
      WPN_EDT_ICE_ENH.setText("");
      WPN_EDT_LIGHTENING_ENH.setText("");
      WPN_EDT_LIGHT_ENH.setText("");
      WPN_EDT_DARK_ENH.setText("");
      WPN_EDT_METAL_ENH.setText("");
      WPN_EDT_Classes_LST.clearSelection();
   }else{
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=false;
      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      // create a new simple table for demonstration purposes
      %query = "select Name,ATK,DEF,MATK,MDEF,VIT,MAG,EVA,ACC,Type,ICON,MESH,DESC,FIRE_ENH,WATER_ENH,EARTH_ENH,WIND_ENH,ICE_ENH,LIGHTENING_ENH,LIGHT_ENH,DARK_ENH,METAL_ENH,Classes from Weapons where WeaponID="@%WeaponID@";";
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Weapons table.");
      }else{
         // attempt to retrieve result data
         $RPG_EDITOR_POPUP_SAVE_ID=%WeaponID;
      WPN_EDT_Name.setText(sqlite.getColumn(%result, "Name"));
      WPN_EDT_ATK.setText(sqlite.getColumn(%result, "ATK"));
      WPN_EDT_DEF.setText(sqlite.getColumn(%result, "DEF"));
      WPN_EDT_MATK.setText(sqlite.getColumn(%result, "MATK"));
      WPN_EDT_MDEF.setText(sqlite.getColumn(%result, "MDEF"));
      WPN_EDT_VIT.setText(sqlite.getColumn(%result, "VIT"));
      WPN_EDT_MAG.setText(sqlite.getColumn(%result, "MAG"));
      WPN_EDT_EVA.setText(sqlite.getColumn(%result, "EVA"));
      WPN_EDT_ACC.setText(sqlite.getColumn(%result, "ACC"));
      WPN_EDT_Type.setSelected(sqlite.getColumn(%result, "Type"));
      WPN_EDT_ICON.setText(sqlite.getColumn(%result, "ICON"));
      WPN_EDT_MESH.setText(sqlite.getColumn(%result, "MESH"));
      WPN_EDT_DESC.setText(sqlite.getColumn(%result, "DESC"));
      WPN_EDT_FIRE_ENH.setText(sqlite.getColumn(%result, "FIRE_ENH"));
      WPN_EDT_WATER_ENH.setText(sqlite.getColumn(%result, "WATER_ENH"));
      WPN_EDT_EARTH_ENH.setText(sqlite.getColumn(%result, "EARTH_ENH"));
      WPN_EDT_WIND_ENH.setText(sqlite.getColumn(%result, "WIND_ENH"));
      WPN_EDT_ICE_ENH.setText(sqlite.getColumn(%result, "ICE_ENH"));
      WPN_EDT_LIGHTENING_ENH.setText(sqlite.getColumn(%result, "LIGHTENING_ENH"));
      WPN_EDT_LIGHT_ENH.setText(sqlite.getColumn(%result, "LIGHT_ENH"));
      WPN_EDT_DARK_ENH.setText(sqlite.getColumn(%result, "DARK_ENH"));
      WPN_EDT_METAL_ENH.setText(sqlite.getColumn(%result, "METAL_ENH"));
      %classList=sqlite.getColumn(%result, "Classes");
         for(%i=0; %i<getWordCount(%classList);%i++){
            %cls_id=getWord(%classList,%i);
            %query = "select Name from Classes where ClassID="@%cls_id@";";
            %result = sqlite.query(%query, 0);  
            if(%result == 0){
               echo("Could Not Find Class ID: "@%cls_id);
            }else{
               WPN_EDT_Classes_LST.setCurSel(WPN_EDT_Classes_LST.findItemText(sqlite.getColumn(%result, "Name")));
            }
         }
      }
   sqlite.closeDatabase();
   sqlite.delete();
   }

}




function RPG_Editor::LoadSelectedWeapons(%this){
   // attempt to retrieve result data
   %count=WPN_Weapons_LST.getSelectedItem();

   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select WeaponID from Weapons;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Weapons table.");
   }else{
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      %WeaponID = sqlite.getColumn(%result, "WeaponID");
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.Open_PopUP_Weapons(%WeaponID);
}
   

function RPG_Editor::NewWeapons(%this)
{
   %this.Open_PopUP_Weapons(0);
}


function RPG_Editor::DeleteWeapons(%this)
{
   // attempt to retrieve result data
   %count=WPN_Weapons_LST.getSelectedItem();
      
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select WeaponID from Weapons;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Weapons table.");
   }else{
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         %SAVEID = sqlite.getColumn(%result, "WeaponID");
         %query = "Delete from Weapons where WeaponID="@%SAVEID@";";
         %result = sqlite.query(%query, 0);
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.LoadWeapons();
}


function RPG_Editor::SaveWeapons(%this)
{
      %Name=WPN_EDT_Name.getText();
      
      if((%Name $= "") == 1) return;
      %ATK=WPN_EDT_ATK.getText();
      %DEF=WPN_EDT_DEF.getText();
      %MATK=WPN_EDT_MATK.getText();
      %MDEF=WPN_EDT_MDEF.getText();
      %VIT=WPN_EDT_VIT.getText();
      %MAG=WPN_EDT_MAG.getText();
      %EVA=WPN_EDT_EVA.getText();
      %ACC=WPN_EDT_ACC.getText();
      %Type=WPN_EDT_Type.getSelected();
      %ICON=WPN_EDT_ICON.getText();
      %MESH=WPN_EDT_MESH.getText();
      %DESC=WPN_EDT_DESC.getText();
      %FIRE_ENH=WPN_EDT_FIRE_ENH.getText();
      %WATER_ENH=WPN_EDT_WATER_ENH.getText();
      %EARTH_ENH=WPN_EDT_EARTH_ENH.getText();
      %WIND_ENH=WPN_EDT_WIND_ENH.getText();
      %ICE_ENH=WPN_EDT_ICE_ENH.getText();
      %LIGHTENING_ENH=WPN_EDT_LIGHTENING_ENH.getText();
      %LIGHT_ENH=WPN_EDT_LIGHT_ENH.getText();
      %DARK_ENH=WPN_EDT_DARK_ENH.getText();
      %METAL_ENH=WPN_EDT_METAL_ENH.getText();
      

      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      %ClassCount = WPN_EDT_Classes_LST.getSelCount();
      %ClassIDs = WPN_EDT_Classes_LST.getSelectedItems();
      for(%i =0;%i < %ClassCount ; %i++){
         %temp=getWord(%ClassIDs, %i);
         %className=WPN_EDT_Classes_LST.getItemText(%temp);
         %query = "select ClassID from Classes where Name='"@%className@"';";
         %result = sqlite.query(%query, 0);   
         if (%result == 0)
         {
            echo("Class Name Not Found");
         }else{
            %REALCLASSID = sqlite.getColumn(%result, "ClassID");
            if(%i==0){            
               %ClassIDList=" "@%REALCLASSID;
            }else{
               %ClassIDList=%ClassIDList@" "@%REALCLASSID;
            }
         }
      }
      
      // create a new simple table for demonstration purposes
      if($RPG_EDITOR_POPUP_SAVE_STATE_NEW==false){
         %WeaponID=$RPG_EDITOR_POPUP_SAVE_ID;
         %query = "Update Weapons set Name='"@%Name@"',ATK='"@%ATK@"',DEF='"@%DEF@"',MATK='"@%MATK@"',MDEF='"@%MDEF@"',VIT='"@%VIT@"',MAG='"@%MAG@"',EVA='"@%EVA@"',ACC='"@%ACC@"',Type='"@%Type@"',ICON='"@%ICON@"',MESH='"@%MESH@"',DESC='"@%DESC@"',FIRE_ENH='"@%FIRE_ENH@"',WATER_ENH='"@%WATER_ENH@"',EARTH_ENH='"@%EARTH_ENH@"',WIND_ENH='"@%WIND_ENH@"',ICE_ENH='"@%ICE_ENH@"',LIGHTENING_ENH='"@%LIGHTENING_ENH@"',LIGHT_ENH='"@%LIGHT_ENH@"',DARK_ENH='"@%DARK_ENH@"',METAL_ENH='"@%METAL_ENH@"',Classes='"@%ClassIDList@"' where WeaponID="@%WeaponID@";";
      }else{
         %query = "Insert into Weapons(Name,ATK,DEF,MATK,MDEF,VIT,MAG,EVA,ACC,Type,ICON,MESH,DESC,FIRE_ENH,WATER_ENH,EARTH_ENH,WIND_ENH,ICE_ENH,LIGHTENING_ENH,LIGHT_ENH,DARK_ENH,METAL_ENH,Classes) Values('"@%Name@"','"@%ATK@"','"@%DEF@"','"@%MATK@"','"@%MDEF@"','"@%VIT@"','"@%MAG@"','"@%EVA@"','"@%ACC@"','"@%Type@"','"@%ICON@"','"@%MESH@"','"@%DESC@"','"@%FIRE_ENH@"','"@%WATER_ENH@"','"@%EARTH_ENH@"','"@%WIND_ENH@"','"@%ICE_ENH@"','"@%LIGHTENING_ENH@"','"@%LIGHT_ENH@"','"@%DARK_ENH@"','"@%METAL_ENH@"','"@%ClassIDList@"');";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Weapons table.");
      }else{   
         
      WPN_EDT_Name.setText("");
      WPN_EDT_ATK.setText("");
      WPN_EDT_DEF.setText("");
      WPN_EDT_MATK.setText("");
      WPN_EDT_MDEF.setText("");
      WPN_EDT_VIT.setText("");
      WPN_EDT_MAG.setText("");
      WPN_EDT_EVA.setText("");
      WPN_EDT_ACC.setText("");
      WPN_EDT_Type.setFirstSelected();
      WPN_EDT_ICON.setText("");
      WPN_EDT_MESH.setText("");
      WPN_EDT_DESC.setText("");
      WPN_EDT_FIRE_ENH.setText("");
      WPN_EDT_WATER_ENH.setText("");
      WPN_EDT_EARTH_ENH.setText("");
      WPN_EDT_WIND_ENH.setText("");
      WPN_EDT_ICE_ENH.setText("");
      WPN_EDT_LIGHTENING_ENH.setText("");
      WPN_EDT_LIGHT_ENH.setText("");
      WPN_EDT_DARK_ENH.setText("");
      WPN_EDT_METAL_ENH.setText("");
      WPN_EDT_Classes_LST.clearItems();
         %this.displayMainEditor();
         %this.SetMainPanel("Weapons");
         %this.LoadWeapons();
      }
   sqlite.closeDatabase();
   sqlite.delete();
}


function RPG_Editor::CancelWeapons(%this){
         
      WPN_EDT_Name.setText("");
      WPN_EDT_ATK.setText("");
      WPN_EDT_DEF.setText("");
      WPN_EDT_MATK.setText("");
      WPN_EDT_MDEF.setText("");
      WPN_EDT_VIT.setText("");
      WPN_EDT_MAG.setText("");
      WPN_EDT_EVA.setText("");
      WPN_EDT_ACC.setText("");
      WPN_EDT_Type.setFirstSelected();
      WPN_EDT_ICON.setText("");
      WPN_EDT_MESH.setText("");
      WPN_EDT_DESC.setText("");
      WPN_EDT_FIRE_ENH.setText("");
      WPN_EDT_WATER_ENH.setText("");
      WPN_EDT_EARTH_ENH.setText("");
      WPN_EDT_WIND_ENH.setText("");
      WPN_EDT_ICE_ENH.setText("");
      WPN_EDT_LIGHTENING_ENH.setText("");
      WPN_EDT_LIGHT_ENH.setText("");
      WPN_EDT_DARK_ENH.setText("");
      WPN_EDT_METAL_ENH.setText("");
      WPN_EDT_Classes_LST.clearItems();
         %this.displayMainEditor();
         %this.SetMainPanel("Weapons");
         %this.LoadWeapons();
}