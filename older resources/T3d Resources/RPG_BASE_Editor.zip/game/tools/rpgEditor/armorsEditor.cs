

function RPG_Editor::LoadArmors(%this)
{
   ARM_Armors_LST.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ArmorID, Name from Armors;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      while (!sqlite.endOfResult(%result))
      {
         %name = sqlite.getColumn(%result, "Name");
         ARM_Armors_LST.addItem(%name);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}



function RPG_Editor::Open_PopUP_Armors(%this, %ArmorID){

   RPG_EDITOR_MAIN.setVisible(false);
   %this.displayPopupEditor("Armors");
   
	%this.loadArmorTypesSelection("AEDT_ARMORTYPE");
	%this.loadClassTypeList("AEDT_Classes_LST");
   
   if(%ArmorID==0){
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=true;
      $RPG_EDITOR_POPUP_SAVE_ID=0;      
      AEDT_Name.setText("");
      AEDT_ATK.setText("");
      AEDT_DEF.setText("");
      AEDT_MATK.setText("");
      AEDT_MDEF.setText("");
      AEDT_VIT.setText("");
      AEDT_MAG.setText("");
      AEDT_EVA.setText("");
      AEDT_ACC.setText("");
      AEDT_ARMORTYPE.setFirstSelected();
      AEDT_ICON.setText("");
      AEDT_MESHSKIN.setText("");
      AEDT_DESC.setText("");
      AEDT_FIRE_RES.setText("");
      AEDT_WATER_RES.setText("");
      AEDT_EARTH_RES.setText("");
      AEDT_WIND_RES.setText("");
      AEDT_ICE_RES.setText("");
      AEDT_LIGHTENING_RES.setText("");
      AEDT_LIGHT_RES.setText("");
      AEDT_DARK_RES.setText("");
      AEDT_METAL_RES.setText("");
      AEDT_Classes_LST.clearSelection();
   }else{
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=false;
      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      // create a new simple table for demonstration purposes
      %query = "select Name,ATK,DEF,MATK,MDEF,VIT,MAG,EVA,ACC,ARMORTYPE,ICON,MESHSKIN,DESC,FIRE_RES,WATER_RES,EARTH_RES,WIND_RES,ICE_RES,LIGHTENING_RES,LIGHT_RES,DARK_RES,METAL_RES,Classes from Armors where ArmorID="@%ArmorID@";";
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Armors table.");
      }else{
         // attempt to retrieve result data
         $RPG_EDITOR_POPUP_SAVE_ID=%ArmorID;
      AEDT_Name.setText(sqlite.getColumn(%result, "Name"));
      AEDT_ATK.setText(sqlite.getColumn(%result, "ATK"));
      AEDT_DEF.setText(sqlite.getColumn(%result, "DEF"));
      AEDT_MATK.setText(sqlite.getColumn(%result, "MATK"));
      AEDT_MDEF.setText(sqlite.getColumn(%result, "MDEF"));
      AEDT_VIT.setText(sqlite.getColumn(%result, "VIT"));
      AEDT_MAG.setText(sqlite.getColumn(%result, "MAG"));
      AEDT_EVA.setText(sqlite.getColumn(%result, "EVA"));
      AEDT_ACC.setText(sqlite.getColumn(%result, "ACC"));
      AEDT_ARMORTYPE.setSelected(sqlite.getColumn(%result, "ARMORTYPE"));
      AEDT_ICON.setText(sqlite.getColumn(%result, "ICON"));
      AEDT_MESHSKIN.setText(sqlite.getColumn(%result, "MESHSKIN"));
      AEDT_DESC.setText(sqlite.getColumn(%result, "DESC"));
      AEDT_FIRE_RES.setText(sqlite.getColumn(%result, "FIRE_RES"));
      AEDT_WATER_RES.setText(sqlite.getColumn(%result, "WATER_RES"));
      AEDT_EARTH_RES.setText(sqlite.getColumn(%result, "EARTH_RES"));
      AEDT_WIND_RES.setText(sqlite.getColumn(%result, "WIND_RES"));
      AEDT_ICE_RES.setText(sqlite.getColumn(%result, "ICE_RES"));
      AEDT_LIGHTENING_RES.setText(sqlite.getColumn(%result, "LIGHTENING_RES"));
      AEDT_LIGHT_RES.setText(sqlite.getColumn(%result, "LIGHT_RES"));
      AEDT_DARK_RES.setText(sqlite.getColumn(%result, "DARK_RES"));
      AEDT_METAL_RES.setText(sqlite.getColumn(%result, "METAL_RES"));
      %classList=sqlite.getColumn(%result, "Classes");
         for(%i=0; %i<getWordCount(%classList);%i++){
            %cls_id=getWord(%classList,%i);
            %query = "select Name from Classes where ClassID="@%cls_id@";";
            %result = sqlite.query(%query, 0);  
            if(%result == 0){
               echo("Could Not Find Class ID: "@%cls_id);
            }else{
               AEDT_Classes_LST.setCurSel(AEDT_Classes_LST.findItemText(sqlite.getColumn(%result, "Name")));
            }
         }
      }
   sqlite.closeDatabase();
   sqlite.delete();
   }

}


function RPG_Editor::LoadSelectedArmors(%this){
   // attempt to retrieve result data
   %count=ARM_Armors_LST.getSelectedItem();

   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ArmorID from Armors;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Armors table.");
   }else{
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      %ArmorID = sqlite.getColumn(%result, "ArmorID");
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.Open_PopUP_Armors(%ArmorID);
}
   
function RPG_Editor::NewArmors(%this)
{
   %this.Open_PopUP_Armors(0);
}

function RPG_Editor::DeleteArmors(%this)
{
   // attempt to retrieve result data
   %count=ARM_Armors_LST.getSelectedItem();
      
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ArmorID from Armors;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Armors table.");
   }else{
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         %SAVEID = sqlite.getColumn(%result, "ArmorID");
         %query = "Delete from Armors where ArmorID="@%SAVEID@";";
         %result = sqlite.query(%query, 0);
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.LoadArmors();
}


function RPG_Editor::SaveArmors(%this)
{
      %Name=AEDT_Name.getText();
      
      if((%Name $= "") == 1) return;
      %ATK=AEDT_ATK.getText();
      %DEF=AEDT_DEF.getText();
      %MATK=AEDT_MATK.getText();
      %MDEF=AEDT_MDEF.getText();
      %VIT=AEDT_VIT.getText();
      %MAG=AEDT_MAG.getText();
      %EVA=AEDT_EVA.getText();
      %ACC=AEDT_ACC.getText();
      %ARMORTYPE=AEDT_ARMORTYPE.getSelected();
      %ICON=AEDT_ICON.getText();
      %MESHSKIN=AEDT_MESHSKIN.getText();
      %DESC=AEDT_DESC.getText();
      %FIRE_RES=AEDT_FIRE_RES.getText();
      %WATER_RES=AEDT_WATER_RES.getText();
      %EARTH_RES=AEDT_EARTH_RES.getText();
      %WIND_RES=AEDT_WIND_RES.getText();
      %ICE_RES=AEDT_ICE_RES.getText();
      %LIGHTENING_RES=AEDT_LIGHTENING_RES.getText();
      %LIGHT_RES=AEDT_LIGHT_RES.getText();
      %DARK_RES=AEDT_DARK_RES.getText();
      %METAL_RES=AEDT_METAL_RES.getText();
      

      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      %ClassCount = AEDT_Classes_LST.getSelCount();
      %ClassIDs = AEDT_Classes_LST.getSelectedItems();
      for(%i =0;%i < %ClassCount ; %i++){
         %temp=getWord(%ClassIDs, %i);
         %className=AEDT_Classes_LST.getItemText(%temp);
         %query = "select ClassID from Classes where Name='"@%className@"';";
         %result = sqlite.query(%query, 0);   
         if (%result == 0)
         {
            echo("Class Name Not Found");
         }else{
            %REALCLASSID = sqlite.getColumn(%result, "ClassID");
            if(%i==0){            
               %ClassIDList=" "@%REALCLASSID;
            }else{
               %ClassIDList=%ClassIDList@" "@%REALCLASSID;
            }
         }
      }
      
      // create a new simple table for demonstration purposes
      if($RPG_EDITOR_POPUP_SAVE_STATE_NEW==false){
         %ArmorID=$RPG_EDITOR_POPUP_SAVE_ID;
         %query = "Update Armors set Name='"@%Name@"',ATK='"@%ATK@"',DEF='"@%DEF@"',MATK='"@%MATK@"',MDEF='"@%MDEF@"',VIT='"@%VIT@"',MAG='"@%MAG@"',EVA='"@%EVA@"',ACC='"@%ACC@"',ARMORTYPE='"@%ARMORTYPE@"',ICON='"@%ICON@"',MESHSKIN='"@%MESHSKIN@"',DESC='"@%DESC@"',FIRE_RES='"@%FIRE_RES@"',WATER_RES='"@%WATER_RES@"',EARTH_RES='"@%EARTH_RES@"',WIND_RES='"@%WIND_RES@"',ICE_RES='"@%ICE_RES@"',LIGHTENING_RES='"@%LIGHTENING_RES@"',LIGHT_RES='"@%LIGHT_RES@"',DARK_RES='"@%DARK_RES@"',METAL_RES='"@%METAL_RES@"',Classes='"@%ClassIDList@"' where ArmorID="@%ArmorID@";";
      }else{
         %query = "Insert into Armors(Name,ATK,DEF,MATK,MDEF,VIT,MAG,EVA,ACC,ARMORTYPE,ICON,MESHSKIN,DESC,FIRE_RES,WATER_RES,EARTH_RES,WIND_RES,ICE_RES,LIGHTENING_RES,LIGHT_RES,DARK_RES,METAL_RES,Classes) Values('"@%Name@"','"@%ATK@"','"@%DEF@"','"@%MATK@"','"@%MDEF@"','"@%VIT@"','"@%MAG@"','"@%EVA@"','"@%ACC@"','"@%ARMORTYPE@"','"@%ICON@"','"@%MESHSKIN@"','"@%DESC@"','"@%FIRE_RES@"','"@%WATER_RES@"','"@%EARTH_RES@"','"@%WIND_RES@"','"@%ICE_RES@"','"@%LIGHTENING_RES@"','"@%LIGHT_RES@"','"@%DARK_RES@"','"@%METAL_RES@"','"@%ClassIDList@"');";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Armors table.");
      }else{   
         
      AEDT_Name.setText("");
      AEDT_ATK.setText("");
      AEDT_DEF.setText("");
      AEDT_MATK.setText("");
      AEDT_MDEF.setText("");
      AEDT_VIT.setText("");
      AEDT_MAG.setText("");
      AEDT_EVA.setText("");
      AEDT_ACC.setText("");
      AEDT_ARMORTYPE.setFirstSelected();
      AEDT_ICON.setText("");
      AEDT_MESHSKIN.setText("");
      AEDT_DESC.setText("");
      AEDT_FIRE_RES.setText("");
      AEDT_WATER_RES.setText("");
      AEDT_EARTH_RES.setText("");
      AEDT_WIND_RES.setText("");
      AEDT_ICE_RES.setText("");
      AEDT_LIGHTENING_RES.setText("");
      AEDT_LIGHT_RES.setText("");
      AEDT_DARK_RES.setText("");
      AEDT_METAL_RES.setText("");
      AEDT_Classes_LST.clearItems();
         %this.displayMainEditor();
         %this.SetMainPanel("Armors");
         %this.LoadArmors();
      }
   sqlite.closeDatabase();
   sqlite.delete();
}

function RPG_Editor::CancelArmors(%this){
         AEDT_Name.setText("");
         AEDT_ATK.setText("");
         AEDT_DEF.setText("");
         AEDT_MATK.setText("");
         AEDT_MDEF.setText("");
         AEDT_VIT.setText("");
         AEDT_MAG.setText("");
         AEDT_EVA.setText("");
         AEDT_ACC.setText("");
         AEDT_ARMORTYPE.setFirstSelected();
         AEDT_ICON.setText("");
         AEDT_MESHSKIN.setText("");
         AEDT_DESC.setText("");
         AEDT_FIRE_RES.setText("");
         AEDT_WATER_RES.setText("");
         AEDT_EARTH_RES.setText("");
         AEDT_WIND_RES.setText("");
         AEDT_ICE_RES.setText("");
         AEDT_LIGHTENING_RES.setText("");
         AEDT_LIGHT_RES.setText("");
         AEDT_DARK_RES.setText("");
         AEDT_METAL_RES.setText("");
         AEDT_Classes_LST.clearItems();
         %this.displayMainEditor();
         %this.SetMainPanel("Armors");
         %this.LoadArmors();
}