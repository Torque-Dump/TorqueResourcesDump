Twillex-Test is a Torque 2D project.  It includes the Twillex engine as one file, Twillex.cs, which you can copy to your own projects.  Find it within the project at game/libraries/Twillex.cs.

You can also load Twillex-Test in T2D and experiment with tweening by launching it.  A little effort will allow it to run in iTorque 2D and probably even Torque 3D!

Download Twillex-Test:

   https://sourceforge.net/projects/twillex/files/

Source Code (in Subversion):

   Browse     - https://sourceforge.net/p/twillex/code/12/tree/trunk/Twillex_Test/
   Subversion - https://svn.code.sf.net/p/twillex/code/trunk/Twillex_Test
