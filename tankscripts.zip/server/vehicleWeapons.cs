//---------------------------------------------------------
// Tank Firing System Contols
//--------------------------------------------------------
function TankPrimaryWeaponImage::onFire(%this, %obj, %slot)
{
   %projectile = %this.projectile;
   //%obj.decInventory(%this.ammo,1);

   %muzzleVector = %obj.getMuzzleVector(%slot);
   %objectVelocity = %obj.getVelocity();
   %muzzleVelocity = VectorAdd(
      VectorScale(%muzzleVector, %projectile.muzzleVelocity),
      VectorScale(%objectVelocity, %projectile.velInheritFactor));

   %smoke = new ParticleEmitterNode() {
      dataBlock        = TankSmokeEmitterNodeData;
      emitter          = TankFireSmokeEmitter;
   };
   %smoke.setTransform(%obj.getMuzzlePoint(%slot));
   schedule(%smoke.emitter.lifetimeMS + 10, 0, "deleteEmitterNode", %smoke);

   %p = new (%this.projectileType)() {
      dataBlock        = %projectile;
      initialVelocity  = %muzzleVelocity;
      initialPosition  = %obj.getMuzzlePoint(%slot);
      sourceObject     = %obj;
      sourceSlot       = %slot;
      client           = %obj.mPlayer.client;
   };
   MissionCleanup.add(%p);
   return %p;
}
function TankPrimaryProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
{
   if (%col.getType() & $TypeMasks::ShapeBaseObjectType)
      %col.damage(%obj,%pos,%this.directDamage,"TankPrimaryProjectile");
      
   radiusDamage
      (%obj, VectorAdd(%pos, VectorScale(%normal, 0.01)),
      %this.damageRadius,%this.radiusDamage,"Radius",40);
}
//--------------------------------------------------------
// Secondary Weapons
//--------------------------------------------------------
function TankSecondaryWeaponImage::onFire(%this, %obj, %slot)
{
   %projectile = %this.projectile;
   //%obj.decInventory(%this.ammo,1);

   %muzzleVector = %obj.getMuzzleVector(%slot);
   %objectVelocity = %obj.getVelocity();
   %muzzleVelocity = VectorAdd(
      VectorScale(%muzzleVector, %projectile.muzzleVelocity),
      VectorScale(%objectVelocity, %projectile.velInheritFactor));

   %p = new (%this.projectileType)() {
      dataBlock        = %projectile;
      initialVelocity  = %muzzleVelocity;
      initialPosition  = %obj.getMuzzlePoint(%slot);
      sourceObject     = %obj;
      sourceSlot       = %slot;
      client           = %obj.mPlayer.client;
   };
   MissionCleanup.add(%p);
   return %p;
}
function TankSecondaryProjectile::onCollision(%this,%obj,%col,%fade,%pos,%normal)
{
   if (%col.getType() & $TypeMasks::ShapeBaseObjectType)
      %col.damage(%obj,%pos,%this.directDamage,"TankSecondaryProjectile");
}
//--------------------------------------------------------
function TankTertiaryWeaponImage::onFire(%this, %obj, %slot)
{
   %projectile = %this.projectile;
   //%obj.decInventory(%this.ammo,1);

   %muzzleVector = %obj.getMuzzleVector(%slot);
   %objectVelocity = %obj.getVelocity();
   %muzzleVelocity = VectorAdd(
      VectorScale(%muzzleVector, %projectile.muzzleVelocity),
      VectorScale(%objectVelocity, %projectile.velInheritFactor));

   %p = new (%this.projectileType)() {
      dataBlock        = %projectile;
      initialVelocity  = %muzzleVelocity;
      initialPosition  = %obj.getMuzzlePoint(%slot);
      sourceObject     = %obj;
      sourceSlot       = %slot;
      client           = %obj.mPlayer.client;
   };
   MissionCleanup.add(%p);
   return %p;
}
//--------------------------------------------------------

//---------------------------------------------------------
