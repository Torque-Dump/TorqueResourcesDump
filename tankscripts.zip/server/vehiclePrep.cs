//-----------------------------------------------------------------------------
// Wheeled Vehicle 
// This works for a limited number of situations (Setups)
//
// Basic 4 Wheels : First 2 are Not Powered and Steering and NOT Unique wheels/springs
//   wheelCount                 = 4;       //2Front / 2Rear
//   uniqueWheels               = false;
//   fourwheelSteer             = false;
//   fourwheelPower             = false;
//   attachTire[0]              = DefaultCarTire;
//   useSpring[0]               = DefaultCarSpring;   
//
// 4 Wheels : First 2 are Not Powered and Steering and Unique wheels/springs
//   wheelCount                 = 4;       //2Front / 2Rear
//   uniqueWheels               = false;
//   fourwheelSteer             = false;
//   fourwheelPower             = false;
//   attachTire[0]              = CheetahCarTire;
//   useSpring[0]               = CheetahCarSpring;   
//   attachTire[1]              = CheetahCarTire;
//   useSpring[1]               = CheetahCarSpring;   
//   attachTire[2]              = CheetahCarTireRear;
//   useSpring[2]               = CheetahCarSpring;   
//   attachTire[3]              = CheetahCarTireRear;
//   useSpring[3]               = CheetahCarSpring;   
//
// 8 Wheels : First 4 are Not Powered and Steering and NOT Unique wheels/springs
//   wheelCount                 = 8;       //4 per side
//   uniqueWheels               = false;
//   fourwheelSteer             = false;     //First Four are steering
//   fourwheelPower             = false;
//   attachTire[0]              = StrykerIAVTire;
//   useSpring[0]               = StryikerIAVSpring;   
//-----------------------------------------------------------------------------
function WheeledVehicleData::onAdd(%this, %obj)
{
   //echo("WheeledVehicleData::onAdd("@ %this.getName() @", "@ %obj.getClassName() @")");

   Parent::onAdd(%this, %obj);

   // Setup the car with some tires & springs
   // This will now deal with different Tire Types
   %tireID = 0;
   %steer = false;
   %power = false;
   for (%i=0; %i<%this.wheelCount; %i++)
   {
      // Add Tire and Springs
      %obj.setWheelTire(%i, %this.attachTire[%tireID]);
      %obj.setWheelSpring(%i, %this.useSpring[%tireID]);
      %tireID = (%this.uniqueWheels) ? %tireID++ : 0; 

      // Set Steering and Power
      %steer = (%this.fourwheelSteer || (%i < (%this.wheelCount/2))) ? true : false; 
      %obj.setWheelSteering(%i, %steer);

      %power = (%this.fourwheelPower || (%i > (%this.wheelCount/2 -1))) ? true : false; 
      %obj.setWheelPowered(%i, %power);
   }
}
//--------------------------------------------------------
// Tank System
// with some careful design and the addition of details
// in the datablock itself, able to avoid having to do
// an onAdd() function for each tank.  This is fairly flexible
// but not perfect.  Any tank that uses this system must
// match Skeleton / Items wise to work properly..
// Hub/Spring order is specific...
//
//----------------------------------
// Front and Back Outer wheels first 
//----------------------------------
// Front->Back (right)  0/1 
// Back->Front (Left)   2/3
//----------------------------------
// Inner Wheels 
//----------------------------------
// Front->Back (right)  4-x
// Back->Front (left)   x+1/last
//
//--------------------------------------------------------
function TankVehicleData::onAdd(%this,%obj)
{
   %obj.mountable = true;
   Parent::onAdd(%this, %obj);

   %frontWheel = %this.attachTire[0];
   %backWheel = %this.attachTire[1];
   %innerWheel = %this.attachTire[2];
   %outerSpring = %this.useSpring[0];
   %innerSpring = %this.useSpring[2];

   %numSide = %this.numInnerWheelsPerSide;
   %curWheel = 0;
   // Outer Wheels First [FrontRight->BackRight -> BackLeft->FrontLeft]
   for( %i=0; %i<4; %i++ )
   {
      %curWheelImage = (%i==0 || %i==3)? %frontWheel : %backWheel;
      %obj.setWheelTire(%curWheel,     %curWheelImage);
      %obj.setWheelPowered(%curWheel,  true);
      %obj.setWheelSpring(%curWheel,   %outerSpring);
      %obj.setWheelSteering(%curWheel, false);
      %curWheel++;
   }
   // Inner Right/Left Sides [5-15] [FrontRight->BackRight -> BackLeft->FrontLeft]
   for( %i = 0; %i<%numSide*2; %i++ )
   {
      %obj.setWheelTire(%curWheel,      %innerWheel);
      %obj.setWheelPowered(%curWheel,   true);
      %obj.setWheelSpring(%curWheel,    %innerSpring);
      %obj.setWheelSteering(%curWheel,  false);
      %curWheel++;
   }
}
//-----------------------------------------------------
// Cheetah Vehicle Setup
//-----------------------------------------------------
function CheetahCar::onAdd(%this, %obj)
{
   Parent::onAdd(%this, %obj);
   addBrakeLights(%obj);
   %obj.mountObject(%obj.brakeLightRight, %this.brakeLightRightSlot);
   %obj.mountObject(%obj.brakeLightLeft, %this.brakeLightLeftSlot);
}
//----------------------------------------------------------
// IAV - HEADLIGHTS AND BRAKE LIGHTS
//----------------------------------------------------------
function addIAVLights(%vehicleDB,%obj)
{
   addHeadLights(%obj);
   addBrakeLights(%obj);
   %obj.mountObject(%obj.brakeLightRight, %vehicleDB.brakeLightRightSlot);
   %obj.mountObject(%obj.brakeLightLeft, %vehicleDB.brakeLightLeftSlot);
   %obj.mountObject(%obj.headLightRight, %vehicleDB.headLightRightSlot);
   %obj.mountObject(%obj.headLightLeft, %vehicleDB.headLightLeftSlot);
}
//----------------------------------------------------------
// HEADLIGHTS AND BRAKE LIGHTS
//----------------------------------------------------------
function addHeadLights(%obj)
{
   %obj.headLightLeft = createHeadLight();
	%obj.headLightRight = createHeadLight();
}
function addBrakeLights(%obj)
{
   %obj.brakeLightLeft = createBrakeLight();
	%obj.brakeLightRight = createBrakeLight();
}
//--------------------------------------------------
function createBrakeLight()
{
   //Simple way to it..
   //Create the Light and return it
   //Makes it feasible to Add to other vehicles
   %lightObj = new PointLight() 
   {
      radius = "1";
      isEnabled = "0";
      color = "1 0 0.141176 1";
      brightness = "2";
      castShadows = "1";
      priority = "1";
      animate = "0";
      animationPeriod = "1";
      animationPhase = "1";
      flareScale = "1";
      attenuationRatio = "0 1 1";
      shadowType = "DualParaboloidSinglePass";
      texSize = "512";
      overDarkFactor = "2000 1000 500 100";
      shadowDistance = "400";
      shadowSoftness = "0.15";
      numSplits = "1";
      logWeight = "0.91";
      fadeStartDistance = "0";
      lastSplitTerrainOnly = "0";
      representedInLightmap = "0";
      shadowDarkenColor = "0 0 0 -1";
      includeLightmappedGeometryInShadow = "0";
      rotation = "1 0 0 0";
      canSave = "1";
      canSaveDynamicFields = "1";
      splitFadeDistances = "10 20 30 40";
   };

   if( isObject(%lightObj) )
      return %lightObj;

   echo("Failed to Create BrakeLight...");
   return -1;
}
function createHeadLight()
{
   %lightObj = new SpotLight() 
   {
      radius = "60";
      isEnabled = "0";
      color = "0.517241 0.517241 0.528736 1";
      brightness = "0.804598";
      castShadows = "1";
      priority = "1";
      animate = "0";
      animationPeriod = "1";
      animationPhase = "1";
      flareScale = "1";
      attenuationRatio = "0 1 1";
      shadowType = "DualParaboloidSinglePass";
      texSize = "512";
      overDarkFactor = "2000 1000 500 100";
      shadowDistance = "400";
      shadowSoftness = "0.15";
      numSplits = "1";
      logWeight = "0.91";
      fadeStartDistance = "0";
      flareType = "LightFlareExample0";
      flareScale = "1";
      lastSplitTerrainOnly = "0";
      representedInLightmap = "0";
      shadowDarkenColor = "0 0 0 -1";
      includeLightmappedGeometryInShadow = "0";
      rotation = "1 0 0 0";
      canSave = "1";
      canSaveDynamicFields = "1";
      splitFadeDistances = "10 20 30 40";
   };

   if( isObject(%lightObj) )
      return %lightObj;

   echo("Failed to Create HeadLight...");
   return -1;
}
