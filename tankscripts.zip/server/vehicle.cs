//-----------------------------------------------------------------------------
// Vehicle Initialization
// ----------------------------------------------------------------------------
function VehicleData::onAdd(%this, %obj)
{
   //echo("\c4VehicleData::onAdd("@ %this.getName() @", "@ %obj.getClassName() @")");

   %obj.setRechargeRate(%this.rechargeRate);
   %obj.setEnergyLevel(%this.MaxEnergy);
   %obj.setRepairRate(0);

   if (%obj.mountable || %obj.mountable $= "")
      %this.isMountable(%obj, true);
   else
      %this.isMountable(%obj, false);

   if (%this.nameTag !$= "")
      %obj.setShapeName(%this.nameTag);
      
   // Mythic DEBUG
   // New Weapon/Object Mounting System
   // For ALL Vehicles from DataBlock info
   // Add the weapons
   // No more then 4 Images at moment
   // Auto Mounts from Slot0-Slot3
   // for connection to the WeaponImage system
   // Always do weapons first..
   // And match the TriggerMount[x] to it
   %imageMount = %this.numImagePoints;
   if( %imageMount > 0 )
   {
      //echo("\c4VehicleData AddObjects .. "@ %this.getName() @", "@ %obj.getClassName() @" : Count : "@%imageMount);
      %slot = 0;
      for( %imageIndex = 0; %imageIndex < %imageMount; %imageIndex++ )
      {
         %objectImage = %this.objectImage[%imageIndex];
         if( isObject(%objectImage) )
         {
            //echo("\c4VehicleData MountingImage .. "@ %this.getName() @", "@ %objectImage.getName());
            if( %this.objectWeapon[%imageIndex] )
            {
               %obj.setInventory(%this.objectItem[%imageIndex], 1);
               %obj.setInventory(%this.objectAmmo[%imageIndex], %this.objectAmmoCnt[%imageIndex]);
            }
            %obj.mountImage(%objectImage, %slot);
            %slot++;
         }
         if( %slot > 3 )   
            break;
      }
   }
}
function VehicleData::onRemove(%this, %obj)
{
   //echo("\c4VehicleData::onRemove("@ %this.getName() @", "@ %obj.getClassName() @")");
   // If there are passengers/driver/weapons/whatever, 
   // Kick them out or destroy them
   for(%i = 0; %i < %obj.getDataBlock().totalMountPoints; %i++)
   {
      %mntObj = %obj.getMountNodeObject(%i);
      if( isObject(%mntObj) )
      {
         if( %mntObj.isMemberOfClass("Player") )
         {
            %mntObj.mVehicle = %obj;
            %mntObj.getDataBlock().doDismount(%mntObj, true);
         }
         else
            %mntObj.delete();
      }
   }
   // Check if we have any mounted lights.
   // if so disable them, then delete them
   if(isObject(%obj.headLightRight))
   {
      %obj.headLightRight.setLightEnabled(false);
      %obj.headLightRight.delete();
   }
   if(isObject(%obj.headLightLeft))
   {
	   %obj.headLightLeft.setLightEnabled(false);
      %obj.headLightLeft.delete();
   }
   // Do the same for Brakelights
   if(isObject(%obj.brakeLightRight))
   {
		%obj.brakeLightRight.setLightEnabled(false);
      %obj.brakeLightRight.delete();
   }
   if(isObject(%obj.brakeLightLeft))
   {
		%obj.brakeLightLeft.setLightEnabled(false);
      %obj.brakeLightLeft.delete();
   }
}
// ----------------------------------------------------------------------------
// Vehicle player mounting and dismounting
// ----------------------------------------------------------------------------
function VehicleData::isMountable(%this, %obj, %val)
{
   %obj.mountable = %val;
}
function VehicleData::mountPlayer(%this, %vehicle, %player)
{
   //echo("\c4VehicleData::mountPlayer("@ %this.getName() @", "@ %vehicle @", "@ %player.client.nameBase @")");
   if (isObject(%vehicle) && %vehicle.getDamageState() !$= "Destroyed")
      %this.schedule(150, "setMountVehicle", %vehicle, %player);
}
function VehicleData::setMountVehicle(%this, %vehicle, %player)
{
   //echo("\c4VehicleData::setMountVehicle("@ %this.getName() @", "@ %vehicle @", "@ %player.client.nameBase @")");
   if (isObject(%vehicle) && %vehicle.getDamageState() !$= "Destroyed")
   {
      %seat = %this.findEmptySeat(%vehicle, %player);
      if (%seat >= 0)
      {
         %pilotNode = %this.pilotNode;
         //echo("\c4Mount Seat: "@ %seat @" -- PilotNode : "@%pilotNode);
         ServerConnection.setFirstPerson(1);
         %player.mVehicle = %vehicle;
         %player.mSeat = %seat;

         %player.setTransform(%vehicle.getTransform());
         %vehicle.mountObject( %player, %seat, %this.mountPointTransform[%seat]);
         
         if( %this.mountCloaked[%seat] )
         {
            %player.startFade(500, 0, true);
            %player.isFaded = true;
         }
         else
            %player.isFaded = false;
            
         //%player.playAudio(0, MountVehicleSound);
         if(%this.unmountWeaponOnMount[%seat])
         {
            %player.lastWeapon = %player.getMountedImage($WeaponSlot);
            %player.unmountImage($WeaponSlot);
         }
         
         //echo("Mounted player :"@%player.getShapeName());
         //Driver
         if (%seat == %pilotNode)
            %vehicle.mountPilot( %player );
      }
   }
}
// ----------------------------------------------------------------------------
// Vehicle Seat Control
// ----------------------------------------------------------------------------
function Vehicle::mountPilot( %this, %player )
{
   //echo("\c4Vehicle::mountPilot("@ %this.getName() @", "@ %player.client.nameBase @")");
   
   %player.client.setControlObject(%this); 
   %this.mPlayer = %player;
   %this.setEngineOn(true);
            
   %wepMntCount = %this.getDataBlock().numWeaponPoints;
   if( %wepMntCount > 0 )
   {
      //echo("Weapon Mounts Found :"@%wepMntCount);
      for(%i=0; %i<%wepMntCount; %i++)
      {
         %weapon = %this.getMountedImage(%i);
         if( isObject(%weapon) && %weapon.isMemberOfClass("WeaponImage") )
         {
            //echo("Found Mounted Weapon :"@%weapon.getClassName());
            %AmmoType = %weapon.ammo;
            %currentAmmo = (%weapon.ammo $= "") ? 0 : %this.getInventory(%AmmoType);
            //echo("Weapon Ammo: count["@%currentAmmo@"]");
            %this.setImageAmmo(%i, %currentAmmo > 0);                     
            if (%player.client && %i == 0)
            {
               //echo("Vehicle::setMountVehicle() -- Driver Hud Update : "@%player.getName()@" : RefreshWeaRefreshWeaponHud( "@%currentAmmo@" , "@%weapon.item.previewImage@" )");
               %player.client.RefreshWeaponHud(%currentAmmo, %weapon.item.previewImage, "", "");
            }
         }
      }
   }
}
function Vehicle::disMountPilot( %this, %player )
{
   //echo("\c4Vehicle::disMountPilot("@ %this.getName() @", "@ %player.client.nameBase @")");

   %player.client.setControlObject(%player); 
   %this.mPlayer = "";
   %this.setEngineOn(false);
}
//-----------------------------------------------------------
function VehicleData::findEmptySeat(%this, %vehicle, %player)
{
   //echo("\c4This vehicle has "@ %this.numMountPoints @" mount points.");
   for (%i = 0; %i < %this.numMountPoints; %i++)
   {
      %passenger = %vehicle.getMountNodeObject(%i);
      if (%passenger == 0)
         return %i;
   }
   return -1;
}
function VehicleData::switchSeats(%this, %vehicle, %player)
{
   for (%i = 0; %i < %this.numMountPoints; %i++)
   {
      %passenger = %vehicle.getMountNodeObject(%i);
      if (%passenger == %player || %passenger > 0)
         continue;
      if (%passenger == 0)
         return %i;
   }
   return -1;
}
function findNextFreeSeat(%client, %vehicle)
{
   %seat = %client.player.mSeat + 1;
   %vehicleDB = %vehicle.getDataBlock();
   if (%seat >= %vehicleDB.numMountPoints)
      %seat = 0;
   %found = false;
   while ((%seat != %client.player.mSeat) && (%found == false))
   {
      if (%seat >= %vehicleDB.numMountPoints)
      {
         %seat = 0;
      }
      else
      {
         %passenger = %vehicle.getMountNodeObject(%seat);
         if (%passenger == 0)
            %found = true;
         if (%found == false)
            %seat++;
      }
   }
   if (%found == false)
      return -1;
   else
      return %seat;
}
//------------------------------------------------------------
function setActiveSeat(%client, %vehicle, %seat)
{
   %player = %client.player;
   %oldSeat = %player.mSeat;
   %player.mSeat = %seat;

   //echo("setActiveSeat -- OldSeat "@%oldSeat@" - New Seat = " @ %seat);
   
   %vehicleDB = %vehicle.getDataBlock();
   %player.setTransform(%vehicle.getTransform());
   %vehicle.mountObject(%player, %seat, %vehicleDB.mountPointTransform[%seat]);

   CommandToClient(%client, 'switchActionMap', %vehicleDB.actionMapForMountPoint[%seat]);
   %player.setActionThread(%vehicleDB.mountPose[%seat]);
	%client.player.mountImage(%player.lastWeapon, $WeaponSlot);

   if( %oldSeat == %vehicleDB.pilotNode )
      %vehicle.disMountPilot( %player );
   else if( %seat == %vehicleDB.pilotNode )
      %vehicle.mountPilot( %player );
   //else
   //{
   //   %player.client.setControlObject(%player); 
   //}

   // Visible Seat
   if( %player.isFaded && !%vehicleDB.mountCloaked[%seat] )
   {
      %player.startFade(500, 0, false);
      %player.isFaded = false;
   }
   else if( %vehicleDB.mountCloaked[%seat] && !%player.isFaded )
   {
      %player.startFade(500, 0, true);
      %player.isFaded = true;
   }

   // No Weapon Seat
   if(%vehicleDB.unmountWeaponOnMount[%seat])
   {
      %weaponObj = %player.getMountedImage($WeaponSlot);
      if(isObject(%weaponObj))
      {
	      %player.lastWeapon = %weaponObj;
         %player.unmountImage($WeaponSlot);
	   }
   }
}
// ----------------------------------------------------------------------------
// Vehicle Damage Control
// ----------------------------------------------------------------------------
function VehicleData::onImpact(%this, %vehicleObject, %collidedObject, %vec, %vecLen)
{
   if(%vehicleObject.getDamageState() $= "Destroyed")
      return;
   %driver = %vehicleObject.getMountNodeObject(%this.pilotNode);
   if( !isObject(%driver) )
      return;

   if( %vehicleObject.mPlayer != %driver )
      %vehicleObject.mPlayer = %driver;      

   //echo("\c4VehicleData::onImpact("@ %data.getClassName() @", "@ %vehicleObject.getClassName() @", "@ %collidedObject.getClassName() @")");
   %this.hitSomething(%vehicleObject,%collidedObject,%vec,%vecLen,'VehicleHitGround');
}
//-------------------------------------------------------------
function VehicleData::onCollision(%this,%obj,%col,%vec,%speed)
{
   %driver = %obj.getMountNodeObject(%this.pilotNode);
   if( !isObject(%driver) )
      return;
   if (%driver == %col)
      return;
   if (!%col.mountVehicle)
      return;
   if(%obj.getDamageState() $= "Destroyed")
      return;

   if (%col.getType() & $TypeMasks::TerrainObjectType)
   {
       %this.hitSomething(%obj,%col,%vec,%speed,'VehicleHitGround');
   }
   else if (%col.getClassName() $= "Item")
   {
      %obj.pickup(%col, 1);
      return;
   }
   else if (%col.getType() & $TypeMasks::ShapeBaseObjectType)
   {
      %directDamage = 50;
      %col.damage(%obj,%pos,%directDamage,"VehicleCollision");
      %this.hitSomething(%obj,%col,%vec,%speed,'VehicleHitObject');
   }
}
function VehicleData::hitSomething(%this,%obj,%col,%vec,%speed,%hitwhat)
{
   if(%speed > %this.hardImpactSpeed)
      %shieldSound = HardImpactSound;
   else if(%speed > %this.softImpactSpeed)
      %shieldSound = SoftImpactSound;

  if(%speed > %this.minImpactSpeed && %speed > %this.minSpeedDamage)
     %obj.damage(%col, VectorAdd(%vec, %obj.getPosition()),
         (%speed-%this.minSpeedDamage) * %this.speedDamageScale, $DamageType::Ground);
}
//--------------------------------------------------------
function VehicleData::damage(%this, %obj, %sourceObject, %position, %damage, %damageType)
{
   echo("VehicleData::damage() ... "@%obj.getClassName());
   if(%obj.getDamageState() $= "Destroyed")
      return;

   %obj.applyDamage(%damage);
   %location = "Body";
   if(%obj.getDamageState() $= "Destroyed")
   {
      for(%i = 0; %i < %obj.getDataBlock().numMountPoints; %i++)
      {
         %passenger = %obj.getMountNodeObject(%i);
         if( isObject(%passenger) && %passenger.isMemberOfClass("Player") )
         {
            //echo("Passenger Killed ... "@%passenger.getShapeName());
            %passenger.getDataBlock().doDismount(%passenger, true);
            %passenger.schedule(800, "kill", %sourceObject, "VehicleDestroyed");
         }
      }
   }
}
function VehicleData::onDamage(%this, %obj)
{
   echo("VehicleData::onDamage() ... "@%obj.getClassName());
   %damage = %obj.getDamageLevel();
   if (%damage >= %obj.destroyedLevel)
   {
      %obj.mountable = false;
      %obj.setDamageState(Destroyed);
   }
   else
   {
      if(%obj.getDamageState() !$= "Enabled")
         %obj.setDamageState(Enabled);
   }
}
function VehicleData::onDestroyed(%this, %obj, %prevState)
{
   echo("VehicleData::onDestroyed() ... "@%obj.getShapeName());
   %totalMountedObjects = %obj.getMountedObjectCount();
   if(%totalMountedObjects > 0)
   {
      %end = %this.numWeaponPoints;
      if( %end > 0 )
      {
         for(%i=0; %i<%end; %i++)
         {
            %weapon = %obj.getMountNodeObject(%i);
            if( isObject(%weapon) )
               %obj.setImageTrigger(%i,false);
         }
      }
   }
   %obj.setShapeName("DestroyedVehicle");
   %obj.startFade(60000, 0, true);  //60 Seconds
   // %obj.schedule(60100, "setHidden", true); //(Why Hide then delete?)
   %obj.schedule(60100, "delete");
   MissionCleanup.Add(%obj);
}
// ----------------------------------------------------------------------------
// Vehicle Misc
// ----------------------------------------------------------------------------
function VehicleData::kill(%this, %sourceObject, %damageType)
{
   %obj.damage(%sourceObject, %this.getPosition(), 10000, %damageType);
}
// ----------------------------------------------------------------------------
function deleteEmitterNode(%obj)
{
   %obj.delete();
}
//--------------------------------------------------------
// Vehicle Lighting System for Flexibility
// Toggle Headlight/BrakeLight Functions - ON\OFF (true\false)
// This is called via a ServerCmd "serverCmdToggleHLights"
//----------------------------------------------------------
function ToggleHeadlightState(%obj, %lightState)
{
   %obj.headLightRight.setLightEnabled(%lightState);
   %obj.headLightLeft.setLightEnabled(%lightState);
}
//----------------------------------------------------------
function ToggleBrakelightState(%obj, %lightState)
{
   %obj.brakeLightRight.setLightEnabled(%lightState);
   %obj.brakeLightLeft.setLightEnabled(%lightState);
}
// ----------------------------------------------------------------------------
// Numerical Health Counter
// ----------------------------------------------------------------------------
function Vehicle::updateHealth(%vehicle)
{
   echo("Vehicle::updateHealth() -> Vehicle Health changed, updating HUD!");
   if(%vehicle.getDamageState() !$= "Enabled")
   {
      echo("updateHealth : Updating Disabled Vehicle!!");
      return;
   }

   // Calcualte player health
   %maxDamage = %vehicle.getDataBlock().maxDamage;
   %damageLevel = %vehicle.getDamageLevel();
   %curHealth = %maxDamage - %damageLevel;
   %curHealth = mceil(%curHealth);

   if( isObject(%vehicle.mPlayer.client) )
      commandToClient(%vehicle.mPlayer.client, 'setNumericalHealthHUD', %curHealth);
}
// ----------------------------------------------------------------------------
// Numerical Energy Counter
// ----------------------------------------------------------------------------
function Vehicle::updateEnergy(%vehicle)
{
   echo("\c4Vehicle::updateEnergy() -> Player Energy changed, updating HUD!");
   if(%vehicle.getDamageState() !$= "Enabled")
   {
      echo("updateEnergy : Updating Disabled Vehicle!!");
      return;
   }

   %energyLevel = %vehicle.getEnergyLevel();
   %curEnergy = mceil(%energyLevel);

   // Send the player object's current health level to the client, where it
   // will Update the numericalEnergy HUD.
   if( isObject(%vehicle.mPlayer.client) )
      commandToClient(%vehicle.mPlayer.client, 'setNumericalEnergyHUD', %curEnergy);
}
function Vehicle::restoreEnergy(%vehicle)
{
   if(%vehicle.getDamageState() !$= "Enabled")
   {
      echo("restoreEnergy : Updating Disabled Vehicle!!");
      return;
   }
   %maxEnergy = %vehicle.getDataBlock().maxEnergy;
   %vehicle.setEnergyLevel(%maxEnergy);
   if( isObject(%vehicle.mPlayer.client) )
      commandToClient(%vehicle.mPlayer.client, 'setNumericalEnergyHUD', %maxEnergy);
}
function Vehicle::decEnergy(%vehicle)
{
   if(%vehicle.getDamageState() !$= "Enabled")
   {
      echo("decEnergy : Updating Disabled Vehicle!!");
      return;
   }
	if(%vehicle.getVelocity() !$="0 0 0")
	{
		%curEnergy = %vehicle.getEnergyLevel() -1;
		%vehicle.setEnergyLevel(%curEnergy);
		%vehicle.updateEnergy();
		if(%curEnergy < 1)
		{
			%vehicle.stop();
         if( isObject(%vehicle.mPlayer.client) )
			   messageClient(%vehicle.mPlayer.client, 'MsgPlayer', '\c0%1 - Cannot Move - Out Of Energy!', %vehicle.mPlayer.getName());
			return;
		}
		%vehicle.schedule(250, "decEnergy");
	}
}
