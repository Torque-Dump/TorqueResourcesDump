//-----------------------------------------------------------------------------
// TankSecondaryWeapon. This file contains all the items related to this TankSecondaryWeapon
// including explosions, ammo, the item and the TankSecondaryWeapon item image.
// These objects rely on the item & inventory support system defined
// in item.cs and inventory.cs
//-----------------------------------------------------------------------------
// Projectile trail emitter
datablock ParticleData(TankSecondarySmokeParticle)
{
   textureName          = "art/shapes/particles/smoke01";

   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.2;  // rises
   inheritedVelFactor   = 0.00;

   lifetimeMS           = 300;   // time in ms
   lifetimeVarianceMS   = 150;   // ...more or less

   useInvAlpha = false;
   spinRandomMin = -30.0;
   spinRandomMax = 30.0;

   colors[0]     = "0.56 0.36 0.26 1.0";
   colors[1]     = "0.56 0.36 0.26 1.0";
   colors[2]     = "0 0 0 0";

   sizes[0]      = 0.1;
   sizes[1]      = 0.15;
   sizes[2]      = 0.3;

   times[0]      = 0.0;
   times[1]      = 0.3;
   times[2]      = 1.0;
};
datablock ParticleEmitterData(TankSecondarySmokeEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;

   ejectionVelocity = 0.25;
   velocityVariance = 0.10;

   thetaMin         = 0.0;
   thetaMax         = 90.0;

   particles = TankSecondarySmokeParticle;
};
//-------------------------------------------------------------------------
// AssaultRifle fire emitter
datablock ParticleData(TankSecondaryFireParticle)
{
   textureName          = "art/shapes/particles/smoke01";

   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.1;  // rises
   inheritedVelFactor   = 0.3;

   lifetimeMS           = 200;   // Time in ms
   lifetimeVarianceMS   = 50;    // ...more or less

   useInvAlpha = false;
   spinRandomMin = -30.0;
   spinRandomMax = 30.0;

   colors[0]     = "1.0 1.0 1.0 0.0";
   colors[1]     = "0.56 0.36 0.26 1.0";
   colors[2]     = "0 0 0 0";

   sizes[0]      = 0.2;
   sizes[1]      = 0.5;
   sizes[2]      = 1;

   times[0]      = 0.0;
   times[1]      = 0.3;
   times[2]      = 1.0;
};
datablock ParticleEmitterData(TankSecondaryFireEmitter)
{
   ejectionPeriodMS = 30;
   periodVarianceMS = 5;

   ejectionVelocity = 2;
   ejectionOffset   = 0.1;
   velocityVariance = 0.10;

   thetaMin         = 0.0;
   thetaMax         = 10.0;

   particles = TankSecondaryFireParticle;
};
//-----------------------------------------------------------------------------
// Projectile Explosion
datablock ParticleData(TankSecondaryExplosionParticle)
{
   dragCoefficient      = 2;
   gravityCoefficient   = 0.2;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 750;
   lifetimeVarianceMS   = 150;
   textureName          = "art/shapes/particles/smoke01";

   colors[0]     = "0.56 0.36 0.26 1.0";
   colors[1]     = "0.56 0.36 0.26 1.0";
   colors[2]     = "0 0 0 0";

   sizes[0]      = 0.5;
   sizes[1]      = 1.0;
};
datablock ParticleEmitterData(TankSecondaryExplosionEmitter)
{
   ejectionPeriodMS  = 7;
   periodVarianceMS  = 0;
   ejectionVelocity  = 1;
   velocityVariance  = 1.0;
   ejectionOffset    = 0.0;
   thetaMin          = 0;
   thetaMax          = 60;
   phiReferenceVel   = 0;
   phiVariance       = 360;
   overrideAdvances  = false;
   particles         = "TankSecondaryExplosionParticle";
};
datablock ExplosionData(TankSecondaryExplosion)
{
   particleEmitter = TankSecondaryExplosionEmitter;
   particleDensity = 50;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;
};
//-----------------------------------------------------------------------------
// Projectile Object
datablock ProjectileData(TankSecondaryProjectile)
{
   projectileShapeName = "art/shapes/vehicles/tankprojectile.dts";
   directDamage        = 10;
   radiusDamage        = 10;
   damageRadius        = 0.5;
   explosion           = TankSecondaryExplosion;
   particleEmitter     = TankSecondarySmokeEmitter;

   muzzleVelocity      = 100;
   velInheritFactor    = 1;

   armingDelay         = 0.3;
   lifetime            = 2000;
   fadeDelay           = 1500;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = true;
   gravityMod = 0.10;

   hasLight    = true;
   lightRadius = 1.5;
   lightColor  = "0.56 0.36 0.26 1.0";

};
//-----------------------------------------------------------------------------
// Ammo Item
datablock ItemData(TankSecondaryWeaponAmmo)
{
   // Mission editor category
   category = "Ammo";

   // Add the Ammo namespace as a parent.  The ammo namespace provides
   // common ammo related functions and hooks into the inventory system.
   className = "Ammo";

   // Basic Item properties
   shapeFile = "art/shapes/weapons/SwarmGun/rocket.dts";
   mass = 1;
   elasticity = 0.2;
   friction = 0.6;

   // Dynamic properties defined by the scripts
   pickUpName = "tank primary ammo";
   maxInventory = 1000;
};
//--------------------------------------------------------------------------
// AssaultRifle shell that's ejected during reload.
datablock DebrisData(TankSecondaryShell)
{
   shapeFile = "art/shapes/vehicles/tankshell.dts";
   lifetime = 3.0;
   minSpinSpeed = 300.0;
   maxSpinSpeed = 400.0;
   elasticity = 0.5;
   friction = 0.2;
   numBounces = 5;
   staticOnMaxBounce = true;
   snapOnMaxBounce = false;
   fade = true;
};
//--------------------------------------------------------------------------
// Weapon Item.  This is the item that exists in the world, i.e. when it's
// been dropped, thrown or is acting as re-spawnable item.  When the Weapon
// is mounted onto a shape, the WeaponImage is used.
datablock ItemData(TankSecondaryWeapon)
{
   // Mission editor category
   category = "Weapon";

   // Hook into Item Weapon class hierarchy. The Weapon namespace
   // provides common Weapon handling functions in addition to hooks
   // into the inventory system.
   className = "Weapon";

   // Basic Item properties
   shapeFile = "art/shapes/vehicles/tankweapon.dts";
   mass = 1;
   elasticity = 0.2;
   friction = 0.6;
   emap = false;

	// Dynamic properties defined by the scripts
	pickUpName = "a machine gun";
	image = TankSecondaryWeaponImage;
};
//--------------------------------------------------------------------------
// Weapon image which does all the work.  Images do not normally exist in
// the world, they can only be mounted on ShapeBase objects.
datablock ShapeBaseImageData(TankSecondaryWeaponImage)
{
   // Basic Item properties
   shapeFile = "art/shapes/vehicles/tankweapon.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first  rendering.
   mountPoint = 3;

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this AssaultRifle doesn't actually fire from the muzzle point,
   // we need to turn this off.
   correctMuzzleVector = false;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = TankSecondaryWeapon;
   ammo = TankSecondaryWeaponAmmo;
   projectile = TankSecondaryProjectile;
   projectileType = Projectile;
   casing = TankSecondaryShell;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
   stateName[0]                     = "Preactivate";
   stateTransitionOnLoaded[0]       = "Activate";
   stateTransitionOnNoAmmo[0]       = "NoAmmo";

   // Activating the gun.  Called when the AssaultRifle is first
   // mounted and there is ammo.
   stateName[1]                     = "Activate";
   stateTransitionOnTimeout[1]      = "Ready";
   stateTimeoutValue[1]             = 1.0;
   stateSequence[1]                 = "Activate";

   // Ready to fire, just waiting for the trigger
   stateName[2]                     = "Ready";
   stateTransitionOnNoAmmo[2]       = "NoAmmo";
   stateTransitionOnTriggerDown[2]  = "Fire";

   // Fire the AssaultRifle. Calls the fire script which does
   // the actual work.
   stateName[3]                     = "Fire";
   stateTransitionOnTimeout[3]      = "Reload";
   stateTimeoutValue[3]             = 0.04;
   stateFire[3]                     = true;
   stateRecoil[3]                   = LightRecoil;
   stateAllowImageChange[3]         = false;
   stateSequence[3]                 = "Fire";
   stateScript[3]                   = "onFire";
   stateEmitter[3]                  = TankSecondaryFireEmitter;
   stateEmitterTime[3]              = 0.12;

   // Play the reload animation, and transition into
   stateName[4]                     = "Reload";
   stateTransitionOnNoAmmo[4]       = "NoAmmo";
   stateTransitionOnTimeout[4]      = "Ready";
   stateTimeoutValue[4]             = 0.04;
   stateAllowImageChange[4]         = false;
   stateSequence[4]                 = "Reload";
   stateEjectShell[4]               = true;

   // No ammo in the AssaultRifle, just idle until something
   // shows up. Play the dry fire sound if the trigger is
   // pulled.
   stateName[5]                     = "NoAmmo";
   stateTransitionOnAmmo[5]         = "Reload";
   stateSequence[5]                 = "NoAmmo";
   stateTransitionOnTriggerDown[5]  = "DryFire";

   // No ammo dry fire
   stateName[6]                     = "DryFire";
   stateTimeoutValue[6]             = 0.04;
   stateTransitionOnTimeout[6]      = "NoAmmo";
};
//-----------------------------------------------------------------------------
// TankTertiaryWeapon
// This could be split off to tankTertiaryWeapon.cs but it is basically a "copy"
// of TankSecondaryWeapon
//-----------------------------------------------------------------------------
datablock ItemData(TankTertiaryWeaponAmmo : TankSecondaryWeaponAmmo)
{
   pickUpName = "tank tertiary ammo";
};
datablock ItemData(TankTertiaryWeapon : TankSecondaryWeapon)
{
   image = TankTertiaryWeaponImage;
};
datablock ShapeBaseImageData(TankTertiaryWeaponImage : TankSecondaryWeaponImage)
{
   // Specify mount point & offset for 3rd person, and eye offset
   // for first  rendering.
   mountPoint = 4;
};
