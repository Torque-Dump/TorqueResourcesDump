//-----------------------------------------------------------------------------
// Basic Buggy
// Information extacted from the shape.
// Wheel Sequences
//    spring#        Wheel spring motion: time 0 = wheel fully extended,
//                   the hub must be displaced, but not directly animated
//                   as it will be rotated in code.
// Other Sequences
//    steering       Wheel steering: time 0 = full right, 0.5 = center
//    breakLight     Break light, time 0 = off, 1 = breaking
//
// Wheel Nodes
//    hub#           Wheel hub, the hub must be in it's upper position
//                   from which the springs are mounted.
// The steering and animation sequences are optional.
// The center of the shape acts as the center of mass for the car.
//-----------------------------------------------------------------------------
datablock SFXProfile(buggyEngineSound)
{
   filename       = "art/sound/vehicles/engineidle";
   description    = AudioClosestLooping3d;
   preload        = true;
};
//----------------------------------------------------------------------------
datablock WheeledVehicleTire(DefaultCarTire)
{
   // Tires act as springs and generate lateral and longitudinal
   // forces to move the vehicle. These distortion/spring forces
   // are what convert wheel angular velocity into forces that
   // act on the rigid body.
   shapeFile               = "art/shapes/vehicles/buggy/wheel.dts";
   staticFriction          = 4.2;
   kineticFriction         = 3.15;
   // Spring that generates lateral tire forces
   lateralForce            = 18000;
   lateralDamping          = 6000;
   lateralRelaxation       = 1;
   // Spring that generates longitudinal tire forces
   longitudinalForce       = 18000;
   longitudinalDamping     = 4000;
   longitudinalRelaxation  = 1;
};
datablock WheeledVehicleSpring(DefaultCarSpring)
{
   // Wheel suspension properties
   length                  = 0.85;             // Suspension travel
   force                   = 2800;              // Spring force
   damping                 = 3600;             // Spring damping
   antiSwayForce           = 3;         // Lateral anti-sway force
};
datablock WheeledVehicleData(DefaultCar)
{
   category    = "Vehicles";
   shapeFile   = "art/shapes/vehicles/buggy/buggy.dts";
   emap        = 1;

   totalMountPoints           = 1;        //Dynamic ALL MountPounts script use only
   numMountPoints             = 1;
   numWeaponPoints            = 0;
   numImagePoints             = 0;
   
   //------------ Driver ---------------------
   pilotNode                  = 0;
   actionMapForMountPoint[0]  = "wheeledVehicleDriverMap";
   mountPose[0]               = "Sitting";
   mountPointTransform[0]     = "0 0 -1.5 1 0 0 0";
   isProtectedMountPoint[0]   = false;
   mountCloaked[0]            = true;
   unmountWeaponOnMount[0]    = true;
   //------------  ---------------------

   shadowEnable               = true; 
   shadowSize                 = 256;
   shadowProjectionDistance   = 14.0;

   useEyePoint                = true;  // Use the vehicle's camera node rather than the player's
   
	freeCamPitch               = false;	// true = ignore values and rotate 360 degrees.
	minCamPitchAngle           = -1.0;  // Lowest angle (radians) the player can look
	maxCamPitchAngle           =  0.4;  // Highest angle (radians) the player can look

	freeCamYaw                 = false;	// true = ignore values and rotate 360 degrees.			
	minCamYawAngle             = -2.0;  // Left turn (radians) the player can look
	maxCamYawAngle             =  2.0;  // Right turn (radians) the player can look

	maxTurnSpeed               = 6.0;  // degrees/second 
   maxPitchSpeed			      = 15.0;		   
   maxYawSpeed				      = 15.0;
   
   maxSteeringAngle           = 0.385;  // Maximum steering angle, should match animation

   // 3rd person camera settings
   cameraRoll                 = false;         // Roll the camera with the vehicle
   cameraMaxDist              = 4.8;         // Far distance from vehicle
   cameraOffset               = 1.5;        // Vertical offset from camera mount point
   cameraLag                  = 0.26;           // Velocity lag of camera
   cameraDecay                = 1.25;        // Decay per sec. rate of velocity lag

   // Rigid Body
   mass                       = 380;
   massCenter                 = "0 -0.2 0";    // Center of mass for rigid body
   massBox                    = "0 0 0";         // Size of box used for moment of inertia,
                              // if zero it defaults to object bounding box
   drag                       = 0.6;                // Drag coefficient
   bodyFriction               = 0.6;
   bodyRestitution            = 0.4;
   minImpactSpeed             = 5;        // Impacts over this invoke the script callback
   softImpactSpeed            = 5;       // Play SoftImpact Sound
   hardImpactSpeed            = 15;      // Play HardImpact Sound
   integration                = 8;           // Physics integration: TickSec/Rate
   collisionTol               = 0.1;        // Collision distance tolerance
   contactTol                 = 0.1;          // Contact velocity tolerance

   // Engine
   engineTorque               = 3300;       // Engine power
   engineBrake                = 600;         // Braking when throttle is 0
   brakeTorque                = 8000;        // When brakes are applied
   maxWheelSpeed              = 50;           // Engine scale by current speed / max speed

   // Energy
   maxEnergy                  = 100;
   jetForce                   = 3000;
   minJetEnergy               = 30;
   jetEnergyDrain             = 2;
   maxDamage                  = 400.0;
   destroyedLevel             = 300.0;

   // Sounds
   engineSound                = BuggyEngineSound;
//   squealSound       = ScoutSquealSound;
//   wheelImpactSound  = WheelImpactSound;
   softImpactSound            = "softImpact";
   hardImpactSound            = "hardImpact";
   //dustEmitter       = "TireEmitter";
   //dustHeight        = "1";

   // Tires and Springs
   // To try and keep Flexible
   // Always Order Tire/Springs
   // Front Tires first
   // Then Rear Tires
   tireEmitter                = "TireEmitter";
   wheelCount                 = 4;       //2Front / 2Rear
   uniqueWheels               = false;
   fourwheelSteer             = false;
   fourwheelPower             = false;
   attachTire[0]              = DefaultCarTire;
   useSpring[0]               = DefaultCarSpring;   

   // Headlights and BrakeLights
   //headlightLeftSlot   = 28;
   //headlightRightSlot  = 27;
   //brakelightLeftSlot  = 29;
   //brakelightRightSlot = 30;

   // Damage Emitters, Offsets, etc.
   damageEmitter[0]           = SuperficialDamageEmitter;
   damageEmitter[1]           = SevereDamageEmitter;
   damageEmitter[2]           = OnDestroyedEmitter;
   damageEmitterOffset[0]     = "0.8 1.5 2.0";
   damageEmitterOffset[1]     = "0.0 0.0 0.5 ";
   damageEmitterOffset[2]     = "0.0 0.0 0.0 ";
   damageLevelTolerance[0]    = 0.3;
   damageLevelTolerance[1]    = 0.7;
   numDmgEmitterAreas         = 1;
   // Explosion
   explosion                  = StrykerMainExplosion;
   renderWhenDestroyed        = false;

   // Dynamic fields accessed via script
   nameTag                    = 'Buggy';
   maxDismountSpeed           = 10;
   maxMountSpeed              = 5;
};
