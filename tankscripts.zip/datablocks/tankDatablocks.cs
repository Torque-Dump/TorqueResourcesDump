//-----------------------------------------------
//Tank Datablocks
//-----------------------------------------------
// Sound System
datablock SFXProfile(ShermanIdleSound)
{
   preload = "1";
   description = "AudioCloseLoop3D";
   fileName = "art/sound/cheetah/cheetah_engine.ogg";
};
datablock SFXProfile(ShermanEngineSound)
{
   preload = "1";
   description = "AudioCloseLoop3D";
   fileName = "art/sound/cheetah/cheetah_engine.ogg";
};
//-----------------------------------------------
datablock ParticleData(TankTireParticle)
{
   textureName          = "art/shapes/particles/dustParticle";
   dragCoefficient      = 2.0;
   gravityCoefficient   = -0.1;
   inheritedVelFactor   = 0.1;
   constantAcceleration = 0.0;
   lifetimeMS           = 1000;
   lifetimeVarianceMS   = 400;
   colors[0]     = "0.46 0.36 0.26 1.0";
   colors[1]     = "0.46 0.46 0.36 0.0";
   sizes[0]      = 1.0;
   sizes[1]      = 4.0;
};
datablock ParticleEmitterData(TankTireEmitter)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 10;
   ejectionVelocity = "14.58";
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TankTireParticle";
   blendStyle = "ADDITIVE";
};
//-----------------------------------------------------------------------------
// Sherman Tires
datablock TankVehicleTire(ShermanOuterFrontWheel)
{
   shapeFile = "art/shapes/vehicles/sherman/sherman_fouter.dts";
   staticFriction = 4.2;
   kineticFriction = "1";
   // Spring that generates lateral tire forces
   lateralForce = 18000;
   lateralDamping = 6000;
   lateralRelaxation = 1;
   // Spring that generates longitudinal tire forces
   longitudinalForce = 18000;
   longitudinalDamping = 4000;
   longitudinalRelaxation = 1;
};
datablock TankVehicleTire(ShermanOuterRearWheel)
{
   shapeFile = "art/shapes/vehicles/sherman/sherman_bouter.dts";
   staticFriction = "4.2";
   kineticFriction = "1";
   // Spring that generates lateral tire forces
   lateralForce = "19000";
   lateralDamping = 6000;
   lateralRelaxation = 1;
   // Spring that generates longitudinal tire forces
   longitudinalForce = 18000;
   longitudinalDamping = 4000;
   longitudinalRelaxation = 1;
};
datablock TankVehicleTire(ShermanInnerWheel)
{
   shapeFile = "art/shapes/vehicles/sherman/sherman_inner.dts";
   staticFriction = 7.2;
   kineticFriction = "1";
   // Spring that generates lateral tire forces
   lateralForce = 18000;
   lateralDamping = 6000;
   lateralRelaxation = 1;
   // Spring that generates longitudinal tire forces
   longitudinalForce = 18000;
   longitudinalDamping = 4000;
   longitudinalRelaxation = 1;
};
//-----------------------------------------------
// Abrams Tires
datablock TankVehicleTire(AbramsOuterFrontWheel : ShermanOuterFrontWheel)
{
   shapeFile = "art/shapes/vehicles/abrams/abrams_fouter.dts";
   staticFriction = 4.2;
   kineticFriction = "1";
   // Spring that generates lateral tire forces
   lateralForce = 18000;
   lateralDamping = 6000;
   lateralRelaxation = 1;
   // Spring that generates longitudinal tire forces
   longitudinalForce = 18000;
   longitudinalDamping = 4000;
   longitudinalRelaxation = 1;
};
datablock TankVehicleTire(AbramsOuterRearWheel : ShermanOuterRearWheel)
{
   shapeFile = "art/shapes/vehicles/abrams/abrams_bouter.dts";
   staticFriction = "4.2";
   kineticFriction = "1";
   // Spring that generates lateral tire forces
   lateralForce = "19000";
   lateralDamping = 6000;
   lateralRelaxation = 1;
   // Spring that generates longitudinal tire forces
   longitudinalForce = 18000;
   longitudinalDamping = 4000;
   longitudinalRelaxation = 1;
};
datablock TankVehicleTire(AbramsInnerWheel : ShermanInnerWheel)
{
   shapeFile = "art/shapes/vehicles/abrams/abrams_inner.dts";
   staticFriction = 7.2;
   kineticFriction = "1";
   // Spring that generates lateral tire forces
   lateralForce = 18000;
   lateralDamping = 6000;
   lateralRelaxation = 1;
   // Spring that generates longitudinal tire forces
   longitudinalForce = 18000;
   longitudinalDamping = 4000;
   longitudinalRelaxation = 1;
};
//-----------------------------------------------
// Sherman Springs
datablock TankVehicleSpring(ShermanOuterSpring)
{
   length = 0.05;             // Suspension travel
   force = 800;              // Spring force
   damping = 600;             // Spring damping
   antiSwayForce = 3;         // Lateral anti-sway force
};
datablock TankVehicleSpring(ShermanInnerSpring)
{
   length = 0.35;             // Suspension travel
   force = 2800;              // Spring force
   damping = 3600;             // Spring damping
   antiSwayForce = 3;         // Lateral anti-sway force
};
//-----------------------------------------------
// Abrams Springs
datablock TankVehicleSpring(AbramsOuterSpring : ShermanOuterSpring)
{
   length = 0.05;             // Suspension travel
   force = 800;              // Spring force
   damping = 600;             // Spring damping
   antiSwayForce = 3;         // Lateral anti-sway force
};
datablock TankVehicleSpring(AbramsInnerSpring : ShermanInnerSpring)
{
   length = 0.35;             // Suspension travel
   force = 2800;              // Spring force
   damping = 3600;             // Spring damping
   antiSwayForce = 3;         // Lateral anti-sway force
};
//-----------------------------------------------------------------------
//    Sherman Tank
//-----------------------------------------------------------------------
datablock TankVehicleData(ShermanTank)
{
   category    = "Tanks";
   shapeFile   = "art/shapes/vehicles/sherman/sherman_hull.dts";
   emap        = 1;

   //==================================================
   // These are REQUIRED fields to have for any vehicle
   totalMountPoints           = 5;        //Dynamic ALL MountPounts script use only
   numMountPoints             = 2;        // Driver/Passengers

   //----------- Driver ----------------------------------
   pilotNode                  = 0;
   actionMapForMountPoint[0]  = "wheeledVehicleDriverMap";
   mountPose[0]               = "Sitting";
   mountPointTransform[0]     = "0 0 -1.0 1 0 0 0";
   isProtectedMountPoint[0]   = true;
   mountCloaked[0]            = false;
   unmountWeaponOnMount[0]    = true;

   actionMapForMountPoint[1]  = "wheeledVehiclePassengerMap";
   mountPose[1]               = "0";
   mountPointTransform[1]     = "0 0 -1.0 1 0 0 0";
   isProtectedMountPoint[1]   = false;
   mountCloaked[1]            = false;
   unmountWeaponOnMount[1]    = false;
   //----------- ----------------------------------

   useEyePoint                = true;  // Use the vehicle's camera node rather than the player's
   shadowEnable               = true; 
   shadowSize                 = 256;
   shadowProjectionDistance   = 14.0;

	freeCamPitch               = false;	// true = ignore values and rotate 360 degrees.
	minCamPitchAngle           = -1.0;  // Lowest angle (radians) the player can look
	maxCamPitchAngle           =  0.4;  // Highest angle (radians) the player can look

	freeCamYaw                 = false;	// true = ignore values and rotate 360 degrees.			
	minCamYawAngle             = -2.0;  // Left turn (radians) the player can look
	maxCamYawAngle             =  2.0;  // Right turn (radians) the player can look

	maxTurnSpeed               = 10.0;  // degrees/second 
   maxPitchSpeed			      = 20.0;		   
   maxYawSpeed				      = 20.0;
   		   
   maxSteeringAngle           = 0.585; // Maximum steering angle, should match animation

   //Suspension Settings
   primaryRecoil              = 10.0;  // Recoil amount for the primary weapon
   suspensionRange            = 0.95;  // proportion of wheel size for wheel to move up/down
   springRangeX               = 0.02;  // How much the tank can rock back and forth
   springRangeY               = 0.02;  // How much the tank can rock side to side
   springVelScale             = 1.0;   // How fast the springs rock
   springLooseness            = 0.8;   // How "tight" the springs are (0 = loose, 1.0 = tight)

   // 3rd person camera settings
   cameraRoll                 = false; // Roll the camera with the vehicle
   cameraMaxDist              = 7.8;   // Far distance from vehicle
   cameraOffset               = 1.0;   // Vertical offset from camera mount point
   cameraLag                  = "0.3"; // Velocity lag of camera
   cameraDecay                = 1.25;  // Decay per sec. rate of velocity lag

   // Rigid Body
   mass                       = "1100";
   massCenter                 = "0 -0.15 0";  // Center of mass for rigid body
   massBox                    = "0 0 0";     // Size of box used for moment of inertia,
                                       // if zero it defaults to object bounding box
   drag                       = 0.6;   // Drag coefficient
   bodyFriction               = 0.6;
   bodyRestitution            = 0.4;
   minImpactSpeed             = 5;     // Impacts over this invoke the script callback
   softImpactSpeed            = 5;     // Play SoftImpact Sound
   hardImpactSpeed            = 15;    // Play HardImpact Sound
   integration                = 8;     // Physics integration: TickSec/Rate
   collisionTol               = "0.1"; // Collision distance tolerance
   contactTol                 = "0.1"; // Contact velocity tolerance

   // Engine
   engineTorque               = 4300;     // Engine power
   engineBrake                = "1000";   // Braking when throttle is 0
   brakeTorque                = "8000";   // When brakes are applied
   maxWheelSpeed              = 25;       // Engine scale by current speed / max speed

   // Energy / Damage
   maxEnergy                  = 100;
   maxDamage                  = 2500.0;
   destroyedLevel             = 2100.0;

   engineSoundA               = ShermanIdleSound;
   engineSoundB               = ShermanEngineSound;
   softImpactSound            = softImpact;
   hardImpactSound            = hardImpact;
   //dustEmitter          = "TankTireEmitter";
   //dustHeight           = "1";

   // Tires and Springs
   tireEmitter                = "TankTireEmitter";
   numInnerWheelsPerSide      = 6;    // in addition to the 2 outer wheels per side
   tankWheelCount             = 16;   // 2Front / 2Rear / numInnerWheelsPerSide * 2
   attachTire[0]              = ShermanOuterFrontWheel;
   useSpring[0]               = ShermanOuterSpring;   
   attachTire[1]              = ShermanOuterRearWheel;
   useSpring[1]               = ShermanOuterSpring;   
   attachTire[2]              = ShermanInnerWheel;
   useSpring[2]               = ShermanInnerSpring;   

   // Dynamic fields accessed via script
   nameTag                    = 'Sherman';
   maxDismountSpeed           = 10;
   maxMountSpeed              = 5;

   // Object List..
   numWeaponPoints            = 3;
   numImagePoints             = 3;
   mountTrigger[0]            = 0;     //Trigger[0] assigned to ImageMountPoint[ mountTrigger[0] ]
   mountTrigger[1]            = 1;     //Trigger[1] assigned to ImageMountPoint[ mountTrigger[1] ]
   mountTrigger[2]            = 1;     //Trigger[1] assigned to ImageMountPoint[ mountTrigger[2] ]
   //
   objectImage[0]             = TankPrimaryWeaponImage;
   objectWeapon[0]            = true;  //This is a weapon Image   
   objectItem[0]              = TankPrimaryWeapon;
   objectAmmo[0]              = TankPrimaryWeaponAmmo;
   objectAmmoCnt[0]           = 50;
   //   
   objectImage[1]             = TankSecondaryWeaponImage;
   objectWeapon[1]            = true;
   objectItem[1]              = TankSecondaryWeapon;
   objectAmmo[1]              = TankSecondaryWeaponAmmo;
   objectAmmoCnt[1]           = 750;
   //
   objectImage[2]             = TankTertiaryWeaponImage;
   objectWeapon[2]            = true;
   objectItem[2]              = TankTertiaryWeapon;
   objectAmmo[2]              = TankTertiaryWeaponAmmo;
   objectAmmoCnt[2]           = 750;
   
   // Allowable Inventory Items
   maxInv[TankPrimaryWeapon]        = 1;
   maxInv[TankPrimaryWeaponAmmo]    = 100;
   maxInv[TankSecondaryWeapon]      = 1;
   maxInv[TankSecondaryWeaponAmmo]  = 1000;
   // This tank has 2 machine guns on the front
   maxInv[TankTertiaryWeapon]       = 1;
   maxInv[TankTertiaryWeaponAmmo]   = 1000;
};
//-----------------------------------------------------------------------
//    Abrams Tank
//-----------------------------------------------------------------------
datablock TankVehicleData(AbramsTank : ShermanTank)
{
   shapeFile = "art/shapes/vehicles/abrams/abrams_hull.dts";

   totalMountPoints           = 4;        //Dynamic ALL MountPounts script use only
   numMountPoints             = 2;        // Driver/Passengers

   //----------- Driver ----------------------------------
   pilotNode                  = 0;
   actionMapForMountPoint[0]  = "wheeledVehicleDriverMap";
   mountPose[0]               = "Sitting";
   mountPointTransform[0]     = "0 0 -1.0 1 0 0 0";
   isProtectedMountPoint[0]   = true;
   mountCloaked[0]            = false;
   unmountWeaponOnMount[0]    = true;

   actionMapForMountPoint[1]  = "wheeledVehiclePassengerMap";
   mountPose[1]               = "0";
   mountPointTransform[1]     = "2.5 -2.5 -1.0 1 0 0 0";
   isProtectedMountPoint[1]   = false;
   mountCloaked[1]            = false;
   unmountWeaponOnMount[1]    = false;
   //----------- ----------------------------------

	freeCamPitch               = false;	// true = ignore values and rotate 360 degrees.
	minCamPitchAngle           = -1.0;  // Lowest angle (radians) the player can look
	maxCamPitchAngle           =  0.4;  // Highest angle (radians) the player can look

	freeCamYaw                 = false;	// true = ignore values and rotate 360 degrees.			
	minCamYawAngle             = -2.0;  // Left turn (radians) the player can look
	maxCamYawAngle             =  2.0;  // Right turn (radians) the player can look

	maxTurnSpeed               = 10.0;  // degrees/second 
   maxPitchSpeed			      = 20.0;		   
   maxYawSpeed				      = 20.0;
   		   
   maxSteeringAngle           = 0.585; // Maximum steering angle, should match animation

   //Suspension Settings
   primaryRecoil              = 10.0;  // Recoil amount for the primary weapon
   suspensionRange            = 0.95;  // proportion of wheel size for wheel to move up/down
   springRangeX               = 0.02;  // How much the tank can rock back and forth
   springRangeY               = 0.02;  // How much the tank can rock side to side
   springVelScale             = 1.0;   // How fast the springs rock
   springLooseness            = 0.8;   // How "tight" the springs are (0 = loose, 1.0 = tight)

   // 3rd person camera settings
   cameraRoll                 = false; // Roll the camera with the vehicle
   cameraMaxDist              = 7.8;   // Far distance from vehicle
   cameraOffset               = 1.0;   // Vertical offset from camera mount point
   cameraLag                  = "0.3"; // Velocity lag of camera
   cameraDecay                = 1.25;  // Decay per sec. rate of velocity lag

   // Rigid Body
   mass                       = "900";
   massCenter                 = "0 -0.25 0";  // Center of mass for rigid body
   massBox                    = "0 0 0";     // Size of box used for moment of inertia,
                                       // if zero it defaults to object bounding box
   drag                       = 0.6;   // Drag coefficient
   bodyFriction               = 0.6;
   bodyRestitution            = 0.4;
   minImpactSpeed             = 5;     // Impacts over this invoke the script callback
   softImpactSpeed            = 5;     // Play SoftImpact Sound
   hardImpactSpeed            = 15;    // Play HardImpact Sound
   integration                = 8;     // Physics integration: TickSec/Rate
   collisionTol               = "0.1"; // Collision distance tolerance
   contactTol                 = "0.1"; // Contact velocity tolerance

   // Engine
   engineTorque               = 4300;     // Engine power
   engineBrake                = "1000";   // Braking when throttle is 0
   brakeTorque                = "8000";   // When brakes are applied
   maxWheelSpeed              = 30;       // Engine scale by current speed / max speed

   // Energy / Damage
   maxEnergy                  = 100;
   maxDamage                  = 3000.0;
   destroyedLevel             = 2900.0;

   engineSoundA               = ShermanIdleSound;
   engineSoundB               = ShermanEngineSound;
   softImpactSound            = softImpact;
   hardImpactSound            = hardImpact;
   //dustEmitter          = "TankTireEmitter";
   //dustHeight           = "1";

   // Tires and Springs
   tireEmitter                = "TankTireEmitter";
   numInnerWheelsPerSide      = 7;    // in addition to the 2 outer wheels per side
   tankWheelCount             = 18;   // 2Front / 2Rear / numInnerWheelsPerSide * 2
   attachTire[0]              = AbramsOuterFrontWheel;
   useSpring[0]               = AbramsOuterSpring;   
   attachTire[1]              = AbramsOuterRearWheel;
   useSpring[1]               = AbramsOuterSpring;   
   attachTire[2]              = AbramsInnerWheel;
   useSpring[2]               = AbramsInnerSpring;   

   // Weapons List..
   numWeaponPoints            = 2;
   numImagePoints             = 2;
   mountTrigger[0]            = 0;     //Trigger[0] assigned to MountPoint[ mountTrigger[0] ]
   mountTrigger[1]            = 1;     //Trigger[1] assigned to MountPoint[ mountTrigger[1] ]
   //
   objectImage[0]             = TankPrimaryWeaponImage;
   objectWeapon[0]            = true;
   objectItem[0]              = TankPrimaryWeapon;
   weaponAmmo[0]              = TankPrimaryWeaponAmmo;
   weaponAmmoCnt[0]           = 10;
   //
   objectImage[1]             = TankSecondaryWeaponImage;
   objectWeapon[1]            = true;
   objectItem[1]              = TankSecondaryWeapon;
   objectAmmo[1]              = TankSecondaryWeaponAmmo;
   objectAmmoCnt[1]           = 500;
   
   // Dynamic fields accessed via script
   nameTag                    = 'Abrams';

   // Allowable Inventory Items
   maxInv[TankPrimaryWeapon]        = 1;
   maxInv[TankPrimaryWeaponAmmo]    = 100;
   maxInv[TankSecondaryWeapon]      = 1;
   maxInv[TankSecondaryWeaponAmmo]  = 1000;
};
//-----------------------------------------------------------------------
