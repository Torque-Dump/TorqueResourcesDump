//------------------------------------------------------------
// Used by Several Vehicles
//------------------------------------------------------------
datablock ParticleData(TireParticle)
{
   dragCoefficient = "1.99902";
   gravityCoefficient = "-0.100122";
   inheritedVelFactor = "0.0998043";
   lifetimeMS = "1689";
   lifetimeVarianceMS = "400";
   textureName = "art/shapes/particles/dustParticle";
   animTexName = "art/shapes/particles/dustParticle";
   colors[0] = "0.456693 0.354331 0.259843 1";
   colors[1] = "0.456693 0.456693 0.354331 0";
   sizes[0] = "3.125";
   sizes[1] = "7.29167";
   sizes[2] = "5.20833";
   sizes[3] = "13.5417";
};
datablock ParticleEmitterData(TireEmitter)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 10;
   ejectionVelocity = "14.58";
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "TireParticle";
   blendStyle = "ADDITIVE";
};
