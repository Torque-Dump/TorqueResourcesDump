//-----------------------------------------------------------------------------
// Torque Game Engine Advanced
// Copyright (C) GarageGames.com, Inc.
// Convertion to TGEA 1.8.1 with karakurty
//-----------------------------------------------------------------------------

#ifndef _GUIRADARCTRL_H_
#define _GUIRADARCTRL_H_

#ifndef _GUIBITMAPCTRL_H_
#include "gui/controls/guiBitmapCtrl.h"
#endif

/// Renders a bitmap.
class GuiRadarCtrl : public GuiBitmapCtrl //GuiControl
{
private:
	typedef /*GuiControl*/ GuiBitmapCtrl Parent;
	Point3F mMyCoords;

protected:
	// Radar
    StringTableEntry mRadarBitmapName;
	StringTableEntry mBlipUpName;
	StringTableEntry mBlipLevelName;
	StringTableEntry mBlipBelowName;

    GFXTexHandle mRadarTextureObject;
    GFXTexHandle mRadarDot;
    GFXTexHandle mRadarUp;
    GFXTexHandle mRadarDown;

	bool mShowRadar;

	bool mShowVehicles;
	bool mShowPlayers;
	bool mShowShapeBase;
    bool mShowBots;
	bool mShowFrame;

	F32 mLevelRange;
	F32 mRadarRadiusRange;

	bool mHideAll;

	//Compass
	StringTableEntry mCompassBitmapName;
	GFXTexHandle mCompassTextureObject;

	bool mShowCompass;

	// <MH>
	// Map
	StringTableEntry mMapBitmapName;
	GFXTexHandle mMapTextureObject;

	bool mShowMap;

	F32 mCompassRotation;
	// </MH>

    Point2I startPoint;
    //bool mRadarWrap;

	GFXStateBlockRef mBlendDisabledStateBlock;
	GFXStateBlockRef mBeforeStateBlock;

public:
    //creation methods
    DECLARE_CONOBJECT(GuiRadarCtrl);
    GuiRadarCtrl();
    static void initPersistFields();

    //Parental methods
    bool onWake();
    void onSleep();
    void inspectPostApply();

    void setRadarBitmap(const char *name, bool resize = false);
    void setRadarBitmap(GFXTexHandle handle, bool resize = false);

	void setRadarLevelBlipBitmap(const char *name);
	void setRadarUpBlipBitmap(const char *name);
	void setRadarBelowBlipBitmap(const char *name);

	void setCompassBitmap(const char *name, bool resize = false);
	void setCompassBitmap(GFXTexHandle handle, bool resize = false);

	void setMapBitmap(const char *name);

	void setRadius(const F32 newRange);
	void setLevelRange(const F32 newLevelRange);

    S32 getWidth() const       { return ( (mRadarTextureObject == NULL) ? 0 : mRadarTextureObject->getWidth() ) ; }
    S32 getHeight() const      { return( (mRadarTextureObject == NULL) ? 0 : mRadarTextureObject->getHeight() ); }

	void setCompassRotation(const F32 rotation);

    void onRender(Point2I offset, const RectI &updateRect);

	void setupStateBlocks();
};

#endif
