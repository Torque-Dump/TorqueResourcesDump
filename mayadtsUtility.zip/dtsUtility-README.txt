----------

dtsUtility v1.0.6

Updated: July 17, 2005

----------

�2004-2005 by Danny Ngan
d@dannyngan.com
http://www.dannyngan.com

----------

Description:

dtsUtility is a GUI front-end for the Maya2DTS exporter for Garage Games'
Torque Game  Engine. It provides options for simplifying scene setup,
configuring export settings, and actual exporting of scene objects to DTS
and DSQ file formats.

For more information, see the accompanying readme file as well as the online
reference guide at the following URL:

http://www.dannyngan.com/torque/maya2dts/

----------

Installation:

1. Unzip the contents.

2. Place "dtsUtility.mel" into your user scripts directory.

	Windows: My Documents\maya\scripts
	OSX: Home folder, Library/Preferences/Alias/maya/scripts

3. In either the Script Editor or the Command Line, enter the following command:

	dtsUtility;

4. Start setting up your scene and exporting it for Torque. :)
	
Optional:
There is an image file included that can be used for a shelf button.

	Windows: dtsUtility.bmp
	OSX: dtsUtility.xpm
	
----------

Changelist:

v1.0.6 (July 17, 2005)
- Added options for setting up axis.
- Moved Setup submenu from the DTS menu to the main menu bar.
- Fixed bug with incorrectly placed bounding box axis when up axis is Z-up. Thanks to Jeff Gran for finding this.

v1.0.5d (November 4, 2004)
- Fixed a bug in Maya 6 where exporting fails if dtsNode does not already exist. Thanks to J. Alan Atherton for finding and fixing this.

v1.0.5c (October 29, 2004)
- Fixed a bug in "Export Settings" that would prevent the exporter from actually using the Export Settings under Maya 6.

v1.0.5b (September 20, 2004)
- Fixed a bug in the procedure getFilename that caused it to not properly load the scene's file name in Maya 6.

v1.0.5a (August 19, 2004)
- General cleanup and minor bug fixes.

v1.0.5 (July 27, 2004)
- Added "Export Settings".
	- Users can specify custom file names and export directories for the
	quick export buttons. These values will override exportDTS and exportDSQ
	directories specified in the project workspace settings.
	- Initial and default values are taken from the project workspace's
	exportDTS and exportDSQ settings.
	- Export settings are saved with the Maya scene file.
	- Optional global settings can used for all quick exports. 
	- Global settings use the default Maya project for initial/default settings. 
-Removed "Export and Dump".
-Added "Export Shape and Dump".
-Added "Export Sequence and Dump". 

v1.0.4a (July 21, 2004)
- Fixed a bug with the procedure "createNode" that would cause it to conflict with a default MEL procedure of the same name. It is named "createDtsNode" now.
- Changed the behavior of "Create Detail Marker". It no longer requires the existence of base01. It only parents to base01 if it exists.

v1.0.4 (July 12, 2004)
- Changed the default value for overrideDuration to -1, i.e. "off" by default (thanks to Mark McCoy for noticing this).
- Added "Renumber Selection" button for quickly adding detail levels to multiple shapes.
- Added "DTS" menu containing all dtsUtility options.
- Added "Setup" submenu with options to configure Maya for TGE.
- Added "Rendering Options" submenu with options for Visibility Animation and Two-Sided Materials.
- Added "Help" menu with links to documentation and support websites.
- Moved "Export and Dump" to the DTS menu.
- Moved Add and Delete Triggers to the Sequences submenu of the DTS menu.
- Moved Detail to the Detail Levels submenu of the DTS menu.
- Moved Eye, Cam, and Mount to the Utility Nodes submenu of the DTS menu.

v1.0.3b (May 23, 2004)
- Bounding box functions now check for both "bounds" and "Bounds".
- Fixed "Create Bounding Box" to work correctly in Maya 4.5 (thanks to Mark McCoy for finding this one).

v1.0.3a (May 4, 2004)
- Adjusted triggerState min and max values.

v1.0.3 (April 25, 2004)
- Added "Export Sequence" button to do a quick export of DSQ files.
- Renamed "Quick Export" to "Export Shape".
- Fixed a delete trigger bug in which the trigger window would not clear after the last trigger was deleted.
- Sequence Attributes window now displays the short names of attributes instead of the long names to reduce column widths.
- Rearranged window layout and button names to fit better in a smaller window.
- General cleanup of script for legibility (i.e. easier for me to read and update).

v1.0.2 (April 20, 2004)
- Added "eye", "cam", and "mount" node buttons.
- Moved "detail" button to new location.
- Added more information to the About window.
- "dtl/eye/cam/mnt" buttons now use the same general dtsCreateNode script.
- General cleanup and optimization of procedures.

v1.0.1 (April 18, 2004)
- With the exception of actual exporting, all options now work on Maya for OS X.
- Renamed "Sequence Manager" to "Sequence Attributes".
- All sequence attributes are now displayed in a spreadsheet editor window.
- Added "+ Trigger" and "- Trigger" buttons to the main window.
- Bounding box now auto-resizes to fit the selected objects/components.
- Additional popup dialogs boxes for errors/warnings.

v1.0 (March 16, 2004)
- First release!

----------
