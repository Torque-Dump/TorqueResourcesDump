The following files are the custom created files and what your Simple FPS Tutorial should look like when it is completed MINUS the files which are edited.

They are provided purely as examples of what the final scripts should look like.

The Simple FPS Tutorial fully covers their creatio, and that's what you should be doing.



Not included (so as not to overwrite the stock files) are:

game/art/datablocks/datablockExec.cs

game/scripts/server/scriptExec.cs

game/scripts/client/default.bind.cs

game/art/client/config.cs (this should be auto generated anyway)


Obviously without the edits/additions to these files, the custom scripts won't work. 

I'd suggest reading the Tutorial contained inside the "Documentation" folder for the relevant information on what to do.