datablock PlayerData(TutorialPlayer : DefaultPlayerData)
{

   runSurfaceAngle  = 50;//yorks edit - was 70

   //yorks additions
   maxInv[semiauto] = 1;
   maxInv[semiautoAmmo] = 20;
   maxInv[fullauto] = 1;
   maxInv[fullautoAmmo] = 30;
};