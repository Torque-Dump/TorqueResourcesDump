//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Demo Pathed AIPlayer.
//-----------------------------------------------------------------------------

datablock PlayerData(TutorialBot : DefaultPlayerData)
{
   shootingDelay = 500;
   
   maxDamage = 50;
   
   runSurfaceAngle  = 50;//yorks edit - was 70
   
   //yorks additions
   maxInv[semiauto] = 1;
   maxInv[semiautoAmmo] = 20;
   maxInv[fullauto] = 1;
   maxInv[fullautoAmmo] = 30;
};