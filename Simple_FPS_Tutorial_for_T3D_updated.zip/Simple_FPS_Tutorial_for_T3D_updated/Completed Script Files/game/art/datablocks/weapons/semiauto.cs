// ----------------------------------------------------------------------------
// Normal-fire Projectile Object
// ----------------------------------------------------------------------------

datablock ProjectileData(semiautoProjectile)
{
   projectileShapeName = "art/shapes/weapons/SwarmGun/rocket.dts";
   directDamage = 25;
   radiusDamage = 0;
   damageRadius = 0;
   areaImpulse = 2500;

   explosion = bulletImpact;
   waterExplosion = bulletWaterImpact;

   decal = bulletHoleDecal;
   splash = bulletSplashRingEmitter;

   muzzleVelocity = 100;
   velInheritFactor = 0.3;

   armingDelay = 0;
   lifetime = 2000; //(200 units range)
   fadeDelay = 1000;

   bounceElasticity = 0;
   bounceFriction = 0;
   isBallistic = false;
   gravityMod = 0.80;

   damageType = "bulletDamage";
};

// ----------------------------------------------------------------------------
// Ammo Item
// ----------------------------------------------------------------------------

datablock ItemData(semiautoAmmo)
{
   // Mission editor category
   category = "Ammo";

   // Add the Ammo namespace as a parent. The ammo namespace provides
   // common ammo related functions and hooks into the inventory system.
   className = "Ammo";

   // Basic Item properties
   shapeFile = "art/shapes/weapons/ramrifle/debris.dts";
   mass = 2;
   elasticity = 0.2;
   friction = 0.6;

   // Dynamic properties defined by the scripts
   pickUpName = "semiauto Ammo";
   maxInventory = 20;
};

// ----------------------------------------------------------------------------
// Weapon Item. This is the item that exists in the world,
// i.e. when it's been dropped, thrown or is acting as re-spawnable item.
// When the weapon is mounted onto a shape, the Image is used.
// ----------------------------------------------------------------------------

datablock ItemData(semiauto)
{
   // Mission editor category
   category = "Weapon";

   // Hook into Item Weapon class hierarchy. The weapon namespace
   // provides common weapon handling functions in addition to hooks
   // into the inventory system.
   className = "Weapon";

   // Basic Item properties
   shapefile = "art/shapes/weapons/ramrifle/base.dts";
   mass = 5;
   elasticity = 0.2;
   friction = 0.6;
   emap = true;

   // Dynamic properties defined by the scripts
   pickUpName = "semiauto Rifle";
   description = "semiauto Rifle";
   image = semiautoImage;

   // weaponHUD
   previewImage = 'ramrifle.png';
   reticle = 'reticle_ramrifle';
};

// ----------------------------------------------------------------------------
// Image which does all the work. Images do not normally exist in
// the world, they can only be mounted on ShapeBase objects.
// ----------------------------------------------------------------------------

datablock ShapeBaseImageData(semiautoImage)
{
   // Basic Item properties
   shapefile = "art/shapes/weapons/ramrifle/base.dts";
   emap = true;

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0.0 0.0 0.1";//"0.0 0.085 0.09";
   //rotation = "1 0 0 -20";
   eyeOffset = "0.25 0.4 -0.4"; // 0.25=right/left 0.5=forward/backward, -0.5=up/down

   // When firing from a point offset from the eye, muzzle correction
   // will adjust the muzzle vector to point to the eye LOS point.
   // Since this weapon doesn't actually fire from the muzzle point,
   // we need to turn this off.
   correctMuzzleVector = false;

   // Add the WeaponImage namespace as a parent, WeaponImage namespace
   // provides some hooks into the inventory system.
   className = "WeaponImage";

   // Projectile && Ammo.
   item = semiauto;
   ammo = semiautoAmmo;
   projectile = semiautoProjectile;
   projectileType = Projectile;

   // shell casings
   casing = semiautoShellCasing;
   shellExitDir = "1.0 0.3 1.0";
   shellExitOffset = "0.15 -0.56 -0.1";
   shellExitVariance = 15.0;
   shellVelocity = 3.0;

   // Let there be light - NoLight, ConstantLight, PulsingLight, WeaponFireLight.
   lightType = "WeaponFireLight";
   lightColor = "1.0 1.0 0.9";
   lightDuration = 200;
   lightRadius = 10;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly. The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
   stateName[0] = "Preactivate";
   stateTransitionOnLoaded[0] = "Activate";
   stateTransitionOnNoAmmo[0] = "NoAmmo";

   // Activating the gun.
   // Called when the weapon is first mounted and there is ammo.
   stateName[1] = "Activate";
   stateTransitionOnTimeout[1] = "Ready";
   stateTimeoutValue[1] = 0.6;
   stateSequence[1] = "Activate";

   // Ready to fire, just waiting for the trigger
   stateName[2] = "Ready";
   stateTransitionOnNoAmmo[2] = "NoAmmo";
   stateTransitionOnTriggerDown[2]  = "Fire";
   stateSequence[2] = "Ready";

   // Fire the weapon. Calls the fire script which does the actual work.
   stateName[3] = "Fire";
   stateTransitionOnTimeout[3] = "WaitForRelease";
   stateTimeoutValue[3] = 0.5;
   stateFire[3] = true;
   stateRecoil[3] = LightRecoil;
   stateAllowImageChange[3] = false;
   stateSequence[3] = "Fire";
   stateScript[3] = "onFire";
   stateSound[3] = bulletFireSound;

	// semi automatic - must release trigger
	stateName[4] = "WaitForRelease";
	stateTransitionOnTriggerUp[4] = "PostFire"; 

   // Check ammo
   stateName[5] = "PostFire";
   stateTransitionOnAmmo[5] = "Reload";
   stateTransitionOnNoAmmo[5] = "NoAmmo";

   // Play the reload animation, and transition into
   stateName[6] = "Reload";
   stateTransitionOnTimeout[6] = "Ready";
   stateTimeoutValue[6] = 0.5;
   stateAllowImageChange[6] = false;
   stateSequence[6] = "Reload";
   stateEjectShell[6] = false; // set to true to enable shell casing eject
   stateSound[6] = bulletReloadSound;

   // No ammo in the weapon, just idle until something shows up.
   // Play the dry fire sound if the trigger iS pulled.
   stateName[7] = "NoAmmo";
   stateTransitionOnAmmo[7] = "Reload";
   stateSequence[7] = "NoAmmo";
   stateTransitionOnTriggerDown[7] = "DryFire";

   // No ammo dry fire
   stateName[8] = "DryFire";
   stateTimeoutValue[8] = 1.0;
   stateTransitionOnTimeout[8] = "NoAmmo";
   stateSound[8] = bulletFireEmptySound;

};
