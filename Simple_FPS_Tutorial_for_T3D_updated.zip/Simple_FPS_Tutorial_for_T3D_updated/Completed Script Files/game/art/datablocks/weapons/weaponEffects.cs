// ----------------------------------------------------------------------------
// Sound profiles
// ----------------------------------------------------------------------------

datablock SFXProfile(bulletFireSound)
{
   filename = "art/sound/weapons/relbow_mono_01";
   description = AudioClose3d;
   preload = true;
};

datablock SFXProfile(bulletFireEmptySound)
{
   filename = "art/sound/metalstep_mono_01";
   description = AudioClose3d;
   preload = true;
};

datablock SFXProfile(bulletReloadSound)
{
   filename = "art/sound/metalstep_mono_01";
   description = AudioClose3d;
   preload = true;
};

datablock SFXProfile(bulletExplosionSound)
{
   filename = "art/sound/lgtStep_mono_01";
   description = AudioDefault3d;
   preload = true;
};

datablock SFXProfile(bulletSplashSound)
{
   filename = "art/sound/waterstep_mono_01";
   description = AudioDefault3d;
   preload = true;
};

// different audio for different weapon

datablock SFXProfile(fullautoFireSound)
{
   filename = "art/sound/weapons/explosion_mono_01";
   description = AudioClose3d;
   preload = true;
};

// ----------------------------------------------------------------------------
// Surface Splash effects
// ----------------------------------------------------------------------------

datablock ParticleData(bulletSplashRingParticle)
{
   textureName = "art/shapes/particles/wake";
   dragCoefficient = 0.0;
   gravityCoefficient = 0.0;
   inheritedVelFactor = 0.0;
   lifetimeMS = 2500;
   lifetimeVarianceMS = 200;
   windCoefficient = 0.0;
   useInvAlpha = 1;
   spinRandomMin = 30.0;
   spinRandomMax = 30.0;
   spinSpeed = 1;
   animateTexture = true;
   framesPerSec = 1;
   animTexTiling = "2 1";
   animTexFrames = "0 1";
   colors[0] = "0.7 0.8 1.0 1.0";
   colors[1] = "0.7 0.8 1.0 0.5";
   colors[2] = "0.7 0.8 1.0 0.0";
   sizes[0] = 2.0;
   sizes[1] = 4.0;
   sizes[2] = 8.0;
   times[0] = 0.0;
   times[1] = 0.5;
   times[2] = 1.0;
};

datablock ParticleEmitterData(BulletSplashRingEmitter)
{
   lifetimeMS = "100";
   ejectionPeriodMS = 200;
   periodVarianceMS = 10;
   ejectionVelocity = 0;
   velocityVariance = 0;
   ejectionOffset = 0;
   thetaMin = 89;
   thetaMax = 90;
   phiReferenceVel = 0;
   phiVariance = 1;
   alignParticles = 1;
   alignDirection = "0 1 0";
   particles = "BulletSplashRingParticle";
};

// ----------------------------------------------------------------------------
// Impact Particle effects
// ----------------------------------------------------------------------------

datablock ParticleData(bulletImpactParticle)
{
   dragCoeffiecient     = 100;
   gravityCoefficient   = -0.01;//positives fall, negatives rise
   inheritedVelFactor   = 0;
   constantAcceleration = 0;
   lifetimeMS           = 1200;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  true;
   spinRandomMin = -120;
   spinRandomMax =  120;

   colors[0]     = "0.5 0.4 0.3 1.0";
   colors[1]     = "0.5 0.4 0.3 0.5";
   colors[2]     = "0.5 0.4 0.3 0.0";

   sizes[0]      = 1;//0.6
   sizes[1]      = 2;//1.0
   sizes[2]      = 3;//2.0

   times[0]      = 0.0;
   times[1]      = 0.6;
   times[2]      = 1.0;
   spinSpeed = 1;
   textureName = "art/shapes/particles/smoke";
};

datablock ParticleEmitterData(bulletImpactEmitter)
{
   ejectionPeriodMS = 30;
   periodVarianceMS = 0;
   ejectionVelocity = 1;
   velocityVariance = 0.0;
   thetaMin         = 0;
   thetaMax         = 30;
   lifetimeMS       = 100;
   blendStyle = "NORMAL";
   ambientFactor = "0";
   particles = "BulletImpactParticle";
};

// ----------------------------------------------------------------------------
// Water Impact
// ----------------------------------------------------------------------------

datablock ParticleData(bulletSplashParticle)
{
   dragCoefficient = 1.0;
   windCoefficient = 2.0;
   gravityCoefficient = 0.3;
   inheritedVelFactor = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS = 600;
   lifetimeVarianceMS = 100;
   useInvAlpha = false;
   spinRandomMin = -90.0;
   spinRandomMax = 500.0;
   spinSpeed = 1;
   textureName = "art/shapes/particles/smoke";
   colors[0] = "0.7 0.8 1.0 1.0";
   colors[1] = "0.7 0.8 1.0 0.5";
   colors[2] = "0.7 0.8 1.0 0.0";
   sizes[0] = 0.2;//0.5;
   sizes[1] = 0.4;//0.5;
   sizes[2] = 0.8;
   times[0] = 0.0;
   times[1] = 0.5;
   times[2] = 1.0;
};

datablock ParticleEmitterData(bulletSplashEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;
   ejectionVelocity = 3.0;
   velocityVariance = 2.0;
   ejectionOffset = 0.15;
   thetaMin = 85;
   thetaMax = 85;
   phiReferenceVel = 0;
   phiVariance = 360;
   overrideAdvance = false;
   lifetimeMS = 250;
   particles = "BulletSplashParticle";
};

// ----------------------------------------------------------------------------
// Dry Impacts Objects
// ----------------------------------------------------------------------------


datablock ExplosionData(bulletImpact)
{
   soundProfile = bulletExplosionSound;
   lifeTimeMS = 200; // I want a quick bang and dissipation, not a slow burn-out

   // Volume particles
   particleEmitter = BulletImpactEmitter;
   particleDensity = 10;//20;
   particleRadius = 1;//2;

   // Point emission
   emitter[0] = bulletImpactEmitter;

   // Camera Shaking
   shakeCamera = true;
   camShakeFreq = "10.0 11.0 9.0";
   camShakeAmp = "5.0 5.0 5.0";
   camShakeDuration = 1.5;
   camShakeRadius = 5;
};

datablock ExplosionData(bulletWaterImpact)
{
   soundProfile = bulletSplashSound;
   lifeTimeMS = 200;
 
    // Volume particles
   particleEmitter = BulletSplashEmitter;
   particleDensity = 10;//20;
   particleRadius = 1;//2;
   
   // Point emission
   emitter[0] = BulletSplashEmitter;

   // Camera Shaking
   shakeCamera = true;
   camShakeFreq = "10.0 11.0 9.0";
   camShakeAmp = "5.0 5.0 5.0";
   camShakeDuration = 1.5;
   camShakeRadius = 5;
};

// Particle Emitter played when firing.

datablock ParticleData(fullautofiring1Particle)
{
   textureName = "art/shapes/particles/fireball";
   dragCoefficient = 100.0;
   gravityCoefficient = -0.25;//-0.5;//0.0;
   inheritedVelFactor = 0.25;//1.0;
   constantAcceleration = 0.1;
   lifetimeMS = 200;
   lifetimeVarianceMS = 100;
   useInvAlpha = false;
   spinSpeed = 1;
   spinRandomMin = -200;
   spinRandomMax = 200;
   colors[0] = "1 0.9 0.8 0.1";
   colors[1] = "1 0.5 0 0.3";
   colors[2] = "0.1 0.1 0.1 0";
   sizes[0] = 0.2;//1;
   sizes[1] = 0.25;//0.15;//0.75;
   sizes[2] = 0.3;//0.1;//0.5;
   times[0] = 0.0;
   times[1] = 0.5;//0.294118;
   times[2] = 1.0;
};

datablock ParticleEmitterData(fullautofiring1Emitter)
{
   ejectionPeriodMS = 15;//75;
   periodVarianceMS = 5;
   ejectionVelocity = 1;
   ejectionOffset = 0.0;
   velocityVariance = 0;
   thetaMin = 0.0;
   thetaMax = 180;//10.0;
   particles = "fullautofiring1Particle";
   blendStyle = "ADDITIVE";
};

//====================================

function spawnBang(%xyz)
{
      %explode = new explosion()
      {
          datablock = rocketLauncherExplosion;
          Position = %xyz;
      };
}