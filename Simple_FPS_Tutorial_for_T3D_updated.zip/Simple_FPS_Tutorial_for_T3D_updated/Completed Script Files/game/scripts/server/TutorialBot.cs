//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// AIPlayer callbacks
// The AIPlayer class implements the following callbacks:
//
//    PlayerData::onStuck(%this,%obj)
//    PlayerData::onUnStuck(%this,%obj)
//    PlayerData::onStop(%this,%obj)
//    PlayerData::onMove(%this,%obj)
//    PlayerData::onReachDestination(%this,%obj)
//    PlayerData::onTargetEnterLOS(%this,%obj)
//    PlayerData::onTargetExitLOS(%this,%obj)
//    PlayerData::onAdd(%this,%obj)
//
// Since the AIPlayer doesn't implement it's own datablock, these callbacks
// all take place in the PlayerData namespace.
//-----------------------------------------------------------------------------

$TutorialBot::Obstacles = 
  $TypeMasks::VehicleObjectType |
  $TypeMasks::PlayerObjectType |      
  $TypeMasks::TerrainObjectType |     
  $TypeMasks::StaticTSObjectType |    
  $TypeMasks::StaticShapeObjectType |
  $TypeMasks::InteriorObjectType |
  $TypeMasks::ForestObjectType;    

function TutorialBot::onReachDestination(%this,%obj)
{
   // Moves to the next node on the path.
   // Override for all player.  Normally we'd override this for only
   // a specific player datablock or class of players.
   if (%obj.path !$= "")
   {
      if (%obj.currentNode == %obj.targetNode)
         %this.onEndOfPath(%obj,%obj.path);
      else
         %obj.moveToNextNode();
   }
}

function TutorialBot::onEndOfPath(%this,%obj,%path)
{
   %obj.nextTask();
}

function TutorialBot::onEndSequence(%this,%obj,%slot)
{
   echo("Sequence Done!");
   %obj.stopThread(%slot);
   %obj.nextTask();
}

function TutorialBot::onTargetEnterLOS(%this,%obj)
{
	//ignore this, we want to make custom scripts
}

function TutorialBot::onTargetExitLOS(%this,%obj)
{
	//ignore this, we want to make custom scripts
}

//-----------------------------------------------------------------------------
// AIPlayer static functions
//-----------------------------------------------------------------------------

function AIPlayer::spawnBot(%name, %spawnPoint, %weapon)
{
	%player = new AiPlayer(%name)
	{
		dataBlock = TutorialBot;
		path = "";
	};
	MissionCleanup.add(%player);
    //%player.setShapeName(%name);
	%player.setTransform(%spawnPoint.getTransform());
	echo(%name @ " has spawned at " @ %spawnpoint);
	
	%player.equipBot(%weapon);
   
	%player.schedule(200, "botThink");
   
	return %player;
}

function AIPlayer::equipBot(%this, %weapon)
{
	if(%weapon $="semiauto")
	{
		%weaponAmmo = "semiautoAmmo";
		%weaponImage = "semiautoImage";
		%this.range = 200;
	}
	
	if(%weapon $="fullauto")
	{
		%weaponAmmo = "fullautoAmmo";
		%weaponImage = "fullautoImage";
		%this.range = 50;
	}
	
	//etc for adding more weapons

	%this.setInventory(%weapon, 1);
	%this.setInventory(%weaponAmmo, %this.maxInventory(%weaponAmmo));
   
	%this.mountimage(%weaponImage, 0);
}

function AIPlayer::botThink(%this)
{
	if(%this.getState() $= "Dead")
		return;
	
	%this.combatMode();
	echo(%this.getname() @ " thinking");
		
	%this.schedule(1000, "botThink");
}

function AIPlayer::combatMode(%this)
{
	%targetID = %this.targetPlayer(%target);

	if(%targetID != -1)
		if(%this.checkRange(%targetID) == true)
			if(%this.clearShot(%targetID) == true)
				%this.attackTarget(%targetID);
}

function AIPlayer::targetPlayer(%this)
{
	%count = ClientGroup.getCount();
	for(%i = 0; %i < %count; %i++)
	{
		%client = ClientGroup.getObject(%i);
		if (%client.player $= "" || %client.player == 0)
        return -1;
		
		%target = %client.player;
		echo(%this.getname() @ " has target " @ %target);
		return %target;
	}
}

function AIPlayer::checkRange(%this, %target)
{
	%rangeFrom = %this.range;
	
	%fromMe = %this.getPosition();
	%toYou = %target.getPosition();
	%rangeTo = VectorDist(%fromMe, %toYou);

	if(%rangeTo > %rangeFrom)
	{
		echo(%this.getname() @ " target too far");
		return false;
	}
	else
	{
		echo(%this.getname() @ " target in range");
		return true;
	}
}

function AIPlayer::clearShot(%this, %target)
{
	
	%ISpy = %this.getEyePoint();
	%YouSpy = %target.getEyePoint();

	%search = containerRayCast(%ISpy, %YouSpy, $TutorialBot::Obstacles, %this.getID());

	%impactID = firstWord(%search);
  
	if(%impactID == %target) 
	{
		echo(%this.getname() @ " has a clearShot");
		return true;
	}
	else
	{
		echo(%this.getname() @ " has no shot");
		return false;
	}
}

function AIPlayer::attackTarget(%this, %target)
{
	echo(%this.getname() @ " attacking!");
	%this.setAimObject(%target, "0 0 1.5");
	%this.schedule(150, "shoot");
	// a slight delay to make sure we're aiming at the target
	//you could always use a raycast to see if the target is in the bot's sights instead
}

function AIPlayer::shoot(%this)
{
	%this.setImageTrigger(0, true);
	
	%this.schedule(%this.shootingDelay, "ceasefire");
}

function AIPlayer::ceasefire(%this)
{
		%this.setImageTrigger(0, false);
}
