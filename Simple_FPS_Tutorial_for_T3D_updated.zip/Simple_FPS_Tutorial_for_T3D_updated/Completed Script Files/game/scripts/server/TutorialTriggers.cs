datablock TriggerData(TutorialTrigger)
{
   tickPeriodMS = 1000;
};

function TutorialTrigger::onEnterTrigger(%this,%trigger,%obj)
{

}

function TutorialTrigger::onLeaveTrigger(%this,%trigger,%obj)
{

}

function TutorialTrigger::onTickTrigger(%this,%trigger)
{

}

datablock TriggerData(NewCustomTrigger)
{
   tickPeriodMS = 1000;
};

function NewCustomTrigger::onEnterTrigger(%this,%trigger,%obj)
{
	%checkclass = %obj.getClassName();
	
	if(%checkclass $= "Player")
	{
		if(!isObject(pathbot2))
		{
			%newBot2 = aiplayer::spawnBot(pathbot2, path2start, semiauto);
			%newBot2.followPath("MissionGroup/botPaths/botPath2", 1);
		}
		
		if(!isObject(pathbot3))
		{
			%newBot3 = aiplayer::spawnBot(pathbot3, path3start, fullauto);
			%newBot3.followPath("MissionGroup/botPaths/botPath3", 3);
		}
		
	}
}

function NewCustomTrigger::onLeaveTrigger(%this,%trigger,%obj)
{

}

function NewCustomTrigger::onTickTrigger(%this,%trigger)
{

}
