// ----------------------------------------------------------------------------
// SimpleFPSTutorialGame
// ----------------------------------------------------------------------------
// Depends on methods found in gameCore.cs.  Those added here are specific to
// this game type and/or over-ride the "default" game functionaliy.
//
// The desired Game Type must be added to each mission's LevelInfo object.
//   - gameType = "SimpleFPSTutorial";
// If this information is missing then the GameCore will default to SimpleFPSTutorial.
// ----------------------------------------------------------------------------

function SimpleFPSTutorialGame::onMissionLoaded(%game)
{
   //echo (%game @"\c4 -> "@ %game.class @" -> SimpleFPSTutorialGame::onMissionLoaded");

   $Server::MissionType = "SimpleFPSTutorial";
   parent::onMissionLoaded(%game);
}

function SimpleFPSTutorialGame::initGameVars(%game)
{
   //echo (%game @"\c4 -> "@ %game.class @" -> SimpleFPSTutorialGame::initGameVars");

   //-----------------------------------------------------------------------------
   // What kind of "player" is spawned is either controlled directly by the
   // SpawnSphere or it defaults back to the values set here. This also controls
   // which SimGroups to attempt to select the spawn sphere's from by walking down
   // the list of SpawnGroups till it finds a valid spawn object.
   // These override the values set in core/scripts/server/spawn.cs
   //-----------------------------------------------------------------------------
   $Game::defaultPlayerClass = "Player";
   $Game::defaultPlayerDataBlock = "DefaultPlayerData";
   $Game::defaultPlayerSpawnGroups = "PlayerSpawnPoints PlayerDropPoints TutorialDropPoints";

   //-----------------------------------------------------------------------------
   // What kind of "camera" is spawned is either controlled directly by the
   // SpawnSphere or it defaults back to the values set here. This also controls
   // which SimGroups to attempt to select the spawn sphere's from by walking down
   // the list of SpawnGroups till it finds a valid spawn object.
   // These override the values set in core/scripts/server/spawn.cs
   //-----------------------------------------------------------------------------
   $Game::defaultCameraClass = "Camera";
   $Game::defaultCameraDataBlock = "Observer";
   $Game::defaultCameraSpawnGroups = "CameraSpawnPoints PlayerSpawnPoints PlayerDropPoints TutorialDropPoints";

}

function SimpleFPSTutorialGame::startGame(%game)
{
   //echo (%game @"\c4 -> "@ %game.class @" -> SimpleFPSTutorialGame::startGame");

   parent::startGame(%game);
}

function SimpleFPSTutorialGame::endGame(%game)
{
   //echo (%game @"\c4 -> "@ %game.class @" -> SimpleFPSTutorialGame::endGame");

   parent::endGame(%game);
   // Inform the client the game is over
   for (%clientIndex = 0; %clientIndex < ClientGroup.getCount(); %clientIndex++)
   {
      %cl = ClientGroup.getObject(%clientIndex);
      commandToClient(%cl, 'GameEnd');
   }
}

function SimpleFPSTutorialGame::onGameDurationEnd()
{
   //echo (%game @"\c4 -> "@ %game.class @" -> SimpleFPSTutorialGame::onGameDurationEnd");

   // Inform the client the game is over
   for (%clientIndex = 0; %clientIndex < ClientGroup.getCount(); %clientIndex++)
   {
      %cl = ClientGroup.getObject(%clientIndex);
      commandToClient(%cl, 'GameEnd');
   }
   parent::onGameDurationEnd();
}

function SimpleFPSTutorialGame::onClientEnterGame(%game, %client)
{
   //echo (%game @"\c4 -> "@ %game.class @" -> SimpleFPSTutorialGame::onClientEnterGame");

   parent::onClientEnterGame(%game, %client);
}

function SimpleFPSTutorialGame::preparePlayer(%game, %client)
{
   //echo (%game @"\c4 -> "@ %game.class @" -> SimpleFPSTutorialGame::preparePlayer");
   
   %playerSpawnPoint = pickPlayerSpawnPoint($Game::DefaultPlayerSpawnGroups);
   // Spawn a camera for this client using the found %spawnPoint
   //%client.spawnPlayer(%playerSpawnPoint);
   %game.spawnPlayer(%client, %playerSpawnPoint);

   // Starting equipment
 //  %client.player.setInventory(fullauto, 1);
 //  %client.player.setInventory(fullautoAmmo, %client.player.maxInventory(fullautoAmmo));

 //  %client.player.mountImage(fullautoImage, 0);
   
   // Prepare the actual player object for spawning and beginning equipment.
//   parent::preparePlayer(%game, %client);
}

// Determine if this client has reached the $Game::EndGameScore limit,
// and if so then cycle the game.
function SimpleFPSTutorialGame::checkScore(%game, %client)
{
   //echo (%game @"\c4 -> "@ %game.class @" -> SimpleFPSTutorialGame::checkScore");

 //  echo("score: "@ %client.score @"  "@ %game.endgameScore @" "@ $Game::EndGameScore);
 //  if (%client.score >= %game.endgameScore)
 //     cycleGame();
}

function SimpleFPSTutorialGame::onDeath(%game, %client, %sourceObject, %sourceClient, %damageType, %damLoc)
{
   //echo (%game @"\c4 -> "@ %game.class @" -> SimpleFPSTutorialGame::onDeath");

 //  parent::onDeath(%game, %client, %sourceObject, %sourceClient, %damageType, %damLoc);
 //  %game.checkScore(%sourceClient);
 
    %client.RefreshWeaponHud(0, "", "");

   // Clear out the name on the corpse
   %client.player.setShapeName("");

   // Update the numerical Health HUD
   %client.player.updateHealth(%obj);

   // Switch the client over to the death cam and unhook the player object.
   if (isObject(%client.camera) && isObject(%client.player))
   {
      %client.camera.setMode("Corpse", %client.player);
      %client.setControlObject(%client.camera);
   }
   %client.player = 0;
} 

function LoopForRemainingAi()
{
      %ai = 0;
      %here = fpath1start.getPosition();
	  
      InitContainerRadiusSearch(%here, 80, $Typemasks::AiObjectType);
	  
      while((%target = containerSearchNext()) !=0)
      {
         if(%target.getState() !$="Dead")
            %ai++;
      }


      if(%ai == 0)
      {
         echo("No Ai left at Station - Game Over, Player Wins!");
		 centerPrintAll( "Station Clear of Bots - You Win!",  5, 1);
		 //time in seconds not m/s!
		 schedule(5000, 0, "quitSimpleFPSTutorial");
      }
      else
      {
         echo("continue checking for remaining Ai");
         schedule(3000, 0 , "LoopForRemainingAi");
      }
}

function quitSimpleFPSTutorial()
{
   MessageBoxYesNo( "You Won!", "Exit?", "disconnect();", "");
}