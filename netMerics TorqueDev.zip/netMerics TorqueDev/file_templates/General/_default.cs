####Empty Code File####An empty code file with a header####TorqueDev Default Templates
// ============================================================
// Project            :  {{PROJECT_NAME}}
// File               :  {{FILE_RELATIVE_PATH}}
// Copyright          :  
// Author             :  {{SYSUSER}}
// Created on         :  {{DATE}}
//
// Editor             :  TorqueDev v. {{CW_VERSION}}
//
// Description        :  
//                    :  
//                    :  
// ============================================================