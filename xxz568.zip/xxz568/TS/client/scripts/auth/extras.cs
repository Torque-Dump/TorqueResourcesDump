function occurrences(%string, %block, %case)
{
   if (!isset(%case))
      %case = 0;
   %block_len = strLen(%block);
   %string_len = strLen(%string);
   %count = 0;
   for (%i = 0; %i < %string_len; %i++)
       if ((getSubStr(%string, %i, %block_len) $= %block) ||
          (!%case && strLwr(getSubStr(%string, %i, %block_len)) $= strLwr(%block)))
          %count++;
   return %count;
}
function isset(%v)
{
   return (%v !$= "");
}
function divmod(%a, %b)
{
   return mFloor(%a / %b) TAB %a % %b;
}

function getRandomSeperator(%length)
{
   %alphanumeric = "abcdefghijklmnopqrstuvwxyz0123456789";
   for (%i = 0; %i < %length; %i++)
   {
       %index = getRandom(strLen(%alphanumeric));
       %letter= getSubStr(%alphanumeric, %index, 1);
       %UpperC = getRandom(0, 1);
       if (%UpperC)
          %letter = strUpr(%letter);
       else
          %letter = strLwr(%letter);
       %seq = %seq @ %letter;
   }
   return %seq;
}

function makeDisposition(%seperator, %name, %content, %isEnd)
{
   if (%isEnd)
      %dispo = "--" @ %seperator @ "\r\nContent-Disposition: form-data; name=\""@%name@"\"\r\n\r\n"@%content@"\r\n--" @ %seperator @ "--";
   else
      %dispo = "--" @ %seperator @ "\r\nContent-Disposition: form-data; name=\""@%name@"\"\r\n\r\n"@%content@"\r\n";
   return %dispo;
}

function makeHeader(%cmd, %get, %host, %userAgent, %extra)
{
   %header = %cmd SPC %get SPC "HTTP/1.1\r\n" @
                    "Host: "@%host@"\r\n" @
                    "User-Agent: "@%userAgent@"\r\nConnection: close\r\n" @
                    %extra;
   return %header;
}

function ord(%c)
{
   // (Signal360)
   // the way i'm doing this is a little ugly,
   // but this works fine for now

   if (!isset($ord))
      for (%i = 0; %i < 256; %i++)
          $ord = $ord TAB chr(%i) SPC %i;
   //torque arrays are not case sensitive
   for (%i = 0; %i < 256; %i++)
       if (strCmp(getWord(getField($ord, %i),0), %c) == 0)
          return getWord(getField($ord, %i),1);
   return 0;
}
