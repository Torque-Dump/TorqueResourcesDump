// - Server <-> Client Connection
// - Written by Signal360 (KeyboardCat)
// - Patched up by Phantom139
$Dev::DevelopersMod = 1;
exec("./pgd_connection.cs");
//-----------------------------------------------------------------------------
// This function is called when a client has requested a connection.

function GameConnection::onConnectRequest( %client, %netAddress, %name, %certificate )
{
   if($Server::PlayerCount >= $pref::Server::MaxPlayers)
      return "CR_SERVERFULL";

   error("CONNECTION -" SPC %netAddress);

   %client.requestedName = %name;
   if ( !isNameUnique( %name ) )
   {
       %client.conflictingName = true;
       %client.conflictingClient = %obj;
   }
   return "";
}

//-----------------------------------------------------------------------------
// This function is called when a client connects to the server
// It's called twice in the authentication stage.

function GameConnection::onConnect( %client ) {
   
   //Phantom139: Begin authentication Process
   if(!%client.doneAuthing) {
      //echo("requesting account cert");
      commandToClient(%client, 'requestClientCert');
      return;
   }
   
   %authInfo = %client.getAuthenticationInfo();
   %accountName = getField(%authInfo, 0);
   %guid = getField(%authInfo, 1);
   %email = getField(%authInfo, 2);
   if(!isSet(%name)) {
      %name = %accountName;
   }
   //

   addToServerGuidList( %guid );

   // Set admin status
   if (%client.getAddress() $= "local") {
      %client.isAdmin = true;
      %client.isSuperAdmin = true;
      %client.isHost = true;
   }
   else {
      %adminStatus = getStoredAdminStatus( %guid );
      switch(%adminStatus) {
         case 1:
              %client.isAdmin = true;
         case 2:
              %client.isAdmin = true;
              %client.isSuperAdmin = true;
         default:
              %client.isAdmin = false;
              %client.isSuperAdmin = false;
              %client.isHost = false;
      }
   }


   %client.guid = %guid;
   %client.accountName = %accountName;

   %client.gender = "Male";
   %client.armor = "Light";
   %client.race = "Human";
   %client.skin = addTaggedString( "base" );
   %client.score = 0;
   
   echo("Client Added:" SPC %client @ "("@%client.guid@"), Account name:" SPC %accountName @
        ", Player name:" SPC getTaggedString(%client.name) SPC %client.getAddress);

   // Inform the client of all the other clients
   %count = ClientGroup.getCount();
   for (%cl = 0; %cl < %count; %cl++)
   {
      %other = ClientGroup.getObject(%cl);
      if ((%other != %client))
      {
         // These should be "silent" versions of these messages...
         messageClient(%client, 'MsgClientJoin', "",
               %other.name,
               %other,
               %other.sendGuid,
               %other.score,
               %other.isAIControlled(),
               %other.isAdmin,
               %other.isSuperAdmin,
               %other.accountName);
      }
   }

   // Inform the client we've joined up
   messageClient(%client,
      'MsgClientJoin', 'Welcome %1, to Torque.',
      %client.accountName,
      %client,
      %client.guid,
      %client.score,
      %client.isAiControlled(),
      %client.isAdmin,
      %client.isSuperAdmin,
      %client.accountName);

   // Inform all the other clients of the new guy
   messageAllExcept(%client, -1, 'MsgClientJoin', '\c1%1 has joined the game (%8)',
      %client.accountName,
      %client,
      %client.guid,
      %client.score,
      %client.isAiControlled(),
      %client.isAdmin,
      %client.isSuperAdmin,
      %client.accountName);
      
   %client.setPlayerName(%accountName);
   $Server::PlayerCount++;
   
   //
   sendLoadInfoToClient( %client );
   //
   $instantGroup = ServerGroup;
   $instantGroup = MissionCleanup;

   // If the mission is running, go ahead download it to the client
   if ($missionRunning) {
      echo("load mission for "@%client@"");
      %client.loadMission();
   }
}
//-----------------------------------------------------------------------------
// This function is called when a client drops for any reason

function GameConnection::onDrop(%client, %reason) {
   echo( "Client Left: "@%client@", Player name:" SPC getTaggedString(%client.name) SPC %client.getAddress );

   %client.onClientLeaveGame();

   removeFromServerGuidList( %client.guid );
   messageAllExcept(%client, -1, 'MsgClientDrop', '\c1%1 has left the game. (%3)', %client.name, %client, %reason );

   removeTaggedString(%client.name);
   
   if ($Server::PlayerCount != 0) //prevent player counts going up to 255
      $Server::PlayerCount--;

   // Reset the server if everyone has left the game
   if( $Server::PlayerCount == 0 && $Server::Dedicated)
      schedule(0, 0, "resetServerDefaults");
}
//-----------------------------------------------------------------------------
// This function changes a player name.

function GameConnection::setPlayerName(%client, %name) {
   if(%name $= "")
      return;

   // Make sure the alias is unique, we'll hit something eventually
   if (!isNameUnique(%name)) {
      %isUnique = false;
      for (%suffix = 1; !%isUnique; %suffix++)  {
         %nameTry = %name @ "_" @ %suffix;
         %isUnique = isNameUnique(%nameTry);
      }
      %name = %nameTry;
   }

   // Tag the name with the "smurf" color:
   %client.nameBase = %name;
   %client.name = addTaggedString("\cp\c8" @ %name @ "\co");
}

function isNameUnique(%name) {
   %count = ClientGroup.getCount();
   for ( %i = 0; %i < %count; %i++ ) {
      %test = ClientGroup.getObject( %i );
      %rawName = strLwr(stripChars( detag( getTaggedString( %test.name ) ), "\cp\co\c6\c7\c8\c9" ));
      if ( strcmp( strLwr(%name), %rawName ) == 0 )
         return false;
   }
   return true;
}


//-----------------------------------------------------------------------------

function GameConnection::startMission(%this) {
   // Inform the client the mission starting
   commandToClient(%this, 'MissionStart', $missionSequence);
}


function GameConnection::endMission(%this) {
   // Inform the client the mission is done
   commandToClient(%this, 'MissionEnd', $missionSequence);
}


//--------------------------------------------------------------------------
// Sync the clock on the client.

function GameConnection::syncClock(%client, %time)
{
   commandToClient(%client, 'syncClock', %time);
}


//--------------------------------------------------------------------------
// Update all the clients with the new score

//function GameConnection::incScore(%this, %delta) {
//   %this.score += %delta;
//
//   %this.team.score += %delta;
//
//   messageAll('MsgClientScoreChanged', "", %this.score, %this);
//}

//--------------------------------------------------------------------------
// Admin Status functions

function getStoredAdminStatus( %guid )
{
   %guidList = $Server::AdminList;
   %adminStatus = 0;
   for (%i = 0; (%i < getFieldCount(%guidList)) && !%adminStatus; %g = getField(%guidList, %i++))
       if (%g == %guid)
          %adminStatus = 1;
   %guidList = $Server::SAList;
   for (%i = 0; (%i < getFieldCount(%guidList)) && %adminStatus != 2; %g = getField(%guidList, %i++))
       if (%g == %guid)
          %adminStatus = 2;
   return %adminStatus;
}

function addToAdminList( %guid )
{
   %guidList = $Server::AdminList;
   if (!getFieldCount( %guidList ))
      %guidList = %guid;
   else
      %guidList = %guidList TAB %guid;
   $Server::AdminList = %guidList;
}

function addToSAList( %guid )
{
   %guidList = $Server::SAList;
   if (!getFieldCount( %guidList ))
      %guidList = %guid;
   else
      %guidList = %guidList TAB %guid;
   $Server::SAList = %guidList;
}

//SERVER CREATION FUNCTONS
function onServerCreated() {
   // Server::GameType is sent to the master server.
   // This variable should uniquely identify your game and/or mod.

   // GameStartTime is the sim time the game started. Used to calculated
   // game elapsed time.
   $Game::StartTime = 0;

   $Game::CanEnd = 1;

   // Load up all datablocks, objects etc.  This function is called when
   // a server is constructed.
   exec("./audioProfiles.cs");
   exec("./envAudioProfiles.cs");
   exec("./camera.cs");
   exec("./markers.cs");
   exec("./triggers.cs");
   exec("./inventory.cs");
   exec("./shapeBase.cs");
   exec("./item.cs");

   exec("./environment.cs");
   exec("./staticShape.cs");
   exec("./weapon.cs");
   exec("./radiusDamage.cs");
   exec("./environment.cs");
   exec("./server.cs");
   exec("./missionInfo.cs");

   exec("common/serverScripts/lightingSystem.cs");

   exec("./player.cs");
   exec("./chimneyfire.cs");
   exec("./aiPlayer.cs");

   exec("./sgExamples.cs");

   error(" --- Done --- ");

   // Load up any custom light data
   lightLoadDataBlocks(expandFileName("~/server/scripts/sgCustomLights/"));

   // Keep track of when the game started
   $Game::StartTime = $Sim::Time;
}

function onServerDestroyed() {
   // This function is called as part of a server shutdown.
}

function createServer(%serverType, %mission) {
   if (%mission $= "") {
      error("createServer: mission name unspecified");
      return;
   }

   // Make sure our mission name is relative so that it can send
   // across the network correctly
   %mission = makeRelativePath(%mission, getWorkingDirectory());

   destroyServer();

   //
   $missionSequence = 0;
   $Server::PlayerCount = 0;
   $Server::ServerType = %serverType;

   // Setup for multi-player, the network must have been
   // initialized before now.
   if (%serverType $= "MultiPlayer") {
      echo("Starting multiplayer mode");

      // Make sure the network port is set to the correct pref.
      portInit($Pref::Server::Port);
      allowConnections(true);

      if ($pref::Net::DisplayOnMaster !$= "Never" )
         schedule(0,0,startHeartbeat);
   }

   // Load the mission
   $ServerGroup = new SimGroup(ServerGroup);
   onServerCreated();
   //
   loadMission(%mission, true);
}


//-----------------------------------------------------------------------------

function destroyServer() {
   $Server::ServerType = "";
   allowConnections(false);
   stopHeartbeat();
   $missionRunning = false;

   // End any running mission
   endMission();
   onServerDestroyed();

   // Delete all the server objects
   if (isObject(MissionGroup))
      MissionGroup.delete();
   if (isObject(MissionCleanup))
      MissionCleanup.delete();
   if (isObject($ServerGroup))
      $ServerGroup.delete();

   // Delete all the connections:
   while (ClientGroup.getCount()) {
      %client = ClientGroup.getObject(0);
      %client.delete();
   }

   $Server::GuidList = "";

   // Delete all the data blocks...
   deleteDataBlocks();

   // Save any server settings
   echo( "Exporting server prefs..." );
   export( "$Pref::Server::*", "~/prefs.cs", false );

   // Dump anything we're not using
   purgeResources();
}

//--------------------------------------------------------------------------

function resetServerDefaults() {
   echo( "Resetting server defaults..." );

   // Override server defaults with prefs:
   exec( "~/defaults.cs" );
   exec( "~/prefs.cs" );

   loadMission( $Server::MissionFile );
}

//Server Connection
//--------------------------------------------------------------------------
// Certificate handling

function serverCmdTransmitAccountDetails(%client, %stream) {
   %client.certChk = %client.certChk @ %stream; //keep downloading.
}
function serverCmdTransmitAccountSignature(%client, %sig) {
   %client.sigChk = %client.sigChk @ %sig;
}

function serverCmdCertificateSent(%client) {
   //Ok, the client is expecting a really quick response from us, so lets make this
   //really quick. We verify the client here using the fields they have sent us
   %crt = %client.certChk;
   %client.verifyClientSignature(%client.sigChk, %crt);
   //if we haven't dropped the client yet, let the client send the rest to us!
}

//this is the final check, we ask for the challenge, and our auth (game info)
function serverCmdpingAuthInfo(%client, %authInfo, %name) {
   %client.doneAuthing = true;
   %client.authInfo = %authInfo;
   %client.onConnect();
}

function GameConnection::getAuthenticationInfo(%client) {
   //username TAB guid TAB email
   return %client.authInfo;
}
