<?php
   function checkName($name) {
      $minLen = 5;
      $maxLen = 30;

      if (!isset($name)) {
         //die("$"."EMPTY?");
         return 1;
      }
      if (strLen($name) < $minLen) {
         //die("$"."TOO_LONG");
         return 2;
      }      
      if (strLen($name) > $maxLen) {
         //die("$"."TOO_LONG");
         return 3;
      }    
      if (!preg_match("/^[A-Za-z0-9]+?$/", $name)) {
         //die("$"."BAD_CHARS\n");
         return 4;
      }
      $con = mysql_connect("localhost","DB_USERNAME_HERE", "DB_PASSWORD_HERE") or die("$"."INTERNAL_ERROR\n");
      mysql_select_db("YOUR_TABLE", $con);

      $result = mysql_query("SELECT * FROM YOUR_ACCOUNTS_TABLE", $con) or die("$"."INTERNAL_ERROR\n");

      while($row = mysql_fetch_array($result))  {
         if(strCmp(strtolower($row["username"]), strtolower($name)) == 0) {
            mysql_close($con); 
            return 5;
         }
      } 
      return 0;
   }
   //
   //checkName($_POST["username"]);
?>
