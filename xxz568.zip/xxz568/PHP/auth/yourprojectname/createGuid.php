<?php
   
   function CreateBLADGUID() {
      $startingVal = 10000003; //8 digit number
      $iteration = rand(13, 29);
      //Ok, here's how this works

      //Step 1: Access the Database, and sort it by the guids
      $con = mysql_connect("localhost","DB_USERNAME_HERE", "DB_PASSWORD_HERE");
      if (!$con) {
         die("$"."INTERNAL_ERROR");
      }

      mysql_select_db("YOUR_TABLE", $con);

      $result = mysql_query("SELECT * FROM YOUR_ACCOUNTS_TABLE ORDER BY guid ASC");
      $i = 0;
      while($row = mysql_fetch_array($result)) {  
         $i++;
         $rowGuid[$i] = $row["guid"];
         //echo "ROW ".$i.": ".$rowGuid[$i]." or ".$row["guid"]."\n";
      }
      //Step 2: Pick the final entry in the database
      $lastguid = $rowGuid[$i];
      if(!isSet($lastguid)) {
         //lets go one before it
         $i--;
         $lastguid = $rowGuid[$i];
         //is it still not there?
         if(!isSet($lastguid)) {
            //we must be the first guy, lulz
            return $startingVal;
         }
         else {
            //Iterate the last guid with a random iteration (from 13-29)
            $newGuid = $lastguid + $iteration; 
            //Step 4: Return the Added Number
            return $newGuid;
         }
      }
      else {
         //Iterate the last guid with a random iteration (from 13-29)
         $newGuid = $lastguid + $iteration; 
         //Step 4: Return the Added Number
         return $newGuid;
      }
   }
?>
