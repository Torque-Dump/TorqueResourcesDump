/**
Certificate System Scheme

Public Certificate: username  \t  guid  \t  email  \t  e  \t  n  \t  sig
Private Certificate: username  \t  sha1(decrypted d):encrypted d

**/ 
#pragma warning (disable : 4996)
#pragma warning (disable : 4239)

#define UPPER_EXPERIENCE_LEVEL 15 //highest amount of EXP gain at a time
#define EXPERIENCE_KEY "Battlelord_Experience_Key"

#include "platform/platform.h"
#include "console/console.h"
#include "console/consoleInternal.h"
#include "console/ast.h"
#include "core/resManager.h"
#include "core/stream/fileStream.h"
#include "console/compiler.h"
#include "platform/event.h"
#include "platform/platformInput.h"
#include "core/util/journal/journal.h"

#include "console/PGDCrypto/cryptoPackage.h"
#include <fstream>
using namespace std;

//console functions
ConsoleFunctionGroupBegin(PGDCryptoFunctions, "PGD's crypto library functions for RSA, AES, and Hashing.");

ConsoleFunction(whirlpool, const char *, 2, 2, "(string) returns the whirlpool hash of a string") {
   argc;
   std::string output_hash = cryptoPackage->whirlpool(argv[1]);
   const char * done = (const char *)malloc(256);
   strcpy((char *)done, output_hash.c_str());
   return done;
}

ConsoleFunction(sha1, const char *, 2, 2, "(string) returns the SHA1 hash of a string") {
   argc;
   std::string output_hash = cryptoPackage->sha1(argv[1]);
   const char * done = (const char *)malloc(256);
   strcpy((char *)done, output_hash.c_str());
   return done;
}

ConsoleFunction(generateRSA2048, int, 1, 1, "generates an RSA 2048 keypair and stored them in a variable") {
   argc;
   //generate RSA
   Con::printf("Generating Account Key");
   InvertibleRSAFunction pgdKey = cryptoPackage->rsaGenerate(1024);
   Con::printf("Storing Account Key");
   Con::setVariable("$Account::RSAKey::E", cryptoPackage->IntegerToString(pgdKey.GetPublicExponent()).c_str());
   Con::setVariable("$Account::RSAKey::N", cryptoPackage->IntegerToString(pgdKey.GetModulus()).c_str());
   Con::setVariable("$Account::RSAKey::D", cryptoPackage->IntegerToString(pgdKey.GetPrivateExponent()).c_str());
   Con::printf("Done Storing...");

   return 1;
}

ConsoleFunction(base64encode, const char *, 2, 2, "(string) returns the base64 encoded value of a string") {
   argc;
   std::string output_b64E; 
   cryptoPackage->Base64Encode(argv[1], output_b64E);
   const char * done = output_b64E.c_str();
   return done;
}

ConsoleFunction(base64decode, const char *, 2, 2, "(string) returns the base64 decoded value of a string") {
   argc;
   std::string output_b64D;
   cryptoPackage->Base64Decode(argv[1], output_b64D);
   const char * done = output_b64D.c_str();
   return done;
}

ConsoleFunction(getUTC, int, 1, 1, "(string) returns the UTC time string") {
   argc;
   unsigned int utc = cryptoPackage->getUTC();
   int out = (int)utc;
   return out;
}

ConsoleFunction(encryptAccountKey, const char *, 3, 3, "(string) encrypts the private account key sector using AES-256-CBC") {
   argc;
   //Variables: D Exponent, AES_KEY
   std::string holderString, encoded;
   cryptoPackage->AESEncrypt(string(argv[2]), string(argv[1]), holderString, 1000);
   const char * done = (const char *)malloc(1024);
   strcpy((char *)done, holderString.c_str());
   return done;
}

ConsoleFunction(DecryptAccount, const char *, 4, 4, "(string) decrypts an account running AES-CBC cipher") {
   argc;
   //vars: encoded exponent, decrypted hash, password input
   std::string holderStringDec, decodedToStr;
   std::string aes_cipher_key = argv[3];
   aes_cipher_key.append(argv[2]);
   // run AES rounds, then compare to decoded hash
   std::string decodeHex = std::string(argv[1]);
   cryptoPackage->AESDecrypt(aes_cipher_key, decodeHex, holderStringDec, 1000);
   const char * done = (const char *)malloc(1024);
   strcpy((char *)done, holderStringDec.c_str());
   //fileobject test
   if(cryptoPackage->pgdHash(holderStringDec.c_str()).compare(std::string(argv[2])) == 0) {
      return done;
   }
   else {
      return "INVALID_PASSWORD";
   }
}

ConsoleFunction(StoreSuccessfulLogin, int, 5, 5, "stores account exponents in a data structure") {
   argc;
   char * EE = (char *)malloc(512);
   char * NE = (char *)malloc(512);
   //char * DE = (char *)malloc(512);
   char * SE = (char *)malloc(512);
   //
   strcpy(EE, argv[1]);
   strcpy(NE, argv[2]);
   //strcpy(DE, argv[3]);
   strcpy(SE, argv[4]);

   Con::setVariable("$ClientKey_E", EE);
   Con::setVariable("$ClientKey_N", NE);
   Con::setVariable("$ClientKey_S", SE);
   return 1;
}

ConsoleFunction(GatherAccountDetails, void, 5, 5, "(string) returns a long appended string of account details (E, N, SIG)") {
   argc;
   //RSA_Verify Time :D
   //what is needed:
      //1: Full Details: whirlpool($guid@$name)
      //2: The Signature: base64
   //We are given the guid, email, and name by the client, attach E and N, then calc a whirlpool hash.
   std::string toWhrl = argv[1];
   toWhrl.append(argv[2]);
   toWhrl.append(argv[3]);
   std::string toWhrl_final = toWhrl;
   toWhrl_final = cryptoPackage->whirlpool(toWhrl);
   //
   std::string hexSig;
   hexSig.assign(string(argv[4]));
   //
   bool rsaverifyresult = cryptoPackage->caVerify(toWhrl_final, hexSig);   
   if(rsaverifyresult != true) {
	   //Naughty Naughty... someone is using a bogus certificate
	   //Kill Them!!!
	   Con::printf("CA_Verify has denied this account certificate.");
	   Con::executef("MessageBoxOk", "Invalid Account", "Invalid Account Certificate");
	   Con::executef("disconnect");
	   return;
   }
   // give our client E/N in an appending sig to work with
   Con::setVariable("AuthenticationDetails", "");
   std::string worker;
   worker.assign(argv[2]);
   worker.append(argv[3]);
   Con::setVariable("AuthenticationDetails", worker.c_str());
   //give the client his signature too!
   Con::setVariable("AuthenticationSignature", "");
   std::string clientSig;
   clientSig.assign(argv[4]);
   Con::setVariable("AuthenticationSignature", clientSig.c_str());
   //
   Con::setVariable("AccountDetails", "");
   std::string hold;
   hold.assign(argv[2]);
   hold.append(":");
   hold.append(argv[3]);
   hold.append(":");
   hold.append(argv[4]);
   //Store it
   Con::setVariable("AccountDetails", hold.c_str());
   Con::printf("AccountDetails is stored.");
}

ConsoleFunction(getFileMD5, const char*, 2, 2, "getFileMD5(file)") {
   std::string result;
   //check if the file exists
   if(!bool(gResourceManager->find(argv[1]))) {
      return "File Not Found";
   }
   //
   const char * done = (const char *)malloc(64);

   CryptoPP::Weak::MD5 hash;
   CryptoPP::FileSource(argv[1],true,new
   CryptoPP::HashFilter(hash,new CryptoPP::HexEncoder(new
   CryptoPP::StringSink(result),false))); 

   strcpy((char *)done, result.c_str());

   return done;
}

ConsoleFunctionGroupEnd(PGDCryptoFunctions);