/**
cryptoPackage.cpp
source cryptoPP function calls

Phantom Games Development Authentication Package xxz568
Package Version: 1.3, Compiled May. 24, 2011
Created By: Robert Clayton Fritzen (Phantom139)
Copyright 2011, Phantom Games Development

Libraries Used In Development: CryptoPP

Credit to the security and cryptography functions go to Wei Dai, who created the CryptoPP library, 
Phantom Games Development does not take any credit for these functions, or the provided function examples
used from the CryptoPP Library, all rights and provided licence agreements to those are reserved 
by the CryptoPP Group and their respective authors.

Unauthorized usage of this system is strictly prohibited, and may be met with legal measures.
This system cannot be used in countries to which the United States Of America has embargoed goods to.
**/

#include <fstream>
#include "cryptoPackage.h"

xxz568 *cryptoPackage = NULL;

xxz568::xxz568() {

}

xxz568::~xxz568() {
   //Destructor functions here... but none are needed :P
   //Phantom139: Eh, I may at some point :)
}

void xxz568::create() {
   //only one...
   if(cryptoPackage == NULL) {
      cryptoPackage = new xxz568();
      Con::printf("*Crypto Package Initialized.");
   }
}

void xxz568::destroy() {
   delete cryptoPackage;
   cryptoPackage = NULL;

   Con::printf("*Crypto Package Deleted.");
}

InvertibleRSAFunction xxz568::rsaGenerate(int bytes) {
   AutoSeededRandomPool rng;
   InvertibleRSAFunction parameters;

   while(parameters.Validate(rng, 3) == false) {
      parameters.GenerateRandomWithKeySize(rng, bytes);
      //parameters.SetPublicExponent(65537);
      RSA::PrivateKey privateKey(parameters);
      RSA::PublicKey publicKey(parameters);
   }

   //bool test = parameters.Validate(rng, 3);
   //cout << "Valid: " << test << endl;

   return parameters;
}

InvertibleRSAFunction xxz568::rsaLoad(std::string e, std::string n, std::string d) {
   InvertibleRSAFunction parameters;
   parameters.Initialize((const Integer)n.c_str(), (const Integer)e.c_str(), (const Integer)d.c_str());
   return parameters;
}

int xxz568::rsaSign(InvertibleRSAFunction rsa, string message, string &output) {
   AutoSeededRandomPool rng;
   RSA::PrivateKey privateKey(rsa);
   std::string holder;

   RSASSA_PKCS1v15_SHA_Signer signer(privateKey);

   StringSource(message, true, 
       new SignerFilter(rng, signer,
           new StringSink(holder)
      ) // SignerFilter
   ); // StringSource

   HexEncode(holder, output);

   return 1;
}

bool xxz568::rsaVerify(InvertibleRSAFunction rsa, std::string message, std::string textSig) {
   
   RSA::PublicKey publicKey(rsa);
   std::string holder;

   try {
      RSASSA_PKCS1v15_SHA_Verifier verifier(publicKey);

      HexDecode(textSig, holder);

      StringSource(message+holder, true,
          new SignatureVerificationFilter(
              verifier, NULL,
              SignatureVerificationFilter::THROW_EXCEPTION
         ) // SignatureVerificationFilter
      ); // StringSource
   }
   catch(std::exception e) {
      return false;
   }

   return true;
}

const char * xxz568::caPublic() {
   return "Place Hex Key Here";
}

std::string xxz568::sha1(std::string text) {
   CryptoPP::SHA1 hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

std::string xxz568::whirlpool(std::string text) {
   CryptoPP::Whirlpool hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

std::string xxz568::tiger(std::string text) {
   CryptoPP::Tiger hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

std::string xxz568::sha224(std::string text) {
   CryptoPP::SHA224 hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

std::string xxz568::sha256(std::string text) {
   CryptoPP::SHA256 hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

std::string xxz568::sha384(std::string text) {
   CryptoPP::SHA384 hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

std::string xxz568::sha512(std::string text) {
   CryptoPP::SHA512 hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

//xxz568 AES Encryption/Decryption, Modifications for 1.1
//Addition of PBKDF, and AES fixes using SecByteBlock
//Credit to these modifications go to: Geoff Beier, geoffbeier@gmail.com
int xxz568::AESEncrypt(std::string key, std::string input, std::string &output, unsigned int PBKDFiterations) {

   std::string hashedKey = whirlpool(key);

   AutoSeededX917RNG<AES> rng;

   SecByteBlock iv(AES::BLOCKSIZE);
   rng.GenerateBlock(iv,iv.size());

   // See NIST SP 800-132 for detailed recommendations on length, generation and
   // format of the salt. This test program will just generate a random one. That
   // might not be sufficient for every application.
   SecByteBlock pwsalt(AES::DEFAULT_KEYLENGTH);
   rng.GenerateBlock(pwsalt,pwsalt.size());

   SecByteBlock derivedkey(AES::DEFAULT_KEYLENGTH);
   PKCS5_PBKDF2_HMAC<SHA256> pbkdf;
   pbkdf.DeriveKey(
      // buffer that holds the derived key
	  derivedkey, derivedkey.size(),
	   // purpose byte. unused by this PBKDF implementation.
	   0x00,
	   // password bytes. careful to be consistent with encoding...
	   (byte *) hashedKey.data(), hashedKey.size(),
	   // salt bytes
	   pwsalt, pwsalt.size(),
	   // iteration count. See SP 800-132 for details. You want this as large as you can tolerate.
	   // make sure to use the same iteration count on both sides...
	   PBKDFiterations
   );
   string ciphertext;

   CBC_Mode<AES>::Encryption aesencryption(derivedkey,derivedkey.size(),iv);
   // encrypt message using key derived above, storing the hex encoded result into ciphertext
   StringSource encryptor(input, true,
      new StreamTransformationFilter(aesencryption, new HexEncoder( new StringSink(ciphertext), false))
   );
   std::string hexsalt, hexiv;
   ArraySource saltEncoder(pwsalt,pwsalt.size(), true, new HexEncoder(new StringSink(hexsalt), false));
   ArraySource ivEncoder(iv,iv.size(), true, new HexEncoder(new StringSink(hexiv), false));

   output.assign(hexsalt);
   output.append(hexiv);
   output.append(ciphertext);
   //
   return 1;
}

int xxz568::AESDecrypt(std::string key, std::string input, std::string &output, unsigned int PBKDFiterations) {
   std::string hashedKey = whirlpool(key);

   std::string saltPull, ivPull, cipherPull, store;
   store.assign(input);
   saltPull.assign(store.substr(0, 32));
   store.assign(store.substr(32, store.length()));
   ivPull.assign(store.substr(0, 32)); 
   store.assign(store.substr(32, store.length()));
   cipherPull.assign(store.substr(0, store.length()));

   // now recover the plain text given the password, salt, IV and ciphertext
   PKCS5_PBKDF2_HMAC<SHA256> pbkdf;
   SecByteBlock recoveredkey(AES::DEFAULT_KEYLENGTH);
   SecByteBlock recoveredsalt(AES::DEFAULT_KEYLENGTH);
   StringSource saltDecoder(saltPull,true,new HexDecoder(new ArraySink(recoveredsalt, recoveredsalt.size())));
   pbkdf.DeriveKey(recoveredkey, recoveredkey.size(), 0x00, (byte *) hashedKey.data(), hashedKey.size(),
      recoveredsalt, recoveredsalt.size(), PBKDFiterations);
   SecByteBlock recoverediv(AES::BLOCKSIZE);
   StringSource ivDecoder(ivPull,true,new HexDecoder(new ArraySink(recoverediv, recoverediv.size())));
   try {
      CBC_Mode<AES>::Decryption aesdecryption(recoveredkey, recoveredkey.size(), recoverediv);
      StringSource decryptor(cipherPull, true, new HexDecoder(
         new StreamTransformationFilter(aesdecryption, new StringSink(output))
      ));
   }
   catch(CryptoPP::Exception e) {
	  output = "Decryption Error: ";
	  output.append(e.GetWhat());
   }
   return 1;
}

int xxz568::HexEncode(std::string input, std::string &output) {
   CryptoPP::StringSource foo(input, true,
	  new CryptoPP::HexEncoder(
         new CryptoPP::StringSink(output), false));
   return 1;
}

int xxz568::HexDecode(std::string input, std::string &output) {
   CryptoPP::StringSource foo(input, true,
	  new CryptoPP::HexDecoder(
         new CryptoPP::StringSink(output)));
   return 1;
}

unsigned int xxz568::getUTC() {
   unsigned int uiTime = static_cast<unsigned int>( time( NULL ) );
   return uiTime;
}

long xxz568::getPGDAssignedDateInteger() {
   long PADI;
   time_t rawtime;
   struct tm * timeinfo;
   char buffer [80];

   time ( &rawtime );
   timeinfo = localtime ( &rawtime );

   strftime (buffer,80,"%Y%m%d",timeinfo);
   PADI = atoi(buffer);
   return PADI;
}

int xxz568::Base64Encode(std::string input, std::string &output) {
   StringSink* sink = new StringSink(output);
   Base64Encoder* base64_enc = new Base64Encoder(sink);
   StringSource source(input, true, base64_enc);
   return 1;
}

int xxz568::Base64Decode(std::string input, std::string &output) {
   StringSink* sink = new StringSink(output);
   Base64Decoder* base64_dec = new Base64Decoder(sink);
   StringSource source(input, true, base64_dec);
   return 1;
}

char * xxz568::charsubstr(char *x, int n, int n2){
   char *p = new char[n2+1]; //This allocates the memory to hold the sub-string.
   //the rest is essentially the same
   for(int i=0; i<=n2; i++) {
      *(p+i) = *(x+i+n); //here x instead of p on the rhs.
   }
   *(p+n2) = '\0';
   return p;
}

std::string xxz568::IntegerToString(const Integer refs) {
   std::ostrstream oss;
   oss << refs;
   oss << std::hex << refs; // use this for hex output
   std::string s(oss.str());
   s = s.substr(0, s.find_first_of("."));
   return s;// output is now in s
}

void xxz568::Base64ToInteger(const char *base64String, Integer &xmlint) {
   StringSource mod_s( base64String, true, new Base64Decoder);
   unsigned long mrs = mod_s.MaxRetrievable();
   char* mod_sstr = new char[mrs];
   mod_s.Get( (unsigned char*)mod_sstr, mrs );
   xmlint = Integer((byte*)mod_sstr, strlen(mod_sstr));
   delete[] mod_sstr;
}

bool xxz568::caVerify(std::string message, std::string signature) {
   std::string dec, fin;
   fin.assign(caPublic());
   fin.append("h");
   Integer rsaPub(fin.c_str()), rsaexp("65537");
   
   std::string holder;

   try {
      RSASSA_PKCS1v15_SHA_Verifier verifier;
      verifier.AccessKey().Initialize(rsaPub, rsaexp);

      HexDecode(signature, holder);

      StringSource(message+holder, true,
          new SignatureVerificationFilter(
              verifier, NULL,
              SignatureVerificationFilter::THROW_EXCEPTION
         ) // SignatureVerificationFilter
      ); // StringSource
   }
   catch(CryptoPP::Exception e) {
      cout << e.GetWhat() << endl;
      return false;
   }

   return true;
}

//Not working yet....
std::string xxz568::RSAEncrypt(const CryptoPP::Integer e, const CryptoPP::Integer n, std::string message) {
   AutoSeededRandomPool rng;
   std::string holder;

   RSAES_OAEP_SHA_Encryptor enc;
   enc.AccessKey().Initialize(n, e);

   StringSource(message, true,
      new PK_EncryptorFilter(rng, enc,
	     new HexEncoder(
            new StringSink(holder), false
		 )
      ) // PK_EncryptorFilter
   ); // StringSource
   return holder;
}

//Not Working Yet
std::string xxz568::RSADecrypt(const CryptoPP::Integer e, const CryptoPP::Integer n, const CryptoPP::Integer d, std::string message) {
   AutoSeededRandomPool rng;
   std::string holder;

   RSAES_OAEP_SHA_Decryptor dec;
   dec.AccessKey().Initialize(n, e, d);

   StringSource(message, true,
      new PK_DecryptorFilter(rng, dec,
	     new HexDecoder(
            new StringSink(holder)
		 )
      ) // PK_EncryptorFilter
   ); // StringSource
   return holder;
}

CryptoPP::Integer xxz568::load(std::string inbound, int r) {
   std::string move;
   move.assign(inbound);
   switch(r) {
	  case 10:
	     break;
	  case 16:
	     move.append("h");
		 break;
	  default:
	     break;
   }
   CryptoPP::Integer hold(move.c_str());
   return hold;
}
