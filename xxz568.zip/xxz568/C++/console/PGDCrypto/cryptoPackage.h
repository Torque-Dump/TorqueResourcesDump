#ifndef xxz568_H
#define xxz568_H

/**
cryptoPackage.h
Header file for cryptoPP function calls

Phantom Games Development Authentication Package xxz568
Package Version: 1.3, Compiled May. 24, 2011
Created By: Robert Clayton Fritzen (Phantom139)
Copyright 2011, Phantom Games Development

Libraries Used In Development: CryptoPP

Credit to the security and cryptography functions go to Wei Dai, who created the CryptoPP library, 
Phantom Games Development does not take any credit for these functions, or the provided function examples
used from the CryptoPP Library, all rights and provided licence agreements to those are reserved 
by the CryptoPP Group and their respective authors.

Unauthorized usage of this system is strictly prohibited, and may be met with legal measures.
This system cannot be used in countries to which the United States Of America has embargoed goods to.

CHANGE LOG
1.0:

* First Implementation
* Basic Hashing Algorithm (SHA1)
* Implementation of Hex Encode/Decode, Base64 Encode/Decode
* RSA Key Generation
* CryptoPP::Integer Loading

1.1:

* Public Release 1
* Revised RSA Code, Now Uses Sign/Verify, as Well as CA_Verify
* Added CA_public for placement of CA's public exponent
* Added Whirlpool Hash, and implementation of PGD Combo Hash
* Added AES Encryption/Decryption, Random Block IV
* Added Method of Getting UTC Time
* Fixed a bug in Integer Loading (Can now properly load Hex Values)

1.2:

* Reimplemented AES, now uses PBKDF, and fixed 0x00 Decryption Failure Error (Thanks Geoff Beier!)
* Added More Hashing Functions:
* SHA2 Family (224, 256, 384, 512)
* Tiger

1.3:

* Added error catching on the AES functions in case of any addiitonal issues.
* Added one centralized class declaration
* Now acts as a singleton
* Added base for RSA Encrypt/Decrypt (but they don't work yet)
* Trimed some useless stuff out...

**/

// Crypto++ Library
#ifdef _DEBUG
#  pragma comment ( lib, "cryptlibd" )
#else
#  pragma comment ( lib, "cryptlib" )
#endif

#pragma warning (disable : 4189)

#define CRYPTOPP_ENABLE_NAMESPACE_WEAK 1

//Include CryptoPP headers
#include <modes.h>
#include <base64.h>
#include <aes.h>
#include <filters.h>
#include <rsa.h>
#include <sha.h>
#include <tiger.h>
#include <hex.h>
#include <whrlpool.h>
#include <osrng.h>
#include <pwdbased.h>
#include <files.h>
#include <md5.h>
//End
#include <time.h>
#include <iostream>
#include <strstream>

using namespace CryptoPP;
using namespace std;

#ifndef _CONSOLE_H_
#include "console/console.h"
#include "console/consoleInternal.h"
#endif

class xxz568 {
   public:  
      static void create();
      static void destroy();

      xxz568();
      ~xxz568();
   //--------------------------
   //xxz568 RSA functions
      InvertibleRSAFunction rsaGenerate(int bytes);
	  InvertibleRSAFunction rsaLoad(std::string e, std::string n, std::string d);
	  int rsaSign(InvertibleRSAFunction rsa, std::string toSign, std::string &output);
	  bool rsaVerify(InvertibleRSAFunction rsa, std::string message, std::string signature); //NON CA VERIFY
	  const char * caPublic();
	  bool caVerify(std::string message, std::string signature);
   //--------------------------
   //xxz568 Hashing functions
	  std::string sha1(std::string text);      //1.0
	  std::string sha224(std::string text);    //1.2
	  std::string sha256(std::string text);    //1.2
	  std::string sha384(std::string text);    //1.2
	  std::string sha512(std::string text);    //1.2
	  std::string tiger(std::string text);     //1.2
	  std::string whirlpool(std::string text); //1.1
   //--------------------------
   //xxz568 Encryption Functions
	  int AESEncrypt(std::string key, std::string input, std::string &output, unsigned int PBKDFiterations);
      int AESDecrypt(std::string key, std::string input, std::string &output, unsigned int PBKDFiterations);
	  int HexEncode(std::string input, std::string &output);
	  int HexDecode(std::string input, std::string &output);
	  int Base64Encode(std::string input, std::string &out);
	  int Base64Decode(std::string input, std::string &out);
	  //RSA Enc/Dec w/ Parameters
	  std::string RSAEncrypt(const CryptoPP::Integer e, const CryptoPP::Integer n, std::string message);
	  std::string RSADecrypt(const CryptoPP::Integer e, const CryptoPP::Integer n, const CryptoPP::Integer d, std::string message);
   //--------------------------
   //xxz568 Misc Functions
	  std::string IntegerToString(const CryptoPP::Integer refs);
      unsigned int getUTC();
	  long getPGDAssignedDateInteger();
	  char * charsubstr(char *x, int n, int n2);
	  void Base64ToInteger(const char *base64String, CryptoPP::Integer &xmlint);
	  CryptoPP::Integer load(std::string inbound, int radix);
   //--------------------------
   private:

   protected:
};

extern xxz568 *cryptoPackage;

#endif