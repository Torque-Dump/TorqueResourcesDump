////////////////////////////////////////////////////
//
// CParser.cpp
//
//   Parser
//
//     (C) by Jarek Szpilewski
//         Jarek@DigitalPayne.de
//         http://www.DigitalPayne.de
//
////////////////////////////////////////////////////

#include "CParser.h"
#include "CIrc.h"
#include "CPlug.h"

#include <stdio.h>
#include <string.h>


//CIrcMessage
//has to be changed
//bad memory allocation :(
CIrcMessage::CIrcMessage (void)
{
	m_lpszCommand = new char [512];
	m_lpszNick = new char [512];
	m_lpszParams = new char [512];
	m_lpszPrefix = new char [512];
	m_lpszPlainText = new char [512];
	m_lpszStream = new char [512];

	memset (m_lpszCommand,0x00,512);
	memset (m_lpszNick,0x00,512);
	memset (m_lpszParams,0x00,512);
	memset (m_lpszPrefix,0x00,512);
	memset (m_lpszPlainText,0x00,512);
	memset (m_lpszStream,0x00,512);
	
}

CIrcMessage::~CIrcMessage (void)
{
	delete [] m_lpszCommand;
	delete [] m_lpszNick;
	delete [] m_lpszParams;
	delete [] m_lpszPrefix;
	delete [] m_lpszPlainText;
	delete [] m_lpszStream;
}


//CParser
CParser::CParser (void)
{
	m_lpAliasPlugList = NULL;
	m_lpRemotePlugList = NULL;
}	

CParser::~CParser (void)
{
	if (m_lpAliasPlugList)
		m_lpAliasPlugList->DeleteAll ();
	
	if (m_lpRemotePlugList)
		m_lpRemotePlugList->DeleteAll ();

	if (m_lpAliasPlugList)
		delete  m_lpAliasPlugList;
	if (m_lpRemotePlugList)
		delete  m_lpRemotePlugList;

}

bool CParser::Init (CIrc *ParentCirc)
{
	m_lpParentCIrc = ParentCirc;
	
	m_lpAliasPlugList = new CList;
	m_lpRemotePlugList = new CList;

	m_lpAliasPlugList->Init ();
	m_lpRemotePlugList->Init ();

	return true;
}



//Alias Plugs
void *CParser::AddAliasPlug (void *Plug)
{
	CPlug *p = (CPlug*)Plug;

	p->m_lpParentCIrc = m_lpParentCIrc;
	p->m_lpParentCParser = this;

	return m_lpAliasPlugList->Add (Plug);
}

void CParser::RemoveAliasPlug (void *Plug)
{
	CListIT ITpluglist(m_lpAliasPlugList);

	CPlug *pPlug = NULL;
	CPlug *sPlug = (CPlug*)Plug;
	
	while (!ITpluglist.IsEnd())
	{
		pPlug = (CPlug*)ITpluglist.GetDataPtr ();

		if (pPlug == sPlug)
		{
			ITpluglist.Delete (Plug);
			return;
		}
		
		ITpluglist.Next();
	}
}

//Remote Plugs
void *CParser::AddRemotePlug (void *Plug)
{
	CPlug *p = (CPlug*)Plug;

	p->m_lpParentCIrc = m_lpParentCIrc;
	p->m_lpParentCParser = this;

	
	return m_lpRemotePlugList->Add (Plug);
}

void CParser::RemoveRemotePlug (void *Plug)
{
	CListIT ITpluglist(m_lpRemotePlugList);

	CPlug *pPlug = NULL;
	CPlug *sPlug = (CPlug*)Plug;
	
	while (!ITpluglist.IsEnd())
	{
		pPlug = (CPlug*)ITpluglist.GetDataPtr ();

		if (pPlug == sPlug)
		{
			ITpluglist.Delete (Plug);
			return;
		}
		
		ITpluglist.Next();
	}
}


int CParser::Execute (char *Tag)
{
	char *upTag = NULL; //das array in grossbuchstaben
	char *upEvent = NULL;

	//Hmm, ein strupr(Tag) ergibt ne
	//Access-Violation. Warum? 
	//Naja, kopieren wir das halt mal um
	char *tmpBuf = new char[512];
	memset(tmpBuf,0x00,512);
	memcpy(tmpBuf,Tag,strlen(Tag));
	upTag = strupr(tmpBuf);

	char *tmpBuf2 = new char[32];
	memset(tmpBuf2,0x00,32);
	
	

	CListIT ITpluglist(m_lpAliasPlugList);
	CPlug *pPlug = NULL;
	while (!ITpluglist.IsEnd())
	{
		pPlug = (CPlug*)ITpluglist.GetDataPtr ();
		memset(tmpBuf2,0x00,32);
		memcpy(tmpBuf2,pPlug->m_lpszEvent,strlen(pPlug->m_lpszEvent));
		upEvent = strupr(tmpBuf2);

		if (strstr(upTag,upEvent))//pPlug->m_lpszEvent))
		{
			pPlug->HandleEvent (Tag);
			return 0;
			break;
		}

		ITpluglist.Next();
	}

	char *lpszMessage = new char[512];
	memset(lpszMessage,0x00,512);

	
	//
	//strupr (Tag);
	if (strstr(upTag,"/QUIT"))
	{
		memcpy(lpszMessage,(Tag+1),strlen(Tag)-1);
		strcat(lpszMessage,"\n");
		m_lpParentCIrc->SendStream (lpszMessage);	
		
		m_lpParentCIrc->Disconnect();

		return 0;
	}

	if (Tag[0] == '/')
	{
		memcpy(lpszMessage,(Tag+1),strlen(Tag)-1);
		strcat(lpszMessage,"\n");
	}

	if (Tag[0] != '/')
	{
		sprintf (lpszMessage,"PRIVMSG ");
		strcat (lpszMessage,m_lpParentCIrc->m_lpCUUserInfo->m_lpszActiveChannel);
		
		strcat (lpszMessage," :");
		memcpy (lpszMessage+strlen(lpszMessage),Tag,strlen(Tag));
		strcat (lpszMessage,"\n");

	}
	m_lpParentCIrc->SendStream (lpszMessage);

	delete [] lpszMessage;
	delete [] tmpBuf;
	delete [] tmpBuf2;

	return 0;
}

CIrcMessage *CParser::ExtractMessage (char *Stream)
{
	CIrcMessage *msg = new CIrcMessage;
	char *p = NULL;

	//Prefix
	if (Stream[0] == ':') // es kommt ein prefix
	{
		for (unsigned int i = 0; i < strlen(Stream); i++)
		{
			if (Stream[i] == ' ')
			{
				memcpy(msg->m_lpszPrefix,Stream,i);
				p = Stream+i+1;
				break;		
			}
		}
	}
	else
	{
		p = Stream;
	}

	//Command
	for (unsigned int i = 0; i < strlen(p); i++)
	{
		if (p[i] == ' ')
		{
			memcpy(msg->m_lpszCommand,p,i);
			p = p + i+1;
			break;
		}
	}

	//Parameter
	memcpy(msg->m_lpszParams,p,strlen(p));

	//extract PlainText
	p = msg->m_lpszParams;

	for (i = 0; i < strlen(msg->m_lpszParams); i++)
	{
		if (p[i] == ':')
		{
			p = msg->m_lpszParams + i + 1;
			memcpy(msg->m_lpszPlainText,p,strlen(p));
			break;
		}
	}

	//parse Prefix for nick
	for (i = 0; i < strlen(msg->m_lpszPrefix); i++)
	{
		if (msg->m_lpszPrefix [i] == '!')
		{
			p = msg->m_lpszPrefix+1;
			memcpy(msg->m_lpszNick ,p,i-1);
			break;
		}
	}

	//copy stream to message structure
	memcpy (msg->m_lpszStream,Stream,strlen(Stream));

	return msg;
}

int CParser::Parse (CIrcMessage *Message)
{
	CListIT ITpluglist(m_lpRemotePlugList);

	CPlug *pPlug = NULL;
	char *upMessage = NULL;
	char *upEvent = NULL;

	char *tmpBuf = new char [512];
	memset (tmpBuf,0x00,512);
	memcpy (tmpBuf,Message->m_lpszStream,strlen(Message->m_lpszStream));
	upMessage = strupr (Message->m_lpszStream);

	char *tmpBuf2 = new char [32];
	memset (tmpBuf2,0x00,32);
	
	while (!ITpluglist.IsEnd())
	{
		pPlug = (CPlug*)ITpluglist.GetDataPtr ();
		
		memset (tmpBuf2,0x00,32);
		memcpy(tmpBuf2,pPlug->m_lpszEvent,strlen(pPlug->m_lpszEvent));
		upEvent = strupr(tmpBuf2);
		
		if (strstr(upMessage,upEvent))
		{
			pPlug->HandleEvent ((void*)Message);
			delete [] tmpBuf;
			delete [] tmpBuf2;
			return 1; //handled by plug
		}
		ITpluglist.Next();
	}

	delete [] tmpBuf;
	delete [] tmpBuf2;

	return 0;
}