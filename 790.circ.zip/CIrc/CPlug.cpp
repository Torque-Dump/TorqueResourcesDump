////////////////////////////////////////////////////
//
// CPlug.cpp
//
//   Plug Base Class
//
//     (C) by Jarek Szpilewski
//         Jarek@DigitalPayne.de
//         http://www.DigitalPayne.de
//
////////////////////////////////////////////////////


#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>
#include "CPlug.h"

void CPlug::GetEvent (char *ev)
{
	*ev = *m_lpszEvent;
}

void CPlug::GetType (int *i)
{
	*i = m_iType;
}

void CPlug::Destroy (void)
{
	//nothing here :)
}
