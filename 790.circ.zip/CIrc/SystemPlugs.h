////////////////////////////////////////////////////
//
// SystemPlugs.h
//
//   CTCP Plugs etc.
//
//     (C) by Jarek Szpilewski
//         Jarek@DigitalPayne.de
//         http://www.DigitalPayne.de
//
////////////////////////////////////////////////////

#ifndef __SystemPlugs_h__
#define __SystemPlugs_h__
#include "CPlug.h"

//alias plugs
class JoinPlug : public CPlug
{
public:
	virtual void Init (void *Params);
	virtual void HandleEvent (void *Params);
};

class NickServPlug : public CPlug
{
public:
	virtual void Init (void *Params);
	virtual void HandleEvent (void *Params);
};

//CTCP plugs
class ActionPlug : public CPlug
{
public:
	virtual void Init (void *Params);
	virtual void HandleEvent (void *Params);
};

class PingPlug : public CPlug
{
public:
	virtual void Init (void *Params);
	virtual void HandleEvent (void *Params);
};

class VersionPlug : public CPlug
{
public:
	virtual void Init (void *Params);
	virtual void HandleEvent (void *Params);
};

class FingerPlug : public CPlug
{
public:
	virtual void Init (void *Params);
	virtual void HandleEvent (void *Params);
};

class TimePlug : public CPlug
{
public:
	virtual void Init (void *Params);
	virtual void HandleEvent (void *Params);
};

#endif