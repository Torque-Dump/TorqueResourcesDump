////////////////////////////////////////////////////
//
// CSocket.cpp
//
//   Simple Socket Encapsulation
//
//     thx to http://glvelocity.gamedev.net
//
////////////////////////////////////////////////////

// specialized includes
#ifdef WIN32
#include <winsock2.h>  // mal gucken ob n�tig
#else
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/time.h>
#endif

// global includes
#include <iostream.h>
#include <assert.h>
#include <stdio.h>
#include "CSocket.h"


#ifdef WIN32
// start + stop
// windows socket subsystem
bool CSocket_startup()
{
	// windows socket subsystem must be initialized
	// we accept windows socket version 1.0
	WSADATA l_version;
	int l_versionrequested = MAKEWORD(1, 0);
	if (WSAStartup(l_versionrequested, &l_version))
	{
		// socket initialization failed
		cerr << "error: initialize winsock2 failed." << endl;
		return false;
	}
	return true;
}


// Cleanup the Windows Socket Subsystem
bool CSocket_cleanup()
{
	return WSACleanup() == 0;
}
#endif


// creates an empty socket object
CSocket::CSocket()
{
	m_buffer   = NULL;
	m_socket   = 0;
}


// creates a socket object from an existing socket handler
CSocket::CSocket(SOCKET p_socket)
{
	m_buffer = NULL;
	m_socket = p_socket;
}


// destroys a socket object
CSocket::~CSocket()
{
	// free up buffer
	if (m_buffer)
		delete [] m_buffer;
	m_buffer = NULL;
	
	// close the socket
	close();
}


// creates a new socket handler
bool CSocket::create()
{
	// close an existing socket
	close();
	// create a new socket handler
	m_socket = socket(AF_INET, SOCK_STREAM, 0);
	//ioctlsocket (m_socket,FIONBIO,(unsigned long*)1);
	//ioctlsocket (m_socket, FIONBIO, (u_long FAR *) & bMode);

	return m_socket ? true: false;
}


// attach an existing handler to this object
bool CSocket::attach(SOCKET p_socket)
{
	// close an existing socket
	close();
	// attach existing socket handler
	m_socket = p_socket;
	return m_socket ? true: false;
}


// detach the handler, do nothing else with this handler
bool CSocket::detach()
{
	m_socket = 0;
	return true;
}


// close an opened socket
bool CSocket::close()
{
	// closes an initialized socket
	int rv = 0;
	if (m_socket != 0)
	{
		// something must happen (socket is open)
#ifdef WIN32
		// use closesocket under windows
		rv = closesocket(m_socket);
#else
		// use close on all other os
		rv = ::close(m_socket);
#endif
		m_socket = 0;

		// returns true if action was successfull
		return rv ? false: true;
	}
	else
		// nothing to close, return true
		return true;
}


// connect the socket to a remote host
bool CSocket::connect(const char* p_hostname, int p_hostport)
{
	// check if p_hostname a valid pointer
	if (!p_hostname)
		return false;

	// close an existing connection
	if (!close())
		return false;
	
	// create address structures
	struct sockaddr_in in_addr;
	in_addr.sin_family = AF_INET;
	in_addr.sin_port   = htons(p_hostport);

	struct hostent* host;
	unsigned long hostb;

    if (inet_addr(p_hostname) == -1)
    {
		// resolve host name
        host = gethostbyname(p_hostname);
        if (host)
        {
			hostb = *((unsigned long*)*host->h_addr_list);
            in_addr.sin_addr.s_addr = hostb;
        }
        else
			return false;
	}
    else
		in_addr.sin_addr.s_addr = inet_addr(p_hostname);
        
	// create socket
	if (!create())
		return false;
	// connect to remote host
	if (::connect(m_socket, (struct sockaddr*)&in_addr, sizeof(in_addr)))
		return false;

	// everything is ok
	return true;
}


// set a socket into listen state
bool CSocket::listen(int p_port, int p_backlog, const char* p_interface)
{
	// close an existing connection
	if (!close())
		return false;
	
	// create address structures
	struct sockaddr_in in_addr;
	in_addr.sin_family = AF_INET;
	in_addr.sin_port   = htons(p_port);

	struct hostent* host;
	unsigned long hostb;

	if (p_interface == NULL)
		in_addr.sin_addr.s_addr = INADDR_ANY;
	else
	{
    	if (inet_addr(p_interface) == -1)
    	{
			// resolve host name
        	host = gethostbyname(p_interface);
        	if (host)
        	{
				hostb = *((unsigned long*)*host->h_addr_list);
            	in_addr.sin_addr.s_addr = hostb;
        	}
        	else
				return false;
		}
    	else
			in_addr.sin_addr.s_addr = inet_addr(p_interface);
    }   
	// create socket
	if (!create())
		return false;
	// bind to the interface
	if (::bind(m_socket, (struct sockaddr*)&in_addr, sizeof(in_addr)))
		return false;
	// listen on the socket for incomming connections
	if (::listen(m_socket, p_backlog))
		return false;

	// everything is ok
	return true;
}


// accept an incomming connection
bool CSocket::accept(CSocket& p_socket)
{
	int s = ::accept(m_socket, NULL, 0);
	if (s >= 0)
	{
		// assign socket to the socket object
		p_socket.attach(s);
		return true;
	}
	else
		// error occured
		return false;
}


// receive data from the remote host
int CSocket::recv(char* p_data, int p_len)
{
	return ::recv(m_socket, p_data, p_len, 0);
}


// sends a data package to the remote host
bool CSocket::send(char* p_data, int p_len)
{
	// check socket healthy
	if (!m_socket)
		// no valid socket object
		return false;
	// send some data
	if (!::send(m_socket, p_data, p_len, 0))
		return false;
	else
		return true;
}


// returns true if there is at least one incomming connection request
bool CSocket::canaccept()
{
	struct timeval tv;
	fd_set l_fd;
	FD_ZERO(&l_fd);
	FD_SET(m_socket, &l_fd);
	tv.tv_sec = 0;
	tv.tv_usec = 1;
	int rv = select(1, &l_fd, NULL, NULL, &tv);
	return rv ? true : false;
}


// returns the remote hostname
char* CSocket::gethostname()
{
	struct sockaddr_in host;
	socklen_t len = sizeof(host);
	char* ptr;
	if (::getsockname(m_socket, (struct sockaddr*)&host, &len) == 0)
	{
		// get the name
		ptr = inet_ntoa(host.sin_addr);
		
		// prepare buffer
		if (m_buffer)
			delete [] m_buffer;
		m_buffer = new char[strlen(ptr) +1];

		// copy name into buffer
		strcpy(m_buffer, ptr);
		return m_buffer;
	}
	else
		// function failed
		return NULL;
}


// returns the remote hostport
int CSocket::gethostport()
{
	struct sockaddr_in host;
	socklen_t len = sizeof(host);
	if (::getsockname(m_socket, (struct sockaddr*)&host, &len) == 0)
		return ntohs(host.sin_port);
	else
		// function failed
		return 0;
}


// returns the remote hostname
char* CSocket::getpeername()
{
	struct sockaddr_in host;
	socklen_t len = sizeof(host);
	char* ptr;
	if (::getpeername(m_socket, (struct sockaddr*)&host, &len) == 0)
	{
		// get the name
		ptr = inet_ntoa(host.sin_addr);
		
		// prepare buffer
		if (m_buffer)
			delete [] m_buffer;
		m_buffer = new char[strlen(ptr) +1];

		// copy name into buffer
		strcpy(m_buffer, ptr);
		return m_buffer;
	}
	else
		// function failed
		return NULL;
}


// returns the peer port number
int CSocket::getpeerport()
{
	struct sockaddr_in host;
	socklen_t len = sizeof(host);
	if (::getpeername(m_socket, (struct sockaddr*)&host, &len) == 0)
		return ntohs(host.sin_port);
	else
		// function failed
		return 0;
}


// casting to SOCKET
CSocket::operator SOCKET ()
{
	return m_socket;
}


// streaming operator for a string
CSocket& CSocket::operator << (const char* p_string)
{
	send((char*)p_string, strlen(p_string));
	return *this;
}


// streaming operator for numbers
CSocket& CSocket::operator << (int p_value)
{
	char l_buffer[34];
	sprintf(l_buffer, "%i\0", p_value);
	send(l_buffer, strlen(l_buffer));
	return *this;
}


// returns true if data can be received without blocking
bool CSocket::canrecv()
{
	// initialize structures
	fd_set lSet;
	lSet.fd_count    = 1;
	lSet.fd_array[0] = m_socket;
	timeval lTime;
	lTime.tv_sec = 0;
	lTime.tv_usec = 0;

	// determine status of the socket
	if (select(0, &lSet, NULL, NULL, &lTime) == 1)
		return true;
	else
		return false;


}
