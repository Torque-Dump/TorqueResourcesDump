////////////////////////////////////////////////////
//
// SystemPlugs.cpp
//
//   CTCP Plugs etc.
//
//     (C) by Jarek Szpilewski
//         Jarek@DigitalPayne.de
//         http://www.DigitalPayne.de
//
////////////////////////////////////////////////////


#include "SystemPlugs.h"
#include "CIrc.h"
#include "CString.h"


//action plug
void ActionPlug::Init (void *Params)
{
	m_iType = CP_REMOTE;
	m_lpszEvent = "\001ACTION";
}

void ActionPlug::HandleEvent (void *Params)
{
	//just a sample.
	//change it as you wish!

	CIrcMessage *Message = (CIrcMessage*)Params;
	CString <512> action;

	sprintf(action,"[ACTION] %s",Message->m_lpszNick);
	strcat(action,(Message->m_lpszPlainText+strlen(m_lpszEvent)));
	action[strlen(action)-3] = '\n';
	action[strlen(action)-2] = 0x00;


	printf(action);
}


//JoinPlug
void JoinPlug::Init (void *Params)
{
	m_iType = CP_ALIAS;
	m_lpszEvent = "/join";
}

void JoinPlug::HandleEvent (void *Params)
{
	char *Tag = (char *)Params;
	bool bChannelIsValid = false;
	CString <32> Channel;

	for (unsigned int i = 0; i < strlen(Tag); i++)
	{
		if (Tag[i] == '#')
		{
			bChannelIsValid = true;
			unsigned int j = 0;
			do
			{
				if (Tag[i+j] >= 32)
					Channel[j] = Tag[i+j];

				if ((Tag[i+j] == ' ') ||
					(Tag[i+j] == 13) ||
					(Tag[i+j] == 0x00) ||
					(j > strlen(Tag)))
					break;

				j ++;
			} while (1);
			break;
		}
	}


	if (!bChannelIsValid)
	{
		printf("\n\nInvalid Channel!\n\n");
		return;
	}

	CIrcUserInfo *ui = NULL;
	ui = m_lpParentCIrc->GetUserInfo ();
	memset(ui->m_lpszActiveChannel,0x00,strlen(ui->m_lpszActiveChannel));
	memcpy (ui->m_lpszActiveChannel,Channel,strlen(Channel));
	m_lpParentCIrc->SetUserInfo (ui);

	char *p = (Tag + 1);
	strcat(p,"\n");
	m_lpParentCIrc->SendStream (p);
};

//NickServPlug
void NickServPlug::Init (void *Params)
{
	m_iType = CP_ALIAS;
	m_lpszEvent = "/NICKSERV";
}

void NickServPlug::HandleEvent (void *Params)
{
	char *Tag = (char *)Params;
	char *p = (Tag+strlen("/NICKSERV "));
	CString <512> command;

	command.set ("/PRIVMSG NICKSERV :");
	strcat(command,p);
	m_lpParentCIrc->ExecuteCommand (command);
}

//PingPlug
void PingPlug::Init (void *Params)
{
	m_iType = CP_REMOTE;
	m_lpszEvent = "PING";
}


void PingPlug::HandleEvent (void *Params)
{
	CIrcMessage *Message = (CIrcMessage*)Params;

	//User-pong
	if (strstr(strupr(Message->m_lpszParams),"PING"))
	{
		char *message = new char[512];
		memset(message,0x00,512);
		char *p = NULL;

		for (unsigned int i = 0; i < strlen(Message->m_lpszParams); i++)
		{
			if (Message->m_lpszParams[i] == ':')
			{
				p = Message->m_lpszParams + i + 1;
				break;
			}
		}

		sprintf(message,"/NOTICE %s :%s",Message->m_lpszNick,p);
		m_lpParentCParser->Execute (message);

		delete [] message;
	}

	//Server-Pong
	if (strstr(strupr(Message->m_lpszCommand),"PING"))
	{
		char *message = new char[512];
		memset(message,0x00,512);
		char *p = NULL;

		for (unsigned int i = 0; i < strlen(Message->m_lpszParams); i++)
		{
			if (Message->m_lpszParams[i] == ':')
			{
				p = Message->m_lpszParams + i + 1;
				break;
			}
		}

		sprintf(message,"/PONG %s",p);
		m_lpParentCParser->Execute (message);

		delete [] message;
	}
}


//version plug
void VersionPlug::Init (void *Params)
{
	m_iType = CP_REMOTE;
	m_lpszEvent = "\001VERSION\001";
}

void VersionPlug::HandleEvent (void *Params)
{
	CIrcMessage *Message = (CIrcMessage*)Params;

	CString <512> command("/NOTICE %s :\001VERSION CIrc.dll v0.1 by Jarek Szpilewski. Get it at: http://www.DigitalPayne.de\001",Message->m_lpszNick);
	m_lpParentCParser->Execute (command);
}


//finger plug
void FingerPlug::Init (void *Params)
{
	m_iType = CP_REMOTE;
	m_lpszEvent = "\001FINGER\001";
}

void FingerPlug::HandleEvent (void *Params)
{
	CIrcMessage *Message = (CIrcMessage*)Params;

	CString <512> command("/NOTICE %s :\001FINGER CIrc.dll v0.1 by Jarek Szpilewski. Get it at: http://www.DigitalPayne.de\001",Message->m_lpszNick);
	m_lpParentCParser->Execute (command);
}


//time plug
void TimePlug::Init (void *Params)
{
	m_iType = CP_REMOTE;
	m_lpszEvent = "\001TIME\001";
}

void TimePlug::HandleEvent (void *Params)
{
	CIrcMessage *Message = (CIrcMessage*)Params;

	CString <512> command("/NOTICE %s :\001TIME It's X-Mas!!!\001",Message->m_lpszNick);
	m_lpParentCParser->Execute (command);
}