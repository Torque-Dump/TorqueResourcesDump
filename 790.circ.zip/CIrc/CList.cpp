////////////////////////////////////////////////////
//
// CList.cpp
//
//   Linked List of Void pointers
//
//     (C) by Jarek Szpilewski
//         Jarek@DigitalPayne.de
//         http://www.DigitalPayne.de
//
////////////////////////////////////////////////////

#include "CList.h"
#include <memory.h>

CList::CList()
{
	Init();
}

CList::~CList()
{
	DeleteAll();
}

void CList::Init(void)
{
	l_iCount = 0;
	memset(&m_items,0x00,sizeof(CItem));
	m_pitemLast = &m_items;
}

int CList::GetCount(void)
{
	return l_iCount;
}

void CList::DeleteAll(void)
{
	CItem *l_pitem, *l_pitemNext;

	l_pitemNext = (CItem*)m_items.m_pnext;

	while(l_pitemNext) 
	{
		l_pitem = l_pitemNext;
		l_pitemNext = (CItem*)l_pitem->m_pnext;
		delete l_pitem;
	}
	Init();
}

void* CList::Add(void* _pdata)
{
	l_iCount++;

	m_pitemLast->m_pnext = new CItem;
	memset(m_pitemLast->m_pnext,0x00,sizeof(CItem));

	m_pitemLast = (CItem*)m_pitemLast->m_pnext;
	m_pitemLast->m_pnext = NULL;

	m_pitemLast->m_pdata = _pdata;
	return _pdata;
}

bool CList::IsEnd(void)
{
	return (m_items.m_pnext == NULL);
}

void* CList::GetEndItem(void)
{
	CItem *l_pitem, *l_pitemNext;

	l_pitemNext = (CItem*)m_items.m_pnext;

	while(l_pitemNext) 
	{
		l_pitem = l_pitemNext;
		l_pitemNext = (CItem*)l_pitem->m_pnext;
	}

	return l_pitem->m_pdata;
}

CItem* CList::DeleteItem(void* _pdata)
{
	CItem *l_pitem, *l_pitemNext, *l_pitemPrev;

	l_pitemPrev = (CItem*)&m_items;
	l_pitemNext = (CItem*)m_items.m_pnext;

	while(l_pitemNext) 
	{
		l_pitem = l_pitemNext;

		if(l_pitem->m_pdata == _pdata) 
		{
			l_pitemPrev->m_pnext = l_pitem->m_pnext;
			delete l_pitem;
			if(l_pitem == m_pitemLast) 
			{
				m_pitemLast = l_pitemPrev;
			}
			if(m_pitemLast == &m_items) 
			{
				Init();
			}
			return l_pitemPrev;
		}
		l_pitemPrev = l_pitem;
		l_pitemNext = (CItem*)l_pitem->m_pnext;
	}
	return NULL;

}

CListIT::CListIT()
{
	m_pitem = NULL;
}

CListIT::CListIT(CList* _plist)
{
	Init(_plist);
}



// Moves to the top of the specified list.
//
void CListIT::Init(CList* _plist)
{
	m_plist = _plist;
	m_pitem = (CItem*)_plist->m_items.m_pnext;

}

void CListIT::Init(void)
{
	m_pitem = (CItem*)m_plist->m_items.m_pnext;
}

void CListIT::Delete(void* _pData)
{
	CItem* l_pitem = (CItem*)m_plist->DeleteItem(_pData);

	if(l_pitem) 
	{
		m_pitem = (CItem*)l_pitem->m_pnext;
	}
	else 
	{
		m_pitem = NULL;
	}

}

// Move to the next item in the list.
//
void CListIT::Next(void)
{
	if(m_pitem) 
	{
		m_pitem = (CItem*)m_pitem->m_pnext;
	}
}

bool CListIT::IsEnd(void)
{
	return (m_pitem == NULL);
}

void* CListIT::GetDataPtr(void)
{
	return m_pitem->m_pdata;
}


