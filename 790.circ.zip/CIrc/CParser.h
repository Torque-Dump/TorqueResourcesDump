////////////////////////////////////////////////////
//
// CParser.h
//
//   Parser
//
//     (C) by Jarek Szpilewski
//         Jarek@DigitalPayne.de
//         http://www.DigitalPayne.de
//
////////////////////////////////////////////////////

#ifndef _CParser_h__
#define _CParser_h__

#include "CSocket.h"
#include "CList.h"

class CIrcMessage
{
public:
	CIrcMessage (void);
	~CIrcMessage (void);
	
	char *m_lpszPrefix;
	char *m_lpszCommand;
	char *m_lpszParams;

	char *m_lpszNick; //who did create this message?
	char *m_lpszPlainText; //plain text. without any commands/prefixes (shoud usually be *g*)

	char *m_lpszStream; //Raw-message
};


class CParser
{
public:
	friend class CIrc;
	
	CParser (void);
	~CParser (void);

	//Plugs
	void *AddAliasPlug (void *Plug);
	void *AddRemotePlug (void *Plug);
	void RemoveAliasPlug (void *Plug);
	void RemoveRemotePlug (void *Plug);

	//Init
	bool Init (CIrc *ParentCIrc);

	//Execution
	int Execute (char *Tag);

	//parse + react
	int Parse (CIrcMessage *Message);

	//Extracts Message from char-stream
	CIrcMessage *ExtractMessage (char *Stream);


private:
	CIrc	*m_lpParentCIrc;

	CList	*m_lpAliasPlugList;
	CList	*m_lpRemotePlugList;
};


#endif