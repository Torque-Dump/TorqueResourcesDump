////////////////////////////////////////////////////
//
// CString.h
//
//   Simple String Template Class
//
//	   thx to http://www.garagegames.com
//     
////////////////////////////////////////////////////
#ifndef __CSTRING_H__
#define __CSTRING_H__

#include <stdio.h>
#include <stdarg.h>
#include <assert.h>

template<int Size> struct CString
{
private:
   char mBuffer[Size];
   
public:
   CString() 
   {
      //mBuffer[0] = '\0';
	   flush();
   }

   CString(const char *format, ...) 
   { 
      // Assert that the format string is not the internal buffer      
      flush();
	  assert(format != mBuffer);                         
      va_list argList;
      va_start(argList, format);
      int length = vsprintf(mBuffer, format, argList);
      // Assert that there was no buffer overflow
      assert(length<Size);
      va_end(argList);
   }
   
   inline void flush (char c = '\0')
   {
		for (int i = 0; i < Size; i++)
			mBuffer[i] = c;
   }

   inline char* set(const char *format, ...)
   {
      // Assert that the format string is not the internal buffer      
      assert(format != mBuffer);                         
      va_list argList;
      va_start(argList, format);
      int length = vsprintf(mBuffer, format, argList);
      // Assert that there was no buffer overflow
      assert(length<Size);
      va_end(argList);
      return mBuffer;
   }
   
   inline operator char*() 
   { 
      return mBuffer; 
   }

};


#endif

