////////////////////////////////////////////////////
//
// CIrc.cpp
//
//   Irc Interface
//
//     (C) by Jarek Szpilewski
//         Jarek@DigitalPayne.de
//         http://www.DigitalPayne.de
//
////////////////////////////////////////////////////

#include "CIrc.h"
#include "CPlug.h"

#include <string.h>
#include <stdio.h>


CIrc::CIrc ()
{
#ifdef WIN32
	// initialize sockets
	CSocket_startup();
#endif
	
	bConnectedToServer = false;
}

CIrc::~CIrc ()
{
#ifdef WIN32
	//close sockets
	CSocket_cleanup(); 
#endif
	
	bConnectedToServer = false;

	if (m_cpParser != NULL)
		delete m_cpParser;
}

void CIrc::Init (void)
{
	//initialize the parser
	m_cpParser = new CParser;
	m_cpParser->Init (this);
}

bool CIrc::Connect (CIrcUserInfo *UserInfo)
{
	char *tmpBuffer = new char[512];
	memset (tmpBuffer,0x00,512);
	
	m_lpCUUserInfo = UserInfo;


	//
	//start TCP/IP connection
	//
	if (!m_CSSocket.connect (m_lpCUUserInfo->m_lpszServer,m_lpCUUserInfo->m_iPort))
	{
		delete [] tmpBuffer;
		return false;
	}
	bConnectedToServer = true;
	//

	//
	//send UserInfo 
	//
	
	//PASS
	if (m_lpCUUserInfo->m_lpszPassword)
	{
		sprintf(tmpBuffer,"PASS %s\n",m_lpCUUserInfo->m_lpszPassword);
		m_CSSocket.send (tmpBuffer,strlen(tmpBuffer));
		memset (tmpBuffer,0x00,512);
	}

	
	//USER
	sprintf(tmpBuffer,"USER %s",m_lpCUUserInfo->m_lpszUser);
	strcat(tmpBuffer," ");
	strcat(tmpBuffer,m_lpCUUserInfo->m_lpszMode);
	strcat(tmpBuffer," ");
	strcat(tmpBuffer,m_lpCUUserInfo->m_lpszUnused);
	
	strcat(tmpBuffer," :");
	strcat(tmpBuffer,m_lpCUUserInfo->m_lpszRealname);
	strcat(tmpBuffer,"\n");

	m_CSSocket.send (tmpBuffer,strlen(tmpBuffer));
	memset (tmpBuffer,0x00,512);
	
	
	
	//change nickname
	sprintf(tmpBuffer,"/NICK %s",m_lpCUUserInfo->m_lpszNick);
	ExecuteCommand (tmpBuffer);

	delete [] tmpBuffer;
		
	return true;
}

void CIrc::Disconnect (void)
{
	bConnectedToServer = false;
	m_CSSocket.close();
	return;
}


void CIrc::ExecuteCommand (char *command)
{
	m_cpParser->Execute (command);
	return;
}


int CIrc::ParseMessage (CIrcMessage *Message)
{
	return m_cpParser->Parse (Message);
}

CIrcMessage *CIrc::ExtractMessage (char *Stream)
{
	return m_cpParser->ExtractMessage (Stream);
}

int CIrc::ReadStream (char *readto)
{
	if (!bConnectedToServer)
		return -23; //not connected

	int iReadCount = 0;
	int iCount = 0;
	char c = 0;

	do
	{
		iCount = m_CSSocket.recv (&c,1);
				
		if (iCount <= 0)
		{
			return 0;
		}
		iReadCount += iCount;
		*readto++ = c;
	
	} while (c != '\n');


	return iReadCount;
}

int CIrc::SendStream (char *message)
{
	if (!bConnectedToServer)
		return -23; //not connected
	m_CSSocket.send (message,strlen(message));

	return 0;
}

void *CIrc::AddPlug (CPlug *Plug)
{
	Plug->Init (NULL);

	switch (Plug->m_iType)
	{
	case CP_ALIAS:
		return m_cpParser->AddAliasPlug (Plug);
		break;
	case CP_REMOTE:
		return m_cpParser->AddRemotePlug (Plug);
		break;
	}

	return NULL;
}

void CIrc::RemovePlug (void *Plug)
{
	CPlug *pPlug = (CPlug*)Plug;
	
	switch (pPlug->m_iType)
	{
	case CP_ALIAS:
		m_cpParser->RemoveAliasPlug (pPlug);
		break;
	case CP_REMOTE:
		m_cpParser->RemoveRemotePlug (pPlug);
		break;
	}
}

CIrcUserInfo *CIrc::GetUserInfo (void)
{
	return m_lpCUUserInfo;
}

void CIrc::SetUserInfo (CIrcUserInfo *UserInfo)
{
	m_lpCUUserInfo = UserInfo;
}

bool CIrc::bCanReceive (void)
{	
	return m_CSSocket.canrecv ();
}