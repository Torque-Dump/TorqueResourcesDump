////////////////////////////////////////////////////
//
// CPlug.h
//
//   Plug Base Class
//
//     (C) by Jarek Szpilewski
//         Jarek@DigitalPayne.de
//         http://www.DigitalPayne.de
//
////////////////////////////////////////////////////


#ifndef __CPlug_H__
#define __CPlug_H__
#include "CParser.h"

#define CP_REMOTE 0x01
#define CP_ALIAS  0x02

class CIrcMessage;
class CIrc;

class CPlug
{
public:
	friend class CIrc;
	friend class CParser;
	
	virtual void Init (void *Params) = 0;
	virtual void HandleEvent (void *Params) = 0;
	virtual void Destroy (void);

	void GetType (int *i);
	void GetEvent (char *ev);

protected:
	int m_iType;
	char *m_lpszEvent;

	CParser *m_lpParentCParser;
	CIrc	*m_lpParentCIrc;
};



#endif