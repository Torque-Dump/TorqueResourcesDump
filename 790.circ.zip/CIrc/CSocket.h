////////////////////////////////////////////////////
//
// CSocket.h
//
//   Simple Socket Encapsulation
//
//     thx to http://glvelocity.gamedev.net
//
////////////////////////////////////////////////////


#ifndef CSOCKET_H
#define CSOCKET_H CSOCKET_H
#ifdef WIN32
#include <winsock2.h>
typedef int socklen_t;
#else
#define INVALID_SOCKET 0
typedef int SOCKET;
#endif


#ifdef WIN32
// global functions
bool CSocket_startup();
bool CSocket_cleanup();
#endif



// encapsulates a syncronous socket
class CSocket
{
	private:
	// attributes
	char*  m_buffer;
	SOCKET m_socket;

	public:
	// construction, destruction
	CSocket();
	CSocket(SOCKET p_socket);
	~CSocket();
	
	// socket lifetime handling
	bool create();
	bool attach(SOCKET p_socket);
	bool detach();
	
	// socket connection controlling
	bool connect(const char* p_hostname, int p_hostport);
	bool listen(int p_port, int p_backlog = 5, const char* p_interface = NULL);
	bool accept(CSocket& p_socket);
	bool close();
	bool send(char* p_data, int p_len);
	int  recv(char* p_data, int p_len);
	
	// connection stats
	bool canrecv();

	// polling incomming connection request
	bool canaccept();
	
	// network informations informations
	char* gethostname();
//	char* gethostip() const;
	int   gethostport();
	char* getpeername();
	int   getpeerport();


	// streaming operatoren
	CSocket& operator << (const char* p_string);
	CSocket& operator << (int p_value);

	// casting
	operator SOCKET ();
};

#endif
