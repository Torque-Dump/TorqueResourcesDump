////////////////////////////////////////////////////
//
// CIrc.h
//
//   Irc Interface
//
//     (C) by Jarek Szpilewski
//         Jarek@DigitalPayne.de
//         http://www.DigitalPayne.de
//
////////////////////////////////////////////////////


#ifndef _CIrc_h__
#define _CIrc_h__

#include "CSocket.h"
#include "CParser.h"
#include "CString.h"
#include "CPlug.h"

typedef struct _CIrcUserInfo
{
	char *m_lpszPassword;
	char *m_lpszNick;
	char *m_lpszServer;
	char *m_lpszActiveChannel;
	
	char *m_lpszUser;
	char *m_lpszMode;
	char *m_lpszUnused;
	char *m_lpszRealname;

	int   m_iPort;
} CIrcUserInfo;

class CIrc
{
public:
	friend class CParser;

	CIrc ();
	~CIrc ();
	
	//Init
	void Init (void); //Init
	
	//Connection
	bool bConnectedToServer; //Verbunden?
	bool Connect (CIrcUserInfo *UserInfo); //Verbindet
	void Disconnect (void); //Disconnect
	
	//Plugs
	void *AddPlug (CPlug *Plug); //Add Plug
	void RemovePlug (void *Plug); //Delete Plug
	
	//Execute w. parse
	void ExecuteCommand (char *command); //Execute
		
	//Message
	int ParseMessage (CIrcMessage *Message); //Parsed Message. dh. die message wird auf plug-events untersucht
	CIrcMessage *ExtractMessage (char *Stream); //Liefert eine CIrcMessage-Struktur zurueck aus einem rohen Stream	

	//Stream
	bool bCanReceive (void); //Liegen Daten zur Abholung vom Server an?
	int ReadStream (char *readto); //Liest Stream vom Server in readto ein
	int SendStream (char *message); //Sendet stream an server

	//UserInfo
	CIrcUserInfo *CIrc::GetUserInfo (void); //Liefert Zeiger auf m_lpCUUserInfo
	void SetUserInfo (CIrcUserInfo *UserInfo); //Setzt die aktuelle UserInfo
		

private:
	CSocket m_CSSocket;
	CParser *m_cpParser;
	CIrcUserInfo *m_lpCUUserInfo;
};



#endif