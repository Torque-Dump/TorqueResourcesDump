////////////////////////////////////////////////////
//
// CList.h
//
//   Linked List of Void pointers
//
//     (C) by Jarek Szpilewski
//         Jarek@DigitalPayne.de
//         http://www.DigitalPayne.de
//
////////////////////////////////////////////////////

#ifndef _CList_h__
#define _CList_h__

#include <stdio.h>
#include <stdlib.h>

typedef struct _CItem 
{
	void* m_pdata;
	void* m_pnext;
} CItem;


class CList
{
public:
	CItem m_items;
	CItem *m_pitemLast;
	int l_iCount;

	CList ();
	~CList ();
	void Init(void);
	void DeleteAll(void);
	int GetCount(void);
	void* Add(void* _pdata);
	bool IsEnd(void);
	void *GetEndItem(void);
	CItem* DeleteItem(void* _pdata);
};


class CListIT 
{
public:
	CItem* m_pitem;
	CList* m_plist;

	CListIT::CListIT();
	CListIT::CListIT(CList* _plist);
	void Init(CList* _plist);
	void Init(void);
	void Delete(void* _pData);
	void Next(void);
	bool IsEnd(void);
	void* GetDataPtr(void);
};

#endif