#ifndef __CLEETENCODER_H__
#define __CLEETENCODER_H__

#include <string.h>
#include <stdio.h>
#include <conio.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <conio.h>
#include <process.h>
#include <windows.h>


class CLeetEnDecoder
{
public:
	CLeetEnDecoder (void);
	
	void EncodeString (char *buffer, char *dest);
	void DecodeString (char *buffer, char *dest);

private:
	bool Decode (char *pIB, char *pOB, char *a, char b);
	bool Decode (char *pIB, char *pOB, char a, char b);

	bool SDecode (char *pIB, char *pOB, char a, char b);
	bool DDecode (char *pIB, char *pOB, char *a, char b);
	bool TDecode (char *pIB, char *pOB, char *a, char b);
	bool QDecode (char *pIB, char *pOB, char *a, char b);
	bool CDecode (char *pIB, char *pOB, char *a, char b);



	char *ASCIIChars;
	char *LeetChars;
	char *NormalChars;
};

#endif