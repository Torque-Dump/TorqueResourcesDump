#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <conio.h>
#include "../CSocket.h"
#include "../CString.h"
#include "../CIrc.h"
#include "../SystemPlugs.h"
#include "CLeetEnDecoder.h"
#include "UserPlugs.h"

bool bRunning = true;
CIrc Irc;

void MessageParser( void)
{
	if (!Irc.bCanReceive ())
		return;

	char *bla = new char[512];
	char *p = NULL;
	memset(bla,0x00,512);
	int iCount = 0;
	int i = 0;
	bool bF = false;

	CIrcMessage *msg;

	memset(bla,0x00,512);
	iCount = Irc.ReadStream (bla);
	if (iCount > 0)
	{
		msg = Irc.ExtractMessage (bla);

		if (Irc.ParseMessage (msg) == 0) //wenn nicht von plug behandelt
		{
			if (msg->m_lpszNick[0] != 0x00)
			{
				printf ("<%s> ",msg->m_lpszNick);
			}
			printf (msg->m_lpszPlainText);
		}
		delete msg;
	}
	if (iCount == -23)
		bRunning = false;

	delete [] bla;
}


void ParseConfigFile (char *filename, CIrcUserInfo *UserInfo)
{
	FILE *f = fopen (filename,"rt");
	if (f == NULL)
	{
		FILE *g = fopen("schwule.log","wt");
		fprintf(g,"Konnte config net oeffn0rn\n");
		fclose(g);
		exit (23);
	}

	char *line = new char[512];
	memset (line,0x00,512);
	char *buf = new char [512];
	memset (buf,0x00,512);

	do
	{
		fscanf(f,"%s\n",line);

		if (!strcmp(line,"{nick}"))
		{
			fscanf(f,"%s\n",buf);
			UserInfo->m_lpszNick = new char [strlen(buf)+1];
			memset(UserInfo->m_lpszNick,0x00,strlen(UserInfo->m_lpszNick));
			memcpy (UserInfo->m_lpszNick,buf,strlen(buf));
		}

		if (!strcmp(line,"{user}"))
		{
			fscanf(f,"%s\n",buf);
			UserInfo->m_lpszUser = new char [strlen(buf)+1];
			memset(UserInfo->m_lpszUser,0x00,strlen(UserInfo->m_lpszUser));
			memcpy (UserInfo->m_lpszUser,buf,strlen(buf));

		}

		if (!strcmp(line,"{server}"))
		{
			fscanf(f,"%s\n",buf);
			UserInfo->m_lpszServer = new char [strlen(buf)+1];
			memset(UserInfo->m_lpszServer,0x00,strlen(UserInfo->m_lpszServer));
			memcpy (UserInfo->m_lpszServer,buf,strlen(buf));
			fscanf(f,"%i",&UserInfo->m_iPort);
		}

		if (!strcmp(line,"{channel}"))
		{
			fscanf(f,"%s\n",buf);
			UserInfo->m_lpszActiveChannel = new char [strlen(buf)+1];
			memset(UserInfo->m_lpszActiveChannel,0x00,strlen(UserInfo->m_lpszActiveChannel));
			memcpy (UserInfo->m_lpszActiveChannel,buf,strlen(buf));
		}

		if (!strcmp(line,"{realname}"))
		{
			char c = 0;
			int i = 0;
			while (1)
			{
				fread(&c,1,1,f);
				if (c == '\n')
					break;
				buf [i++] = c;
			};
			UserInfo->m_lpszRealname = new char [strlen(buf)+1];
			memset(UserInfo->m_lpszRealname,0x00,strlen(UserInfo->m_lpszRealname));
			memcpy (UserInfo->m_lpszRealname,buf,strlen(buf));
		}

		if (!strcmp(line,"{end}"))
			break;

		memset (line,0x00,512);
		memset (buf,0x00,512);
	}
	while (1);

	fclose (f);

	delete [] line;
	delete [] buf;
}

CString <512> buffer;
int z = 0;
void DoInput (void)
{
	char c;

	if (kbhit())
	{
		c = getch();

		buffer[z] = c;

		if (c == 27)
		{
			printf("\nExit!\n");
			Irc.ExecuteCommand ("/QUIT :[ESC].Pressed");
		}

		if (c == 13)
		{
			printf("\n");
			Irc.ExecuteCommand (buffer);
			memset(buffer,0x00,512);
			z = 0;
			return;
		}

		if (c == 8)
		{
			buffer[z] = 0x00;
			z -= 2;

			if (z < -1)
				z = -1;
		}

		printf("%c",c);
		z ++;
	}

}

int main (void)
{

	CIrcUserInfo *UserInfo = new CIrcUserInfo;

	//UserInfo fuellen
	//UserInfo.m_lpszActiveChannel = "#CIrc";
	UserInfo->m_lpszMode= "0";
	//UserInfo.m_lpszNick = "CIrc";
	UserInfo->m_lpszPassword = NULL;
	//UserInfo.m_iPort = 6667;
	//UserInfo.m_lpszRealname = "CIrc by JS]";
	//UserInfo.m_lpszServer = "irc.ham.de.euirc.net";
	UserInfo->m_lpszUnused = "*";
	//UserInfo.m_lpszUser = "CIrc";

	ParseConfigFile ("config\\config.txt",UserInfo);

	Irc.Init ();

	//system plugs
	Irc.AddPlug (new JoinPlug);
	Irc.AddPlug (new NickServPlug);

	//CTCP plugs
	Irc.AddPlug (new PingPlug);
	Irc.AddPlug (new VersionPlug);
	Irc.AddPlug (new FingerPlug);
	Irc.AddPlug (new ActionPlug);
	Irc.AddPlug (new TimePlug);

	//addon plugs
	Irc.AddPlug (new DiePlug);
	Irc.AddPlug (new LeetEncoderPlug);
	Irc.AddPlug (new LeetDecoderPlug);
	Irc.AddPlug (new SpruchPlug);
	Irc.AddPlug (new LernSpruchPlug);
	Irc.AddPlug (new WitzPlug);
	Irc.AddPlug (new ASCIIPlug);
	void *hp = Irc.AddPlug (new HelpPlug);

	//Irc.RemovePlug (hp); //demonstriert das entfernen eines plugs


	if (!Irc.Connect (UserInfo))
	{
		printf("*** NOT Connected!\n\n");
		exit(23);
	}
	else
	{
		printf("*** Connected!\n\n");
	}

	Irc.ExecuteCommand (CString<512> ("/JOIN %s",UserInfo->m_lpszActiveChannel));

	while (bRunning && Irc.bConnectedToServer)
	{
		DoInput();
		MessageParser();
	}

	return 0;
}