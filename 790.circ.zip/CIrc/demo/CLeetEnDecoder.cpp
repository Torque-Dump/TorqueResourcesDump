///
///
/// WARNING! LAME CODE!!!
///
///

#include "CLeetEnDecoder.h"

CLeetEnDecoder::CLeetEnDecoder (void)
{
	ASCIIChars = new char [255];
	LeetChars = new char [255*4];
	NormalChars = new char [255];

	//ASCII-zeichensatz generieren
	for (int loop = 0; loop < 255; loop++)
	{
		ASCIIChars[loop] = char (loop);
	}

	//Leeten Zeichensatz generieren
	memset(LeetChars,0x00,255*4);
	for (loop = 0; loop < 255; loop++)
	{
		LeetChars[loop*4] = ASCIIChars[loop];
	}

	LeetChars['a'*4] = ASCIIChars['4']; //a
	LeetChars['�'*4] = ASCIIChars['a']; //�
	LeetChars['�'*4+1] = ASCIIChars['e']; //�
	LeetChars['b'*4] = ASCIIChars['6']; //b
	LeetChars['c'*4] = ASCIIChars['(']; //c
	LeetChars['d'*4] = ASCIIChars['|']; //d
	LeetChars['d'*4+1] = ASCIIChars[')']; //d
	LeetChars['e'*4] = ASCIIChars['3']; //e
	LeetChars['f'*4] = ASCIIChars['p']; //f
	LeetChars['f'*4+1] = ASCIIChars['|'];//f
	LeetChars['f'*4+2] = ASCIIChars['-'];//f
	LeetChars['f'*4+3] = ASCIIChars['|'];//f
	LeetChars['g'*4] = ASCIIChars['9']; //g
	LeetChars['h'*4] = ASCIIChars['|']; //h
	LeetChars['h'*4+1] = ASCIIChars['-']; //h
	LeetChars['h'*4+2] = ASCIIChars['|']; //h
	LeetChars['i'*4] = ASCIIChars['1']; //i
	LeetChars['j'*4] = ASCIIChars[';']; //i
	LeetChars['k'*4] = ASCIIChars['|']; //k
	LeetChars['k'*4+1] = ASCIIChars['<']; //k
	LeetChars['l'*4] = ASCIIChars['|']; //k
	LeetChars['l'*4+1] = ASCIIChars['_']; //k
	LeetChars['m'*4] = ASCIIChars['|'];
	LeetChars['m'*4+1] = ASCIIChars['\\'];
	LeetChars['m'*4+2] = ASCIIChars['/'];
	LeetChars['m'*4+3] = ASCIIChars['|'];
	LeetChars['n'*4] = ASCIIChars['|'];
	LeetChars['n'*4+1] = ASCIIChars['\\'];
	LeetChars['n'*4+2] = ASCIIChars['|'];
	LeetChars['o'*4] = ASCIIChars['0']; //o
	LeetChars['�'*4+1] = ASCIIChars['o']; //�
	LeetChars['�'*4+1] = ASCIIChars[':']; //�
	LeetChars['p'*4] = ASCIIChars['|']; //o
	LeetChars['p'*4+1] = ASCIIChars['>']; //o
	LeetChars['q'*4] = ASCIIChars['<']; //o
	LeetChars['q'*4+1] = ASCIIChars['|']; //o
	LeetChars['r'*4] = ASCIIChars['|']; //o
	LeetChars['r'*4+1] = ASCIIChars['^']; //o
	LeetChars['s'*4] = ASCIIChars['5']; //s
	LeetChars['t'*4] = ASCIIChars['7']; //t
	LeetChars['u'*4] = ASCIIChars['|']; //t
	LeetChars['u'*4+1] = ASCIIChars['_']; //t
	LeetChars['u'*4+2] = ASCIIChars['|']; //t
	LeetChars['�'*4] = ASCIIChars['c']; //�
	LeetChars['�'*4+1] = ASCIIChars[':']; //�
	LeetChars['v'*4] = ASCIIChars['\\']; //v
	LeetChars['v'*4+1] = ASCIIChars['/']; //v
	LeetChars['w'*4] = ASCIIChars['\\'];
	LeetChars['w'*4+1] = ASCIIChars['/'];
	LeetChars['w'*4+2] = ASCIIChars['\\'];
	LeetChars['w'*4+3] = ASCIIChars['/'];
	LeetChars['x'*4] = ASCIIChars['>'];
	LeetChars['x'*4+1] = ASCIIChars['<'];
	LeetChars['y'*4] = ASCIIChars['\''];
	LeetChars['y'*4+1] = ASCIIChars['/'];
	LeetChars['z'*4] = ASCIIChars['2'];


	//Normalen Zeichensatz erstellen
	memcpy(NormalChars,ASCIIChars,255);
	NormalChars['0'] = ASCIIChars['o'];
	NormalChars['1'] = ASCIIChars['i'];
	NormalChars['2'] = ASCIIChars['z'];
	NormalChars['3'] = ASCIIChars['e'];
	NormalChars['4'] = ASCIIChars['a'];
	NormalChars['5'] = ASCIIChars['s'];
	NormalChars['6'] = ASCIIChars['b'];
	NormalChars['7'] = ASCIIChars['t'];
	NormalChars['9'] = ASCIIChars['g'];
	NormalChars['('] = ASCIIChars['c'];
	NormalChars[';'] = ASCIIChars['j'];
}

bool CLeetEnDecoder::Decode (char *pIB, char *pOB, char *a, char b)
{

	if (strlen(a) == 2)
		return DDecode (pIB,pOB,a,b);
	if (strlen(a) == 3)
		return TDecode (pIB,pOB,a,b);
	if (strlen(a) == 4)
		return QDecode (pIB,pOB,a,b);
	if (strlen(a) == 5)
		return CDecode (pIB,pOB,a,b);

	return false;
}

bool CLeetEnDecoder::Decode (char *pIB, char *pOB, char a, char b)
{
	return SDecode (pIB,pOB,a,b);
}

//Single Chars
bool CLeetEnDecoder::SDecode (char *pIB, char *pOB, char a, char b)
{
	if (*(pIB) == a)
	{
		*(pOB) = b;
		return true;
	}
	return false;
}

//Double Chars
bool CLeetEnDecoder::DDecode (char *pIB, char *pOB, char *a, char b)
{
	if ((*(pIB) == a[0]) && (*(pIB+1) == a[1]))
	{
		*(pOB) = b;
		return true;
	}
	return false;
}

//Triple Chars
bool CLeetEnDecoder::TDecode (char *pIB, char *pOB, char *a, char b)
{
	if ((*(pIB) == a[0]) && (*(pIB+1) == a[1]) && (*(pIB+2) == a[2]))
	{
		*(pOB) = b;
		return true;
	}
	return false;
}

//Quad Chars
bool CLeetEnDecoder::QDecode (char *pIB, char *pOB, char *a, char b)
{
	if ((*(pIB) == a[0]) && (*(pIB+1) == a[1]) && (*(pIB+2) == a[2]) && (*(pIB+3) == a[3]))
	{
		*(pOB) = b;
		return true;
	}
	return false;
}

//5ive Chars
bool CLeetEnDecoder::CDecode (char *pIB, char *pOB, char *a, char b)
{
	if ((*(pIB) == a[0]) && (*(pIB+1) == a[1]) && (*(pIB+2) == a[2]) && (*(pIB+3) == a[3]) && (*(pIB+3) == a[4]))
	{
		*(pOB) = b;
		return true;
	}
	return false;
}


//Nen String decoden
void CLeetEnDecoder::DecodeString (char *buffer, char *dest)
{
	//Decoder
	char *pIB = buffer; //Pointer To InBuffer
	char *pOB = dest; //Pointer To OutBuffer

	pIB = strlwr(pIB);


	do
	{
		bool bOK = false;

		if (Decode (pIB,pOB,"ph",'f') && !bOK)
		{
			pIB ++;
			bOK = true;
		}


		if (Decode (pIB,pOB,"ae",'�') && !bOK)
		{
			pIB ++;
			bOK = true;
		}

		if (Decode (pIB,pOB,"c:",'�') && !bOK)
		{
			pIB ++;
			bOK = true;
		}

		if (Decode (pIB,pOB,"o:",'�') && !bOK)
		{
			pIB ++;
			bOK = true;
		}

		if (Decode (pIB,pOB,"p|-|",'f') && !bOK)
		{
			pIB += 3;
			bOK = true;
		}

		if (Decode (pIB,pOB,"|>|-|",'f') && !bOK)
		{
			pIB += 4;
			bOK = true;
		}


		if (Decode (pIB,pOB,"|)",'d') && !bOK)
		{
			pIB ++;
			bOK = true;
		}

		if (Decode (pIB,pOB,"|<",'k') && !bOK)
		{
			pIB ++;
			bOK = true;
		}

		if (Decode (pIB,pOB,"|_|",'u') && !bOK)
		{
			pIB += 2;
			bOK = true;
		}

		if (Decode (pIB,pOB,"|_",'l') && !bOK)
		{
			pIB ++;
			bOK = true;
		}


		if (Decode (pIB,pOB,"\\/\\/",'w') && !bOK)
		{
			pIB += 3;
			bOK = true;
		}

		if (Decode (pIB,pOB,"\\/",'v') && !bOK)
		{
			pIB ++;
			bOK = true;
		}

		if (Decode (pIB,pOB,"|-|",'h') && !bOK)
		{
			pIB += 2;
			bOK = true;
		}

		if (Decode (pIB,pOB,"|\\|",'n') && !bOK)
		{
			pIB += 2;
			bOK = true;
		}

		if (Decode (pIB,pOB,"|\\/|",'m') && !bOK)
		{
			pIB += 3;
			bOK = true;
		}

		if (Decode (pIB,pOB,"|>",'p') && !bOK)
		{
			pIB ++;
			bOK = true;
		}

		if (Decode (pIB,pOB,"<|",'q') && !bOK)
		{
			pIB ++;
			bOK = true;
		}

		if (Decode (pIB,pOB,"|^",'r') && !bOK)
		{
			pIB ++;
			bOK = true;
		}


		if (Decode (pIB,pOB,"><",'x') && !bOK)
		{
			pIB ++;
			bOK = true;
		}

		if (Decode (pIB,pOB,"\'/",'y') && !bOK)
		{
			pIB ++;
			bOK = true;
		}


		if (!bOK)
		{
			for (int i = 0; i < 255; i++)
			{
				if (Decode (pIB,pOB,LeetChars[i],NormalChars[LeetChars[i]]))
				{
					bOK = true;
					break;
				}
			}
		}

		//Nicht konvertiert? na gut, dann wird einfach kopiert
		if (!bOK)
			*(pOB) = *(pIB);

		pOB ++;
		pIB ++;
	} while (*(pIB) != 0x00);
}

//StringEncoder
void CLeetEnDecoder::EncodeString (char *buffer, char *dest)
{
	buffer = strlwr(buffer);

	//Encoder
	char *pOB = dest; //Pointer To OutBuffer
	for (unsigned int i = 0; i <= strlen(buffer); i++)
	{
		*(pOB++) = LeetChars[buffer[i]*4];
		if (LeetChars[buffer[i]*4+1] != 0x00)
			*(pOB++) = LeetChars[buffer[i]*4+1];
		if (LeetChars[buffer[i]*4+2] != 0x00)
			*(pOB++) = LeetChars[buffer[i]*4+2];
		if (LeetChars[buffer[i]*4+3] != 0x00)
			*(pOB++) = LeetChars[buffer[i]*4+3];
	}
}
