////////////////////////////////////////////////////
//
// UserPlugs.cpp
//
//   Sample User Plugs
//
//     (C) by Jarek Szpilewski
//         Jarek@DigitalPayne.de
//         http://www.DigitalPayne.de
//
////////////////////////////////////////////////////

#include "UserPlugs.h"
#include "CLeetEnDecoder.h"

#include "../CIrc.h"
#include "../CString.h"

#define SPRUCHDB "data\\spruchdb.txt"
#define WITZDB "data\\witzdb.txt"
#define ASCIIDB "data\\asciidb.txt"
#define HELPDB "data\\help.txt"

//DiePlug
void DiePlug::Init (void *Params)
{
	m_iType = CP_REMOTE;
	m_lpszEvent = "!die";
}

void DiePlug::HandleEvent (void *Params)
{
	CIrcMessage *Message = (CIrcMessage*)Params;
	CString <512> command ("/QUIT :DiePlug::HandleEvent() called by %s ... exitus", Message->m_lpszNick);
	m_lpParentCParser->Execute (command);
}

//LeetDecoderPlug
void LeetDecoderPlug::Init (void *Params)
{
	m_iType = CP_REMOTE;
	m_lpszEvent = "!leet-de";
}

void LeetDecoderPlug::HandleEvent (void *Params)
{
	CIrcMessage *Message = (CIrcMessage*)Params;
	CLeetEnDecoder *Dec = new CLeetEnDecoder;
	char *p = Message->m_lpszPlainText + strlen(m_lpszEvent) +1;

	CString <512> command;
	CString <512> buffer;

	command.set ("%s: ",Message->m_lpszNick);
	Dec->DecodeString (p,buffer);
	strcat(command,buffer);

	m_lpParentCParser->Execute (command);

	delete Dec;
}
//LeetEncoderPlug
void LeetEncoderPlug::Init (void *Params)
{
	m_iType = CP_REMOTE;
	m_lpszEvent = "!de-leet";
}

void LeetEncoderPlug::HandleEvent (void *Params)
{
	CIrcMessage *Message = (CIrcMessage*)Params;
	CLeetEnDecoder *Enc = new CLeetEnDecoder;
	char *p = Message->m_lpszPlainText + strlen(m_lpszEvent)+1;

	CString <512> command;
	CString <512> buffer;

	command.set ("%s: ",Message->m_lpszNick);
	Enc->EncodeString (p,buffer);
	strcat(command,buffer);

	m_lpParentCParser->Execute (command);

	delete Enc;
}

//Spruch Plug
void SpruchPlug::Init (void *Params)
{
	m_iType = CP_REMOTE;
	m_lpszEvent = "!spruch";
}

void SpruchPlug::HandleEvent (void *Params)
{
	CIrcMessage *Message = (CIrcMessage*)Params;
	CString <512> zitat;

	FILE *f = fopen (SPRUCHDB,"rt");

	if (f == NULL)
	{
		zitat.set ("Could not open %s for input!",SPRUCHDB);
		m_lpParentCParser->Execute (zitat);
		return;
	}


	int maxlinecount = 0;
	int r = 0;
	int linecount = 0;


	char c = 0;
	while (!feof(f))
	{
		//fread(&c,1,1,f);
		fscanf(f,"%c",&c);
		if (c == '\n')
			maxlinecount ++;
	};
	fseek(f,0,0);

	srand(GetTickCount());
	r = rand()%maxlinecount;

	do
	{
		fread(&c,1,1,f);
		if (c == '\n')
			linecount ++;
	} while (linecount != r && linecount < maxlinecount);

	int i = 0;
	do
	{
		fread(&zitat[i],1,1,f);
	} while (zitat[i++] != '\n');
	fclose(f);

	printf("[Sende Zitat: %i/%i an %s]\n",r,maxlinecount,Message->m_lpszNick);

	m_lpParentCParser->Execute (zitat);
}

//LernSpruchPlug
void LernSpruchPlug::Init (void *Params)
{
	m_iType = CP_REMOTE;
	m_lpszEvent = "!lernspruch";
}

void LernSpruchPlug::HandleEvent (void *Params)
{
	CIrcMessage *Message = (CIrcMessage*)Params;

	char *p = Message->m_lpszPlainText + strlen(m_lpszEvent)+1;

	CString <512> command;

	FILE *f = fopen (SPRUCHDB,"at");
	if (f == NULL)
	{
		command.set ("Could not open %s for output!",SPRUCHDB);
		m_lpParentCParser->Execute (command);
		return;
	}

	fprintf(f,p);

	fclose(f);

	command.set ("%s: Spruch in Datenbank aufgenommmen.",Message->m_lpszNick);
	m_lpParentCParser->Execute (command);

//	delete [] command;
}


//WitzPlug
void WitzPlug::Init (void *Params)
{
	m_iType = CP_REMOTE;
	m_lpszEvent = "!witz";
}

void WitzPlug::HandleEvent (void *Params)
{
	CIrcMessage *Message = (CIrcMessage*)Params;

	CString <4096> witz;
	CString <512> command;


	FILE *f = fopen (WITZDB,"rt");

	if (f == NULL)
	{
		sprintf(command,"Could not open %s for input!",WITZDB);
		m_lpParentCParser->Execute (command);
		return;
	}


	int maxwitzcount = 0;
	int r = 0;
	int witzcount = 0;


	//Witze zaehlen
	char c = 0;
	while (!feof(f))
	{
		fscanf(f,"%c",&c);
		if (c == '{')
			maxwitzcount ++;
	};
	fseek(f,0,0);

	srand(GetTickCount());
	r = rand()%maxwitzcount + 1;

	//Den Witz suchen
	do
	{
		fread(&c,1,1,f);
		if (c == '{')
			witzcount ++;
	} while (witzcount != r && witzcount < maxwitzcount);

	fread(&c,1,1,f);
	//Witz auslesen
	int i = 0;
	int ilast = 0;
	do
	{
		fread(&witz[i],1,1,f);

		if (witz[i] == '\n')
		{
			witz[i] = 0x00;
			memcpy(command,witz,strlen(witz));
			//printf(command);

			m_lpParentCParser->Execute (command);

			command.flush ();
			witz.flush ();
			i = -1;
		}

		if (witz[i] == '}')
			break;

		i++;


	} while (1);

	fclose(f);

	printf("[Sende Witz: %i/%i an %s]\n",r,maxwitzcount,Message->m_lpszNick);
}

//ASCIIPlug
void ASCIIPlug::Init (void *Params)
{
	m_iType = CP_REMOTE;
	m_lpszEvent = "!ascii";
}

void ASCIIPlug::HandleEvent (void *Params)
{
	CIrcMessage *Message = (CIrcMessage*)Params;

	CString <4096> item;
	CString <512> command;


	FILE *f = fopen (ASCIIDB,"rt");

	if (f == NULL)
	{
		sprintf(command,"Could not open %s for input!",ASCIIDB);
		m_lpParentCParser->Execute (command);
		return;
	}


	int maxitemcount = 0;
	int r = 0;
	int itemcount = 0;


	//items zaehlen
	char c = 0;
	while (!feof(f))
	{
		fscanf(f,"%c",&c);
		if (c == '{')
			maxitemcount ++;
	};
	fseek(f,0,0);

	srand(GetTickCount());
	r = rand()%maxitemcount + 1;

	//Den item suchen
	do
	{
		fread(&c,1,1,f);
		if (c == '{')
			itemcount ++;
	} while (itemcount != r && itemcount < maxitemcount);

	fread(&c,1,1,f);
	//item auslesen
	int i = 0;
	int ilast = 0;
	do
	{
		fread(&item[i],1,1,f);

		if (item[i] == '\n')
		{
			item[i] = 0x00;
			memcpy(command,item,strlen(item));
			//printf(command);

			m_lpParentCParser->Execute (command);

			item.flush ();
			command.flush ();
			i = -1;
		}

		if (item[i] == '}')
			break;

		i++;


	} while (1);

	fclose(f);

	printf("[Sende ASCII: %i/%i an %s]\n",r,maxitemcount,Message->m_lpszNick);

}

//HelpPlug
void HelpPlug::Init (void *Params)
{
	m_iType = CP_REMOTE;
	m_lpszEvent = "!help";
}

void HelpPlug::HandleEvent (void *Params)
{
	CIrcMessage *Message = (CIrcMessage*)Params;

	CString <4096> item;
	CString <512> command;


	FILE *f = fopen (HELPDB,"rt");

	if (f == NULL)
	{
		sprintf(command,"Could not open %s for input!",HELPDB);
		m_lpParentCParser->Execute (command);
		return;
	}


	int maxitemcount = 0;
	int r = 0;
	int itemcount = 0;


	//items zaehlen
	char c = 0;
	while (!feof(f))
	{
		fscanf(f,"%c",&c);
		if (c == '{')
			maxitemcount ++;
	};
	fseek(f,0,0);

	srand(GetTickCount());
	r = rand()%maxitemcount;

	//Den item suchen

	do
	{
		fread(&c,1,1,f);
		if (c == '{')
			itemcount ++;
	} while (itemcount != r && itemcount < maxitemcount);

	fread(&c,1,1,f);
	//item auslesen
	int i = 0;
	int ilast = 0;
	do
	{
		fread(&item[i],1,1,f);

		if (item[i] == '\n')
		{
			item[i] = 0x00;
			memcpy(command,item,strlen(item));
			//printf(command);

			m_lpParentCParser->Execute (command);

			item.flush ();
			command.flush ();
			i = -1;
		}

		if (item[i] == '}')
			break;

		if (++i >= 512)
			break;


	} while (1);

	fclose(f);

	printf("[Sende help: %i/%i an %s]\n",r,maxitemcount,Message->m_lpszNick);
}


