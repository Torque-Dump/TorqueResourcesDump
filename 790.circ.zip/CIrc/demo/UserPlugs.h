////////////////////////////////////////////////////
//
// UserPlugs.h
//
//   Sample User Plugs
//
//     (C) by Jarek Szpilewski
//         Jarek@DigitalPayne.de
//         http://www.DigitalPayne.de
//
////////////////////////////////////////////////////

#ifndef __UserPlugs_h__
#define __UserPlugs_h__
#include "../CPlug.h"

class DiePlug : public CPlug
{
public:
	void Init (void *Params);
	void HandleEvent (void *Params);
};

class LeetDecoderPlug : public CPlug
{
public:
	void Init (void *Params);
	void HandleEvent (void *Params);
};

class LeetEncoderPlug : public CPlug
{
public:
	void Init (void *Params);
	void HandleEvent (void *Params);
};

class SpruchPlug : public CPlug
{
public:
	void Init (void *Params);
	void HandleEvent (void *Params);
};

class LernSpruchPlug : public CPlug
{
public:
	void Init (void *Params);
	void HandleEvent (void *Params);
};

class WitzPlug : public CPlug
{
public:
	void Init (void *Params);
	void HandleEvent (void *Params);
};

class ASCIIPlug : public CPlug
{
public:
	void Init (void *Params);
	void HandleEvent (void *Params);
};

class HelpPlug : public CPlug
{
public:
	void Init (void *Params);
	void HandleEvent (void *Params);
};


#endif