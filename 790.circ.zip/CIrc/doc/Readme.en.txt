CIrc 0.1b Readme
================

What's it?
----------
CIrc is a collection of some classes I've written to simplify
the communication over the IRC-protocol. There's also a little
demo that shows how to use the classes.


Copyright
---------
The code is (c) by Jarek Szpilewski
Free use for not comercial software allowed!
I do not guarantee anything! :)


Contact
-------
mail: jarek@digitalpayne.de
web: http://www.digitalpayne.de

Excuse my bad English :)