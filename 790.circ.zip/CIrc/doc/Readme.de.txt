CIrc 0.1b Readme
================

Was ist das?
------------
Hierbei handelt es sich um eine Ansammlung von C++ Klassen,
die den Umgang mit dem IRC-Protokoll vereinfachen sollen.
Anbei liegt eine kleine Demonstration der Faehigkeiten dieser
Klassensammlung.


Copyright
---------
Der Code ist (C) by Jarek Szpilewski
Die unsingeschraenkte Nutzung fuer nichtkommerzielle Zwecke ist erlaubt!
Bei Verwendung in einem kommerziellen Produkt bitte anfragen!
Der Autor uebernimmt keinerlei Verantwortung/Garantie.


Kontakt
-------
mail: jarek@digitalpayne.de
web: http://www.digitalpayne.de