datablock TSShapeConstructor(MarineDts)
{
   baseShape = "./marine.dts";
   sequence0 = "./marine_run.dsq run";
   sequence1 = "./marine_root.dsq root";
   sequence2 = "./marine_look.dsq look";
   sequence3 = "./marine_crouchroot.dsq crouchroot";
   sequence4 = "./marine_crouchforward.dsq crouchforward";
   sequence5 = "./marine_crouchdie.dsq crouchdie";
   sequence6 = "./marine_reloadRifle.dsq reloadRifle";
   sequence7 = "./marine_standdie0.dsq standdie0";
   sequence8 = "./marine_pistolLook.dsq pistolLook";
   sequence9 = "./marine_nullLook.dsq nullLook";
   sequence10 = "./marine_standHide.dsq standHide";
   sequence11 = "./marine_standRight.dsq standRight";
   sequence12 = "./marine_standLeft.dsq standLeft";
   sequence13 = "./marine_crouchhide.dsq crouchhide";
   sequence14 = "./marine_standFire.dsq standFire";
   sequence15 = "./marine_forwardDeath.dsq forwardDeath";
   sequence16 = "./marine_side.dsq side";
   sequence17 = "./marine_standdie1.dsq standdie1";
   sequence18 = "./marine_standdie2.dsq standdie2";
   sequence19 = "./marine_run.dsq back";
};
