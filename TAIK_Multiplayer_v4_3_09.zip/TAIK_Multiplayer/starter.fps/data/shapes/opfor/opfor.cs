datablock TSShapeConstructor(OpforDts)
{
   baseShape = "./opfor.dts";
   sequence0 = "./opfor.dsq";
};
