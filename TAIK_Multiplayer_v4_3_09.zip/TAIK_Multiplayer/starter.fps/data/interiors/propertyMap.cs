//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

addMaterialMapping( "Floor_slate01" , "sound: 0" );
addMaterialMapping( "Floor_tile01"  , "sound: 1" );
addMaterialMapping( "FlrFiller3_01" , "sound: 2" );
addMaterialMapping( "FlrFiller3_02" , "sound: 3" );
addMaterialMapping( "FlrFiller3_03" , "sound: 1" );