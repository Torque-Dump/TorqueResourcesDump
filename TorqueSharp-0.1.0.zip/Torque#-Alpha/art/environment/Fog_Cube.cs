
singleton TSShapeConstructor(Fog_CubeDAE)
{
   baseShape = "./Fog_Cube.DAE";
   lodType = "TrailingNumber";
   neverImport = "env*";
   loadLights = "0";
};
