﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;

namespace Torque3D
{
   internal class EngineCallbacks
   {
      private static readonly Dictionary<string, Type> ClassTypeDictionary = new Dictionary<string, Type>();
      private static readonly Dictionary<string, MethodInfo> FunctionDictionary = new Dictionary<string, MethodInfo>();
      private static readonly Dictionary<int, SimObject> ObjectDictionary = new Dictionary<int, SimObject>();

      public static void RegisterType(string className, Type classType)
      {
         ClassTypeDictionary.Add(className, classType);
      }

      public static void RegisterFunction(string functionName, MethodInfo methodInfo)
      {
         FunctionDictionary.Add(functionName, methodInfo);
      }

      public static void Clear()
      {
         ClassTypeDictionary.Clear();
         FunctionDictionary.Clear();
      }

      public static string CallScriptFunction(string pFunctionName, object[] args, out bool found)
      {
         if (!FunctionDictionary.ContainsKey(pFunctionName))
         {
            found = false;
            return null;
         }
         found = true;
         MethodInfo methodInfo = FunctionDictionary[pFunctionName];
         // todo: make automatic typecasting if posisble
         if (methodInfo.ReturnType == typeof(string))
            return (string)methodInfo.Invoke(null, args);
         if (methodInfo.ReturnType == typeof(bool))
            return (bool)methodInfo.Invoke(null, args) ? "1" : "0";
         methodInfo.Invoke(null, args);
         return null;
      }

      public static string CallScriptMethod(string className, SimObject objectWrapper, string methodName, object[] args,
         out bool found)
      {
         Type type;
         string objectName = objectWrapper?.getName();
         if (objectName != null && ClassTypeDictionary.ContainsKey(objectName))
         {
            type = ClassTypeDictionary[objectName];
         }
         else if (ClassTypeDictionary.ContainsKey(className))
         {
            type = ClassTypeDictionary[className];
         }
         else
         {
            //todo throw exception?
            found = false;
            return null;
         }
         MethodInfo callbackMethod = type.GetMethod(methodName);
         if (callbackMethod != null)
         {
            found = true;
            object simObj = null;
            if (!callbackMethod.IsStatic)
               simObj = CreateInstance(type, objectWrapper);
            if (callbackMethod.ReturnType == typeof(string))
               return (string)callbackMethod.Invoke(simObj, args);
            callbackMethod.Invoke(simObj, args);
            return null;
         }
         found = false;
         return null;
      }

      private static object CreateInstance(Type type, SimObject objectWrapper)
      {
         if (!ObjectDictionary.ContainsKey(objectWrapper.getId()))
         {
            SimObject obj = (SimObject)FormatterServices.GetUninitializedObject(type);
            obj.SetPointerFromObject(objectWrapper);
            ObjectDictionary[objectWrapper.getId()] = obj;
         }
         return ObjectDictionary[objectWrapper.getId()];
      }

      public static bool IsMethod(string className, string methodName)
      {
         if (string.IsNullOrWhiteSpace(className))
            return FunctionDictionary.ContainsKey(methodName);
         if (!ClassTypeDictionary.ContainsKey(className))
            return false;
         return ClassTypeDictionary[className].GetMethod(methodName) != null;
      }
   }
}
