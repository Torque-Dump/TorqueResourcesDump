using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class RenderShapeExample : SceneObject
	{
		public RenderShapeExample()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.RenderShapeExample_create());
		}

		public RenderShapeExample(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public RenderShapeExample(SimObject pObj) : base(pObj)
		{
		}

		public RenderShapeExample(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _RenderShapeExample_create();
         private static _RenderShapeExample_create _RenderShapeExample_createFunc;
         internal static IntPtr RenderShapeExample_create()
         {
         	if (_RenderShapeExample_createFunc == null)
         	{
         		_RenderShapeExample_createFunc =
         			(_RenderShapeExample_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_RenderShapeExample_create"), typeof(_RenderShapeExample_create));
         	}
         
         	return  _RenderShapeExample_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}