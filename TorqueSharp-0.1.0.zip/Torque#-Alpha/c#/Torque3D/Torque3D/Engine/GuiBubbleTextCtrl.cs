using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiBubbleTextCtrl : GuiTextCtrl
	{
		public GuiBubbleTextCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiBubbleTextCtrl_create());
		}

		public GuiBubbleTextCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiBubbleTextCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiBubbleTextCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiBubbleTextCtrl_create();
         private static _GuiBubbleTextCtrl_create _GuiBubbleTextCtrl_createFunc;
         internal static IntPtr GuiBubbleTextCtrl_create()
         {
         	if (_GuiBubbleTextCtrl_createFunc == null)
         	{
         		_GuiBubbleTextCtrl_createFunc =
         			(_GuiBubbleTextCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiBubbleTextCtrl_create"), typeof(_GuiBubbleTextCtrl_create));
         	}
         
         	return  _GuiBubbleTextCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}