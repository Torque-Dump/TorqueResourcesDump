using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class CloudLayer : SceneObject
	{
		public CloudLayer()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.CloudLayer_create());
		}

		public CloudLayer(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public CloudLayer(SimObject pObj) : base(pObj)
		{
		}

		public CloudLayer(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _CloudLayer_create();
         private static _CloudLayer_create _CloudLayer_createFunc;
         internal static IntPtr CloudLayer_create()
         {
         	if (_CloudLayer_createFunc == null)
         	{
         		_CloudLayer_createFunc =
         			(_CloudLayer_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_CloudLayer_create"), typeof(_CloudLayer_create));
         	}
         
         	return  _CloudLayer_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}