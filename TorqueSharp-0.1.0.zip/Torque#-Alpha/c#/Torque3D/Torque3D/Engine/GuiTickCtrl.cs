using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiTickCtrl : GuiControl
	{
		public GuiTickCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiTickCtrl_create());
		}

		public GuiTickCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiTickCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiTickCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setProcessTicks(IntPtr thisPtr, bool tick);
         private static _setProcessTicks _setProcessTicksFunc;
         internal static void setProcessTicks(IntPtr thisPtr, bool tick)
         {
         	if (_setProcessTicksFunc == null)
         	{
         		_setProcessTicksFunc =
         			(_setProcessTicks)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiTickCtrl_setProcessTicks"), typeof(_setProcessTicks));
         	}
         
         	 _setProcessTicksFunc(thisPtr, tick);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiTickCtrl_create();
         private static _GuiTickCtrl_create _GuiTickCtrl_createFunc;
         internal static IntPtr GuiTickCtrl_create()
         {
         	if (_GuiTickCtrl_createFunc == null)
         	{
         		_GuiTickCtrl_createFunc =
         			(_GuiTickCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiTickCtrl_create"), typeof(_GuiTickCtrl_create));
         	}
         
         	return  _GuiTickCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void setProcessTicks(bool tick = true)
         {
            InternalUnsafeMethods.setProcessTicks(ObjectPtr->RefPtr->ObjPtr, tick);
         }
      
      
      #endregion

	}
}