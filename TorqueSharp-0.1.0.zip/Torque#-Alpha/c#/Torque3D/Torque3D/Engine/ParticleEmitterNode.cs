using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ParticleEmitterNode : GameBase
	{
		public ParticleEmitterNode()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ParticleEmitterNode_create());
		}

		public ParticleEmitterNode(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ParticleEmitterNode(SimObject pObj) : base(pObj)
		{
		}

		public ParticleEmitterNode(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setEmitterDataBlock(IntPtr thisPtr, IntPtr emitterDatablock);
         private static _setEmitterDataBlock _setEmitterDataBlockFunc;
         internal static void setEmitterDataBlock(IntPtr thisPtr, IntPtr emitterDatablock)
         {
         	if (_setEmitterDataBlockFunc == null)
         	{
         		_setEmitterDataBlockFunc =
         			(_setEmitterDataBlock)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnParticleEmitterNode_setEmitterDataBlock"), typeof(_setEmitterDataBlock));
         	}
         
         	 _setEmitterDataBlockFunc(thisPtr, emitterDatablock);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setActive(IntPtr thisPtr, bool active);
         private static _setActive _setActiveFunc;
         internal static void setActive(IntPtr thisPtr, bool active)
         {
         	if (_setActiveFunc == null)
         	{
         		_setActiveFunc =
         			(_setActive)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnParticleEmitterNode_setActive"), typeof(_setActive));
         	}
         
         	 _setActiveFunc(thisPtr, active);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ParticleEmitterNode_create();
         private static _ParticleEmitterNode_create _ParticleEmitterNode_createFunc;
         internal static IntPtr ParticleEmitterNode_create()
         {
         	if (_ParticleEmitterNode_createFunc == null)
         	{
         		_ParticleEmitterNode_createFunc =
         			(_ParticleEmitterNode_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ParticleEmitterNode_create"), typeof(_ParticleEmitterNode_create));
         	}
         
         	return  _ParticleEmitterNode_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void setEmitterDataBlock(ParticleEmitterData emitterDatablock = null)
         {
            InternalUnsafeMethods.setEmitterDataBlock(ObjectPtr->RefPtr->ObjPtr, emitterDatablock.ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setActive(bool active)
         {
            InternalUnsafeMethods.setActive(ObjectPtr->RefPtr->ObjPtr, active);
         }
      
      
      #endregion

	}
}