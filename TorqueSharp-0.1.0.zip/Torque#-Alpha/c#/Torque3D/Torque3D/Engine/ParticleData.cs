using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ParticleData : SimDataBlock
	{
		public ParticleData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ParticleData_create());
		}

		public ParticleData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ParticleData(SimObject pObj) : base(pObj)
		{
		}

		public ParticleData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _reload(IntPtr thisPtr);
         private static _reload _reloadFunc;
         internal static void reload(IntPtr thisPtr)
         {
         	if (_reloadFunc == null)
         	{
         		_reloadFunc =
         			(_reload)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnParticleData_reload"), typeof(_reload));
         	}
         
         	 _reloadFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ParticleData_create();
         private static _ParticleData_create _ParticleData_createFunc;
         internal static IntPtr ParticleData_create()
         {
         	if (_ParticleData_createFunc == null)
         	{
         		_ParticleData_createFunc =
         			(_ParticleData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ParticleData_create"), typeof(_ParticleData_create));
         	}
         
         	return  _ParticleData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void reload()
         {
            InternalUnsafeMethods.reload(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}