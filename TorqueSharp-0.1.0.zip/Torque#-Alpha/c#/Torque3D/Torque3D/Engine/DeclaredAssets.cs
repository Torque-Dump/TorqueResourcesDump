using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class DeclaredAssets : SimObject
	{
		public DeclaredAssets()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.DeclaredAssets_create());
		}

		public DeclaredAssets(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public DeclaredAssets(SimObject pObj) : base(pObj)
		{
		}

		public DeclaredAssets(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _DeclaredAssets_create();
         private static _DeclaredAssets_create _DeclaredAssets_createFunc;
         internal static IntPtr DeclaredAssets_create()
         {
         	if (_DeclaredAssets_createFunc == null)
         	{
         		_DeclaredAssets_createFunc =
         			(_DeclaredAssets_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_DeclaredAssets_create"), typeof(_DeclaredAssets_create));
         	}
         
         	return  _DeclaredAssets_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}