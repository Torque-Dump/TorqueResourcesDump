using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class FlyingVehicleData : VehicleData
	{
		public FlyingVehicleData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.FlyingVehicleData_create());
		}

		public FlyingVehicleData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public FlyingVehicleData(SimObject pObj) : base(pObj)
		{
		}

		public FlyingVehicleData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _FlyingVehicleData_create();
         private static _FlyingVehicleData_create _FlyingVehicleData_createFunc;
         internal static IntPtr FlyingVehicleData_create()
         {
         	if (_FlyingVehicleData_createFunc == null)
         	{
         		_FlyingVehicleData_createFunc =
         			(_FlyingVehicleData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_FlyingVehicleData_create"), typeof(_FlyingVehicleData_create));
         	}
         
         	return  _FlyingVehicleData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}