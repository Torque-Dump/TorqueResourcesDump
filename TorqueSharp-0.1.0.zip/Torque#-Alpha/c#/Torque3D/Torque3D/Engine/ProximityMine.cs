using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ProximityMine : Item
	{
		public ProximityMine()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ProximityMine_create());
		}

		public ProximityMine(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ProximityMine(SimObject pObj) : base(pObj)
		{
		}

		public ProximityMine(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _explode(IntPtr thisPtr);
         private static _explode _explodeFunc;
         internal static void explode(IntPtr thisPtr)
         {
         	if (_explodeFunc == null)
         	{
         		_explodeFunc =
         			(_explode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnProximityMine_explode"), typeof(_explode));
         	}
         
         	 _explodeFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ProximityMine_create();
         private static _ProximityMine_create _ProximityMine_createFunc;
         internal static IntPtr ProximityMine_create()
         {
         	if (_ProximityMine_createFunc == null)
         	{
         		_ProximityMine_createFunc =
         			(_ProximityMine_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ProximityMine_create"), typeof(_ProximityMine_create));
         	}
         
         	return  _ProximityMine_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void explode()
         {
            InternalUnsafeMethods.explode(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}