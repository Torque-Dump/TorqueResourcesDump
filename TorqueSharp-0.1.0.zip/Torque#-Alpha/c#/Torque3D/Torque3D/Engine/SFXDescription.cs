using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class SFXDescription : SimDataBlock
	{
		public SFXDescription()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.SFXDescription_create());
		}

		public SFXDescription(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public SFXDescription(SimObject pObj) : base(pObj)
		{
		}

		public SFXDescription(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _SFXDescription_create();
         private static _SFXDescription_create _SFXDescription_createFunc;
         internal static IntPtr SFXDescription_create()
         {
         	if (_SFXDescription_createFunc == null)
         	{
         		_SFXDescription_createFunc =
         			(_SFXDescription_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_SFXDescription_create"), typeof(_SFXDescription_create));
         	}
         
         	return  _SFXDescription_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}