using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class SFXState : SimDataBlock
	{
		public SFXState()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.SFXState_create());
		}

		public SFXState(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public SFXState(SimObject pObj) : base(pObj)
		{
		}

		public SFXState(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _isActive(IntPtr thisPtr);
         private static _isActive _isActiveFunc;
         internal static bool isActive(IntPtr thisPtr)
         {
         	if (_isActiveFunc == null)
         	{
         		_isActiveFunc =
         			(_isActive)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnSFXState_isActive"), typeof(_isActive));
         	}
         
         	return  _isActiveFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _activate(IntPtr thisPtr);
         private static _activate _activateFunc;
         internal static void activate(IntPtr thisPtr)
         {
         	if (_activateFunc == null)
         	{
         		_activateFunc =
         			(_activate)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnSFXState_activate"), typeof(_activate));
         	}
         
         	 _activateFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _deactivate(IntPtr thisPtr);
         private static _deactivate _deactivateFunc;
         internal static void deactivate(IntPtr thisPtr)
         {
         	if (_deactivateFunc == null)
         	{
         		_deactivateFunc =
         			(_deactivate)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnSFXState_deactivate"), typeof(_deactivate));
         	}
         
         	 _deactivateFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _isDisabled(IntPtr thisPtr);
         private static _isDisabled _isDisabledFunc;
         internal static bool isDisabled(IntPtr thisPtr)
         {
         	if (_isDisabledFunc == null)
         	{
         		_isDisabledFunc =
         			(_isDisabled)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnSFXState_isDisabled"), typeof(_isDisabled));
         	}
         
         	return  _isDisabledFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _disable(IntPtr thisPtr);
         private static _disable _disableFunc;
         internal static void disable(IntPtr thisPtr)
         {
         	if (_disableFunc == null)
         	{
         		_disableFunc =
         			(_disable)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnSFXState_disable"), typeof(_disable));
         	}
         
         	 _disableFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _enable(IntPtr thisPtr);
         private static _enable _enableFunc;
         internal static void enable(IntPtr thisPtr)
         {
         	if (_enableFunc == null)
         	{
         		_enableFunc =
         			(_enable)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnSFXState_enable"), typeof(_enable));
         	}
         
         	 _enableFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _SFXState_create();
         private static _SFXState_create _SFXState_createFunc;
         internal static IntPtr SFXState_create()
         {
         	if (_SFXState_createFunc == null)
         	{
         		_SFXState_createFunc =
         			(_SFXState_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_SFXState_create"), typeof(_SFXState_create));
         	}
         
         	return  _SFXState_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public bool isActive()
         {
            return InternalUnsafeMethods.isActive(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void activate()
         {
            InternalUnsafeMethods.activate(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void deactivate()
         {
            InternalUnsafeMethods.deactivate(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public bool isDisabled()
         {
            return InternalUnsafeMethods.isDisabled(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void disable()
         {
            InternalUnsafeMethods.disable(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void enable()
         {
            InternalUnsafeMethods.enable(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}