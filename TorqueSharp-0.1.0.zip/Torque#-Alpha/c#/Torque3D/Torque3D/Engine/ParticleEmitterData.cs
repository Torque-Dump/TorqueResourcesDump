using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ParticleEmitterData : GameBaseData
	{
		public ParticleEmitterData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ParticleEmitterData_create());
		}

		public ParticleEmitterData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ParticleEmitterData(SimObject pObj) : base(pObj)
		{
		}

		public ParticleEmitterData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _reload(IntPtr thisPtr);
         private static _reload _reloadFunc;
         internal static void reload(IntPtr thisPtr)
         {
         	if (_reloadFunc == null)
         	{
         		_reloadFunc =
         			(_reload)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnParticleEmitterData_reload"), typeof(_reload));
         	}
         
         	 _reloadFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ParticleEmitterData_create();
         private static _ParticleEmitterData_create _ParticleEmitterData_createFunc;
         internal static IntPtr ParticleEmitterData_create()
         {
         	if (_ParticleEmitterData_createFunc == null)
         	{
         		_ParticleEmitterData_createFunc =
         			(_ParticleEmitterData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ParticleEmitterData_create"), typeof(_ParticleEmitterData_create));
         	}
         
         	return  _ParticleEmitterData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void reload()
         {
            InternalUnsafeMethods.reload(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}