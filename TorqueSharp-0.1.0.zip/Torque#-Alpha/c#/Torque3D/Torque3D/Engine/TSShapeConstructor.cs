using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class TSShapeConstructor : SimObject
	{
		public TSShapeConstructor()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.TSShapeConstructor_create());
		}

		public TSShapeConstructor(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public TSShapeConstructor(SimObject pObj) : base(pObj)
		{
		}

		public TSShapeConstructor(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _addPrimitive(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string meshName, [MarshalAs(UnmanagedType.LPWStr)]string type, [MarshalAs(UnmanagedType.LPWStr)]string _params, InternalTransformStruct txfm, [MarshalAs(UnmanagedType.LPWStr)]string nodeName);
         private static _addPrimitive _addPrimitiveFunc;
         internal static bool addPrimitive(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string meshName, [MarshalAs(UnmanagedType.LPWStr)]string type, [MarshalAs(UnmanagedType.LPWStr)]string _params, InternalTransformStruct txfm, [MarshalAs(UnmanagedType.LPWStr)]string nodeName)
         {
         	if (_addPrimitiveFunc == null)
         	{
         		_addPrimitiveFunc =
         			(_addPrimitive)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_addPrimitive"), typeof(_addPrimitive));
         	}
         
         	return  _addPrimitiveFunc(thisPtr, meshName, type, _params, txfm, nodeName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _addCollisionDetail(IntPtr thisPtr, int size, [MarshalAs(UnmanagedType.LPWStr)]string type, [MarshalAs(UnmanagedType.LPWStr)]string target, int depth, float merge, float concavity, int maxVerts, float boxMaxError, float sphereMaxError, float capsuleMaxError);
         private static _addCollisionDetail _addCollisionDetailFunc;
         internal static bool addCollisionDetail(IntPtr thisPtr, int size, [MarshalAs(UnmanagedType.LPWStr)]string type, [MarshalAs(UnmanagedType.LPWStr)]string target, int depth, float merge, float concavity, int maxVerts, float boxMaxError, float sphereMaxError, float capsuleMaxError)
         {
         	if (_addCollisionDetailFunc == null)
         	{
         		_addCollisionDetailFunc =
         			(_addCollisionDetail)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_addCollisionDetail"), typeof(_addCollisionDetail));
         	}
         
         	return  _addCollisionDetailFunc(thisPtr, size, type, target, depth, merge, concavity, maxVerts, boxMaxError, sphereMaxError, capsuleMaxError);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _dumpShape(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string filename);
         private static _dumpShape _dumpShapeFunc;
         internal static void dumpShape(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string filename)
         {
         	if (_dumpShapeFunc == null)
         	{
         		_dumpShapeFunc =
         			(_dumpShape)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_dumpShape"), typeof(_dumpShape));
         	}
         
         	 _dumpShapeFunc(thisPtr, filename);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _saveShape(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string filename);
         private static _saveShape _saveShapeFunc;
         internal static void saveShape(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string filename)
         {
         	if (_saveShapeFunc == null)
         	{
         		_saveShapeFunc =
         			(_saveShape)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_saveShape"), typeof(_saveShape));
         	}
         
         	 _saveShapeFunc(thisPtr, filename);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _writeChangeSet(IntPtr thisPtr);
         private static _writeChangeSet _writeChangeSetFunc;
         internal static void writeChangeSet(IntPtr thisPtr)
         {
         	if (_writeChangeSetFunc == null)
         	{
         		_writeChangeSetFunc =
         			(_writeChangeSet)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_writeChangeSet"), typeof(_writeChangeSet));
         	}
         
         	 _writeChangeSetFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _notifyShapeChanged(IntPtr thisPtr);
         private static _notifyShapeChanged _notifyShapeChangedFunc;
         internal static void notifyShapeChanged(IntPtr thisPtr)
         {
         	if (_notifyShapeChangedFunc == null)
         	{
         		_notifyShapeChangedFunc =
         			(_notifyShapeChanged)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_notifyShapeChanged"), typeof(_notifyShapeChanged));
         	}
         
         	 _notifyShapeChangedFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getNodeCount(IntPtr thisPtr);
         private static _getNodeCount _getNodeCountFunc;
         internal static int getNodeCount(IntPtr thisPtr)
         {
         	if (_getNodeCountFunc == null)
         	{
         		_getNodeCountFunc =
         			(_getNodeCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getNodeCount"), typeof(_getNodeCount));
         	}
         
         	return  _getNodeCountFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getNodeIndex(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getNodeIndex _getNodeIndexFunc;
         internal static int getNodeIndex(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getNodeIndexFunc == null)
         	{
         		_getNodeIndexFunc =
         			(_getNodeIndex)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getNodeIndex"), typeof(_getNodeIndex));
         	}
         
         	return  _getNodeIndexFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getNodeName(IntPtr thisPtr, int index);
         private static _getNodeName _getNodeNameFunc;
         internal static IntPtr getNodeName(IntPtr thisPtr, int index)
         {
         	if (_getNodeNameFunc == null)
         	{
         		_getNodeNameFunc =
         			(_getNodeName)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getNodeName"), typeof(_getNodeName));
         	}
         
         	return  _getNodeNameFunc(thisPtr, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getNodeParentName(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getNodeParentName _getNodeParentNameFunc;
         internal static IntPtr getNodeParentName(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getNodeParentNameFunc == null)
         	{
         		_getNodeParentNameFunc =
         			(_getNodeParentName)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getNodeParentName"), typeof(_getNodeParentName));
         	}
         
         	return  _getNodeParentNameFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _setNodeParent(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, [MarshalAs(UnmanagedType.LPWStr)]string parentName);
         private static _setNodeParent _setNodeParentFunc;
         internal static bool setNodeParent(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, [MarshalAs(UnmanagedType.LPWStr)]string parentName)
         {
         	if (_setNodeParentFunc == null)
         	{
         		_setNodeParentFunc =
         			(_setNodeParent)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_setNodeParent"), typeof(_setNodeParent));
         	}
         
         	return  _setNodeParentFunc(thisPtr, name, parentName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getNodeChildCount(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getNodeChildCount _getNodeChildCountFunc;
         internal static int getNodeChildCount(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getNodeChildCountFunc == null)
         	{
         		_getNodeChildCountFunc =
         			(_getNodeChildCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getNodeChildCount"), typeof(_getNodeChildCount));
         	}
         
         	return  _getNodeChildCountFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getNodeChildName(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int index);
         private static _getNodeChildName _getNodeChildNameFunc;
         internal static IntPtr getNodeChildName(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int index)
         {
         	if (_getNodeChildNameFunc == null)
         	{
         		_getNodeChildNameFunc =
         			(_getNodeChildName)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getNodeChildName"), typeof(_getNodeChildName));
         	}
         
         	return  _getNodeChildNameFunc(thisPtr, name, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getNodeObjectCount(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getNodeObjectCount _getNodeObjectCountFunc;
         internal static int getNodeObjectCount(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getNodeObjectCountFunc == null)
         	{
         		_getNodeObjectCountFunc =
         			(_getNodeObjectCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getNodeObjectCount"), typeof(_getNodeObjectCount));
         	}
         
         	return  _getNodeObjectCountFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getNodeObjectName(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int index);
         private static _getNodeObjectName _getNodeObjectNameFunc;
         internal static IntPtr getNodeObjectName(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int index)
         {
         	if (_getNodeObjectNameFunc == null)
         	{
         		_getNodeObjectNameFunc =
         			(_getNodeObjectName)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getNodeObjectName"), typeof(_getNodeObjectName));
         	}
         
         	return  _getNodeObjectNameFunc(thisPtr, name, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate InternalTransformStruct _getNodeTransform(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, bool isWorld);
         private static _getNodeTransform _getNodeTransformFunc;
         internal static InternalTransformStruct getNodeTransform(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, bool isWorld)
         {
         	if (_getNodeTransformFunc == null)
         	{
         		_getNodeTransformFunc =
         			(_getNodeTransform)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getNodeTransform"), typeof(_getNodeTransform));
         	}
         
         	return  _getNodeTransformFunc(thisPtr, name, isWorld);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _setNodeTransform(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, InternalTransformStruct txfm, bool isWorld);
         private static _setNodeTransform _setNodeTransformFunc;
         internal static bool setNodeTransform(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, InternalTransformStruct txfm, bool isWorld)
         {
         	if (_setNodeTransformFunc == null)
         	{
         		_setNodeTransformFunc =
         			(_setNodeTransform)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_setNodeTransform"), typeof(_setNodeTransform));
         	}
         
         	return  _setNodeTransformFunc(thisPtr, name, txfm, isWorld);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _renameNode(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string oldName, [MarshalAs(UnmanagedType.LPWStr)]string newName);
         private static _renameNode _renameNodeFunc;
         internal static bool renameNode(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string oldName, [MarshalAs(UnmanagedType.LPWStr)]string newName)
         {
         	if (_renameNodeFunc == null)
         	{
         		_renameNodeFunc =
         			(_renameNode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_renameNode"), typeof(_renameNode));
         	}
         
         	return  _renameNodeFunc(thisPtr, oldName, newName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _addNode(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, [MarshalAs(UnmanagedType.LPWStr)]string parentName, InternalTransformStruct txfm, bool isWorld);
         private static _addNode _addNodeFunc;
         internal static bool addNode(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, [MarshalAs(UnmanagedType.LPWStr)]string parentName, InternalTransformStruct txfm, bool isWorld)
         {
         	if (_addNodeFunc == null)
         	{
         		_addNodeFunc =
         			(_addNode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_addNode"), typeof(_addNode));
         	}
         
         	return  _addNodeFunc(thisPtr, name, parentName, txfm, isWorld);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _removeNode(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _removeNode _removeNodeFunc;
         internal static bool removeNode(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_removeNodeFunc == null)
         	{
         		_removeNodeFunc =
         			(_removeNode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_removeNode"), typeof(_removeNode));
         	}
         
         	return  _removeNodeFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getTargetCount(IntPtr thisPtr);
         private static _getTargetCount _getTargetCountFunc;
         internal static int getTargetCount(IntPtr thisPtr)
         {
         	if (_getTargetCountFunc == null)
         	{
         		_getTargetCountFunc =
         			(_getTargetCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getTargetCount"), typeof(_getTargetCount));
         	}
         
         	return  _getTargetCountFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getTargetName(IntPtr thisPtr, int index);
         private static _getTargetName _getTargetNameFunc;
         internal static IntPtr getTargetName(IntPtr thisPtr, int index)
         {
         	if (_getTargetNameFunc == null)
         	{
         		_getTargetNameFunc =
         			(_getTargetName)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getTargetName"), typeof(_getTargetName));
         	}
         
         	return  _getTargetNameFunc(thisPtr, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getObjectCount(IntPtr thisPtr);
         private static _getObjectCount _getObjectCountFunc;
         internal static int getObjectCount(IntPtr thisPtr)
         {
         	if (_getObjectCountFunc == null)
         	{
         		_getObjectCountFunc =
         			(_getObjectCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getObjectCount"), typeof(_getObjectCount));
         	}
         
         	return  _getObjectCountFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getObjectName(IntPtr thisPtr, int index);
         private static _getObjectName _getObjectNameFunc;
         internal static IntPtr getObjectName(IntPtr thisPtr, int index)
         {
         	if (_getObjectNameFunc == null)
         	{
         		_getObjectNameFunc =
         			(_getObjectName)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getObjectName"), typeof(_getObjectName));
         	}
         
         	return  _getObjectNameFunc(thisPtr, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getObjectIndex(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getObjectIndex _getObjectIndexFunc;
         internal static int getObjectIndex(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getObjectIndexFunc == null)
         	{
         		_getObjectIndexFunc =
         			(_getObjectIndex)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getObjectIndex"), typeof(_getObjectIndex));
         	}
         
         	return  _getObjectIndexFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getObjectNode(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getObjectNode _getObjectNodeFunc;
         internal static IntPtr getObjectNode(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getObjectNodeFunc == null)
         	{
         		_getObjectNodeFunc =
         			(_getObjectNode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getObjectNode"), typeof(_getObjectNode));
         	}
         
         	return  _getObjectNodeFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _setObjectNode(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string objName, [MarshalAs(UnmanagedType.LPWStr)]string nodeName);
         private static _setObjectNode _setObjectNodeFunc;
         internal static bool setObjectNode(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string objName, [MarshalAs(UnmanagedType.LPWStr)]string nodeName)
         {
         	if (_setObjectNodeFunc == null)
         	{
         		_setObjectNodeFunc =
         			(_setObjectNode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_setObjectNode"), typeof(_setObjectNode));
         	}
         
         	return  _setObjectNodeFunc(thisPtr, objName, nodeName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _renameObject(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string oldName, [MarshalAs(UnmanagedType.LPWStr)]string newName);
         private static _renameObject _renameObjectFunc;
         internal static bool renameObject(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string oldName, [MarshalAs(UnmanagedType.LPWStr)]string newName)
         {
         	if (_renameObjectFunc == null)
         	{
         		_renameObjectFunc =
         			(_renameObject)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_renameObject"), typeof(_renameObject));
         	}
         
         	return  _renameObjectFunc(thisPtr, oldName, newName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _removeObject(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _removeObject _removeObjectFunc;
         internal static bool removeObject(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_removeObjectFunc == null)
         	{
         		_removeObjectFunc =
         			(_removeObject)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_removeObject"), typeof(_removeObject));
         	}
         
         	return  _removeObjectFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getMeshCount(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getMeshCount _getMeshCountFunc;
         internal static int getMeshCount(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getMeshCountFunc == null)
         	{
         		_getMeshCountFunc =
         			(_getMeshCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getMeshCount"), typeof(_getMeshCount));
         	}
         
         	return  _getMeshCountFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getMeshName(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int index);
         private static _getMeshName _getMeshNameFunc;
         internal static IntPtr getMeshName(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int index)
         {
         	if (_getMeshNameFunc == null)
         	{
         		_getMeshNameFunc =
         			(_getMeshName)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getMeshName"), typeof(_getMeshName));
         	}
         
         	return  _getMeshNameFunc(thisPtr, name, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getMeshSize(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int index);
         private static _getMeshSize _getMeshSizeFunc;
         internal static int getMeshSize(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int index)
         {
         	if (_getMeshSizeFunc == null)
         	{
         		_getMeshSizeFunc =
         			(_getMeshSize)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getMeshSize"), typeof(_getMeshSize));
         	}
         
         	return  _getMeshSizeFunc(thisPtr, name, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _setMeshSize(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int size);
         private static _setMeshSize _setMeshSizeFunc;
         internal static bool setMeshSize(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int size)
         {
         	if (_setMeshSizeFunc == null)
         	{
         		_setMeshSizeFunc =
         			(_setMeshSize)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_setMeshSize"), typeof(_setMeshSize));
         	}
         
         	return  _setMeshSizeFunc(thisPtr, name, size);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getMeshType(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getMeshType _getMeshTypeFunc;
         internal static IntPtr getMeshType(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getMeshTypeFunc == null)
         	{
         		_getMeshTypeFunc =
         			(_getMeshType)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getMeshType"), typeof(_getMeshType));
         	}
         
         	return  _getMeshTypeFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _setMeshType(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, [MarshalAs(UnmanagedType.LPWStr)]string type);
         private static _setMeshType _setMeshTypeFunc;
         internal static bool setMeshType(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, [MarshalAs(UnmanagedType.LPWStr)]string type)
         {
         	if (_setMeshTypeFunc == null)
         	{
         		_setMeshTypeFunc =
         			(_setMeshType)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_setMeshType"), typeof(_setMeshType));
         	}
         
         	return  _setMeshTypeFunc(thisPtr, name, type);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getMeshMaterial(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getMeshMaterial _getMeshMaterialFunc;
         internal static IntPtr getMeshMaterial(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getMeshMaterialFunc == null)
         	{
         		_getMeshMaterialFunc =
         			(_getMeshMaterial)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getMeshMaterial"), typeof(_getMeshMaterial));
         	}
         
         	return  _getMeshMaterialFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _setMeshMaterial(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string meshName, [MarshalAs(UnmanagedType.LPWStr)]string matName);
         private static _setMeshMaterial _setMeshMaterialFunc;
         internal static bool setMeshMaterial(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string meshName, [MarshalAs(UnmanagedType.LPWStr)]string matName)
         {
         	if (_setMeshMaterialFunc == null)
         	{
         		_setMeshMaterialFunc =
         			(_setMeshMaterial)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_setMeshMaterial"), typeof(_setMeshMaterial));
         	}
         
         	return  _setMeshMaterialFunc(thisPtr, meshName, matName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _addMesh(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string meshName, [MarshalAs(UnmanagedType.LPWStr)]string srcShape, [MarshalAs(UnmanagedType.LPWStr)]string srcMesh);
         private static _addMesh _addMeshFunc;
         internal static bool addMesh(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string meshName, [MarshalAs(UnmanagedType.LPWStr)]string srcShape, [MarshalAs(UnmanagedType.LPWStr)]string srcMesh)
         {
         	if (_addMeshFunc == null)
         	{
         		_addMeshFunc =
         			(_addMesh)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_addMesh"), typeof(_addMesh));
         	}
         
         	return  _addMeshFunc(thisPtr, meshName, srcShape, srcMesh);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _removeMesh(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _removeMesh _removeMeshFunc;
         internal static bool removeMesh(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_removeMeshFunc == null)
         	{
         		_removeMeshFunc =
         			(_removeMesh)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_removeMesh"), typeof(_removeMesh));
         	}
         
         	return  _removeMeshFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float[] _getBounds(IntPtr thisPtr);
         private static _getBounds _getBoundsFunc;
         internal static float[] getBounds(IntPtr thisPtr)
         {
         	if (_getBoundsFunc == null)
         	{
         		_getBoundsFunc =
         			(_getBounds)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getBounds"), typeof(_getBounds));
         	}
         
         	return  _getBoundsFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _setBounds(IntPtr thisPtr, float[] bbox);
         private static _setBounds _setBoundsFunc;
         internal static bool setBounds(IntPtr thisPtr, float[] bbox)
         {
         	if (_setBoundsFunc == null)
         	{
         		_setBoundsFunc =
         			(_setBounds)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_setBounds"), typeof(_setBounds));
         	}
         
         	return  _setBoundsFunc(thisPtr, bbox);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getDetailLevelCount(IntPtr thisPtr);
         private static _getDetailLevelCount _getDetailLevelCountFunc;
         internal static int getDetailLevelCount(IntPtr thisPtr)
         {
         	if (_getDetailLevelCountFunc == null)
         	{
         		_getDetailLevelCountFunc =
         			(_getDetailLevelCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getDetailLevelCount"), typeof(_getDetailLevelCount));
         	}
         
         	return  _getDetailLevelCountFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getDetailLevelName(IntPtr thisPtr, int index);
         private static _getDetailLevelName _getDetailLevelNameFunc;
         internal static IntPtr getDetailLevelName(IntPtr thisPtr, int index)
         {
         	if (_getDetailLevelNameFunc == null)
         	{
         		_getDetailLevelNameFunc =
         			(_getDetailLevelName)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getDetailLevelName"), typeof(_getDetailLevelName));
         	}
         
         	return  _getDetailLevelNameFunc(thisPtr, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getDetailLevelSize(IntPtr thisPtr, int index);
         private static _getDetailLevelSize _getDetailLevelSizeFunc;
         internal static int getDetailLevelSize(IntPtr thisPtr, int index)
         {
         	if (_getDetailLevelSizeFunc == null)
         	{
         		_getDetailLevelSizeFunc =
         			(_getDetailLevelSize)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getDetailLevelSize"), typeof(_getDetailLevelSize));
         	}
         
         	return  _getDetailLevelSizeFunc(thisPtr, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getDetailLevelIndex(IntPtr thisPtr, int size);
         private static _getDetailLevelIndex _getDetailLevelIndexFunc;
         internal static int getDetailLevelIndex(IntPtr thisPtr, int size)
         {
         	if (_getDetailLevelIndexFunc == null)
         	{
         		_getDetailLevelIndexFunc =
         			(_getDetailLevelIndex)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getDetailLevelIndex"), typeof(_getDetailLevelIndex));
         	}
         
         	return  _getDetailLevelIndexFunc(thisPtr, size);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _renameDetailLevel(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string oldName, [MarshalAs(UnmanagedType.LPWStr)]string newName);
         private static _renameDetailLevel _renameDetailLevelFunc;
         internal static bool renameDetailLevel(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string oldName, [MarshalAs(UnmanagedType.LPWStr)]string newName)
         {
         	if (_renameDetailLevelFunc == null)
         	{
         		_renameDetailLevelFunc =
         			(_renameDetailLevel)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_renameDetailLevel"), typeof(_renameDetailLevel));
         	}
         
         	return  _renameDetailLevelFunc(thisPtr, oldName, newName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _removeDetailLevel(IntPtr thisPtr, int index);
         private static _removeDetailLevel _removeDetailLevelFunc;
         internal static bool removeDetailLevel(IntPtr thisPtr, int index)
         {
         	if (_removeDetailLevelFunc == null)
         	{
         		_removeDetailLevelFunc =
         			(_removeDetailLevel)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_removeDetailLevel"), typeof(_removeDetailLevel));
         	}
         
         	return  _removeDetailLevelFunc(thisPtr, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _setDetailLevelSize(IntPtr thisPtr, int index, int newSize);
         private static _setDetailLevelSize _setDetailLevelSizeFunc;
         internal static int setDetailLevelSize(IntPtr thisPtr, int index, int newSize)
         {
         	if (_setDetailLevelSizeFunc == null)
         	{
         		_setDetailLevelSizeFunc =
         			(_setDetailLevelSize)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_setDetailLevelSize"), typeof(_setDetailLevelSize));
         	}
         
         	return  _setDetailLevelSizeFunc(thisPtr, index, newSize);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getImposterDetailLevel(IntPtr thisPtr);
         private static _getImposterDetailLevel _getImposterDetailLevelFunc;
         internal static int getImposterDetailLevel(IntPtr thisPtr)
         {
         	if (_getImposterDetailLevelFunc == null)
         	{
         		_getImposterDetailLevelFunc =
         			(_getImposterDetailLevel)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getImposterDetailLevel"), typeof(_getImposterDetailLevel));
         	}
         
         	return  _getImposterDetailLevelFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getImposterSettings(IntPtr thisPtr, int index);
         private static _getImposterSettings _getImposterSettingsFunc;
         internal static IntPtr getImposterSettings(IntPtr thisPtr, int index)
         {
         	if (_getImposterSettingsFunc == null)
         	{
         		_getImposterSettingsFunc =
         			(_getImposterSettings)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getImposterSettings"), typeof(_getImposterSettings));
         	}
         
         	return  _getImposterSettingsFunc(thisPtr, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _addImposter(IntPtr thisPtr, int size, int equatorSteps, int polarSteps, int dl, int dim, bool includePoles, float polarAngle);
         private static _addImposter _addImposterFunc;
         internal static int addImposter(IntPtr thisPtr, int size, int equatorSteps, int polarSteps, int dl, int dim, bool includePoles, float polarAngle)
         {
         	if (_addImposterFunc == null)
         	{
         		_addImposterFunc =
         			(_addImposter)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_addImposter"), typeof(_addImposter));
         	}
         
         	return  _addImposterFunc(thisPtr, size, equatorSteps, polarSteps, dl, dim, includePoles, polarAngle);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _removeImposter(IntPtr thisPtr);
         private static _removeImposter _removeImposterFunc;
         internal static bool removeImposter(IntPtr thisPtr)
         {
         	if (_removeImposterFunc == null)
         	{
         		_removeImposterFunc =
         			(_removeImposter)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_removeImposter"), typeof(_removeImposter));
         	}
         
         	return  _removeImposterFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getSequenceCount(IntPtr thisPtr);
         private static _getSequenceCount _getSequenceCountFunc;
         internal static int getSequenceCount(IntPtr thisPtr)
         {
         	if (_getSequenceCountFunc == null)
         	{
         		_getSequenceCountFunc =
         			(_getSequenceCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getSequenceCount"), typeof(_getSequenceCount));
         	}
         
         	return  _getSequenceCountFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getSequenceIndex(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getSequenceIndex _getSequenceIndexFunc;
         internal static int getSequenceIndex(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getSequenceIndexFunc == null)
         	{
         		_getSequenceIndexFunc =
         			(_getSequenceIndex)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getSequenceIndex"), typeof(_getSequenceIndex));
         	}
         
         	return  _getSequenceIndexFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getSequenceName(IntPtr thisPtr, int index);
         private static _getSequenceName _getSequenceNameFunc;
         internal static IntPtr getSequenceName(IntPtr thisPtr, int index)
         {
         	if (_getSequenceNameFunc == null)
         	{
         		_getSequenceNameFunc =
         			(_getSequenceName)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getSequenceName"), typeof(_getSequenceName));
         	}
         
         	return  _getSequenceNameFunc(thisPtr, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getSequenceSource(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getSequenceSource _getSequenceSourceFunc;
         internal static IntPtr getSequenceSource(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getSequenceSourceFunc == null)
         	{
         		_getSequenceSourceFunc =
         			(_getSequenceSource)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getSequenceSource"), typeof(_getSequenceSource));
         	}
         
         	return  _getSequenceSourceFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getSequenceFrameCount(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getSequenceFrameCount _getSequenceFrameCountFunc;
         internal static int getSequenceFrameCount(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getSequenceFrameCountFunc == null)
         	{
         		_getSequenceFrameCountFunc =
         			(_getSequenceFrameCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getSequenceFrameCount"), typeof(_getSequenceFrameCount));
         	}
         
         	return  _getSequenceFrameCountFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float _getSequencePriority(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getSequencePriority _getSequencePriorityFunc;
         internal static float getSequencePriority(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getSequencePriorityFunc == null)
         	{
         		_getSequencePriorityFunc =
         			(_getSequencePriority)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getSequencePriority"), typeof(_getSequencePriority));
         	}
         
         	return  _getSequencePriorityFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _setSequencePriority(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, float priority);
         private static _setSequencePriority _setSequencePriorityFunc;
         internal static bool setSequencePriority(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, float priority)
         {
         	if (_setSequencePriorityFunc == null)
         	{
         		_setSequencePriorityFunc =
         			(_setSequencePriority)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_setSequencePriority"), typeof(_setSequencePriority));
         	}
         
         	return  _setSequencePriorityFunc(thisPtr, name, priority);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getSequenceGroundSpeed(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getSequenceGroundSpeed _getSequenceGroundSpeedFunc;
         internal static IntPtr getSequenceGroundSpeed(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getSequenceGroundSpeedFunc == null)
         	{
         		_getSequenceGroundSpeedFunc =
         			(_getSequenceGroundSpeed)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getSequenceGroundSpeed"), typeof(_getSequenceGroundSpeed));
         	}
         
         	return  _getSequenceGroundSpeedFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _setSequenceGroundSpeed(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, float[] transSpeed, float[] rotSpeed);
         private static _setSequenceGroundSpeed _setSequenceGroundSpeedFunc;
         internal static bool setSequenceGroundSpeed(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, float[] transSpeed, float[] rotSpeed)
         {
         	if (_setSequenceGroundSpeedFunc == null)
         	{
         		_setSequenceGroundSpeedFunc =
         			(_setSequenceGroundSpeed)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_setSequenceGroundSpeed"), typeof(_setSequenceGroundSpeed));
         	}
         
         	return  _setSequenceGroundSpeedFunc(thisPtr, name, transSpeed, rotSpeed);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _getSequenceCyclic(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getSequenceCyclic _getSequenceCyclicFunc;
         internal static bool getSequenceCyclic(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getSequenceCyclicFunc == null)
         	{
         		_getSequenceCyclicFunc =
         			(_getSequenceCyclic)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getSequenceCyclic"), typeof(_getSequenceCyclic));
         	}
         
         	return  _getSequenceCyclicFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _setSequenceCyclic(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, bool cyclic);
         private static _setSequenceCyclic _setSequenceCyclicFunc;
         internal static bool setSequenceCyclic(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, bool cyclic)
         {
         	if (_setSequenceCyclicFunc == null)
         	{
         		_setSequenceCyclicFunc =
         			(_setSequenceCyclic)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_setSequenceCyclic"), typeof(_setSequenceCyclic));
         	}
         
         	return  _setSequenceCyclicFunc(thisPtr, name, cyclic);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getSequenceBlend(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getSequenceBlend _getSequenceBlendFunc;
         internal static IntPtr getSequenceBlend(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getSequenceBlendFunc == null)
         	{
         		_getSequenceBlendFunc =
         			(_getSequenceBlend)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getSequenceBlend"), typeof(_getSequenceBlend));
         	}
         
         	return  _getSequenceBlendFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _setSequenceBlend(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, bool blend, [MarshalAs(UnmanagedType.LPWStr)]string blendSeq, int blendFrame);
         private static _setSequenceBlend _setSequenceBlendFunc;
         internal static bool setSequenceBlend(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, bool blend, [MarshalAs(UnmanagedType.LPWStr)]string blendSeq, int blendFrame)
         {
         	if (_setSequenceBlendFunc == null)
         	{
         		_setSequenceBlendFunc =
         			(_setSequenceBlend)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_setSequenceBlend"), typeof(_setSequenceBlend));
         	}
         
         	return  _setSequenceBlendFunc(thisPtr, name, blend, blendSeq, blendFrame);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _renameSequence(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string oldName, [MarshalAs(UnmanagedType.LPWStr)]string newName);
         private static _renameSequence _renameSequenceFunc;
         internal static bool renameSequence(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string oldName, [MarshalAs(UnmanagedType.LPWStr)]string newName)
         {
         	if (_renameSequenceFunc == null)
         	{
         		_renameSequenceFunc =
         			(_renameSequence)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_renameSequence"), typeof(_renameSequence));
         	}
         
         	return  _renameSequenceFunc(thisPtr, oldName, newName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _addSequence(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string source, [MarshalAs(UnmanagedType.LPWStr)]string name, int start, int end, bool padRot, bool padTrans);
         private static _addSequence _addSequenceFunc;
         internal static bool addSequence(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string source, [MarshalAs(UnmanagedType.LPWStr)]string name, int start, int end, bool padRot, bool padTrans)
         {
         	if (_addSequenceFunc == null)
         	{
         		_addSequenceFunc =
         			(_addSequence)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_addSequence"), typeof(_addSequence));
         	}
         
         	return  _addSequenceFunc(thisPtr, source, name, start, end, padRot, padTrans);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _removeSequence(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _removeSequence _removeSequenceFunc;
         internal static bool removeSequence(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_removeSequenceFunc == null)
         	{
         		_removeSequenceFunc =
         			(_removeSequence)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_removeSequence"), typeof(_removeSequence));
         	}
         
         	return  _removeSequenceFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getTriggerCount(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name);
         private static _getTriggerCount _getTriggerCountFunc;
         internal static int getTriggerCount(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name)
         {
         	if (_getTriggerCountFunc == null)
         	{
         		_getTriggerCountFunc =
         			(_getTriggerCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getTriggerCount"), typeof(_getTriggerCount));
         	}
         
         	return  _getTriggerCountFunc(thisPtr, name);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getTrigger(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int index);
         private static _getTrigger _getTriggerFunc;
         internal static IntPtr getTrigger(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int index)
         {
         	if (_getTriggerFunc == null)
         	{
         		_getTriggerFunc =
         			(_getTrigger)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_getTrigger"), typeof(_getTrigger));
         	}
         
         	return  _getTriggerFunc(thisPtr, name, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _addTrigger(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int keyframe, int state);
         private static _addTrigger _addTriggerFunc;
         internal static bool addTrigger(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int keyframe, int state)
         {
         	if (_addTriggerFunc == null)
         	{
         		_addTriggerFunc =
         			(_addTrigger)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_addTrigger"), typeof(_addTrigger));
         	}
         
         	return  _addTriggerFunc(thisPtr, name, keyframe, state);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _removeTrigger(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int keyframe, int state);
         private static _removeTrigger _removeTriggerFunc;
         internal static bool removeTrigger(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string name, int keyframe, int state)
         {
         	if (_removeTriggerFunc == null)
         	{
         		_removeTriggerFunc =
         			(_removeTrigger)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSShapeConstructor_removeTrigger"), typeof(_removeTrigger));
         	}
         
         	return  _removeTriggerFunc(thisPtr, name, keyframe, state);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _TSShapeConstructor_create();
         private static _TSShapeConstructor_create _TSShapeConstructor_createFunc;
         internal static IntPtr TSShapeConstructor_create()
         {
         	if (_TSShapeConstructor_createFunc == null)
         	{
         		_TSShapeConstructor_createFunc =
         			(_TSShapeConstructor_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_TSShapeConstructor_create"), typeof(_TSShapeConstructor_create));
         	}
         
         	return  _TSShapeConstructor_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public bool addPrimitive(string meshName, string type, string _params, TransformF txfm, string nodeName)
         {
            return InternalUnsafeMethods.addPrimitive(ObjectPtr->RefPtr->ObjPtr, meshName, type, _params, txfm.ToStruct(), nodeName);
         }
      
         public bool addCollisionDetail(int size, string type, string target, int depth = 4, float merge = 30, float concavity = 30, int maxVerts = 32, float boxMaxError = 0, float sphereMaxError = 0, float capsuleMaxError = 0)
         {
            return InternalUnsafeMethods.addCollisionDetail(ObjectPtr->RefPtr->ObjPtr, size, type, target, depth, merge, concavity, maxVerts, boxMaxError, sphereMaxError, capsuleMaxError);
         }
      
         public void dumpShape(string filename = "")
         {
            InternalUnsafeMethods.dumpShape(ObjectPtr->RefPtr->ObjPtr, filename);
         }
      
         public void saveShape(string filename)
         {
            InternalUnsafeMethods.saveShape(ObjectPtr->RefPtr->ObjPtr, filename);
         }
      
         public void writeChangeSet()
         {
            InternalUnsafeMethods.writeChangeSet(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void notifyShapeChanged()
         {
            InternalUnsafeMethods.notifyShapeChanged(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public int getNodeCount()
         {
            return InternalUnsafeMethods.getNodeCount(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public int getNodeIndex(string name)
         {
            return InternalUnsafeMethods.getNodeIndex(ObjectPtr->RefPtr->ObjPtr, name);
         }
      
         public string getNodeName(int index)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getNodeName(ObjectPtr->RefPtr->ObjPtr, index));
         }
      
         public string getNodeParentName(string name)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getNodeParentName(ObjectPtr->RefPtr->ObjPtr, name));
         }
      
         public bool setNodeParent(string name, string parentName)
         {
            return InternalUnsafeMethods.setNodeParent(ObjectPtr->RefPtr->ObjPtr, name, parentName);
         }
      
         public int getNodeChildCount(string name)
         {
            return InternalUnsafeMethods.getNodeChildCount(ObjectPtr->RefPtr->ObjPtr, name);
         }
      
         public string getNodeChildName(string name, int index)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getNodeChildName(ObjectPtr->RefPtr->ObjPtr, name, index));
         }
      
         public int getNodeObjectCount(string name)
         {
            return InternalUnsafeMethods.getNodeObjectCount(ObjectPtr->RefPtr->ObjPtr, name);
         }
      
         public string getNodeObjectName(string name, int index)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getNodeObjectName(ObjectPtr->RefPtr->ObjPtr, name, index));
         }
      
         public TransformF getNodeTransform(string name, bool isWorld = false)
         {
            return new TransformF(InternalUnsafeMethods.getNodeTransform(ObjectPtr->RefPtr->ObjPtr, name, isWorld));
         }
      
         public bool setNodeTransform(string name, TransformF txfm, bool isWorld = false)
         {
            return InternalUnsafeMethods.setNodeTransform(ObjectPtr->RefPtr->ObjPtr, name, txfm.ToStruct(), isWorld);
         }
      
         public bool renameNode(string oldName, string newName)
         {
            return InternalUnsafeMethods.renameNode(ObjectPtr->RefPtr->ObjPtr, oldName, newName);
         }
      
         public bool addNode(string name, string parentName, TransformF txfm = null, bool isWorld = false)
         {
            if (txfm == null) txfm = TransformF.Identity;
                  return InternalUnsafeMethods.addNode(ObjectPtr->RefPtr->ObjPtr, name, parentName, txfm.ToStruct(), isWorld);
         }
      
         public bool removeNode(string name)
         {
            return InternalUnsafeMethods.removeNode(ObjectPtr->RefPtr->ObjPtr, name);
         }
      
         public int getTargetCount()
         {
            return InternalUnsafeMethods.getTargetCount(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public string getTargetName(int index)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getTargetName(ObjectPtr->RefPtr->ObjPtr, index));
         }
      
         public int getObjectCount()
         {
            return InternalUnsafeMethods.getObjectCount(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public string getObjectName(int index)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getObjectName(ObjectPtr->RefPtr->ObjPtr, index));
         }
      
         public int getObjectIndex(string name)
         {
            return InternalUnsafeMethods.getObjectIndex(ObjectPtr->RefPtr->ObjPtr, name);
         }
      
         public string getObjectNode(string name)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getObjectNode(ObjectPtr->RefPtr->ObjPtr, name));
         }
      
         public bool setObjectNode(string objName, string nodeName)
         {
            return InternalUnsafeMethods.setObjectNode(ObjectPtr->RefPtr->ObjPtr, objName, nodeName);
         }
      
         public bool renameObject(string oldName, string newName)
         {
            return InternalUnsafeMethods.renameObject(ObjectPtr->RefPtr->ObjPtr, oldName, newName);
         }
      
         public bool removeObject(string name)
         {
            return InternalUnsafeMethods.removeObject(ObjectPtr->RefPtr->ObjPtr, name);
         }
      
         public int getMeshCount(string name)
         {
            return InternalUnsafeMethods.getMeshCount(ObjectPtr->RefPtr->ObjPtr, name);
         }
      
         public string getMeshName(string name, int index)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getMeshName(ObjectPtr->RefPtr->ObjPtr, name, index));
         }
      
         public int getMeshSize(string name, int index)
         {
            return InternalUnsafeMethods.getMeshSize(ObjectPtr->RefPtr->ObjPtr, name, index);
         }
      
         public bool setMeshSize(string name, int size)
         {
            return InternalUnsafeMethods.setMeshSize(ObjectPtr->RefPtr->ObjPtr, name, size);
         }
      
         public string getMeshType(string name)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getMeshType(ObjectPtr->RefPtr->ObjPtr, name));
         }
      
         public bool setMeshType(string name, string type)
         {
            return InternalUnsafeMethods.setMeshType(ObjectPtr->RefPtr->ObjPtr, name, type);
         }
      
         public string getMeshMaterial(string name)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getMeshMaterial(ObjectPtr->RefPtr->ObjPtr, name));
         }
      
         public bool setMeshMaterial(string meshName, string matName)
         {
            return InternalUnsafeMethods.setMeshMaterial(ObjectPtr->RefPtr->ObjPtr, meshName, matName);
         }
      
         public bool addMesh(string meshName, string srcShape, string srcMesh)
         {
            return InternalUnsafeMethods.addMesh(ObjectPtr->RefPtr->ObjPtr, meshName, srcShape, srcMesh);
         }
      
         public bool removeMesh(string name)
         {
            return InternalUnsafeMethods.removeMesh(ObjectPtr->RefPtr->ObjPtr, name);
         }
      
         public Box3F getBounds()
         {
            return new Box3F(InternalUnsafeMethods.getBounds(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public bool setBounds(Box3F bbox)
         {
            return InternalUnsafeMethods.setBounds(ObjectPtr->RefPtr->ObjPtr, bbox.ToArray());
         }
      
         public int getDetailLevelCount()
         {
            return InternalUnsafeMethods.getDetailLevelCount(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public string getDetailLevelName(int index)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getDetailLevelName(ObjectPtr->RefPtr->ObjPtr, index));
         }
      
         public int getDetailLevelSize(int index)
         {
            return InternalUnsafeMethods.getDetailLevelSize(ObjectPtr->RefPtr->ObjPtr, index);
         }
      
         public int getDetailLevelIndex(int size)
         {
            return InternalUnsafeMethods.getDetailLevelIndex(ObjectPtr->RefPtr->ObjPtr, size);
         }
      
         public bool renameDetailLevel(string oldName, string newName)
         {
            return InternalUnsafeMethods.renameDetailLevel(ObjectPtr->RefPtr->ObjPtr, oldName, newName);
         }
      
         public bool removeDetailLevel(int index)
         {
            return InternalUnsafeMethods.removeDetailLevel(ObjectPtr->RefPtr->ObjPtr, index);
         }
      
         public int setDetailLevelSize(int index, int newSize)
         {
            return InternalUnsafeMethods.setDetailLevelSize(ObjectPtr->RefPtr->ObjPtr, index, newSize);
         }
      
         public int getImposterDetailLevel()
         {
            return InternalUnsafeMethods.getImposterDetailLevel(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public string getImposterSettings(int index)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getImposterSettings(ObjectPtr->RefPtr->ObjPtr, index));
         }
      
         public int addImposter(int size, int equatorSteps, int polarSteps, int dl, int dim, bool includePoles, float polarAngle)
         {
            return InternalUnsafeMethods.addImposter(ObjectPtr->RefPtr->ObjPtr, size, equatorSteps, polarSteps, dl, dim, includePoles, polarAngle);
         }
      
         public bool removeImposter()
         {
            return InternalUnsafeMethods.removeImposter(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public int getSequenceCount()
         {
            return InternalUnsafeMethods.getSequenceCount(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public int getSequenceIndex(string name)
         {
            return InternalUnsafeMethods.getSequenceIndex(ObjectPtr->RefPtr->ObjPtr, name);
         }
      
         public string getSequenceName(int index)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getSequenceName(ObjectPtr->RefPtr->ObjPtr, index));
         }
      
         public string getSequenceSource(string name)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getSequenceSource(ObjectPtr->RefPtr->ObjPtr, name));
         }
      
         public int getSequenceFrameCount(string name)
         {
            return InternalUnsafeMethods.getSequenceFrameCount(ObjectPtr->RefPtr->ObjPtr, name);
         }
      
         public float getSequencePriority(string name)
         {
            return InternalUnsafeMethods.getSequencePriority(ObjectPtr->RefPtr->ObjPtr, name);
         }
      
         public bool setSequencePriority(string name, float priority)
         {
            return InternalUnsafeMethods.setSequencePriority(ObjectPtr->RefPtr->ObjPtr, name, priority);
         }
      
         public string getSequenceGroundSpeed(string name)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getSequenceGroundSpeed(ObjectPtr->RefPtr->ObjPtr, name));
         }
      
         public bool setSequenceGroundSpeed(string name, Point3F transSpeed, Point3F rotSpeed = null)
         {
            if (rotSpeed == null) rotSpeed = Point3F.Zero;
                  return InternalUnsafeMethods.setSequenceGroundSpeed(ObjectPtr->RefPtr->ObjPtr, name, transSpeed.ToArray(), rotSpeed.ToArray());
         }
      
         public bool getSequenceCyclic(string name)
         {
            return InternalUnsafeMethods.getSequenceCyclic(ObjectPtr->RefPtr->ObjPtr, name);
         }
      
         public bool setSequenceCyclic(string name, bool cyclic)
         {
            return InternalUnsafeMethods.setSequenceCyclic(ObjectPtr->RefPtr->ObjPtr, name, cyclic);
         }
      
         public string getSequenceBlend(string name)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getSequenceBlend(ObjectPtr->RefPtr->ObjPtr, name));
         }
      
         public bool setSequenceBlend(string name, bool blend, string blendSeq, int blendFrame)
         {
            return InternalUnsafeMethods.setSequenceBlend(ObjectPtr->RefPtr->ObjPtr, name, blend, blendSeq, blendFrame);
         }
      
         public bool renameSequence(string oldName, string newName)
         {
            return InternalUnsafeMethods.renameSequence(ObjectPtr->RefPtr->ObjPtr, oldName, newName);
         }
      
         public bool addSequence(string source, string name, int start = 0, int end = -1, bool padRot = true, bool padTrans = false)
         {
            return InternalUnsafeMethods.addSequence(ObjectPtr->RefPtr->ObjPtr, source, name, start, end, padRot, padTrans);
         }
      
         public bool removeSequence(string name)
         {
            return InternalUnsafeMethods.removeSequence(ObjectPtr->RefPtr->ObjPtr, name);
         }
      
         public int getTriggerCount(string name)
         {
            return InternalUnsafeMethods.getTriggerCount(ObjectPtr->RefPtr->ObjPtr, name);
         }
      
         public string getTrigger(string name, int index)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getTrigger(ObjectPtr->RefPtr->ObjPtr, name, index));
         }
      
         public bool addTrigger(string name, int keyframe, int state)
         {
            return InternalUnsafeMethods.addTrigger(ObjectPtr->RefPtr->ObjPtr, name, keyframe, state);
         }
      
         public bool removeTrigger(string name, int keyframe, int state)
         {
            return InternalUnsafeMethods.removeTrigger(ObjectPtr->RefPtr->ObjPtr, name, keyframe, state);
         }
      
      
      #endregion

	}
}