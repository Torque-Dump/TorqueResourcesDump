using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class MEDeleteUndoAction : UndoAction
	{
		public MEDeleteUndoAction()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.MEDeleteUndoAction_create());
		}

		public MEDeleteUndoAction(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public MEDeleteUndoAction(SimObject pObj) : base(pObj)
		{
		}

		public MEDeleteUndoAction(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _deleteObject(IntPtr thisPtr, IntPtr obj);
         private static _deleteObject _deleteObjectFunc;
         internal static void deleteObject(IntPtr thisPtr, IntPtr obj)
         {
         	if (_deleteObjectFunc == null)
         	{
         		_deleteObjectFunc =
         			(_deleteObject)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnMEDeleteUndoAction_deleteObject"), typeof(_deleteObject));
         	}
         
         	 _deleteObjectFunc(thisPtr, obj);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _MEDeleteUndoAction_create();
         private static _MEDeleteUndoAction_create _MEDeleteUndoAction_createFunc;
         internal static IntPtr MEDeleteUndoAction_create()
         {
         	if (_MEDeleteUndoAction_createFunc == null)
         	{
         		_MEDeleteUndoAction_createFunc =
         			(_MEDeleteUndoAction_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_MEDeleteUndoAction_create"), typeof(_MEDeleteUndoAction_create));
         	}
         
         	return  _MEDeleteUndoAction_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void deleteObject(SimObject obj)
         {
            InternalUnsafeMethods.deleteObject(ObjectPtr->RefPtr->ObjPtr, obj.ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}