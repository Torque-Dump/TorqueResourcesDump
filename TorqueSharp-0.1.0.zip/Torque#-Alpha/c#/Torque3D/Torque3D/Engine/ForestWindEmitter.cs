using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ForestWindEmitter : SceneObject
	{
		public ForestWindEmitter()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ForestWindEmitter_create());
		}

		public ForestWindEmitter(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ForestWindEmitter(SimObject pObj) : base(pObj)
		{
		}

		public ForestWindEmitter(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _attachToObject(IntPtr thisPtr, uint objectID);
         private static _attachToObject _attachToObjectFunc;
         internal static void attachToObject(IntPtr thisPtr, uint objectID)
         {
         	if (_attachToObjectFunc == null)
         	{
         		_attachToObjectFunc =
         			(_attachToObject)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnForestWindEmitter_attachToObject"), typeof(_attachToObject));
         	}
         
         	 _attachToObjectFunc(thisPtr, objectID);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ForestWindEmitter_create();
         private static _ForestWindEmitter_create _ForestWindEmitter_createFunc;
         internal static IntPtr ForestWindEmitter_create()
         {
         	if (_ForestWindEmitter_createFunc == null)
         	{
         		_ForestWindEmitter_createFunc =
         			(_ForestWindEmitter_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ForestWindEmitter_create"), typeof(_ForestWindEmitter_create));
         	}
         
         	return  _ForestWindEmitter_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void attachToObject(uint objectID)
         {
            InternalUnsafeMethods.attachToObject(ObjectPtr->RefPtr->ObjPtr, objectID);
         }
      
      
      #endregion

	}
}