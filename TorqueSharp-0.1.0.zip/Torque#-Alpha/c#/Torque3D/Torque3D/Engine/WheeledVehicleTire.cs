using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class WheeledVehicleTire : SimDataBlock
	{
		public WheeledVehicleTire()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.WheeledVehicleTire_create());
		}

		public WheeledVehicleTire(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public WheeledVehicleTire(SimObject pObj) : base(pObj)
		{
		}

		public WheeledVehicleTire(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _WheeledVehicleTire_create();
         private static _WheeledVehicleTire_create _WheeledVehicleTire_createFunc;
         internal static IntPtr WheeledVehicleTire_create()
         {
         	if (_WheeledVehicleTire_createFunc == null)
         	{
         		_WheeledVehicleTire_createFunc =
         			(_WheeledVehicleTire_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_WheeledVehicleTire_create"), typeof(_WheeledVehicleTire_create));
         	}
         
         	return  _WheeledVehicleTire_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}