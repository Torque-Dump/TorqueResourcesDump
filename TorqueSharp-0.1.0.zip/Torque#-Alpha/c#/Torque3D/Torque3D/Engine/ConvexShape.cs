using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ConvexShape : SceneObject
	{
		public ConvexShape()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ConvexShape_create());
		}

		public ConvexShape(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ConvexShape(SimObject pObj) : base(pObj)
		{
		}

		public ConvexShape(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ConvexShape_create();
         private static _ConvexShape_create _ConvexShape_createFunc;
         internal static IntPtr ConvexShape_create()
         {
         	if (_ConvexShape_createFunc == null)
         	{
         		_ConvexShape_createFunc =
         			(_ConvexShape_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ConvexShape_create"), typeof(_ConvexShape_create));
         	}
         
         	return  _ConvexShape_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}