using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class SplashData : GameBaseData
	{
		public SplashData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.SplashData_create());
		}

		public SplashData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public SplashData(SimObject pObj) : base(pObj)
		{
		}

		public SplashData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _SplashData_create();
         private static _SplashData_create _SplashData_createFunc;
         internal static IntPtr SplashData_create()
         {
         	if (_SplashData_createFunc == null)
         	{
         		_SplashData_createFunc =
         			(_SplashData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_SplashData_create"), typeof(_SplashData_create));
         	}
         
         	return  _SplashData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}