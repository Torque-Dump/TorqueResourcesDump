using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiIdleCamFadeBitmapCtrl : GuiBitmapCtrl
	{
		public GuiIdleCamFadeBitmapCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiIdleCamFadeBitmapCtrl_create());
		}

		public GuiIdleCamFadeBitmapCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiIdleCamFadeBitmapCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiIdleCamFadeBitmapCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _fadeIn(IntPtr thisPtr);
         private static _fadeIn _fadeInFunc;
         internal static void fadeIn(IntPtr thisPtr)
         {
         	if (_fadeInFunc == null)
         	{
         		_fadeInFunc =
         			(_fadeIn)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiIdleCamFadeBitmapCtrl_fadeIn"), typeof(_fadeIn));
         	}
         
         	 _fadeInFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _fadeOut(IntPtr thisPtr);
         private static _fadeOut _fadeOutFunc;
         internal static void fadeOut(IntPtr thisPtr)
         {
         	if (_fadeOutFunc == null)
         	{
         		_fadeOutFunc =
         			(_fadeOut)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiIdleCamFadeBitmapCtrl_fadeOut"), typeof(_fadeOut));
         	}
         
         	 _fadeOutFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiIdleCamFadeBitmapCtrl_create();
         private static _GuiIdleCamFadeBitmapCtrl_create _GuiIdleCamFadeBitmapCtrl_createFunc;
         internal static IntPtr GuiIdleCamFadeBitmapCtrl_create()
         {
         	if (_GuiIdleCamFadeBitmapCtrl_createFunc == null)
         	{
         		_GuiIdleCamFadeBitmapCtrl_createFunc =
         			(_GuiIdleCamFadeBitmapCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiIdleCamFadeBitmapCtrl_create"), typeof(_GuiIdleCamFadeBitmapCtrl_create));
         	}
         
         	return  _GuiIdleCamFadeBitmapCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void fadeIn()
         {
            InternalUnsafeMethods.fadeIn(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void fadeOut()
         {
            InternalUnsafeMethods.fadeOut(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}