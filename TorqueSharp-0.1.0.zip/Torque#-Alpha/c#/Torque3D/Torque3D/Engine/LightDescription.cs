using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class LightDescription : SimDataBlock
	{
		public LightDescription()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.LightDescription_create());
		}

		public LightDescription(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public LightDescription(SimObject pObj) : base(pObj)
		{
		}

		public LightDescription(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _apply(IntPtr thisPtr);
         private static _apply _applyFunc;
         internal static void apply(IntPtr thisPtr)
         {
         	if (_applyFunc == null)
         	{
         		_applyFunc =
         			(_apply)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnLightDescription_apply"), typeof(_apply));
         	}
         
         	 _applyFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _LightDescription_create();
         private static _LightDescription_create _LightDescription_createFunc;
         internal static IntPtr LightDescription_create()
         {
         	if (_LightDescription_createFunc == null)
         	{
         		_LightDescription_createFunc =
         			(_LightDescription_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_LightDescription_create"), typeof(_LightDescription_create));
         	}
         
         	return  _LightDescription_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void apply()
         {
            InternalUnsafeMethods.apply(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}