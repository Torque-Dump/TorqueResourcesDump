using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class River : WaterObject
	{
		public River()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.River_create());
		}

		public River(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public River(SimObject pObj) : base(pObj)
		{
		}

		public River(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _regenerate(IntPtr thisPtr);
         private static _regenerate _regenerateFunc;
         internal static void regenerate(IntPtr thisPtr)
         {
         	if (_regenerateFunc == null)
         	{
         		_regenerateFunc =
         			(_regenerate)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnRiver_regenerate"), typeof(_regenerate));
         	}
         
         	 _regenerateFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setMetersPerSegment(IntPtr thisPtr, float meters);
         private static _setMetersPerSegment _setMetersPerSegmentFunc;
         internal static void setMetersPerSegment(IntPtr thisPtr, float meters)
         {
         	if (_setMetersPerSegmentFunc == null)
         	{
         		_setMetersPerSegmentFunc =
         			(_setMetersPerSegment)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnRiver_setMetersPerSegment"), typeof(_setMetersPerSegment));
         	}
         
         	 _setMetersPerSegmentFunc(thisPtr, meters);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setBatchSize(IntPtr thisPtr, float meters);
         private static _setBatchSize _setBatchSizeFunc;
         internal static void setBatchSize(IntPtr thisPtr, float meters)
         {
         	if (_setBatchSizeFunc == null)
         	{
         		_setBatchSizeFunc =
         			(_setBatchSize)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnRiver_setBatchSize"), typeof(_setBatchSize));
         	}
         
         	 _setBatchSizeFunc(thisPtr, meters);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setNodeDepth(IntPtr thisPtr, int idx, float meters);
         private static _setNodeDepth _setNodeDepthFunc;
         internal static void setNodeDepth(IntPtr thisPtr, int idx, float meters)
         {
         	if (_setNodeDepthFunc == null)
         	{
         		_setNodeDepthFunc =
         			(_setNodeDepth)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnRiver_setNodeDepth"), typeof(_setNodeDepth));
         	}
         
         	 _setNodeDepthFunc(thisPtr, idx, meters);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setMaxDivisionSize(IntPtr thisPtr, float meters);
         private static _setMaxDivisionSize _setMaxDivisionSizeFunc;
         internal static void setMaxDivisionSize(IntPtr thisPtr, float meters)
         {
         	if (_setMaxDivisionSizeFunc == null)
         	{
         		_setMaxDivisionSizeFunc =
         			(_setMaxDivisionSize)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnRiver_setMaxDivisionSize"), typeof(_setMaxDivisionSize));
         	}
         
         	 _setMaxDivisionSizeFunc(thisPtr, meters);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _River_create();
         private static _River_create _River_createFunc;
         internal static IntPtr River_create()
         {
         	if (_River_createFunc == null)
         	{
         		_River_createFunc =
         			(_River_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_River_create"), typeof(_River_create));
         	}
         
         	return  _River_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void regenerate()
         {
            InternalUnsafeMethods.regenerate(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setMetersPerSegment(float meters)
         {
            InternalUnsafeMethods.setMetersPerSegment(ObjectPtr->RefPtr->ObjPtr, meters);
         }
      
         public void setBatchSize(float meters)
         {
            InternalUnsafeMethods.setBatchSize(ObjectPtr->RefPtr->ObjPtr, meters);
         }
      
         public void setNodeDepth(int idx, float meters)
         {
            InternalUnsafeMethods.setNodeDepth(ObjectPtr->RefPtr->ObjPtr, idx, meters);
         }
      
         public void setMaxDivisionSize(float meters)
         {
            InternalUnsafeMethods.setMaxDivisionSize(ObjectPtr->RefPtr->ObjPtr, meters);
         }
      
      
      #endregion

	}
}