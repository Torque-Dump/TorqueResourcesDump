using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class LevelInfo : NetObject
	{
		public LevelInfo()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.LevelInfo_create());
		}

		public LevelInfo(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public LevelInfo(SimObject pObj) : base(pObj)
		{
		}

		public LevelInfo(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _LevelInfo_create();
         private static _LevelInfo_create _LevelInfo_createFunc;
         internal static IntPtr LevelInfo_create()
         {
         	if (_LevelInfo_createFunc == null)
         	{
         		_LevelInfo_createFunc =
         			(_LevelInfo_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_LevelInfo_create"), typeof(_LevelInfo_create));
         	}
         
         	return  _LevelInfo_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}