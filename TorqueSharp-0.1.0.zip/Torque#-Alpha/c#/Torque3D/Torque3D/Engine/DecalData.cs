using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class DecalData : SimDataBlock
	{
		public DecalData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.DecalData_create());
		}

		public DecalData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public DecalData(SimObject pObj) : base(pObj)
		{
		}

		public DecalData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _postApply(IntPtr thisPtr);
         private static _postApply _postApplyFunc;
         internal static void postApply(IntPtr thisPtr)
         {
         	if (_postApplyFunc == null)
         	{
         		_postApplyFunc =
         			(_postApply)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnDecalData_postApply"), typeof(_postApply));
         	}
         
         	 _postApplyFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _DecalData_create();
         private static _DecalData_create _DecalData_createFunc;
         internal static IntPtr DecalData_create()
         {
         	if (_DecalData_createFunc == null)
         	{
         		_DecalData_createFunc =
         			(_DecalData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_DecalData_create"), typeof(_DecalData_create));
         	}
         
         	return  _DecalData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void postApply()
         {
            InternalUnsafeMethods.postApply(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}