using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiMLTextEditCtrl : GuiMLTextCtrl
	{
		public GuiMLTextEditCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiMLTextEditCtrl_create());
		}

		public GuiMLTextEditCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiMLTextEditCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiMLTextEditCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiMLTextEditCtrl_create();
         private static _GuiMLTextEditCtrl_create _GuiMLTextEditCtrl_createFunc;
         internal static IntPtr GuiMLTextEditCtrl_create()
         {
         	if (_GuiMLTextEditCtrl_createFunc == null)
         	{
         		_GuiMLTextEditCtrl_createFunc =
         			(_GuiMLTextEditCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiMLTextEditCtrl_create"), typeof(_GuiMLTextEditCtrl_create));
         	}
         
         	return  _GuiMLTextEditCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}