using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiTextEditSliderBitmapCtrl : GuiTextEditCtrl
	{
		public GuiTextEditSliderBitmapCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiTextEditSliderBitmapCtrl_create());
		}

		public GuiTextEditSliderBitmapCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiTextEditSliderBitmapCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiTextEditSliderBitmapCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiTextEditSliderBitmapCtrl_create();
         private static _GuiTextEditSliderBitmapCtrl_create _GuiTextEditSliderBitmapCtrl_createFunc;
         internal static IntPtr GuiTextEditSliderBitmapCtrl_create()
         {
         	if (_GuiTextEditSliderBitmapCtrl_createFunc == null)
         	{
         		_GuiTextEditSliderBitmapCtrl_createFunc =
         			(_GuiTextEditSliderBitmapCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiTextEditSliderBitmapCtrl_create"), typeof(_GuiTextEditSliderBitmapCtrl_create));
         	}
         
         	return  _GuiTextEditSliderBitmapCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}