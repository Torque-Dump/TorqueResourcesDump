using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class RenderFormatToken : RenderPassStateToken
	{
		public RenderFormatToken()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.RenderFormatToken_create());
		}

		public RenderFormatToken(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public RenderFormatToken(SimObject pObj) : base(pObj)
		{
		}

		public RenderFormatToken(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _RenderFormatToken_create();
         private static _RenderFormatToken_create _RenderFormatToken_createFunc;
         internal static IntPtr RenderFormatToken_create()
         {
         	if (_RenderFormatToken_createFunc == null)
         	{
         		_RenderFormatToken_createFunc =
         			(_RenderFormatToken_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_RenderFormatToken_create"), typeof(_RenderFormatToken_create));
         	}
         
         	return  _RenderFormatToken_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}