using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class LightAnimData : SimDataBlock
	{
		public LightAnimData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.LightAnimData_create());
		}

		public LightAnimData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public LightAnimData(SimObject pObj) : base(pObj)
		{
		}

		public LightAnimData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _LightAnimData_create();
         private static _LightAnimData_create _LightAnimData_createFunc;
         internal static IntPtr LightAnimData_create()
         {
         	if (_LightAnimData_createFunc == null)
         	{
         		_LightAnimData_createFunc =
         			(_LightAnimData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_LightAnimData_create"), typeof(_LightAnimData_create));
         	}
         
         	return  _LightAnimData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}