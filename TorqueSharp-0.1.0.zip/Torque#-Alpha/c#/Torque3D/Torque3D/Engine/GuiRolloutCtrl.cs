using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiRolloutCtrl : GuiControl
	{
		public GuiRolloutCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiRolloutCtrl_create());
		}

		public GuiRolloutCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiRolloutCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiRolloutCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _isExpanded(IntPtr thisPtr);
         private static _isExpanded _isExpandedFunc;
         internal static bool isExpanded(IntPtr thisPtr)
         {
         	if (_isExpandedFunc == null)
         	{
         		_isExpandedFunc =
         			(_isExpanded)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiRolloutCtrl_isExpanded"), typeof(_isExpanded));
         	}
         
         	return  _isExpandedFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _collapse(IntPtr thisPtr);
         private static _collapse _collapseFunc;
         internal static void collapse(IntPtr thisPtr)
         {
         	if (_collapseFunc == null)
         	{
         		_collapseFunc =
         			(_collapse)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiRolloutCtrl_collapse"), typeof(_collapse));
         	}
         
         	 _collapseFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _expand(IntPtr thisPtr);
         private static _expand _expandFunc;
         internal static void expand(IntPtr thisPtr)
         {
         	if (_expandFunc == null)
         	{
         		_expandFunc =
         			(_expand)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiRolloutCtrl_expand"), typeof(_expand));
         	}
         
         	 _expandFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _toggleCollapse(IntPtr thisPtr);
         private static _toggleCollapse _toggleCollapseFunc;
         internal static void toggleCollapse(IntPtr thisPtr)
         {
         	if (_toggleCollapseFunc == null)
         	{
         		_toggleCollapseFunc =
         			(_toggleCollapse)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiRolloutCtrl_toggleCollapse"), typeof(_toggleCollapse));
         	}
         
         	 _toggleCollapseFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _toggleExpanded(IntPtr thisPtr, bool instantly);
         private static _toggleExpanded _toggleExpandedFunc;
         internal static void toggleExpanded(IntPtr thisPtr, bool instantly)
         {
         	if (_toggleExpandedFunc == null)
         	{
         		_toggleExpandedFunc =
         			(_toggleExpanded)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiRolloutCtrl_toggleExpanded"), typeof(_toggleExpanded));
         	}
         
         	 _toggleExpandedFunc(thisPtr, instantly);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _instantCollapse(IntPtr thisPtr);
         private static _instantCollapse _instantCollapseFunc;
         internal static void instantCollapse(IntPtr thisPtr)
         {
         	if (_instantCollapseFunc == null)
         	{
         		_instantCollapseFunc =
         			(_instantCollapse)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiRolloutCtrl_instantCollapse"), typeof(_instantCollapse));
         	}
         
         	 _instantCollapseFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _instantExpand(IntPtr thisPtr);
         private static _instantExpand _instantExpandFunc;
         internal static void instantExpand(IntPtr thisPtr)
         {
         	if (_instantExpandFunc == null)
         	{
         		_instantExpandFunc =
         			(_instantExpand)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiRolloutCtrl_instantExpand"), typeof(_instantExpand));
         	}
         
         	 _instantExpandFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _sizeToContents(IntPtr thisPtr);
         private static _sizeToContents _sizeToContentsFunc;
         internal static void sizeToContents(IntPtr thisPtr)
         {
         	if (_sizeToContentsFunc == null)
         	{
         		_sizeToContentsFunc =
         			(_sizeToContents)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiRolloutCtrl_sizeToContents"), typeof(_sizeToContents));
         	}
         
         	 _sizeToContentsFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiRolloutCtrl_create();
         private static _GuiRolloutCtrl_create _GuiRolloutCtrl_createFunc;
         internal static IntPtr GuiRolloutCtrl_create()
         {
         	if (_GuiRolloutCtrl_createFunc == null)
         	{
         		_GuiRolloutCtrl_createFunc =
         			(_GuiRolloutCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiRolloutCtrl_create"), typeof(_GuiRolloutCtrl_create));
         	}
         
         	return  _GuiRolloutCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public bool isExpanded()
         {
            return InternalUnsafeMethods.isExpanded(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void collapse()
         {
            InternalUnsafeMethods.collapse(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void expand()
         {
            InternalUnsafeMethods.expand(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void toggleCollapse()
         {
            InternalUnsafeMethods.toggleCollapse(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void toggleExpanded(bool instantly = false)
         {
            InternalUnsafeMethods.toggleExpanded(ObjectPtr->RefPtr->ObjPtr, instantly);
         }
      
         public void instantCollapse()
         {
            InternalUnsafeMethods.instantCollapse(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void instantExpand()
         {
            InternalUnsafeMethods.instantExpand(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void sizeToContents()
         {
            InternalUnsafeMethods.sizeToContents(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}