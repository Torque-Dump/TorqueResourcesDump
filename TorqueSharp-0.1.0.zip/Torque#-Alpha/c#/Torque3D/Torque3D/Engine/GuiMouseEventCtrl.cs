using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiMouseEventCtrl : GuiControl
	{
		public GuiMouseEventCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiMouseEventCtrl_create());
		}

		public GuiMouseEventCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiMouseEventCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiMouseEventCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiMouseEventCtrl_create();
         private static _GuiMouseEventCtrl_create _GuiMouseEventCtrl_createFunc;
         internal static IntPtr GuiMouseEventCtrl_create()
         {
         	if (_GuiMouseEventCtrl_createFunc == null)
         	{
         		_GuiMouseEventCtrl_createFunc =
         			(_GuiMouseEventCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiMouseEventCtrl_create"), typeof(_GuiMouseEventCtrl_create));
         	}
         
         	return  _GuiMouseEventCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}