using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class StaticShapeData : ShapeBaseData
	{
		public StaticShapeData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.StaticShapeData_create());
		}

		public StaticShapeData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public StaticShapeData(SimObject pObj) : base(pObj)
		{
		}

		public StaticShapeData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _StaticShapeData_create();
         private static _StaticShapeData_create _StaticShapeData_createFunc;
         internal static IntPtr StaticShapeData_create()
         {
         	if (_StaticShapeData_createFunc == null)
         	{
         		_StaticShapeData_createFunc =
         			(_StaticShapeData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_StaticShapeData_create"), typeof(_StaticShapeData_create));
         	}
         
         	return  _StaticShapeData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}