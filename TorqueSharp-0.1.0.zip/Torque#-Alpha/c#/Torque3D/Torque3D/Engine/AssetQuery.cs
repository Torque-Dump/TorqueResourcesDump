using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class AssetQuery : SimObject
	{
		public AssetQuery()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.AssetQuery_create());
		}

		public AssetQuery(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public AssetQuery(SimObject pObj) : base(pObj)
		{
		}

		public AssetQuery(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _clear(IntPtr thisPtr);
         private static _clear _clearFunc;
         internal static void clear(IntPtr thisPtr)
         {
         	if (_clearFunc == null)
         	{
         		_clearFunc =
         			(_clear)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetQuery_clear"), typeof(_clear));
         	}
         
         	 _clearFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _set(IntPtr thisPtr, int queryId);
         private static _set _setFunc;
         internal static bool set(IntPtr thisPtr, int queryId)
         {
         	if (_setFunc == null)
         	{
         		_setFunc =
         			(_set)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetQuery_set"), typeof(_set));
         	}
         
         	return  _setFunc(thisPtr, queryId);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getCount(IntPtr thisPtr);
         private static _getCount _getCountFunc;
         internal static int getCount(IntPtr thisPtr)
         {
         	if (_getCountFunc == null)
         	{
         		_getCountFunc =
         			(_getCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetQuery_getCount"), typeof(_getCount));
         	}
         
         	return  _getCountFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getAsset(IntPtr thisPtr, int resultIndex);
         private static _getAsset _getAssetFunc;
         internal static IntPtr getAsset(IntPtr thisPtr, int resultIndex)
         {
         	if (_getAssetFunc == null)
         	{
         		_getAssetFunc =
         			(_getAsset)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetQuery_getAsset"), typeof(_getAsset));
         	}
         
         	return  _getAssetFunc(thisPtr, resultIndex);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _AssetQuery_create();
         private static _AssetQuery_create _AssetQuery_createFunc;
         internal static IntPtr AssetQuery_create()
         {
         	if (_AssetQuery_createFunc == null)
         	{
         		_AssetQuery_createFunc =
         			(_AssetQuery_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_AssetQuery_create"), typeof(_AssetQuery_create));
         	}
         
         	return  _AssetQuery_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void clear()
         {
            InternalUnsafeMethods.clear(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public bool set(int queryId)
         {
            return InternalUnsafeMethods.set(ObjectPtr->RefPtr->ObjPtr, queryId);
         }
      
         public int getCount()
         {
            return InternalUnsafeMethods.getCount(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public string getAsset(int resultIndex = -1)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getAsset(ObjectPtr->RefPtr->ObjPtr, resultIndex));
         }
      
      
      #endregion

	}
}