using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiCrossHairHud : GuiBitmapCtrl
	{
		public GuiCrossHairHud()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiCrossHairHud_create());
		}

		public GuiCrossHairHud(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiCrossHairHud(SimObject pObj) : base(pObj)
		{
		}

		public GuiCrossHairHud(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiCrossHairHud_create();
         private static _GuiCrossHairHud_create _GuiCrossHairHud_createFunc;
         internal static IntPtr GuiCrossHairHud_create()
         {
         	if (_GuiCrossHairHud_createFunc == null)
         	{
         		_GuiCrossHairHud_createFunc =
         			(_GuiCrossHairHud_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiCrossHairHud_create"), typeof(_GuiCrossHairHud_create));
         	}
         
         	return  _GuiCrossHairHud_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}