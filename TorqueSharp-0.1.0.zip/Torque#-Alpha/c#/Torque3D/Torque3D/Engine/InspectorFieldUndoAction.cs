using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class InspectorFieldUndoAction : UndoAction
	{
		public InspectorFieldUndoAction()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.InspectorFieldUndoAction_create());
		}

		public InspectorFieldUndoAction(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public InspectorFieldUndoAction(SimObject pObj) : base(pObj)
		{
		}

		public InspectorFieldUndoAction(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _InspectorFieldUndoAction_create();
         private static _InspectorFieldUndoAction_create _InspectorFieldUndoAction_createFunc;
         internal static IntPtr InspectorFieldUndoAction_create()
         {
         	if (_InspectorFieldUndoAction_createFunc == null)
         	{
         		_InspectorFieldUndoAction_createFunc =
         			(_InspectorFieldUndoAction_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_InspectorFieldUndoAction_create"), typeof(_InspectorFieldUndoAction_create));
         	}
         
         	return  _InspectorFieldUndoAction_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}