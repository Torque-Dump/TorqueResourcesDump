using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class Forest : SceneObject
	{
		public Forest()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.Forest_create());
		}

		public Forest(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public Forest(SimObject pObj) : base(pObj)
		{
		}

		public Forest(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _saveDataFile(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string path);
         private static _saveDataFile _saveDataFileFunc;
         internal static void saveDataFile(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string path)
         {
         	if (_saveDataFileFunc == null)
         	{
         		_saveDataFileFunc =
         			(_saveDataFile)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnForest_saveDataFile"), typeof(_saveDataFile));
         	}
         
         	 _saveDataFileFunc(thisPtr, path);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _isDirty(IntPtr thisPtr);
         private static _isDirty _isDirtyFunc;
         internal static bool isDirty(IntPtr thisPtr)
         {
         	if (_isDirtyFunc == null)
         	{
         		_isDirtyFunc =
         			(_isDirty)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnForest_isDirty"), typeof(_isDirty));
         	}
         
         	return  _isDirtyFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _regenCells(IntPtr thisPtr);
         private static _regenCells _regenCellsFunc;
         internal static void regenCells(IntPtr thisPtr)
         {
         	if (_regenCellsFunc == null)
         	{
         		_regenCellsFunc =
         			(_regenCells)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnForest_regenCells"), typeof(_regenCells));
         	}
         
         	 _regenCellsFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _clear(IntPtr thisPtr);
         private static _clear _clearFunc;
         internal static void clear(IntPtr thisPtr)
         {
         	if (_clearFunc == null)
         	{
         		_clearFunc =
         			(_clear)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnForest_clear"), typeof(_clear));
         	}
         
         	 _clearFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _Forest_create();
         private static _Forest_create _Forest_createFunc;
         internal static IntPtr Forest_create()
         {
         	if (_Forest_createFunc == null)
         	{
         		_Forest_createFunc =
         			(_Forest_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_Forest_create"), typeof(_Forest_create));
         	}
         
         	return  _Forest_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void saveDataFile(string path = "")
         {
            InternalUnsafeMethods.saveDataFile(ObjectPtr->RefPtr->ObjPtr, path);
         }
      
         public bool isDirty()
         {
            return InternalUnsafeMethods.isDirty(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void regenCells()
         {
            InternalUnsafeMethods.regenCells(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void clear()
         {
            InternalUnsafeMethods.clear(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}