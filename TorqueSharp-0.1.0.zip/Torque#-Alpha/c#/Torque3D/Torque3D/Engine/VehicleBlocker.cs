using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class VehicleBlocker : SceneObject
	{
		public VehicleBlocker()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.VehicleBlocker_create());
		}

		public VehicleBlocker(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public VehicleBlocker(SimObject pObj) : base(pObj)
		{
		}

		public VehicleBlocker(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _VehicleBlocker_create();
         private static _VehicleBlocker_create _VehicleBlocker_createFunc;
         internal static IntPtr VehicleBlocker_create()
         {
         	if (_VehicleBlocker_createFunc == null)
         	{
         		_VehicleBlocker_createFunc =
         			(_VehicleBlocker_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_VehicleBlocker_create"), typeof(_VehicleBlocker_create));
         	}
         
         	return  _VehicleBlocker_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}