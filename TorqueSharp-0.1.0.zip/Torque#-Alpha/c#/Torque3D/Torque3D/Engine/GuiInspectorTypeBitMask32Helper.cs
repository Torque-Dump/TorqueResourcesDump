using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiInspectorTypeBitMask32Helper : GuiInspectorField
	{
		public GuiInspectorTypeBitMask32Helper()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiInspectorTypeBitMask32Helper_create());
		}

		public GuiInspectorTypeBitMask32Helper(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiInspectorTypeBitMask32Helper(SimObject pObj) : base(pObj)
		{
		}

		public GuiInspectorTypeBitMask32Helper(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiInspectorTypeBitMask32Helper_create();
         private static _GuiInspectorTypeBitMask32Helper_create _GuiInspectorTypeBitMask32Helper_createFunc;
         internal static IntPtr GuiInspectorTypeBitMask32Helper_create()
         {
         	if (_GuiInspectorTypeBitMask32Helper_createFunc == null)
         	{
         		_GuiInspectorTypeBitMask32Helper_createFunc =
         			(_GuiInspectorTypeBitMask32Helper_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiInspectorTypeBitMask32Helper_create"), typeof(_GuiInspectorTypeBitMask32Helper_create));
         	}
         
         	return  _GuiInspectorTypeBitMask32Helper_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}