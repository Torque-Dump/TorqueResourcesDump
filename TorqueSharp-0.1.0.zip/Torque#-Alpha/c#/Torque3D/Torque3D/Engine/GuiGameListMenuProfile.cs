using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiGameListMenuProfile : GuiControlProfile
	{
		public GuiGameListMenuProfile()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiGameListMenuProfile_create());
		}

		public GuiGameListMenuProfile(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiGameListMenuProfile(SimObject pObj) : base(pObj)
		{
		}

		public GuiGameListMenuProfile(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiGameListMenuProfile_create();
         private static _GuiGameListMenuProfile_create _GuiGameListMenuProfile_createFunc;
         internal static IntPtr GuiGameListMenuProfile_create()
         {
         	if (_GuiGameListMenuProfile_createFunc == null)
         	{
         		_GuiGameListMenuProfile_createFunc =
         			(_GuiGameListMenuProfile_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiGameListMenuProfile_create"), typeof(_GuiGameListMenuProfile_create));
         	}
         
         	return  _GuiGameListMenuProfile_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}