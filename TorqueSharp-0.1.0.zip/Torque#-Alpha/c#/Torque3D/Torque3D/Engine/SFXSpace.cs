using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class SFXSpace : SceneObject
	{
		public SFXSpace()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.SFXSpace_create());
		}

		public SFXSpace(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public SFXSpace(SimObject pObj) : base(pObj)
		{
		}

		public SFXSpace(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _SFXSpace_create();
         private static _SFXSpace_create _SFXSpace_createFunc;
         internal static IntPtr SFXSpace_create()
         {
         	if (_SFXSpace_createFunc == null)
         	{
         		_SFXSpace_createFunc =
         			(_SFXSpace_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_SFXSpace_create"), typeof(_SFXSpace_create));
         	}
         
         	return  _SFXSpace_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}