using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiNavEditorCtrl : EditTSCtrl
	{
		public GuiNavEditorCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiNavEditorCtrl_create());
		}

		public GuiNavEditorCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiNavEditorCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiNavEditorCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _selectMesh(IntPtr thisPtr, int id);
         private static _selectMesh _selectMeshFunc;
         internal static void selectMesh(IntPtr thisPtr, int id)
         {
         	if (_selectMeshFunc == null)
         	{
         		_selectMeshFunc =
         			(_selectMesh)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiNavEditorCtrl_selectMesh"), typeof(_selectMesh));
         	}
         
         	 _selectMeshFunc(thisPtr, id);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getMesh(IntPtr thisPtr);
         private static _getMesh _getMeshFunc;
         internal static int getMesh(IntPtr thisPtr)
         {
         	if (_getMeshFunc == null)
         	{
         		_getMeshFunc =
         			(_getMesh)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiNavEditorCtrl_getMesh"), typeof(_getMesh));
         	}
         
         	return  _getMeshFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getPlayer(IntPtr thisPtr);
         private static _getPlayer _getPlayerFunc;
         internal static int getPlayer(IntPtr thisPtr)
         {
         	if (_getPlayerFunc == null)
         	{
         		_getPlayerFunc =
         			(_getPlayer)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiNavEditorCtrl_getPlayer"), typeof(_getPlayer));
         	}
         
         	return  _getPlayerFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _deselect(IntPtr thisPtr);
         private static _deselect _deselectFunc;
         internal static void deselect(IntPtr thisPtr)
         {
         	if (_deselectFunc == null)
         	{
         		_deselectFunc =
         			(_deselect)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiNavEditorCtrl_deselect"), typeof(_deselect));
         	}
         
         	 _deselectFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _deleteLink(IntPtr thisPtr);
         private static _deleteLink _deleteLinkFunc;
         internal static void deleteLink(IntPtr thisPtr)
         {
         	if (_deleteLinkFunc == null)
         	{
         		_deleteLinkFunc =
         			(_deleteLink)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiNavEditorCtrl_deleteLink"), typeof(_deleteLink));
         	}
         
         	 _deleteLinkFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setLinkFlags(IntPtr thisPtr, uint flags);
         private static _setLinkFlags _setLinkFlagsFunc;
         internal static void setLinkFlags(IntPtr thisPtr, uint flags)
         {
         	if (_setLinkFlagsFunc == null)
         	{
         		_setLinkFlagsFunc =
         			(_setLinkFlags)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiNavEditorCtrl_setLinkFlags"), typeof(_setLinkFlags));
         	}
         
         	 _setLinkFlagsFunc(thisPtr, flags);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _buildTile(IntPtr thisPtr);
         private static _buildTile _buildTileFunc;
         internal static void buildTile(IntPtr thisPtr)
         {
         	if (_buildTileFunc == null)
         	{
         		_buildTileFunc =
         			(_buildTile)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiNavEditorCtrl_buildTile"), typeof(_buildTile));
         	}
         
         	 _buildTileFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _spawnPlayer(IntPtr thisPtr);
         private static _spawnPlayer _spawnPlayerFunc;
         internal static void spawnPlayer(IntPtr thisPtr)
         {
         	if (_spawnPlayerFunc == null)
         	{
         		_spawnPlayerFunc =
         			(_spawnPlayer)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiNavEditorCtrl_spawnPlayer"), typeof(_spawnPlayer));
         	}
         
         	 _spawnPlayerFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getMode(IntPtr thisPtr, int argc, string[] argv);
         private static _getMode _getModeFunc;
         internal static IntPtr getMode(IntPtr thisPtr, int argc, string[] argv)
         {
         	if (_getModeFunc == null)
         	{
         		_getModeFunc =
         			(_getMode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiNavEditorCtrl_getMode"), typeof(_getMode));
         	}
         
         	return  _getModeFunc(thisPtr, argc, argv);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setMode(IntPtr thisPtr, int argc, string[] argv);
         private static _setMode _setModeFunc;
         internal static void setMode(IntPtr thisPtr, int argc, string[] argv)
         {
         	if (_setModeFunc == null)
         	{
         		_setModeFunc =
         			(_setMode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiNavEditorCtrl_setMode"), typeof(_setMode));
         	}
         
         	 _setModeFunc(thisPtr, argc, argv);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiNavEditorCtrl_create();
         private static _GuiNavEditorCtrl_create _GuiNavEditorCtrl_createFunc;
         internal static IntPtr GuiNavEditorCtrl_create()
         {
         	if (_GuiNavEditorCtrl_createFunc == null)
         	{
         		_GuiNavEditorCtrl_createFunc =
         			(_GuiNavEditorCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiNavEditorCtrl_create"), typeof(_GuiNavEditorCtrl_create));
         	}
         
         	return  _GuiNavEditorCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void selectMesh(int id)
         {
            InternalUnsafeMethods.selectMesh(ObjectPtr->RefPtr->ObjPtr, id);
         }
      
         public int getMesh()
         {
            return InternalUnsafeMethods.getMesh(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public int getPlayer()
         {
            return InternalUnsafeMethods.getPlayer(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void deselect()
         {
            InternalUnsafeMethods.deselect(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void deleteLink()
         {
            InternalUnsafeMethods.deleteLink(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setLinkFlags(uint flags)
         {
            InternalUnsafeMethods.setLinkFlags(ObjectPtr->RefPtr->ObjPtr, flags);
         }
      
         public void buildTile()
         {
            InternalUnsafeMethods.buildTile(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void spawnPlayer()
         {
            InternalUnsafeMethods.spawnPlayer(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public string getMode()
         {
            List<string> tmp_arg_list = new List<string> {""};
                  return Marshal.PtrToStringUni(InternalUnsafeMethods.getMode(ObjectPtr->RefPtr->ObjPtr, tmp_arg_list.Count, tmp_arg_list.ToArray()));
         }
      
         public void setMode()
         {
            List<string> tmp_arg_list = new List<string> {""};
                  InternalUnsafeMethods.setMode(ObjectPtr->RefPtr->ObjPtr, tmp_arg_list.Count, tmp_arg_list.ToArray());
         }
      
      
      #endregion

	}
}