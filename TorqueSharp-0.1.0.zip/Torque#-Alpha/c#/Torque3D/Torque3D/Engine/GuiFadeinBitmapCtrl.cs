using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiFadeinBitmapCtrl : GuiBitmapCtrl
	{
		public GuiFadeinBitmapCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiFadeinBitmapCtrl_create());
		}

		public GuiFadeinBitmapCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiFadeinBitmapCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiFadeinBitmapCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiFadeinBitmapCtrl_create();
         private static _GuiFadeinBitmapCtrl_create _GuiFadeinBitmapCtrl_createFunc;
         internal static IntPtr GuiFadeinBitmapCtrl_create()
         {
         	if (_GuiFadeinBitmapCtrl_createFunc == null)
         	{
         		_GuiFadeinBitmapCtrl_createFunc =
         			(_GuiFadeinBitmapCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiFadeinBitmapCtrl_create"), typeof(_GuiFadeinBitmapCtrl_create));
         	}
         
         	return  _GuiFadeinBitmapCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}