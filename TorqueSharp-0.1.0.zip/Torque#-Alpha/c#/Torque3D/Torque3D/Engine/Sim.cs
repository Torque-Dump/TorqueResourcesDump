﻿using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;

namespace Torque3D.Engine
{
   public unsafe class Sim
   {
      [StructLayout(LayoutKind.Explicit, Size = 4)]
      public struct SimObjectPtr
      {
         [FieldOffset(0)]
         public WeakRefPtr* RefPtr;
      }

      [StructLayout(LayoutKind.Explicit, Size = 4)]
      public struct WeakRefPtr
      {
         [FieldOffset(0)]
         public IntPtr ObjPtr;
      }

      public static SimObject WrapObject(int id)
      {
         return null;
      }

      public static SimObject WrapObject(uint id)
      {
         return null;
      }

      #region UnsafeNativeMethods

      new internal struct InternalUnsafeMethods
      {
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _FindObjectWrapperById(uint id);
         private static _FindObjectWrapperById _FindObjectWrapperByIdFunc;
         internal static IntPtr FindObjectWrapperById(uint id)
         {
            if (_FindObjectWrapperByIdFunc == null)
            {
               _FindObjectWrapperByIdFunc =
                  (_FindObjectWrapperById)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
                     "FindObjectWrapperById"), typeof(_FindObjectWrapperById));
            }

            return _FindObjectWrapperByIdFunc(id);
         }
         
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _FindObjectWrapperByName(string name);
         private static _FindObjectWrapperByName _FindObjectWrapperByNameFunc;
         internal static IntPtr FindObjectWrapperByName(string name)
         {
            if (_FindObjectWrapperByNameFunc == null)
            {
               _FindObjectWrapperByNameFunc =
                  (_FindObjectWrapperByName)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
                     "FindObjectWrapperByName"), typeof(_FindObjectWrapperByName));
            }

            return _FindObjectWrapperByNameFunc(name);
         }

         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _Sim_WrapObject(IntPtr obj);
         private static _Sim_WrapObject _Sim_WrapObjectFunc;
         internal static IntPtr Sim_WrapObject(IntPtr obj)
         {
            if (_Sim_WrapObjectFunc == null)
            {
               _Sim_WrapObjectFunc =
                  (_Sim_WrapObject)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
                     "WrapObject"), typeof(_Sim_WrapObject));
            }

            return _Sim_WrapObjectFunc(obj);
         }
      }

      #endregion

      #region Functions

      public static SimObject FindObjectById(uint id)
      {
         return new SimObject(FindObjectWrapperById(id));
      }

      public static SimObjectPtr* FindObjectWrapperById(uint id)
      {
         return (SimObjectPtr*)InternalUnsafeMethods.FindObjectWrapperById(id);
      }

      public static T FindObjectByName<T>(string name) where T : SimObject
      {
         T obj = (T)FormatterServices.GetUninitializedObject(typeof(T));
         obj.SetPointer(FindObjectWrapperByName(name));
         return obj;
      }

      public static SimObjectPtr* FindObjectWrapperByName(string name)
      {
         return (SimObjectPtr*)InternalUnsafeMethods.FindObjectWrapperByName(name);
      }

      public static SimObjectPtr* WrapObject(IntPtr obj)
      {
         return (SimObjectPtr*)InternalUnsafeMethods.Sim_WrapObject(obj);
      }

      #endregion
   }
}
