using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class HoverVehicle : Vehicle
	{
		public HoverVehicle()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.HoverVehicle_create());
		}

		public HoverVehicle(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public HoverVehicle(SimObject pObj) : base(pObj)
		{
		}

		public HoverVehicle(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _HoverVehicle_create();
         private static _HoverVehicle_create _HoverVehicle_createFunc;
         internal static IntPtr HoverVehicle_create()
         {
         	if (_HoverVehicle_createFunc == null)
         	{
         		_HoverVehicle_createFunc =
         			(_HoverVehicle_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_HoverVehicle_create"), typeof(_HoverVehicle_create));
         	}
         
         	return  _HoverVehicle_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}