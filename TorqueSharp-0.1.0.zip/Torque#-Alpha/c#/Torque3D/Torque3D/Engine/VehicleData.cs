using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class VehicleData : ShapeBaseData
	{
		public VehicleData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.VehicleData_create());
		}

		public VehicleData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public VehicleData(SimObject pObj) : base(pObj)
		{
		}

		public VehicleData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _VehicleData_create();
         private static _VehicleData_create _VehicleData_createFunc;
         internal static IntPtr VehicleData_create()
         {
         	if (_VehicleData_createFunc == null)
         	{
         		_VehicleData_createFunc =
         			(_VehicleData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_VehicleData_create"), typeof(_VehicleData_create));
         	}
         
         	return  _VehicleData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}