using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class RenderPassStateBin : RenderBinManager
	{
		public RenderPassStateBin()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.RenderPassStateBin_create());
		}

		public RenderPassStateBin(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public RenderPassStateBin(SimObject pObj) : base(pObj)
		{
		}

		public RenderPassStateBin(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _RenderPassStateBin_create();
         private static _RenderPassStateBin_create _RenderPassStateBin_createFunc;
         internal static IntPtr RenderPassStateBin_create()
         {
         	if (_RenderPassStateBin_createFunc == null)
         	{
         		_RenderPassStateBin_createFunc =
         			(_RenderPassStateBin_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_RenderPassStateBin_create"), typeof(_RenderPassStateBin_create));
         	}
         
         	return  _RenderPassStateBin_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}