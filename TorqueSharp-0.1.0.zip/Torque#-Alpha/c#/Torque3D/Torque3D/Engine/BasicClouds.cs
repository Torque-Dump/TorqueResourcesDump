using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class BasicClouds : SceneObject
	{
		public BasicClouds()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.BasicClouds_create());
		}

		public BasicClouds(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public BasicClouds(SimObject pObj) : base(pObj)
		{
		}

		public BasicClouds(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _BasicClouds_create();
         private static _BasicClouds_create _BasicClouds_createFunc;
         internal static IntPtr BasicClouds_create()
         {
         	if (_BasicClouds_createFunc == null)
         	{
         		_BasicClouds_createFunc =
         			(_BasicClouds_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_BasicClouds_create"), typeof(_BasicClouds_create));
         	}
         
         	return  _BasicClouds_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}