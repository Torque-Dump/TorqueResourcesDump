using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiTabPageCtrl : GuiTextCtrl
	{
		public GuiTabPageCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiTabPageCtrl_create());
		}

		public GuiTabPageCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiTabPageCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiTabPageCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _select(IntPtr thisPtr);
         private static _select _selectFunc;
         internal static void select(IntPtr thisPtr)
         {
         	if (_selectFunc == null)
         	{
         		_selectFunc =
         			(_select)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiTabPageCtrl_select"), typeof(_select));
         	}
         
         	 _selectFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiTabPageCtrl_create();
         private static _GuiTabPageCtrl_create _GuiTabPageCtrl_createFunc;
         internal static IntPtr GuiTabPageCtrl_create()
         {
         	if (_GuiTabPageCtrl_createFunc == null)
         	{
         		_GuiTabPageCtrl_createFunc =
         			(_GuiTabPageCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiTabPageCtrl_create"), typeof(_GuiTabPageCtrl_create));
         	}
         
         	return  _GuiTabPageCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void select()
         {
            InternalUnsafeMethods.select(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}