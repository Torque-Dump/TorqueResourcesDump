using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class guiAnimBitmapCtrl : GuiBitmapCtrl
	{
		public guiAnimBitmapCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.guiAnimBitmapCtrl_create());
		}

		public guiAnimBitmapCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public guiAnimBitmapCtrl(SimObject pObj) : base(pObj)
		{
		}

		public guiAnimBitmapCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _guiAnimBitmapCtrl_create();
         private static _guiAnimBitmapCtrl_create _guiAnimBitmapCtrl_createFunc;
         internal static IntPtr guiAnimBitmapCtrl_create()
         {
         	if (_guiAnimBitmapCtrl_createFunc == null)
         	{
         		_guiAnimBitmapCtrl_createFunc =
         			(_guiAnimBitmapCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_guiAnimBitmapCtrl_create"), typeof(_guiAnimBitmapCtrl_create));
         	}
         
         	return  _guiAnimBitmapCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}