using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class TerrainSmoothAction : UndoAction
	{
		public TerrainSmoothAction()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.TerrainSmoothAction_create());
		}

		public TerrainSmoothAction(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public TerrainSmoothAction(SimObject pObj) : base(pObj)
		{
		}

		public TerrainSmoothAction(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _smooth(IntPtr thisPtr, IntPtr terrain, float factor, uint steps);
         private static _smooth _smoothFunc;
         internal static void smooth(IntPtr thisPtr, IntPtr terrain, float factor, uint steps)
         {
         	if (_smoothFunc == null)
         	{
         		_smoothFunc =
         			(_smooth)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTerrainSmoothAction_smooth"), typeof(_smooth));
         	}
         
         	 _smoothFunc(thisPtr, terrain, factor, steps);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _TerrainSmoothAction_create();
         private static _TerrainSmoothAction_create _TerrainSmoothAction_createFunc;
         internal static IntPtr TerrainSmoothAction_create()
         {
         	if (_TerrainSmoothAction_createFunc == null)
         	{
         		_TerrainSmoothAction_createFunc =
         			(_TerrainSmoothAction_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_TerrainSmoothAction_create"), typeof(_TerrainSmoothAction_create));
         	}
         
         	return  _TerrainSmoothAction_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void smooth(TerrainBlock terrain, float factor, uint steps)
         {
            InternalUnsafeMethods.smooth(ObjectPtr->RefPtr->ObjPtr, terrain.ObjectPtr->RefPtr->ObjPtr, factor, steps);
         }
      
      
      #endregion

	}
}