using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiInspectorTypeEaseF : GuiInspectorField
	{
		public GuiInspectorTypeEaseF()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiInspectorTypeEaseF_create());
		}

		public GuiInspectorTypeEaseF(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiInspectorTypeEaseF(SimObject pObj) : base(pObj)
		{
		}

		public GuiInspectorTypeEaseF(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiInspectorTypeEaseF_create();
         private static _GuiInspectorTypeEaseF_create _GuiInspectorTypeEaseF_createFunc;
         internal static IntPtr GuiInspectorTypeEaseF_create()
         {
         	if (_GuiInspectorTypeEaseF_createFunc == null)
         	{
         		_GuiInspectorTypeEaseF_createFunc =
         			(_GuiInspectorTypeEaseF_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiInspectorTypeEaseF_create"), typeof(_GuiInspectorTypeEaseF_create));
         	}
         
         	return  _GuiInspectorTypeEaseF_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}