using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiInspectorTypeSFXStateName : GuiInspectorTypeMenuBase
	{
		public GuiInspectorTypeSFXStateName()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiInspectorTypeSFXStateName_create());
		}

		public GuiInspectorTypeSFXStateName(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiInspectorTypeSFXStateName(SimObject pObj) : base(pObj)
		{
		}

		public GuiInspectorTypeSFXStateName(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiInspectorTypeSFXStateName_create();
         private static _GuiInspectorTypeSFXStateName_create _GuiInspectorTypeSFXStateName_createFunc;
         internal static IntPtr GuiInspectorTypeSFXStateName_create()
         {
         	if (_GuiInspectorTypeSFXStateName_createFunc == null)
         	{
         		_GuiInspectorTypeSFXStateName_createFunc =
         			(_GuiInspectorTypeSFXStateName_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiInspectorTypeSFXStateName_create"), typeof(_GuiInspectorTypeSFXStateName_create));
         	}
         
         	return  _GuiInspectorTypeSFXStateName_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}