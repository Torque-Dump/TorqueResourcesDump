using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class RenderGlowMgr : RenderTexTargetBinManager
	{
		public RenderGlowMgr()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.RenderGlowMgr_create());
		}

		public RenderGlowMgr(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public RenderGlowMgr(SimObject pObj) : base(pObj)
		{
		}

		public RenderGlowMgr(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _RenderGlowMgr_create();
         private static _RenderGlowMgr_create _RenderGlowMgr_createFunc;
         internal static IntPtr RenderGlowMgr_create()
         {
         	if (_RenderGlowMgr_createFunc == null)
         	{
         		_RenderGlowMgr_createFunc =
         			(_RenderGlowMgr_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_RenderGlowMgr_create"), typeof(_RenderGlowMgr_create));
         	}
         
         	return  _RenderGlowMgr_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}