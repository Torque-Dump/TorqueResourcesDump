using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ShapeBaseImageData : GameBaseData
	{
		public ShapeBaseImageData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ShapeBaseImageData_create());
		}

		public ShapeBaseImageData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ShapeBaseImageData(SimObject pObj) : base(pObj)
		{
		}

		public ShapeBaseImageData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ShapeBaseImageData_create();
         private static _ShapeBaseImageData_create _ShapeBaseImageData_createFunc;
         internal static IntPtr ShapeBaseImageData_create()
         {
         	if (_ShapeBaseImageData_createFunc == null)
         	{
         		_ShapeBaseImageData_createFunc =
         			(_ShapeBaseImageData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ShapeBaseImageData_create"), typeof(_ShapeBaseImageData_create));
         	}
         
         	return  _ShapeBaseImageData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}