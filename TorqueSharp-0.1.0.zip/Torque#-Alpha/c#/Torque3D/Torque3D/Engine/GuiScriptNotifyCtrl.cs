using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiScriptNotifyCtrl : GuiControl
	{
		public GuiScriptNotifyCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiScriptNotifyCtrl_create());
		}

		public GuiScriptNotifyCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiScriptNotifyCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiScriptNotifyCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiScriptNotifyCtrl_create();
         private static _GuiScriptNotifyCtrl_create _GuiScriptNotifyCtrl_createFunc;
         internal static IntPtr GuiScriptNotifyCtrl_create()
         {
         	if (_GuiScriptNotifyCtrl_createFunc == null)
         	{
         		_GuiScriptNotifyCtrl_createFunc =
         			(_GuiScriptNotifyCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiScriptNotifyCtrl_create"), typeof(_GuiScriptNotifyCtrl_create));
         	}
         
         	return  _GuiScriptNotifyCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}