using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiInspectorTypeRectUV : GuiInspectorField
	{
		public GuiInspectorTypeRectUV()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiInspectorTypeRectUV_create());
		}

		public GuiInspectorTypeRectUV(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiInspectorTypeRectUV(SimObject pObj) : base(pObj)
		{
		}

		public GuiInspectorTypeRectUV(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiInspectorTypeRectUV_create();
         private static _GuiInspectorTypeRectUV_create _GuiInspectorTypeRectUV_createFunc;
         internal static IntPtr GuiInspectorTypeRectUV_create()
         {
         	if (_GuiInspectorTypeRectUV_createFunc == null)
         	{
         		_GuiInspectorTypeRectUV_createFunc =
         			(_GuiInspectorTypeRectUV_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiInspectorTypeRectUV_create"), typeof(_GuiInspectorTypeRectUV_create));
         	}
         
         	return  _GuiInspectorTypeRectUV_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}