using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiBitmapBarCtrl : GuiBitmapCtrl
	{
		public GuiBitmapBarCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiBitmapBarCtrl_create());
		}

		public GuiBitmapBarCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiBitmapBarCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiBitmapBarCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiBitmapBarCtrl_create();
         private static _GuiBitmapBarCtrl_create _GuiBitmapBarCtrl_createFunc;
         internal static IntPtr GuiBitmapBarCtrl_create()
         {
         	if (_GuiBitmapBarCtrl_createFunc == null)
         	{
         		_GuiBitmapBarCtrl_createFunc =
         			(_GuiBitmapBarCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiBitmapBarCtrl_create"), typeof(_GuiBitmapBarCtrl_create));
         	}
         
         	return  _GuiBitmapBarCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}