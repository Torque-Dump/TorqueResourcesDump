using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiProgressCtrl : GuiTextCtrl
	{
		public GuiProgressCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiProgressCtrl_create());
		}

		public GuiProgressCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiProgressCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiProgressCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiProgressCtrl_create();
         private static _GuiProgressCtrl_create _GuiProgressCtrl_createFunc;
         internal static IntPtr GuiProgressCtrl_create()
         {
         	if (_GuiProgressCtrl_createFunc == null)
         	{
         		_GuiProgressCtrl_createFunc =
         			(_GuiProgressCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiProgressCtrl_create"), typeof(_GuiProgressCtrl_create));
         	}
         
         	return  _GuiProgressCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}