using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class SFXEnvironment : SimDataBlock
	{
		public SFXEnvironment()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.SFXEnvironment_create());
		}

		public SFXEnvironment(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public SFXEnvironment(SimObject pObj) : base(pObj)
		{
		}

		public SFXEnvironment(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _SFXEnvironment_create();
         private static _SFXEnvironment_create _SFXEnvironment_createFunc;
         internal static IntPtr SFXEnvironment_create()
         {
         	if (_SFXEnvironment_createFunc == null)
         	{
         		_SFXEnvironment_createFunc =
         			(_SFXEnvironment_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_SFXEnvironment_create"), typeof(_SFXEnvironment_create));
         	}
         
         	return  _SFXEnvironment_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}