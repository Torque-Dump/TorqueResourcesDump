using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ComponentAsset : AssetBase
	{
		public ComponentAsset()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ComponentAsset_create());
		}

		public ComponentAsset(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ComponentAsset(SimObject pObj) : base(pObj)
		{
		}

		public ComponentAsset(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ComponentAsset_create();
         private static _ComponentAsset_create _ComponentAsset_createFunc;
         internal static IntPtr ComponentAsset_create()
         {
         	if (_ComponentAsset_createFunc == null)
         	{
         		_ComponentAsset_createFunc =
         			(_ComponentAsset_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ComponentAsset_create"), typeof(_ComponentAsset_create));
         	}
         
         	return  _ComponentAsset_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}