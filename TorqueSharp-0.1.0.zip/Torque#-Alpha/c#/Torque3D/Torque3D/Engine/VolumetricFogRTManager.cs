using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class VolumetricFogRTManager : SceneObject
	{
		public VolumetricFogRTManager()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.VolumetricFogRTManager_create());
		}

		public VolumetricFogRTManager(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public VolumetricFogRTManager(SimObject pObj) : base(pObj)
		{
		}

		public VolumetricFogRTManager(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _VolumetricFogRTManager_create();
         private static _VolumetricFogRTManager_create _VolumetricFogRTManager_createFunc;
         internal static IntPtr VolumetricFogRTManager_create()
         {
         	if (_VolumetricFogRTManager_createFunc == null)
         	{
         		_VolumetricFogRTManager_createFunc =
         			(_VolumetricFogRTManager_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_VolumetricFogRTManager_create"), typeof(_VolumetricFogRTManager_create));
         	}
         
         	return  _VolumetricFogRTManager_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}