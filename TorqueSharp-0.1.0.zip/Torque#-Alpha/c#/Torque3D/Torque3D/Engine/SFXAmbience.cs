using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class SFXAmbience : SimDataBlock
	{
		public SFXAmbience()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.SFXAmbience_create());
		}

		public SFXAmbience(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public SFXAmbience(SimObject pObj) : base(pObj)
		{
		}

		public SFXAmbience(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _SFXAmbience_create();
         private static _SFXAmbience_create _SFXAmbience_createFunc;
         internal static IntPtr SFXAmbience_create()
         {
         	if (_SFXAmbience_createFunc == null)
         	{
         		_SFXAmbience_createFunc =
         			(_SFXAmbience_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_SFXAmbience_create"), typeof(_SFXAmbience_create));
         	}
         
         	return  _SFXAmbience_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}