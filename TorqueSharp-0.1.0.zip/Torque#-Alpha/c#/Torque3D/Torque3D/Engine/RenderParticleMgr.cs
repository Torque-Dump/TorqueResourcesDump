using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class RenderParticleMgr : RenderTexTargetBinManager
	{
		public RenderParticleMgr()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.RenderParticleMgr_create());
		}

		public RenderParticleMgr(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public RenderParticleMgr(SimObject pObj) : base(pObj)
		{
		}

		public RenderParticleMgr(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _RenderParticleMgr_create();
         private static _RenderParticleMgr_create _RenderParticleMgr_createFunc;
         internal static IntPtr RenderParticleMgr_create()
         {
         	if (_RenderParticleMgr_createFunc == null)
         	{
         		_RenderParticleMgr_createFunc =
         			(_RenderParticleMgr_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_RenderParticleMgr_create"), typeof(_RenderParticleMgr_create));
         	}
         
         	return  _RenderParticleMgr_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}