using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiInspectorVariableField : GuiInspectorField
	{
		public GuiInspectorVariableField()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiInspectorVariableField_create());
		}

		public GuiInspectorVariableField(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiInspectorVariableField(SimObject pObj) : base(pObj)
		{
		}

		public GuiInspectorVariableField(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiInspectorVariableField_create();
         private static _GuiInspectorVariableField_create _GuiInspectorVariableField_createFunc;
         internal static IntPtr GuiInspectorVariableField_create()
         {
         	if (_GuiInspectorVariableField_createFunc == null)
         	{
         		_GuiInspectorVariableField_createFunc =
         			(_GuiInspectorVariableField_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiInspectorVariableField_create"), typeof(_GuiInspectorVariableField_create));
         	}
         
         	return  _GuiInspectorVariableField_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}