using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class HoverVehicleData : VehicleData
	{
		public HoverVehicleData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.HoverVehicleData_create());
		}

		public HoverVehicleData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public HoverVehicleData(SimObject pObj) : base(pObj)
		{
		}

		public HoverVehicleData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _HoverVehicleData_create();
         private static _HoverVehicleData_create _HoverVehicleData_createFunc;
         internal static IntPtr HoverVehicleData_create()
         {
         	if (_HoverVehicleData_createFunc == null)
         	{
         		_HoverVehicleData_createFunc =
         			(_HoverVehicleData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_HoverVehicleData_create"), typeof(_HoverVehicleData_create));
         	}
         
         	return  _HoverVehicleData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}