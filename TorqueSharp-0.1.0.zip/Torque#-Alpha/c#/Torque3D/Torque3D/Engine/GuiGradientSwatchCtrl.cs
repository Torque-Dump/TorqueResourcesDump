using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiGradientSwatchCtrl : GuiSwatchButtonCtrl
	{
		public GuiGradientSwatchCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiGradientSwatchCtrl_create());
		}

		public GuiGradientSwatchCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiGradientSwatchCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiGradientSwatchCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiGradientSwatchCtrl_create();
         private static _GuiGradientSwatchCtrl_create _GuiGradientSwatchCtrl_createFunc;
         internal static IntPtr GuiGradientSwatchCtrl_create()
         {
         	if (_GuiGradientSwatchCtrl_createFunc == null)
         	{
         		_GuiGradientSwatchCtrl_createFunc =
         			(_GuiGradientSwatchCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiGradientSwatchCtrl_create"), typeof(_GuiGradientSwatchCtrl_create));
         	}
         
         	return  _GuiGradientSwatchCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}