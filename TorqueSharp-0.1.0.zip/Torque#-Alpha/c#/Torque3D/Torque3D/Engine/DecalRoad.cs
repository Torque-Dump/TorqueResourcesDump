using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class DecalRoad : SceneObject
	{
		public DecalRoad()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.DecalRoad_create());
		}

		public DecalRoad(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public DecalRoad(SimObject pObj) : base(pObj)
		{
		}

		public DecalRoad(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _regenerate(IntPtr thisPtr);
         private static _regenerate _regenerateFunc;
         internal static void regenerate(IntPtr thisPtr)
         {
         	if (_regenerateFunc == null)
         	{
         		_regenerateFunc =
         			(_regenerate)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnDecalRoad_regenerate"), typeof(_regenerate));
         	}
         
         	 _regenerateFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _postApply(IntPtr thisPtr);
         private static _postApply _postApplyFunc;
         internal static void postApply(IntPtr thisPtr)
         {
         	if (_postApplyFunc == null)
         	{
         		_postApplyFunc =
         			(_postApply)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnDecalRoad_postApply"), typeof(_postApply));
         	}
         
         	 _postApplyFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _DecalRoad_create();
         private static _DecalRoad_create _DecalRoad_createFunc;
         internal static IntPtr DecalRoad_create()
         {
         	if (_DecalRoad_createFunc == null)
         	{
         		_DecalRoad_createFunc =
         			(_DecalRoad_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_DecalRoad_create"), typeof(_DecalRoad_create));
         	}
         
         	return  _DecalRoad_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void regenerate()
         {
            InternalUnsafeMethods.regenerate(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void postApply()
         {
            InternalUnsafeMethods.postApply(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}