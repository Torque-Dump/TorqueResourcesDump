using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GizmoProfile : SimObject
	{
		public GizmoProfile()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GizmoProfile_create());
		}

		public GizmoProfile(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GizmoProfile(SimObject pObj) : base(pObj)
		{
		}

		public GizmoProfile(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GizmoProfile_create();
         private static _GizmoProfile_create _GizmoProfile_createFunc;
         internal static IntPtr GizmoProfile_create()
         {
         	if (_GizmoProfile_createFunc == null)
         	{
         		_GizmoProfile_createFunc =
         			(_GizmoProfile_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GizmoProfile_create"), typeof(_GizmoProfile_create));
         	}
         
         	return  _GizmoProfile_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}