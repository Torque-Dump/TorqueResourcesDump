using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class fxShapeReplicator : SceneObject
	{
		public fxShapeReplicator()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.fxShapeReplicator_create());
		}

		public fxShapeReplicator(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public fxShapeReplicator(SimObject pObj) : base(pObj)
		{
		}

		public fxShapeReplicator(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _fxShapeReplicator_create();
         private static _fxShapeReplicator_create _fxShapeReplicator_createFunc;
         internal static IntPtr fxShapeReplicator_create()
         {
         	if (_fxShapeReplicator_createFunc == null)
         	{
         		_fxShapeReplicator_createFunc =
         			(_fxShapeReplicator_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_fxShapeReplicator_create"), typeof(_fxShapeReplicator_create));
         	}
         
         	return  _fxShapeReplicator_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}