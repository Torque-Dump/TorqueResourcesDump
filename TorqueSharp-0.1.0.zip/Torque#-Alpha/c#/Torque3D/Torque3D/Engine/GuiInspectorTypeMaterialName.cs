using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiInspectorTypeMaterialName : GuiInspectorField
	{
		public GuiInspectorTypeMaterialName()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiInspectorTypeMaterialName_create());
		}

		public GuiInspectorTypeMaterialName(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiInspectorTypeMaterialName(SimObject pObj) : base(pObj)
		{
		}

		public GuiInspectorTypeMaterialName(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiInspectorTypeMaterialName_create();
         private static _GuiInspectorTypeMaterialName_create _GuiInspectorTypeMaterialName_createFunc;
         internal static IntPtr GuiInspectorTypeMaterialName_create()
         {
         	if (_GuiInspectorTypeMaterialName_createFunc == null)
         	{
         		_GuiInspectorTypeMaterialName_createFunc =
         			(_GuiInspectorTypeMaterialName_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiInspectorTypeMaterialName_create"), typeof(_GuiInspectorTypeMaterialName_create));
         	}
         
         	return  _GuiInspectorTypeMaterialName_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}