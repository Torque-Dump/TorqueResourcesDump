using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class DBDeleteUndoAction : UndoAction
	{
		public DBDeleteUndoAction()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.DBDeleteUndoAction_create());
		}

		public DBDeleteUndoAction(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public DBDeleteUndoAction(SimObject pObj) : base(pObj)
		{
		}

		public DBDeleteUndoAction(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _DBDeleteUndoAction_create();
         private static _DBDeleteUndoAction_create _DBDeleteUndoAction_createFunc;
         internal static IntPtr DBDeleteUndoAction_create()
         {
         	if (_DBDeleteUndoAction_createFunc == null)
         	{
         		_DBDeleteUndoAction_createFunc =
         			(_DBDeleteUndoAction_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_DBDeleteUndoAction_create"), typeof(_DBDeleteUndoAction_create));
         	}
         
         	return  _DBDeleteUndoAction_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}