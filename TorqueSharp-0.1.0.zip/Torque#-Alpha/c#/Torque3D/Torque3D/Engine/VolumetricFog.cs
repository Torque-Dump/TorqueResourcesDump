using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class VolumetricFog : SceneObject
	{
		public VolumetricFog()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.VolumetricFog_create());
		}

		public VolumetricFog(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public VolumetricFog(SimObject pObj) : base(pObj)
		{
		}

		public VolumetricFog(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _SetFogColorF(IntPtr thisPtr, InternalColorFStruct new_color);
         private static _SetFogColorF _SetFogColorFFunc;
         internal static void SetFogColorF(IntPtr thisPtr, InternalColorFStruct new_color)
         {
         	if (_SetFogColorFFunc == null)
         	{
         		_SetFogColorFFunc =
         			(_SetFogColorF)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnVolumetricFog_SetFogColorF"), typeof(_SetFogColorF));
         	}
         
         	 _SetFogColorFFunc(thisPtr, new_color);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _SetFogColor(IntPtr thisPtr, InternalColorIStruct new_color);
         private static _SetFogColor _SetFogColorFunc;
         internal static void SetFogColor(IntPtr thisPtr, InternalColorIStruct new_color)
         {
         	if (_SetFogColorFunc == null)
         	{
         		_SetFogColorFunc =
         			(_SetFogColor)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnVolumetricFog_SetFogColor"), typeof(_SetFogColor));
         	}
         
         	 _SetFogColorFunc(thisPtr, new_color);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _SetFogDensity(IntPtr thisPtr, float new_density);
         private static _SetFogDensity _SetFogDensityFunc;
         internal static void SetFogDensity(IntPtr thisPtr, float new_density)
         {
         	if (_SetFogDensityFunc == null)
         	{
         		_SetFogDensityFunc =
         			(_SetFogDensity)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnVolumetricFog_SetFogDensity"), typeof(_SetFogDensity));
         	}
         
         	 _SetFogDensityFunc(thisPtr, new_density);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _SetFogModulation(IntPtr thisPtr, float new_strenght, float[] new_speed1, float[] new_speed2);
         private static _SetFogModulation _SetFogModulationFunc;
         internal static void SetFogModulation(IntPtr thisPtr, float new_strenght, float[] new_speed1, float[] new_speed2)
         {
         	if (_SetFogModulationFunc == null)
         	{
         		_SetFogModulationFunc =
         			(_SetFogModulation)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnVolumetricFog_SetFogModulation"), typeof(_SetFogModulation));
         	}
         
         	 _SetFogModulationFunc(thisPtr, new_strenght, new_speed1, new_speed2);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _SetFogGlow(IntPtr thisPtr, bool on_off, float strength);
         private static _SetFogGlow _SetFogGlowFunc;
         internal static void SetFogGlow(IntPtr thisPtr, bool on_off, float strength)
         {
         	if (_SetFogGlowFunc == null)
         	{
         		_SetFogGlowFunc =
         			(_SetFogGlow)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnVolumetricFog_SetFogGlow"), typeof(_SetFogGlow));
         	}
         
         	 _SetFogGlowFunc(thisPtr, on_off, strength);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _SetFogLightray(IntPtr thisPtr, bool on_off, float strength);
         private static _SetFogLightray _SetFogLightrayFunc;
         internal static void SetFogLightray(IntPtr thisPtr, bool on_off, float strength)
         {
         	if (_SetFogLightrayFunc == null)
         	{
         		_SetFogLightrayFunc =
         			(_SetFogLightray)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnVolumetricFog_SetFogLightray"), typeof(_SetFogLightray));
         	}
         
         	 _SetFogLightrayFunc(thisPtr, on_off, strength);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _isInsideFog(IntPtr thisPtr);
         private static _isInsideFog _isInsideFogFunc;
         internal static bool isInsideFog(IntPtr thisPtr)
         {
         	if (_isInsideFogFunc == null)
         	{
         		_isInsideFogFunc =
         			(_isInsideFog)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnVolumetricFog_isInsideFog"), typeof(_isInsideFog));
         	}
         
         	return  _isInsideFogFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _VolumetricFog_create();
         private static _VolumetricFog_create _VolumetricFog_createFunc;
         internal static IntPtr VolumetricFog_create()
         {
         	if (_VolumetricFog_createFunc == null)
         	{
         		_VolumetricFog_createFunc =
         			(_VolumetricFog_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_VolumetricFog_create"), typeof(_VolumetricFog_create));
         	}
         
         	return  _VolumetricFog_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void SetFogColorF(ColorF new_color)
         {
            InternalUnsafeMethods.SetFogColorF(ObjectPtr->RefPtr->ObjPtr, new_color.ToStruct());
         }
      
         public void SetFogColor(ColorI new_color)
         {
            InternalUnsafeMethods.SetFogColor(ObjectPtr->RefPtr->ObjPtr, new_color.ToStruct());
         }
      
         public void SetFogDensity(float new_density)
         {
            InternalUnsafeMethods.SetFogDensity(ObjectPtr->RefPtr->ObjPtr, new_density);
         }
      
         public void SetFogModulation(float new_strenght, Point2F new_speed1, Point2F new_speed2)
         {
            InternalUnsafeMethods.SetFogModulation(ObjectPtr->RefPtr->ObjPtr, new_strenght, new_speed1.ToArray(), new_speed2.ToArray());
         }
      
         public void SetFogGlow(bool on_off, float strength)
         {
            InternalUnsafeMethods.SetFogGlow(ObjectPtr->RefPtr->ObjPtr, on_off, strength);
         }
      
         public void SetFogLightray(bool on_off, float strength)
         {
            InternalUnsafeMethods.SetFogLightray(ObjectPtr->RefPtr->ObjPtr, on_off, strength);
         }
      
         public bool isInsideFog()
         {
            return InternalUnsafeMethods.isInsideFog(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}