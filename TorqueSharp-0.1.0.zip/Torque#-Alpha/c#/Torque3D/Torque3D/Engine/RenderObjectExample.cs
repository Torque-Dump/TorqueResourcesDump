using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class RenderObjectExample : SceneObject
	{
		public RenderObjectExample()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.RenderObjectExample_create());
		}

		public RenderObjectExample(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public RenderObjectExample(SimObject pObj) : base(pObj)
		{
		}

		public RenderObjectExample(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _RenderObjectExample_create();
         private static _RenderObjectExample_create _RenderObjectExample_createFunc;
         internal static IntPtr RenderObjectExample_create()
         {
         	if (_RenderObjectExample_createFunc == null)
         	{
         		_RenderObjectExample_createFunc =
         			(_RenderObjectExample_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_RenderObjectExample_create"), typeof(_RenderObjectExample_create));
         	}
         
         	return  _RenderObjectExample_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}