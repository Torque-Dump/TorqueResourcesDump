using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ParticleEmitterNodeData : GameBaseData
	{
		public ParticleEmitterNodeData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ParticleEmitterNodeData_create());
		}

		public ParticleEmitterNodeData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ParticleEmitterNodeData(SimObject pObj) : base(pObj)
		{
		}

		public ParticleEmitterNodeData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ParticleEmitterNodeData_create();
         private static _ParticleEmitterNodeData_create _ParticleEmitterNodeData_createFunc;
         internal static IntPtr ParticleEmitterNodeData_create()
         {
         	if (_ParticleEmitterNodeData_createFunc == null)
         	{
         		_ParticleEmitterNodeData_createFunc =
         			(_ParticleEmitterNodeData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ParticleEmitterNodeData_create"), typeof(_ParticleEmitterNodeData_create));
         	}
         
         	return  _ParticleEmitterNodeData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}