using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class RenderImposterMgr : RenderBinManager
	{
		public RenderImposterMgr()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.RenderImposterMgr_create());
		}

		public RenderImposterMgr(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public RenderImposterMgr(SimObject pObj) : base(pObj)
		{
		}

		public RenderImposterMgr(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _RenderImposterMgr_create();
         private static _RenderImposterMgr_create _RenderImposterMgr_createFunc;
         internal static IntPtr RenderImposterMgr_create()
         {
         	if (_RenderImposterMgr_createFunc == null)
         	{
         		_RenderImposterMgr_createFunc =
         			(_RenderImposterMgr_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_RenderImposterMgr_create"), typeof(_RenderImposterMgr_create));
         	}
         
         	return  _RenderImposterMgr_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}