using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiTextCtrl : GuiContainer
	{
		public GuiTextCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiTextCtrl_create());
		}

		public GuiTextCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiTextCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiTextCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setText(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string text);
         private static _setText _setTextFunc;
         internal static void setText(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string text)
         {
         	if (_setTextFunc == null)
         	{
         		_setTextFunc =
         			(_setText)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiTextCtrl_setText"), typeof(_setText));
         	}
         
         	 _setTextFunc(thisPtr, text);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setTextID(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string textID);
         private static _setTextID _setTextIDFunc;
         internal static void setTextID(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string textID)
         {
         	if (_setTextIDFunc == null)
         	{
         		_setTextIDFunc =
         			(_setTextID)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiTextCtrl_setTextID"), typeof(_setTextID));
         	}
         
         	 _setTextIDFunc(thisPtr, textID);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiTextCtrl_create();
         private static _GuiTextCtrl_create _GuiTextCtrl_createFunc;
         internal static IntPtr GuiTextCtrl_create()
         {
         	if (_GuiTextCtrl_createFunc == null)
         	{
         		_GuiTextCtrl_createFunc =
         			(_GuiTextCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiTextCtrl_create"), typeof(_GuiTextCtrl_create));
         	}
         
         	return  _GuiTextCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void setText(string text)
         {
            InternalUnsafeMethods.setText(ObjectPtr->RefPtr->ObjPtr, text);
         }
      
         public void setTextID(string textID)
         {
            InternalUnsafeMethods.setTextID(ObjectPtr->RefPtr->ObjPtr, textID);
         }
      
      
      #endregion

	}
}