using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiOffscreenCanvas : GuiCanvas
	{
		public GuiOffscreenCanvas()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiOffscreenCanvas_create());
		}

		public GuiOffscreenCanvas(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiOffscreenCanvas(SimObject pObj) : base(pObj)
		{
		}

		public GuiOffscreenCanvas(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _resetTarget(IntPtr thisPtr);
         private static _resetTarget _resetTargetFunc;
         internal static void resetTarget(IntPtr thisPtr)
         {
         	if (_resetTargetFunc == null)
         	{
         		_resetTargetFunc =
         			(_resetTarget)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiOffscreenCanvas_resetTarget"), typeof(_resetTarget));
         	}
         
         	 _resetTargetFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _markDirty(IntPtr thisPtr);
         private static _markDirty _markDirtyFunc;
         internal static void markDirty(IntPtr thisPtr)
         {
         	if (_markDirtyFunc == null)
         	{
         		_markDirtyFunc =
         			(_markDirty)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiOffscreenCanvas_markDirty"), typeof(_markDirty));
         	}
         
         	 _markDirtyFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiOffscreenCanvas_create();
         private static _GuiOffscreenCanvas_create _GuiOffscreenCanvas_createFunc;
         internal static IntPtr GuiOffscreenCanvas_create()
         {
         	if (_GuiOffscreenCanvas_createFunc == null)
         	{
         		_GuiOffscreenCanvas_createFunc =
         			(_GuiOffscreenCanvas_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiOffscreenCanvas_create"), typeof(_GuiOffscreenCanvas_create));
         	}
         
         	return  _GuiOffscreenCanvas_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void resetTarget()
         {
            InternalUnsafeMethods.resetTarget(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void markDirty()
         {
            InternalUnsafeMethods.markDirty(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}