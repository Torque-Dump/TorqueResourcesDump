using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class RenderOcclusionMgr : RenderBinManager
	{
		public RenderOcclusionMgr()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.RenderOcclusionMgr_create());
		}

		public RenderOcclusionMgr(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public RenderOcclusionMgr(SimObject pObj) : base(pObj)
		{
		}

		public RenderOcclusionMgr(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _RenderOcclusionMgr_create();
         private static _RenderOcclusionMgr_create _RenderOcclusionMgr_createFunc;
         internal static IntPtr RenderOcclusionMgr_create()
         {
         	if (_RenderOcclusionMgr_createFunc == null)
         	{
         		_RenderOcclusionMgr_createFunc =
         			(_RenderOcclusionMgr_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_RenderOcclusionMgr_create"), typeof(_RenderOcclusionMgr_create));
         	}
         
         	return  _RenderOcclusionMgr_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}