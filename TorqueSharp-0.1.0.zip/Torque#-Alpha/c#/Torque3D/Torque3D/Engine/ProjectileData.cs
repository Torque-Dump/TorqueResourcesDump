using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ProjectileData : GameBaseData
	{
		public ProjectileData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ProjectileData_create());
		}

		public ProjectileData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ProjectileData(SimObject pObj) : base(pObj)
		{
		}

		public ProjectileData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ProjectileData_create();
         private static _ProjectileData_create _ProjectileData_createFunc;
         internal static IntPtr ProjectileData_create()
         {
         	if (_ProjectileData_createFunc == null)
         	{
         		_ProjectileData_createFunc =
         			(_ProjectileData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ProjectileData_create"), typeof(_ProjectileData_create));
         	}
         
         	return  _ProjectileData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}