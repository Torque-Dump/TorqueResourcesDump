using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiObjectView : GuiTSCtrl
	{
		public GuiObjectView()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiObjectView_create());
		}

		public GuiObjectView(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiObjectView(SimObject pObj) : base(pObj)
		{
		}

		public GuiObjectView(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getModel(IntPtr thisPtr);
         private static _getModel _getModelFunc;
         internal static IntPtr getModel(IntPtr thisPtr)
         {
         	if (_getModelFunc == null)
         	{
         		_getModelFunc =
         			(_getModel)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_getModel"), typeof(_getModel));
         	}
         
         	return  _getModelFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setModel(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string shapeName);
         private static _setModel _setModelFunc;
         internal static void setModel(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string shapeName)
         {
         	if (_setModelFunc == null)
         	{
         		_setModelFunc =
         			(_setModel)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_setModel"), typeof(_setModel));
         	}
         
         	 _setModelFunc(thisPtr, shapeName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getMountedModel(IntPtr thisPtr);
         private static _getMountedModel _getMountedModelFunc;
         internal static IntPtr getMountedModel(IntPtr thisPtr)
         {
         	if (_getMountedModelFunc == null)
         	{
         		_getMountedModelFunc =
         			(_getMountedModel)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_getMountedModel"), typeof(_getMountedModel));
         	}
         
         	return  _getMountedModelFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setMountedModel(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string shapeName);
         private static _setMountedModel _setMountedModelFunc;
         internal static void setMountedModel(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string shapeName)
         {
         	if (_setMountedModelFunc == null)
         	{
         		_setMountedModelFunc =
         			(_setMountedModel)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_setMountedModel"), typeof(_setMountedModel));
         	}
         
         	 _setMountedModelFunc(thisPtr, shapeName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getSkin(IntPtr thisPtr);
         private static _getSkin _getSkinFunc;
         internal static IntPtr getSkin(IntPtr thisPtr)
         {
         	if (_getSkinFunc == null)
         	{
         		_getSkinFunc =
         			(_getSkin)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_getSkin"), typeof(_getSkin));
         	}
         
         	return  _getSkinFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setSkin(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string skinName);
         private static _setSkin _setSkinFunc;
         internal static void setSkin(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string skinName)
         {
         	if (_setSkinFunc == null)
         	{
         		_setSkinFunc =
         			(_setSkin)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_setSkin"), typeof(_setSkin));
         	}
         
         	 _setSkinFunc(thisPtr, skinName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getMountSkin(IntPtr thisPtr, int param1, int param2);
         private static _getMountSkin _getMountSkinFunc;
         internal static IntPtr getMountSkin(IntPtr thisPtr, int param1, int param2)
         {
         	if (_getMountSkinFunc == null)
         	{
         		_getMountSkinFunc =
         			(_getMountSkin)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_getMountSkin"), typeof(_getMountSkin));
         	}
         
         	return  _getMountSkinFunc(thisPtr, param1, param2);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setMountSkin(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string skinName);
         private static _setMountSkin _setMountSkinFunc;
         internal static void setMountSkin(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string skinName)
         {
         	if (_setMountSkinFunc == null)
         	{
         		_setMountSkinFunc =
         			(_setMountSkin)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_setMountSkin"), typeof(_setMountSkin));
         	}
         
         	 _setMountSkinFunc(thisPtr, skinName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setSeq(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string indexOrName);
         private static _setSeq _setSeqFunc;
         internal static void setSeq(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string indexOrName)
         {
         	if (_setSeqFunc == null)
         	{
         		_setSeqFunc =
         			(_setSeq)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_setSeq"), typeof(_setSeq));
         	}
         
         	 _setSeqFunc(thisPtr, indexOrName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setMount(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string shapeName, [MarshalAs(UnmanagedType.LPWStr)]string mountNodeIndexOrName);
         private static _setMount _setMountFunc;
         internal static void setMount(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string shapeName, [MarshalAs(UnmanagedType.LPWStr)]string mountNodeIndexOrName)
         {
         	if (_setMountFunc == null)
         	{
         		_setMountFunc =
         			(_setMount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_setMount"), typeof(_setMount));
         	}
         
         	 _setMountFunc(thisPtr, shapeName, mountNodeIndexOrName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float _getOrbitDistance(IntPtr thisPtr);
         private static _getOrbitDistance _getOrbitDistanceFunc;
         internal static float getOrbitDistance(IntPtr thisPtr)
         {
         	if (_getOrbitDistanceFunc == null)
         	{
         		_getOrbitDistanceFunc =
         			(_getOrbitDistance)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_getOrbitDistance"), typeof(_getOrbitDistance));
         	}
         
         	return  _getOrbitDistanceFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setOrbitDistance(IntPtr thisPtr, float distance);
         private static _setOrbitDistance _setOrbitDistanceFunc;
         internal static void setOrbitDistance(IntPtr thisPtr, float distance)
         {
         	if (_setOrbitDistanceFunc == null)
         	{
         		_setOrbitDistanceFunc =
         			(_setOrbitDistance)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_setOrbitDistance"), typeof(_setOrbitDistance));
         	}
         
         	 _setOrbitDistanceFunc(thisPtr, distance);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float _getCameraSpeed(IntPtr thisPtr);
         private static _getCameraSpeed _getCameraSpeedFunc;
         internal static float getCameraSpeed(IntPtr thisPtr)
         {
         	if (_getCameraSpeedFunc == null)
         	{
         		_getCameraSpeedFunc =
         			(_getCameraSpeed)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_getCameraSpeed"), typeof(_getCameraSpeed));
         	}
         
         	return  _getCameraSpeedFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setCameraSpeed(IntPtr thisPtr, float factor);
         private static _setCameraSpeed _setCameraSpeedFunc;
         internal static void setCameraSpeed(IntPtr thisPtr, float factor)
         {
         	if (_setCameraSpeedFunc == null)
         	{
         		_setCameraSpeedFunc =
         			(_setCameraSpeed)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_setCameraSpeed"), typeof(_setCameraSpeed));
         	}
         
         	 _setCameraSpeedFunc(thisPtr, factor);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setLightColor(IntPtr thisPtr, InternalColorFStruct color);
         private static _setLightColor _setLightColorFunc;
         internal static void setLightColor(IntPtr thisPtr, InternalColorFStruct color)
         {
         	if (_setLightColorFunc == null)
         	{
         		_setLightColorFunc =
         			(_setLightColor)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_setLightColor"), typeof(_setLightColor));
         	}
         
         	 _setLightColorFunc(thisPtr, color);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setLightAmbient(IntPtr thisPtr, InternalColorFStruct color);
         private static _setLightAmbient _setLightAmbientFunc;
         internal static void setLightAmbient(IntPtr thisPtr, InternalColorFStruct color)
         {
         	if (_setLightAmbientFunc == null)
         	{
         		_setLightAmbientFunc =
         			(_setLightAmbient)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_setLightAmbient"), typeof(_setLightAmbient));
         	}
         
         	 _setLightAmbientFunc(thisPtr, color);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setLightDirection(IntPtr thisPtr, float[] direction);
         private static _setLightDirection _setLightDirectionFunc;
         internal static void setLightDirection(IntPtr thisPtr, float[] direction)
         {
         	if (_setLightDirectionFunc == null)
         	{
         		_setLightDirectionFunc =
         			(_setLightDirection)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiObjectView_setLightDirection"), typeof(_setLightDirection));
         	}
         
         	 _setLightDirectionFunc(thisPtr, direction);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiObjectView_create();
         private static _GuiObjectView_create _GuiObjectView_createFunc;
         internal static IntPtr GuiObjectView_create()
         {
         	if (_GuiObjectView_createFunc == null)
         	{
         		_GuiObjectView_createFunc =
         			(_GuiObjectView_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiObjectView_create"), typeof(_GuiObjectView_create));
         	}
         
         	return  _GuiObjectView_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public string getModel()
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getModel(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public void setModel(string shapeName)
         {
            InternalUnsafeMethods.setModel(ObjectPtr->RefPtr->ObjPtr, shapeName);
         }
      
         public string getMountedModel()
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getMountedModel(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public void setMountedModel(string shapeName)
         {
            InternalUnsafeMethods.setMountedModel(ObjectPtr->RefPtr->ObjPtr, shapeName);
         }
      
         public string getSkin()
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getSkin(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public void setSkin(string skinName)
         {
            InternalUnsafeMethods.setSkin(ObjectPtr->RefPtr->ObjPtr, skinName);
         }
      
         public string getMountSkin(int param1, int param2)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getMountSkin(ObjectPtr->RefPtr->ObjPtr, param1, param2));
         }
      
         public void setMountSkin(string skinName)
         {
            InternalUnsafeMethods.setMountSkin(ObjectPtr->RefPtr->ObjPtr, skinName);
         }
      
         public void setSeq(string indexOrName)
         {
            InternalUnsafeMethods.setSeq(ObjectPtr->RefPtr->ObjPtr, indexOrName);
         }
      
         public void setMount(string shapeName, string mountNodeIndexOrName)
         {
            InternalUnsafeMethods.setMount(ObjectPtr->RefPtr->ObjPtr, shapeName, mountNodeIndexOrName);
         }
      
         public float getOrbitDistance()
         {
            return InternalUnsafeMethods.getOrbitDistance(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setOrbitDistance(float distance)
         {
            InternalUnsafeMethods.setOrbitDistance(ObjectPtr->RefPtr->ObjPtr, distance);
         }
      
         public float getCameraSpeed()
         {
            return InternalUnsafeMethods.getCameraSpeed(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setCameraSpeed(float factor)
         {
            InternalUnsafeMethods.setCameraSpeed(ObjectPtr->RefPtr->ObjPtr, factor);
         }
      
         public void setLightColor(ColorF color)
         {
            InternalUnsafeMethods.setLightColor(ObjectPtr->RefPtr->ObjPtr, color.ToStruct());
         }
      
         public void setLightAmbient(ColorF color)
         {
            InternalUnsafeMethods.setLightAmbient(ObjectPtr->RefPtr->ObjPtr, color.ToStruct());
         }
      
         public void setLightDirection(Point3F direction)
         {
            InternalUnsafeMethods.setLightDirection(ObjectPtr->RefPtr->ObjPtr, direction.ToArray());
         }
      
      
      #endregion

	}
}