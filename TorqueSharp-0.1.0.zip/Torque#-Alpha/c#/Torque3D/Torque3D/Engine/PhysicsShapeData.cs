using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class PhysicsShapeData : GameBaseData
	{
		public PhysicsShapeData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.PhysicsShapeData_create());
		}

		public PhysicsShapeData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public PhysicsShapeData(SimObject pObj) : base(pObj)
		{
		}

		public PhysicsShapeData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _PhysicsShapeData_create();
         private static _PhysicsShapeData_create _PhysicsShapeData_createFunc;
         internal static IntPtr PhysicsShapeData_create()
         {
         	if (_PhysicsShapeData_createFunc == null)
         	{
         		_PhysicsShapeData_createFunc =
         			(_PhysicsShapeData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_PhysicsShapeData_create"), typeof(_PhysicsShapeData_create));
         	}
         
         	return  _PhysicsShapeData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}