using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class FlyingVehicle : Vehicle
	{
		public FlyingVehicle()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.FlyingVehicle_create());
		}

		public FlyingVehicle(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public FlyingVehicle(SimObject pObj) : base(pObj)
		{
		}

		public FlyingVehicle(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _useCreateHeight(IntPtr thisPtr, bool enabled);
         private static _useCreateHeight _useCreateHeightFunc;
         internal static void useCreateHeight(IntPtr thisPtr, bool enabled)
         {
         	if (_useCreateHeightFunc == null)
         	{
         		_useCreateHeightFunc =
         			(_useCreateHeight)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnFlyingVehicle_useCreateHeight"), typeof(_useCreateHeight));
         	}
         
         	 _useCreateHeightFunc(thisPtr, enabled);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _FlyingVehicle_create();
         private static _FlyingVehicle_create _FlyingVehicle_createFunc;
         internal static IntPtr FlyingVehicle_create()
         {
         	if (_FlyingVehicle_createFunc == null)
         	{
         		_FlyingVehicle_createFunc =
         			(_FlyingVehicle_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_FlyingVehicle_create"), typeof(_FlyingVehicle_create));
         	}
         
         	return  _FlyingVehicle_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void useCreateHeight(bool enabled)
         {
            InternalUnsafeMethods.useCreateHeight(ObjectPtr->RefPtr->ObjPtr, enabled);
         }
      
      
      #endregion

	}
}