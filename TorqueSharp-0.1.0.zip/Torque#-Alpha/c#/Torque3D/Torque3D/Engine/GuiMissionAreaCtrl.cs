using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiMissionAreaCtrl : GuiBitmapCtrl
	{
		public GuiMissionAreaCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiMissionAreaCtrl_create());
		}

		public GuiMissionAreaCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiMissionAreaCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiMissionAreaCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setMissionArea(IntPtr thisPtr, IntPtr area);
         private static _setMissionArea _setMissionAreaFunc;
         internal static void setMissionArea(IntPtr thisPtr, IntPtr area)
         {
         	if (_setMissionAreaFunc == null)
         	{
         		_setMissionAreaFunc =
         			(_setMissionArea)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMissionAreaCtrl_setMissionArea"), typeof(_setMissionArea));
         	}
         
         	 _setMissionAreaFunc(thisPtr, area);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _updateTerrain(IntPtr thisPtr);
         private static _updateTerrain _updateTerrainFunc;
         internal static void updateTerrain(IntPtr thisPtr)
         {
         	if (_updateTerrainFunc == null)
         	{
         		_updateTerrainFunc =
         			(_updateTerrain)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMissionAreaCtrl_updateTerrain"), typeof(_updateTerrain));
         	}
         
         	 _updateTerrainFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiMissionAreaCtrl_create();
         private static _GuiMissionAreaCtrl_create _GuiMissionAreaCtrl_createFunc;
         internal static IntPtr GuiMissionAreaCtrl_create()
         {
         	if (_GuiMissionAreaCtrl_createFunc == null)
         	{
         		_GuiMissionAreaCtrl_createFunc =
         			(_GuiMissionAreaCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiMissionAreaCtrl_create"), typeof(_GuiMissionAreaCtrl_create));
         	}
         
         	return  _GuiMissionAreaCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void setMissionArea(MissionArea area)
         {
            InternalUnsafeMethods.setMissionArea(ObjectPtr->RefPtr->ObjPtr, area.ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void updateTerrain()
         {
            InternalUnsafeMethods.updateTerrain(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}