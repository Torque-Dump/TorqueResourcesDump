using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GameObjectAsset : AssetBase
	{
		public GameObjectAsset()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GameObjectAsset_create());
		}

		public GameObjectAsset(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GameObjectAsset(SimObject pObj) : base(pObj)
		{
		}

		public GameObjectAsset(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GameObjectAsset_create();
         private static _GameObjectAsset_create _GameObjectAsset_createFunc;
         internal static IntPtr GameObjectAsset_create()
         {
         	if (_GameObjectAsset_createFunc == null)
         	{
         		_GameObjectAsset_createFunc =
         			(_GameObjectAsset_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GameObjectAsset_create"), typeof(_GameObjectAsset_create));
         	}
         
         	return  _GameObjectAsset_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}