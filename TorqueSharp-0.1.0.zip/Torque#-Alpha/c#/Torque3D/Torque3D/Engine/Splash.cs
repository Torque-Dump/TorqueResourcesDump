using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class Splash : GameBase
	{
		public Splash()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.Splash_create());
		}

		public Splash(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public Splash(SimObject pObj) : base(pObj)
		{
		}

		public Splash(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _Splash_create();
         private static _Splash_create _Splash_createFunc;
         internal static IntPtr Splash_create()
         {
         	if (_Splash_createFunc == null)
         	{
         		_Splash_createFunc =
         			(_Splash_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_Splash_create"), typeof(_Splash_create));
         	}
         
         	return  _Splash_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}