using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiGradientCtrl : GuiControl
	{
		public GuiGradientCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiGradientCtrl_create());
		}

		public GuiGradientCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiGradientCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiGradientCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getColorCount(IntPtr thisPtr);
         private static _getColorCount _getColorCountFunc;
         internal static int getColorCount(IntPtr thisPtr)
         {
         	if (_getColorCountFunc == null)
         	{
         		_getColorCountFunc =
         			(_getColorCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiGradientCtrl_getColorCount"), typeof(_getColorCount));
         	}
         
         	return  _getColorCountFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate InternalColorFStruct _getColor(IntPtr thisPtr, int idx);
         private static _getColor _getColorFunc;
         internal static InternalColorFStruct getColor(IntPtr thisPtr, int idx)
         {
         	if (_getColorFunc == null)
         	{
         		_getColorFunc =
         			(_getColor)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiGradientCtrl_getColor"), typeof(_getColor));
         	}
         
         	return  _getColorFunc(thisPtr, idx);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiGradientCtrl_create();
         private static _GuiGradientCtrl_create _GuiGradientCtrl_createFunc;
         internal static IntPtr GuiGradientCtrl_create()
         {
         	if (_GuiGradientCtrl_createFunc == null)
         	{
         		_GuiGradientCtrl_createFunc =
         			(_GuiGradientCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiGradientCtrl_create"), typeof(_GuiGradientCtrl_create));
         	}
         
         	return  _GuiGradientCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public int getColorCount()
         {
            return InternalUnsafeMethods.getColorCount(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public ColorF getColor(int idx)
         {
            return new ColorF(InternalUnsafeMethods.getColor(ObjectPtr->RefPtr->ObjPtr, idx));
         }
      
      
      #endregion

	}
}