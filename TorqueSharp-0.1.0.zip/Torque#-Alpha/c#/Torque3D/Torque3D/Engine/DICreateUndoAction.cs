using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class DICreateUndoAction : UndoAction
	{
		public DICreateUndoAction()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.DICreateUndoAction_create());
		}

		public DICreateUndoAction(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public DICreateUndoAction(SimObject pObj) : base(pObj)
		{
		}

		public DICreateUndoAction(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _DICreateUndoAction_create();
         private static _DICreateUndoAction_create _DICreateUndoAction_createFunc;
         internal static IntPtr DICreateUndoAction_create()
         {
         	if (_DICreateUndoAction_createFunc == null)
         	{
         		_DICreateUndoAction_createFunc =
         			(_DICreateUndoAction_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_DICreateUndoAction_create"), typeof(_DICreateUndoAction_create));
         	}
         
         	return  _DICreateUndoAction_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}