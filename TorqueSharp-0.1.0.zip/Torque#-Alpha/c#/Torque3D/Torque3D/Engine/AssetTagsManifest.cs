using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class AssetTagsManifest : SimObject
	{
		public AssetTagsManifest()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.AssetTagsManifest_create());
		}

		public AssetTagsManifest(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public AssetTagsManifest(SimObject pObj) : base(pObj)
		{
		}

		public AssetTagsManifest(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _createTag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string tagName);
         private static _createTag _createTagFunc;
         internal static void createTag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string tagName)
         {
         	if (_createTagFunc == null)
         	{
         		_createTagFunc =
         			(_createTag)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetTagsManifest_createTag"), typeof(_createTag));
         	}
         
         	 _createTagFunc(thisPtr, tagName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _renameTag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string oldTagName, [MarshalAs(UnmanagedType.LPWStr)]string newTagName);
         private static _renameTag _renameTagFunc;
         internal static bool renameTag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string oldTagName, [MarshalAs(UnmanagedType.LPWStr)]string newTagName)
         {
         	if (_renameTagFunc == null)
         	{
         		_renameTagFunc =
         			(_renameTag)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetTagsManifest_renameTag"), typeof(_renameTag));
         	}
         
         	return  _renameTagFunc(thisPtr, oldTagName, newTagName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _deleteTag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string tagName);
         private static _deleteTag _deleteTagFunc;
         internal static bool deleteTag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string tagName)
         {
         	if (_deleteTagFunc == null)
         	{
         		_deleteTagFunc =
         			(_deleteTag)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetTagsManifest_deleteTag"), typeof(_deleteTag));
         	}
         
         	return  _deleteTagFunc(thisPtr, tagName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _isTag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string tagName);
         private static _isTag _isTagFunc;
         internal static bool isTag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string tagName)
         {
         	if (_isTagFunc == null)
         	{
         		_isTagFunc =
         			(_isTag)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetTagsManifest_isTag"), typeof(_isTag));
         	}
         
         	return  _isTagFunc(thisPtr, tagName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getTagCount(IntPtr thisPtr);
         private static _getTagCount _getTagCountFunc;
         internal static int getTagCount(IntPtr thisPtr)
         {
         	if (_getTagCountFunc == null)
         	{
         		_getTagCountFunc =
         			(_getTagCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetTagsManifest_getTagCount"), typeof(_getTagCount));
         	}
         
         	return  _getTagCountFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getTag(IntPtr thisPtr, int tagIndex);
         private static _getTag _getTagFunc;
         internal static IntPtr getTag(IntPtr thisPtr, int tagIndex)
         {
         	if (_getTagFunc == null)
         	{
         		_getTagFunc =
         			(_getTag)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetTagsManifest_getTag"), typeof(_getTag));
         	}
         
         	return  _getTagFunc(thisPtr, tagIndex);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getAssetTagCount(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string assetId);
         private static _getAssetTagCount _getAssetTagCountFunc;
         internal static int getAssetTagCount(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string assetId)
         {
         	if (_getAssetTagCountFunc == null)
         	{
         		_getAssetTagCountFunc =
         			(_getAssetTagCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetTagsManifest_getAssetTagCount"), typeof(_getAssetTagCount));
         	}
         
         	return  _getAssetTagCountFunc(thisPtr, assetId);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getAssetTag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string assetId, int tagIndex);
         private static _getAssetTag _getAssetTagFunc;
         internal static IntPtr getAssetTag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string assetId, int tagIndex)
         {
         	if (_getAssetTagFunc == null)
         	{
         		_getAssetTagFunc =
         			(_getAssetTag)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetTagsManifest_getAssetTag"), typeof(_getAssetTag));
         	}
         
         	return  _getAssetTagFunc(thisPtr, assetId, tagIndex);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _tag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string assetId, [MarshalAs(UnmanagedType.LPWStr)]string tagName);
         private static _tag _tagFunc;
         internal static bool tag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string assetId, [MarshalAs(UnmanagedType.LPWStr)]string tagName)
         {
         	if (_tagFunc == null)
         	{
         		_tagFunc =
         			(_tag)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetTagsManifest_tag"), typeof(_tag));
         	}
         
         	return  _tagFunc(thisPtr, assetId, tagName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _untag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string assetId, [MarshalAs(UnmanagedType.LPWStr)]string tagName);
         private static _untag _untagFunc;
         internal static bool untag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string assetId, [MarshalAs(UnmanagedType.LPWStr)]string tagName)
         {
         	if (_untagFunc == null)
         	{
         		_untagFunc =
         			(_untag)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetTagsManifest_untag"), typeof(_untag));
         	}
         
         	return  _untagFunc(thisPtr, assetId, tagName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _hasTag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string assetId, [MarshalAs(UnmanagedType.LPWStr)]string tagName);
         private static _hasTag _hasTagFunc;
         internal static bool hasTag(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string assetId, [MarshalAs(UnmanagedType.LPWStr)]string tagName)
         {
         	if (_hasTagFunc == null)
         	{
         		_hasTagFunc =
         			(_hasTag)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetTagsManifest_hasTag"), typeof(_hasTag));
         	}
         
         	return  _hasTagFunc(thisPtr, assetId, tagName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _AssetTagsManifest_create();
         private static _AssetTagsManifest_create _AssetTagsManifest_createFunc;
         internal static IntPtr AssetTagsManifest_create()
         {
         	if (_AssetTagsManifest_createFunc == null)
         	{
         		_AssetTagsManifest_createFunc =
         			(_AssetTagsManifest_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_AssetTagsManifest_create"), typeof(_AssetTagsManifest_create));
         	}
         
         	return  _AssetTagsManifest_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void createTag(string tagName = "")
         {
            InternalUnsafeMethods.createTag(ObjectPtr->RefPtr->ObjPtr, tagName);
         }
      
         public bool renameTag(string oldTagName, string newTagName)
         {
            return InternalUnsafeMethods.renameTag(ObjectPtr->RefPtr->ObjPtr, oldTagName, newTagName);
         }
      
         public bool deleteTag(string tagName)
         {
            return InternalUnsafeMethods.deleteTag(ObjectPtr->RefPtr->ObjPtr, tagName);
         }
      
         public bool isTag(string tagName)
         {
            return InternalUnsafeMethods.isTag(ObjectPtr->RefPtr->ObjPtr, tagName);
         }
      
         public int getTagCount()
         {
            return InternalUnsafeMethods.getTagCount(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public string getTag(int tagIndex)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getTag(ObjectPtr->RefPtr->ObjPtr, tagIndex));
         }
      
         public int getAssetTagCount(string assetId)
         {
            return InternalUnsafeMethods.getAssetTagCount(ObjectPtr->RefPtr->ObjPtr, assetId);
         }
      
         public string getAssetTag(string assetId, int tagIndex)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getAssetTag(ObjectPtr->RefPtr->ObjPtr, assetId, tagIndex));
         }
      
         public bool tag(string assetId, string tagName)
         {
            return InternalUnsafeMethods.tag(ObjectPtr->RefPtr->ObjPtr, assetId, tagName);
         }
      
         public bool untag(string assetId, string tagName)
         {
            return InternalUnsafeMethods.untag(ObjectPtr->RefPtr->ObjPtr, assetId, tagName);
         }
      
         public bool hasTag(string assetId, string tagName)
         {
            return InternalUnsafeMethods.hasTag(ObjectPtr->RefPtr->ObjPtr, assetId, tagName);
         }
      
      
      #endregion

	}
}