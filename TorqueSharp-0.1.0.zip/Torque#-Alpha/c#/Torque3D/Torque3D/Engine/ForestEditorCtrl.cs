using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ForestEditorCtrl : EditTSCtrl
	{
		public ForestEditorCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ForestEditorCtrl_create());
		}

		public ForestEditorCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ForestEditorCtrl(SimObject pObj) : base(pObj)
		{
		}

		public ForestEditorCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _updateActiveForest(IntPtr thisPtr);
         private static _updateActiveForest _updateActiveForestFunc;
         internal static void updateActiveForest(IntPtr thisPtr)
         {
         	if (_updateActiveForestFunc == null)
         	{
         		_updateActiveForestFunc =
         			(_updateActiveForest)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnForestEditorCtrl_updateActiveForest"), typeof(_updateActiveForest));
         	}
         
         	 _updateActiveForestFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setActiveTool(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string toolName);
         private static _setActiveTool _setActiveToolFunc;
         internal static void setActiveTool(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string toolName)
         {
         	if (_setActiveToolFunc == null)
         	{
         		_setActiveToolFunc =
         			(_setActiveTool)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnForestEditorCtrl_setActiveTool"), typeof(_setActiveTool));
         	}
         
         	 _setActiveToolFunc(thisPtr, toolName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getActiveTool(IntPtr thisPtr);
         private static _getActiveTool _getActiveToolFunc;
         internal static int getActiveTool(IntPtr thisPtr)
         {
         	if (_getActiveToolFunc == null)
         	{
         		_getActiveToolFunc =
         			(_getActiveTool)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnForestEditorCtrl_getActiveTool"), typeof(_getActiveTool));
         	}
         
         	return  _getActiveToolFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _deleteMeshSafe(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string obj);
         private static _deleteMeshSafe _deleteMeshSafeFunc;
         internal static void deleteMeshSafe(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string obj)
         {
         	if (_deleteMeshSafeFunc == null)
         	{
         		_deleteMeshSafeFunc =
         			(_deleteMeshSafe)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnForestEditorCtrl_deleteMeshSafe"), typeof(_deleteMeshSafe));
         	}
         
         	 _deleteMeshSafeFunc(thisPtr, obj);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _isDirty(IntPtr thisPtr);
         private static _isDirty _isDirtyFunc;
         internal static bool isDirty(IntPtr thisPtr)
         {
         	if (_isDirtyFunc == null)
         	{
         		_isDirtyFunc =
         			(_isDirty)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnForestEditorCtrl_isDirty"), typeof(_isDirty));
         	}
         
         	return  _isDirtyFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setActiveForest(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string obj);
         private static _setActiveForest _setActiveForestFunc;
         internal static void setActiveForest(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string obj)
         {
         	if (_setActiveForestFunc == null)
         	{
         		_setActiveForestFunc =
         			(_setActiveForest)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnForestEditorCtrl_setActiveForest"), typeof(_setActiveForest));
         	}
         
         	 _setActiveForestFunc(thisPtr, obj);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ForestEditorCtrl_create();
         private static _ForestEditorCtrl_create _ForestEditorCtrl_createFunc;
         internal static IntPtr ForestEditorCtrl_create()
         {
         	if (_ForestEditorCtrl_createFunc == null)
         	{
         		_ForestEditorCtrl_createFunc =
         			(_ForestEditorCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ForestEditorCtrl_create"), typeof(_ForestEditorCtrl_create));
         	}
         
         	return  _ForestEditorCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void updateActiveForest()
         {
            InternalUnsafeMethods.updateActiveForest(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setActiveTool(string toolName)
         {
            InternalUnsafeMethods.setActiveTool(ObjectPtr->RefPtr->ObjPtr, toolName);
         }
      
         public int getActiveTool()
         {
            return InternalUnsafeMethods.getActiveTool(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void deleteMeshSafe(string obj)
         {
            InternalUnsafeMethods.deleteMeshSafe(ObjectPtr->RefPtr->ObjPtr, obj);
         }
      
         public bool isDirty()
         {
            return InternalUnsafeMethods.isDirty(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setActiveForest(string obj)
         {
            InternalUnsafeMethods.setActiveForest(ObjectPtr->RefPtr->ObjPtr, obj);
         }
      
      
      #endregion

	}
}