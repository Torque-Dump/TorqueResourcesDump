using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ScriptTickObject : ScriptObject
	{
		public ScriptTickObject()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ScriptTickObject_create());
		}

		public ScriptTickObject(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ScriptTickObject(SimObject pObj) : base(pObj)
		{
		}

		public ScriptTickObject(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setProcessTicks(IntPtr thisPtr, bool tick);
         private static _setProcessTicks _setProcessTicksFunc;
         internal static void setProcessTicks(IntPtr thisPtr, bool tick)
         {
         	if (_setProcessTicksFunc == null)
         	{
         		_setProcessTicksFunc =
         			(_setProcessTicks)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnScriptTickObject_setProcessTicks"), typeof(_setProcessTicks));
         	}
         
         	 _setProcessTicksFunc(thisPtr, tick);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _isProcessingTicks(IntPtr thisPtr);
         private static _isProcessingTicks _isProcessingTicksFunc;
         internal static bool isProcessingTicks(IntPtr thisPtr)
         {
         	if (_isProcessingTicksFunc == null)
         	{
         		_isProcessingTicksFunc =
         			(_isProcessingTicks)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnScriptTickObject_isProcessingTicks"), typeof(_isProcessingTicks));
         	}
         
         	return  _isProcessingTicksFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ScriptTickObject_create();
         private static _ScriptTickObject_create _ScriptTickObject_createFunc;
         internal static IntPtr ScriptTickObject_create()
         {
         	if (_ScriptTickObject_createFunc == null)
         	{
         		_ScriptTickObject_createFunc =
         			(_ScriptTickObject_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ScriptTickObject_create"), typeof(_ScriptTickObject_create));
         	}
         
         	return  _ScriptTickObject_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void setProcessTicks(bool tick)
         {
            InternalUnsafeMethods.setProcessTicks(ObjectPtr->RefPtr->ObjPtr, tick);
         }
      
         public bool isProcessingTicks()
         {
            return InternalUnsafeMethods.isProcessingTicks(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}