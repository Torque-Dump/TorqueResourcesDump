using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiIconButtonCtrl : GuiButtonCtrl
	{
		public GuiIconButtonCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiIconButtonCtrl_create());
		}

		public GuiIconButtonCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiIconButtonCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiIconButtonCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setBitmap(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string buttonFilename);
         private static _setBitmap _setBitmapFunc;
         internal static void setBitmap(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string buttonFilename)
         {
         	if (_setBitmapFunc == null)
         	{
         		_setBitmapFunc =
         			(_setBitmap)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiIconButtonCtrl_setBitmap"), typeof(_setBitmap));
         	}
         
         	 _setBitmapFunc(thisPtr, buttonFilename);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiIconButtonCtrl_create();
         private static _GuiIconButtonCtrl_create _GuiIconButtonCtrl_createFunc;
         internal static IntPtr GuiIconButtonCtrl_create()
         {
         	if (_GuiIconButtonCtrl_createFunc == null)
         	{
         		_GuiIconButtonCtrl_createFunc =
         			(_GuiIconButtonCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiIconButtonCtrl_create"), typeof(_GuiIconButtonCtrl_create));
         	}
         
         	return  _GuiIconButtonCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void setBitmap(string buttonFilename)
         {
            InternalUnsafeMethods.setBitmap(ObjectPtr->RefPtr->ObjPtr, buttonFilename);
         }
      
      
      #endregion

	}
}