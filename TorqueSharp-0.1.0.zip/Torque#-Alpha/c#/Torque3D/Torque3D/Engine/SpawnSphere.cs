using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class SpawnSphere : MissionMarker
	{
		public SpawnSphere()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.SpawnSphere_create());
		}

		public SpawnSphere(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public SpawnSphere(SimObject pObj) : base(pObj)
		{
		}

		public SpawnSphere(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _spawnObject(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string additionalProps);
         private static _spawnObject _spawnObjectFunc;
         internal static int spawnObject(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string additionalProps)
         {
         	if (_spawnObjectFunc == null)
         	{
         		_spawnObjectFunc =
         			(_spawnObject)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnSpawnSphere_spawnObject"), typeof(_spawnObject));
         	}
         
         	return  _spawnObjectFunc(thisPtr, additionalProps);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _SpawnSphere_create();
         private static _SpawnSphere_create _SpawnSphere_createFunc;
         internal static IntPtr SpawnSphere_create()
         {
         	if (_SpawnSphere_createFunc == null)
         	{
         		_SpawnSphere_createFunc =
         			(_SpawnSphere_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_SpawnSphere_create"), typeof(_SpawnSphere_create));
         	}
         
         	return  _SpawnSphere_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public int spawnObject(string additionalProps)
         {
            return InternalUnsafeMethods.spawnObject(ObjectPtr->RefPtr->ObjPtr, additionalProps);
         }
      
      
      #endregion

	}
}