using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiSeparatorCtrl : GuiControl
	{
		public GuiSeparatorCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiSeparatorCtrl_create());
		}

		public GuiSeparatorCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiSeparatorCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiSeparatorCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiSeparatorCtrl_create();
         private static _GuiSeparatorCtrl_create _GuiSeparatorCtrl_createFunc;
         internal static IntPtr GuiSeparatorCtrl_create()
         {
         	if (_GuiSeparatorCtrl_createFunc == null)
         	{
         		_GuiSeparatorCtrl_createFunc =
         			(_GuiSeparatorCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiSeparatorCtrl_create"), typeof(_GuiSeparatorCtrl_create));
         	}
         
         	return  _GuiSeparatorCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}