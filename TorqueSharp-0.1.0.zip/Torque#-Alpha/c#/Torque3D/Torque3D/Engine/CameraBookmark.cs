using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class CameraBookmark : MissionMarker
	{
		public CameraBookmark()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.CameraBookmark_create());
		}

		public CameraBookmark(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public CameraBookmark(SimObject pObj) : base(pObj)
		{
		}

		public CameraBookmark(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _CameraBookmark_create();
         private static _CameraBookmark_create _CameraBookmark_createFunc;
         internal static IntPtr CameraBookmark_create()
         {
         	if (_CameraBookmark_createFunc == null)
         	{
         		_CameraBookmark_createFunc =
         			(_CameraBookmark_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_CameraBookmark_create"), typeof(_CameraBookmark_create));
         	}
         
         	return  _CameraBookmark_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}