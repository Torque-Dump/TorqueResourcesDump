using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class SkyBox : SceneObject
	{
		public SkyBox()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.SkyBox_create());
		}

		public SkyBox(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public SkyBox(SimObject pObj) : base(pObj)
		{
		}

		public SkyBox(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _postApply(IntPtr thisPtr);
         private static _postApply _postApplyFunc;
         internal static void postApply(IntPtr thisPtr)
         {
         	if (_postApplyFunc == null)
         	{
         		_postApplyFunc =
         			(_postApply)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnSkyBox_postApply"), typeof(_postApply));
         	}
         
         	 _postApplyFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _SkyBox_create();
         private static _SkyBox_create _SkyBox_createFunc;
         internal static IntPtr SkyBox_create()
         {
         	if (_SkyBox_createFunc == null)
         	{
         		_SkyBox_createFunc =
         			(_SkyBox_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_SkyBox_create"), typeof(_SkyBox_create));
         	}
         
         	return  _SkyBox_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void postApply()
         {
            InternalUnsafeMethods.postApply(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}