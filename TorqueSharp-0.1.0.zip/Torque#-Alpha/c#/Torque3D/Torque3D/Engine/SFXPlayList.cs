using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class SFXPlayList : SFXTrack
	{
		public SFXPlayList()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.SFXPlayList_create());
		}

		public SFXPlayList(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public SFXPlayList(SimObject pObj) : base(pObj)
		{
		}

		public SFXPlayList(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _SFXPlayList_create();
         private static _SFXPlayList_create _SFXPlayList_createFunc;
         internal static IntPtr SFXPlayList_create()
         {
         	if (_SFXPlayList_createFunc == null)
         	{
         		_SFXPlayList_createFunc =
         			(_SFXPlayList_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_SFXPlayList_create"), typeof(_SFXPlayList_create));
         	}
         
         	return  _SFXPlayList_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}