using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class PlayerData : ShapeBaseData
	{
		public PlayerData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.PlayerData_create());
		}

		public PlayerData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public PlayerData(SimObject pObj) : base(pObj)
		{
		}

		public PlayerData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _PlayerData_create();
         private static _PlayerData_create _PlayerData_createFunc;
         internal static IntPtr PlayerData_create()
         {
         	if (_PlayerData_createFunc == null)
         	{
         		_PlayerData_createFunc =
         			(_PlayerData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_PlayerData_create"), typeof(_PlayerData_create));
         	}
         
         	return  _PlayerData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}