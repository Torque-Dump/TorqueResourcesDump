using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiHealthBarHud : GuiControl
	{
		public GuiHealthBarHud()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiHealthBarHud_create());
		}

		public GuiHealthBarHud(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiHealthBarHud(SimObject pObj) : base(pObj)
		{
		}

		public GuiHealthBarHud(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiHealthBarHud_create();
         private static _GuiHealthBarHud_create _GuiHealthBarHud_createFunc;
         internal static IntPtr GuiHealthBarHud_create()
         {
         	if (_GuiHealthBarHud_createFunc == null)
         	{
         		_GuiHealthBarHud_createFunc =
         			(_GuiHealthBarHud_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiHealthBarHud_create"), typeof(_GuiHealthBarHud_create));
         	}
         
         	return  _GuiHealthBarHud_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}