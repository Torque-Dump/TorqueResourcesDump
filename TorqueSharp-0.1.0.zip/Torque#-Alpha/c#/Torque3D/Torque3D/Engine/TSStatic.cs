using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class TSStatic : SceneObject
	{
		public TSStatic()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.TSStatic_create());
		}

		public TSStatic(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public TSStatic(SimObject pObj) : base(pObj)
		{
		}

		public TSStatic(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getTargetName(IntPtr thisPtr, int index);
         private static _getTargetName _getTargetNameFunc;
         internal static IntPtr getTargetName(IntPtr thisPtr, int index)
         {
         	if (_getTargetNameFunc == null)
         	{
         		_getTargetNameFunc =
         			(_getTargetName)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSStatic_getTargetName"), typeof(_getTargetName));
         	}
         
         	return  _getTargetNameFunc(thisPtr, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getTargetCount(IntPtr thisPtr);
         private static _getTargetCount _getTargetCountFunc;
         internal static int getTargetCount(IntPtr thisPtr)
         {
         	if (_getTargetCountFunc == null)
         	{
         		_getTargetCountFunc =
         			(_getTargetCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSStatic_getTargetCount"), typeof(_getTargetCount));
         	}
         
         	return  _getTargetCountFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _changeMaterial(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string mapTo, IntPtr oldMat, IntPtr newMat);
         private static _changeMaterial _changeMaterialFunc;
         internal static void changeMaterial(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string mapTo, IntPtr oldMat, IntPtr newMat)
         {
         	if (_changeMaterialFunc == null)
         	{
         		_changeMaterialFunc =
         			(_changeMaterial)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSStatic_changeMaterial"), typeof(_changeMaterial));
         	}
         
         	 _changeMaterialFunc(thisPtr, mapTo, oldMat, newMat);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getModelFile(IntPtr thisPtr);
         private static _getModelFile _getModelFileFunc;
         internal static IntPtr getModelFile(IntPtr thisPtr)
         {
         	if (_getModelFileFunc == null)
         	{
         		_getModelFileFunc =
         			(_getModelFile)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTSStatic_getModelFile"), typeof(_getModelFile));
         	}
         
         	return  _getModelFileFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _TSStatic_create();
         private static _TSStatic_create _TSStatic_createFunc;
         internal static IntPtr TSStatic_create()
         {
         	if (_TSStatic_createFunc == null)
         	{
         		_TSStatic_createFunc =
         			(_TSStatic_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_TSStatic_create"), typeof(_TSStatic_create));
         	}
         
         	return  _TSStatic_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public string getTargetName(int index = 0)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getTargetName(ObjectPtr->RefPtr->ObjPtr, index));
         }
      
         public int getTargetCount()
         {
            return InternalUnsafeMethods.getTargetCount(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void changeMaterial(string mapTo = "", Material oldMat = null, Material newMat = null)
         {
            InternalUnsafeMethods.changeMaterial(ObjectPtr->RefPtr->ObjPtr, mapTo, oldMat.ObjectPtr->RefPtr->ObjPtr, newMat.ObjectPtr->RefPtr->ObjPtr);
         }
      
         public string getModelFile()
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getModelFile(ObjectPtr->RefPtr->ObjPtr));
         }
      
      
      #endregion

	}
}