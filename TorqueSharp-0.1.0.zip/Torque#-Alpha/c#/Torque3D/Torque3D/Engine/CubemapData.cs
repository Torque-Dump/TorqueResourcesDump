using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class CubemapData : SimObject
	{
		public CubemapData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.CubemapData_create());
		}

		public CubemapData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public CubemapData(SimObject pObj) : base(pObj)
		{
		}

		public CubemapData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _updateFaces(IntPtr thisPtr);
         private static _updateFaces _updateFacesFunc;
         internal static void updateFaces(IntPtr thisPtr)
         {
         	if (_updateFacesFunc == null)
         	{
         		_updateFacesFunc =
         			(_updateFaces)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCubemapData_updateFaces"), typeof(_updateFaces));
         	}
         
         	 _updateFacesFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getFilename(IntPtr thisPtr);
         private static _getFilename _getFilenameFunc;
         internal static IntPtr getFilename(IntPtr thisPtr)
         {
         	if (_getFilenameFunc == null)
         	{
         		_getFilenameFunc =
         			(_getFilename)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCubemapData_getFilename"), typeof(_getFilename));
         	}
         
         	return  _getFilenameFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _CubemapData_create();
         private static _CubemapData_create _CubemapData_createFunc;
         internal static IntPtr CubemapData_create()
         {
         	if (_CubemapData_createFunc == null)
         	{
         		_CubemapData_createFunc =
         			(_CubemapData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_CubemapData_create"), typeof(_CubemapData_create));
         	}
         
         	return  _CubemapData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void updateFaces()
         {
            InternalUnsafeMethods.updateFaces(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public string getFilename()
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getFilename(ObjectPtr->RefPtr->ObjPtr));
         }
      
      
      #endregion

	}
}