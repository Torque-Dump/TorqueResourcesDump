using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class Gizmo : SimObject
	{
		public Gizmo()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.Gizmo_create());
		}

		public Gizmo(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public Gizmo(SimObject pObj) : base(pObj)
		{
		}

		public Gizmo(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _Gizmo_create();
         private static _Gizmo_create _Gizmo_createFunc;
         internal static IntPtr Gizmo_create()
         {
         	if (_Gizmo_createFunc == null)
         	{
         		_Gizmo_createFunc =
         			(_Gizmo_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_Gizmo_create"), typeof(_Gizmo_create));
         	}
         
         	return  _Gizmo_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}