using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ReflectorDesc : SimDataBlock
	{
		public ReflectorDesc()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ReflectorDesc_create());
		}

		public ReflectorDesc(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ReflectorDesc(SimObject pObj) : base(pObj)
		{
		}

		public ReflectorDesc(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ReflectorDesc_create();
         private static _ReflectorDesc_create _ReflectorDesc_createFunc;
         internal static IntPtr ReflectorDesc_create()
         {
         	if (_ReflectorDesc_createFunc == null)
         	{
         		_ReflectorDesc_createFunc =
         			(_ReflectorDesc_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ReflectorDesc_create"), typeof(_ReflectorDesc_create));
         	}
         
         	return  _ReflectorDesc_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}