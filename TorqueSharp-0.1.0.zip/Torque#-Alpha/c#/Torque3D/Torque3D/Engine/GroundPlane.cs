using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GroundPlane : SceneObject
	{
		public GroundPlane()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GroundPlane_create());
		}

		public GroundPlane(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GroundPlane(SimObject pObj) : base(pObj)
		{
		}

		public GroundPlane(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _postApply(IntPtr thisPtr);
         private static _postApply _postApplyFunc;
         internal static void postApply(IntPtr thisPtr)
         {
         	if (_postApplyFunc == null)
         	{
         		_postApplyFunc =
         			(_postApply)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGroundPlane_postApply"), typeof(_postApply));
         	}
         
         	 _postApplyFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GroundPlane_create();
         private static _GroundPlane_create _GroundPlane_createFunc;
         internal static IntPtr GroundPlane_create()
         {
         	if (_GroundPlane_createFunc == null)
         	{
         		_GroundPlane_createFunc =
         			(_GroundPlane_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GroundPlane_create"), typeof(_GroundPlane_create));
         	}
         
         	return  _GroundPlane_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void postApply()
         {
            InternalUnsafeMethods.postApply(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}