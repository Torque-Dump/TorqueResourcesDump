using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiPaneControl : GuiControl
	{
		public GuiPaneControl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiPaneControl_create());
		}

		public GuiPaneControl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiPaneControl(SimObject pObj) : base(pObj)
		{
		}

		public GuiPaneControl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setCollapsed(IntPtr thisPtr, bool collapse);
         private static _setCollapsed _setCollapsedFunc;
         internal static void setCollapsed(IntPtr thisPtr, bool collapse)
         {
         	if (_setCollapsedFunc == null)
         	{
         		_setCollapsedFunc =
         			(_setCollapsed)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiPaneControl_setCollapsed"), typeof(_setCollapsed));
         	}
         
         	 _setCollapsedFunc(thisPtr, collapse);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiPaneControl_create();
         private static _GuiPaneControl_create _GuiPaneControl_createFunc;
         internal static IntPtr GuiPaneControl_create()
         {
         	if (_GuiPaneControl_createFunc == null)
         	{
         		_GuiPaneControl_createFunc =
         			(_GuiPaneControl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiPaneControl_create"), typeof(_GuiPaneControl_create));
         	}
         
         	return  _GuiPaneControl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void setCollapsed(bool collapse)
         {
            InternalUnsafeMethods.setCollapsed(ObjectPtr->RefPtr->ObjPtr, collapse);
         }
      
      
      #endregion

	}
}