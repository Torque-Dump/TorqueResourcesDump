using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ForestBrush : SimGroup
	{
		public ForestBrush()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ForestBrush_create());
		}

		public ForestBrush(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ForestBrush(SimObject pObj) : base(pObj)
		{
		}

		public ForestBrush(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _containsItemData(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string obj);
         private static _containsItemData _containsItemDataFunc;
         internal static bool containsItemData(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string obj)
         {
         	if (_containsItemDataFunc == null)
         	{
         		_containsItemDataFunc =
         			(_containsItemData)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnForestBrush_containsItemData"), typeof(_containsItemData));
         	}
         
         	return  _containsItemDataFunc(thisPtr, obj);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ForestBrush_create();
         private static _ForestBrush_create _ForestBrush_createFunc;
         internal static IntPtr ForestBrush_create()
         {
         	if (_ForestBrush_createFunc == null)
         	{
         		_ForestBrush_createFunc =
         			(_ForestBrush_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ForestBrush_create"), typeof(_ForestBrush_create));
         	}
         
         	return  _ForestBrush_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public bool containsItemData(string obj)
         {
            return InternalUnsafeMethods.containsItemData(ObjectPtr->RefPtr->ObjPtr, obj);
         }
      
      
      #endregion

	}
}