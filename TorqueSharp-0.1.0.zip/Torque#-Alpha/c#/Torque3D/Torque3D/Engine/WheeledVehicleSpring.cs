using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class WheeledVehicleSpring : SimDataBlock
	{
		public WheeledVehicleSpring()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.WheeledVehicleSpring_create());
		}

		public WheeledVehicleSpring(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public WheeledVehicleSpring(SimObject pObj) : base(pObj)
		{
		}

		public WheeledVehicleSpring(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _WheeledVehicleSpring_create();
         private static _WheeledVehicleSpring_create _WheeledVehicleSpring_createFunc;
         internal static IntPtr WheeledVehicleSpring_create()
         {
         	if (_WheeledVehicleSpring_createFunc == null)
         	{
         		_WheeledVehicleSpring_createFunc =
         			(_WheeledVehicleSpring_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_WheeledVehicleSpring_create"), typeof(_WheeledVehicleSpring_create));
         	}
         
         	return  _WheeledVehicleSpring_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}