using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class TimeOfDay : SceneObject
	{
		public TimeOfDay()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.TimeOfDay_create());
		}

		public TimeOfDay(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public TimeOfDay(SimObject pObj) : base(pObj)
		{
		}

		public TimeOfDay(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _addTimeOfDayEvent(IntPtr thisPtr, float elevation, [MarshalAs(UnmanagedType.LPWStr)]string identifier);
         private static _addTimeOfDayEvent _addTimeOfDayEventFunc;
         internal static void addTimeOfDayEvent(IntPtr thisPtr, float elevation, [MarshalAs(UnmanagedType.LPWStr)]string identifier)
         {
         	if (_addTimeOfDayEventFunc == null)
         	{
         		_addTimeOfDayEventFunc =
         			(_addTimeOfDayEvent)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTimeOfDay_addTimeOfDayEvent"), typeof(_addTimeOfDayEvent));
         	}
         
         	 _addTimeOfDayEventFunc(thisPtr, elevation, identifier);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setTimeOfDay(IntPtr thisPtr, float time);
         private static _setTimeOfDay _setTimeOfDayFunc;
         internal static void setTimeOfDay(IntPtr thisPtr, float time)
         {
         	if (_setTimeOfDayFunc == null)
         	{
         		_setTimeOfDayFunc =
         			(_setTimeOfDay)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTimeOfDay_setTimeOfDay"), typeof(_setTimeOfDay));
         	}
         
         	 _setTimeOfDayFunc(thisPtr, time);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setPlay(IntPtr thisPtr, bool enabled);
         private static _setPlay _setPlayFunc;
         internal static void setPlay(IntPtr thisPtr, bool enabled)
         {
         	if (_setPlayFunc == null)
         	{
         		_setPlayFunc =
         			(_setPlay)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTimeOfDay_setPlay"), typeof(_setPlay));
         	}
         
         	 _setPlayFunc(thisPtr, enabled);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setDayLength(IntPtr thisPtr, float seconds);
         private static _setDayLength _setDayLengthFunc;
         internal static void setDayLength(IntPtr thisPtr, float seconds)
         {
         	if (_setDayLengthFunc == null)
         	{
         		_setDayLengthFunc =
         			(_setDayLength)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTimeOfDay_setDayLength"), typeof(_setDayLength));
         	}
         
         	 _setDayLengthFunc(thisPtr, seconds);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _animate(IntPtr thisPtr, float elevation, float degreesPerSecond);
         private static _animate _animateFunc;
         internal static void animate(IntPtr thisPtr, float elevation, float degreesPerSecond)
         {
         	if (_animateFunc == null)
         	{
         		_animateFunc =
         			(_animate)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTimeOfDay_animate"), typeof(_animate));
         	}
         
         	 _animateFunc(thisPtr, elevation, degreesPerSecond);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _TimeOfDay_create();
         private static _TimeOfDay_create _TimeOfDay_createFunc;
         internal static IntPtr TimeOfDay_create()
         {
         	if (_TimeOfDay_createFunc == null)
         	{
         		_TimeOfDay_createFunc =
         			(_TimeOfDay_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_TimeOfDay_create"), typeof(_TimeOfDay_create));
         	}
         
         	return  _TimeOfDay_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void addTimeOfDayEvent(float elevation, string identifier)
         {
            InternalUnsafeMethods.addTimeOfDayEvent(ObjectPtr->RefPtr->ObjPtr, elevation, identifier);
         }
      
         public void setTimeOfDay(float time)
         {
            InternalUnsafeMethods.setTimeOfDay(ObjectPtr->RefPtr->ObjPtr, time);
         }
      
         public void setPlay(bool enabled)
         {
            InternalUnsafeMethods.setPlay(ObjectPtr->RefPtr->ObjPtr, enabled);
         }
      
         public void setDayLength(float seconds)
         {
            InternalUnsafeMethods.setDayLength(ObjectPtr->RefPtr->ObjPtr, seconds);
         }
      
         public void animate(float elevation, float degreesPerSecond)
         {
            InternalUnsafeMethods.animate(ObjectPtr->RefPtr->ObjPtr, elevation, degreesPerSecond);
         }
      
      
      #endregion

	}
}