using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class TurretShape : Item
	{
		public TurretShape()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.TurretShape_create());
		}

		public TurretShape(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public TurretShape(SimObject pObj) : base(pObj)
		{
		}

		public TurretShape(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _getAllowManualRotation(IntPtr thisPtr);
         private static _getAllowManualRotation _getAllowManualRotationFunc;
         internal static bool getAllowManualRotation(IntPtr thisPtr)
         {
         	if (_getAllowManualRotationFunc == null)
         	{
         		_getAllowManualRotationFunc =
         			(_getAllowManualRotation)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTurretShape_getAllowManualRotation"), typeof(_getAllowManualRotation));
         	}
         
         	return  _getAllowManualRotationFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setAllowManualRotation(IntPtr thisPtr, bool allow);
         private static _setAllowManualRotation _setAllowManualRotationFunc;
         internal static void setAllowManualRotation(IntPtr thisPtr, bool allow)
         {
         	if (_setAllowManualRotationFunc == null)
         	{
         		_setAllowManualRotationFunc =
         			(_setAllowManualRotation)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTurretShape_setAllowManualRotation"), typeof(_setAllowManualRotation));
         	}
         
         	 _setAllowManualRotationFunc(thisPtr, allow);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _getAllowManualFire(IntPtr thisPtr);
         private static _getAllowManualFire _getAllowManualFireFunc;
         internal static bool getAllowManualFire(IntPtr thisPtr)
         {
         	if (_getAllowManualFireFunc == null)
         	{
         		_getAllowManualFireFunc =
         			(_getAllowManualFire)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTurretShape_getAllowManualFire"), typeof(_getAllowManualFire));
         	}
         
         	return  _getAllowManualFireFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setAllowManualFire(IntPtr thisPtr, bool allow);
         private static _setAllowManualFire _setAllowManualFireFunc;
         internal static void setAllowManualFire(IntPtr thisPtr, bool allow)
         {
         	if (_setAllowManualFireFunc == null)
         	{
         		_setAllowManualFireFunc =
         			(_setAllowManualFire)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTurretShape_setAllowManualFire"), typeof(_setAllowManualFire));
         	}
         
         	 _setAllowManualFireFunc(thisPtr, allow);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getState(IntPtr thisPtr);
         private static _getState _getStateFunc;
         internal static IntPtr getState(IntPtr thisPtr)
         {
         	if (_getStateFunc == null)
         	{
         		_getStateFunc =
         			(_getState)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTurretShape_getState"), typeof(_getState));
         	}
         
         	return  _getStateFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float[] _getTurretEulerRotation(IntPtr thisPtr);
         private static _getTurretEulerRotation _getTurretEulerRotationFunc;
         internal static float[] getTurretEulerRotation(IntPtr thisPtr)
         {
         	if (_getTurretEulerRotationFunc == null)
         	{
         		_getTurretEulerRotationFunc =
         			(_getTurretEulerRotation)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTurretShape_getTurretEulerRotation"), typeof(_getTurretEulerRotation));
         	}
         
         	return  _getTurretEulerRotationFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setTurretEulerRotation(IntPtr thisPtr, float[] rot);
         private static _setTurretEulerRotation _setTurretEulerRotationFunc;
         internal static void setTurretEulerRotation(IntPtr thisPtr, float[] rot)
         {
         	if (_setTurretEulerRotationFunc == null)
         	{
         		_setTurretEulerRotationFunc =
         			(_setTurretEulerRotation)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTurretShape_setTurretEulerRotation"), typeof(_setTurretEulerRotation));
         	}
         
         	 _setTurretEulerRotationFunc(thisPtr, rot);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _doRespawn(IntPtr thisPtr);
         private static _doRespawn _doRespawnFunc;
         internal static bool doRespawn(IntPtr thisPtr)
         {
         	if (_doRespawnFunc == null)
         	{
         		_doRespawnFunc =
         			(_doRespawn)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTurretShape_doRespawn"), typeof(_doRespawn));
         	}
         
         	return  _doRespawnFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _TurretShape_create();
         private static _TurretShape_create _TurretShape_createFunc;
         internal static IntPtr TurretShape_create()
         {
         	if (_TurretShape_createFunc == null)
         	{
         		_TurretShape_createFunc =
         			(_TurretShape_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_TurretShape_create"), typeof(_TurretShape_create));
         	}
         
         	return  _TurretShape_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public bool getAllowManualRotation()
         {
            return InternalUnsafeMethods.getAllowManualRotation(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setAllowManualRotation(bool allow)
         {
            InternalUnsafeMethods.setAllowManualRotation(ObjectPtr->RefPtr->ObjPtr, allow);
         }
      
         public bool getAllowManualFire()
         {
            return InternalUnsafeMethods.getAllowManualFire(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setAllowManualFire(bool allow)
         {
            InternalUnsafeMethods.setAllowManualFire(ObjectPtr->RefPtr->ObjPtr, allow);
         }
      
         public string getState()
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getState(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public Point3F getTurretEulerRotation()
         {
            return new Point3F(InternalUnsafeMethods.getTurretEulerRotation(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public void setTurretEulerRotation(Point3F rot)
         {
            InternalUnsafeMethods.setTurretEulerRotation(ObjectPtr->RefPtr->ObjPtr, rot.ToArray());
         }
      
         public bool doRespawn()
         {
            return InternalUnsafeMethods.doRespawn(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}