using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class Marker : SceneObject
	{
		public Marker()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.Marker_create());
		}

		public Marker(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public Marker(SimObject pObj) : base(pObj)
		{
		}

		public Marker(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _Marker_create();
         private static _Marker_create _Marker_createFunc;
         internal static IntPtr Marker_create()
         {
         	if (_Marker_createFunc == null)
         	{
         		_Marker_createFunc =
         			(_Marker_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_Marker_create"), typeof(_Marker_create));
         	}
         
         	return  _Marker_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}