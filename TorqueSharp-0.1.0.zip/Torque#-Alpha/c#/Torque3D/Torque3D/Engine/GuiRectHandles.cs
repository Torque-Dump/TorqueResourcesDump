using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiRectHandles : GuiControl
	{
		public GuiRectHandles()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiRectHandles_create());
		}

		public GuiRectHandles(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiRectHandles(SimObject pObj) : base(pObj)
		{
		}

		public GuiRectHandles(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiRectHandles_create();
         private static _GuiRectHandles_create _GuiRectHandles_createFunc;
         internal static IntPtr GuiRectHandles_create()
         {
         	if (_GuiRectHandles_createFunc == null)
         	{
         		_GuiRectHandles_createFunc =
         			(_GuiRectHandles_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiRectHandles_create"), typeof(_GuiRectHandles_create));
         	}
         
         	return  _GuiRectHandles_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}