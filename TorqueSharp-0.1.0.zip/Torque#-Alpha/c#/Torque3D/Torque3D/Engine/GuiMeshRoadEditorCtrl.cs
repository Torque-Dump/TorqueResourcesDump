using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiMeshRoadEditorCtrl : EditTSCtrl
	{
		public GuiMeshRoadEditorCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiMeshRoadEditorCtrl_create());
		}

		public GuiMeshRoadEditorCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiMeshRoadEditorCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiMeshRoadEditorCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _deleteNode(IntPtr thisPtr);
         private static _deleteNode _deleteNodeFunc;
         internal static void deleteNode(IntPtr thisPtr)
         {
         	if (_deleteNodeFunc == null)
         	{
         		_deleteNodeFunc =
         			(_deleteNode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMeshRoadEditorCtrl_deleteNode"), typeof(_deleteNode));
         	}
         
         	 _deleteNodeFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getMode(IntPtr thisPtr);
         private static _getMode _getModeFunc;
         internal static IntPtr getMode(IntPtr thisPtr)
         {
         	if (_getModeFunc == null)
         	{
         		_getModeFunc =
         			(_getMode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMeshRoadEditorCtrl_getMode"), typeof(_getMode));
         	}
         
         	return  _getModeFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setMode(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string mode);
         private static _setMode _setModeFunc;
         internal static void setMode(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string mode)
         {
         	if (_setModeFunc == null)
         	{
         		_setModeFunc =
         			(_setMode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMeshRoadEditorCtrl_setMode"), typeof(_setMode));
         	}
         
         	 _setModeFunc(thisPtr, mode);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float _getNodeWidth(IntPtr thisPtr);
         private static _getNodeWidth _getNodeWidthFunc;
         internal static float getNodeWidth(IntPtr thisPtr)
         {
         	if (_getNodeWidthFunc == null)
         	{
         		_getNodeWidthFunc =
         			(_getNodeWidth)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMeshRoadEditorCtrl_getNodeWidth"), typeof(_getNodeWidth));
         	}
         
         	return  _getNodeWidthFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setNodeWidth(IntPtr thisPtr, float width);
         private static _setNodeWidth _setNodeWidthFunc;
         internal static void setNodeWidth(IntPtr thisPtr, float width)
         {
         	if (_setNodeWidthFunc == null)
         	{
         		_setNodeWidthFunc =
         			(_setNodeWidth)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMeshRoadEditorCtrl_setNodeWidth"), typeof(_setNodeWidth));
         	}
         
         	 _setNodeWidthFunc(thisPtr, width);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float _getNodeDepth(IntPtr thisPtr);
         private static _getNodeDepth _getNodeDepthFunc;
         internal static float getNodeDepth(IntPtr thisPtr)
         {
         	if (_getNodeDepthFunc == null)
         	{
         		_getNodeDepthFunc =
         			(_getNodeDepth)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMeshRoadEditorCtrl_getNodeDepth"), typeof(_getNodeDepth));
         	}
         
         	return  _getNodeDepthFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setNodeDepth(IntPtr thisPtr, float depth);
         private static _setNodeDepth _setNodeDepthFunc;
         internal static void setNodeDepth(IntPtr thisPtr, float depth)
         {
         	if (_setNodeDepthFunc == null)
         	{
         		_setNodeDepthFunc =
         			(_setNodeDepth)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMeshRoadEditorCtrl_setNodeDepth"), typeof(_setNodeDepth));
         	}
         
         	 _setNodeDepthFunc(thisPtr, depth);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float[] _getNodePosition(IntPtr thisPtr);
         private static _getNodePosition _getNodePositionFunc;
         internal static float[] getNodePosition(IntPtr thisPtr)
         {
         	if (_getNodePositionFunc == null)
         	{
         		_getNodePositionFunc =
         			(_getNodePosition)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMeshRoadEditorCtrl_getNodePosition"), typeof(_getNodePosition));
         	}
         
         	return  _getNodePositionFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setNodePosition(IntPtr thisPtr, float[] pos);
         private static _setNodePosition _setNodePositionFunc;
         internal static void setNodePosition(IntPtr thisPtr, float[] pos)
         {
         	if (_setNodePositionFunc == null)
         	{
         		_setNodePositionFunc =
         			(_setNodePosition)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMeshRoadEditorCtrl_setNodePosition"), typeof(_setNodePosition));
         	}
         
         	 _setNodePositionFunc(thisPtr, pos);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float[] _getNodeNormal(IntPtr thisPtr);
         private static _getNodeNormal _getNodeNormalFunc;
         internal static float[] getNodeNormal(IntPtr thisPtr)
         {
         	if (_getNodeNormalFunc == null)
         	{
         		_getNodeNormalFunc =
         			(_getNodeNormal)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMeshRoadEditorCtrl_getNodeNormal"), typeof(_getNodeNormal));
         	}
         
         	return  _getNodeNormalFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setNodeNormal(IntPtr thisPtr, float[] normal);
         private static _setNodeNormal _setNodeNormalFunc;
         internal static void setNodeNormal(IntPtr thisPtr, float[] normal)
         {
         	if (_setNodeNormalFunc == null)
         	{
         		_setNodeNormalFunc =
         			(_setNodeNormal)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMeshRoadEditorCtrl_setNodeNormal"), typeof(_setNodeNormal));
         	}
         
         	 _setNodeNormalFunc(thisPtr, normal);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setSelectedRoad(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string objName);
         private static _setSelectedRoad _setSelectedRoadFunc;
         internal static void setSelectedRoad(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string objName)
         {
         	if (_setSelectedRoadFunc == null)
         	{
         		_setSelectedRoadFunc =
         			(_setSelectedRoad)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMeshRoadEditorCtrl_setSelectedRoad"), typeof(_setSelectedRoad));
         	}
         
         	 _setSelectedRoadFunc(thisPtr, objName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getSelectedRoad(IntPtr thisPtr);
         private static _getSelectedRoad _getSelectedRoadFunc;
         internal static int getSelectedRoad(IntPtr thisPtr)
         {
         	if (_getSelectedRoadFunc == null)
         	{
         		_getSelectedRoadFunc =
         			(_getSelectedRoad)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMeshRoadEditorCtrl_getSelectedRoad"), typeof(_getSelectedRoad));
         	}
         
         	return  _getSelectedRoadFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _regenerate(IntPtr thisPtr);
         private static _regenerate _regenerateFunc;
         internal static void regenerate(IntPtr thisPtr)
         {
         	if (_regenerateFunc == null)
         	{
         		_regenerateFunc =
         			(_regenerate)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMeshRoadEditorCtrl_regenerate"), typeof(_regenerate));
         	}
         
         	 _regenerateFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _matchTerrainToRoad(IntPtr thisPtr);
         private static _matchTerrainToRoad _matchTerrainToRoadFunc;
         internal static void matchTerrainToRoad(IntPtr thisPtr)
         {
         	if (_matchTerrainToRoadFunc == null)
         	{
         		_matchTerrainToRoadFunc =
         			(_matchTerrainToRoad)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMeshRoadEditorCtrl_matchTerrainToRoad"), typeof(_matchTerrainToRoad));
         	}
         
         	 _matchTerrainToRoadFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiMeshRoadEditorCtrl_create();
         private static _GuiMeshRoadEditorCtrl_create _GuiMeshRoadEditorCtrl_createFunc;
         internal static IntPtr GuiMeshRoadEditorCtrl_create()
         {
         	if (_GuiMeshRoadEditorCtrl_createFunc == null)
         	{
         		_GuiMeshRoadEditorCtrl_createFunc =
         			(_GuiMeshRoadEditorCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiMeshRoadEditorCtrl_create"), typeof(_GuiMeshRoadEditorCtrl_create));
         	}
         
         	return  _GuiMeshRoadEditorCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void deleteNode()
         {
            InternalUnsafeMethods.deleteNode(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public string getMode()
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getMode(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public void setMode(string mode)
         {
            InternalUnsafeMethods.setMode(ObjectPtr->RefPtr->ObjPtr, mode);
         }
      
         public float getNodeWidth()
         {
            return InternalUnsafeMethods.getNodeWidth(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setNodeWidth(float width)
         {
            InternalUnsafeMethods.setNodeWidth(ObjectPtr->RefPtr->ObjPtr, width);
         }
      
         public float getNodeDepth()
         {
            return InternalUnsafeMethods.getNodeDepth(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setNodeDepth(float depth)
         {
            InternalUnsafeMethods.setNodeDepth(ObjectPtr->RefPtr->ObjPtr, depth);
         }
      
         public Point3F getNodePosition()
         {
            return new Point3F(InternalUnsafeMethods.getNodePosition(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public void setNodePosition(Point3F pos)
         {
            InternalUnsafeMethods.setNodePosition(ObjectPtr->RefPtr->ObjPtr, pos.ToArray());
         }
      
         public Point3F getNodeNormal()
         {
            return new Point3F(InternalUnsafeMethods.getNodeNormal(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public void setNodeNormal(Point3F normal)
         {
            InternalUnsafeMethods.setNodeNormal(ObjectPtr->RefPtr->ObjPtr, normal.ToArray());
         }
      
         public void setSelectedRoad(string objName = "")
         {
            InternalUnsafeMethods.setSelectedRoad(ObjectPtr->RefPtr->ObjPtr, objName);
         }
      
         public int getSelectedRoad()
         {
            return InternalUnsafeMethods.getSelectedRoad(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void regenerate()
         {
            InternalUnsafeMethods.regenerate(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void matchTerrainToRoad()
         {
            InternalUnsafeMethods.matchTerrainToRoad(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}