using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class FileDialog : SimObject
	{
		public FileDialog()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.FileDialog_create());
		}

		public FileDialog(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public FileDialog(SimObject pObj) : base(pObj)
		{
		}

		public FileDialog(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _Execute(IntPtr thisPtr);
         private static _Execute _ExecuteFunc;
         internal static bool Execute(IntPtr thisPtr)
         {
         	if (_ExecuteFunc == null)
         	{
         		_ExecuteFunc =
         			(_Execute)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnFileDialog_Execute"), typeof(_Execute));
         	}
         
         	return  _ExecuteFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _FileDialog_create();
         private static _FileDialog_create _FileDialog_createFunc;
         internal static IntPtr FileDialog_create()
         {
         	if (_FileDialog_createFunc == null)
         	{
         		_FileDialog_createFunc =
         			(_FileDialog_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_FileDialog_create"), typeof(_FileDialog_create));
         	}
         
         	return  _FileDialog_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public bool Execute()
         {
            return InternalUnsafeMethods.Execute(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}