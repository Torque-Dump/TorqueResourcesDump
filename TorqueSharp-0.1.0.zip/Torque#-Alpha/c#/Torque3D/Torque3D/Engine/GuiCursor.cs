using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiCursor : SimObject
	{
		public GuiCursor()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiCursor_create());
		}

		public GuiCursor(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiCursor(SimObject pObj) : base(pObj)
		{
		}

		public GuiCursor(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiCursor_create();
         private static _GuiCursor_create _GuiCursor_createFunc;
         internal static IntPtr GuiCursor_create()
         {
         	if (_GuiCursor_createFunc == null)
         	{
         		_GuiCursor_createFunc =
         			(_GuiCursor_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiCursor_create"), typeof(_GuiCursor_create));
         	}
         
         	return  _GuiCursor_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}