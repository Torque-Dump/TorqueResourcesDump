using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class SFXProfile : SFXTrack
	{
		public SFXProfile()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.SFXProfile_create());
		}

		public SFXProfile(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public SFXProfile(SimObject pObj) : base(pObj)
		{
		}

		public SFXProfile(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float _getSoundDuration(IntPtr thisPtr);
         private static _getSoundDuration _getSoundDurationFunc;
         internal static float getSoundDuration(IntPtr thisPtr)
         {
         	if (_getSoundDurationFunc == null)
         	{
         		_getSoundDurationFunc =
         			(_getSoundDuration)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnSFXProfile_getSoundDuration"), typeof(_getSoundDuration));
         	}
         
         	return  _getSoundDurationFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _SFXProfile_create();
         private static _SFXProfile_create _SFXProfile_createFunc;
         internal static IntPtr SFXProfile_create()
         {
         	if (_SFXProfile_createFunc == null)
         	{
         		_SFXProfile_createFunc =
         			(_SFXProfile_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_SFXProfile_create"), typeof(_SFXProfile_create));
         	}
         
         	return  _SFXProfile_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public float getSoundDuration()
         {
            return InternalUnsafeMethods.getSoundDuration(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}