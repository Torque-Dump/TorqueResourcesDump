using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ForestBrushElement : SimObject
	{
		public ForestBrushElement()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ForestBrushElement_create());
		}

		public ForestBrushElement(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ForestBrushElement(SimObject pObj) : base(pObj)
		{
		}

		public ForestBrushElement(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ForestBrushElement_create();
         private static _ForestBrushElement_create _ForestBrushElement_createFunc;
         internal static IntPtr ForestBrushElement_create()
         {
         	if (_ForestBrushElement_createFunc == null)
         	{
         		_ForestBrushElement_createFunc =
         			(_ForestBrushElement_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ForestBrushElement_create"), typeof(_ForestBrushElement_create));
         	}
         
         	return  _ForestBrushElement_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}