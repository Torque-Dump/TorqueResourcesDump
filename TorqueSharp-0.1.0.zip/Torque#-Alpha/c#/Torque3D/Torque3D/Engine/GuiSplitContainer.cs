using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiSplitContainer : GuiContainer
	{
		public GuiSplitContainer()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiSplitContainer_create());
		}

		public GuiSplitContainer(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiSplitContainer(SimObject pObj) : base(pObj)
		{
		}

		public GuiSplitContainer(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiSplitContainer_create();
         private static _GuiSplitContainer_create _GuiSplitContainer_createFunc;
         internal static IntPtr GuiSplitContainer_create()
         {
         	if (_GuiSplitContainer_createFunc == null)
         	{
         		_GuiSplitContainer_createFunc =
         			(_GuiSplitContainer_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiSplitContainer_create"), typeof(_GuiSplitContainer_create));
         	}
         
         	return  _GuiSplitContainer_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}