using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ScatterSky : SceneObject
	{
		public ScatterSky()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ScatterSky_create());
		}

		public ScatterSky(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ScatterSky(SimObject pObj) : base(pObj)
		{
		}

		public ScatterSky(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _applyChanges(IntPtr thisPtr);
         private static _applyChanges _applyChangesFunc;
         internal static void applyChanges(IntPtr thisPtr)
         {
         	if (_applyChangesFunc == null)
         	{
         		_applyChangesFunc =
         			(_applyChanges)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnScatterSky_applyChanges"), typeof(_applyChanges));
         	}
         
         	 _applyChangesFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ScatterSky_create();
         private static _ScatterSky_create _ScatterSky_createFunc;
         internal static IntPtr ScatterSky_create()
         {
         	if (_ScatterSky_createFunc == null)
         	{
         		_ScatterSky_createFunc =
         			(_ScatterSky_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ScatterSky_create"), typeof(_ScatterSky_create));
         	}
         
         	return  _ScatterSky_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void applyChanges()
         {
            InternalUnsafeMethods.applyChanges(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}