using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class CustomMaterial : Material
	{
		public CustomMaterial()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.CustomMaterial_create());
		}

		public CustomMaterial(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public CustomMaterial(SimObject pObj) : base(pObj)
		{
		}

		public CustomMaterial(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _CustomMaterial_create();
         private static _CustomMaterial_create _CustomMaterial_createFunc;
         internal static IntPtr CustomMaterial_create()
         {
         	if (_CustomMaterial_createFunc == null)
         	{
         		_CustomMaterial_createFunc =
         			(_CustomMaterial_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_CustomMaterial_create"), typeof(_CustomMaterial_create));
         	}
         
         	return  _CustomMaterial_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}