using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiConsoleTextCtrl : GuiControl
	{
		public GuiConsoleTextCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiConsoleTextCtrl_create());
		}

		public GuiConsoleTextCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiConsoleTextCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiConsoleTextCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiConsoleTextCtrl_create();
         private static _GuiConsoleTextCtrl_create _GuiConsoleTextCtrl_createFunc;
         internal static IntPtr GuiConsoleTextCtrl_create()
         {
         	if (_GuiConsoleTextCtrl_createFunc == null)
         	{
         		_GuiConsoleTextCtrl_createFunc =
         			(_GuiConsoleTextCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiConsoleTextCtrl_create"), typeof(_GuiConsoleTextCtrl_create));
         	}
         
         	return  _GuiConsoleTextCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}