using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class fxFoliageReplicator : SceneObject
	{
		public fxFoliageReplicator()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.fxFoliageReplicator_create());
		}

		public fxFoliageReplicator(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public fxFoliageReplicator(SimObject pObj) : base(pObj)
		{
		}

		public fxFoliageReplicator(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _fxFoliageReplicator_create();
         private static _fxFoliageReplicator_create _fxFoliageReplicator_createFunc;
         internal static IntPtr fxFoliageReplicator_create()
         {
         	if (_fxFoliageReplicator_createFunc == null)
         	{
         		_fxFoliageReplicator_createFunc =
         			(_fxFoliageReplicator_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_fxFoliageReplicator_create"), typeof(_fxFoliageReplicator_create));
         	}
         
         	return  _fxFoliageReplicator_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}