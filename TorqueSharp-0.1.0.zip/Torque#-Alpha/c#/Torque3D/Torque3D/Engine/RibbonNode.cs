using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class RibbonNode : GameBase
	{
		public RibbonNode()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.RibbonNode_create());
		}

		public RibbonNode(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public RibbonNode(SimObject pObj) : base(pObj)
		{
		}

		public RibbonNode(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setRibbonDatablock(IntPtr thisPtr, IntPtr ribbonDatablock);
         private static _setRibbonDatablock _setRibbonDatablockFunc;
         internal static void setRibbonDatablock(IntPtr thisPtr, IntPtr ribbonDatablock)
         {
         	if (_setRibbonDatablockFunc == null)
         	{
         		_setRibbonDatablockFunc =
         			(_setRibbonDatablock)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnRibbonNode_setRibbonDatablock"), typeof(_setRibbonDatablock));
         	}
         
         	 _setRibbonDatablockFunc(thisPtr, ribbonDatablock);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setActive(IntPtr thisPtr, bool active);
         private static _setActive _setActiveFunc;
         internal static void setActive(IntPtr thisPtr, bool active)
         {
         	if (_setActiveFunc == null)
         	{
         		_setActiveFunc =
         			(_setActive)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnRibbonNode_setActive"), typeof(_setActive));
         	}
         
         	 _setActiveFunc(thisPtr, active);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _RibbonNode_create();
         private static _RibbonNode_create _RibbonNode_createFunc;
         internal static IntPtr RibbonNode_create()
         {
         	if (_RibbonNode_createFunc == null)
         	{
         		_RibbonNode_createFunc =
         			(_RibbonNode_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_RibbonNode_create"), typeof(_RibbonNode_create));
         	}
         
         	return  _RibbonNode_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void setRibbonDatablock(RibbonData ribbonDatablock)
         {
            InternalUnsafeMethods.setRibbonDatablock(ObjectPtr->RefPtr->ObjPtr, ribbonDatablock.ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setActive(bool active)
         {
            InternalUnsafeMethods.setActive(ObjectPtr->RefPtr->ObjPtr, active);
         }
      
      
      #endregion

	}
}