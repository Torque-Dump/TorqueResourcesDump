using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiTextEditSliderCtrl : GuiTextEditCtrl
	{
		public GuiTextEditSliderCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiTextEditSliderCtrl_create());
		}

		public GuiTextEditSliderCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiTextEditSliderCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiTextEditSliderCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiTextEditSliderCtrl_create();
         private static _GuiTextEditSliderCtrl_create _GuiTextEditSliderCtrl_createFunc;
         internal static IntPtr GuiTextEditSliderCtrl_create()
         {
         	if (_GuiTextEditSliderCtrl_createFunc == null)
         	{
         		_GuiTextEditSliderCtrl_createFunc =
         			(_GuiTextEditSliderCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiTextEditSliderCtrl_create"), typeof(_GuiTextEditSliderCtrl_create));
         	}
         
         	return  _GuiTextEditSliderCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}