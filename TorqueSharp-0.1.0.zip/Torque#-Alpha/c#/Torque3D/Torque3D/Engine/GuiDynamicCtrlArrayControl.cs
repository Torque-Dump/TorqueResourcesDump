using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiDynamicCtrlArrayControl : GuiControl
	{
		public GuiDynamicCtrlArrayControl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiDynamicCtrlArrayControl_create());
		}

		public GuiDynamicCtrlArrayControl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiDynamicCtrlArrayControl(SimObject pObj) : base(pObj)
		{
		}

		public GuiDynamicCtrlArrayControl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _refresh(IntPtr thisPtr);
         private static _refresh _refreshFunc;
         internal static void refresh(IntPtr thisPtr)
         {
         	if (_refreshFunc == null)
         	{
         		_refreshFunc =
         			(_refresh)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiDynamicCtrlArrayControl_refresh"), typeof(_refresh));
         	}
         
         	 _refreshFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiDynamicCtrlArrayControl_create();
         private static _GuiDynamicCtrlArrayControl_create _GuiDynamicCtrlArrayControl_createFunc;
         internal static IntPtr GuiDynamicCtrlArrayControl_create()
         {
         	if (_GuiDynamicCtrlArrayControl_createFunc == null)
         	{
         		_GuiDynamicCtrlArrayControl_createFunc =
         			(_GuiDynamicCtrlArrayControl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiDynamicCtrlArrayControl_create"), typeof(_GuiDynamicCtrlArrayControl_create));
         	}
         
         	return  _GuiDynamicCtrlArrayControl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void refresh()
         {
            InternalUnsafeMethods.refresh(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}