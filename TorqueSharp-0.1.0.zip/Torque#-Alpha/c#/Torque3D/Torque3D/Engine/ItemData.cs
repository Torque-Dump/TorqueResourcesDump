using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ItemData : ShapeBaseData
	{
		public ItemData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ItemData_create());
		}

		public ItemData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ItemData(SimObject pObj) : base(pObj)
		{
		}

		public ItemData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ItemData_create();
         private static _ItemData_create _ItemData_createFunc;
         internal static IntPtr ItemData_create()
         {
         	if (_ItemData_createFunc == null)
         	{
         		_ItemData_createFunc =
         			(_ItemData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ItemData_create"), typeof(_ItemData_create));
         	}
         
         	return  _ItemData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}