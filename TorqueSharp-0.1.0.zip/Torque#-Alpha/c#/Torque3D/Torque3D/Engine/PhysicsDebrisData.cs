using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class PhysicsDebrisData : GameBaseData
	{
		public PhysicsDebrisData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.PhysicsDebrisData_create());
		}

		public PhysicsDebrisData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public PhysicsDebrisData(SimObject pObj) : base(pObj)
		{
		}

		public PhysicsDebrisData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _preload(IntPtr thisPtr);
         private static _preload _preloadFunc;
         internal static void preload(IntPtr thisPtr)
         {
         	if (_preloadFunc == null)
         	{
         		_preloadFunc =
         			(_preload)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnPhysicsDebrisData_preload"), typeof(_preload));
         	}
         
         	 _preloadFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _PhysicsDebrisData_create();
         private static _PhysicsDebrisData_create _PhysicsDebrisData_createFunc;
         internal static IntPtr PhysicsDebrisData_create()
         {
         	if (_PhysicsDebrisData_createFunc == null)
         	{
         		_PhysicsDebrisData_createFunc =
         			(_PhysicsDebrisData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_PhysicsDebrisData_create"), typeof(_PhysicsDebrisData_create));
         	}
         
         	return  _PhysicsDebrisData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void preload()
         {
            InternalUnsafeMethods.preload(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}