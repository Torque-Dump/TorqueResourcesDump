using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiStackControl : GuiControl
	{
		public GuiStackControl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiStackControl_create());
		}

		public GuiStackControl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiStackControl(SimObject pObj) : base(pObj)
		{
		}

		public GuiStackControl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _isFrozen(IntPtr thisPtr);
         private static _isFrozen _isFrozenFunc;
         internal static bool isFrozen(IntPtr thisPtr)
         {
         	if (_isFrozenFunc == null)
         	{
         		_isFrozenFunc =
         			(_isFrozen)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiStackControl_isFrozen"), typeof(_isFrozen));
         	}
         
         	return  _isFrozenFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _freeze(IntPtr thisPtr, bool freeze);
         private static _freeze _freezeFunc;
         internal static void freeze(IntPtr thisPtr, bool freeze)
         {
         	if (_freezeFunc == null)
         	{
         		_freezeFunc =
         			(_freeze)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiStackControl_freeze"), typeof(_freeze));
         	}
         
         	 _freezeFunc(thisPtr, freeze);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _updateStack(IntPtr thisPtr);
         private static _updateStack _updateStackFunc;
         internal static void updateStack(IntPtr thisPtr)
         {
         	if (_updateStackFunc == null)
         	{
         		_updateStackFunc =
         			(_updateStack)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiStackControl_updateStack"), typeof(_updateStack));
         	}
         
         	 _updateStackFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiStackControl_create();
         private static _GuiStackControl_create _GuiStackControl_createFunc;
         internal static IntPtr GuiStackControl_create()
         {
         	if (_GuiStackControl_createFunc == null)
         	{
         		_GuiStackControl_createFunc =
         			(_GuiStackControl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiStackControl_create"), typeof(_GuiStackControl_create));
         	}
         
         	return  _GuiStackControl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public bool isFrozen()
         {
            return InternalUnsafeMethods.isFrozen(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void freeze(bool freeze)
         {
            InternalUnsafeMethods.freeze(ObjectPtr->RefPtr->ObjPtr, freeze);
         }
      
         public void updateStack()
         {
            InternalUnsafeMethods.updateStack(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}