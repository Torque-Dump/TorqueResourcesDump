using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiToggleButtonCtrl : GuiButtonCtrl
	{
		public GuiToggleButtonCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiToggleButtonCtrl_create());
		}

		public GuiToggleButtonCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiToggleButtonCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiToggleButtonCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiToggleButtonCtrl_create();
         private static _GuiToggleButtonCtrl_create _GuiToggleButtonCtrl_createFunc;
         internal static IntPtr GuiToggleButtonCtrl_create()
         {
         	if (_GuiToggleButtonCtrl_createFunc == null)
         	{
         		_GuiToggleButtonCtrl_createFunc =
         			(_GuiToggleButtonCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiToggleButtonCtrl_create"), typeof(_GuiToggleButtonCtrl_create));
         	}
         
         	return  _GuiToggleButtonCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}