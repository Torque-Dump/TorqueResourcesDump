using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GameBase : SceneObject
	{
		public GameBase()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GameBase_create());
		}

		public GameBase(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GameBase(SimObject pObj) : base(pObj)
		{
		}

		public GameBase(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getDataBlock(IntPtr thisPtr);
         private static _getDataBlock _getDataBlockFunc;
         internal static int getDataBlock(IntPtr thisPtr)
         {
         	if (_getDataBlockFunc == null)
         	{
         		_getDataBlockFunc =
         			(_getDataBlock)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGameBase_getDataBlock"), typeof(_getDataBlock));
         	}
         
         	return  _getDataBlockFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _setDataBlock(IntPtr thisPtr, IntPtr data);
         private static _setDataBlock _setDataBlockFunc;
         internal static bool setDataBlock(IntPtr thisPtr, IntPtr data)
         {
         	if (_setDataBlockFunc == null)
         	{
         		_setDataBlockFunc =
         			(_setDataBlock)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGameBase_setDataBlock"), typeof(_setDataBlock));
         	}
         
         	return  _setDataBlockFunc(thisPtr, data);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _applyImpulse(IntPtr thisPtr, float[] pos, float[] vel);
         private static _applyImpulse _applyImpulseFunc;
         internal static bool applyImpulse(IntPtr thisPtr, float[] pos, float[] vel)
         {
         	if (_applyImpulseFunc == null)
         	{
         		_applyImpulseFunc =
         			(_applyImpulse)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGameBase_applyImpulse"), typeof(_applyImpulse));
         	}
         
         	return  _applyImpulseFunc(thisPtr, pos, vel);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _applyRadialImpulse(IntPtr thisPtr, float[] origin, float radius, float magnitude);
         private static _applyRadialImpulse _applyRadialImpulseFunc;
         internal static void applyRadialImpulse(IntPtr thisPtr, float[] origin, float radius, float magnitude)
         {
         	if (_applyRadialImpulseFunc == null)
         	{
         		_applyRadialImpulseFunc =
         			(_applyRadialImpulse)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGameBase_applyRadialImpulse"), typeof(_applyRadialImpulse));
         	}
         
         	 _applyRadialImpulseFunc(thisPtr, origin, radius, magnitude);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GameBase_create();
         private static _GameBase_create _GameBase_createFunc;
         internal static IntPtr GameBase_create()
         {
         	if (_GameBase_createFunc == null)
         	{
         		_GameBase_createFunc =
         			(_GameBase_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GameBase_create"), typeof(_GameBase_create));
         	}
         
         	return  _GameBase_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public int getDataBlock()
         {
            return InternalUnsafeMethods.getDataBlock(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public bool setDataBlock(GameBaseData data)
         {
            return InternalUnsafeMethods.setDataBlock(ObjectPtr->RefPtr->ObjPtr, data.ObjectPtr->RefPtr->ObjPtr);
         }
      
         public bool applyImpulse(Point3F pos, VectorF vel)
         {
            return InternalUnsafeMethods.applyImpulse(ObjectPtr->RefPtr->ObjPtr, pos.ToArray(), vel.ToArray());
         }
      
         public void applyRadialImpulse(Point3F origin, float radius, float magnitude)
         {
            InternalUnsafeMethods.applyRadialImpulse(ObjectPtr->RefPtr->ObjPtr, origin.ToArray(), radius, magnitude);
         }
      
      
      #endregion

	}
}