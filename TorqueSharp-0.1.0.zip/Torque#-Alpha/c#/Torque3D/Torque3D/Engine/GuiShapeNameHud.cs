using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiShapeNameHud : GuiControl
	{
		public GuiShapeNameHud()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiShapeNameHud_create());
		}

		public GuiShapeNameHud(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiShapeNameHud(SimObject pObj) : base(pObj)
		{
		}

		public GuiShapeNameHud(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiShapeNameHud_create();
         private static _GuiShapeNameHud_create _GuiShapeNameHud_createFunc;
         internal static IntPtr GuiShapeNameHud_create()
         {
         	if (_GuiShapeNameHud_createFunc == null)
         	{
         		_GuiShapeNameHud_createFunc =
         			(_GuiShapeNameHud_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiShapeNameHud_create"), typeof(_GuiShapeNameHud_create));
         	}
         
         	return  _GuiShapeNameHud_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}