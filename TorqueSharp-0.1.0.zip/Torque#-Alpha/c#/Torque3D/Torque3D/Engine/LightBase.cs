using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class LightBase : SceneObject
	{
		public LightBase()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.LightBase_create());
		}

		public LightBase(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public LightBase(SimObject pObj) : base(pObj)
		{
		}

		public LightBase(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setLightEnabled(IntPtr thisPtr, bool state);
         private static _setLightEnabled _setLightEnabledFunc;
         internal static void setLightEnabled(IntPtr thisPtr, bool state)
         {
         	if (_setLightEnabledFunc == null)
         	{
         		_setLightEnabledFunc =
         			(_setLightEnabled)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnLightBase_setLightEnabled"), typeof(_setLightEnabled));
         	}
         
         	 _setLightEnabledFunc(thisPtr, state);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _playAnimation(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string anim);
         private static _playAnimation _playAnimationFunc;
         internal static void playAnimation(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string anim)
         {
         	if (_playAnimationFunc == null)
         	{
         		_playAnimationFunc =
         			(_playAnimation)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnLightBase_playAnimation"), typeof(_playAnimation));
         	}
         
         	 _playAnimationFunc(thisPtr, anim);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _pauseAnimation(IntPtr thisPtr);
         private static _pauseAnimation _pauseAnimationFunc;
         internal static void pauseAnimation(IntPtr thisPtr)
         {
         	if (_pauseAnimationFunc == null)
         	{
         		_pauseAnimationFunc =
         			(_pauseAnimation)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnLightBase_pauseAnimation"), typeof(_pauseAnimation));
         	}
         
         	 _pauseAnimationFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _LightBase_create();
         private static _LightBase_create _LightBase_createFunc;
         internal static IntPtr LightBase_create()
         {
         	if (_LightBase_createFunc == null)
         	{
         		_LightBase_createFunc =
         			(_LightBase_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_LightBase_create"), typeof(_LightBase_create));
         	}
         
         	return  _LightBase_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void setLightEnabled(bool state)
         {
            InternalUnsafeMethods.setLightEnabled(ObjectPtr->RefPtr->ObjPtr, state);
         }
      
         public void playAnimation(string anim = "")
         {
            InternalUnsafeMethods.playAnimation(ObjectPtr->RefPtr->ObjPtr, anim);
         }
      
         public void pauseAnimation()
         {
            InternalUnsafeMethods.pauseAnimation(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}