using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GameBaseData : SimDataBlock
	{
		public GameBaseData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GameBaseData_create());
		}

		public GameBaseData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GameBaseData(SimObject pObj) : base(pObj)
		{
		}

		public GameBaseData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GameBaseData_create();
         private static _GameBaseData_create _GameBaseData_createFunc;
         internal static IntPtr GameBaseData_create()
         {
         	if (_GameBaseData_createFunc == null)
         	{
         		_GameBaseData_createFunc =
         			(_GameBaseData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GameBaseData_create"), typeof(_GameBaseData_create));
         	}
         
         	return  _GameBaseData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}