using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class RenderTranslucentMgr : RenderBinManager
	{
		public RenderTranslucentMgr()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.RenderTranslucentMgr_create());
		}

		public RenderTranslucentMgr(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public RenderTranslucentMgr(SimObject pObj) : base(pObj)
		{
		}

		public RenderTranslucentMgr(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _RenderTranslucentMgr_create();
         private static _RenderTranslucentMgr_create _RenderTranslucentMgr_createFunc;
         internal static IntPtr RenderTranslucentMgr_create()
         {
         	if (_RenderTranslucentMgr_createFunc == null)
         	{
         		_RenderTranslucentMgr_createFunc =
         			(_RenderTranslucentMgr_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_RenderTranslucentMgr_create"), typeof(_RenderTranslucentMgr_create));
         	}
         
         	return  _RenderTranslucentMgr_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}