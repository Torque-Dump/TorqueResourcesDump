using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class Vehicle : ShapeBase
	{
		public Vehicle()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.Vehicle_create());
		}

		public Vehicle(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public Vehicle(SimObject pObj) : base(pObj)
		{
		}

		public Vehicle(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _Vehicle_create();
         private static _Vehicle_create _Vehicle_createFunc;
         internal static IntPtr Vehicle_create()
         {
         	if (_Vehicle_createFunc == null)
         	{
         		_Vehicle_createFunc =
         			(_Vehicle_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_Vehicle_create"), typeof(_Vehicle_create));
         	}
         
         	return  _Vehicle_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}