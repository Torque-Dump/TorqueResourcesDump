using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ModuleDefinition : SimSet
	{
		public ModuleDefinition()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ModuleDefinition_create());
		}

		public ModuleDefinition(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ModuleDefinition(SimObject pObj) : base(pObj)
		{
		}

		public ModuleDefinition(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _save(IntPtr thisPtr);
         private static _save _saveFunc;
         internal static bool save(IntPtr thisPtr)
         {
         	if (_saveFunc == null)
         	{
         		_saveFunc =
         			(_save)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnModuleDefinition_save"), typeof(_save));
         	}
         
         	return  _saveFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getModuleManager(IntPtr thisPtr);
         private static _getModuleManager _getModuleManagerFunc;
         internal static int getModuleManager(IntPtr thisPtr)
         {
         	if (_getModuleManagerFunc == null)
         	{
         		_getModuleManagerFunc =
         			(_getModuleManager)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnModuleDefinition_getModuleManager"), typeof(_getModuleManager));
         	}
         
         	return  _getModuleManagerFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getDependencyCount(IntPtr thisPtr);
         private static _getDependencyCount _getDependencyCountFunc;
         internal static int getDependencyCount(IntPtr thisPtr)
         {
         	if (_getDependencyCountFunc == null)
         	{
         		_getDependencyCountFunc =
         			(_getDependencyCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnModuleDefinition_getDependencyCount"), typeof(_getDependencyCount));
         	}
         
         	return  _getDependencyCountFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getDependency(IntPtr thisPtr, uint dependencyIndex);
         private static _getDependency _getDependencyFunc;
         internal static IntPtr getDependency(IntPtr thisPtr, uint dependencyIndex)
         {
         	if (_getDependencyFunc == null)
         	{
         		_getDependencyFunc =
         			(_getDependency)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnModuleDefinition_getDependency"), typeof(_getDependency));
         	}
         
         	return  _getDependencyFunc(thisPtr, dependencyIndex);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _addDependency(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string pModuleId, uint versionId);
         private static _addDependency _addDependencyFunc;
         internal static bool addDependency(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string pModuleId, uint versionId)
         {
         	if (_addDependencyFunc == null)
         	{
         		_addDependencyFunc =
         			(_addDependency)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnModuleDefinition_addDependency"), typeof(_addDependency));
         	}
         
         	return  _addDependencyFunc(thisPtr, pModuleId, versionId);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _removeDependency(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string pModuleId);
         private static _removeDependency _removeDependencyFunc;
         internal static bool removeDependency(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string pModuleId)
         {
         	if (_removeDependencyFunc == null)
         	{
         		_removeDependencyFunc =
         			(_removeDependency)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnModuleDefinition_removeDependency"), typeof(_removeDependency));
         	}
         
         	return  _removeDependencyFunc(thisPtr, pModuleId);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ModuleDefinition_create();
         private static _ModuleDefinition_create _ModuleDefinition_createFunc;
         internal static IntPtr ModuleDefinition_create()
         {
         	if (_ModuleDefinition_createFunc == null)
         	{
         		_ModuleDefinition_createFunc =
         			(_ModuleDefinition_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ModuleDefinition_create"), typeof(_ModuleDefinition_create));
         	}
         
         	return  _ModuleDefinition_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public bool save()
         {
            return InternalUnsafeMethods.save(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public int getModuleManager()
         {
            return InternalUnsafeMethods.getModuleManager(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public int getDependencyCount()
         {
            return InternalUnsafeMethods.getDependencyCount(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public string getDependency(uint dependencyIndex = 0)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getDependency(ObjectPtr->RefPtr->ObjPtr, dependencyIndex));
         }
      
         public bool addDependency(string pModuleId = "", uint versionId = 0)
         {
            return InternalUnsafeMethods.addDependency(ObjectPtr->RefPtr->ObjPtr, pModuleId, versionId);
         }
      
         public bool removeDependency(string pModuleId = "")
         {
            return InternalUnsafeMethods.removeDependency(ObjectPtr->RefPtr->ObjPtr, pModuleId);
         }
      
      
      #endregion

	}
}