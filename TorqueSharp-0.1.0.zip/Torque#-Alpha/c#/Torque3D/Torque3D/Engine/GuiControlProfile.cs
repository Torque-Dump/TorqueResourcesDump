using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiControlProfile : SimObject
	{
		public GuiControlProfile()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiControlProfile_create());
		}

		public GuiControlProfile(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiControlProfile(SimObject pObj) : base(pObj)
		{
		}

		public GuiControlProfile(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getStringWidth(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string _string);
         private static _getStringWidth _getStringWidthFunc;
         internal static int getStringWidth(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string _string)
         {
         	if (_getStringWidthFunc == null)
         	{
         		_getStringWidthFunc =
         			(_getStringWidth)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiControlProfile_getStringWidth"), typeof(_getStringWidth));
         	}
         
         	return  _getStringWidthFunc(thisPtr, _string);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiControlProfile_create();
         private static _GuiControlProfile_create _GuiControlProfile_createFunc;
         internal static IntPtr GuiControlProfile_create()
         {
         	if (_GuiControlProfile_createFunc == null)
         	{
         		_GuiControlProfile_createFunc =
         			(_GuiControlProfile_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiControlProfile_create"), typeof(_GuiControlProfile_create));
         	}
         
         	return  _GuiControlProfile_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public int getStringWidth(string _string)
         {
            return InternalUnsafeMethods.getStringWidth(ObjectPtr->RefPtr->ObjPtr, _string);
         }
      
      
      #endregion

	}
}