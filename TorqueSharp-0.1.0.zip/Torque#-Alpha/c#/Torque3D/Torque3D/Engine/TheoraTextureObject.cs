using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class TheoraTextureObject : SimObject
	{
		public TheoraTextureObject()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.TheoraTextureObject_create());
		}

		public TheoraTextureObject(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public TheoraTextureObject(SimObject pObj) : base(pObj)
		{
		}

		public TheoraTextureObject(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _play(IntPtr thisPtr);
         private static _play _playFunc;
         internal static void play(IntPtr thisPtr)
         {
         	if (_playFunc == null)
         	{
         		_playFunc =
         			(_play)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTheoraTextureObject_play"), typeof(_play));
         	}
         
         	 _playFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _stop(IntPtr thisPtr);
         private static _stop _stopFunc;
         internal static void stop(IntPtr thisPtr)
         {
         	if (_stopFunc == null)
         	{
         		_stopFunc =
         			(_stop)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTheoraTextureObject_stop"), typeof(_stop));
         	}
         
         	 _stopFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _pause(IntPtr thisPtr);
         private static _pause _pauseFunc;
         internal static void pause(IntPtr thisPtr)
         {
         	if (_pauseFunc == null)
         	{
         		_pauseFunc =
         			(_pause)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnTheoraTextureObject_pause"), typeof(_pause));
         	}
         
         	 _pauseFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _TheoraTextureObject_create();
         private static _TheoraTextureObject_create _TheoraTextureObject_createFunc;
         internal static IntPtr TheoraTextureObject_create()
         {
         	if (_TheoraTextureObject_createFunc == null)
         	{
         		_TheoraTextureObject_createFunc =
         			(_TheoraTextureObject_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_TheoraTextureObject_create"), typeof(_TheoraTextureObject_create));
         	}
         
         	return  _TheoraTextureObject_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void play()
         {
            InternalUnsafeMethods.play(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void stop()
         {
            InternalUnsafeMethods.stop(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void pause()
         {
            InternalUnsafeMethods.pause(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}