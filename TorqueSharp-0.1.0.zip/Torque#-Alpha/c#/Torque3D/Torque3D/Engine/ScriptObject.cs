using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ScriptObject : SimObject
	{
		public ScriptObject()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ScriptObject_create());
		}

		public ScriptObject(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ScriptObject(SimObject pObj) : base(pObj)
		{
		}

		public ScriptObject(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ScriptObject_create();
         private static _ScriptObject_create _ScriptObject_createFunc;
         internal static IntPtr ScriptObject_create()
         {
         	if (_ScriptObject_createFunc == null)
         	{
         		_ScriptObject_createFunc =
         			(_ScriptObject_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ScriptObject_create"), typeof(_ScriptObject_create));
         	}
         
         	return  _ScriptObject_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}