using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class TSForestItemData : ForestItemData
	{
		public TSForestItemData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.TSForestItemData_create());
		}

		public TSForestItemData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public TSForestItemData(SimObject pObj) : base(pObj)
		{
		}

		public TSForestItemData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _TSForestItemData_create();
         private static _TSForestItemData_create _TSForestItemData_createFunc;
         internal static IntPtr TSForestItemData_create()
         {
         	if (_TSForestItemData_createFunc == null)
         	{
         		_TSForestItemData_createFunc =
         			(_TSForestItemData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_TSForestItemData_create"), typeof(_TSForestItemData_create));
         	}
         
         	return  _TSForestItemData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}