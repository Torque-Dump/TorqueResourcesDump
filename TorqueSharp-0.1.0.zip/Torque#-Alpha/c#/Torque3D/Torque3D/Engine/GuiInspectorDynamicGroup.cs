using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiInspectorDynamicGroup : GuiInspectorGroup
	{
		public GuiInspectorDynamicGroup()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiInspectorDynamicGroup_create());
		}

		public GuiInspectorDynamicGroup(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiInspectorDynamicGroup(SimObject pObj) : base(pObj)
		{
		}

		public GuiInspectorDynamicGroup(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _inspectGroup(IntPtr thisPtr);
         private static _inspectGroup _inspectGroupFunc;
         internal static bool inspectGroup(IntPtr thisPtr)
         {
         	if (_inspectGroupFunc == null)
         	{
         		_inspectGroupFunc =
         			(_inspectGroup)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiInspectorDynamicGroup_inspectGroup"), typeof(_inspectGroup));
         	}
         
         	return  _inspectGroupFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _addDynamicField(IntPtr thisPtr);
         private static _addDynamicField _addDynamicFieldFunc;
         internal static void addDynamicField(IntPtr thisPtr)
         {
         	if (_addDynamicFieldFunc == null)
         	{
         		_addDynamicFieldFunc =
         			(_addDynamicField)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiInspectorDynamicGroup_addDynamicField"), typeof(_addDynamicField));
         	}
         
         	 _addDynamicFieldFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _removeDynamicField(IntPtr thisPtr);
         private static _removeDynamicField _removeDynamicFieldFunc;
         internal static void removeDynamicField(IntPtr thisPtr)
         {
         	if (_removeDynamicFieldFunc == null)
         	{
         		_removeDynamicFieldFunc =
         			(_removeDynamicField)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiInspectorDynamicGroup_removeDynamicField"), typeof(_removeDynamicField));
         	}
         
         	 _removeDynamicFieldFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiInspectorDynamicGroup_create();
         private static _GuiInspectorDynamicGroup_create _GuiInspectorDynamicGroup_createFunc;
         internal static IntPtr GuiInspectorDynamicGroup_create()
         {
         	if (_GuiInspectorDynamicGroup_createFunc == null)
         	{
         		_GuiInspectorDynamicGroup_createFunc =
         			(_GuiInspectorDynamicGroup_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiInspectorDynamicGroup_create"), typeof(_GuiInspectorDynamicGroup_create));
         	}
         
         	return  _GuiInspectorDynamicGroup_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public bool inspectGroup()
         {
            return InternalUnsafeMethods.inspectGroup(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void addDynamicField()
         {
            InternalUnsafeMethods.addDynamicField(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void removeDynamicField()
         {
            InternalUnsafeMethods.removeDynamicField(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}