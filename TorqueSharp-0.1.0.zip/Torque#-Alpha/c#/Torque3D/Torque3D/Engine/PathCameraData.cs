using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class PathCameraData : ShapeBaseData
	{
		public PathCameraData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.PathCameraData_create());
		}

		public PathCameraData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public PathCameraData(SimObject pObj) : base(pObj)
		{
		}

		public PathCameraData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _PathCameraData_create();
         private static _PathCameraData_create _PathCameraData_createFunc;
         internal static IntPtr PathCameraData_create()
         {
         	if (_PathCameraData_createFunc == null)
         	{
         		_PathCameraData_createFunc =
         			(_PathCameraData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_PathCameraData_create"), typeof(_PathCameraData_create));
         	}
         
         	return  _PathCameraData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}