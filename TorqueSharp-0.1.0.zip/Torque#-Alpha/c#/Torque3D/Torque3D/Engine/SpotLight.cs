using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class SpotLight : LightBase
	{
		public SpotLight()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.SpotLight_create());
		}

		public SpotLight(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public SpotLight(SimObject pObj) : base(pObj)
		{
		}

		public SpotLight(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _SpotLight_create();
         private static _SpotLight_create _SpotLight_createFunc;
         internal static IntPtr SpotLight_create()
         {
         	if (_SpotLight_createFunc == null)
         	{
         		_SpotLight_createFunc =
         			(_SpotLight_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_SpotLight_create"), typeof(_SpotLight_create));
         	}
         
         	return  _SpotLight_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}