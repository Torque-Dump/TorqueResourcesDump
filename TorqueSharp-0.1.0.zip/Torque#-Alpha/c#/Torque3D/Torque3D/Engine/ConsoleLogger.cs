using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ConsoleLogger : SimObject
	{
		public ConsoleLogger()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ConsoleLogger_create());
		}

		public ConsoleLogger(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ConsoleLogger(SimObject pObj) : base(pObj)
		{
		}

		public ConsoleLogger(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _attach(IntPtr thisPtr);
         private static _attach _attachFunc;
         internal static bool attach(IntPtr thisPtr)
         {
         	if (_attachFunc == null)
         	{
         		_attachFunc =
         			(_attach)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnConsoleLogger_attach"), typeof(_attach));
         	}
         
         	return  _attachFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _detach(IntPtr thisPtr);
         private static _detach _detachFunc;
         internal static bool detach(IntPtr thisPtr)
         {
         	if (_detachFunc == null)
         	{
         		_detachFunc =
         			(_detach)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnConsoleLogger_detach"), typeof(_detach));
         	}
         
         	return  _detachFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ConsoleLogger_create();
         private static _ConsoleLogger_create _ConsoleLogger_createFunc;
         internal static IntPtr ConsoleLogger_create()
         {
         	if (_ConsoleLogger_createFunc == null)
         	{
         		_ConsoleLogger_createFunc =
         			(_ConsoleLogger_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ConsoleLogger_create"), typeof(_ConsoleLogger_create));
         	}
         
         	return  _ConsoleLogger_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public bool attach()
         {
            return InternalUnsafeMethods.attach(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public bool detach()
         {
            return InternalUnsafeMethods.detach(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}