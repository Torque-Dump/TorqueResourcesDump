using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ShapeAsset : AssetBase
	{
		public ShapeAsset()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ShapeAsset_create());
		}

		public ShapeAsset(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ShapeAsset(SimObject pObj) : base(pObj)
		{
		}

		public ShapeAsset(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ShapeAsset_create();
         private static _ShapeAsset_create _ShapeAsset_createFunc;
         internal static IntPtr ShapeAsset_create()
         {
         	if (_ShapeAsset_createFunc == null)
         	{
         		_ShapeAsset_createFunc =
         			(_ShapeAsset_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ShapeAsset_create"), typeof(_ShapeAsset_create));
         	}
         
         	return  _ShapeAsset_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}