using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiWindowCollapseCtrl : GuiWindowCtrl
	{
		public GuiWindowCollapseCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiWindowCollapseCtrl_create());
		}

		public GuiWindowCollapseCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiWindowCollapseCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiWindowCollapseCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiWindowCollapseCtrl_create();
         private static _GuiWindowCollapseCtrl_create _GuiWindowCollapseCtrl_createFunc;
         internal static IntPtr GuiWindowCollapseCtrl_create()
         {
         	if (_GuiWindowCollapseCtrl_createFunc == null)
         	{
         		_GuiWindowCollapseCtrl_createFunc =
         			(_GuiWindowCollapseCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiWindowCollapseCtrl_create"), typeof(_GuiWindowCollapseCtrl_create));
         	}
         
         	return  _GuiWindowCollapseCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}