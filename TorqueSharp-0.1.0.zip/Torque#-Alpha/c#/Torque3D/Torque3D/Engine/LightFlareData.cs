using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class LightFlareData : SimDataBlock
	{
		public LightFlareData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.LightFlareData_create());
		}

		public LightFlareData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public LightFlareData(SimObject pObj) : base(pObj)
		{
		}

		public LightFlareData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _apply(IntPtr thisPtr);
         private static _apply _applyFunc;
         internal static void apply(IntPtr thisPtr)
         {
         	if (_applyFunc == null)
         	{
         		_applyFunc =
         			(_apply)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnLightFlareData_apply"), typeof(_apply));
         	}
         
         	 _applyFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _LightFlareData_create();
         private static _LightFlareData_create _LightFlareData_createFunc;
         internal static IntPtr LightFlareData_create()
         {
         	if (_LightFlareData_createFunc == null)
         	{
         		_LightFlareData_createFunc =
         			(_LightFlareData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_LightFlareData_create"), typeof(_LightFlareData_create));
         	}
         
         	return  _LightFlareData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void apply()
         {
            InternalUnsafeMethods.apply(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}