using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class Zone : SceneObject
	{
		public Zone()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.Zone_create());
		}

		public Zone(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public Zone(SimObject pObj) : base(pObj)
		{
		}

		public Zone(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getZoneId(IntPtr thisPtr);
         private static _getZoneId _getZoneIdFunc;
         internal static int getZoneId(IntPtr thisPtr)
         {
         	if (_getZoneIdFunc == null)
         	{
         		_getZoneIdFunc =
         			(_getZoneId)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnZone_getZoneId"), typeof(_getZoneId));
         	}
         
         	return  _getZoneIdFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _dumpZoneState(IntPtr thisPtr, bool updateFirst);
         private static _dumpZoneState _dumpZoneStateFunc;
         internal static void dumpZoneState(IntPtr thisPtr, bool updateFirst)
         {
         	if (_dumpZoneStateFunc == null)
         	{
         		_dumpZoneStateFunc =
         			(_dumpZoneState)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnZone_dumpZoneState"), typeof(_dumpZoneState));
         	}
         
         	 _dumpZoneStateFunc(thisPtr, updateFirst);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _Zone_create();
         private static _Zone_create _Zone_createFunc;
         internal static IntPtr Zone_create()
         {
         	if (_Zone_createFunc == null)
         	{
         		_Zone_createFunc =
         			(_Zone_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_Zone_create"), typeof(_Zone_create));
         	}
         
         	return  _Zone_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public int getZoneId()
         {
            return InternalUnsafeMethods.getZoneId(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void dumpZoneState(bool updateFirst = true)
         {
            InternalUnsafeMethods.dumpZoneState(ObjectPtr->RefPtr->ObjPtr, updateFirst);
         }
      
      
      #endregion

	}
}