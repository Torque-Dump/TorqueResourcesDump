using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class RenderBinManager : SimObject
	{
		public RenderBinManager()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.RenderBinManager_create());
		}

		public RenderBinManager(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public RenderBinManager(SimObject pObj) : base(pObj)
		{
		}

		public RenderBinManager(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getBinType(IntPtr thisPtr);
         private static _getBinType _getBinTypeFunc;
         internal static IntPtr getBinType(IntPtr thisPtr)
         {
         	if (_getBinTypeFunc == null)
         	{
         		_getBinTypeFunc =
         			(_getBinType)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnRenderBinManager_getBinType"), typeof(_getBinType));
         	}
         
         	return  _getBinTypeFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _RenderBinManager_create();
         private static _RenderBinManager_create _RenderBinManager_createFunc;
         internal static IntPtr RenderBinManager_create()
         {
         	if (_RenderBinManager_createFunc == null)
         	{
         		_RenderBinManager_createFunc =
         			(_RenderBinManager_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_RenderBinManager_create"), typeof(_RenderBinManager_create));
         	}
         
         	return  _RenderBinManager_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public string getBinType()
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getBinType(ObjectPtr->RefPtr->ObjPtr));
         }
      
      
      #endregion

	}
}