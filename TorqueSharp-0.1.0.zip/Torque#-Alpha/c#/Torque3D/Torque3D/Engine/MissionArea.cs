using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class MissionArea : NetObject
	{
		public MissionArea()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.MissionArea_create());
		}

		public MissionArea(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public MissionArea(SimObject pObj) : base(pObj)
		{
		}

		public MissionArea(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getArea(IntPtr thisPtr);
         private static _getArea _getAreaFunc;
         internal static IntPtr getArea(IntPtr thisPtr)
         {
         	if (_getAreaFunc == null)
         	{
         		_getAreaFunc =
         			(_getArea)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnMissionArea_getArea"), typeof(_getArea));
         	}
         
         	return  _getAreaFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setArea(IntPtr thisPtr, int x, int y, int width, int height);
         private static _setArea _setAreaFunc;
         internal static void setArea(IntPtr thisPtr, int x, int y, int width, int height)
         {
         	if (_setAreaFunc == null)
         	{
         		_setAreaFunc =
         			(_setArea)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnMissionArea_setArea"), typeof(_setArea));
         	}
         
         	 _setAreaFunc(thisPtr, x, y, width, height);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _postApply(IntPtr thisPtr);
         private static _postApply _postApplyFunc;
         internal static void postApply(IntPtr thisPtr)
         {
         	if (_postApplyFunc == null)
         	{
         		_postApplyFunc =
         			(_postApply)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnMissionArea_postApply"), typeof(_postApply));
         	}
         
         	 _postApplyFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _MissionArea_create();
         private static _MissionArea_create _MissionArea_createFunc;
         internal static IntPtr MissionArea_create()
         {
         	if (_MissionArea_createFunc == null)
         	{
         		_MissionArea_createFunc =
         			(_MissionArea_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_MissionArea_create"), typeof(_MissionArea_create));
         	}
         
         	return  _MissionArea_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public string getArea()
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getArea(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public void setArea(int x, int y, int width, int height)
         {
            InternalUnsafeMethods.setArea(ObjectPtr->RefPtr->ObjPtr, x, y, width, height);
         }
      
         public void postApply()
         {
            InternalUnsafeMethods.postApply(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}