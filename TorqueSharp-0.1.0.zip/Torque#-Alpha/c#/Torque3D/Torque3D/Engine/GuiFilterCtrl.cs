using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiFilterCtrl : GuiControl
	{
		public GuiFilterCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiFilterCtrl_create());
		}

		public GuiFilterCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiFilterCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiFilterCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getValue(IntPtr thisPtr);
         private static _getValue _getValueFunc;
         internal static IntPtr getValue(IntPtr thisPtr)
         {
         	if (_getValueFunc == null)
         	{
         		_getValueFunc =
         			(_getValue)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiFilterCtrl_getValue"), typeof(_getValue));
         	}
         
         	return  _getValueFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setValue(IntPtr thisPtr, int argc, string[] argv);
         private static _setValue _setValueFunc;
         internal static void setValue(IntPtr thisPtr, int argc, string[] argv)
         {
         	if (_setValueFunc == null)
         	{
         		_setValueFunc =
         			(_setValue)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiFilterCtrl_setValue"), typeof(_setValue));
         	}
         
         	 _setValueFunc(thisPtr, argc, argv);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _identity(IntPtr thisPtr);
         private static _identity _identityFunc;
         internal static void identity(IntPtr thisPtr)
         {
         	if (_identityFunc == null)
         	{
         		_identityFunc =
         			(_identity)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiFilterCtrl_identity"), typeof(_identity));
         	}
         
         	 _identityFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiFilterCtrl_create();
         private static _GuiFilterCtrl_create _GuiFilterCtrl_createFunc;
         internal static IntPtr GuiFilterCtrl_create()
         {
         	if (_GuiFilterCtrl_createFunc == null)
         	{
         		_GuiFilterCtrl_createFunc =
         			(_GuiFilterCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiFilterCtrl_create"), typeof(_GuiFilterCtrl_create));
         	}
         
         	return  _GuiFilterCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public string getValue()
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getValue(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public void setValue()
         {
            List<string> tmp_arg_list = new List<string> {""};
                  InternalUnsafeMethods.setValue(ObjectPtr->RefPtr->ObjPtr, tmp_arg_list.Count, tmp_arg_list.ToArray());
         }
      
         public void identity()
         {
            InternalUnsafeMethods.identity(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}