using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiWindowCtrl : GuiContainer
	{
		public GuiWindowCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiWindowCtrl_create());
		}

		public GuiWindowCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiWindowCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiWindowCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _selectWindow(IntPtr thisPtr);
         private static _selectWindow _selectWindowFunc;
         internal static void selectWindow(IntPtr thisPtr)
         {
         	if (_selectWindowFunc == null)
         	{
         		_selectWindowFunc =
         			(_selectWindow)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiWindowCtrl_selectWindow"), typeof(_selectWindow));
         	}
         
         	 _selectWindowFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setCollapseGroup(IntPtr thisPtr, bool state);
         private static _setCollapseGroup _setCollapseGroupFunc;
         internal static void setCollapseGroup(IntPtr thisPtr, bool state)
         {
         	if (_setCollapseGroupFunc == null)
         	{
         		_setCollapseGroupFunc =
         			(_setCollapseGroup)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiWindowCtrl_setCollapseGroup"), typeof(_setCollapseGroup));
         	}
         
         	 _setCollapseGroupFunc(thisPtr, state);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _toggleCollapseGroup(IntPtr thisPtr);
         private static _toggleCollapseGroup _toggleCollapseGroupFunc;
         internal static void toggleCollapseGroup(IntPtr thisPtr)
         {
         	if (_toggleCollapseGroupFunc == null)
         	{
         		_toggleCollapseGroupFunc =
         			(_toggleCollapseGroup)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiWindowCtrl_toggleCollapseGroup"), typeof(_toggleCollapseGroup));
         	}
         
         	 _toggleCollapseGroupFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _attachTo(IntPtr thisPtr, IntPtr window);
         private static _attachTo _attachToFunc;
         internal static void attachTo(IntPtr thisPtr, IntPtr window)
         {
         	if (_attachToFunc == null)
         	{
         		_attachToFunc =
         			(_attachTo)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiWindowCtrl_attachTo"), typeof(_attachTo));
         	}
         
         	 _attachToFunc(thisPtr, window);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _attach(IntPtr thisPtr, IntPtr bottomWindow, IntPtr topWindow);
         private static _attach _attachFunc;
         internal static void attach(IntPtr thisPtr, IntPtr bottomWindow, IntPtr topWindow)
         {
         	if (_attachFunc == null)
         	{
         		_attachFunc =
         			(_attach)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiWindowCtrl_attach"), typeof(_attach));
         	}
         
         	 _attachFunc(thisPtr, bottomWindow, topWindow);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiWindowCtrl_create();
         private static _GuiWindowCtrl_create _GuiWindowCtrl_createFunc;
         internal static IntPtr GuiWindowCtrl_create()
         {
         	if (_GuiWindowCtrl_createFunc == null)
         	{
         		_GuiWindowCtrl_createFunc =
         			(_GuiWindowCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiWindowCtrl_create"), typeof(_GuiWindowCtrl_create));
         	}
         
         	return  _GuiWindowCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void selectWindow()
         {
            InternalUnsafeMethods.selectWindow(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setCollapseGroup(bool state)
         {
            InternalUnsafeMethods.setCollapseGroup(ObjectPtr->RefPtr->ObjPtr, state);
         }
      
         public void toggleCollapseGroup()
         {
            InternalUnsafeMethods.toggleCollapseGroup(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void attachTo(GuiWindowCtrl window)
         {
            InternalUnsafeMethods.attachTo(ObjectPtr->RefPtr->ObjPtr, window.ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void attach(GuiWindowCtrl bottomWindow, GuiWindowCtrl topWindow)
         {
            InternalUnsafeMethods.attach(ObjectPtr->RefPtr->ObjPtr, bottomWindow.ObjectPtr->RefPtr->ObjPtr, topWindow.ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}