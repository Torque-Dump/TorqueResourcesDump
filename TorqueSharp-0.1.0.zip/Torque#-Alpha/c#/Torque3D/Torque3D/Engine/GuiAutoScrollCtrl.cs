using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiAutoScrollCtrl : GuiTickCtrl
	{
		public GuiAutoScrollCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiAutoScrollCtrl_create());
		}

		public GuiAutoScrollCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiAutoScrollCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiAutoScrollCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _reset(IntPtr thisPtr);
         private static _reset _resetFunc;
         internal static void reset(IntPtr thisPtr)
         {
         	if (_resetFunc == null)
         	{
         		_resetFunc =
         			(_reset)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiAutoScrollCtrl_reset"), typeof(_reset));
         	}
         
         	 _resetFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiAutoScrollCtrl_create();
         private static _GuiAutoScrollCtrl_create _GuiAutoScrollCtrl_createFunc;
         internal static IntPtr GuiAutoScrollCtrl_create()
         {
         	if (_GuiAutoScrollCtrl_createFunc == null)
         	{
         		_GuiAutoScrollCtrl_createFunc =
         			(_GuiAutoScrollCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiAutoScrollCtrl_create"), typeof(_GuiAutoScrollCtrl_create));
         	}
         
         	return  _GuiAutoScrollCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void reset()
         {
            InternalUnsafeMethods.reset(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}