using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class NavPath : SceneObject
	{
		public NavPath()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.NavPath_create());
		}

		public NavPath(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public NavPath(SimObject pObj) : base(pObj)
		{
		}

		public NavPath(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _plan(IntPtr thisPtr);
         private static _plan _planFunc;
         internal static bool plan(IntPtr thisPtr)
         {
         	if (_planFunc == null)
         	{
         		_planFunc =
         			(_plan)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnNavPath_plan"), typeof(_plan));
         	}
         
         	return  _planFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _onNavMeshUpdate(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string data);
         private static _onNavMeshUpdate _onNavMeshUpdateFunc;
         internal static void onNavMeshUpdate(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string data)
         {
         	if (_onNavMeshUpdateFunc == null)
         	{
         		_onNavMeshUpdateFunc =
         			(_onNavMeshUpdate)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnNavPath_onNavMeshUpdate"), typeof(_onNavMeshUpdate));
         	}
         
         	 _onNavMeshUpdateFunc(thisPtr, data);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _onNavMeshUpdateBox(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string data);
         private static _onNavMeshUpdateBox _onNavMeshUpdateBoxFunc;
         internal static void onNavMeshUpdateBox(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string data)
         {
         	if (_onNavMeshUpdateBoxFunc == null)
         	{
         		_onNavMeshUpdateBoxFunc =
         			(_onNavMeshUpdateBox)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnNavPath_onNavMeshUpdateBox"), typeof(_onNavMeshUpdateBox));
         	}
         
         	 _onNavMeshUpdateBoxFunc(thisPtr, data);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _size(IntPtr thisPtr);
         private static _size _sizeFunc;
         internal static int size(IntPtr thisPtr)
         {
         	if (_sizeFunc == null)
         	{
         		_sizeFunc =
         			(_size)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnNavPath_size"), typeof(_size));
         	}
         
         	return  _sizeFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float[] _getNode(IntPtr thisPtr, int idx);
         private static _getNode _getNodeFunc;
         internal static float[] getNode(IntPtr thisPtr, int idx)
         {
         	if (_getNodeFunc == null)
         	{
         		_getNodeFunc =
         			(_getNode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnNavPath_getNode"), typeof(_getNode));
         	}
         
         	return  _getNodeFunc(thisPtr, idx);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getFlags(IntPtr thisPtr, int idx);
         private static _getFlags _getFlagsFunc;
         internal static int getFlags(IntPtr thisPtr, int idx)
         {
         	if (_getFlagsFunc == null)
         	{
         		_getFlagsFunc =
         			(_getFlags)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnNavPath_getFlags"), typeof(_getFlags));
         	}
         
         	return  _getFlagsFunc(thisPtr, idx);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float _getLength(IntPtr thisPtr);
         private static _getLength _getLengthFunc;
         internal static float getLength(IntPtr thisPtr)
         {
         	if (_getLengthFunc == null)
         	{
         		_getLengthFunc =
         			(_getLength)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnNavPath_getLength"), typeof(_getLength));
         	}
         
         	return  _getLengthFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _NavPath_create();
         private static _NavPath_create _NavPath_createFunc;
         internal static IntPtr NavPath_create()
         {
         	if (_NavPath_createFunc == null)
         	{
         		_NavPath_createFunc =
         			(_NavPath_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_NavPath_create"), typeof(_NavPath_create));
         	}
         
         	return  _NavPath_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public bool plan()
         {
            return InternalUnsafeMethods.plan(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void onNavMeshUpdate(string data)
         {
            InternalUnsafeMethods.onNavMeshUpdate(ObjectPtr->RefPtr->ObjPtr, data);
         }
      
         public void onNavMeshUpdateBox(string data)
         {
            InternalUnsafeMethods.onNavMeshUpdateBox(ObjectPtr->RefPtr->ObjPtr, data);
         }
      
         public int size()
         {
            return InternalUnsafeMethods.size(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public Point3F getNode(int idx)
         {
            return new Point3F(InternalUnsafeMethods.getNode(ObjectPtr->RefPtr->ObjPtr, idx));
         }
      
         public int getFlags(int idx)
         {
            return InternalUnsafeMethods.getFlags(ObjectPtr->RefPtr->ObjPtr, idx);
         }
      
         public float getLength()
         {
            return InternalUnsafeMethods.getLength(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}