using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiControlArrayControl : GuiControl
	{
		public GuiControlArrayControl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiControlArrayControl_create());
		}

		public GuiControlArrayControl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiControlArrayControl(SimObject pObj) : base(pObj)
		{
		}

		public GuiControlArrayControl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiControlArrayControl_create();
         private static _GuiControlArrayControl_create _GuiControlArrayControl_createFunc;
         internal static IntPtr GuiControlArrayControl_create()
         {
         	if (_GuiControlArrayControl_createFunc == null)
         	{
         		_GuiControlArrayControl_createFunc =
         			(_GuiControlArrayControl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiControlArrayControl_create"), typeof(_GuiControlArrayControl_create));
         	}
         
         	return  _GuiControlArrayControl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}