using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class Projectile : GameBase
	{
		public Projectile()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.Projectile_create());
		}

		public Projectile(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public Projectile(SimObject pObj) : base(pObj)
		{
		}

		public Projectile(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _presimulate(IntPtr thisPtr, float seconds);
         private static _presimulate _presimulateFunc;
         internal static void presimulate(IntPtr thisPtr, float seconds)
         {
         	if (_presimulateFunc == null)
         	{
         		_presimulateFunc =
         			(_presimulate)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnProjectile_presimulate"), typeof(_presimulate));
         	}
         
         	 _presimulateFunc(thisPtr, seconds);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _Projectile_create();
         private static _Projectile_create _Projectile_createFunc;
         internal static IntPtr Projectile_create()
         {
         	if (_Projectile_createFunc == null)
         	{
         		_Projectile_createFunc =
         			(_Projectile_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_Projectile_create"), typeof(_Projectile_create));
         	}
         
         	return  _Projectile_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void presimulate(float seconds = 1.0f)
         {
            InternalUnsafeMethods.presimulate(ObjectPtr->RefPtr->ObjPtr, seconds);
         }
      
      
      #endregion

	}
}