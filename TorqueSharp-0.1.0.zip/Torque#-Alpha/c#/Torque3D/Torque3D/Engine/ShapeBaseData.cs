using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ShapeBaseData : GameBaseData
	{
		public ShapeBaseData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ShapeBaseData_create());
		}

		public ShapeBaseData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ShapeBaseData(SimObject pObj) : base(pObj)
		{
		}

		public ShapeBaseData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _checkDeployPos(IntPtr thisPtr, InternalTransformStruct txfm);
         private static _checkDeployPos _checkDeployPosFunc;
         internal static bool checkDeployPos(IntPtr thisPtr, InternalTransformStruct txfm)
         {
         	if (_checkDeployPosFunc == null)
         	{
         		_checkDeployPosFunc =
         			(_checkDeployPos)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnShapeBaseData_checkDeployPos"), typeof(_checkDeployPos));
         	}
         
         	return  _checkDeployPosFunc(thisPtr, txfm);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate InternalTransformStruct _getDeployTransform(IntPtr thisPtr, float[] pos, float[] normal);
         private static _getDeployTransform _getDeployTransformFunc;
         internal static InternalTransformStruct getDeployTransform(IntPtr thisPtr, float[] pos, float[] normal)
         {
         	if (_getDeployTransformFunc == null)
         	{
         		_getDeployTransformFunc =
         			(_getDeployTransform)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnShapeBaseData_getDeployTransform"), typeof(_getDeployTransform));
         	}
         
         	return  _getDeployTransformFunc(thisPtr, pos, normal);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ShapeBaseData_create();
         private static _ShapeBaseData_create _ShapeBaseData_createFunc;
         internal static IntPtr ShapeBaseData_create()
         {
         	if (_ShapeBaseData_createFunc == null)
         	{
         		_ShapeBaseData_createFunc =
         			(_ShapeBaseData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ShapeBaseData_create"), typeof(_ShapeBaseData_create));
         	}
         
         	return  _ShapeBaseData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public bool checkDeployPos(TransformF txfm)
         {
            return InternalUnsafeMethods.checkDeployPos(ObjectPtr->RefPtr->ObjPtr, txfm.ToStruct());
         }
      
         public TransformF getDeployTransform(Point3F pos, Point3F normal)
         {
            return new TransformF(InternalUnsafeMethods.getDeployTransform(ObjectPtr->RefPtr->ObjPtr, pos.ToArray(), normal.ToArray()));
         }
      
      
      #endregion

	}
}