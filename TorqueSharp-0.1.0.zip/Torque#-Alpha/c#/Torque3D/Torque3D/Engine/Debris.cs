using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class Debris : GameBase
	{
		public Debris()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.Debris_create());
		}

		public Debris(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public Debris(SimObject pObj) : base(pObj)
		{
		}

		public Debris(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _init(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string inputPosition, [MarshalAs(UnmanagedType.LPWStr)]string inputVelocity);
         private static _init _initFunc;
         internal static bool init(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string inputPosition, [MarshalAs(UnmanagedType.LPWStr)]string inputVelocity)
         {
         	if (_initFunc == null)
         	{
         		_initFunc =
         			(_init)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnDebris_init"), typeof(_init));
         	}
         
         	return  _initFunc(thisPtr, inputPosition, inputVelocity);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _Debris_create();
         private static _Debris_create _Debris_createFunc;
         internal static IntPtr Debris_create()
         {
         	if (_Debris_createFunc == null)
         	{
         		_Debris_createFunc =
         			(_Debris_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_Debris_create"), typeof(_Debris_create));
         	}
         
         	return  _Debris_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public bool init(string inputPosition = "1.0 1.0 1.0", string inputVelocity = "1.0 0.0 0.0")
         {
            return InternalUnsafeMethods.init(ObjectPtr->RefPtr->ObjPtr, inputPosition, inputVelocity);
         }
      
      
      #endregion

	}
}