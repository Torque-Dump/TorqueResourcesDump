using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class WaterObject : SceneObject
	{
		public WaterObject()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.WaterObject_create());
		}

		public WaterObject(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public WaterObject(SimObject pObj) : base(pObj)
		{
		}

		public WaterObject(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _WaterObject_create();
         private static _WaterObject_create _WaterObject_createFunc;
         internal static IntPtr WaterObject_create()
         {
         	if (_WaterObject_createFunc == null)
         	{
         		_WaterObject_createFunc =
         			(_WaterObject_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_WaterObject_create"), typeof(_WaterObject_create));
         	}
         
         	return  _WaterObject_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}