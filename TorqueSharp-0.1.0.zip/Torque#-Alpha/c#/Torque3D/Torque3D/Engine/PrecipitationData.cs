using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class PrecipitationData : GameBaseData
	{
		public PrecipitationData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.PrecipitationData_create());
		}

		public PrecipitationData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public PrecipitationData(SimObject pObj) : base(pObj)
		{
		}

		public PrecipitationData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _PrecipitationData_create();
         private static _PrecipitationData_create _PrecipitationData_createFunc;
         internal static IntPtr PrecipitationData_create()
         {
         	if (_PrecipitationData_createFunc == null)
         	{
         		_PrecipitationData_createFunc =
         			(_PrecipitationData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_PrecipitationData_create"), typeof(_PrecipitationData_create));
         	}
         
         	return  _PrecipitationData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}