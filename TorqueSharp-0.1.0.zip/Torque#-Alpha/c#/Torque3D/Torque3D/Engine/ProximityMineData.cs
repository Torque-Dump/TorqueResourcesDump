using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ProximityMineData : ItemData
	{
		public ProximityMineData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ProximityMineData_create());
		}

		public ProximityMineData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ProximityMineData(SimObject pObj) : base(pObj)
		{
		}

		public ProximityMineData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ProximityMineData_create();
         private static _ProximityMineData_create _ProximityMineData_createFunc;
         internal static IntPtr ProximityMineData_create()
         {
         	if (_ProximityMineData_createFunc == null)
         	{
         		_ProximityMineData_createFunc =
         			(_ProximityMineData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ProximityMineData_create"), typeof(_ProximityMineData_create));
         	}
         
         	return  _ProximityMineData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}