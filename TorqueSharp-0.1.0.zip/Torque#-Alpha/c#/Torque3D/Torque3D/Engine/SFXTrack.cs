using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class SFXTrack : SimDataBlock
	{
		public SFXTrack()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.SFXTrack_create());
		}

		public SFXTrack(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public SFXTrack(SimObject pObj) : base(pObj)
		{
		}

		public SFXTrack(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _SFXTrack_create();
         private static _SFXTrack_create _SFXTrack_createFunc;
         internal static IntPtr SFXTrack_create()
         {
         	if (_SFXTrack_createFunc == null)
         	{
         		_SFXTrack_createFunc =
         			(_SFXTrack_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_SFXTrack_create"), typeof(_SFXTrack_create));
         	}
         
         	return  _SFXTrack_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}