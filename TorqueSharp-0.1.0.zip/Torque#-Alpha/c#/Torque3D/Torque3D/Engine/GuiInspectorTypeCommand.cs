using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiInspectorTypeCommand : GuiInspectorField
	{
		public GuiInspectorTypeCommand()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiInspectorTypeCommand_create());
		}

		public GuiInspectorTypeCommand(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiInspectorTypeCommand(SimObject pObj) : base(pObj)
		{
		}

		public GuiInspectorTypeCommand(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiInspectorTypeCommand_create();
         private static _GuiInspectorTypeCommand_create _GuiInspectorTypeCommand_createFunc;
         internal static IntPtr GuiInspectorTypeCommand_create()
         {
         	if (_GuiInspectorTypeCommand_createFunc == null)
         	{
         		_GuiInspectorTypeCommand_createFunc =
         			(_GuiInspectorTypeCommand_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiInspectorTypeCommand_create"), typeof(_GuiInspectorTypeCommand_create));
         	}
         
         	return  _GuiInspectorTypeCommand_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}