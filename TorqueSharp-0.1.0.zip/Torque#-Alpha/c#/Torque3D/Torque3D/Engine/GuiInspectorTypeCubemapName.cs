using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiInspectorTypeCubemapName : GuiInspectorTypeMenuBase
	{
		public GuiInspectorTypeCubemapName()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiInspectorTypeCubemapName_create());
		}

		public GuiInspectorTypeCubemapName(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiInspectorTypeCubemapName(SimObject pObj) : base(pObj)
		{
		}

		public GuiInspectorTypeCubemapName(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiInspectorTypeCubemapName_create();
         private static _GuiInspectorTypeCubemapName_create _GuiInspectorTypeCubemapName_createFunc;
         internal static IntPtr GuiInspectorTypeCubemapName_create()
         {
         	if (_GuiInspectorTypeCubemapName_createFunc == null)
         	{
         		_GuiInspectorTypeCubemapName_createFunc =
         			(_GuiInspectorTypeCubemapName_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiInspectorTypeCubemapName_create"), typeof(_GuiInspectorTypeCubemapName_create));
         	}
         
         	return  _GuiInspectorTypeCubemapName_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}