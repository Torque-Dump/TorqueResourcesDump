using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiTabBookCtrl : GuiContainer
	{
		public GuiTabBookCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiTabBookCtrl_create());
		}

		public GuiTabBookCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiTabBookCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiTabBookCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _addPage(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string title);
         private static _addPage _addPageFunc;
         internal static void addPage(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string title)
         {
         	if (_addPageFunc == null)
         	{
         		_addPageFunc =
         			(_addPage)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiTabBookCtrl_addPage"), typeof(_addPage));
         	}
         
         	 _addPageFunc(thisPtr, title);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _selectPage(IntPtr thisPtr, int index);
         private static _selectPage _selectPageFunc;
         internal static void selectPage(IntPtr thisPtr, int index)
         {
         	if (_selectPageFunc == null)
         	{
         		_selectPageFunc =
         			(_selectPage)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiTabBookCtrl_selectPage"), typeof(_selectPage));
         	}
         
         	 _selectPageFunc(thisPtr, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getSelectedPage(IntPtr thisPtr);
         private static _getSelectedPage _getSelectedPageFunc;
         internal static int getSelectedPage(IntPtr thisPtr)
         {
         	if (_getSelectedPageFunc == null)
         	{
         		_getSelectedPageFunc =
         			(_getSelectedPage)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiTabBookCtrl_getSelectedPage"), typeof(_getSelectedPage));
         	}
         
         	return  _getSelectedPageFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiTabBookCtrl_create();
         private static _GuiTabBookCtrl_create _GuiTabBookCtrl_createFunc;
         internal static IntPtr GuiTabBookCtrl_create()
         {
         	if (_GuiTabBookCtrl_createFunc == null)
         	{
         		_GuiTabBookCtrl_createFunc =
         			(_GuiTabBookCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiTabBookCtrl_create"), typeof(_GuiTabBookCtrl_create));
         	}
         
         	return  _GuiTabBookCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void addPage(string title = "")
         {
            InternalUnsafeMethods.addPage(ObjectPtr->RefPtr->ObjPtr, title);
         }
      
         public void selectPage(int index)
         {
            InternalUnsafeMethods.selectPage(ObjectPtr->RefPtr->ObjPtr, index);
         }
      
         public int getSelectedPage()
         {
            return InternalUnsafeMethods.getSelectedPage(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}