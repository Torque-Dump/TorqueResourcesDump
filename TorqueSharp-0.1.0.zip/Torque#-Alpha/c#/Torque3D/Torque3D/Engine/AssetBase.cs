using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class AssetBase : SimObject
	{
		public AssetBase()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.AssetBase_create());
		}

		public AssetBase(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public AssetBase(SimObject pObj) : base(pObj)
		{
		}

		public AssetBase(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _refreshAsset(IntPtr thisPtr);
         private static _refreshAsset _refreshAssetFunc;
         internal static void refreshAsset(IntPtr thisPtr)
         {
         	if (_refreshAssetFunc == null)
         	{
         		_refreshAssetFunc =
         			(_refreshAsset)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetBase_refreshAsset"), typeof(_refreshAsset));
         	}
         
         	 _refreshAssetFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getAssetId(IntPtr thisPtr);
         private static _getAssetId _getAssetIdFunc;
         internal static IntPtr getAssetId(IntPtr thisPtr)
         {
         	if (_getAssetIdFunc == null)
         	{
         		_getAssetIdFunc =
         			(_getAssetId)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnAssetBase_getAssetId"), typeof(_getAssetId));
         	}
         
         	return  _getAssetIdFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _AssetBase_create();
         private static _AssetBase_create _AssetBase_createFunc;
         internal static IntPtr AssetBase_create()
         {
         	if (_AssetBase_createFunc == null)
         	{
         		_AssetBase_createFunc =
         			(_AssetBase_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_AssetBase_create"), typeof(_AssetBase_create));
         	}
         
         	return  _AssetBase_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void refreshAsset()
         {
            InternalUnsafeMethods.refreshAsset(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public string getAssetId()
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getAssetId(ObjectPtr->RefPtr->ObjPtr));
         }
      
      
      #endregion

	}
}