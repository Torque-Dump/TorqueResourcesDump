using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ExplosionData : GameBaseData
	{
		public ExplosionData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ExplosionData_create());
		}

		public ExplosionData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ExplosionData(SimObject pObj) : base(pObj)
		{
		}

		public ExplosionData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ExplosionData_create();
         private static _ExplosionData_create _ExplosionData_createFunc;
         internal static IntPtr ExplosionData_create()
         {
         	if (_ExplosionData_createFunc == null)
         	{
         		_ExplosionData_createFunc =
         			(_ExplosionData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ExplosionData_create"), typeof(_ExplosionData_create));
         	}
         
         	return  _ExplosionData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}