using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class WaterBlock : WaterObject
	{
		public WaterBlock()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.WaterBlock_create());
		}

		public WaterBlock(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public WaterBlock(SimObject pObj) : base(pObj)
		{
		}

		public WaterBlock(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _WaterBlock_create();
         private static _WaterBlock_create _WaterBlock_createFunc;
         internal static IntPtr WaterBlock_create()
         {
         	if (_WaterBlock_createFunc == null)
         	{
         		_WaterBlock_createFunc =
         			(_WaterBlock_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_WaterBlock_create"), typeof(_WaterBlock_create));
         	}
         
         	return  _WaterBlock_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}