using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class Lightning : GameBase
	{
		public Lightning()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.Lightning_create());
		}

		public Lightning(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public Lightning(SimObject pObj) : base(pObj)
		{
		}

		public Lightning(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _warningFlashes(IntPtr thisPtr);
         private static _warningFlashes _warningFlashesFunc;
         internal static void warningFlashes(IntPtr thisPtr)
         {
         	if (_warningFlashesFunc == null)
         	{
         		_warningFlashesFunc =
         			(_warningFlashes)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnLightning_warningFlashes"), typeof(_warningFlashes));
         	}
         
         	 _warningFlashesFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _strikeRandomPoint(IntPtr thisPtr);
         private static _strikeRandomPoint _strikeRandomPointFunc;
         internal static void strikeRandomPoint(IntPtr thisPtr)
         {
         	if (_strikeRandomPointFunc == null)
         	{
         		_strikeRandomPointFunc =
         			(_strikeRandomPoint)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnLightning_strikeRandomPoint"), typeof(_strikeRandomPoint));
         	}
         
         	 _strikeRandomPointFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _strikeObject(IntPtr thisPtr, IntPtr pSB);
         private static _strikeObject _strikeObjectFunc;
         internal static void strikeObject(IntPtr thisPtr, IntPtr pSB)
         {
         	if (_strikeObjectFunc == null)
         	{
         		_strikeObjectFunc =
         			(_strikeObject)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnLightning_strikeObject"), typeof(_strikeObject));
         	}
         
         	 _strikeObjectFunc(thisPtr, pSB);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _Lightning_create();
         private static _Lightning_create _Lightning_createFunc;
         internal static IntPtr Lightning_create()
         {
         	if (_Lightning_createFunc == null)
         	{
         		_Lightning_createFunc =
         			(_Lightning_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_Lightning_create"), typeof(_Lightning_create));
         	}
         
         	return  _Lightning_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void warningFlashes()
         {
            InternalUnsafeMethods.warningFlashes(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void strikeRandomPoint()
         {
            InternalUnsafeMethods.strikeRandomPoint(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void strikeObject(ShapeBase pSB)
         {
            InternalUnsafeMethods.strikeObject(ObjectPtr->RefPtr->ObjPtr, pSB.ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}