using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class AITurretShapeData : TurretShapeData
	{
		public AITurretShapeData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.AITurretShapeData_create());
		}

		public AITurretShapeData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public AITurretShapeData(SimObject pObj) : base(pObj)
		{
		}

		public AITurretShapeData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _AITurretShapeData_create();
         private static _AITurretShapeData_create _AITurretShapeData_createFunc;
         internal static IntPtr AITurretShapeData_create()
         {
         	if (_AITurretShapeData_createFunc == null)
         	{
         		_AITurretShapeData_createFunc =
         			(_AITurretShapeData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_AITurretShapeData_create"), typeof(_AITurretShapeData_create));
         	}
         
         	return  _AITurretShapeData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}