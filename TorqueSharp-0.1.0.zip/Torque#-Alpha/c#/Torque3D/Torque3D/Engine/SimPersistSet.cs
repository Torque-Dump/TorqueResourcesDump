using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class SimPersistSet : SimSet
	{
		public SimPersistSet()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.SimPersistSet_create());
		}

		public SimPersistSet(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public SimPersistSet(SimObject pObj) : base(pObj)
		{
		}

		public SimPersistSet(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _resolvePersistentIds(IntPtr thisPtr);
         private static _resolvePersistentIds _resolvePersistentIdsFunc;
         internal static void resolvePersistentIds(IntPtr thisPtr)
         {
         	if (_resolvePersistentIdsFunc == null)
         	{
         		_resolvePersistentIdsFunc =
         			(_resolvePersistentIds)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnSimPersistSet_resolvePersistentIds"), typeof(_resolvePersistentIds));
         	}
         
         	 _resolvePersistentIdsFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _SimPersistSet_create();
         private static _SimPersistSet_create _SimPersistSet_createFunc;
         internal static IntPtr SimPersistSet_create()
         {
         	if (_SimPersistSet_createFunc == null)
         	{
         		_SimPersistSet_createFunc =
         			(_SimPersistSet_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_SimPersistSet_create"), typeof(_SimPersistSet_create));
         	}
         
         	return  _SimPersistSet_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void resolvePersistentIds()
         {
            InternalUnsafeMethods.resolvePersistentIds(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}