using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ScriptMsgListener : SimObject
	{
		public ScriptMsgListener()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ScriptMsgListener_create());
		}

		public ScriptMsgListener(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ScriptMsgListener(SimObject pObj) : base(pObj)
		{
		}

		public ScriptMsgListener(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ScriptMsgListener_create();
         private static _ScriptMsgListener_create _ScriptMsgListener_createFunc;
         internal static IntPtr ScriptMsgListener_create()
         {
         	if (_ScriptMsgListener_createFunc == null)
         	{
         		_ScriptMsgListener_createFunc =
         			(_ScriptMsgListener_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ScriptMsgListener_create"), typeof(_ScriptMsgListener_create));
         	}
         
         	return  _ScriptMsgListener_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}