using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiContainer : GuiControl
	{
		public GuiContainer()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiContainer_create());
		}

		public GuiContainer(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiContainer(SimObject pObj) : base(pObj)
		{
		}

		public GuiContainer(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiContainer_create();
         private static _GuiContainer_create _GuiContainer_createFunc;
         internal static IntPtr GuiContainer_create()
         {
         	if (_GuiContainer_createFunc == null)
         	{
         		_GuiContainer_createFunc =
         			(_GuiContainer_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiContainer_create"), typeof(_GuiContainer_create));
         	}
         
         	return  _GuiContainer_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}