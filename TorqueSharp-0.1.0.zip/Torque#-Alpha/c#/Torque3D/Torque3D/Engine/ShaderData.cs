using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ShaderData : SimObject
	{
		public ShaderData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ShaderData_create());
		}

		public ShaderData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ShaderData(SimObject pObj) : base(pObj)
		{
		}

		public ShaderData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _reload(IntPtr thisPtr);
         private static _reload _reloadFunc;
         internal static void reload(IntPtr thisPtr)
         {
         	if (_reloadFunc == null)
         	{
         		_reloadFunc =
         			(_reload)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnShaderData_reload"), typeof(_reload));
         	}
         
         	 _reloadFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ShaderData_create();
         private static _ShaderData_create _ShaderData_createFunc;
         internal static IntPtr ShaderData_create()
         {
         	if (_ShaderData_createFunc == null)
         	{
         		_ShaderData_createFunc =
         			(_ShaderData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ShaderData_create"), typeof(_ShaderData_create));
         	}
         
         	return  _ShaderData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void reload()
         {
            InternalUnsafeMethods.reload(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}