using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiInspectorTypeSFXTrackName : GuiInspectorDatablockField
	{
		public GuiInspectorTypeSFXTrackName()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiInspectorTypeSFXTrackName_create());
		}

		public GuiInspectorTypeSFXTrackName(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiInspectorTypeSFXTrackName(SimObject pObj) : base(pObj)
		{
		}

		public GuiInspectorTypeSFXTrackName(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiInspectorTypeSFXTrackName_create();
         private static _GuiInspectorTypeSFXTrackName_create _GuiInspectorTypeSFXTrackName_createFunc;
         internal static IntPtr GuiInspectorTypeSFXTrackName_create()
         {
         	if (_GuiInspectorTypeSFXTrackName_createFunc == null)
         	{
         		_GuiInspectorTypeSFXTrackName_createFunc =
         			(_GuiInspectorTypeSFXTrackName_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiInspectorTypeSFXTrackName_create"), typeof(_GuiInspectorTypeSFXTrackName_create));
         	}
         
         	return  _GuiInspectorTypeSFXTrackName_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}