using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class Camera : ShapeBase
	{
		public Camera()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.Camera_create());
		}

		public Camera(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public Camera(SimObject pObj) : base(pObj)
		{
		}

		public Camera(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate CameraMotionMode _getMode(IntPtr thisPtr);
         private static _getMode _getModeFunc;
         internal static CameraMotionMode getMode(IntPtr thisPtr)
         {
         	if (_getModeFunc == null)
         	{
         		_getModeFunc =
         			(_getMode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_getMode"), typeof(_getMode));
         	}
         
         	return  _getModeFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float[] _getPosition(IntPtr thisPtr);
         private static _getPosition _getPositionFunc;
         internal static float[] getPosition(IntPtr thisPtr)
         {
         	if (_getPositionFunc == null)
         	{
         		_getPositionFunc =
         			(_getPosition)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_getPosition"), typeof(_getPosition));
         	}
         
         	return  _getPositionFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float[] _getRotation(IntPtr thisPtr);
         private static _getRotation _getRotationFunc;
         internal static float[] getRotation(IntPtr thisPtr)
         {
         	if (_getRotationFunc == null)
         	{
         		_getRotationFunc =
         			(_getRotation)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_getRotation"), typeof(_getRotation));
         	}
         
         	return  _getRotationFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setRotation(IntPtr thisPtr, float[] rot);
         private static _setRotation _setRotationFunc;
         internal static void setRotation(IntPtr thisPtr, float[] rot)
         {
         	if (_setRotationFunc == null)
         	{
         		_setRotationFunc =
         			(_setRotation)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setRotation"), typeof(_setRotation));
         	}
         
         	 _setRotationFunc(thisPtr, rot);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float[] _getOffset(IntPtr thisPtr);
         private static _getOffset _getOffsetFunc;
         internal static float[] getOffset(IntPtr thisPtr)
         {
         	if (_getOffsetFunc == null)
         	{
         		_getOffsetFunc =
         			(_getOffset)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_getOffset"), typeof(_getOffset));
         	}
         
         	return  _getOffsetFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setOffset(IntPtr thisPtr, float[] offset);
         private static _setOffset _setOffsetFunc;
         internal static void setOffset(IntPtr thisPtr, float[] offset)
         {
         	if (_setOffsetFunc == null)
         	{
         		_setOffsetFunc =
         			(_setOffset)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setOffset"), typeof(_setOffset));
         	}
         
         	 _setOffsetFunc(thisPtr, offset);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setOrbitMode(IntPtr thisPtr, IntPtr orbitObject, InternalTransformStruct orbitPoint, float minDistance, float maxDistance, float initDistance, bool ownClientObj, float[] offset, bool locked);
         private static _setOrbitMode _setOrbitModeFunc;
         internal static void setOrbitMode(IntPtr thisPtr, IntPtr orbitObject, InternalTransformStruct orbitPoint, float minDistance, float maxDistance, float initDistance, bool ownClientObj, float[] offset, bool locked)
         {
         	if (_setOrbitModeFunc == null)
         	{
         		_setOrbitModeFunc =
         			(_setOrbitMode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setOrbitMode"), typeof(_setOrbitMode));
         	}
         
         	 _setOrbitModeFunc(thisPtr, orbitObject, orbitPoint, minDistance, maxDistance, initDistance, ownClientObj, offset, locked);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _setOrbitObject(IntPtr thisPtr, IntPtr orbitObject, float[] rotation, float minDistance, float maxDistance, float initDistance, bool ownClientObject, float[] offset, bool locked);
         private static _setOrbitObject _setOrbitObjectFunc;
         internal static bool setOrbitObject(IntPtr thisPtr, IntPtr orbitObject, float[] rotation, float minDistance, float maxDistance, float initDistance, bool ownClientObject, float[] offset, bool locked)
         {
         	if (_setOrbitObjectFunc == null)
         	{
         		_setOrbitObjectFunc =
         			(_setOrbitObject)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setOrbitObject"), typeof(_setOrbitObject));
         	}
         
         	return  _setOrbitObjectFunc(thisPtr, orbitObject, rotation, minDistance, maxDistance, initDistance, ownClientObject, offset, locked);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setOrbitPoint(IntPtr thisPtr, InternalTransformStruct orbitPoint, float minDistance, float maxDistance, float initDistance, float[] offset, bool locked);
         private static _setOrbitPoint _setOrbitPointFunc;
         internal static void setOrbitPoint(IntPtr thisPtr, InternalTransformStruct orbitPoint, float minDistance, float maxDistance, float initDistance, float[] offset, bool locked)
         {
         	if (_setOrbitPointFunc == null)
         	{
         		_setOrbitPointFunc =
         			(_setOrbitPoint)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setOrbitPoint"), typeof(_setOrbitPoint));
         	}
         
         	 _setOrbitPointFunc(thisPtr, orbitPoint, minDistance, maxDistance, initDistance, offset, locked);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _setTrackObject(IntPtr thisPtr, IntPtr trackObject, float[] offset);
         private static _setTrackObject _setTrackObjectFunc;
         internal static bool setTrackObject(IntPtr thisPtr, IntPtr trackObject, float[] offset)
         {
         	if (_setTrackObjectFunc == null)
         	{
         		_setTrackObjectFunc =
         			(_setTrackObject)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setTrackObject"), typeof(_setTrackObject));
         	}
         
         	return  _setTrackObjectFunc(thisPtr, trackObject, offset);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setEditOrbitMode(IntPtr thisPtr);
         private static _setEditOrbitMode _setEditOrbitModeFunc;
         internal static void setEditOrbitMode(IntPtr thisPtr)
         {
         	if (_setEditOrbitModeFunc == null)
         	{
         		_setEditOrbitModeFunc =
         			(_setEditOrbitMode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setEditOrbitMode"), typeof(_setEditOrbitMode));
         	}
         
         	 _setEditOrbitModeFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setFlyMode(IntPtr thisPtr);
         private static _setFlyMode _setFlyModeFunc;
         internal static void setFlyMode(IntPtr thisPtr)
         {
         	if (_setFlyModeFunc == null)
         	{
         		_setFlyModeFunc =
         			(_setFlyMode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setFlyMode"), typeof(_setFlyMode));
         	}
         
         	 _setFlyModeFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setNewtonFlyMode(IntPtr thisPtr);
         private static _setNewtonFlyMode _setNewtonFlyModeFunc;
         internal static void setNewtonFlyMode(IntPtr thisPtr)
         {
         	if (_setNewtonFlyModeFunc == null)
         	{
         		_setNewtonFlyModeFunc =
         			(_setNewtonFlyMode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setNewtonFlyMode"), typeof(_setNewtonFlyMode));
         	}
         
         	 _setNewtonFlyModeFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _isRotationDamped(IntPtr thisPtr);
         private static _isRotationDamped _isRotationDampedFunc;
         internal static bool isRotationDamped(IntPtr thisPtr)
         {
         	if (_isRotationDampedFunc == null)
         	{
         		_isRotationDampedFunc =
         			(_isRotationDamped)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_isRotationDamped"), typeof(_isRotationDamped));
         	}
         
         	return  _isRotationDampedFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float[] _getAngularVelocity(IntPtr thisPtr);
         private static _getAngularVelocity _getAngularVelocityFunc;
         internal static float[] getAngularVelocity(IntPtr thisPtr)
         {
         	if (_getAngularVelocityFunc == null)
         	{
         		_getAngularVelocityFunc =
         			(_getAngularVelocity)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_getAngularVelocity"), typeof(_getAngularVelocity));
         	}
         
         	return  _getAngularVelocityFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setAngularVelocity(IntPtr thisPtr, float[] velocity);
         private static _setAngularVelocity _setAngularVelocityFunc;
         internal static void setAngularVelocity(IntPtr thisPtr, float[] velocity)
         {
         	if (_setAngularVelocityFunc == null)
         	{
         		_setAngularVelocityFunc =
         			(_setAngularVelocity)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setAngularVelocity"), typeof(_setAngularVelocity));
         	}
         
         	 _setAngularVelocityFunc(thisPtr, velocity);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setAngularForce(IntPtr thisPtr, float force);
         private static _setAngularForce _setAngularForceFunc;
         internal static void setAngularForce(IntPtr thisPtr, float force)
         {
         	if (_setAngularForceFunc == null)
         	{
         		_setAngularForceFunc =
         			(_setAngularForce)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setAngularForce"), typeof(_setAngularForce));
         	}
         
         	 _setAngularForceFunc(thisPtr, force);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setAngularDrag(IntPtr thisPtr, float drag);
         private static _setAngularDrag _setAngularDragFunc;
         internal static void setAngularDrag(IntPtr thisPtr, float drag)
         {
         	if (_setAngularDragFunc == null)
         	{
         		_setAngularDragFunc =
         			(_setAngularDrag)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setAngularDrag"), typeof(_setAngularDrag));
         	}
         
         	 _setAngularDragFunc(thisPtr, drag);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setMass(IntPtr thisPtr, float mass);
         private static _setMass _setMassFunc;
         internal static void setMass(IntPtr thisPtr, float mass)
         {
         	if (_setMassFunc == null)
         	{
         		_setMassFunc =
         			(_setMass)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setMass"), typeof(_setMass));
         	}
         
         	 _setMassFunc(thisPtr, mass);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float[] _getVelocity(IntPtr thisPtr);
         private static _getVelocity _getVelocityFunc;
         internal static float[] getVelocity(IntPtr thisPtr)
         {
         	if (_getVelocityFunc == null)
         	{
         		_getVelocityFunc =
         			(_getVelocity)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_getVelocity"), typeof(_getVelocity));
         	}
         
         	return  _getVelocityFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setVelocity(IntPtr thisPtr, float[] velocity);
         private static _setVelocity _setVelocityFunc;
         internal static void setVelocity(IntPtr thisPtr, float[] velocity)
         {
         	if (_setVelocityFunc == null)
         	{
         		_setVelocityFunc =
         			(_setVelocity)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setVelocity"), typeof(_setVelocity));
         	}
         
         	 _setVelocityFunc(thisPtr, velocity);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setDrag(IntPtr thisPtr, float drag);
         private static _setDrag _setDragFunc;
         internal static void setDrag(IntPtr thisPtr, float drag)
         {
         	if (_setDragFunc == null)
         	{
         		_setDragFunc =
         			(_setDrag)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setDrag"), typeof(_setDrag));
         	}
         
         	 _setDragFunc(thisPtr, drag);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setFlyForce(IntPtr thisPtr, float force);
         private static _setFlyForce _setFlyForceFunc;
         internal static void setFlyForce(IntPtr thisPtr, float force)
         {
         	if (_setFlyForceFunc == null)
         	{
         		_setFlyForceFunc =
         			(_setFlyForce)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setFlyForce"), typeof(_setFlyForce));
         	}
         
         	 _setFlyForceFunc(thisPtr, force);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setSpeedMultiplier(IntPtr thisPtr, float multiplier);
         private static _setSpeedMultiplier _setSpeedMultiplierFunc;
         internal static void setSpeedMultiplier(IntPtr thisPtr, float multiplier)
         {
         	if (_setSpeedMultiplierFunc == null)
         	{
         		_setSpeedMultiplierFunc =
         			(_setSpeedMultiplier)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setSpeedMultiplier"), typeof(_setSpeedMultiplier));
         	}
         
         	 _setSpeedMultiplierFunc(thisPtr, multiplier);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setBrakeMultiplier(IntPtr thisPtr, float multiplier);
         private static _setBrakeMultiplier _setBrakeMultiplierFunc;
         internal static void setBrakeMultiplier(IntPtr thisPtr, float multiplier)
         {
         	if (_setBrakeMultiplierFunc == null)
         	{
         		_setBrakeMultiplierFunc =
         			(_setBrakeMultiplier)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setBrakeMultiplier"), typeof(_setBrakeMultiplier));
         	}
         
         	 _setBrakeMultiplierFunc(thisPtr, multiplier);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _isEditOrbitMode(IntPtr thisPtr);
         private static _isEditOrbitMode _isEditOrbitModeFunc;
         internal static bool isEditOrbitMode(IntPtr thisPtr)
         {
         	if (_isEditOrbitModeFunc == null)
         	{
         		_isEditOrbitModeFunc =
         			(_isEditOrbitMode)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_isEditOrbitMode"), typeof(_isEditOrbitMode));
         	}
         
         	return  _isEditOrbitModeFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setValidEditOrbitPoint(IntPtr thisPtr, bool validPoint);
         private static _setValidEditOrbitPoint _setValidEditOrbitPointFunc;
         internal static void setValidEditOrbitPoint(IntPtr thisPtr, bool validPoint)
         {
         	if (_setValidEditOrbitPointFunc == null)
         	{
         		_setValidEditOrbitPointFunc =
         			(_setValidEditOrbitPoint)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setValidEditOrbitPoint"), typeof(_setValidEditOrbitPoint));
         	}
         
         	 _setValidEditOrbitPointFunc(thisPtr, validPoint);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setEditOrbitPoint(IntPtr thisPtr, float[] point);
         private static _setEditOrbitPoint _setEditOrbitPointFunc;
         internal static void setEditOrbitPoint(IntPtr thisPtr, float[] point)
         {
         	if (_setEditOrbitPointFunc == null)
         	{
         		_setEditOrbitPointFunc =
         			(_setEditOrbitPoint)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_setEditOrbitPoint"), typeof(_setEditOrbitPoint));
         	}
         
         	 _setEditOrbitPointFunc(thisPtr, point);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _autoFitRadius(IntPtr thisPtr, float radius);
         private static _autoFitRadius _autoFitRadiusFunc;
         internal static void autoFitRadius(IntPtr thisPtr, float radius)
         {
         	if (_autoFitRadiusFunc == null)
         	{
         		_autoFitRadiusFunc =
         			(_autoFitRadius)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_autoFitRadius"), typeof(_autoFitRadius));
         	}
         
         	 _autoFitRadiusFunc(thisPtr, radius);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _lookAt(IntPtr thisPtr, float[] point);
         private static _lookAt _lookAtFunc;
         internal static void lookAt(IntPtr thisPtr, float[] point)
         {
         	if (_lookAtFunc == null)
         	{
         		_lookAtFunc =
         			(_lookAt)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCamera_lookAt"), typeof(_lookAt));
         	}
         
         	 _lookAtFunc(thisPtr, point);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _Camera_create();
         private static _Camera_create _Camera_createFunc;
         internal static IntPtr Camera_create()
         {
         	if (_Camera_createFunc == null)
         	{
         		_Camera_createFunc =
         			(_Camera_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_Camera_create"), typeof(_Camera_create));
         	}
         
         	return  _Camera_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public CameraMotionMode getMode()
         {
            return InternalUnsafeMethods.getMode(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public Point3F getPosition()
         {
            return new Point3F(InternalUnsafeMethods.getPosition(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public Point3F getRotation()
         {
            return new Point3F(InternalUnsafeMethods.getRotation(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public void setRotation(Point3F rot)
         {
            InternalUnsafeMethods.setRotation(ObjectPtr->RefPtr->ObjPtr, rot.ToArray());
         }
      
         public Point3F getOffset()
         {
            return new Point3F(InternalUnsafeMethods.getOffset(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public void setOffset(Point3F offset)
         {
            InternalUnsafeMethods.setOffset(ObjectPtr->RefPtr->ObjPtr, offset.ToArray());
         }
      
         public void setOrbitMode(GameBase orbitObject, TransformF orbitPoint, float minDistance, float maxDistance, float initDistance, bool ownClientObj = false, Point3F offset = null, bool locked = false)
         {
            if (offset == null) offset = Point3F.Zero;
                  InternalUnsafeMethods.setOrbitMode(ObjectPtr->RefPtr->ObjPtr, orbitObject.ObjectPtr->RefPtr->ObjPtr, orbitPoint.ToStruct(), minDistance, maxDistance, initDistance, ownClientObj, offset.ToArray(), locked);
         }
      
         public bool setOrbitObject(GameBase orbitObject, VectorF rotation, float minDistance, float maxDistance, float initDistance, bool ownClientObject = false, Point3F offset = null, bool locked = false)
         {
            if (offset == null) offset = Point3F.Zero;
                  return InternalUnsafeMethods.setOrbitObject(ObjectPtr->RefPtr->ObjPtr, orbitObject.ObjectPtr->RefPtr->ObjPtr, rotation.ToArray(), minDistance, maxDistance, initDistance, ownClientObject, offset.ToArray(), locked);
         }
      
         public void setOrbitPoint(TransformF orbitPoint, float minDistance, float maxDistance, float initDistance, Point3F offset = null, bool locked = false)
         {
            if (offset == null) offset = Point3F.Zero;
                  InternalUnsafeMethods.setOrbitPoint(ObjectPtr->RefPtr->ObjPtr, orbitPoint.ToStruct(), minDistance, maxDistance, initDistance, offset.ToArray(), locked);
         }
      
         public bool setTrackObject(GameBase trackObject, Point3F offset = null)
         {
            if (offset == null) offset = Point3F.Zero;
                  return InternalUnsafeMethods.setTrackObject(ObjectPtr->RefPtr->ObjPtr, trackObject.ObjectPtr->RefPtr->ObjPtr, offset.ToArray());
         }
      
         public void setEditOrbitMode()
         {
            InternalUnsafeMethods.setEditOrbitMode(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setFlyMode()
         {
            InternalUnsafeMethods.setFlyMode(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setNewtonFlyMode()
         {
            InternalUnsafeMethods.setNewtonFlyMode(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public bool isRotationDamped()
         {
            return InternalUnsafeMethods.isRotationDamped(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public VectorF getAngularVelocity()
         {
            return new VectorF(InternalUnsafeMethods.getAngularVelocity(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public void setAngularVelocity(VectorF velocity)
         {
            InternalUnsafeMethods.setAngularVelocity(ObjectPtr->RefPtr->ObjPtr, velocity.ToArray());
         }
      
         public void setAngularForce(float force)
         {
            InternalUnsafeMethods.setAngularForce(ObjectPtr->RefPtr->ObjPtr, force);
         }
      
         public void setAngularDrag(float drag)
         {
            InternalUnsafeMethods.setAngularDrag(ObjectPtr->RefPtr->ObjPtr, drag);
         }
      
         public void setMass(float mass)
         {
            InternalUnsafeMethods.setMass(ObjectPtr->RefPtr->ObjPtr, mass);
         }
      
         public VectorF getVelocity()
         {
            return new VectorF(InternalUnsafeMethods.getVelocity(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public void setVelocity(VectorF velocity)
         {
            InternalUnsafeMethods.setVelocity(ObjectPtr->RefPtr->ObjPtr, velocity.ToArray());
         }
      
         public void setDrag(float drag)
         {
            InternalUnsafeMethods.setDrag(ObjectPtr->RefPtr->ObjPtr, drag);
         }
      
         public void setFlyForce(float force)
         {
            InternalUnsafeMethods.setFlyForce(ObjectPtr->RefPtr->ObjPtr, force);
         }
      
         public void setSpeedMultiplier(float multiplier)
         {
            InternalUnsafeMethods.setSpeedMultiplier(ObjectPtr->RefPtr->ObjPtr, multiplier);
         }
      
         public void setBrakeMultiplier(float multiplier)
         {
            InternalUnsafeMethods.setBrakeMultiplier(ObjectPtr->RefPtr->ObjPtr, multiplier);
         }
      
         public bool isEditOrbitMode()
         {
            return InternalUnsafeMethods.isEditOrbitMode(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setValidEditOrbitPoint(bool validPoint)
         {
            InternalUnsafeMethods.setValidEditOrbitPoint(ObjectPtr->RefPtr->ObjPtr, validPoint);
         }
      
         public void setEditOrbitPoint(Point3F point)
         {
            InternalUnsafeMethods.setEditOrbitPoint(ObjectPtr->RefPtr->ObjPtr, point.ToArray());
         }
      
         public void autoFitRadius(float radius)
         {
            InternalUnsafeMethods.autoFitRadius(ObjectPtr->RefPtr->ObjPtr, radius);
         }
      
         public void lookAt(Point3F point)
         {
            InternalUnsafeMethods.lookAt(ObjectPtr->RefPtr->ObjPtr, point.ToArray());
         }
      
      
      #endregion

	}
}