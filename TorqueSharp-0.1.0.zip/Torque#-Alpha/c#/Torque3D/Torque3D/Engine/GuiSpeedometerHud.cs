using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiSpeedometerHud : GuiBitmapCtrl
	{
		public GuiSpeedometerHud()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiSpeedometerHud_create());
		}

		public GuiSpeedometerHud(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiSpeedometerHud(SimObject pObj) : base(pObj)
		{
		}

		public GuiSpeedometerHud(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiSpeedometerHud_create();
         private static _GuiSpeedometerHud_create _GuiSpeedometerHud_createFunc;
         internal static IntPtr GuiSpeedometerHud_create()
         {
         	if (_GuiSpeedometerHud_createFunc == null)
         	{
         		_GuiSpeedometerHud_createFunc =
         			(_GuiSpeedometerHud_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiSpeedometerHud_create"), typeof(_GuiSpeedometerHud_create));
         	}
         
         	return  _GuiSpeedometerHud_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}