using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class OcclusionVolume : SceneObject
	{
		public OcclusionVolume()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.OcclusionVolume_create());
		}

		public OcclusionVolume(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public OcclusionVolume(SimObject pObj) : base(pObj)
		{
		}

		public OcclusionVolume(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _OcclusionVolume_create();
         private static _OcclusionVolume_create _OcclusionVolume_createFunc;
         internal static IntPtr OcclusionVolume_create()
         {
         	if (_OcclusionVolume_createFunc == null)
         	{
         		_OcclusionVolume_createFunc =
         			(_OcclusionVolume_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_OcclusionVolume_create"), typeof(_OcclusionVolume_create));
         	}
         
         	return  _OcclusionVolume_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}