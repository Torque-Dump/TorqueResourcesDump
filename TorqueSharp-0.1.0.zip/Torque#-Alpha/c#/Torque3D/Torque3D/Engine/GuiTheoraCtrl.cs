using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiTheoraCtrl : GuiControl
	{
		public GuiTheoraCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiTheoraCtrl_create());
		}

		public GuiTheoraCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiTheoraCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiTheoraCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setFile(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string filename);
         private static _setFile _setFileFunc;
         internal static void setFile(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string filename)
         {
         	if (_setFileFunc == null)
         	{
         		_setFileFunc =
         			(_setFile)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiTheoraCtrl_setFile"), typeof(_setFile));
         	}
         
         	 _setFileFunc(thisPtr, filename);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _play(IntPtr thisPtr);
         private static _play _playFunc;
         internal static void play(IntPtr thisPtr)
         {
         	if (_playFunc == null)
         	{
         		_playFunc =
         			(_play)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiTheoraCtrl_play"), typeof(_play));
         	}
         
         	 _playFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _pause(IntPtr thisPtr);
         private static _pause _pauseFunc;
         internal static void pause(IntPtr thisPtr)
         {
         	if (_pauseFunc == null)
         	{
         		_pauseFunc =
         			(_pause)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiTheoraCtrl_pause"), typeof(_pause));
         	}
         
         	 _pauseFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _stop(IntPtr thisPtr);
         private static _stop _stopFunc;
         internal static void stop(IntPtr thisPtr)
         {
         	if (_stopFunc == null)
         	{
         		_stopFunc =
         			(_stop)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiTheoraCtrl_stop"), typeof(_stop));
         	}
         
         	 _stopFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float _getCurrentTime(IntPtr thisPtr);
         private static _getCurrentTime _getCurrentTimeFunc;
         internal static float getCurrentTime(IntPtr thisPtr)
         {
         	if (_getCurrentTimeFunc == null)
         	{
         		_getCurrentTimeFunc =
         			(_getCurrentTime)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiTheoraCtrl_getCurrentTime"), typeof(_getCurrentTime));
         	}
         
         	return  _getCurrentTimeFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _isPlaybackDone(IntPtr thisPtr);
         private static _isPlaybackDone _isPlaybackDoneFunc;
         internal static bool isPlaybackDone(IntPtr thisPtr)
         {
         	if (_isPlaybackDoneFunc == null)
         	{
         		_isPlaybackDoneFunc =
         			(_isPlaybackDone)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiTheoraCtrl_isPlaybackDone"), typeof(_isPlaybackDone));
         	}
         
         	return  _isPlaybackDoneFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiTheoraCtrl_create();
         private static _GuiTheoraCtrl_create _GuiTheoraCtrl_createFunc;
         internal static IntPtr GuiTheoraCtrl_create()
         {
         	if (_GuiTheoraCtrl_createFunc == null)
         	{
         		_GuiTheoraCtrl_createFunc =
         			(_GuiTheoraCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiTheoraCtrl_create"), typeof(_GuiTheoraCtrl_create));
         	}
         
         	return  _GuiTheoraCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void setFile(string filename)
         {
            InternalUnsafeMethods.setFile(ObjectPtr->RefPtr->ObjPtr, filename);
         }
      
         public void play()
         {
            InternalUnsafeMethods.play(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void pause()
         {
            InternalUnsafeMethods.pause(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void stop()
         {
            InternalUnsafeMethods.stop(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public float getCurrentTime()
         {
            return InternalUnsafeMethods.getCurrentTime(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public bool isPlaybackDone()
         {
            return InternalUnsafeMethods.isPlaybackDone(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}