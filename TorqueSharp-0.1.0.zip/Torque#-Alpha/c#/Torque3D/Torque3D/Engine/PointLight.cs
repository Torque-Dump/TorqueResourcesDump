using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class PointLight : LightBase
	{
		public PointLight()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.PointLight_create());
		}

		public PointLight(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public PointLight(SimObject pObj) : base(pObj)
		{
		}

		public PointLight(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _PointLight_create();
         private static _PointLight_create _PointLight_createFunc;
         internal static IntPtr PointLight_create()
         {
         	if (_PointLight_createFunc == null)
         	{
         		_PointLight_createFunc =
         			(_PointLight_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_PointLight_create"), typeof(_PointLight_create));
         	}
         
         	return  _PointLight_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}