using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class CoverPoint : SceneObject
	{
		public CoverPoint()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.CoverPoint_create());
		}

		public CoverPoint(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public CoverPoint(SimObject pObj) : base(pObj)
		{
		}

		public CoverPoint(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _isOccupied(IntPtr thisPtr);
         private static _isOccupied _isOccupiedFunc;
         internal static bool isOccupied(IntPtr thisPtr)
         {
         	if (_isOccupiedFunc == null)
         	{
         		_isOccupiedFunc =
         			(_isOccupied)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnCoverPoint_isOccupied"), typeof(_isOccupied));
         	}
         
         	return  _isOccupiedFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _CoverPoint_create();
         private static _CoverPoint_create _CoverPoint_createFunc;
         internal static IntPtr CoverPoint_create()
         {
         	if (_CoverPoint_createFunc == null)
         	{
         		_CoverPoint_createFunc =
         			(_CoverPoint_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_CoverPoint_create"), typeof(_CoverPoint_create));
         	}
         
         	return  _CoverPoint_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public bool isOccupied()
         {
            return InternalUnsafeMethods.isOccupied(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}