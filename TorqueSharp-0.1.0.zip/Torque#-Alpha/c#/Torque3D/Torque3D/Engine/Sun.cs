using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class Sun : SceneObject
	{
		public Sun()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.Sun_create());
		}

		public Sun(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public Sun(SimObject pObj) : base(pObj)
		{
		}

		public Sun(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _apply(IntPtr thisPtr);
         private static _apply _applyFunc;
         internal static void apply(IntPtr thisPtr)
         {
         	if (_applyFunc == null)
         	{
         		_applyFunc =
         			(_apply)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnSun_apply"), typeof(_apply));
         	}
         
         	 _applyFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _animate(IntPtr thisPtr, float duration, float startAzimuth, float endAzimuth, float startElevation, float endElevation);
         private static _animate _animateFunc;
         internal static void animate(IntPtr thisPtr, float duration, float startAzimuth, float endAzimuth, float startElevation, float endElevation)
         {
         	if (_animateFunc == null)
         	{
         		_animateFunc =
         			(_animate)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnSun_animate"), typeof(_animate));
         	}
         
         	 _animateFunc(thisPtr, duration, startAzimuth, endAzimuth, startElevation, endElevation);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _Sun_create();
         private static _Sun_create _Sun_createFunc;
         internal static IntPtr Sun_create()
         {
         	if (_Sun_createFunc == null)
         	{
         		_Sun_createFunc =
         			(_Sun_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_Sun_create"), typeof(_Sun_create));
         	}
         
         	return  _Sun_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void apply()
         {
            InternalUnsafeMethods.apply(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void animate(float duration, float startAzimuth, float endAzimuth, float startElevation, float endElevation)
         {
            InternalUnsafeMethods.animate(ObjectPtr->RefPtr->ObjPtr, duration, startAzimuth, endAzimuth, startElevation, endElevation);
         }
      
      
      #endregion

	}
}