using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiConsole : GuiArrayCtrl
	{
		public GuiConsole()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiConsole_create());
		}

		public GuiConsole(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiConsole(SimObject pObj) : base(pObj)
		{
		}

		public GuiConsole(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiConsole_create();
         private static _GuiConsole_create _GuiConsole_createFunc;
         internal static IntPtr GuiConsole_create()
         {
         	if (_GuiConsole_createFunc == null)
         	{
         		_GuiConsole_createFunc =
         			(_GuiConsole_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiConsole_create"), typeof(_GuiConsole_create));
         	}
         
         	return  _GuiConsole_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}