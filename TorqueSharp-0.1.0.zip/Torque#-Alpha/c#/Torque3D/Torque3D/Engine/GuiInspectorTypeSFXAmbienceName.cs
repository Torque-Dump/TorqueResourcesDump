using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiInspectorTypeSFXAmbienceName : GuiInspectorDatablockField
	{
		public GuiInspectorTypeSFXAmbienceName()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiInspectorTypeSFXAmbienceName_create());
		}

		public GuiInspectorTypeSFXAmbienceName(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiInspectorTypeSFXAmbienceName(SimObject pObj) : base(pObj)
		{
		}

		public GuiInspectorTypeSFXAmbienceName(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiInspectorTypeSFXAmbienceName_create();
         private static _GuiInspectorTypeSFXAmbienceName_create _GuiInspectorTypeSFXAmbienceName_createFunc;
         internal static IntPtr GuiInspectorTypeSFXAmbienceName_create()
         {
         	if (_GuiInspectorTypeSFXAmbienceName_createFunc == null)
         	{
         		_GuiInspectorTypeSFXAmbienceName_createFunc =
         			(_GuiInspectorTypeSFXAmbienceName_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiInspectorTypeSFXAmbienceName_create"), typeof(_GuiInspectorTypeSFXAmbienceName_create));
         	}
         
         	return  _GuiInspectorTypeSFXAmbienceName_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}