using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiInspectorTypeTerrainMaterialIndex : GuiInspectorTypeMaterialName
	{
		public GuiInspectorTypeTerrainMaterialIndex()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiInspectorTypeTerrainMaterialIndex_create());
		}

		public GuiInspectorTypeTerrainMaterialIndex(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiInspectorTypeTerrainMaterialIndex(SimObject pObj) : base(pObj)
		{
		}

		public GuiInspectorTypeTerrainMaterialIndex(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiInspectorTypeTerrainMaterialIndex_create();
         private static _GuiInspectorTypeTerrainMaterialIndex_create _GuiInspectorTypeTerrainMaterialIndex_createFunc;
         internal static IntPtr GuiInspectorTypeTerrainMaterialIndex_create()
         {
         	if (_GuiInspectorTypeTerrainMaterialIndex_createFunc == null)
         	{
         		_GuiInspectorTypeTerrainMaterialIndex_createFunc =
         			(_GuiInspectorTypeTerrainMaterialIndex_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiInspectorTypeTerrainMaterialIndex_create"), typeof(_GuiInspectorTypeTerrainMaterialIndex_create));
         	}
         
         	return  _GuiInspectorTypeTerrainMaterialIndex_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}