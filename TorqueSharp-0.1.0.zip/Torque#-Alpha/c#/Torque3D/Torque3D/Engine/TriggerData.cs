using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class TriggerData : GameBaseData
	{
		public TriggerData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.TriggerData_create());
		}

		public TriggerData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public TriggerData(SimObject pObj) : base(pObj)
		{
		}

		public TriggerData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _TriggerData_create();
         private static _TriggerData_create _TriggerData_createFunc;
         internal static IntPtr TriggerData_create()
         {
         	if (_TriggerData_createFunc == null)
         	{
         		_TriggerData_createFunc =
         			(_TriggerData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_TriggerData_create"), typeof(_TriggerData_create));
         	}
         
         	return  _TriggerData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}