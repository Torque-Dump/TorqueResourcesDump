using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GFXSamplerStateData : SimObject
	{
		public GFXSamplerStateData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GFXSamplerStateData_create());
		}

		public GFXSamplerStateData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GFXSamplerStateData(SimObject pObj) : base(pObj)
		{
		}

		public GFXSamplerStateData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GFXSamplerStateData_create();
         private static _GFXSamplerStateData_create _GFXSamplerStateData_createFunc;
         internal static IntPtr GFXSamplerStateData_create()
         {
         	if (_GFXSamplerStateData_createFunc == null)
         	{
         		_GFXSamplerStateData_createFunc =
         			(_GFXSamplerStateData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GFXSamplerStateData_create"), typeof(_GFXSamplerStateData_create));
         	}
         
         	return  _GFXSamplerStateData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}