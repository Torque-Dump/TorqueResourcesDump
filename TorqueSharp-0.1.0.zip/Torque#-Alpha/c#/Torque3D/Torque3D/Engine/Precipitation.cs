using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class Precipitation : GameBase
	{
		public Precipitation()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.Precipitation_create());
		}

		public Precipitation(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public Precipitation(SimObject pObj) : base(pObj)
		{
		}

		public Precipitation(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setPercentage(IntPtr thisPtr, float percentage);
         private static _setPercentage _setPercentageFunc;
         internal static void setPercentage(IntPtr thisPtr, float percentage)
         {
         	if (_setPercentageFunc == null)
         	{
         		_setPercentageFunc =
         			(_setPercentage)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnPrecipitation_setPercentage"), typeof(_setPercentage));
         	}
         
         	 _setPercentageFunc(thisPtr, percentage);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _modifyStorm(IntPtr thisPtr, float percentage, float seconds);
         private static _modifyStorm _modifyStormFunc;
         internal static void modifyStorm(IntPtr thisPtr, float percentage, float seconds)
         {
         	if (_modifyStormFunc == null)
         	{
         		_modifyStormFunc =
         			(_modifyStorm)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnPrecipitation_modifyStorm"), typeof(_modifyStorm));
         	}
         
         	 _modifyStormFunc(thisPtr, percentage, seconds);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setTurbulence(IntPtr thisPtr, float max, float speed, float seconds);
         private static _setTurbulence _setTurbulenceFunc;
         internal static void setTurbulence(IntPtr thisPtr, float max, float speed, float seconds)
         {
         	if (_setTurbulenceFunc == null)
         	{
         		_setTurbulenceFunc =
         			(_setTurbulence)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnPrecipitation_setTurbulence"), typeof(_setTurbulence));
         	}
         
         	 _setTurbulenceFunc(thisPtr, max, speed, seconds);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _Precipitation_create();
         private static _Precipitation_create _Precipitation_createFunc;
         internal static IntPtr Precipitation_create()
         {
         	if (_Precipitation_createFunc == null)
         	{
         		_Precipitation_createFunc =
         			(_Precipitation_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_Precipitation_create"), typeof(_Precipitation_create));
         	}
         
         	return  _Precipitation_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void setPercentage(float percentage = 1.0f)
         {
            InternalUnsafeMethods.setPercentage(ObjectPtr->RefPtr->ObjPtr, percentage);
         }
      
         public void modifyStorm(float percentage = 1.0f, float seconds = 5.0f)
         {
            InternalUnsafeMethods.modifyStorm(ObjectPtr->RefPtr->ObjPtr, percentage, seconds);
         }
      
         public void setTurbulence(float max = 1.0f, float speed = 5.0f, float seconds = 5.0f)
         {
            InternalUnsafeMethods.setTurbulence(ObjectPtr->RefPtr->ObjPtr, max, speed, seconds);
         }
      
      
      #endregion

	}
}