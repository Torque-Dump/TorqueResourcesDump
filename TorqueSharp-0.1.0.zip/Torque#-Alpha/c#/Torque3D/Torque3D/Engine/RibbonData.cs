using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class RibbonData : GameBaseData
	{
		public RibbonData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.RibbonData_create());
		}

		public RibbonData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public RibbonData(SimObject pObj) : base(pObj)
		{
		}

		public RibbonData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _RibbonData_create();
         private static _RibbonData_create _RibbonData_createFunc;
         internal static IntPtr RibbonData_create()
         {
         	if (_RibbonData_createFunc == null)
         	{
         		_RibbonData_createFunc =
         			(_RibbonData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_RibbonData_create"), typeof(_RibbonData_create));
         	}
         
         	return  _RibbonData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}