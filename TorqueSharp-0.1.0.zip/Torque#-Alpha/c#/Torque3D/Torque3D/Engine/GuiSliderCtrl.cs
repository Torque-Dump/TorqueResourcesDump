using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiSliderCtrl : GuiControl
	{
		public GuiSliderCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiSliderCtrl_create());
		}

		public GuiSliderCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiSliderCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiSliderCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate float _getValue(IntPtr thisPtr);
         private static _getValue _getValueFunc;
         internal static float getValue(IntPtr thisPtr)
         {
         	if (_getValueFunc == null)
         	{
         		_getValueFunc =
         			(_getValue)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiSliderCtrl_getValue"), typeof(_getValue));
         	}
         
         	return  _getValueFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setValue(IntPtr thisPtr, float pos, bool doCallback);
         private static _setValue _setValueFunc;
         internal static void setValue(IntPtr thisPtr, float pos, bool doCallback)
         {
         	if (_setValueFunc == null)
         	{
         		_setValueFunc =
         			(_setValue)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiSliderCtrl_setValue"), typeof(_setValue));
         	}
         
         	 _setValueFunc(thisPtr, pos, doCallback);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _isThumbBeingDragged(IntPtr thisPtr);
         private static _isThumbBeingDragged _isThumbBeingDraggedFunc;
         internal static bool isThumbBeingDragged(IntPtr thisPtr)
         {
         	if (_isThumbBeingDraggedFunc == null)
         	{
         		_isThumbBeingDraggedFunc =
         			(_isThumbBeingDragged)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiSliderCtrl_isThumbBeingDragged"), typeof(_isThumbBeingDragged));
         	}
         
         	return  _isThumbBeingDraggedFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiSliderCtrl_create();
         private static _GuiSliderCtrl_create _GuiSliderCtrl_createFunc;
         internal static IntPtr GuiSliderCtrl_create()
         {
         	if (_GuiSliderCtrl_createFunc == null)
         	{
         		_GuiSliderCtrl_createFunc =
         			(_GuiSliderCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiSliderCtrl_create"), typeof(_GuiSliderCtrl_create));
         	}
         
         	return  _GuiSliderCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public float getValue()
         {
            return InternalUnsafeMethods.getValue(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setValue(float pos, bool doCallback = false)
         {
            InternalUnsafeMethods.setValue(ObjectPtr->RefPtr->ObjPtr, pos, doCallback);
         }
      
         public bool isThumbBeingDragged()
         {
            return InternalUnsafeMethods.isThumbBeingDragged(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}