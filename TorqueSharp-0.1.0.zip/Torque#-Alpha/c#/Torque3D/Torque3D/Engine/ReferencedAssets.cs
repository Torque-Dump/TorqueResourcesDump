using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ReferencedAssets : SimObject
	{
		public ReferencedAssets()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ReferencedAssets_create());
		}

		public ReferencedAssets(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ReferencedAssets(SimObject pObj) : base(pObj)
		{
		}

		public ReferencedAssets(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ReferencedAssets_create();
         private static _ReferencedAssets_create _ReferencedAssets_createFunc;
         internal static IntPtr ReferencedAssets_create()
         {
         	if (_ReferencedAssets_createFunc == null)
         	{
         		_ReferencedAssets_createFunc =
         			(_ReferencedAssets_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ReferencedAssets_create"), typeof(_ReferencedAssets_create));
         	}
         
         	return  _ReferencedAssets_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}