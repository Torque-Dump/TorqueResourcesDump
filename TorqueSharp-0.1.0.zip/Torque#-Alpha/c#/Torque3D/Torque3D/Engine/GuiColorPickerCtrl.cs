using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiColorPickerCtrl : GuiControl
	{
		public GuiColorPickerCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiColorPickerCtrl_create());
		}

		public GuiColorPickerCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiColorPickerCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiColorPickerCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int[] _getSelectorPos(IntPtr thisPtr);
         private static _getSelectorPos _getSelectorPosFunc;
         internal static int[] getSelectorPos(IntPtr thisPtr)
         {
         	if (_getSelectorPosFunc == null)
         	{
         		_getSelectorPosFunc =
         			(_getSelectorPos)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiColorPickerCtrl_getSelectorPos"), typeof(_getSelectorPos));
         	}
         
         	return  _getSelectorPosFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setSelectorPos(IntPtr thisPtr, int[] newPos);
         private static _setSelectorPos _setSelectorPosFunc;
         internal static void setSelectorPos(IntPtr thisPtr, int[] newPos)
         {
         	if (_setSelectorPosFunc == null)
         	{
         		_setSelectorPosFunc =
         			(_setSelectorPos)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiColorPickerCtrl_setSelectorPos"), typeof(_setSelectorPos));
         	}
         
         	 _setSelectorPosFunc(thisPtr, newPos);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _updateColor(IntPtr thisPtr);
         private static _updateColor _updateColorFunc;
         internal static void updateColor(IntPtr thisPtr)
         {
         	if (_updateColorFunc == null)
         	{
         		_updateColorFunc =
         			(_updateColor)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiColorPickerCtrl_updateColor"), typeof(_updateColor));
         	}
         
         	 _updateColorFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setSelectorColor(IntPtr thisPtr, InternalColorFStruct color);
         private static _setSelectorColor _setSelectorColorFunc;
         internal static void setSelectorColor(IntPtr thisPtr, InternalColorFStruct color)
         {
         	if (_setSelectorColorFunc == null)
         	{
         		_setSelectorColorFunc =
         			(_setSelectorColor)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiColorPickerCtrl_setSelectorColor"), typeof(_setSelectorColor));
         	}
         
         	 _setSelectorColorFunc(thisPtr, color);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiColorPickerCtrl_create();
         private static _GuiColorPickerCtrl_create _GuiColorPickerCtrl_createFunc;
         internal static IntPtr GuiColorPickerCtrl_create()
         {
         	if (_GuiColorPickerCtrl_createFunc == null)
         	{
         		_GuiColorPickerCtrl_createFunc =
         			(_GuiColorPickerCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiColorPickerCtrl_create"), typeof(_GuiColorPickerCtrl_create));
         	}
         
         	return  _GuiColorPickerCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public Point2I getSelectorPos()
         {
            return new Point2I(InternalUnsafeMethods.getSelectorPos(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public void setSelectorPos(Point2I newPos)
         {
            InternalUnsafeMethods.setSelectorPos(ObjectPtr->RefPtr->ObjPtr, newPos.ToArray());
         }
      
         public void updateColor()
         {
            InternalUnsafeMethods.updateColor(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setSelectorColor(ColorF color)
         {
            InternalUnsafeMethods.setSelectorColor(ObjectPtr->RefPtr->ObjPtr, color.ToStruct());
         }
      
      
      #endregion

	}
}