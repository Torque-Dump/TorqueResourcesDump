using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiMaterialCtrl : GuiContainer
	{
		public GuiMaterialCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiMaterialCtrl_create());
		}

		public GuiMaterialCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiMaterialCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiMaterialCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate bool _setMaterial(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string materialName);
         private static _setMaterial _setMaterialFunc;
         internal static bool setMaterial(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string materialName)
         {
         	if (_setMaterialFunc == null)
         	{
         		_setMaterialFunc =
         			(_setMaterial)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiMaterialCtrl_setMaterial"), typeof(_setMaterial));
         	}
         
         	return  _setMaterialFunc(thisPtr, materialName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiMaterialCtrl_create();
         private static _GuiMaterialCtrl_create _GuiMaterialCtrl_createFunc;
         internal static IntPtr GuiMaterialCtrl_create()
         {
         	if (_GuiMaterialCtrl_createFunc == null)
         	{
         		_GuiMaterialCtrl_createFunc =
         			(_GuiMaterialCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiMaterialCtrl_create"), typeof(_GuiMaterialCtrl_create));
         	}
         
         	return  _GuiMaterialCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public bool setMaterial(string materialName)
         {
            return InternalUnsafeMethods.setMaterial(ObjectPtr->RefPtr->ObjPtr, materialName);
         }
      
      
      #endregion

	}
}