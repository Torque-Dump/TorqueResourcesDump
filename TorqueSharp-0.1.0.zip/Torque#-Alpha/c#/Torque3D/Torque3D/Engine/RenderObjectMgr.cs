using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class RenderObjectMgr : RenderBinManager
	{
		public RenderObjectMgr()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.RenderObjectMgr_create());
		}

		public RenderObjectMgr(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public RenderObjectMgr(SimObject pObj) : base(pObj)
		{
		}

		public RenderObjectMgr(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _RenderObjectMgr_create();
         private static _RenderObjectMgr_create _RenderObjectMgr_createFunc;
         internal static IntPtr RenderObjectMgr_create()
         {
         	if (_RenderObjectMgr_createFunc == null)
         	{
         		_RenderObjectMgr_createFunc =
         			(_RenderObjectMgr_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_RenderObjectMgr_create"), typeof(_RenderObjectMgr_create));
         	}
         
         	return  _RenderObjectMgr_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}