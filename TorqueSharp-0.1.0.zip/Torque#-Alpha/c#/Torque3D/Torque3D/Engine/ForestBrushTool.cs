using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ForestBrushTool : ForestTool
	{
		public ForestBrushTool()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ForestBrushTool_create());
		}

		public ForestBrushTool(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ForestBrushTool(SimObject pObj) : base(pObj)
		{
		}

		public ForestBrushTool(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _collectElements(IntPtr thisPtr);
         private static _collectElements _collectElementsFunc;
         internal static void collectElements(IntPtr thisPtr)
         {
         	if (_collectElementsFunc == null)
         	{
         		_collectElementsFunc =
         			(_collectElements)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnForestBrushTool_collectElements"), typeof(_collectElements));
         	}
         
         	 _collectElementsFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ForestBrushTool_create();
         private static _ForestBrushTool_create _ForestBrushTool_createFunc;
         internal static IntPtr ForestBrushTool_create()
         {
         	if (_ForestBrushTool_createFunc == null)
         	{
         		_ForestBrushTool_createFunc =
         			(_ForestBrushTool_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ForestBrushTool_create"), typeof(_ForestBrushTool_create));
         	}
         
         	return  _ForestBrushTool_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void collectElements()
         {
            InternalUnsafeMethods.collectElements(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}