using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ScriptGroup : SimGroup
	{
		public ScriptGroup()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ScriptGroup_create());
		}

		public ScriptGroup(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ScriptGroup(SimObject pObj) : base(pObj)
		{
		}

		public ScriptGroup(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ScriptGroup_create();
         private static _ScriptGroup_create _ScriptGroup_createFunc;
         internal static IntPtr ScriptGroup_create()
         {
         	if (_ScriptGroup_createFunc == null)
         	{
         		_ScriptGroup_createFunc =
         			(_ScriptGroup_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ScriptGroup_create"), typeof(_ScriptGroup_create));
         	}
         
         	return  _ScriptGroup_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}