using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiSwatchButtonCtrl : GuiButtonBaseCtrl
	{
		public GuiSwatchButtonCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiSwatchButtonCtrl_create());
		}

		public GuiSwatchButtonCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiSwatchButtonCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiSwatchButtonCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setColor(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string newColor);
         private static _setColor _setColorFunc;
         internal static void setColor(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string newColor)
         {
         	if (_setColorFunc == null)
         	{
         		_setColorFunc =
         			(_setColor)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiSwatchButtonCtrl_setColor"), typeof(_setColor));
         	}
         
         	 _setColorFunc(thisPtr, newColor);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiSwatchButtonCtrl_create();
         private static _GuiSwatchButtonCtrl_create _GuiSwatchButtonCtrl_createFunc;
         internal static IntPtr GuiSwatchButtonCtrl_create()
         {
         	if (_GuiSwatchButtonCtrl_createFunc == null)
         	{
         		_GuiSwatchButtonCtrl_createFunc =
         			(_GuiSwatchButtonCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiSwatchButtonCtrl_create"), typeof(_GuiSwatchButtonCtrl_create));
         	}
         
         	return  _GuiSwatchButtonCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void setColor(string newColor)
         {
            InternalUnsafeMethods.setColor(ObjectPtr->RefPtr->ObjPtr, newColor);
         }
      
      
      #endregion

	}
}