using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GFXStateBlockData : SimObject
	{
		public GFXStateBlockData()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GFXStateBlockData_create());
		}

		public GFXStateBlockData(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GFXStateBlockData(SimObject pObj) : base(pObj)
		{
		}

		public GFXStateBlockData(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GFXStateBlockData_create();
         private static _GFXStateBlockData_create _GFXStateBlockData_createFunc;
         internal static IntPtr GFXStateBlockData_create()
         {
         	if (_GFXStateBlockData_createFunc == null)
         	{
         		_GFXStateBlockData_createFunc =
         			(_GFXStateBlockData_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GFXStateBlockData_create"), typeof(_GFXStateBlockData_create));
         	}
         
         	return  _GFXStateBlockData_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}