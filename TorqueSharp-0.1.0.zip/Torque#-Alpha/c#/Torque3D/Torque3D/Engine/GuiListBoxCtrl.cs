using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiListBoxCtrl : GuiControl
	{
		public GuiListBoxCtrl()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiListBoxCtrl_create());
		}

		public GuiListBoxCtrl(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiListBoxCtrl(SimObject pObj) : base(pObj)
		{
		}

		public GuiListBoxCtrl(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setMultipleSelection(IntPtr thisPtr, bool allowMultSelections);
         private static _setMultipleSelection _setMultipleSelectionFunc;
         internal static void setMultipleSelection(IntPtr thisPtr, bool allowMultSelections)
         {
         	if (_setMultipleSelectionFunc == null)
         	{
         		_setMultipleSelectionFunc =
         			(_setMultipleSelection)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_setMultipleSelection"), typeof(_setMultipleSelection));
         	}
         
         	 _setMultipleSelectionFunc(thisPtr, allowMultSelections);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _clearItems(IntPtr thisPtr);
         private static _clearItems _clearItemsFunc;
         internal static void clearItems(IntPtr thisPtr)
         {
         	if (_clearItemsFunc == null)
         	{
         		_clearItemsFunc =
         			(_clearItems)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_clearItems"), typeof(_clearItems));
         	}
         
         	 _clearItemsFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _clearSelection(IntPtr thisPtr);
         private static _clearSelection _clearSelectionFunc;
         internal static void clearSelection(IntPtr thisPtr)
         {
         	if (_clearSelectionFunc == null)
         	{
         		_clearSelectionFunc =
         			(_clearSelection)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_clearSelection"), typeof(_clearSelection));
         	}
         
         	 _clearSelectionFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setSelected(IntPtr thisPtr, int index, bool setSelected);
         private static _setSelected _setSelectedFunc;
         internal static void setSelected(IntPtr thisPtr, int index, bool setSelected)
         {
         	if (_setSelectedFunc == null)
         	{
         		_setSelectedFunc =
         			(_setSelected)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_setSelected"), typeof(_setSelected));
         	}
         
         	 _setSelectedFunc(thisPtr, index, setSelected);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getItemCount(IntPtr thisPtr);
         private static _getItemCount _getItemCountFunc;
         internal static int getItemCount(IntPtr thisPtr)
         {
         	if (_getItemCountFunc == null)
         	{
         		_getItemCountFunc =
         			(_getItemCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_getItemCount"), typeof(_getItemCount));
         	}
         
         	return  _getItemCountFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getSelCount(IntPtr thisPtr);
         private static _getSelCount _getSelCountFunc;
         internal static int getSelCount(IntPtr thisPtr)
         {
         	if (_getSelCountFunc == null)
         	{
         		_getSelCountFunc =
         			(_getSelCount)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_getSelCount"), typeof(_getSelCount));
         	}
         
         	return  _getSelCountFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getSelectedItem(IntPtr thisPtr);
         private static _getSelectedItem _getSelectedItemFunc;
         internal static int getSelectedItem(IntPtr thisPtr)
         {
         	if (_getSelectedItemFunc == null)
         	{
         		_getSelectedItemFunc =
         			(_getSelectedItem)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_getSelectedItem"), typeof(_getSelectedItem));
         	}
         
         	return  _getSelectedItemFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getSelectedItems(IntPtr thisPtr);
         private static _getSelectedItems _getSelectedItemsFunc;
         internal static IntPtr getSelectedItems(IntPtr thisPtr)
         {
         	if (_getSelectedItemsFunc == null)
         	{
         		_getSelectedItemsFunc =
         			(_getSelectedItems)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_getSelectedItems"), typeof(_getSelectedItems));
         	}
         
         	return  _getSelectedItemsFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _findItemText(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string findText, bool bCaseSensitive);
         private static _findItemText _findItemTextFunc;
         internal static int findItemText(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string findText, bool bCaseSensitive)
         {
         	if (_findItemTextFunc == null)
         	{
         		_findItemTextFunc =
         			(_findItemText)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_findItemText"), typeof(_findItemText));
         	}
         
         	return  _findItemTextFunc(thisPtr, findText, bCaseSensitive);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setCurSel(IntPtr thisPtr, int indexId);
         private static _setCurSel _setCurSelFunc;
         internal static void setCurSel(IntPtr thisPtr, int indexId)
         {
         	if (_setCurSelFunc == null)
         	{
         		_setCurSelFunc =
         			(_setCurSel)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_setCurSel"), typeof(_setCurSel));
         	}
         
         	 _setCurSelFunc(thisPtr, indexId);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setCurSelRange(IntPtr thisPtr, int indexStart, int indexStop);
         private static _setCurSelRange _setCurSelRangeFunc;
         internal static void setCurSelRange(IntPtr thisPtr, int indexStart, int indexStop)
         {
         	if (_setCurSelRangeFunc == null)
         	{
         		_setCurSelRangeFunc =
         			(_setCurSelRange)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_setCurSelRange"), typeof(_setCurSelRange));
         	}
         
         	 _setCurSelRangeFunc(thisPtr, indexStart, indexStop);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _addItem(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string newItem, [MarshalAs(UnmanagedType.LPWStr)]string color);
         private static _addItem _addItemFunc;
         internal static int addItem(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string newItem, [MarshalAs(UnmanagedType.LPWStr)]string color)
         {
         	if (_addItemFunc == null)
         	{
         		_addItemFunc =
         			(_addItem)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_addItem"), typeof(_addItem));
         	}
         
         	return  _addItemFunc(thisPtr, newItem, color);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setItemColor(IntPtr thisPtr, int index, InternalColorFStruct color);
         private static _setItemColor _setItemColorFunc;
         internal static void setItemColor(IntPtr thisPtr, int index, InternalColorFStruct color)
         {
         	if (_setItemColorFunc == null)
         	{
         		_setItemColorFunc =
         			(_setItemColor)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_setItemColor"), typeof(_setItemColor));
         	}
         
         	 _setItemColorFunc(thisPtr, index, color);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _clearItemColor(IntPtr thisPtr, int index);
         private static _clearItemColor _clearItemColorFunc;
         internal static void clearItemColor(IntPtr thisPtr, int index)
         {
         	if (_clearItemColorFunc == null)
         	{
         		_clearItemColorFunc =
         			(_clearItemColor)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_clearItemColor"), typeof(_clearItemColor));
         	}
         
         	 _clearItemColorFunc(thisPtr, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _insertItem(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string text, int index);
         private static _insertItem _insertItemFunc;
         internal static void insertItem(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string text, int index)
         {
         	if (_insertItemFunc == null)
         	{
         		_insertItemFunc =
         			(_insertItem)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_insertItem"), typeof(_insertItem));
         	}
         
         	 _insertItemFunc(thisPtr, text, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _deleteItem(IntPtr thisPtr, int itemIndex);
         private static _deleteItem _deleteItemFunc;
         internal static void deleteItem(IntPtr thisPtr, int itemIndex)
         {
         	if (_deleteItemFunc == null)
         	{
         		_deleteItemFunc =
         			(_deleteItem)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_deleteItem"), typeof(_deleteItem));
         	}
         
         	 _deleteItemFunc(thisPtr, itemIndex);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getItemText(IntPtr thisPtr, int index);
         private static _getItemText _getItemTextFunc;
         internal static IntPtr getItemText(IntPtr thisPtr, int index)
         {
         	if (_getItemTextFunc == null)
         	{
         		_getItemTextFunc =
         			(_getItemText)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_getItemText"), typeof(_getItemText));
         	}
         
         	return  _getItemTextFunc(thisPtr, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getItemObject(IntPtr thisPtr, int index);
         private static _getItemObject _getItemObjectFunc;
         internal static IntPtr getItemObject(IntPtr thisPtr, int index)
         {
         	if (_getItemObjectFunc == null)
         	{
         		_getItemObjectFunc =
         			(_getItemObject)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_getItemObject"), typeof(_getItemObject));
         	}
         
         	return  _getItemObjectFunc(thisPtr, index);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setItemText(IntPtr thisPtr, int index, [MarshalAs(UnmanagedType.LPWStr)]string newtext);
         private static _setItemText _setItemTextFunc;
         internal static void setItemText(IntPtr thisPtr, int index, [MarshalAs(UnmanagedType.LPWStr)]string newtext)
         {
         	if (_setItemTextFunc == null)
         	{
         		_setItemTextFunc =
         			(_setItemText)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_setItemText"), typeof(_setItemText));
         	}
         
         	 _setItemTextFunc(thisPtr, index, newtext);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _setItemTooltip(IntPtr thisPtr, int index, [MarshalAs(UnmanagedType.LPWStr)]string text);
         private static _setItemTooltip _setItemTooltipFunc;
         internal static void setItemTooltip(IntPtr thisPtr, int index, [MarshalAs(UnmanagedType.LPWStr)]string text)
         {
         	if (_setItemTooltipFunc == null)
         	{
         		_setItemTooltipFunc =
         			(_setItemTooltip)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_setItemTooltip"), typeof(_setItemTooltip));
         	}
         
         	 _setItemTooltipFunc(thisPtr, index, text);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate int _getLastClickItem(IntPtr thisPtr);
         private static _getLastClickItem _getLastClickItemFunc;
         internal static int getLastClickItem(IntPtr thisPtr)
         {
         	if (_getLastClickItemFunc == null)
         	{
         		_getLastClickItemFunc =
         			(_getLastClickItem)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_getLastClickItem"), typeof(_getLastClickItem));
         	}
         
         	return  _getLastClickItemFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _doMirror(IntPtr thisPtr);
         private static _doMirror _doMirrorFunc;
         internal static void doMirror(IntPtr thisPtr)
         {
         	if (_doMirrorFunc == null)
         	{
         		_doMirrorFunc =
         			(_doMirror)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_doMirror"), typeof(_doMirror));
         	}
         
         	 _doMirrorFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _addFilteredItem(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string newItem);
         private static _addFilteredItem _addFilteredItemFunc;
         internal static void addFilteredItem(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string newItem)
         {
         	if (_addFilteredItemFunc == null)
         	{
         		_addFilteredItemFunc =
         			(_addFilteredItem)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_addFilteredItem"), typeof(_addFilteredItem));
         	}
         
         	 _addFilteredItemFunc(thisPtr, newItem);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _removeFilteredItem(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string itemName);
         private static _removeFilteredItem _removeFilteredItemFunc;
         internal static void removeFilteredItem(IntPtr thisPtr, [MarshalAs(UnmanagedType.LPWStr)]string itemName)
         {
         	if (_removeFilteredItemFunc == null)
         	{
         		_removeFilteredItemFunc =
         			(_removeFilteredItem)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnGuiListBoxCtrl_removeFilteredItem"), typeof(_removeFilteredItem));
         	}
         
         	 _removeFilteredItemFunc(thisPtr, itemName);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiListBoxCtrl_create();
         private static _GuiListBoxCtrl_create _GuiListBoxCtrl_createFunc;
         internal static IntPtr GuiListBoxCtrl_create()
         {
         	if (_GuiListBoxCtrl_createFunc == null)
         	{
         		_GuiListBoxCtrl_createFunc =
         			(_GuiListBoxCtrl_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiListBoxCtrl_create"), typeof(_GuiListBoxCtrl_create));
         	}
         
         	return  _GuiListBoxCtrl_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public void setMultipleSelection(bool allowMultSelections)
         {
            InternalUnsafeMethods.setMultipleSelection(ObjectPtr->RefPtr->ObjPtr, allowMultSelections);
         }
      
         public void clearItems()
         {
            InternalUnsafeMethods.clearItems(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void clearSelection()
         {
            InternalUnsafeMethods.clearSelection(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void setSelected(int index, bool setSelected = true)
         {
            InternalUnsafeMethods.setSelected(ObjectPtr->RefPtr->ObjPtr, index, setSelected);
         }
      
         public int getItemCount()
         {
            return InternalUnsafeMethods.getItemCount(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public int getSelCount()
         {
            return InternalUnsafeMethods.getSelCount(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public int getSelectedItem()
         {
            return InternalUnsafeMethods.getSelectedItem(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public string getSelectedItems()
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getSelectedItems(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public int findItemText(string findText, bool bCaseSensitive = false)
         {
            return InternalUnsafeMethods.findItemText(ObjectPtr->RefPtr->ObjPtr, findText, bCaseSensitive);
         }
      
         public void setCurSel(int indexId)
         {
            InternalUnsafeMethods.setCurSel(ObjectPtr->RefPtr->ObjPtr, indexId);
         }
      
         public void setCurSelRange(int indexStart, int indexStop = 999999)
         {
            InternalUnsafeMethods.setCurSelRange(ObjectPtr->RefPtr->ObjPtr, indexStart, indexStop);
         }
      
         public int addItem(string newItem, string color = "")
         {
            return InternalUnsafeMethods.addItem(ObjectPtr->RefPtr->ObjPtr, newItem, color);
         }
      
         public void setItemColor(int index, ColorF color)
         {
            InternalUnsafeMethods.setItemColor(ObjectPtr->RefPtr->ObjPtr, index, color.ToStruct());
         }
      
         public void clearItemColor(int index)
         {
            InternalUnsafeMethods.clearItemColor(ObjectPtr->RefPtr->ObjPtr, index);
         }
      
         public void insertItem(string text, int index)
         {
            InternalUnsafeMethods.insertItem(ObjectPtr->RefPtr->ObjPtr, text, index);
         }
      
         public void deleteItem(int itemIndex)
         {
            InternalUnsafeMethods.deleteItem(ObjectPtr->RefPtr->ObjPtr, itemIndex);
         }
      
         public string getItemText(int index)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getItemText(ObjectPtr->RefPtr->ObjPtr, index));
         }
      
         public string getItemObject(int index)
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getItemObject(ObjectPtr->RefPtr->ObjPtr, index));
         }
      
         public void setItemText(int index, string newtext)
         {
            InternalUnsafeMethods.setItemText(ObjectPtr->RefPtr->ObjPtr, index, newtext);
         }
      
         public void setItemTooltip(int index, string text)
         {
            InternalUnsafeMethods.setItemTooltip(ObjectPtr->RefPtr->ObjPtr, index, text);
         }
      
         public int getLastClickItem()
         {
            return InternalUnsafeMethods.getLastClickItem(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void doMirror()
         {
            InternalUnsafeMethods.doMirror(ObjectPtr->RefPtr->ObjPtr);
         }
      
         public void addFilteredItem(string newItem)
         {
            InternalUnsafeMethods.addFilteredItem(ObjectPtr->RefPtr->ObjPtr, newItem);
         }
      
         public void removeFilteredItem(string itemName)
         {
            InternalUnsafeMethods.removeFilteredItem(ObjectPtr->RefPtr->ObjPtr, itemName);
         }
      
      
      #endregion

	}
}