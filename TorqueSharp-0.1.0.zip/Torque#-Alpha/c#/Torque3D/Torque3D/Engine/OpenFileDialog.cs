using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class OpenFileDialog : FileDialog
	{
		public OpenFileDialog()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.OpenFileDialog_create());
		}

		public OpenFileDialog(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public OpenFileDialog(SimObject pObj) : base(pObj)
		{
		}

		public OpenFileDialog(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _OpenFileDialog_create();
         private static _OpenFileDialog_create _OpenFileDialog_createFunc;
         internal static IntPtr OpenFileDialog_create()
         {
         	if (_OpenFileDialog_createFunc == null)
         	{
         		_OpenFileDialog_createFunc =
         			(_OpenFileDialog_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_OpenFileDialog_create"), typeof(_OpenFileDialog_create));
         	}
         
         	return  _OpenFileDialog_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}