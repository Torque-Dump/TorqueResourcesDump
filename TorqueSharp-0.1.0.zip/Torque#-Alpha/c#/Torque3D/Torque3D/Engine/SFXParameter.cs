using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class SFXParameter : SimObject
	{
		public SFXParameter()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.SFXParameter_create());
		}

		public SFXParameter(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public SFXParameter(SimObject pObj) : base(pObj)
		{
		}

		public SFXParameter(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _getParameterName(IntPtr thisPtr);
         private static _getParameterName _getParameterNameFunc;
         internal static IntPtr getParameterName(IntPtr thisPtr)
         {
         	if (_getParameterNameFunc == null)
         	{
         		_getParameterNameFunc =
         			(_getParameterName)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnSFXParameter_getParameterName"), typeof(_getParameterName));
         	}
         
         	return  _getParameterNameFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate void _reset(IntPtr thisPtr);
         private static _reset _resetFunc;
         internal static void reset(IntPtr thisPtr)
         {
         	if (_resetFunc == null)
         	{
         		_resetFunc =
         			(_reset)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fnSFXParameter_reset"), typeof(_reset));
         	}
         
         	 _resetFunc(thisPtr);
         }
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _SFXParameter_create();
         private static _SFXParameter_create _SFXParameter_createFunc;
         internal static IntPtr SFXParameter_create()
         {
         	if (_SFXParameter_createFunc == null)
         	{
         		_SFXParameter_createFunc =
         			(_SFXParameter_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_SFXParameter_create"), typeof(_SFXParameter_create));
         	}
         
         	return  _SFXParameter_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
         public string getParameterName()
         {
            return Marshal.PtrToStringUni(InternalUnsafeMethods.getParameterName(ObjectPtr->RefPtr->ObjPtr));
         }
      
         public void reset()
         {
            InternalUnsafeMethods.reset(ObjectPtr->RefPtr->ObjPtr);
         }
      
      
      #endregion

	}
}