using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class GuiHealthTextHud : GuiControl
	{
		public GuiHealthTextHud()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.GuiHealthTextHud_create());
		}

		public GuiHealthTextHud(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public GuiHealthTextHud(SimObject pObj) : base(pObj)
		{
		}

		public GuiHealthTextHud(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _GuiHealthTextHud_create();
         private static _GuiHealthTextHud_create _GuiHealthTextHud_createFunc;
         internal static IntPtr GuiHealthTextHud_create()
         {
         	if (_GuiHealthTextHud_createFunc == null)
         	{
         		_GuiHealthTextHud_createFunc =
         			(_GuiHealthTextHud_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_GuiHealthTextHud_create"), typeof(_GuiHealthTextHud_create));
         	}
         
         	return  _GuiHealthTextHud_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}