using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Torque3D.Engine;
using Torque3D.Util;

namespace Torque3D
{
	public unsafe class ModuleMergeDefinition : SimObject
	{
		public ModuleMergeDefinition()
		{
			ObjectPtr = Sim.WrapObject(InternalUnsafeMethods.ModuleMergeDefinition_create());
		}

		public ModuleMergeDefinition(Sim.SimObjectPtr* pObjPtr) : base(pObjPtr)
		{
		}

		public ModuleMergeDefinition(SimObject pObj) : base(pObj)
		{
		}

		public ModuleMergeDefinition(IntPtr pObjPtr) : base(pObjPtr)
		{
		}

      #region UnsafeNativeMethods
      
      new internal struct InternalUnsafeMethods
      {
      
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         private delegate IntPtr _ModuleMergeDefinition_create();
         private static _ModuleMergeDefinition_create _ModuleMergeDefinition_createFunc;
         internal static IntPtr ModuleMergeDefinition_create()
         {
         	if (_ModuleMergeDefinition_createFunc == null)
         	{
         		_ModuleMergeDefinition_createFunc =
         			(_ModuleMergeDefinition_create)Marshal.GetDelegateForFunctionPointer(Torque3D.DllLoadUtils.GetProcAddress(Torque3D.Torque3DLibHandle,
         				"fn_ModuleMergeDefinition_create"), typeof(_ModuleMergeDefinition_create));
         	}
         
         	return  _ModuleMergeDefinition_createFunc();
         }
      
      }
      
      #endregion


      #region Functions
      
      
      
      #endregion

	}
}