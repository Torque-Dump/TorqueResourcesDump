﻿using System;
using System.Runtime.InteropServices;

namespace Torque3D.Util
{
   [StructLayout(LayoutKind.Sequential)]
   internal struct InternalRectSpacingIStruct
   {
      public float left;
      public float top;
      public float right;
      public float bottom;
   }

   public class RectSpacingI
   {
      public float Left { get; set; }
      public float Top { get; set; }
      public float Right { get; set; }
      public float Bottom { get; set; }

      public RectSpacingI(float left, float top, float right, float bottom)
      {
         Left = left;
         Top = top;
         Right = right;
         Bottom = bottom;
      }

      internal RectSpacingI(InternalRectSpacingIStruct rectSpacingI)
      {
         Left = rectSpacingI.left;
         Top = rectSpacingI.top;
         Right = rectSpacingI.right;
         Bottom = rectSpacingI.bottom;
      }

      internal InternalRectSpacingIStruct ToStruct()
      {
         return new InternalRectSpacingIStruct
         {
            left = Left,
            top = Top,
            right = Right,
            bottom = Bottom
         };
      }
   }
}
