﻿using System;

namespace Torque3D.Util
{
   public class MatrixF
   {
      public float[] M { get; set; }
      public static MatrixF Identity = new MatrixF(new []
      {
         1.0f, 0.0f, 0.0f, 0.0f,
         0.0f, 1.0f, 0.0f, 0.0f,
         0.0f, 0.0f, 1.0f, 0.0f,
         0.0f, 0.0f, 0.0f, 1.0f
      });

      public MatrixF(float[] data)
      {
         if(data.Length != 16) throw new ArgumentException("MatrixF always takes exactly 16 parameters");
         M = data;
      }

      public float[] ToArray()
      {
         return M;
      }
   }
}
