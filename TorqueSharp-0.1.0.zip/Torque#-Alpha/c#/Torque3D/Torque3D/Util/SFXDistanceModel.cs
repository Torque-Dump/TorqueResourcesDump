﻿namespace Torque3D.Util
{
   public enum SFXDistanceModel
   {
      Linear,
      Logarithmic
   }
}
