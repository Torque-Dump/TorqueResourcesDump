﻿using System;

namespace Torque3D.Util
{
   public class Box3F
   {
      public Point3F MinExtents { get; set; }
      public Point3F MaxExtents { get; set; }

      public Box3F(float x1, float y1, float z1, float x2, float y2, float z2)
      {
         MinExtents = new Point3F(x1, y1, z1);
         MinExtents = new Point3F(x2, y2, z2);
      }

      public Box3F(float[] data)
      {
         if (data.Length != 6) throw new ArgumentException("Point2F always takes exactly 2 parameters");

         MinExtents = new Point3F(data[0], data[1], data[2]);
         MinExtents = new Point3F(data[4], data[5], data[6]);
      }

      public float[] ToArray()
      {
         return new[] {MinExtents.X, MinExtents.Y, MinExtents.Z, MaxExtents.X, MaxExtents.Y, MaxExtents.Z};
      }
   }
}
