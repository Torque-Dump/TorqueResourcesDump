﻿namespace Torque3D.Util
{
   public class AngAxisF
   {
      public Point3F Axis { get; set; }
      public float Angle { get; set; }

      public AngAxisF(float x, float y, float z, float a)
      {
         Axis = new Point3F(x, y, z);
         Angle = a;
      }

      public AngAxisF(Point3F axis, float a)
      {
         Axis = axis;
         Angle = a;
      }

      public float[] ToArray()
      {
         return new[] {Axis.X, Axis.Y, Axis.Z, Angle};
      }
   }
}
