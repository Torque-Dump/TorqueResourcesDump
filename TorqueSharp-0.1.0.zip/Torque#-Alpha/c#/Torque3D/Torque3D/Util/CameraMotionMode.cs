﻿namespace Torque3D.Util
{
   public enum CameraMotionMode
   {
      StationaryMode,
      FreeRotationMode,
      FlyMode,
      OrbitObjectMode,
      OrbitPointMode,
      TrackObjectMode,
      OverheadMode,
      EditOrbitMode
   }
}
