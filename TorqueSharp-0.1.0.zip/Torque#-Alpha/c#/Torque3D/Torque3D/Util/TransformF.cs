﻿using System.Runtime.InteropServices;

namespace Torque3D.Util
{
   [StructLayout(LayoutKind.Sequential, Size = 32*6+1)]
   internal struct InternalTransformStruct
   {
      public float x;
      public float y;
      public float z;

      public float rx;
      public float ry;
      public float rz;
      public float ra;

      [MarshalAs(UnmanagedType.I1)]
      public bool hasRot;
   }

   public class TransformF
   {
      public Point3F Position { get; set; }
      public AngAxisF Orientation { get; set; }
      public bool HasRotation { get; set; }
      public static TransformF Identity = new TransformF(Point3F.Zero, new AngAxisF( new Point3F( 0, 0, 1 ), 0) );

      public TransformF(Point3F p, AngAxisF rotation)
      {
         Position = p;
         Orientation = rotation;
         HasRotation = true;
      }

      internal TransformF(InternalTransformStruct internalTransform)
      {
         Position = new Point3F(internalTransform.x, internalTransform.y, internalTransform.z);
         Orientation = new AngAxisF(internalTransform.rx, internalTransform.ry, internalTransform.rz, internalTransform.ra);
         HasRotation = internalTransform.hasRot;
      }

      internal InternalTransformStruct ToStruct()
      {
         return new InternalTransformStruct
         {
            x = Position.X,
            y = Position.Y,
            z = Position.Z,

            rx = Orientation.Axis.X,
            ry = Orientation.Axis.Y,
            rz = Orientation.Axis.Z,
            ra = Orientation.Angle,

            hasRot = HasRotation
         };
      }
   }
}
