﻿namespace Torque3D.Util
{
   public enum SFXStatus
   {
      Null,
      Playing,
      Stopped,
      Paused,
      Blocked,
      Transition
   }
}
