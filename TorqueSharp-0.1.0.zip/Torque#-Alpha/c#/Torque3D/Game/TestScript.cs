﻿using System.Reflection;
using Torque3D;
using Torque3D.Engine;
using Path = System.IO.Path;

namespace Game
{
   class TestScript
   {
      // [ScriptEntryPoint] Specifies which method should handle initialization of the engine. Think of it as the main.cs file.
      [ScriptEntryPoint]
      public static void entry()
      {
         // --- Boilerplate C#-specific setup. Normally Torque uses the main.cs file to set these variables, here we have to do it ourselves.
         string CSDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location).Replace('\\', '/');
         Global.setMainDotCsDir(CSDir);
         Global.setCurrentDirectory(CSDir);
         // ---

         Global.setLogMode(6);

         // Set the name of our application
         Globals.SetString("appName", "Empty");

         // The directory it is run from
         Globals.SetString("defaultGame", "scripts");

         // Set profile directory
         Globals.SetString("Pref::Video::ProfilePath", "core/profile");

         // Display the optional commandline arguements
         Globals.SetBool("displayHelp", false);

         // Use these to record and play back crashes
         //Global.saveJournal("editorOnFileQuitCrash.jrn");
         //Global.playJournal("editorOnFileQuitCrash.jrn");

         // Process command line arguments
         Global.exec("core/parseArgs.cs");

         Globals.SetBool("isDedicated", false);
         Globals.SetInt("dirCount", 2);
         Globals.SetString("userDirs", Globals.GetString("defaultGame") + ";art;levels");

         // load tools scripts if we're a tool build
         if (Global.isToolBuild())
            Globals.SetString("userDirs", "tools;" + Globals.GetString("userDirs"));

         // Parse the executable arguments with the standard
         // function from core/main.cs
         Global.call("defaultParseArgs");

         if (Globals.GetInt("dirCount") == 0)
         {
            Globals.SetString("userDirs", Globals.GetString("defaultGame"));
            Globals.SetInt("dirCount", 1);
         }

         //-----------------------------------------------------------------------------
         // Display a splash window immediately to improve app responsiveness before
         // engine is initialized and main window created
         if (!Globals.GetBool("isDedicated"))
            Global.displaySplashWindow();

         if (Globals.GetBool("compileAll"))
         {
            Global.echo(" --- Compiling all files ---");
            compileFiles("*.cs");
            compileFiles("*.gui");
            compileFiles("*.ts");
            Global.echo(" --- Compiling all files ---");
            Global.echo(" --- Exiting after compile ---");
            Global.quit();
         }

         if (Globals.GetBool("compileTools"))
         {
            Global.echo(" --- Compiling tools scritps ---");
            compileFiles("tools/*.cs");
            compileFiles("tools/*.gui");
            compileFiles("tools/*.ts");
            Global.echo(" --- Exiting after compile ---");
            Global.quit();
         }

         // Default to a new logfile each session.
         if (!Globals.GetBool("logModeSpecified"))
         {
            string platform = Globals.GetString("platform");
            if (!platform.Equals("xbox") && !platform.Equals("xenon"))
               Global.setLogMode(6);
         }

         // Get the first dir on the list, which will be the last to be applied... this
         // does not modify the list.
         Global.nextToken(Globals.GetString("userDirs"), "currentMod", ";");

         Global.echo("--------- Loading DIRS ---------");

         loadDirs(Globals.GetString("userDirs"));
         Global.echo("");

         if (Globals.GetInt("dirCount") == 0)
         {
            Global.enableWinConsole(true);
            Global.error("Error: Unable to load any specified directories");
            Global.quit();
         }

         // Parse the command line arguments
         Global.echo("--------- Parsing Arguments ---------");
         // We want to call the TS-define parseArgs, not the C#-defined atm.
         Global.call("parseArgs");
         GuiCanvas Canvas = null;
         // Either display the help message or startup the app.
         if (Globals.GetBool("displayHelp"))
         {
            Global.enableWinConsole(true);
            // We want to call the TS-define displayHelp, not the C#-defined atm.
            Global.call("displayHelp");
            Global.quit();
         }
         else
         {
            // We want to call the TS-define onStart, not the C#-defined atm.
            Global.call("onStart");
            Global.echo("Engine initialized...");

            ModuleManager ModuleDatabase = Sim.FindObjectByName<ModuleManager>("ModuleDatabase");
            ModuleDatabase.scanModules("");

            //You can also explicitly decalre some modules here to be loaded by default if they are part of your game
            //Ex: ModuleDatabase.LoadExplicit( "AppCore" );

            Canvas = Sim.FindObjectByName<GuiCanvas>("Canvas");
            if (!Globals.GetBool("isDedicated"))
            {
               // As we know at this point that the initial load is complete,
               // we can hide any splash screen we have, and show the canvas.
               // This keeps things looking nice, instead of having a blank window
               Global.closeSplashWindow();
               Canvas.showWindow();
            }

            // Auto-load on the 360
            if (Globals.GetString("platform").Equals("xenon"))
            {
               string mission = "levels/Empty Terrain.mis";

               Global.echo($"Xbox360 Autoloading level: \'{mission}\'");

               string serverType;
               if (Globals.GetBool("pref::HostMultiPlayer"))
                  serverType = "MultiPlayer";
               else
                  serverType = "SinglePlayer";

               Global.call("createAndConnectToLocalServer", serverType, mission);
            }
         }

         // Display an error message for unused arguments
         for (int i = 1; i < Globals.GetInt("Game::argc"); i++)
         {
            if (!Globals.GetBool($"argUsed[{i}"))
               Global.error("Error: Unknown command line argument: " + Globals.GetString($"Game::argv[{i}]"));
         }

         GuiCursor DefaultCursor = Sim.FindObjectByName<GuiCursor>("DefaultCursor");
         GuiControl EditorChooseLevelGui = Sim.FindObjectByName<GuiControl>("EditorChooseLevelGui");
         GuiControl EditorChooseGui = Sim.FindObjectByName<GuiControl>("EditorChooseGui");

         // Automatically start up the appropriate eidtor, if any
         if (Globals.GetBool("startWorldEditor"))
         {
            Canvas.setCursor(DefaultCursor);
            Canvas.setContent(EditorChooseLevelGui);
         }
         else if (Globals.GetBool("startGUIEditor"))
         {
            Canvas.setCursor(DefaultCursor);
            Canvas.setContent(EditorChooseGui);
         }
      }

      [ConsoleFunction]
      public static bool createCanvas()
      {
         if (Globals.GetBool("isDedicated"))
         {
            // This doesn't work in C# atm
            Global.call("GFXInit::createNullDevice");
            return true;
         }

         // Create the Canvas
         GuiCanvas Canvas = new GuiCanvas();
         Canvas.setName("Canvas");
         Canvas.registerObject();
         // foo.displayWindow = $platform !$= "windows";

         Globals.SetInt("GameCanvas", Canvas.getId());

         // Set the window title
         if (Global.isObject("Canvas"))
            Canvas.setWindowTitle(Global.getEngineName() + " - " + Globals.GetString("appName"));

         return true;
      }

      // Check if a script file exists, compiled or not.
      // Marking a static function with [ConsoleFunction] exposes it to the engine, so it can be called from TorqueScript or via eval etc.
      [ConsoleFunction]
      public static bool isScriptFile(string path)
      {
         return Global.isFile(path + ".dso") || Global.isFile(path);
      }

      // The displayHelp, onStart, onExit and parseArgs function are overriden
      // by mod packages to get hooked into initialization and cleanup.
      // lukaspj: Currently these are not marked with ConsoleFunction, because I have not figured out how to represent packages in C# yet. 
      //  - And whether they should be represented.
      public static void onStart()
      {
         // Default startup function
      }

      public static void onExit()
      {
         // OnExit is called directly from C++ code, whereas onStart is
         // invoked at the end of this file.
      }

      public static void parseArgs()
      {
         // Here for mod override, the arguments have already
         // been parsed.
      }

      [ConsoleFunction]
      public static void compileFiles(string pattern)
      {
         string path = Global.filePath(pattern);

         string saveDSO = Globals.GetString("Scripts::OverrideDSOPath");
         bool saveIgnore = Globals.GetBool("Scripts::ignoreDSOs");

         Globals.SetString("Scripts::OverrideDSOPath", path);
         Globals.SetBool("Scripts::ignoreDSOs", false);
         string mainCsFile = Global.makeFullPath("main.cs");

         for (string file = Global.findFirstFileMultiExpr(pattern);
            !file.Equals("");
            file = Global.findNextFileMultiExpr(pattern))
         {
            // we don't want to try and compile the primary main.cs
            if (!mainCsFile.Equals(file))
               Global.compile(file, true);
         }

         Globals.SetString("Scripts::OverrideDSOPath", saveDSO);
         Globals.SetBool("Scripts::ignoreDSOs", saveIgnore);
      }

      [ConsoleFunction]
      public static void displayHelp()
      {
         Global.activatePackage("Help");

         // Notes on logmode: console logging is written to console.log.
         // -log 0 disables console logging.
         // -log 1 appends to existing logfile; it also closes the file
         // (flushing the write buffer) after every write.
         // -log 2 overwrites any existing logfile; it also only closes
         // the logfile when the application shuts down.  (default)

         Global.error(
            "Torque Demo command line options:\n" +
            "  -log <logmode>         Logging behavior; see main.cs comments for details\n" +
            "  -game <game_name>      Reset list of mods to only contain <game_name>\n" +
            "  <game_name>            Works like the -game argument\n" +
            "  -dir <dir_name>        Add <dir_name> to list of directories\n" +
            "  -console               Open a separate console\n" +
            "  -jSave  <file_name>    Record a journal\n" +
            "  -jPlay  <file_name>    Play back a journal\n" +
            "  -help                  Display this help message\n"
            );
      }

      // Execute startup scripts for each mod, starting at base and working up
      [ConsoleFunction]
      public static void loadDir(string dir)
      {
         //TODO pushback($userDirs, % dir, ";");

         if (isScriptFile(dir + "/main.cs"))
            Global.exec(dir + "/main.cs");
      }

      [ConsoleFunction]
      public static void loadDirs(string dirPath)
      {
         dirPath = Global.nextToken(dirPath, "token", ";");
         string token = Globals.GetString("token");

         if (!dirPath.Equals(""))
            loadDirs(dirPath);

         if (Global.exec(token + "/main.cs") != true)
         {
            Global.error("Error: Unable to find specified directory: " + "token");
            Globals.SetInt("dirCount", Globals.GetInt("dirCount") - 1);
         }
      }
   }
}