

function RPG_Editor::LoadMGroups(%this)
{
   MOBGP_MGroups_LST.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select MGroupID, Name from MGroups;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      $MGroupGUI::MGroupID=%result;
      while (!sqlite.endOfResult(%result))
      {
         %MGroupname = sqlite.getColumn(%result, "Name");
         MOBGP_MGroups_LST.addItem(%MGroupname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}



function RPG_Editor::Open_PopUP_MGroups(%this, %MGroupID){

   RPG_EDITOR_MAIN.setVisible(false);
   %this.displayPopupEditor("MGroups");
   
   %this.loadMAPSelection("MGPEDT_MAPENCOUNTERED");
   %this.loadMonsterList("MGPEDT_MONSTERS_LST");
   
   
   if(%MGroupID==0){
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=true;
      $RPG_EDITOR_POPUP_SAVE_ID=0;
      
      MGPEDT_Name.setText("");
	   MGPEDT_ENCOUNTERRATE.setText("");
	   MGPEDT_MAPENCOUNTERED.setFirstSelected();
	   MGPEDT_MONSTERS_LST.clearSelection();
	   
   }else{
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=false;
      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      // create a new simple table for demonstration purposes
      %query = "select Name,ATK_GRD,DEF_GRD,MATK_GRD,MDEF_GRD,VIT_GRD,MAG_GRD,EVA_GRD,ACC_GRD from MGroups where MGroupID="@%MGroupID@";";
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from MGroups table.");
      }else{
         // attempt to retrieve result data
         $RPG_EDITOR_POPUP_SAVE_ID=%MGroupID;
      
      MGPEDT_Name.setText(sqlite.getColumn(%result, "Name"));
	   MGPEDT_ENCOUNTERRATE.setText(sqlite.getColumn(%result, "Name"));
	   MGPEDT_MAPENCOUNTERED.setSelected(sqlite.getColumn(%result, "Name"));
	   
	   
      
      %List=sqlite.getColumn(%result, "MONSTER_LST");
         for(%i=0; %i<getWordCount(%List);%i++){
            %_id=getWord(%List,%i);
            %query = "select Name from Monsters where MonsterID="@%_id@";";
            %results = sqlite.query(%query, 0);  
            if(%results == 0){
               echo("Could Not Find Class ID: "@%_id);
            }else{
               MGPEDT_MONSTERS_LST.setCurSel(MGPEDT_MONSTERS_LST.findItemText(sqlite.getColumn(%results, "Name")));
            }
         }
	   
      }
   sqlite.closeDatabase();
   sqlite.delete();
   }

}



function RPG_Editor::LoadSelectedMGroup(%this){
   // attempt to retrieve result data
   %count=MOBGP_MGroups_LST.getSelectedItem();

   if(count==0)return;
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select MGroupID from MGroups;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from MGroups table.");
   }else{
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      %MGroupID = sqlite.getColumn(%result, "MGroupID");
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.Open_PopUP_MGroups(%MGroupID);
}
   

   
function RPG_Editor::NewMGroup(%this)
{
   %this.Open_PopUP_MGroups(0);
}


function RPG_Editor::DeleteMGroup(%this)
{
   // attempt to retrieve result data
   %count=MOBGP_MGroups_LST.getSelectedItem();
      
   if(count==0)return;
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select MGroupID from MGroups;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from MGroups table.");
   }else{
      // attempt to retrieve result data
      $MGroupGUI::MGroupID=%result;
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         %SAVEID = sqlite.getColumn(%result, "MGroupID");
         %query = "Delete from MGroups where MGroupID="@%SAVEID@";";
         %result = sqlite.query(%query, 0);
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.LoadMGroups();
}



function RPG_Editor::SaveMGroups(%this)
{      
      %MGPEDT_Name=MGPEDT_Name.getText();
      
      if((%MGPEDT_Name $= "") == 1) return;
	   %MGPEDT_ENCOUNTERRATE=MGPEDT_ENCOUNTERRATE.getText();
	   %MGPEDT_MAPENCOUNTERED=MGPEDT_MAPENCOUNTERED.getSelected();
	   
	   
	   
      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
            
      %Count = MGPEDT_MONSTERS_LST.getSelCount();
      %IDs = MGPEDT_MONSTERS_LST.getSelectedItems();
      for(%i =0;%i < %Count ; %i++){
         %temp=getWord(%IDs, %i);
         %Name=MGPEDT_MONSTERS_LST.getItemText(%temp);
         %query = "select MonsterID from Monsters where Name='"@%Name@"';";
         %result = sqlite.query(%query, 0);   
         if (%result == 0)
         {
            echo("Class Name Not Found");
         }else{
            %REALID = sqlite.getColumn(%result, "MonsterID");
            if(%i==0){            
               %MGPEDT_MONSTERS_LST=%REALID;
            }else{
               %MGPEDT_MONSTERS_LST=%MGPEDT_MONSTERS_LST@" "@%REALID;
            }
         }
      }
      
      
      
                  
      
      
      // create a new simple table for demonstration purposes
      if($RPG_EDITOR_POPUP_SAVE_STATE_NEW==false){
         %MGroupID=$RPG_EDITOR_POPUP_SAVE_ID;
         %query = "Update MGroups set Name='"@%MGPEDT_Name@"',ENCOUNTERRATE='"@%MGPEDT_ENCOUNTERRATE@"',MAPENCOUNTERED='"@%MGPEDT_MAPENCOUNTERED@"',MONSTER_LST='"@%MGPEDT_MONSTERS_LST@"' where MGroupID="@%MGroupID@";";
      }else{
         %query = "Insert into MGroups(Name,ENCOUNTERRATE,MAPENCOUNTERED,MONSTER_LST) Values('"@%MGPEDT_Name@"','"@%MGPEDT_ENCOUNTERRATE@"','"@%MGPEDT_MAPENCOUNTERED@"','"@%MGPEDT_MONSTERS_LST@"');";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from MGroups table.");
      }else{   

      
      MGPEDT_Name.setText("");
	   MGPEDT_ENCOUNTERRATE.setText("");
	   MGPEDT_MAPENCOUNTERED.setFirstSelected();
	   MGPEDT_MONSTERS_LST.clearSelection();
	   
         %this.displayMainEditor();
         %this.SetMainPanel("MGroups");
         %this.LoadMGroups();
      }
   sqlite.closeDatabase();
   sqlite.delete();
}


function RPG_Editor::CancelMGroups(%this){

      
      MGPEDT_Name.setText("");
	   MGPEDT_ENCOUNTERRATE.setText("");
	   MGPEDT_MAPENCOUNTERED.setFirstSelected();
	   MGPEDT_MONSTERS_LST.clearSelection();
	   
         %this.displayMainEditor();
         %this.SetMainPanel("MGroups");
         %this.LoadMGroups();
}