

function RPG_Editor::LoadMaps(%this)
{  
   MAP_Save_BTN.setVisible(false);
   MAP_Cancel_BTN.setVisible(false);
   MAP_New_BTN.setVisible(true);
   MAP_Edit_BTN.setVisible(true);
   MAP_Delete_BTN.setVisible(true);
   RPG_Map_LST.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select MapID, Name from Maps;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      $MapGUI::MapID=%result;
      while (!sqlite.endOfResult(%result))
      {
         %Mapname = sqlite.getColumn(%result, "Name");
         RPG_Map_LST.addItem(%Mapname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}



function RPG_Editor::Open_PopUP_Maps(%this, %MapID){
  
   MAP_Save_BTN.setVisible(true);
   MAP_Cancel_BTN.setVisible(true);
   MAP_New_BTN.setVisible(false);
   MAP_Edit_BTN.setVisible(false);
   MAP_Delete_BTN.setVisible(false);
   if(%MapID==0){
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=true;
      $RPG_EDITOR_POPUP_SAVE_ID=0;
      MAP_Name.setText("");
   }else{
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=false;
      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      // create a new simple table for demonstration purposes
      %query = "select Name from Maps where MapID="@%MapID@";";
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Maps table.");
      }else{
         // attempt to retrieve result data
         $RPG_EDITOR_POPUP_SAVE_ID=%MapID;
         MAP_Name.setText(sqlite.getColumn(%result, "Name"));
      }
   sqlite.closeDatabase();
   sqlite.delete();
   }

}



function RPG_Editor::LoadSelectedMap(%this){
   // attempt to retrieve result data
   %count=RPG_Map_LST.getSelectedItem();
   if(count==0)return;
   MAP_Save_BTN.setVisible(true);
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select MapID from Maps;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Maps table.");
   }else{
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      %MapID = sqlite.getColumn(%result, "MapID");
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.Open_PopUP_Maps(%MapID);
}
   

function RPG_Editor::NewMap(%this)
{
   %this.Open_PopUP_Maps(0);
}

function RPG_Editor::DeleteMap(%this)
{
   // attempt to retrieve result data
   %count=RPG_Map_LST.getSelectedItem();
      
   if(count==0)return;
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select MapID from Maps;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Maps table.");
   }else{
      // attempt to retrieve result data
      $MapGUI::MapID=%result;
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         %SAVEID = sqlite.getColumn(%result, "MapID");
         %query = "Delete from Maps where MapID="@%SAVEID@";";
         %result = sqlite.query(%query, 0);
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.LoadMaps();
}

function RPG_Editor::SaveMaps(%this)
{
      %name=MAP_Name.getText();
      
      
      if((%name $= "") == 1) return;
      
      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      // create a new simple table for demonstration purposes
      if($RPG_EDITOR_POPUP_SAVE_STATE_NEW==false){
         %MapID=$RPG_EDITOR_POPUP_SAVE_ID;
         %query = "Update Maps set Name='"@%name@"' where MapID="@%MapID@";";
      }else{
         %query = "Insert into Maps(Name) Values('"@%name@"');";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Maps table.");
      }else{   
         MAP_Name.setText("");  
         MAP_Save_BTN.setVisible(false);
         MAP_Cancel_BTN.setVisible(false);
   MAP_New_BTN.setVisible(true);
   MAP_Edit_BTN.setVisible(true);
   MAP_Delete_BTN.setVisible(true);
         //%this.displayMainEditor();
         %this.SetMainPanel("Maps");
         %this.LoadMaps();
      }
   sqlite.closeDatabase();
   sqlite.delete();
}

function RPG_Editor::CancelMaps(%this){
         MAP_Name.setText("");      
         MAP_Save_BTN.setVisible(false);
         MAP_Cancel_BTN.setVisible(false);
   MAP_New_BTN.setVisible(true);
   MAP_Edit_BTN.setVisible(true);
   MAP_Delete_BTN.setVisible(true);
         //%this.displayMainEditor();
         %this.SetMainPanel("Maps");
         %this.LoadMaps();
}