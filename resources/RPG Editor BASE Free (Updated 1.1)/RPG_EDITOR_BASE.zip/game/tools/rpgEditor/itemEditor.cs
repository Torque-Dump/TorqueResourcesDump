
function RPG_Editor::LoadItems(%this)
{
   ITM_Item_LST.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ItemID, Name from Items;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      $CLASSGUI::CLASSID=%result;
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ITM_Item_LST.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}



function RPG_Editor::Open_PopUP_Items(%this, %itemID){

   RPG_EDITOR_MAIN.setVisible(false);
   %this.displayPopupEditor("Items");
   
   %this.loadItemTypesSelection("IEDT_ITEMTYPE");
   %this.loadArcanaTypesSelection("IEDT_ARCANATYPE");
   %this.loadStatusTypesSelection("IEDT_STATUSEFFECTTYPE");
   %this.loadBoostTypesSelection("IEDT_STATUSBOOSTTYPE");
   %this.loadTargetsTypesSelection("IEDT_TARGETTYPE");
   %this.loadSpellSelection("IEDT_TEACHSPELL");
   %this.loadSpecialsSelection("IEDT_TEACHSPECIAL");
   %this.loadSummonSelection("IEDT_TEACHSUMMON");
   
   
   if(%itemID==0){
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=true;
      $RPG_EDITOR_POPUP_SAVE_ID=0;
      IEDT_Name.setText("");
      IEDT_Effect_PCT.setText("");
      IEDT_Effect_VALUE.setText("");
      IEDT_COST.setText("");
      IEDT_SELL.setText("");
      IEDT_QUANTITY.setText("");
      IEDT_ICON.setText("");
      IEDT_ANIM.setText("");
      IEDT_INBATTLEONLY.setStateOn(false);
      IEDT_DESC.setText("");
      IEDT_ITEMTYPE.setFirstSelected();
      IEDT_ARCANATYPE.setFirstSelected();
      IEDT_STATUSEFFECTTYPE.setFirstSelected();
      IEDT_STATUSBOOSTTYPE.setFirstSelected();
      IEDT_TARGETTYPE.setFirstSelected();
      IEDT_TEACHSPELL.setFirstSelected();
      IEDT_TEACHSPECIAL.setFirstSelected();
      IEDT_TEACHSUMMON.setFirstSelected();
      
   }else{
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=false;
      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      // create a new simple table for demonstration purposes
      %query = "select Name, Effect_PCT, Effect_VALUE, COST, SELL, QUANTITY, ICON, ANIM, INBATTLEONLY, DESC, ITEMTYPE, ARCANATYPE, STATUSTYPE, ATTRIBUTETYPE, TARGETTYPE, TEACHSPELL, TEACHSPECIAL, TEACHSUMMON from Items where ItemID="@%itemID@";";
      %result = sqlite.query(%query, 0);   
      
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Items table.");
      }else{
         // attempt to retrieve result data
         $RPG_EDITOR_POPUP_SAVE_ID=%itemID;
         IEDT_Name.setText(sqlite.getColumn(%result, "Name"));
         IEDT_Effect_PCT.setText(sqlite.getColumn(%result, "Effect_PCT"));
         IEDT_Effect_VALUE.setText(sqlite.getColumn(%result, "Effect_VALUE"));
         IEDT_COST.setText(sqlite.getColumn(%result, "COST"));
         IEDT_SELL.setText(sqlite.getColumn(%result, "SELL"));
         IEDT_QUANTITY.setText(sqlite.getColumn(%result, "QUANTITY"));
         IEDT_ICON.setText(sqlite.getColumn(%result, "ICON"));
         IEDT_ANIM.setText(sqlite.getColumn(%result, "ANIM"));
         IEDT_INBATTLEONLY.setStateOn(sqlite.getColumn(%result, "INBATTLEONLY"));
         IEDT_DESC.setText(sqlite.getColumn(%result, "DESC"));
         IEDT_ITEMTYPE.setSelected(sqlite.getColumn(%result, "ITEMTYPE"));
         IEDT_ARCANATYPE.setSelected(sqlite.getColumn(%result, "ARCANATYPE"));
         IEDT_STATUSEFFECTTYPE.setSelected(sqlite.getColumn(%result, "STATUSTYPE"));
         IEDT_STATUSBOOSTTYPE.setSelected(sqlite.getColumn(%result, "ATTRIBUTETYPE"));
         IEDT_TARGETTYPE.setSelected(sqlite.getColumn(%result, "TARGETTYPE"));
         IEDT_TEACHSPELL.setSelected(sqlite.getColumn(%result, "TEACHSPELL"));
         IEDT_TEACHSPECIAL.setSelected(sqlite.getColumn(%result, "TEACHSPECIAL"));
         IEDT_TEACHSUMMON.setSelected(sqlite.getColumn(%result, "TEACHSUMMON"));
      }
   sqlite.closeDatabase();
   sqlite.delete();
   }

}


function RPG_Editor::LoadSelectedItem(%this){
   // attempt to retrieve result data
   %count=ITM_Item_LST.getSelectedItem();

   if(count==0)return;
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ItemID from Items;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Items table.");
   }else{
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      %itmeID = sqlite.getColumn(%result, "ItemID");
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.Open_PopUP_Items(%itmeID);
}
   
function RPG_Editor::NewItem(%this)
{
   %this.Open_PopUP_Items(0);
}

function RPG_Editor::DeleteItem(%this)
{
   // attempt to retrieve result data
   %count=ITM_Item_LST.getSelectedItem();
      
   if(count==0)return;
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ItemID from Items;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Items table.");
   }else{
      // attempt to retrieve result data
      
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         %SAVEID = sqlite.getColumn(%result, "ItemID");
         %query = "Delete from Items where ItemID="@%SAVEID@";";
         %result = sqlite.query(%query, 0);
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.LoadItems();
}

function RPG_Editor::SaveItems(%this)
{
      
      %name=IEDT_Name.getText();
      if((%name $= "") == 1) return;
      %eff_pct=IEDT_Effect_PCT.getText();
      %eff_val=IEDT_Effect_VALUE.getText();
      %cost=IEDT_COST.getText();
      %sell=IEDT_SELL.getText();
      %quant=IEDT_QUANTITY.getText();
      %icon=IEDT_ICON.getText();
      %anim=IEDT_ANIM.getText();
      %in_bat=IEDT_INBATTLEONLY.isStateOn();
      %desc=IEDT_DESC.getText();
      %itype=IEDT_ITEMTYPE.getSelected();
      %atype=IEDT_ARCANATYPE.getSelected();
      %SEtype=IEDT_STATUSEFFECTTYPE.getSelected();
      %SBtype=IEDT_STATUSBOOSTTYPE.getSelected();
      %Ttype=IEDT_TARGETTYPE.getSelected();
      %SPELL=IEDT_TEACHSPELL.getSelected();
      %SPEC=IEDT_TEACHSPECIAL.getSelected();
      %SMN=IEDT_TEACHSUMMON.getSelected();

      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      // create a new simple table for demonstration purposes
      if($RPG_EDITOR_POPUP_SAVE_STATE_NEW==false){
         %itemID=$RPG_EDITOR_POPUP_SAVE_ID;
         %query = "Update Items set Name='"@%name@"',Effect_PCT='"@%eff_pct@"',Effect_VALUE='"@%eff_val@"',COST='"@%cost@"',SELL='"@%sell@"',QUANTITY='"@%quant@"',ICON='"@%icon@"',ANIM='"@%anim@"',INBATTLEONLY='"@%in_bat@"',DESC='"@%desc@"',ITEMTYPE='"@%itype@"',ARCANATYPE='"@%atype@"',STATUSTYPE='"@%SEtype@"',ATTRIBUTETYPE='"@%SBtype@"',TARGETTYPE='"@%Ttype@"',TEACHSPELL='"@%SPELL@"',TEACHSPECIAL='"@%SPEC@"',TEACHSUMMON='"@%SMN@"' where ItemID="@%itemID@";";
      }else{
         %query = "Insert into Items(Name,Effect_PCT,Effect_VALUE,COST,SELL,QUANTITY,ICON,ANIM,INBATTLEONLY,DESC,ITEMTYPE,ARCANATYPE,STATUSTYPE,ATTRIBUTETYPE,TARGETTYPE,TEACHSPELL,TEACHSPECIAL,TEACHSUMMON) Values('"@%name@"','"@%eff_pct@"','"@%eff_val@"','"@%cost@"','"@%sell@"','"@%quant@"','"@%icon@"','"@%anim@"','"@%in_bat@"','"@%desc@"','"@%itype@"','"@%atype@"','"@%SEtype@"','"@%SBtype@"','"@%Ttype@"','"@%SPELL@"','"@%SPEC@"','"@%SMN@"');";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Items table.");
      }else{   

         IEDT_Name.setText("");
         IEDT_Effect_PCT.setText("");
         IEDT_Effect_VALUE.setText("");
         IEDT_COST.setText("");
         IEDT_SELL.setText("");
         IEDT_QUANTITY.setText("");
         IEDT_ICON.setText("");
         IEDT_ANIM.setText("");
         IEDT_INBATTLEONLY.setStateOn(false);
         IEDT_DESC.setText("");
         IEDT_ITEMTYPE.setFirstSelected();
         IEDT_ARCANATYPE.setFirstSelected();
         IEDT_STATUSEFFECTTYPE.setFirstSelected();
         IEDT_STATUSBOOSTTYPE.setFirstSelected();
         IEDT_TARGETTYPE.setFirstSelected();
         IEDT_TEACHSPELL.setFirstSelected();
         IEDT_TEACHSPECIAL.setFirstSelected();
         IEDT_TEACHSUMMON.setFirstSelected();
         %this.displayMainEditor();
         %this.SetMainPanel("Items");
         %this.LoadItems();
      }
   sqlite.closeDatabase();
   sqlite.delete();
}

function RPG_Editor::CancelItems(%this){
         IEDT_Name.setText("");
         IEDT_Effect_PCT.setText("");
         IEDT_Effect_VALUE.setText("");
         IEDT_COST.setText("");
         IEDT_SELL.setText("");
         IEDT_QUANTITY.setText("");
         IEDT_ICON.setText("");
         IEDT_ANIM.setText("");
         IEDT_INBATTLEONLY.setStateOn(false);
         IEDT_DESC.setText("");
         IEDT_ITEMTYPE.setFirstSelected();
         IEDT_ARCANATYPE.setFirstSelected();
         IEDT_STATUSEFFECTTYPE.setFirstSelected();
         IEDT_STATUSBOOSTTYPE.setFirstSelected();
         IEDT_TARGETTYPE.setFirstSelected();
         IEDT_TEACHSPELL.setFirstSelected();
         IEDT_TEACHSPECIAL.setFirstSelected();
         IEDT_TEACHSUMMON.setFirstSelected();
         %this.displayMainEditor();
         %this.SetMainPanel("Items");
         %this.LoadItems();
}