

function RPG_Editor::LoadClasses(%this)
{
   CLS_Classes_LST.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ClassID, Name from Classes;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      $CLASSGUI::CLASSID=%result;
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         CLS_Classes_LST.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}



function RPG_Editor::Open_PopUP_Classes(%this, %classID){

   RPG_EDITOR_MAIN.setVisible(false);
   %this.displayPopupEditor("Classes");
   
   %this.loadGradesSelection("CEDT_ATK");
   %this.loadGradesSelection("CEDT_DEF");
   %this.loadGradesSelection("CEDT_MATK");
   %this.loadGradesSelection("CEDT_MDEF");
   %this.loadGradesSelection("CEDT_VIT");
   %this.loadGradesSelection("CEDT_MAG");
   %this.loadGradesSelection("CEDT_EVA");
   %this.loadGradesSelection("CEDT_ACC");
   
   
   if(%classID==0){
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=true;
      $RPG_EDITOR_POPUP_SAVE_ID=0;
      CEDT_Name.setText("");
      CEDT_ATK.setFirstSelected();
      CEDT_DEF.setFirstSelected();
      CEDT_MATK.setFirstSelected();
      CEDT_MDEF.setFirstSelected();
      CEDT_VIT.setFirstSelected();
      CEDT_MAG.setFirstSelected();
      CEDT_EVA.setFirstSelected();
      CEDT_ACC.setFirstSelected();
   }else{
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=false;
      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      // create a new simple table for demonstration purposes
      %query = "select Name,ATK_GRD,DEF_GRD,MATK_GRD,MDEF_GRD,VIT_GRD,MAG_GRD,EVA_GRD,ACC_GRD from Classes where ClassID="@%classID@";";
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Classes table.");
      }else{
         // attempt to retrieve result data
         $RPG_EDITOR_POPUP_SAVE_ID=%classID;
         CEDT_Name.setText(sqlite.getColumn(%result, "Name"));
         CEDT_ATK.setSelected(sqlite.getColumn(%result, "ATK_GRD"));
         CEDT_DEF.setSelected(sqlite.getColumn(%result, "DEF_GRD"));
         CEDT_MATK.setSelected(sqlite.getColumn(%result, "MATK_GRD"));
         CEDT_MDEF.setSelected(sqlite.getColumn(%result, "MDEF_GRD"));
         CEDT_VIT.setSelected(sqlite.getColumn(%result, "VIT_GRD"));
         CEDT_MAG.setSelected(sqlite.getColumn(%result, "MAG_GRD"));
         CEDT_EVA.setSelected(sqlite.getColumn(%result, "EVA_GRD"));
         CEDT_ACC.setSelected(sqlite.getColumn(%result, "ACC_GRD"));
      }
   sqlite.closeDatabase();
   sqlite.delete();
   }

}


function RPG_Editor::LoadSelectedClass(%this){
   // attempt to retrieve result data
   %count=CLS_Classes_LST.getSelectedItem();

   if(count==0)return;
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ClassID from Classes;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      %classID = sqlite.getColumn(%result, "ClassID");
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.Open_PopUP_Classes(%classID);
}
   
function RPG_Editor::NewClass(%this)
{
   %this.Open_PopUP_Classes(0);
}

function RPG_Editor::DeleteClass(%this)
{
   // attempt to retrieve result data
   %count=CLS_Classes_LST.getSelectedItem();
      
   if(count==0)return;
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ClassID from Classes;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      // attempt to retrieve result data
      $CLASSGUI::CLASSID=%result;
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         %SAVEID = sqlite.getColumn(%result, "ClassID");
         %query = "Delete from Classes where ClassID="@%SAVEID@";";
         %result = sqlite.query(%query, 0);
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.LoadClasses();
}


function RPG_Editor::SaveClasses(%this)
{
      %name=CEDT_Name.getText();
      if((%name $= "") == 1) return;
      %atk=CEDT_ATK.getSelected();
      %def=CEDT_DEF.getSelected();
      %matk=CEDT_MATK.getSelected();
      %mdef=CEDT_MDEF.getSelected();
      %vit=CEDT_VIT.getSelected();
      %mag=CEDT_MAG.getSelected();
      %eva=CEDT_EVA.getSelected();
      %acc=CEDT_ACC.getSelected();

      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      // create a new simple table for demonstration purposes
      if($RPG_EDITOR_POPUP_SAVE_STATE_NEW==false){
         %classID=$RPG_EDITOR_POPUP_SAVE_ID;
         %query = "Update Classes set Name='"@%name@"',ATK_GRD='"@%atk@"',DEF_GRD='"@%def@"',MATK_GRD='"@%matk@"',MDEF_GRD='"@%mdef@"',VIT_GRD='"@%vit@"',MAG_GRD='"@%mag@"',EVA_GRD='"@%eva@"',ACC_GRD='"@%acc@"' where ClassID="@%classID@";";
      }else{
         %query = "Insert into Classes(Name,ATK_GRD,DEF_GRD,MATK_GRD,MDEF_GRD,VIT_GRD,MAG_GRD,EVA_GRD,ACC_GRD) Values('"@%name@"','"@%atk@"','"@%def@"','"@%matk@"','"@%mdef@"','"@%vit@"','"@%mag@"','"@%eva@"','"@%acc@"');";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Classes table.");
      }else{   
         CEDT_Name.setText("");      
         CEDT_ATK.clear();
         CEDT_DEF.clear();
         CEDT_MATK.clear();
         CEDT_MDEF.clear();
         CEDT_VIT.clear();
         CEDT_MAG.clear();
         CEDT_EVA.clear();
         CEDT_ACC.clear();
         %this.displayMainEditor();
         %this.SetMainPanel("Classes");
         %this.LoadClasses();
      }
   sqlite.closeDatabase();
   sqlite.delete();
}

function RPG_Editor::CancelClasses(%this){
         CEDT_Name.setText("");      
         CEDT_ATK.clear();
         CEDT_DEF.clear();
         CEDT_MATK.clear();
         CEDT_MDEF.clear();
         CEDT_VIT.clear();
         CEDT_MAG.clear();
         CEDT_EVA.clear();
         CEDT_ACC.clear();
         %this.displayMainEditor();
         %this.SetMainPanel("Classes");
         %this.LoadClasses();
}