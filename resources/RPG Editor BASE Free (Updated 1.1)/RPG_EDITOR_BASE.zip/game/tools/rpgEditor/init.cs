function loadRPGEditor()
{
   exec("./RPG_Editor.cs");
   exec("./classesEditor.cs");
   exec("./multiUse.cs");   
   exec("./RPG_Editor.gui");
   exec("./itemEditor.cs");
   exec("./herosEditor.cs");
   exec("./armorsEditor.cs");
   exec("./mgroupEditor.cs");
   exec("./specialsEditor.cs");
   exec("./spellsEditor.cs");
   exec("./summonsEditor.cs");
   exec("./mapEditor.cs");
   exec("./monsterEditor.cs");
   exec("./weaponEditor.cs");
}
loadRPGEditor();
