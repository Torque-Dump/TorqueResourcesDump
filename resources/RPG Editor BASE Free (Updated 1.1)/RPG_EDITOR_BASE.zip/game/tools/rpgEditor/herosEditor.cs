

function RPG_Editor::LoadPlayers(%this)
{
   HRO_Heros_LST.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select PlayerID, Name from Players;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %Playername = sqlite.getColumn(%result, "Name");
         HRO_Heros_LST.addItem(%Playername);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}



function RPG_Editor::Open_PopUP_Players(%this, %PlayerID){

   RPG_EDITOR_MAIN.setVisible(false);
   %this.displayPopupEditor("Heros");
   
   %this.loadClassTypesSelection("HEDT_CLASS_SEL");
   
   if(%PlayerID==0){
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=true;
      $RPG_EDITOR_POPUP_SAVE_ID=0;
      HEDT_Name.setText("");
      HEDT_CLASS_SEL.setFirstSelected();
      HEDT_ATK.setText("");
      HEDT_DEF.setText("");
      HEDT_MATK.setText("");
      HEDT_MDEF.setText("");
      HEDT_VIT.setText("");
      HEDT_MAG.setText("");
      HEDT_EVA.setText("");
      HEDT_ACC.setText("");
      HEDT_SHAPE.setText("");
      HEDT_Bio.setText("");
      HEDT_Race.setText("");
      HEDT_DIAG_IMAGE.setText("");
      HEDT_LEVEL.setText("");
  
   }else{
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=false;
      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      // create a new simple table for demonstration purposes
      %query = "select Name,StartLevel,CLASS,ATK,DEF,MATK,MDEF,VIT,MAG,EVA,ACC,Race,SHAPE,Bio,DIAG_IMAGE from Players where PlayerID="@%PlayerID@";";
      
      
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Players table.");
      }else{
         // attempt to retrieve result data         
      HEDT_Name.setText(sqlite.getColumn(%result, "Name"));
      HEDT_LEVEL.setText(sqlite.getColumn(%result, "StartLevel"));
      HEDT_CLASS_SEL.setSelected(sqlite.getColumn(%result, "CLASS"));
      HEDT_ATK.setText(sqlite.getColumn(%result, "ATK"));
      HEDT_DEF.setText(sqlite.getColumn(%result, "DEF"));
      HEDT_MATK.setText(sqlite.getColumn(%result, "MATK"));
      HEDT_MDEF.setText(sqlite.getColumn(%result, "MDEF"));
      HEDT_VIT.setText(sqlite.getColumn(%result, "VIT"));
      HEDT_MAG.setText(sqlite.getColumn(%result, "MAG"));
      HEDT_EVA.setText(sqlite.getColumn(%result, "EVA"));
      HEDT_ACC.setText(sqlite.getColumn(%result, "ACC"));
      HEDT_SHAPE.setText(sqlite.getColumn(%result, "SHAPE"));
      HEDT_Bio.setText(sqlite.getColumn(%result, "Bio"));
      HEDT_Race.setText(sqlite.getColumn(%result, "Race"));
      HEDT_DIAG_IMAGE.setText(sqlite.getColumn(%result, "DIAG_IMAGE"));
      }
   sqlite.closeDatabase();
   sqlite.delete();
   }

}


function RPG_Editor::LoadSelectedPlayer(%this){
   // attempt to retrieve result data
   %count=HRO_Heros_LST.getSelectedItem();

   if(count==0)return;
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select PlayerID from Players;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Players table.");
   }else{
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      %PlayerID = sqlite.getColumn(%result, "PlayerID");
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.Open_PopUP_Players(%PlayerID);
}
   
function RPG_Editor::NewPlayer(%this)
{
   %this.Open_PopUP_Players(0);
}

function RPG_Editor::DeletePlayer(%this)
{
   // attempt to retrieve result data
   %count=HRO_Heros_LST.getSelectedItem();
      
   if(count==0)return;
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select PlayerID from Players;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Players table.");
   }else{
      // attempt to retrieve result data
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         %SAVEID = sqlite.getColumn(%result, "PlayerID");
         %query = "Delete from Players where PlayerID="@%SAVEID@";";
         %result = sqlite.query(%query, 0);
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.LoadPlayers();
}


function RPG_Editor::SavePlayers(%this)
{
      %name=HEDT_Name.getText();
      if((%name $= "") == 1) return;
      %level=HEDT_LEVEL.getText();
      %class=HEDT_CLASS_SEL.getSelected();
      %atk=HEDT_ATK.getText();
      %def=HEDT_DEF.getText();
      %matk=HEDT_MATK.getText();
      %mdef=HEDT_MDEF.getText();
      %vit=HEDT_VIT.getText();
      %mag=HEDT_MAG.getText();
      %eva=HEDT_EVA.getText();
      %acc=HEDT_ACC.getText();
      %shape=HEDT_SHAPE.getText();
      %bio=HEDT_Bio.getText();
      %race=HEDT_Race.getText();
      %diagimg=HEDT_DIAG_IMAGE.getText();

      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      // create a new simple table for demonstration purposes
      if($RPG_EDITOR_POPUP_SAVE_STATE_NEW==false){
         %PlayerID=$RPG_EDITOR_POPUP_SAVE_ID;
         %query = "Update Players set Name='"@%name@"',StartLevel='"@%level@"',CLASS='"@%class@"',ATK='"@%atk@"',DEF='"@%def@"',MATK='"@%matk@"',MDEF='"@%mdef@"',VIT='"@%vit@"',MAG='"@%mag@"',EVA='"@%eva@"',ACC='"@%acc@"',Race='"@%race@"',SHAPE='"@%shape@"',Bio='"@%bio@"',DIAG_IMAGE='"@%diagimg@"' where PlayerID="@%PlayerID@";";
      }else{
         %query = "Insert into Players(Name,StartLevel,CLASS,ATK,DEF,MATK,MDEF,VIT,MAG,EVA,ACC,Race,SHAPE,Bio,DIAG_IMAGE) Values('"@%name@"','"@%level@"','"@%class@"','"@%atk@"','"@%def@"','"@%matk@"','"@%mdef@"','"@%vit@"','"@%mag@"','"@%eva@"','"@%acc@"','"@%race@"','"@%shape@"','"@%bio@"','"@%diagimg@"');";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Players table.");
      }else{   
      HEDT_Name.setText("");
      HEDT_CLASS_SEL.clearSelection();
      HEDT_ATK.setText("");
      HEDT_DEF.setText("");
      HEDT_MATK.setText("");
      HEDT_MDEF.setText("");
      HEDT_VIT.setText("");
      HEDT_MAG.setText("");
      HEDT_EVA.setText("");
      HEDT_ACC.setText("");
      HEDT_SHAPE.setText("");
      HEDT_Bio.setText("");
      HEDT_Race.setText("");
      HEDT_DIAG_IMAGE.setText("");
      HEDT_LEVEL.setText("");
         %this.displayMainEditor();
         %this.SetMainPanel("Heros");
         %this.LoadPlayers();
      }
   sqlite.closeDatabase();
   sqlite.delete();
}

function RPG_Editor::CancelPlayers(%this){
         
      HEDT_Name.setText("");
      HEDT_CLASS_SEL.clearSelection();
      HEDT_ATK.setText("");
      HEDT_DEF.setText("");
      HEDT_MATK.setText("");
      HEDT_MDEF.setText("");
      HEDT_VIT.setText("");
      HEDT_MAG.setText("");
      HEDT_EVA.setText("");
      HEDT_ACC.setText("");
      HEDT_SHAPE.setText("");
      HEDT_Bio.setText("");
      HEDT_Race.setText("");
      HEDT_DIAG_IMAGE.setText("");
      HEDT_LEVEL.setText("");
         %this.displayMainEditor();
         %this.SetMainPanel("Heros");
         %this.LoadPlayers();
}

function RPG_Editor::UpdatePlayerCalc(%this){
/*   
   HEDT_OBJ_VIEWER
   HEDT_OBJ_VIEWER_ZOOMIN
   HEDT_OBJ_VIEWER_ZOOMOUT
   HEDT_OBJ_VIEWER_TURNLEFT
   HEDT_OBJ_VIEWER_TURNRIGHT
   HEDT_OBJ_VIEWER_PANLEFT
   HEDT_OBJ_VIEWER_PANRIGHT
   HEDT_ANIMATION_SEL*/
   
   %level=HEDT_LEVEL.getText();
   %class=HEDT_CLASS_SEL.getSelected();
   %atk=HEDT_ATK.getText();
   %def=HEDT_DEF.getText();
   %matk=HEDT_MATK.getText();
   %mdef=HEDT_MDEF.getText();
   %vit=HEDT_VIT.getText();
   %mag=HEDT_MAG.getText();
   %eva=HEDT_EVA.getText();
   %acc=HEDT_ACC.getText();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   %query = "select ATK_GRD,DEF_GRD,MATK_GRD,MDEF_GRD,VIT_GRD,MAG_GRD,EVA_GRD,ACC_GRD from Classes where ClassID="@%class@";";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Players table.");
   }else{   
      
      %_ATK=(sqlite.getColumn(%result, "ATK_GRD"));
      %_DEF=(sqlite.getColumn(%result, "DEF_GRD"));
      %_MATK=(sqlite.getColumn(%result, "MATK_GRD"));
      %_MDEF=(sqlite.getColumn(%result, "MDEF_GRD"));
      %_VIT=(sqlite.getColumn(%result, "VIT_GRD"));
      %_MAG=(sqlite.getColumn(%result, "MAG_GRD"));
      %_EVA=(sqlite.getColumn(%result, "EVA_GRD"));
      %_ACC=(sqlite.getColumn(%result, "ACC_GRD"));

      %Attack=mFloor((((%_ATK+%atk)*(%level))/1000)*999);
      %Defense=mFloor((((%_DEF+%def)*(%level))/1000)*999);
      %MagicAttack=mFloor((((%_MATK+%matk)*(%level))/1000)*999);
      %MagicDefense=mFloor((((%_MDEF+%mdef)*(%level))/1000)*999);
      %Vitality=mFloor((((%_VIT+%vit)*(%level))/1000)*999);
      %Magic=mFloor((((%_MAG+%mag)*(%level))/1000)*999);
      %Evasion=mFloor((((%_EVA+%eva)*(%level))/1000)*999);
      %Accuracy=mFloor((((%_ACC+%acc)*(%level))/1000)*999);
                      
      %MaxHP=%Vitality*12;
      %MaxMP=%Magic*12;
      %MaxKP=%level*12;
      
      for(%i=0; %i < %level ; %i++){
         %Exp=(%i+1)*1000;
      }
      
      %ExpTNL=(%level+1)*1000;
      
      HEDT_HP_CAL.setText(%MaxHP);
      HEDT_MP_CAL.setText(%MaxMP);
      HEDT_TP_CAL.setText(%MaxKP);
      HEDT_ATK_CAL.setText(%Attack);
      HEDT_DEF_CAL.setText(%Defense);
      HEDT_MATK_CAL.setText(%MagicAttack);
      HEDT_MDEF_CAL.setText(%MagicDefense);
      HEDT_VIT_CAL.setText(%Vitality);
      HEDT_MAG_CAL.setText(%Magic);
      HEDT_EVA_CAL.setText(%Evasion);
      HEDT_ACC_CAL.setText(%Accuracy);
      HEDT_EXP_CAL.setText(%Exp);
      HEDT_EXPTNL_CAL.setText(%ExpTNL);
      
   }
   sqlite.closeDatabase();
   sqlite.delete();
}
