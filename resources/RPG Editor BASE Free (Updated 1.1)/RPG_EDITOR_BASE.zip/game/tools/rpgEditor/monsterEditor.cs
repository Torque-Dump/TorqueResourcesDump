

function RPG_Editor::LoadMonsters(%this)
{
   MOB_Monsters_LST.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select MonsterID, Name from Monsters;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      $MonsterGUI::MonsterID=%result;
      while (!sqlite.endOfResult(%result))
      {
         %Monstername = sqlite.getColumn(%result, "Name");
         MOB_Monsters_LST.addItem(%Monstername);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}



function RPG_Editor::Open_PopUP_Monsters(%this, %MonsterID){

   RPG_EDITOR_MAIN.setVisible(false);
   %this.displayPopupEditor("Monsters");
   
   %this.loadGradesSelection("MEDT_ATK_SEL");
   %this.loadGradesSelection("MEDT_DEF_SEL");
   %this.loadGradesSelection("MEDT_MATK_SEL");
   %this.loadGradesSelection("MEDT_MDEF_SEL");
   %this.loadGradesSelection("MEDT_VIT_SEL");
   %this.loadGradesSelection("MEDT_MAG_SEL");
   %this.loadGradesSelection("MEDT_EVA_SEL");
   %this.loadGradesSelection("MEDT_ACC_SEL");
   %this.loadArcanaTypesSelection("MEDT_Arcana_EHN_SEL");
   %this.loadSpecialsSelection("MEDT_SPC_LST");
   %this.loadAITaticsSelection("MEDT_AITATICS_SEL");
   %this.loadItemList("MEDT_ITEM_LST");
   %this.loadSpellList("MEDT_SPL_LST");
   %this.loadAISpecialActivationSelection("MEDT_SPC_ACTIVATION");
   	
   if(%MonsterID==0){
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=true;
      $RPG_EDITOR_POPUP_SAVE_ID=0;
      CEDT_Name.setText("");
      CEDT_ATK.setFirstSelected();
      MEDT_Name.setText("");
      MEDT_ISBOSS.setStateOn(false);
      MEDT_EXP.setText("");
      MEDT_LEVEL.setText("");
      MEDT_SHAPE.setText("");
      MEDT_CASTANIMATION.setText("");
      MEDT_AITATICS_SEL.setFirstSelected();
      MEDT_SPC_ANIMATION.setText("");
      MEDT_SPC_ACTIVATION.setText("");
      MEDT_SPC_LST.setText("");
      MEDT_ATK.setText("");
      MEDT_DEF.setText("");
      MEDT_MATK.setText("");
      MEDT_MDEF.setText("");
      MEDT_VIT.setText("");
      MEDT_MAG.setText("");
      MEDT_EVA.setText("");
      MEDT_ACC.setText("");
      MEDT_ATK_SEL.setFirstSelected();
      MEDT_DEF_SEL.setFirstSelected();
      MEDT_MATK_SEL.setFirstSelected();
      MEDT_MDEF_SEL.setFirstSelected();
      MEDT_VIT_SEL.setFirstSelected();
      MEDT_MAG_SEL.setFirstSelected();
      MEDT_EVA_SEL.setFirstSelected();
      MEDT_ACC_SEL.setFirstSelected();
      MEDT_DROPRATE.setText("");
      MEDT_ITEM_LST.clearSelection();
      MEDT_FIRE_RES.setText("");
      MEDT_WATER_RES.setText("");
      MEDT_EARTH_RES.setText("");
      MEDT_WIND_RES.setText("");
      MEDT_ICE_RES.setText("");
      MEDT_LIGHTENING_RES.setText("");
      MEDT_LIGHT_RES.setText("");
      MEDT_DARK_RES.setText("");
      MEDT_METAL_RES.setText("");
      MEDT_Arcana_EHN_SEL.setFirstSelected();
      MEDT_SPL_LST.clearSelection();
   }else{
      $RPG_EDITOR_POPUP_SAVE_STATE_NEW=false;
      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      // create a new simple table for demonstration purposes
      %query = "select Name,ISBOSS,EXP,LEVEL,SHAPE,CASTANIMATION,AITATICS_SEL,SPC_ANIMATION,SPC_ACTIVATION,SPC_LST,ATK,DEF,MATK,MDEF,VIT,MAG,EVA,ACC,ATK_GRD,DEF_GRD,MATK_GRD,MDEF_GRD,VIT_GRD,MAG_GRD,EVA_GRD,ACC_GRD,DROPRATE,ITEM_LST,FIRE_RES,WATER_RES,EARTH_RES,WIND_RES,ICE_RES,LIGHTENING_RES,LIGHT_RES,DARK_RES,METAL_RES,ARCH_ENH,SPL_LST from Monsters where MonsterID="@%MonsterID@";";
      
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Monsters table.");
      }else{
         // attempt to retrieve result data
         $RPG_EDITOR_POPUP_SAVE_ID=%MonsterID;
      MEDT_Name.setText(sqlite.getColumn(%result, "Name"));
      MEDT_ISBOSS.setStateOn(sqlite.getColumn(%result, "ISBOSS"));
      MEDT_EXP.setText(sqlite.getColumn(%result, "EXP"));
      MEDT_LEVEL.setText(sqlite.getColumn(%result, "LEVEL"));
      MEDT_SHAPE.setText(sqlite.getColumn(%result, "SHAPE"));
      MEDT_CASTANIMATION.setText(sqlite.getColumn(%result, "CASTANIMATION"));
      MEDT_AITATICS_SEL.setSelected(sqlite.getColumn(%result, "AITATICS_SEL"));
      MEDT_SPC_ANIMATION.setText(sqlite.getColumn(%result, "SPC_ANIMATION"));
      MEDT_SPC_ACTIVATION.setText(sqlite.getColumn(%result, "SPC_ACTIVATION"));
      MEDT_SPC_LST.setSelected(sqlite.getColumn(%result, "SPC_LST"));
      MEDT_ATK.setText(sqlite.getColumn(%result, "ATK"));
      MEDT_DEF.setText(sqlite.getColumn(%result, "DEF"));
      MEDT_MATK.setText(sqlite.getColumn(%result, "MATK"));
      MEDT_MDEF.setText(sqlite.getColumn(%result, "MDEF"));
      MEDT_VIT.setText(sqlite.getColumn(%result, "VIT"));
      MEDT_MAG.setText(sqlite.getColumn(%result, "MAG"));
      MEDT_EVA.setText(sqlite.getColumn(%result, "EVA"));
      MEDT_ACC.setText(sqlite.getColumn(%result, "ACC"));
      MEDT_ATK_SEL.setSelected(sqlite.getColumn(%result, "ATK_GRD"));
      MEDT_DEF_SEL.setSelected(sqlite.getColumn(%result, "DEF_GRD"));
      MEDT_MATK_SEL.setSelected(sqlite.getColumn(%result, "MATK_GRD"));
      MEDT_MDEF_SEL.setSelected(sqlite.getColumn(%result, "MDEF_GRD"));
      MEDT_VIT_SEL.setSelected(sqlite.getColumn(%result, "VIT_GRD"));
      MEDT_MAG_SEL.setSelected(sqlite.getColumn(%result, "MAG_GRD"));
      MEDT_EVA_SEL.setSelected(sqlite.getColumn(%result, "EVA_GRD"));
      MEDT_ACC_SEL.setSelected(sqlite.getColumn(%result, "ACC_GRD"));
      MEDT_DROPRATE.setText(sqlite.getColumn(%result, "DROPRATE"));
      
      %list = sqlite.getColumn(%result, "ITEM_LST");
         for(%i=0; %i<getWordCount(%list);%i++){
            %ITM_id=getWord(%list,%i);
            %query = "select Name from Items where ItemID="@%ITM_id@";";
            %result1 = sqlite.query(%query, 0);  
            if(%result1 == 0){
               echo("Could Not Find Class ID: "@%ITM_id);
            }else{
               MEDT_ITEM_LST.setCurSel(MEDT_ITEM_LST.findItemText(sqlite.getColumn(%result1, "Name")));
            }
         }
      
      MEDT_FIRE_RES.setText(sqlite.getColumn(%result, "FIRE_RES"));
      MEDT_WATER_RES.setText(sqlite.getColumn(%result, "WATER_RES"));
      MEDT_EARTH_RES.setText(sqlite.getColumn(%result, "EARTH_RES"));
      MEDT_WIND_RES.setText(sqlite.getColumn(%result, "WIND_RES"));
      MEDT_ICE_RES.setText(sqlite.getColumn(%result, "ICE_RES"));
      MEDT_LIGHTENING_RES.setText(sqlite.getColumn(%result, "LIGHTENING_RES"));
      MEDT_LIGHT_RES.setText(sqlite.getColumn(%result, "LIGHT_RES"));
      MEDT_DARK_RES.setText(sqlite.getColumn(%result, "DARK_RES"));
      MEDT_METAL_RES.setText(sqlite.getColumn(%result, "METAL_RES"));
      MEDT_Arcana_EHN_SEL.setSelected(sqlite.getColumn(%result, "ARCH_ENH"));
      
      %list = sqlite.getColumn(%result, "SPL_LST");
      for(%i=0; %i<getWordCount(%list);%i++){
         %SPL_id=getWord(%list,%i);
         %query = "select Name from Spells where SpellID="@%SPL_id@";";
         %result2 = sqlite.query(%query, 0);  
         if(%result2 == 0){
               echo("Could Not Find Class ID: "@%SPL_id);
         }else{
               MEDT_SPL_LST.setCurSel(MEDT_SPL_LST.findItemText(sqlite.getColumn(%result2, "Name")));
         }
      }
         
      }
   sqlite.closeDatabase();
   sqlite.delete();
   }

}



function RPG_Editor::LoadSelectedMonster(%this){
   // attempt to retrieve result data
   %count=MOB_Monsters_LST.getSelectedItem();

   if(count==0)return;
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select MonsterID from Monsters;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Monsters table.");
   }else{
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      %MonsterID = sqlite.getColumn(%result, "MonsterID");
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.Open_PopUP_Monsters(%MonsterID);
}
 
function RPG_Editor::NewMonster(%this)
{
   %this.Open_PopUP_Monsters(0);
}

function RPG_Editor::DeleteMonster(%this)
{
   // attempt to retrieve result data
   %count=MOB_Monsters_LST.getSelectedItem();
      
   if(count==0)return;
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select MonsterID from Monsters;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Monsters table.");
   }else{
      // attempt to retrieve result data
      $MonsterGUI::MonsterID=%result;
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         %SAVEID = sqlite.getColumn(%result, "MonsterID");
         %query = "Delete from Monsters where MonsterID="@%SAVEID@";";
         %result = sqlite.query(%query, 0);
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   %this.LoadMonsters();
}



function RPG_Editor::SaveMonsters(%this)
{

      %MEDT_Name=MEDT_Name.getText();
      
      if((%MEDT_Name $= "") == 1) return;
      %MEDT_ISBOSS=MEDT_ISBOSS.isStateOn();
      %MEDT_EXP=MEDT_EXP.getText();
      %MEDT_LEVEL=MEDT_LEVEL.getText();
      %MEDT_SHAPE=MEDT_SHAPE.getText();
      %MEDT_CASTANIMATION=MEDT_CASTANIMATION.getText();
      %MEDT_AITATICS_SEL=MEDT_AITATICS_SEL.getSelected();
      %MEDT_SPC_ANIMATION=MEDT_SPC_ANIMATION.getText();
      %MEDT_SPC_ACTIVATION=MEDT_SPC_ACTIVATION.getText();
      %MEDT_SPC_LST=MEDT_SPC_LST.getSelected();
      %MEDT_ATK=MEDT_ATK.getText();
      %MEDT_DEF=MEDT_DEF.getText();
      %MEDT_MATK=MEDT_MATK.getText();
      %MEDT_MDEF=MEDT_MDEF.getText();
      %MEDT_VIT=MEDT_VIT.getText();
      %MEDT_MAG=MEDT_MAG.getText();
      %MEDT_EVA=MEDT_EVA.getText();
      %MEDT_ACC=MEDT_ACC.getText();
      %MEDT_ATK_SEL=MEDT_ATK_SEL.getSelected();
      %MEDT_DEF_SEL=MEDT_DEF_SEL.getSelected();
      %MEDT_MATK_SEL=MEDT_MATK_SEL.getSelected();
      %MEDT_MDEF_SEL=MEDT_MDEF_SEL.getSelected();
      %MEDT_VIT_SEL=MEDT_VIT_SEL.getSelected();
      %MEDT_MAG_SEL=MEDT_MAG_SEL.getSelected();
      %MEDT_EVA_SEL=MEDT_EVA_SEL.getSelected();
      %MEDT_ACC_SEL=MEDT_ACC_SEL.getSelected();
      %MEDT_DROPRATE=MEDT_DROPRATE.getText();
      

      %MEDT_FIRE_RES=MEDT_FIRE_RES.getText();
      %MEDT_WATER_RES=MEDT_WATER_RES.getText();
      %MEDT_EARTH_RES=MEDT_EARTH_RES.getText();
      %MEDT_WIND_RES=MEDT_WIND_RES.getText();
      %MEDT_ICE_RES=MEDT_ICE_RES.getText();
      %MEDT_LIGHTENING_RES=MEDT_LIGHTENING_RES.getText();
      %MEDT_LIGHT_RES=MEDT_LIGHT_RES.getText();
      %MEDT_DARK_RES=MEDT_DARK_RES.getText();
      %MEDT_METAL_RES=MEDT_METAL_RES.getText();
      %MEDT_Arcana_EHN_SEL=MEDT_Arcana_EHN_SEL.getSelected();
      

      %sqlite = new SQLiteObject(sqlite);
      if (%sqlite == 0)
      {
         echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
         return;
      }
      
      // open database
      if (sqlite.openDatabase("Database.db") == 0)
      {
         echo("ERROR: Failed to open database: " @ %dbname);
         echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
         sqlite.delete();
         return;
      }
      
      %Count = MEDT_ITEM_LST.getSelCount();
      %IDs = MEDT_ITEM_LST.getSelectedItems();
      for(%i =0;%i < %Count ; %i++){
         %temp=getWord(%IDs, %i);
         %Name=MEDT_ITEM_LST.getItemText(%temp);
         %query = "select ItemID from Items where Name='"@%Name@"';";
         %result = sqlite.query(%query, 0);   
         if (%result == 0)
         {
            echo("Item Name Not Found");
         }else{
            %REALID = sqlite.getColumn(%result, "ItemID");
            if(%i==0){            
               %MEDT_ITEM_LST=%REALID;
            }else{
               %MEDT_ITEM_LST=%MEDT_ITEM_LST@" "@%REALID;
            }
         }
      }
      
      
      
      %Count = MEDT_SPL_LST.getSelCount();
      %IDs = MEDT_SPL_LST.getSelectedItems();
      for(%i =0;%i < %Count ; %i++){
         %temp=getWord(%IDs, %i);
         %Name=MEDT_SPL_LST.getItemText(%temp);
         %query = "select SpellID from Spells where Name='"@%Name@"';";
         %result = sqlite.query(%query, 0);   
         if (%result == 0)
         {
            echo("Spell Name Not Found");
         }else{
            %REALID = sqlite.getColumn(%result, "SpellID");
            if(%i==0){            
               %MEDT_SPL_LST=%REALID;
            }else{
               %MEDT_SPL_LST=%MEDT_SPL_LST@" "@%REALID;
            }
         }
      }
      
      
      
      // create a new simple table for demonstration purposes
      if($RPG_EDITOR_POPUP_SAVE_STATE_NEW==false){
         %MonsterID=$RPG_EDITOR_POPUP_SAVE_ID;
         %query = "Update Monsters set Name='"@%MEDT_Name@"',ISBOSS='"@%MEDT_ISBOSS@"',EXP='"@%MEDT_EXP@"',LEVEL='"@%MEDT_LEVEL@"',SHAPE='"@%MEDT_SHAPE@"',CASTANIMATION='"@%MEDT_CASTANIMATION@"',AITATICS_SEL='"@%MEDT_AITATICS_SEL@"',SPC_ANIMATION='"@%MEDT_SPC_ANIMATION@"',SPC_ACTIVATION='"@%MEDT_SPC_ACTIVATION@"',SPC_LST='"@%MEDT_SPC_LST@"',ATK='"@%MEDT_ATK@"',DEF='"@%MEDT_DEF@"',MATK='"@%MEDT_MATK@"',MDEF='"@%MEDT_MDEF@"',VIT='"@%MEDT_VIT@"',MAG='"@%MEDT_MAG@"',EVA='"@%MEDT_EVA@"',ACC='"@%MEDT_ACC@"',ATK_GRD='"@%MEDT_ATK_SEL@"',DEF_GRD='"@%MEDT_DEF_SEL@"',MATK_GRD='"@%MEDT_MATK_SEL@"',MDEF_GRD='"@%MEDT_MDEF_SEL@"',VIT_GRD='"@%MEDT_VIT_SEL@"',MAG_GRD='"@%MEDT_MAG_SEL@"',EVA_GRD='"@%MEDT_EVA_SEL@"',ACC_GRD='"@%MEDT_ACC_SEL@"',DROPRATE='"@%MEDT_DROPRATE@"',ITEM_LST='"@%MEDT_ITEM_LST@"',FIRE_RES='"@%MEDT_FIRE_RES@"',WATER_RES='"@%MEDT_WATER_RES@"',EARTH_RES='"@%MEDT_EARTH_RES@"',WIND_RES='"@%MEDT_WIND_RES@"',ICE_RES='"@%MEDT_ICE_RES@"',LIGHTENING_RES='"@%MEDT_LIGHTENING_RES@"',LIGHT_RES='"@%MEDT_LIGHT_RES@"',DARK_RES='"@%MEDT_DARK_RES@"',METAL_RES='"@%MEDT_METAL_RES@"',ARCH_ENH='"@%MEDT_Arcana_EHN_SEL@"',SPL_LST='"@%MEDT_SPL_LST@"' where MonsterID="@%MonsterID@";";
      }else{
         %query = "Insert into Monsters(Name,ISBOSS,EXP,LEVEL,SHAPE,CASTANIMATION,AITATICS_SEL,SPC_ANIMATION,SPC_ACTIVATION,SPC_LST,ATK,DEF,MATK,MDEF,VIT,MAG,EVA,ACC,ATK_GRD,DEF_GRD,MATK_GRD,MDEF_GRD,VIT_GRD,MAG_GRD,EVA_GRD,ACC_GRD,DROPRATE,ITEM_LST,FIRE_RES,WATER_RES,EARTH_RES,WIND_RES,ICE_RES,LIGHTENING_RES,LIGHT_RES,DARK_RES,METAL_RES,ARCH_ENH,SPL_LST) Values('"@%MEDT_Name@"','"@%MEDT_ISBOSS@"','"@%MEDT_EXP@"','"@%MEDT_LEVEL@"','"@%MEDT_SHAPE@"','"@%MEDT_CASTANIMATION@"','"@%MEDT_AITATICS_SEL@"','"@%MEDT_SPC_ANIMATION@"','"@%MEDT_SPC_ACTIVATION@"','"@%MEDT_SPC_LST@"','"@%MEDT_ATK@"','"@%MEDT_DEF@"','"@%MEDT_MATK@"','"@%MEDT_MDEF@"','"@%MEDT_VIT@"','"@%MEDT_MAG@"','"@%MEDT_EVA@"','"@%MEDT_ACC@"','"@%MEDT_ATK_SEL@"','"@%MEDT_DEF_SEL@"','"@%MEDT_ATK_SEL@"','"@%MEDT_MDEF_SEL@"','"@%MEDT_VIT_SEL@"','"@%MEDT_MAG_SEL@"','"@%MEDT_EVA_SEL@"','"@%MEDT_ACC_SEL@"','"@%MEDT_DROPRATE@"','"@%MEDT_ITEM_LST@"','"@%MEDT_FIRE_RES@"','"@%MEDT_WATER_RES@"','"@%MEDT_EARTH_RES@"','"@%MEDT_WIND_RES@"','"@%MEDT_ICE_RES@"','"@%MEDT_LIGHTENING_RES@"','"@%MEDT_LIGHT_RES@"','"@%MEDT_LIGHT_RES@"','"@%MEDT_METAL_RES@"','"@%MEDT_Arcana_EHN_SEL@"','"@%MEDT_SPL_LST@"');";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from Monsters table.");
      }else{   
         
         MEDT_Name.setText("");
         MEDT_ISBOSS.setStateOn(false);
         MEDT_EXP.setText("");
         MEDT_LEVEL.setText("");
         MEDT_SHAPE.setText("");
         MEDT_CASTANIMATION.setText("");
         MEDT_AITATICS_SEL.setFirstSelected();
         MEDT_SPC_ANIMATION.setText("");
         MEDT_SPC_ACTIVATION.setText("");
         MEDT_SPC_LST.setText("");
         MEDT_ATK.setText("");
         MEDT_DEF.setText("");
         MEDT_MATK.setText("");
         MEDT_MDEF.setText("");
         MEDT_VIT.setText("");
         MEDT_MAG.setText("");
         MEDT_EVA.setText("");
         MEDT_ACC.setText("");
         MEDT_ATK_SEL.setFirstSelected();
         MEDT_DEF_SEL.setFirstSelected();
         MEDT_MATK_SEL.setFirstSelected();
         MEDT_MDEF_SEL.setFirstSelected();
         MEDT_VIT_SEL.setFirstSelected();
         MEDT_MAG_SEL.setFirstSelected();
         MEDT_EVA_SEL.setFirstSelected();
         MEDT_ACC_SEL.setFirstSelected();
         MEDT_DROPRATE.setText("");
         MEDT_ITEM_LST.clearSelection();
         MEDT_FIRE_RES.setText("");
         MEDT_WATER_RES.setText("");
         MEDT_EARTH_RES.setText("");
         MEDT_WIND_RES.setText("");
         MEDT_ICE_RES.setText("");
         MEDT_LIGHTENING_RES.setText("");
         MEDT_LIGHT_RES.setText("");
         MEDT_DARK_RES.setText("");
         MEDT_METAL_RES.setText("");
         MEDT_Arcana_EHN_SEL.setFirstSelected();
         MEDT_SPL_LST.clearSelection();
         %this.displayMainEditor();
         %this.SetMainPanel("Monsters");
         %this.LoadMonsters();
      }
   sqlite.closeDatabase();
   sqlite.delete();
}

function RPG_Editor::CancelMonsters(%this){
         MEDT_Name.setText("");
         MEDT_ISBOSS.setStateOn(false);
         MEDT_EXP.setText("");
         MEDT_LEVEL.setText("");
         MEDT_SHAPE.setText("");
         MEDT_CASTANIMATION.setText("");
         MEDT_AITATICS_SEL.setFirstSelected();
         MEDT_SPC_ANIMATION.setText("");
         MEDT_SPC_ACTIVATION.setText("");
         MEDT_SPC_LST.setText("");
         MEDT_ATK.setText("");
         MEDT_DEF.setText("");
         MEDT_MATK.setText("");
         MEDT_MDEF.setText("");
         MEDT_VIT.setText("");
         MEDT_MAG.setText("");
         MEDT_EVA.setText("");
         MEDT_ACC.setText("");
         MEDT_ATK_SEL.setFirstSelected();
         MEDT_DEF_SEL.setFirstSelected();
         MEDT_MATK_SEL.setFirstSelected();
         MEDT_MDEF_SEL.setFirstSelected();
         MEDT_VIT_SEL.setFirstSelected();
         MEDT_MAG_SEL.setFirstSelected();
         MEDT_EVA_SEL.setFirstSelected();
         MEDT_ACC_SEL.setFirstSelected();
         MEDT_DROPRATE.setText("");
         MEDT_ITEM_LST.clearSelection();
         MEDT_FIRE_RES.setText("");
         MEDT_WATER_RES.setText("");
         MEDT_EARTH_RES.setText("");
         MEDT_WIND_RES.setText("");
         MEDT_ICE_RES.setText("");
         MEDT_LIGHTENING_RES.setText("");
         MEDT_LIGHT_RES.setText("");
         MEDT_DARK_RES.setText("");
         MEDT_METAL_RES.setText("");
         MEDT_Arcana_EHN_SEL.setFirstSelected();
         MEDT_SPL_LST.clearSelection();
         %this.displayMainEditor();
         %this.SetMainPanel("Monsters");
         %this.LoadMonsters();
}


function RPG_Editor::UpdateMonsterCalc(%this){

   %level=MEDT_LEVEL.getText();
   %atk=HEDT_ATK.getText();
   %def=HEDT_DEF.getText();
   %matk=HEDT_MATK.getText();
   %mdef=HEDT_MDEF.getText();
   %vit=HEDT_VIT.getText();
   %mag=HEDT_MAG.getText();
   %eva=HEDT_EVA.getText();
   %acc=HEDT_ACC.getText();
   
   %_ATK=MEDT_ATK_SEL.getSelected();
   %_DEF=MEDT_DEF_SEL.getSelected();
   %_MATK=MEDT_MATK_SEL.getSelected();
   %_MDEF=MEDT_MDEF_SEL.getSelected();
   %_VIT=MEDT_VIT_SEL.getSelected();
   %_MAG=MEDT_MAG_SEL.getSelected();
   %_EVA=MEDT_EVA_SEL.getSelected();
   %_ACC=MEDT_ACC_SEL.getSelected();

   %Attack=mFloor((((%_ATK+%atk)*(%level))/1000)*999);
   %Defense=mFloor((((%_DEF+%def)*(%level))/1000)*999);
   %MagicAttack=mFloor((((%_MATK+%matk)*(%level))/1000)*999);
   %MagicDefense=mFloor((((%_MDEF+%mdef)*(%level))/1000)*999);
   %Vitality=mFloor((((%_VIT+%vit)*(%level))/1000)*999);
   %Magic=mFloor((((%_MAG+%mag)*(%level))/1000)*999);
   %Evasion=mFloor((((%_EVA+%eva)*(%level))/1000)*999);
   %Accuracy=mFloor((((%_ACC+%acc)*(%level))/1000)*999);
                      
   %MaxHP=%Vitality*12;
   %MaxMP=%Magic*12;
   %MaxKP=%level*12;
      
   MEDT_HP_CAL.setText(%MaxHP);
   MEDT_MP_CAL.setText(%MaxMP);
   MEDT_TP_CAL.setText(%MaxKP);
   MEDT_ATK_CAL.setText(%Attack);
   MEDT_DEF_CAL.setText(%Defense);
   MEDT_MATK_CAL.setText(%MagicAttack);
   MEDT_MDEF_CAL.setText(%MagicDefense);
   MEDT_VIT_CAL.setText(%Vitality);
   MEDT_MAG_CAL.setText(%Magic);
   MEDT_EVA_CAL.setText(%Evasion);
   MEDT_ACC_CAL.setText(%Accuracy);
      
}
