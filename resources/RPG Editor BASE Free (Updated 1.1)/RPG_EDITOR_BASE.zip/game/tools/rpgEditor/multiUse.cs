
function RPG_Editor::findDataFromIndex(%this, %lookUpObject, %DataArray2D, %indexCount)
{
   %ndxret = -1;
   for(%ndx = 0 ; %ndx < %indexCount ; %ndx++){
      if(%DataArray2D[%ndx,1]==%lookUpObject){
         %ndxret=%ndx;
         break;
      }
   }
   return %ndxret;
}

function RPG_Editor::findData(%this, %lookIndex,%DataArray2D)
{
   return %DataArray2D[%lookIndex,1];
}

function RPG_Editor::displayMainEditor(%this)
{
 if(($RPG_EDITOR_POPUP $= "") == 0){
   ("RPG_" @ $RPG_EDITOR_POPUP @ "_EDT").setVisible(false);
 }
 RPG_EDITOR_MAIN.setVisible(true);
}