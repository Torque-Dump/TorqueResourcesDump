//////////////////////////////////////////////////////////////////////////////////////
//   Inventory.h - Header File for the Inventory Manager
//////////////////////////////////////////////////////////////////////////////////////

#ifndef _INVENTORY_H_
#define _INVENTORY_H_

#include "platform/platform.h"

class Inventory  {

public:
Inventory();
~Inventory();
void AddItem(char* name, char* amount, char* type, char* description, char* max);
void RemoveItem(char* name);

void GetItem(char* type, char* rettype, char* retvalue); 

bool MoveCurrent(char* move); //move the currentpos pointer next, last, or first

bool IncAmount(char* name, char* samount);
bool DecAmount(char* name, char* samount);
bool SetAmount(char* name, char* samount);

void ClearInventory();
 
private:

struct InvItem {

char Name[256];
S32 Amount;
char Type[256];
char Description[256];
S32 Max;

};

struct InvLink {

InvItem ItemData;

InvLink* nextLink;
InvLink* lastLink;

};

InvLink* FirstItemInList;
InvLink* CurrentItemInList;

void AddLink(char* name, char* amount, char* type, char* description, char* max);  //Add a link to the link list
void DeleteLink(char* name);  //delete a link from the link list

bool NextLink(); //Go to the next link in the chain
bool LastLink(); //Go to the last link visited in the chain
InvLink* GetLink(char* name); //get the link equal to the name

};

#endif