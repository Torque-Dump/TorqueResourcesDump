/////////////////////////////////////////////////////////////////////////////////////
//
//  Inventory.cc
//
//  Used to hold Inventory Items
//
//  NOTE: Built in Link List due to the fact that STL has problems with Torque
//
/////////////////////////////////////////////////////////////////////////////////////


#include "game/Inventory.h"


//To make sure that it works on all platforms and compilers
///////////////////////////////////////////////////////////////
static const char* inItoa(S32 i)
{
   static char buf[32];
   dSprintf(buf, sizeof(buf), "%d", i);
   return buf;
}

///////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////
Inventory::Inventory() {

    FirstItemInList = NULL;
    CurrentItemInList = NULL;
}

///////////////////////////////////////////////////////////////
Inventory::~Inventory() {

    
	//cleanup all of the link list
	CurrentItemInList = NULL;

    if (FirstItemInList != NULL) {    
        while ( FirstItemInList->nextLink != NULL) {

	        FirstItemInList = FirstItemInList->nextLink;
		    delete FirstItemInList->lastLink;
        }

    	delete FirstItemInList;
	}
    
}

///////////////////////////////////////////////////////////////
//  Inventory functions
///////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////
//  Public function to add an item to the inventory
///////////////////////////////////////////////////////////////
void Inventory::AddItem(char* name, char* amount, char* type, char* description, char* max) {
	AddLink(name, amount, type, description, max);
}

///////////////////////////////////////////////////////////////
//  Public function to remove an item from the inventory
///////////////////////////////////////////////////////////////
void Inventory::RemoveItem(char* name) {
    DeleteLink(name);
}

///////////////////////////////////////////////////////////////
//  Returns the rettype (name, amount, description, all) from 
//  the type (first current, name)
///////////////////////////////////////////////////////////////
void Inventory::GetItem(char* type, char* rettype, char* retvalue) {

	if (dStricmp(type, "first") == 0) {  //first Item in list
		
		if (dStricmp(rettype, "name") == 0) {

			dStrcpy(retvalue, FirstItemInList->ItemData.Name);
			return;

		} else if (dStricmp(rettype, "amount") == 0) {

			dStrcpy(retvalue, inItoa(FirstItemInList->ItemData.Amount));
			return;

        } else if (dStricmp(rettype, "type") == 0) {

			dStrcpy(retvalue, FirstItemInList->ItemData.Type);
			return;


        } else if (dStricmp(rettype, "description") == 0) {

			dStrcpy(retvalue, FirstItemInList->ItemData.Description);
			return;

        } else if (dStricmp(rettype, "max") == 0) {

			
			dStrcpy(retvalue, inItoa(FirstItemInList->ItemData.Max));
			return;

		} else {  //return all separated by \t

			dStrcpy(retvalue, FirstItemInList->ItemData.Name);
            dStrcatl(retvalue, sizeof(retvalue), "\t", inItoa(FirstItemInList->ItemData.Amount), "\t", FirstItemInList->ItemData.Type, "\t", FirstItemInList->ItemData.Description, NULL);
			return;
		}

	} else if (dStricmp(type, "current") == 0) {  //current item in list

        if (dStricmp(rettype, "name") == 0) {

            dStrcpy(retvalue, CurrentItemInList->ItemData.Name);
			return;

		} else if (dStricmp(rettype, "amount") == 0) {

            dStrcpy(retvalue, inItoa(CurrentItemInList->ItemData.Amount));
			return;

        } else if (dStricmp(rettype, "type") == 0) {

            dStrcpy(retvalue, CurrentItemInList->ItemData.Type);
			return;

        } else if (dStricmp(rettype, "description") == 0) {

            dStrcpy(retvalue, CurrentItemInList->ItemData.Description);
			return;

		} else if (dStricmp(rettype, "max") == 0) {

			dStrcpy(retvalue, inItoa(CurrentItemInList->ItemData.Max));
			return;


		} else {  //return all separated by \t

			dStrcpy(retvalue, CurrentItemInList->ItemData.Name);
			dStrcatl(retvalue, sizeof(retvalue), "\t", inItoa(CurrentItemInList->ItemData.Amount), "\t", CurrentItemInList->ItemData.Type, "\t", CurrentItemInList->ItemData.Description, NULL);
			return;
            
		}

	} else {

        InvLink* tempLink = GetLink(type);

        if (tempLink != NULL) {
			if (dStricmp(rettype, "name") == 0) {

			    dStrcpy(retvalue, tempLink->ItemData.Name);
				return;

			} else if (dStricmp(rettype, "amount") == 0) {

				dStrcpy(retvalue, inItoa(tempLink->ItemData.Amount));
				return;

            } else if (dStricmp(rettype, "type") == 0) {

				dStrcpy(retvalue, tempLink->ItemData.Type);
				return;

		    } else if (dStricmp(rettype, "description") == 0) {

				dStrcpy(retvalue, tempLink->ItemData.Description);
				return;

			} else if (dStricmp(rettype, "max") == 0) {

			dStrcpy(retvalue, inItoa(tempLink->ItemData.Max));
			return;


			} else {  //return all separated by \t

			    dStrcpy(retvalue, tempLink->ItemData.Name);
			    dStrcatl(retvalue, sizeof(retvalue), "\t", inItoa(tempLink->ItemData.Amount), "\t", tempLink->ItemData.Type, "\t", tempLink->ItemData.Description, NULL);	
				return;

			}
		}

	}

}

///////////////////////////////////////////////////////////////
//  move the currentpos pointer next, last, or first
///////////////////////////////////////////////////////////////
bool Inventory::MoveCurrent(char* move) {

	if (dStricmp(move, "next") == 0) {
	
		return NextLink();

	} else if (dStricmp(move, "last") == 0) {
	
	    return LastLink();

	} else if (dStricmp(move, "first") == 0) {
	
        CurrentItemInList = FirstItemInList;
		if (CurrentItemInList != NULL)
		    return true;
		else
		    return false;

	}

	return false;

}

///////////////////////////////////////////////////////////////
//  Increment Amount
///////////////////////////////////////////////////////////////
bool Inventory::IncAmount(char* name, char* samount) {

    InvLink* tempLink = GetLink(name);
    S32 amount = dAtoi(samount);

    if (tempLink != NULL) {
		if ((tempLink->ItemData.Amount + amount) <= tempLink->ItemData.Max) {

			tempLink->ItemData.Amount += amount;
			return true;
		} else {
		    if (tempLink->ItemData.Amount < tempLink->ItemData.Max) {
				tempLink->ItemData.Amount = tempLink->ItemData.Max;
				return true;
			}
		}
	}

	return false;

}

///////////////////////////////////////////////////////////////
//  Decrement Amount
///////////////////////////////////////////////////////////////
bool Inventory::DecAmount(char* name, char* samount) {

    InvLink* tempLink = GetLink(name);
	S32 amount = dAtoi(samount);

    if (tempLink != NULL) {
		if ((tempLink->ItemData.Amount - amount) >= 0) {

			tempLink->ItemData.Amount -= amount;
			return true;
		}
		else {
		    if (tempLink->ItemData.Amount > 0) {
				tempLink->ItemData.Amount = 0;
				return true;
			}
		}
	}

	return false;

}

///////////////////////////////////////////////////////////////
//  Set Amount
///////////////////////////////////////////////////////////////
bool Inventory::SetAmount(char* name, char* samount) {

    InvLink* tempLink = GetLink(name);
	S32 amount = dAtoi(samount);

    if (tempLink != NULL) {
		tempLink->ItemData.Amount = amount;
		return true;
	}	

	return false;

}

///////////////////////////////////////////////////////////////
//  Clears the Amount
///////////////////////////////////////////////////////////////
void Inventory::ClearInventory() {

    InvLink* getLink = FirstItemInList;

    if (getLink != NULL) {
		while ( getLink->nextLink != NULL) {

			getLink->ItemData.Amount = 0;

			getLink = getLink->nextLink;
		}
	}

	if (getLink != NULL) {
		getLink->ItemData.Amount = 0;
	}

}

///////////////////////////////////////////////////////////////
//  Link List helper functions
///////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////
//  Add a link to the link list
///////////////////////////////////////////////////////////////
void Inventory::AddLink(char* name, char* amount, char* type, char* description, char* max) {

	if (FirstItemInList == NULL) {  //the list is empty

		FirstItemInList = new InvLink;
		dStrcpy(FirstItemInList->ItemData.Name, name);
		FirstItemInList->ItemData.Amount =  dAtoi(amount);
        dStrcpy(FirstItemInList->ItemData.Type, type);
        dStrcpy(FirstItemInList->ItemData.Description, description);
        FirstItemInList->ItemData.Max =  dAtoi(max);
		FirstItemInList->nextLink = NULL;
        FirstItemInList->lastLink = NULL;
		CurrentItemInList = FirstItemInList;

	} else {

        InvLink* sortLink = FirstItemInList;
		
		while ( sortLink->nextLink != NULL)
		    sortLink = sortLink->nextLink;

        InvLink* tempLink = new InvLink;
		
        dStrcpy(tempLink->ItemData.Name, name);
		tempLink->ItemData.Amount = dAtoi(amount);
		dStrcpy(tempLink->ItemData.Type, type);
        dStrcpy(tempLink->ItemData.Description, description);
		tempLink->ItemData.Max = dAtoi(max);
		tempLink->nextLink = NULL;
		
		sortLink->nextLink = tempLink;
		tempLink->lastLink = sortLink;

	}

}  

///////////////////////////////////////////////////////////////
//  Delete a link from the link list
///////////////////////////////////////////////////////////////
void Inventory::DeleteLink(char* name) {

    InvLink* deleteLink = GetLink(name);
			
    if (deleteLink != NULL) {
		if (deleteLink->lastLink == NULL) { //This is the first link...treat it special
				
			FirstItemInList = deleteLink->nextLink;
			deleteLink->nextLink = NULL;
			FirstItemInList->lastLink = NULL;
			
		} else {
                
			if (deleteLink->nextLink != NULL) {
				deleteLink->nextLink->lastLink = deleteLink->lastLink;
				deleteLink->lastLink = NULL;
				deleteLink->nextLink->lastLink->nextLink = deleteLink->nextLink;
				deleteLink->nextLink = NULL;
			} else {
				deleteLink->lastLink->nextLink = NULL;
			}
		}
			
		delete deleteLink;
	}

}

///////////////////////////////////////////////////////////////
//  Go to the next link in the chain
///////////////////////////////////////////////////////////////
bool Inventory::NextLink() { 

    if (CurrentItemInList->nextLink != NULL) {
    
	   CurrentItemInList = CurrentItemInList->nextLink;
	   return true;
	}

    return false;
}

///////////////////////////////////////////////////////////////
//  Go to the last link visited in the chain
///////////////////////////////////////////////////////////////
bool Inventory::LastLink() {

   if (CurrentItemInList->lastLink != NULL) {
       
       CurrentItemInList = CurrentItemInList->lastLink;
	   return true;
   }

   return false;
}

///////////////////////////////////////////////////////////////
//  Get link equal to the name
///////////////////////////////////////////////////////////////
Inventory::InvLink* Inventory::GetLink(char* name) { 

    InvLink* getLink = FirstItemInList;

    if (getLink != NULL) {
		while ( getLink->nextLink != NULL) {

			if (dStricmp(getLink->ItemData.Name,name) == 0) {

				return getLink;
			}
			getLink = getLink->nextLink;
		}
	}

	if (getLink != NULL) {
		if (dStricmp(getLink->ItemData.Name,name) == 0) {

				return getLink;
		}
	}


   return NULL;
}


