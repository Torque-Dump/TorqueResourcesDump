//////////////////////////////////////////////////////////////
//  File:  tog_BumperCar.cs
//  Version: 1.0.0
//
//  Author:  William McGuire (WGM)
//
//  Creation Date:  Mar 7, 2004
//
//  Purpose:  Creates a Bumper Car (Vehicle)
//
//  Last Updated:  None
//////////////////////////////////////////////////////////////

// exec("starter.fps/BumperCar/tog_BumperCar.cs");

$bumperCarMountTransform = "0 0 5 0 0 1 0";

datablock HoverVehicleData(BumperCar)
{
   category = "Vehicles";

   shapeFile = "starter.fps/data/shapes/BumperCar/tog_BumperCar.dts";

   emap = true;

   floatingGravMag = 50.5;
   ComputeCRC = true;

   drag = 0.0;
   density = 0.3;

   cameraMaxDist = 5.0;
   cameraOffset = 5.7;
   cameraLag = 5.5;

   lightOnly = 1;

   maxDamage = 0;

   // --- Rigid Body
   mass = 10;
   bodyFriction = 0;
   bodyRestitution = 0.5;
   softImpactSpeed = 20;
   hardImpactSpeed = 28;

   dragForce = 2;
   vertFactor = 0.5;
   floatingThrustFactor = 0.5;

   mainThrustForce = 100;
   reverseThrustForce = 70;
   strafeThrustForce = 70;

   brakingForce = 30;
   brakingActivationSpeed = 30;

   stabLenMin = 6.50;
   stabLenMax = 7.25;
   stabSpringConstant = 20;
   stabDampingConstant = 20;

   steeringForce = 90;

   minMountDist = 8;
   maxMountSpeed = 10;
   maxDismountSpeed = 10;
   mountable = true;
   numMountPoints = 1;

   mountPose[0] = Sitting;
   mountPointTransform[0] = $bumperCarMountTransform;
   isProtectedMountPoint[0] = false;

   mountDelay = 2;
   dismountDelay = 1;

   stationaryThreshold = 0.5;

   checkRadius = 1.7785;
   observeParameters = "1 10 10";

   integration = 4;
   collisionTOL = 0.1;
   collContactTOL = 0.1;
};

datablock HoverVehicleData(BumperCar_Blue)
{
   category = "Vehicles";

   shapeFile = "starter.fps/data/shapes/BumperCar/tog_BumperCar_Blue.dts";

   //emap = true;

   floatingGravMag = 50.5;
   //ComputeCRC = true;

   drag = 0.0;
   density = 0.3;

   cameraMaxDist = 5.0;
   cameraOffset = 5.7;
   cameraLag = 5.5;

   lightOnly = 1;

   maxDamage = 0;

   // --- Rigid Body
   mass = 10;
   bodyFriction = 0;
   bodyRestitution = 0.5;
   softImpactSpeed = 20;
   hardImpactSpeed = 28;

   dragForce = 2;
   vertFactor = 0.5;
   floatingThrustFactor = 0.5;

   mainThrustForce = 100;
   reverseThrustForce = 70;
   strafeThrustForce = 70;

   brakingForce = 30;
   brakingActivationSpeed = 30;

   stabLenMin = 6.50;
   stabLenMax = 7.25;
   stabSpringConstant = 20;
   stabDampingConstant = 20;

   steeringForce = 90;

   minMountDist = 8;
   maxMountSpeed = 10;
   maxDismountSpeed = 10;
   mountable = true;
   numMountPoints = 1;

   mountPose[0] = Sitting;
   mountPointTransform[0] = $bumperCarMountTransform;
   isProtectedMountPoint[0] = false;

   mountDelay = 2;
   dismountDelay = 1;

   stationaryThreshold = 0.5;

   checkRadius = 1.7785;
   observeParameters = "1 10 10";

   integration = 4;
   collisionTOL = 0.1;
   collContactTOL = 0.1;
};

datablock HoverVehicleData(BumperCar_Green)
{
   category = "Vehicles";

   shapeFile = "starter.fps/data/shapes/BumperCar/tog_BumperCar_Green.dts";

   //emap = true;

   floatingGravMag = 50.5;
   //ComputeCRC = true;

   drag = 0.0;
   density = 0.3;

   cameraMaxDist = 5.0;
   cameraOffset = 5.7;
   cameraLag = 5.5;

   lightOnly = 1;

   maxDamage = 0;

   // --- Rigid Body
   mass = 10;
   bodyFriction = 0;
   bodyRestitution = 0.5;
   softImpactSpeed = 20;
   hardImpactSpeed = 28;

   dragForce = 2;
   vertFactor = 0.5;
   floatingThrustFactor = 0.5;

   mainThrustForce = 100;
   reverseThrustForce = 70;
   strafeThrustForce = 70;

   brakingForce = 30;
   brakingActivationSpeed = 30;

   stabLenMin = 6.50;
   stabLenMax = 7.25;
   stabSpringConstant = 20;
   stabDampingConstant = 20;

   steeringForce = 90;

   minMountDist = 8;
   maxMountSpeed = 10;
   maxDismountSpeed = 10;
   mountable = true;
   numMountPoints = 1;

   mountPose[0] = Sitting;
   mountPointTransform[0] = $bumperCarMountTransform;
   isProtectedMountPoint[0] = false;

   mountDelay = 2;
   dismountDelay = 1;

   stationaryThreshold = 0.5;

   checkRadius = 1.7785;
   observeParameters = "1 10 10";

   integration = 4;
   collisionTOL = 0.1;
   collContactTOL = 0.1;
};

datablock HoverVehicleData(BumperCar_Pink)
{
   category = "Vehicles";

   shapeFile = "starter.fps/data/shapes/BumperCar/tog_BumperCar_Pink.dts";

   //emap = true;

   floatingGravMag = 50.5;
   //ComputeCRC = true;

   drag = 0.0;
   density = 0.3;

   cameraMaxDist = 5.0;
   cameraOffset = 5.7;
   cameraLag = 5.5;

   lightOnly = 1;

   maxDamage = 0;

   // --- Rigid Body
   mass = 10;
   bodyFriction = 0;
   bodyRestitution = 0.5;
   softImpactSpeed = 20;
   hardImpactSpeed = 28;

   dragForce = 2;
   vertFactor = 0.5;
   floatingThrustFactor = 0.5;

   mainThrustForce = 100;
   reverseThrustForce = 70;
   strafeThrustForce = 70;

   brakingForce = 30;
   brakingActivationSpeed = 30;

   stabLenMin = 6.50;
   stabLenMax = 7.25;
   stabSpringConstant = 20;
   stabDampingConstant = 20;

   steeringForce = 90;

   minMountDist = 8;
   maxMountSpeed = 10;
   maxDismountSpeed = 10;
   mountable = true;
   numMountPoints = 1;

   mountPose[0] = Sitting;
   mountPointTransform[0] = $bumperCarMountTransform;
   isProtectedMountPoint[0] = false;

   mountDelay = 2;
   dismountDelay = 1;

   stationaryThreshold = 0.5;

   checkRadius = 1.7785;
   observeParameters = "1 10 10";

   integration = 4;
   collisionTOL = 0.1;
   collContactTOL = 0.1;
};

datablock HoverVehicleData(BumperCar_Purple)
{
   category = "Vehicles";

   shapeFile = "starter.fps/data/shapes/BumperCar/tog_BumperCar_Purple.dts";

   //emap = true;

   floatingGravMag = 50.5;
   //ComputeCRC = true;

   drag = 0.0;
   density = 0.3;

   cameraMaxDist = 5.0;
   cameraOffset = 5.7;
   cameraLag = 5.5;

   lightOnly = 1;

   maxDamage = 0;

   // --- Rigid Body
   mass = 10;
   bodyFriction = 0;
   bodyRestitution = 0.5;
   softImpactSpeed = 20;
   hardImpactSpeed = 28;

   dragForce = 2;
   vertFactor = 0.5;
   floatingThrustFactor = 0.5;

   mainThrustForce = 100;
   reverseThrustForce = 70;
   strafeThrustForce = 70;

   brakingForce = 30;
   brakingActivationSpeed = 30;

   stabLenMin = 6.50;
   stabLenMax = 7.25;
   stabSpringConstant = 20;
   stabDampingConstant = 20;
   
   steeringForce = 90;

   minMountDist = 8;
   maxMountSpeed = 10;
   maxDismountSpeed = 10;
   mountable = true;
   numMountPoints = 1;

   mountPose[0] = Sitting;
   mountPointTransform[0] = $bumperCarMountTransform;
   isProtectedMountPoint[0] = false;

   mountDelay = 2;
   dismountDelay = 1;

   stationaryThreshold = 0.5;

   checkRadius = 1.7785;
   observeParameters = "1 10 10";

   integration = 4;
   collisionTOL = 0.1;
   collContactTOL = 0.1;
};

//-----------------------------------------------------------------------------

function HoverVehicleData::create(%block)
{
   %obj = new HoverVehicle()
   {
      dataBlock = %block;
   };
   return(%obj);
}

//-----------------------------------------------------------------------------

function HoverVehicleData::onAdd(%this,%obj)
{
   // I don't know what to do here
   // this will remain blank for now
}

function HoverVehicleData::onCollision(%this,%obj,%col,%vec,%speed)
{
   if (%col.getVelocity() && %col.category == "Vehicles")
   {
      echo("Player" SPC %col.playerName SPC "hit" SPC %obj.playerName);

      %pos = %obj.getPosition();
      %fwVec = %col.getForwardVector();

      %impulseVec = VectorScale(%fwVec, 1);

      %obj.applyImpulse(%pos, vectorScale(%impulseVec, 50));

      %impulseVec = VectorScale(%fwVec, -1);

      %col.applyImpulse(%pos, vectorScale(%impulseVec, 25));
   }
}

function AddCar()
{
   commandToServer('addcar');
}

function GetInCar()
{
   commandToServer('mountvehicle');
}

function isVehicleMoving(%vehicle)
{
   // Calculate the vehicle's velocity
   %vel = %vehicle.getVelocity();
   %speed = vectorLen(%vel);

   // Determine if the vehicle is moving according to the
   // threshold value defined in the vehicle's datablock.
   if (%speed > %vehicle.getDataBlock().stationaryThreshold)
      return true;
   else
      return false;
}

function getVehicleSpeed(%vehicle)
{
   %vel = %vehicle.getVelocity();
   %speed = vectorLen(%vel);
   return %speed;
}

function onMountVehicle(%vehicle, %obj, %col)
{
   // Is the vehicle currently mountable?
   if (%col.mountable == false)
   {
      echo("Sorry, the vehicle is not mountable.");
      return;
   }

   // Check the speed of the vehicle. If it's moving, we can't mount it.
   // Note there is a threshold that determines if the vehicle is moving.
   %vel = %col.getVelocity();
   %speed = vectorLen(%vel);

   if ( %speed <= %vehicle.maxMountSpeed )
   {
      // Find an empty seat
      %seat = findEmptySeat(%col, %vehicle);

      %obj.mVehicle = %col;
      %obj.mSeat = %seat;
      %obj.isMounted = true;

      echo("Mounting vehicle in seat " @ %seat);

      // Now mount the vehicle.
      %col.mountObject(%obj,%seat);
   }
   else
   {
      echo("You cannot mount a moving vehicle.");
   }
}

function findNextFreeSeat(%client, %vehicle, %vehicleblock)
{
   // Check the next seat
   %seat = %client.player.mSeat + 1;

   if (%seat == %vehicleblock.numMountPoints)
   {
      // Check from seat 0, we've run out of seats to check.
      %seat = 0;
   }

   // Reset the flag.
   %found = false;

   // Search through the seats.
   while ((%seat != %client.player.mSeat) && (%found == false))
   {
      if (%seat >= %vehicleblock.numMountPoints)
      {
         // Go back to the first (driver's) seat
         %seat = 0;
      }

      // Is this seat free?
      %node = %vehicle.getMountNodeObject(%seat);

      if (%node == 0)
      {
         // Yes it is free.
         %found = true;
      }
      if (%found == false)
      {
         // We couldn't find a free seat.
         %seat++;
      }
   }

   if (%found == false)
      return -1;
   else
      return %seat;
}

function findPreviousFreeSeat(%client, %vehicle, %vehicleblock)
{
   // Check the previous seat
   %seat = %client.player.mSeat - 1;

   if (%seat == -1)
   {
      // Check from the last seat
      echo("Checking from seat " @ %seat);
   }

   %found = false;

   // Search through the seats.
   while ((%seat != %client.player.mSeat) && (%found == false))
   {
      if (%seat < 0)
      {
         %seat = %vehicleblock.numMountPoints - 1;
      }

      %node = %vehicle.getMountNodeObject(%seat);

      if (%node == 0)
      {
         %found = true;
      }
      if (%found == false)
         %seat--;
   }

   if (%found == false)
      return -1;
   else
      return %seat;
}

function findEmptySeat(%vehicle, %vehicleblock)
{
   echo("This vehicle has " @ %vehicleblock.numMountPoints @ " mount points.");
   for (%i = 0; %i <  %vehicleblock.numMountPoints; %i++)
   {
      %node = %vehicle.getMountNodeObject(%i);
      if (%node == 0)
      {
         return %i;
      }
   }
   return -1;
}

function setActiveSeat(%client, %vehicle, %vehicleblock, %seat)
{
   echo("Set Active Seat Executed");

   %client.setTransform(%vehicle.getDataBlock().mountPointTransform[%seat]);
   %vehicle.mountObject(%client,%seat);
   %client.mVehicle = %vehicle;

   //CommandToClient(%obj.client, 'PopActionMap', moveMap);
   //CommandToClient(%obj.client, 'PushActionMap', $Vehicle::moveMaps[%seat]);

   %client.mSeat = %seat;

   %client.setActionThread(%vehicle.getDatablock().mountPose[%seat],true,true);

   // Are we driving this vehicle?
   if (%seat == 0)
   {
      %client.setControlObject(%vehicle);
      %client.setArmThread("sitting");
   }
   else
   {
      %client.setControlObject(%client);
      %client.setArmThread("looknw");
   }
}

function onPlayerMount(%player,%obj,%vehicle,%node)
{
   echo("onPlayerMount Executed ---");

   //CommandToClient(%obj.client, 'PopActionMap', moveMap);
   //CommandToClient(%obj.client, 'PushActionMap', $Vehicle::moveMaps[%node]);
   //CommandToClient(%obj.client,'HideCommandMenuServer');

   %obj.setTransform(%vehicle.getDataBlock().mountPointTransform[%node]);
   %obj.lastWeapon = %obj.getMountedImage($WeaponSlot);
   %obj.unmountImage($WeaponSlot);
   %obj.setActionThread(%vehicle.getDatablock().mountPose[%node],true,true);

   // Are we driving this vehicle?
   if (%node == 0)  {
      %obj.setControlObject(%vehicle);
   }
}

function onPlayerUnmount(%player, %obj, %vehicle, %node)
{
   %obj.mountImage(%obj.lastWeapon, $WeaponSlot);
}

function doPlayerDismount(%player, %obj, %forced)
{
   %vel = %obj.getVelocity();
   %speed = vectorLen(%vel);

   // Check our speed. If we're still moving, we can't dismount.
   if (%speed >= 1 || !%obj.isMounted())
   {
      // The vehicle is moving or the player is not mounted.
      return;
   }

   // Find the position above dismount point.
   %pos    = getWords(%obj.getTransform(), 0, 2);
   %oldPos = %pos;
   %vec[0] = " 2  0  0";
   %vec[1] = " 0  -2  0";
   %vec[2] = " 0  2  0";
   %vec[3] = "-2  0  0";
   %vec[4] = " 4  0  0";
   %impulseVec  = "0 0 0";
   %vec[0] = MatrixMulVector( %obj.getTransform(), %vec[0]);

   // Make sure the point is valid
   %pos = "0 0 0";
   %numAttempts = 5;
   %success     = -1;
   for (%i = 0; %i < %numAttempts; %i++) {
      %pos = VectorAdd(%oldPos, VectorScale(%vec[%i], 3));
      if (%obj.checkDismountPoint(%oldPos, %pos)) {
         %success = %i;
         %impulseVec = %vec[%i];
         break;
      }
   }

   if (%forced && %success == -1)
      %pos = %oldPos;

   %obj.unmount();
   %obj.setControlObject(%obj);
   %obj.mountVehicle = false;

   // Schedule the function to set the mount flag, so that the player
   // can mount another vehicle in the future.
   %obj.schedule(4000, "MountVehicles", true);

   // Position above dismount point
   %obj.setTransform(%pos);
   %obj.applyImpulse(%pos, VectorScale(%impulseVec, %obj.getDataBlock().mass));

   %obj.setActionThread("run",true,true);
   %obj.setArmThread("look");

   // Command the client to display the correct movement map and
   // activate the command menu.
   //CommandToClient(%obj.client, 'PopActionMap', $Vehicle::moveMaps[%obj.mSeat]);
   //CommandToClient(%obj.client, 'PushActionMap', moveMap);
   //CommandToClient(%obj.client,'activateCommandMenu');
}

function serverCmdAddCar(%client, %strColor)
{
   if (%client.player $= "" )
      return;

   if (%client.player) {
      if (%client.player.isMounted())
         return;
   }

   switch$(%strColor)
   {
      case "Green": // Used with Mikey
         %dataBlockToUse = BumperCar_Green;

      case "Pink": // Used with Jessica
         %dataBlockToUse = BumperCar_Pink;

      case "Blue" : // Used with Johnny
         %dataBlockToUse = BumperCar_Blue;

      case "Purple" : // Used with Kelli
         %dataBlockToUse = BumperCar_Purple;

      default: // Default car is Red
         %dataBlockToUse = BumperCar;
   }

   %car = new HoverVehicle()
   {
      dataBlock = %dataBlockToUse;
   };

   %car.mountable = true;
   %car.setEnergyLevel(1000);

   // Get the player's position. We will use this to
   // place the car near the player.
   %pos = %client.player.getTransform();
   %x = getWord(%pos, 0);
   %y = getWord(%pos, 1);
   %z = getWord(%pos, 2);
   //%x += 5.0;
   %y += 5.0;
   %z += 1.0;
   %car.setTransform(%x SPC %y SPC %z);

   MissionCleanup.add(%car);
}

function serverCmdMountVehicle(%client)
{
   //Determine how far should the picking ray extend into the world?
   %selectRange = 8;
   
   // Only search for vehicles
   %searchMasks = $TypeMasks::vehicleObjectType;
   %pos = %client.player.getEyePoint();
   
   // Start with the shape's eye vector...
   %eye = %client.player.getEyeVector();
   %eye = vectorNormalize(%eye);
   %vec = vectorScale(%eye, %selectRange);
   %end = vectorAdd(%vec, %pos);
   %scanTarg = ContainerRayCast (%pos, %end, %searchMasks);
   
   // a target in range was found so select it
   if (%scanTarg)
   {
      %targetObject = firstWord(%scanTarg);
      echo("Found a vehicle: " @ %targetObject);
      onMountVehicle(%targetObject.getDataBlock(), %client.player, %targetObject);
   }
   else
   {
      echo("No object found");
   }
}

function serverCmdDismountVehicle(%client)
{
   doPlayerDismount(%client, %client.player, %true);
}

// exec("starter.fps/BumperCar/tog_BumperCar.cs");
