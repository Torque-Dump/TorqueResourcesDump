

singleton GuiControlProfile( GuiServerBrowserHeaderProfile )
{
	opaque = false;
	border = "1";

	fontColor = "0 0 0 255";
	fontColorHL = "0 0 255 255";
	fontColorNA = "0 0 0 255";
	//fontColorSEL ="0 0 0";
	fixedExtent = 0;
	justify = "center";
	canKeyFocus = false;
	bitmap = "core/art/gui/images/server_tabs";
	hasBitmapArray = "1";
	category = "Core";
   fontColors[1] = "0 0 255 255";
   fontColors[3] = "0 0 0 255";
   fontColorSEL = "0 0 0 255";
   profileForChildren = "";
   fillColor = "0 255 160 160";
};

singleton GuiControlProfile( GuiServerBrowserProfile )
{
	opaque = false;
	border = "0";

	fontColor = "0 255 136 255";
	fontColorHL = "255 255 255";
	fontColorNA = "180 180 180";
	//fontColorSEL ="0 0 0";
	fixedExtent = 0;
	justify = "center";
	canKeyFocus = true;
	hasBitmapArray = "0";
	category = "Core";
   fontColors[0] = "0 255 136 255";
   fontColors[1] = "255 255 255 255";
   fontColors[2] = "180 180 180 255";
   fillColorHL = "2 138 204 255";
   fillColorSEL = "1 147 103 255";
   fillColor = "242 241 240 53";
   fillColorNA = "1 147 103 141";
   borderThickness = "0";
};

singleton GuiControlProfile( GuiServerBrowserSortProfile )
{
	opaque = false;
	border = "1";
	fixedExtent = 0;
	justify = "Bottom";
	canKeyFocus = false;
	bitmap = "core/art/gui/images/shll_sortarrow";
	hasBitmapArray = "0";
	category = "Core";
	fontColors[0] = "255 255 255 255";
	fontColors[1] = "255 255 255 255";
	fontColors[2] = "255 255 255 255";
   fontColor = "255 255 255 255";
   fontColorHL = "255 255 255 255";
   fontColorNA = "255 255 255 255";
   fontColors[4] = "255 255 255 255";
   fontColors[5] = "255 255 255 255";
   fontColors[6] = "255 255 255 255";
   fontColors[7] = "255 255 255 255";
   fontColors[8] = "255 255 255 255";
   fontColors[9] = "255 255 255 255";
   fontColorLink = "255 255 255 255";
   fontColorLinkHL = "255 255 255 255";
   returnTab = "1";
};

singleton GuiControlProfile(GuiServerScrollProfile : GuiScrollProfile)
{
   opaque = "0";
   fillColor = "2 254 184 255";
};

singleton GuiControlProfile(GuiServerScrollBProfile : GuiServerScrollProfile)
{
   opaque = "1";
   fillColor = "0 0 0 255";
};

