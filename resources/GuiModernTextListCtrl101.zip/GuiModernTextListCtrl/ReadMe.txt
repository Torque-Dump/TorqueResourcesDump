GuiModernTextListCtrl version 1.01 -- 2011-09-19 (Monday, September 19th, 2011)

The use of the GuiModernTextListCtrl is governed by the license as described in License.txt text file.
This control was specifically developed and tested for Torque 3D 1.1 Final and later, no promises for
any other Torque engine.

Documentation and updates can be found at:
   http://dottools.net/doku.php/programming/tge/controls/guimoderntextlistctrl


Install and compile:

1) Copy the header and source files (.h, .cpp) to the <Torque 3D directory>/Engine/source/gui/controls directory.
2) Add the header and source files to your Visual Studio (or makefile, etc..) Torque 3D project file.
4) Apply any bug fixes to other parts of the Torque engine by reading Torque Bug Fixes section of this document.
5) Build the project and hopefully it'll be a successful build.


To make use of the Game Browser simulator Demonstration GUI Dialog:

1) Copy the provided game/ directory to your Torque 3D project's directory and if prompted press Yes to copy over existing directory.
2) Nagivate to the game/core/ directory and to make sure that customProfiles.cs and GameBrowserGui.gui are executed by editing the main.cs file and add the following lines:

   Find function onStart() and go to the end of the function, but just above this line:
   echo(" % - Initialized Core");

   Insert the following lines above it:
   exec("./art/gui/customProfiles.cs");
   exec("./art/gui/GameBrowserGui.gui");

3) Save the game/core/main.cs file and now go navigate to the game/art/gui/ directory
4) Rename your existing mainMenuGui.gui file to something like mainMenuGui_Original.gui
5) Rename the provided mainMenuGui_ModernTextList.gui file to mainMenuGui.gui
6) Now launch your game executable that you've just built after following the compile steps.
7) Click on the "Try Experimental Server Browser" button to open the Game Browser dialog.
8) Play around with the simulated server list, Customize button brings up a simple list preferences editor.
9) Enjoy!


Torque Bug Fixes:

A) guiArrayCtrl Clip Rectangle Fix -- effects Torque 3D 1.1 Final and earlier (possibly TGEA too)
   Engine/source/gui/core/guiArrayCtrl.cpp has a debug in the OnRender() method that causes drawn
   content to leak below the control's vertical bounds (bottom side) which is due to an incorrect
   clip rectangle update after rendering of column headers.

   Patch file guiArrayCtrl_Fixes-20110912.patch is provided to fix this, but to manually fix the
   problem continue to read the instructions.

   Open Engine/source/gui/core/guiArrayCtrl.cpp source file for editing.

   Scroll down to this method:
   void GuiArrayCtrl::onRender(Point2I offset, const RectI &updateRect)

   Search for:
         clipRect.point.y = headerClip.point.y + headerClip.extent.y - 1;

   And replace it with these two lines:
         clipRect.point.y  += headerClip.extent.y;
         clipRect.extent.y -= headerClip.extent.y;

   Now save and you're done manually patching guiArrayCtrl.cpp.

Now go back to the Install and compile instructions above in this document.


	-Nathan Martin / TRON

Document last updated on 2011-09-19.
