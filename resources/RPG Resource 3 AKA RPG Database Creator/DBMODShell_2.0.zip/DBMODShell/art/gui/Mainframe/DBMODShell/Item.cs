//------------------------------------------------------------------------------
// Torque        Engine
// Copyright (C) GarageGames.com, Inc.
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// OnclassLoad methods
//------------------------------------------------------------------------------

$ItemGUI::SAVEID="";
$ItemGUI::CreateNew=1;

function ItemGui::LoadItems()
{
   ItemList.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Items;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ItemList.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}


function ItemGui::LoadItemTypes()
{
   ItemTypeList.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from ItemTypes;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ItemTypeList.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   ItemTypeList.clearSelection();
   ItemTypeList.setCurSel(0);
}


function ItemGui::LoadArcana()
{
   ArcanaList.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Arcana;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      ArcanaList.addItem("None");
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ArcanaList.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   ArcanaList.clearSelection();
   ArcanaList.setCurSel(0);
}


function ItemGui::LoadStatus()
{
   StatusList.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Statuses;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      StatusList.addItem("None");
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         StatusList.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   StatusList.clearSelection();
   StatusList.setCurSel(0);
}


function ItemGui::LoadParams()
{
   ParamList.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Parameters;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      
      ParamList.addItem("None");
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ParamList.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   ParamList.clearSelection();
   ParamList.setCurSel(0);
}


function ItemGui::LoadRanges()
{
   RangeList.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Ranges;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         RangeList.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   RangeList.clearSelection();
   RangeList.setCurSel(0);
}


function ItemGui::onWake(%this)
{
   ItemGui.LoadItems();
   ItemGui.LoadItemTypes();
   ItemGui.LoadArcana();
   ItemGui.LoadStatus();
   ItemGui.LoadParams();
   ItemGui.LoadRanges();
   ItemName.setText("");
   Variance.setText("");
   Potency.setText("");
   Cost.setText("");
   Description.setText("");
   Image.setText("");
   Animation.setText("");
   OutPartyUse.setText("");
   InPartyUse.setText("");
   MaxQuantity.setText("");
}

//------------------------------------------------------------------------------
// global methods
//------------------------------------------------------------------------------

/// Callback from the shell button for triggering single Item.
function ItemGui::LoadMain()
{
   Canvas.setContent(DBMODGui);
}

function ItemGui::SaveItem()
{
      %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   %pname = ItemName.getText();
   %ItemID=ItemTypeList.getSelectedItem()+1;
   %ArcanaID=ArcanaList.getSelectedItem();
   %StatusID=StatusList.getSelectedItem();
   %ParamID=ParamList.getSelectedItem();
   %RangeID=RangeList.getSelectedItem()+1;
   
   %Variance= Variance.getText();
   %Potency= Potency.getText();
   %Cost= Cost.getText();
   %Description= Description.getText();
   %Image= Image.getText();
   %Animation= Animation.getText();
   %OutPartyUse= OutPartyUse.getText();
   %InPartyUse= InPartyUse.getText();
   %MaxQuantity= MaxQuantity.getText();
      
      // create a new simple table for demonstration purposes
      if($ItemGUI::CreateNew==0){
         %query = "Update Items set Name='"@%pname@"', ItemTypeID='"@%ItemID@"', Variance='"@%Variance@"', Potency='"@%Potency@"', ArcanaID='"@%ArcanaID@"', StatusID='"@%StatusID@"', ParamID='"@%ParamID@"', RangeID='"@%RangeID@"', Cost='"@%Cost@"', Description='"@%Description@"', Image='"@%Image@"', Animation='"@%Animation@"', OutPartyUse='"@%OutPartyUse@"', InPartyUse='"@%InPartyUse@"', MaxQuantity='"@%MaxQuantity@"' where ItemID='"@ $ItemGUI::SAVEID @"';";
      }else{
         %query = "Insert into Items(Name, ItemTypeID, Variance, Potency, ArcanaID, StatusID, ParamID, RangeID, Cost, Description, Image, Animation, OutPartyUse, InPartyUse, MaxQuantity) Values('"@ %pname @"', '"@%ItemID@"', '"@%Variance@"', '"@%Potency@"', '"@%ArcanaID@"', '"@%StatusID@"', '"@%ParamID@"', '"@%RangeID@"', '"@%Cost@"', '"@%Description@"', '"@%Image@"', '"@%Animation@"', '"@%OutPartyUse@"', '"@%InPartyUse@"', '"@%MaxQuantity@"');";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from users table.");
      }else{
         
         $ItemGUI::CreateNew=1;
         ItemName.setText("");
         Variance.setText("");
         Potency.setText("");
         Cost.setText("");
         Description.setText("");
         Image.setText("");
         Animation.setText("");
         OutPartyUse.setText("");
         InPartyUse.setText("");
         MaxQuantity.setText("");
         
         ItemTypeList.clearSelection();
         ArcanaList.clearSelection();
         StatusList.clearSelection();
         ParamList.clearSelection();
         RangeList.clearSelection();
         
         ItemTypeList.setCurSel(0);
         ArcanaList.setCurSel(0);
         StatusList.setCurSel(0);
         ParamList.setCurSel(0);
         RangeList.setCurSel(0);
      }
   sqlite.closeDatabase();
   sqlite.delete();
   ItemGui.LoadItems();
}

function ItemGui::LoadSelectedItem(){

   // attempt to retrieve result data
   $ItemGUI::CreateNew=0;

   %count=ItemList.getSelectedItem();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ItemID, Name, ItemTypeID, Variance, Potency, ArcanaID, StatusID, ParamID, RangeID, Cost, Description, Image, Animation, OutPartyUse, InPartyUse, MaxQuantity from Items;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      // attempt to retrieve result data
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      $ItemGUI::SAVEID = sqlite.getColumn(%result, "ItemID");
      %Name = sqlite.getColumn(%result, "Name");
      %ItemTypeID = sqlite.getColumn(%result, "ItemTypeID");
      %Variance = sqlite.getColumn(%result, "Variance");
      %Potency = sqlite.getColumn(%result, "Potency");
      %ArcanaID = sqlite.getColumn(%result, "ArcanaID");
      %StatusID = sqlite.getColumn(%result, "StatusID");
      %ParamID = sqlite.getColumn(%result, "ParamID");
      %RangeID = sqlite.getColumn(%result, "RangeID");
      %Cost = sqlite.getColumn(%result, "Cost");
      %Description = sqlite.getColumn(%result, "Description");
      %Image = sqlite.getColumn(%result, "Image");
      %Animation = sqlite.getColumn(%result, "Animation");
      %OutPartyUse = sqlite.getColumn(%result, "OutPartyUse");
      %InPartyUse = sqlite.getColumn(%result, "InPartyUse");
      %MaxQuantity = sqlite.getColumn(%result, "MaxQuantity");
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
         ItemName.setText(%Name);
         Variance.setText(%Variance);
         Potency.setText(%Potency);
         Cost.setText(%Cost);
         Description.setText(%Description);
         Image.setText(%Image);
         Animation.setText(%Animation);
         OutPartyUse.setText(%OutPartyUse);
         InPartyUse.setText(%InPartyUse);
         MaxQuantity.setText(%MaxQuantity);
         
         ItemTypeList.clearSelection();
         ArcanaList.clearSelection();
         StatusList.clearSelection();
         ParamList.clearSelection();
         RangeList.clearSelection();
         
         ItemTypeList.setCurSel(%ItemTypeID-1);
         ArcanaList.setCurSel(%ArcanaID);
         StatusList.setCurSel(%StatusID);
         ParamList.setCurSel(%ParamID);
         RangeList.setCurSel(%RangeID-1);
}
   
function ItemGui::New()
{
         $ItemGUI::CreateNew=1;
         ItemName.setText("");
         Variance.setText("");
         Potency.setText("");
         Cost.setText("");
         Description.setText("");
         Image.setText("");
         Animation.setText("");
         OutPartyUse.setText("");
         InPartyUse.setText("");
         MaxQuantity.setText("");
         
         ItemTypeList.clearSelection();
         ArcanaList.clearSelection();
         StatusList.clearSelection();
         ParamList.clearSelection();
         RangeList.clearSelection();
         
         ItemTypeList.setCurSel(0);
         ArcanaList.setCurSel(0);
         StatusList.setCurSel(0);
         ParamList.setCurSel(0);
         RangeList.setCurSel(0);
}

function ItemGui::Delete()
{
   // attempt to retrieve result data
   $ItemGUI::CreateNew=1;
   %count=ItemList.getSelectedItem();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ItemID from Items;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      // attempt to retrieve result data
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         $ItemGUI::SAVEID = sqlite.getColumn(%result, "ItemID");
         %query = "Delete from Items where ItemID="@$ItemGUI::SAVEID@";";
         %result = sqlite.query(%query, 0);
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   ItemGui.LoadItems();
         $ItemGUI::CreateNew=1;
         ItemName.setText("");
         Variance.setText("");
         Potency.setText("");
         Cost.setText("");
         Description.setText("");
         Image.setText("");
         Animation.setText("");
         OutPartyUse.setText("");
         InPartyUse.setText("");
         MaxQuantity.setText("");
         
         ItemTypeList.clearSelection();
         ArcanaList.clearSelection();
         StatusList.clearSelection();
         ParamList.clearSelection();
         RangeList.clearSelection();
         
         ItemTypeList.setCurSel(0);
         ArcanaList.setCurSel(0);
         StatusList.setCurSel(0);
         ParamList.setCurSel(0);
         RangeList.setCurSel(0);
}
