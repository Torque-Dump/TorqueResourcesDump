//------------------------------------------------------------------------------
// Torque        Engine
// Copyright (C) GarageGames.com, Inc.
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// OnclassLoad methods
//------------------------------------------------------------------------------

$ArmorGUI::SAVEID="";
$ArmorGUI::CreateNew=1;

function ArmorGui::LoadArmors()
{
   ArmorList2.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Armors;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ArmorList2.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}

function ArmorGui::LoadClasses()
{
   ClassList3.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Classes;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ClassList3.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   ClassList3.clearSelection();
   ClassList3.setCurSel(0);
}


function ArmorGui::LoadArmorTypes()
{
   ArmorTypeList.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from ArmorTypes;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ArmorTypeList.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   ArmorTypeList.clearSelection();
   ArmorTypeList.setCurSel(0);
}


function ArmorGui::onWake(%this)
{
   ArmorGui.LoadArmors();
   ArmorGui.LoadClasses();
   ArmorGui.LoadArmorTypes();
   ArmorName.setText("");
   Level2.setText("");
   Cost2.setText("");
   MaxQuantity2.setText("");
   Image2.setText("");
   Skin2.setText("");
   Description2.setText("");
   Attack2.setText("");
   Defense2.setText("");
   MagicAttack2.setText("");
   MagicDefense2.setText("");
   Vitality2.setText("");
   Magic2.setText("");
   Evasion2.setText("");
   Accuracy2.setText("");
   Fire2.setText("");
   Water2.setText("");
   Thunder2.setText("");
   Earth2.setText("");
   Wind2.setText("");
   Ice2.setText("");
   Light2.setText("");
   Dark2.setText("");
}
//------------------------------------------------------------------------------
// global methods
//------------------------------------------------------------------------------

/// Callback from the shell button for triggering single Armor.
function ArmorGui::LoadMain()
{
   Canvas.setContent(DBMODGui);
}

function ArmorGui::SaveArmor()
{
      %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   %ClassCount = ClassList3.getSelCount();
   %ClassIDs = ClassList3.getSelectedItems();
   
   
   %ArmorTypeID = ArmorTypeList.getSelectedItem()+1;
   %pname = ArmorName.getText();
   %Level2 = Level2.getText();
   %Cost2 = Cost2.getText();
   %MaxQuantity2 = MaxQuantity2.getText();
   %Image2 = Image2.getText();
   %Skin2 = Skin2.getText();
   %Description2 = Description2.getText();
   %Attack2 = Attack2.getText();
   %Defense2 = Defense2.getText();
   %MagicAttack2 = MagicAttack2.getText();
   %MagicDefense2 = MagicDefense2.getText();
   %Vitality2 = Vitality2.getText();
   %Magic2 = Magic2.getText();
   %Evasion2 = Evasion2.getText();
   %Accuracy2 = Accuracy2.getText();
   %Fire2 = Fire2.getText();
   %Water2 = Water2.getText();
   %Thunder2 = Thunder2.getText();
   %Earth2 = Earth2.getText();
   %Wind2 = Wind2.getText();
   %Ice2 = Ice2.getText();
   %Light2 = Light2.getText();
   %Dark2 = Dark2.getText();
      
   // create a new simple table for demonstration purposes
      if($ArmorGUI::CreateNew==0){
         %query = "Update Armors set ArmorTypeID='"@%ArmorTypeID@"', Name='"@%pname@"', Level='"@%Level2@"', Cost='"@%Cost2@"', Description='"@%Description2@"', Image='"@%Image2@"', Skin='"@%Skin2@"', MaxQuantities='"@%MaxQuantity2@"' where ArmorID='"@$ArmorGUI::SAVEID@"';";
      }else{
         %query = "Insert into Armors(ArmorTypeID, Name, Level, Cost, Description, Image, Skin, MaxQuantities) Values('"@%ArmorTypeID@"', '"@%pname@"', '"@%Level2@"', '"@%Cost2@"', '"@%Description2@"', '"@%Image2@"', '"@%Skin2@"', '"@%MaxQuantity2@"');";
      }
      echo(%query);
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from users table.");
      }else{
            // create a new simple table for demonstration purposes
            %query = "Select ArmorID from Armors where ArmorTypeID='"@%ArmorTypeID@"' AND Name='"@%pname@"' AND Level='"@%Level2@"' AND Cost='"@%Cost2@"' AND Description='"@%Description2@"' AND Image='"@%Image2@"' AND Skin='"@%Skin2@"' AND MaxQuantities='"@%MaxQuantity2@"';";
            echo(%query);            
            %result = sqlite.query(%query, 0);   
            $ArmorGUI::SAVEID = sqlite.getColumn(%result, "ArmorID");
            
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%Attack2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=1, ArcanaID=0;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 1, 0, '"@%Attack2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);
         
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%Defense2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=2, ArcanaID=0;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 2, 0, '"@%Defense2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);
         
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%MagicAttack2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=3, ArcanaID=0;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 3, 0, '"@%MagicAttack2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);
         
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%MagicDefense2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=4, ArcanaID=0;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 4, 0, '"@%MagicDefense2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);
         
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%Vitality2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=5, ArcanaID=0;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 5, 0, '"@%Vitality2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);
         
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%Magic2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=6, ArcanaID=0;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 6, 0, '"@%Magic2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);
         
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%Evasion2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=7, ArcanaID=0;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 7, 0, '"@%Evasion2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);
         
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%Accuracy2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=8, ArcanaID=0;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 8, 0, '"@%Accuracy2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);
         
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%Fire2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=0, ArcanaID=1;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 0, 1, '"@%Fire2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);
         
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%Water2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=0, ArcanaID=2;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 0, 2, '"@%Water2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);
         
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%Thunder2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=0, ArcanaID=3;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 0, 3, '"@%Thunder2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);
         
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%Earth2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=0, ArcanaID=4;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 0, 4, '"@%Earth2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);
         
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%Wind2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=0, ArcanaID=5;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 0, 5, '"@%Wind2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);
         
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%Ice2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=0, ArcanaID=6;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 0, 6, '"@%Ice2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);
         
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%Light2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=0, ArcanaID=7;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 0, 7, '"@%Light2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);
         
            if($ArmorGUI::CreateNew==0){
               %query = "Update ArmorParams set Value='"@%Dark2@"' where ArmorID='"@$ArmorGUI::SAVEID@"', ParamID=0, ArcanaID=8;";
            }else{
               %query = "Insert into ArmorParams(ArmorID, ParamID, ArcanaID, Value) Values('"@$ArmorGUI::SAVEID@"', 0, 8, '"@%Dark2@"');";
            }
            echo(%query);            
            %result = sqlite.query(%query, 0);


            %query = "Delete from ArmorClass where ArmorID='"@$ArmorGUI::SAVEID@"';";
            echo(%query);            
            %result = sqlite.query(%query, 0);   
            
            
            for(%i =0;%i < %ClassCount ; %i++){
               %query = "select ClassID from Classes;";
               echo(%query);            
               %result = sqlite.query(%query, 0);   
               if (%result == 0)
               {
                  echo("ERROR: Failed to SELECT from Classes table.");
               }else{
                  // attempt to retrieve result data
                  %asd=getWord(%ClassIDs, %i);
                  for(%c = 0 ;%c< getWord(%ClassIDs, %i);%c++)
                  {
                     sqlite.nextRow(%result);
                  }
               }
               
               %REALCLASSID = sqlite.getColumn(%result, "ClassID");
               %query = "Insert into ArmorClass(ArmorID, ClassID) Values('"@$ArmorGUI::SAVEID@"', '"@%REALCLASSID@"');";
               echo(%query);            
               %result = sqlite.query(%query, 0);
            }
         $ArmorGUI::CreateNew=1;
         ArmorName.setText("");
         Level2.setText("");
         Cost2.setText("");
         MaxQuantity2.setText("");
         Image2.setText("");
         Skin2.setText("");
         Description2.setText("");
         Attack2.setText("");
         Defense2.setText("");
         MagicAttack2.setText("");
         MagicDefense2.setText("");
         Vitality2.setText("");
         Magic2.setText("");
         Evasion2.setText("");
         Accuracy2.setText("");
         Fire2.setText("");
         Water2.setText("");
         Thunder2.setText("");
         Earth2.setText("");
         Wind2.setText("");
         Ice2.setText("");
         Light2.setText("");
         Dark2.setText("");
         ClassList3.clearSelection();
         ClassList3.setCurSel(0);
         ArmorTypeList.clearSelection();
         ArmorTypeList.setCurSel(0);
      }
   sqlite.closeDatabase();
   sqlite.delete();
   ArmorGui.LoadArmors();
}

function ArmorGui::LoadSelectedArmor(){

   // attempt to retrieve result data
   $ArmorGUI::CreateNew=0;

   %count=ArmorList2.getSelectedItem();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ArmorID, ArmorTypeID, Name, Level, Cost, Description, Image, Skin, MaxQuantities from Armors;";
   echo(%query);            
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      // attempt to retrieve result data
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      $ArmorGUI::SAVEID = sqlite.getColumn(%result, "ArmorID");
      %ArmorTypeID = sqlite.getColumn(%result, "ArmorTypeID");
      %Name = sqlite.getColumn(%result, "Name");
      %Level = sqlite.getColumn(%result, "Level");
      %Cost = sqlite.getColumn(%result, "Cost");
      %Description = sqlite.getColumn(%result, "Description");
      %Image = sqlite.getColumn(%result, "Image");
      %Skin = sqlite.getColumn(%result, "Skin");
      %MaxQuantities = sqlite.getColumn(%result, "MaxQuantities");
      
      
            %query = "select Value from ArmorParams where ArmorID='"@$ArmorGUI::SAVEID@"';";
            echo(%query);            
            %result = sqlite.query(%query, 0);   
            if (%result == 0)
            {
               echo("ERROR: Failed to SELECT from Classes table.");
            }else{
               
               %ATK = sqlite.getColumn(%result, "Value");
                     sqlite.nextRow(%result);
               %DEF = sqlite.getColumn(%result, "Value");
                     sqlite.nextRow(%result);
               %MATK = sqlite.getColumn(%result, "Value");
                     sqlite.nextRow(%result);
               %MDEF = sqlite.getColumn(%result, "Value");
                     sqlite.nextRow(%result);
               %VIT = sqlite.getColumn(%result, "Value");
                     sqlite.nextRow(%result);
               %MAG = sqlite.getColumn(%result, "Value");
                     sqlite.nextRow(%result);
               %EVA = sqlite.getColumn(%result, "Value");
                     sqlite.nextRow(%result);
               %ACC = sqlite.getColumn(%result, "Value");
                     sqlite.nextRow(%result);
               %Fire = sqlite.getColumn(%result, "Value");
                     sqlite.nextRow(%result);
               %Water = sqlite.getColumn(%result, "Value");
                     sqlite.nextRow(%result);
               %Thunder = sqlite.getColumn(%result, "Value");
                     sqlite.nextRow(%result);
               %Earth = sqlite.getColumn(%result, "Value");
                     sqlite.nextRow(%result);
               %Wind = sqlite.getColumn(%result, "Value");
                     sqlite.nextRow(%result);
               %Ice = sqlite.getColumn(%result, "Value");
                     sqlite.nextRow(%result);
               %Light = sqlite.getColumn(%result, "Value");
                     sqlite.nextRow(%result);
               %Dark = sqlite.getColumn(%result, "Value");
               
      
                     %query = "select ClassID from ArmorClass where ArmorID='"@$ArmorGUI::SAVEID@"';";
                     echo(%query);            
                     %result = sqlite.query(%query, 0);   
                     if (%result == 0)
                     {
                        echo("ERROR: Failed to SELECT from Classes table.");
                     }else{
                        
                           %a=0;
                           while (!sqlite.endOfResult(%result))
                           {
                              %ClassIDs[%a] = sqlite.getColumn(%result, "ClassID");
                              sqlite.nextRow(%result);
                              %a++;
                           }
                        
                     }               
               
               
               
            }
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
         $ArmorGUI::CreateNew=0;
         ArmorName.setText(%Name);
         Level2.setText(%Level);
         Cost2.setText(%Cost);
         MaxQuantity2.setText(%MaxQuantities);
         Image2.setText(%Image);
         Skin2.setText(%Skin);
         Description2.setText(%Description);
         Attack2.setText(%ATK);
         Defense2.setText(%DEF);
         MagicAttack2.setText(%MATK);
         MagicDefense2.setText(%MDEF);
         Vitality2.setText(%VIT);
         Magic2.setText(%MAG);
         Evasion2.setText(%EVA);
         Accuracy2.setText(%ACC);
         Fire2.setText(%Fire);
         Water2.setText(%Water);
         Thunder2.setText(%Thunder);
         Earth2.setText(%Earth);
         Wind2.setText(%Wind);
         Ice2.setText(%Ice);
         Light2.setText(%Light);
         Dark2.setText(%Dark);
         
         ClassList3.clearSelection();
         for(%f =0 ; %f< %a ; %f++){
            ClassList3.setCurSel(%ClassIDs[%f]-1);
         }
         ArmorTypeList.clearSelection();
         ArmorTypeList.setCurSel(%ArmorTypeID-1);
}
   
function ArmorGui::New()
{
         $ArmorGUI::CreateNew=1;
         ArmorName.setText("");
         Level2.setText("");
         Cost2.setText("");
         MaxQuantity2.setText("");
         Image2.setText("");
         Skin2.setText("");
         Description2.setText("");
         Attack2.setText("");
         Defense2.setText("");
         MagicAttack2.setText("");
         MagicDefense2.setText("");
         Vitality2.setText("");
         Magic2.setText("");
         Evasion2.setText("");
         Accuracy2.setText("");
         Fire2.setText("");
         Water2.setText("");
         Thunder2.setText("");
         Earth2.setText("");
         Wind2.setText("");
         Ice2.setText("");
         Light2.setText("");
         Dark2.setText("");
         ClassList3.clearSelection();
         ClassList3.setCurSel(0);
         ArmorTypeList.clearSelection();
         ArmorTypeList.setCurSel(0);
}

function ArmorGui::Delete()
{
   // attempt to retrieve result data
   $ArmorGUI::CreateNew=1;
   %count=ArmorList2.getSelectedArmor();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ArmorID from Armors;";
   echo(%query);            
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      // attempt to retrieve result data
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         $ArmorGUI::SAVEID = sqlite.getColumn(%result, "ArmorID");
         
         %query = "Delete from Armors where ArmorID='"@$ArmorGUI::SAVEID@"';";
         echo(%query);            
         %result = sqlite.query(%query, 0);
         %query = "Delete from ArmorParams where ArmorID='"@$ArmorGUI::SAVEID@"';";
         echo(%query);            
         %result = sqlite.query(%query, 0);
         %query = "Delete from ArmorClass where ArmorID='"@$ArmorGUI::SAVEID@"';";
         echo(%query);            
         %result = sqlite.query(%query, 0);
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   ArmorGui.LoadArmors();
         $ArmorGUI::CreateNew=1;
         ArmorName.setText("");
         Level2.setText("");
         Cost2.setText("");
         MaxQuantity2.setText("");
         Image2.setText("");
         Skin2.setText("");
         Description2.setText("");
         Attack2.setText("");
         Defense2.setText("");
         MagicAttack2.setText("");
         MagicDefense2.setText("");
         Vitality2.setText("");
         Magic2.setText("");
         Evasion2.setText("");
         Accuracy2.setText("");
         Fire2.setText("");
         Water2.setText("");
         Thunder2.setText("");
         Earth2.setText("");
         Wind2.setText("");
         Ice2.setText("");
         Light2.setText("");
         Dark2.setText("");
         ClassList3.clearSelection();
         ClassList3.setCurSel(0);
         ArmorTypeList.clearSelection();
         ArmorTypeList.setCurSel(0);
}
