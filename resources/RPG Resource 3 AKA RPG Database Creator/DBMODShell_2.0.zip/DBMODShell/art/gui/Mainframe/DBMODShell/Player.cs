//------------------------------------------------------------------------------
// Torque        Engine
// Copyright (C) GarageGames.com, Inc.
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// OnclassLoad methods
//------------------------------------------------------------------------------

$PLAYERGUI::SAVEID="";
$PLAYERGUI::CreateNew=1;

function PlayerGui::LoadPlayers()
{
   PlayerList.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select PlayerID, Name, ClassID, RaceID from PlayersInit;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         PlayerList.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}


function PlayerGui::LoadRaces()
{
   RaceList.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Races;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         RaceList.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   RaceList.clearSelection();
   RaceList.setCurSel(0);
}



function PlayerGui::LoadClasses()
{
   ClassList2.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Classes;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ClassList2.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   ClassList2.clearSelection();
   ClassList2.setCurSel(0);
}

function PlayerGui::onWake(%this)
{
   PlayerGui.LoadPlayers();
   PlayerGui.LoadRaces();
   PlayerGui.LoadClasses();
         playerName.setText("");
         Level.setText("");
         DataBlockPL.setText("");
         Attack.setText("");
         Defense.setText("");
         magickAttack.setText("");
         magicDefense.setText("");
         Vitality.setText("");
         Magic.setText("");
         Evasion.setText("");
         Accuracy.setText("");
         Bio.setText("");
}

//------------------------------------------------------------------------------
// global methods
//------------------------------------------------------------------------------

/// Callback from the shell button for triggering single player.
function PlayerGui::LoadMain()
{
   Canvas.setContent(DBMODGui);
}

function PlayerGui::SavePlayer()
{
      %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
      %pname = playerName.getText();
      
      %RACEID= RaceList.getSelectedItem()+1;
      %CLASSID= ClassList2.getSelectedItem()+1;
      
      %LVL= Level.getText();
      %ATK= Attack.getText();
      %DEF= Defense.getText();
      %MATK= magickAttack.getText();
      %MDEF= magicDefense.getText();
      %VIT= Vitality.getText();
      %MAG= Magic.getText();
      %EVA= Evasion.getText();
      %ACC= Accuracy.getText();
      %BIO= Bio.getText();
      %DB=  DataBlockPL.getText();
      
      // create a new simple table for demonstration purposes
      if($PLAYERGUI::CreateNew==0){
         %query = "Update PlayersInit set Name='"@ %pname @"', ClassID="@ %CLASSID @", RaceID="@ %RACEID @", Biography='"@ %BIO @"', Level="@%LVL@" , DataBlock='"@%DB@"' where PlayerID="@ $PLAYERGUI::SAVEID @";";
      }else{
         %query = "Insert into PlayersInit(Name, RaceID, ClassID, Biography, Level, DataBlock) Values('"@ %pname @"', "@ %RACEID @", "@ %CLASSID @", '"@ %BIO @"', "@%LVL@", '"@%DB@"');";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from users table.");
      }else{
         
         %query = "Select PlayerID from PlayersInit where Name='"@ %pname @"' and RaceID="@ %RACEID @" and ClassID="@ %CLASSID @";";
         %result = sqlite.query(%query, 0);  
         %PlayerID = sqlite.getColumn(%result, "PlayerID");
         if($PLAYERGUI::CreateNew==0){
            %query = "Update PlayerParams set Value='"@ %ATK @"' where PlayerID="@ %PlayerID @" and ParamID=1;";
         }else{
            %query = "Insert into PlayerParams(PlayerID, ParamID, Value) Values('"@ %PlayerID @"', 1, "@ %ATK @");";
         }
      %result = sqlite.query(%query, 0);  
         if($PLAYERGUI::CreateNew==0){
            %query = "Update PlayerParams set Value='"@ %DEF @"' where PlayerID="@ %PlayerID @" and ParamID=2;";
         }else{
            %query = "Insert into PlayerParams(PlayerID, ParamID, Value) Values('"@ %PlayerID @"', 2, "@ %DEF @");";
         }
      %result = sqlite.query(%query, 0);  
         if($PLAYERGUI::CreateNew==0){
            %query = "Update PlayerParams set Value='"@ %MATK @"' where PlayerID="@ %PlayerID @" and ParamID=3;";
         }else{
            %query = "Insert into PlayerParams(PlayerID, ParamID, Value) Values('"@ %PlayerID @"', 3, "@ %MATK @");";
         }
      %result = sqlite.query(%query, 0);  
         if($PLAYERGUI::CreateNew==0){
            %query = "Update PlayerParams set Value='"@ %MDEF @"' where PlayerID="@ %PlayerID @" and ParamID=4;";
         }else{
            %query = "Insert into PlayerParams(PlayerID, ParamID, Value) Values('"@ %PlayerID @"', 4, "@ %MDEF @");";
         }
      %result = sqlite.query(%query, 0);  
         if($PLAYERGUI::CreateNew==0){
            %query = "Update PlayerParams set Value='"@ %VIT @"' where PlayerID="@ %PlayerID @" and ParamID=5;";
         }else{
            %query = "Insert into PlayerParams(PlayerID, ParamID, Value) Values('"@ %PlayerID @"', 5, "@ %VIT @");";
         }
      %result = sqlite.query(%query, 0);  
         if($PLAYERGUI::CreateNew==0){
            %query = "Update PlayerParams set Value='"@ %MAG @"' where PlayerID="@ %PlayerID @" and ParamID=6;";
         }else{
            %query = "Insert into PlayerParams(PlayerID, ParamID, Value) Values('"@ %PlayerID @"', 6, "@ %MAG @");";
         }
      %result = sqlite.query(%query, 0);  
         if($PLAYERGUI::CreateNew==0){
            %query = "Update PlayerParams set Value='"@ %EVA @"' where PlayerID="@ %PlayerID @" and ParamID=7;";
         }else{
            %query = "Insert into PlayerParams(PlayerID, ParamID, Value) Values('"@ %PlayerID @"', 7, "@ %EVA @");";
         }
      %result = sqlite.query(%query, 0);  
         if($PLAYERGUI::CreateNew==0){
            %query = "Update PlayerParams set Value='"@ %ACC @"' where PlayerID="@ %PlayerID @" and ParamID=8;";
         }else{
            %query = "Insert into PlayerParams(PlayerID, ParamID, Value) Values('"@ %PlayerID @"', 8, "@ %ACC @");";
         }
      %result = sqlite.query(%query, 0);  
         $PLAYERGUI::CreateNew=1;
         playerName.setText("");
         Level.setText("");
         Attack.setText("");
         Defense.setText("");
         magickAttack.setText("");
         magicDefense.setText("");
         Vitality.setText("");
         Magic.setText("");
         Evasion.setText("");
         Accuracy.setText("");
         Bio.setText("");
         RaceList.clearSelection();
         ClassList2.clearSelection();
         RaceList.setCurSel(0);
         ClassList2.setCurSel(0);
      }
   sqlite.closeDatabase();
   sqlite.delete();
   PlayerGui.LoadPlayers();
}

function PlayerGui::LoadSelectedPlayer(){

   // attempt to retrieve result data
   $PLAYERGUI::CreateNew=0;

   %count=PlayerList.getSelectedItem();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select PlayerID, Name, RaceID, ClassID, Biography, Level, DataBlock from PlayersInit;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      // attempt to retrieve result data
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      $PLAYERGUI::SAVEID = sqlite.getColumn(%result, "PlayerID");
      %Name = sqlite.getColumn(%result, "Name");
      %RaceID = sqlite.getColumn(%result, "RaceID");
      %ClassID = sqlite.getColumn(%result, "ClassID");
      %Bio = sqlite.getColumn(%result, "Biography");
      %LVL = sqlite.getColumn(%result, "Level");
      %DB = sqlite.getColumn(%result, "DataBlock");
      
         // create a new simple table for demonstration purposes
         %query = "select Value from PlayerParams where PlayerID="@$PLAYERGUI::SAVEID@";";
         %result = sqlite.query(%query, 0);   
         if (%result == 0)
         {
            echo("ERROR: Failed to SELECT from PlayerParams table.");
         }else{
            // attempt to retrieve result data
            %ATK = sqlite.getColumn(%result, "Value");
            sqlite.nextRow(%result);
            %DEF = sqlite.getColumn(%result, "Value");
            sqlite.nextRow(%result);
            %MATK = sqlite.getColumn(%result, "Value");
            sqlite.nextRow(%result);
            %MDEF = sqlite.getColumn(%result, "Value");
            sqlite.nextRow(%result);
            %VIT = sqlite.getColumn(%result, "Value");
            sqlite.nextRow(%result);
            %MAG = sqlite.getColumn(%result, "Value");
            sqlite.nextRow(%result);
            %EVA = sqlite.getColumn(%result, "Value");
            sqlite.nextRow(%result);
            %ACC = sqlite.getColumn(%result, "Value");
         }
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
   playerName.setText(%Name);
   Level.setText(%LVL);
   Attack.setText(%ATK);
   Defense.setText(%DEF);
   magickAttack.setText(%MATK);
   magicDefense.setText(%MDEF);
   Vitality.setText(%VIT);
   Magic.setText(%MAG);
   Evasion.setText(%EVA);
   Accuracy.setText(%ACC);
   DataBlockPL.setText(%DB);
   Bio.setText(%BIO);
   RaceList.clearSelection();
   ClassList2.clearSelection();
   RaceList.setCurSel(%RaceID-1);
   ClassList2.setCurSel(%ClassID-1);
}
   
function PlayerGui::New()
{
    $PLAYERGUI::CreateNew=1;
    playerName.setText("");
    Level.setText("");
    Attack.setText("");
    Defense.setText("");
    magickAttack.setText("");
    magicDefense.setText("");
    Vitality.setText("");
    Magic.setText("");
    Evasion.setText("");
    Accuracy.setText("");
    DataBlockPL.setText("");
    Bio.setText("");
    PlayerList.clearSelection();
    RaceList.clearSelection();
    ClassList2.clearSelection();
    RaceList.setCurSel(0);
    ClassList2.setCurSel(0);
}

function PlayerGui::Delete()
{

   // attempt to retrieve result data
   $PLAYERGUI::CreateNew=0;
   %count=PlayerList.getSelectedItem();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select PlayerID from PlayersInit;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      // attempt to retrieve result data
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         $PLAYERGUI::SAVEID = sqlite.getColumn(%result, "PlayerID");
         %query = "Delete from PlayersInit where PlayerID="@$PLAYERGUI::SAVEID@";";
         %result = sqlite.query(%query, 0);   
         %query = "Delete from PlayerParams where PlayerID="@$PLAYERGUI::SAVEID@";";
         %result = sqlite.query(%query, 0);   
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   PlayerGui.LoadPlayers();
   $PLAYERGUI::CreateNew=1;
   playerName.setText("");
   Level.setText("");
   Attack.setText("");
   Defense.setText("");
   magickAttack.setText("");
   magicDefense.setText("");
   Vitality.setText("");
   Magic.setText("");
   Evasion.setText("");
   Accuracy.setText("");
   DataBlockPL.setText("");
   Bio.setText("");
   RaceList.clearSelection();
   ClassList2.clearSelection();
   RaceList.setCurSel(0);
   ClassList2.setCurSel(0);
}
