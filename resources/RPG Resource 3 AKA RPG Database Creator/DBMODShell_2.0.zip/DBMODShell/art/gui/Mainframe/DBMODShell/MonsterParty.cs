//------------------------------------------------------------------------------
// Torque        Engine
// Copyright (C) GarageGames.com, Inc.
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// OnclassLoad methods
//------------------------------------------------------------------------------

$MonsterPartyGUI::SAVEID="";
$MonsterPartyGUI::IDs="";
$MonsterPartyGUI::CreateNew=1;

function MonsterPartyGui::LoadMonsterParty()
{
   MonsterPartyList.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from MonsterParty;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      %i=1;
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         MonsterPartyList.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}


function MonsterPartyGui::LoadMonsters()
{
   Monster1.clearItems();
   Monster2.clearItems();
   Monster3.clearItems();
   Monster4.clearItems();
   Monster5.clearItems();
   Monster6.clearItems();
   Monster7.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select MonsterID, Name, Level from Monsters;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
         Monster1.addItem("None");
         Monster2.addItem("None");
         Monster3.addItem("None");
         Monster4.addItem("None");
         Monster5.addItem("None");
         Monster6.addItem("None");
         Monster7.addItem("None");
         %i=0;
         $MonsterPartyGUI::IDs[%i]=0;
         %i++;
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         %classnameLVL = sqlite.getColumn(%result, "Level");
         $MonsterPartyGUI::IDs[%i] = sqlite.getColumn(%result, "MonsterID");
         Monster1.addItem("LVL~"@%classnameLVL@": "@%classname);
         Monster2.addItem("LVL~"@%classnameLVL@": "@%classname);
         Monster3.addItem("LVL~"@%classnameLVL@": "@%classname);
         Monster4.addItem("LVL~"@%classnameLVL@": "@%classname);
         Monster5.addItem("LVL~"@%classnameLVL@": "@%classname);
         Monster6.addItem("LVL~"@%classnameLVL@": "@%classname);
         Monster7.addItem("LVL~"@%classnameLVL@": "@%classname);
         sqlite.nextRow(%result);
         %i++;
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   Monster1.clearSelection();
   Monster2.clearSelection();
   Monster3.clearSelection();
   Monster4.clearSelection();
   Monster5.clearSelection();
   Monster6.clearSelection();
   Monster7.clearSelection();
   Monster1.setCurSel(0);
   Monster2.setCurSel(0);
   Monster3.setCurSel(0);
   Monster4.setCurSel(0);
   Monster5.setCurSel(0);
   Monster6.setCurSel(0);
   Monster7.setCurSel(0);
}



function MonsterPartyGui::onWake(%this)
{
   MonsterPartyGui.LoadMonsterParty();
   MonsterPartyGui.LoadMonsters();
   MonsterPartyName.setText("");
   EncounterRate10.setText("");
   MapID10.setText("");
}

//------------------------------------------------------------------------------
// global methods
//------------------------------------------------------------------------------

/// Callback from the shell button for triggering single MonsterParty.
function MonsterPartyGui::LoadMain()
{
   Canvas.setContent(DBMODGui);
}

function MonsterPartyGui::SaveMonsterParty()
{
      %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
      %MonsterName = MonsterPartyName.getText();
      %EncounterRate = EncounterRate10.getText();
      %MapID= MapID10.getText();
      
      %Monster1= $MonsterPartyGUI::IDs[Monster1.getSelectedItem()];
      %Monster2= $MonsterPartyGUI::IDs[Monster2.getSelectedItem()];
      %Monster3= $MonsterPartyGUI::IDs[Monster3.getSelectedItem()];
      %Monster4= $MonsterPartyGUI::IDs[Monster4.getSelectedItem()];
      %Monster5= $MonsterPartyGUI::IDs[Monster5.getSelectedItem()];
      %Monster6= $MonsterPartyGUI::IDs[Monster6.getSelectedItem()];
      %Monster7= $MonsterPartyGUI::IDs[Monster7.getSelectedItem()];
      
      // create a new simple table for demonstration purposes
      if($MonsterPartyGUI::CreateNew==0){
         %query = "Update MonsterParty set Monster1ID='"@ %Monster1 @"', Monster2ID='"@ %Monster2 @"', Monster3ID='"@ %Monster3 @"', Monster4ID='"@ %Monster4 @"', Monster5ID='"@%Monster5@"', Monster6ID='"@%Monster6@"', Monster7ID='"@%Monster7@"', Name='"@%MonsterName@"', EncounterRate='"@%EncounterRate@"', MapID='"@%MapID@"' where MonsterPartyID="@ $MonsterPartyGUI::SAVEID @";";
      }else{
         %query = "Insert into MonsterParty(Monster1ID, Monster2ID, Monster3ID, Monster4ID, Monster5ID, Monster6ID, Monster7ID, Name, EncounterRate, MapID) Values('"@ %Monster1 @"', '"@ %Monster2 @"', '"@ %Monster3 @"', '"@ %Monster4 @"', '"@%Monster5@"', '"@%Monster6@"', '"@%Monster7@"', '"@%MonsterName@"', '"@%EncounterRate@"', '"@%MapID@"');";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from users table.");
      }else{
         $MonsterPartyGUI::CreateNew=1;
   MonsterPartyName.setText("");
   EncounterRate10.setText("");
   MapID10.setText("");
   Monster1.clearSelection();
   Monster2.clearSelection();
   Monster3.clearSelection();
   Monster4.clearSelection();
   Monster5.clearSelection();
   Monster6.clearSelection();
   Monster7.clearSelection();
   Monster1.setCurSel(0);
   Monster2.setCurSel(0);
   Monster3.setCurSel(0);
   Monster4.setCurSel(0);
   Monster5.setCurSel(0);
   Monster6.setCurSel(0);
   Monster7.setCurSel(0);
      }
   sqlite.closeDatabase();
   sqlite.delete();
   MonsterPartyGui.LoadMonsterParty();
}

function MonsterPartyGui::LoadSelectedMonsterParty(){

   // attempt to retrieve result data
   $MonsterPartyGUI::CreateNew=0;

   %count=MonsterPartyList.getSelectedItem();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select MonsterPartyID, Name, EncounterRate, MapID, Monster1ID, Monster2ID, Monster3ID, Monster4ID, Monster5ID, Monster6ID, Monster7ID from MonsterParty;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      // attempt to retrieve result data
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      $MonsterPartyGUI::SAVEID = sqlite.getColumn(%result, "MonsterPartyID");
      %Name = sqlite.getColumn(%result, "Name");
      %EncounterRate = sqlite.getColumn(%result, "EncounterRate");
      %MapID = sqlite.getColumn(%result, "MapID");
      %Monster1ID = sqlite.getColumn(%result, "Monster1ID");
      %Monster2ID = sqlite.getColumn(%result, "Monster2ID");
      %Monster3ID = sqlite.getColumn(%result, "Monster3ID");
      %Monster4ID = sqlite.getColumn(%result, "Monster4ID");
      %Monster5ID = sqlite.getColumn(%result, "Monster5ID");
      %Monster6ID = sqlite.getColumn(%result, "Monster6ID");
      %Monster7ID = sqlite.getColumn(%result, "Monster7ID");
      
         // create a new simple table for demonstration purposes
         %query = "select MonsterID from Monsters;";
         %result = sqlite.query(%query, 0);   
         if (%result == 0)
         {
            echo("ERROR: Failed to SELECT from MonsterPartyParams table.");
         }else{
            // attempt to retrieve result data
            Monster1.clearSelection();
            Monster2.clearSelection();
            Monster3.clearSelection();
            Monster4.clearSelection();
            Monster5.clearSelection();
            Monster6.clearSelection();
            Monster7.clearSelection();
            Monster1.setCurSel(0);
            Monster2.setCurSel(0);
            Monster3.setCurSel(0);
            Monster4.setCurSel(0);
            Monster5.setCurSel(0);
            Monster6.setCurSel(0);
            Monster7.setCurSel(0);
            
            %i=1;
            while (!sqlite.endOfResult(%result))
            {
               %username = sqlite.getColumn(%result, "MonsterID");
                  if(%Monster1ID==%username){
                     Monster1.clearSelection();
                     Monster1.setCurSel(%i);
                  }
                  if(%Monster2ID==%username){
                     Monster2.clearSelection();
                     Monster2.setCurSel(%i);
                  }
                  if(%Monster3ID==%username){
                     Monster3.clearSelection();
                     Monster3.setCurSel(%i);
                  }
                  if(%Monster4ID==%username){
                     Monster4.clearSelection();
                     Monster4.setCurSel(%i);
                  }
                  if(%Monster5ID==%username){
                     Monster5.clearSelection();
                     Monster5.setCurSel(%i);
                  }
                  if(%Monster6ID==%username){
                     Monster6.clearSelection();
                     Monster6.setCurSel(%i);
                  }
                  if(%Monster7ID==%username){
                     Monster7.clearSelection();
                     Monster7.setCurSel(%i);
                  }
               %i++;
               sqlite.nextRow(%result);
            }
         }
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
   MonsterPartyName.setText(%Name);
   EncounterRate10.setText(%EncounterRate);
   MapID10.setText(%MapID);
}
   
function MonsterPartyGui::New()
{
         $MonsterPartyGUI::CreateNew=1;
   MonsterPartyName.setText("");
   EncounterRate10.setText("");
   MapID10.setText("");
   Monster1.clearSelection();
   Monster2.clearSelection();
   Monster3.clearSelection();
   Monster4.clearSelection();
   Monster5.clearSelection();
   Monster6.clearSelection();
   Monster7.clearSelection();
   Monster1.setCurSel(0);
   Monster2.setCurSel(0);
   Monster3.setCurSel(0);
   Monster4.setCurSel(0);
   Monster5.setCurSel(0);
   Monster6.setCurSel(0);
   Monster7.setCurSel(0);
}

function MonsterPartyGui::Delete()
{

   // attempt to retrieve result data
   $MonsterPartyGUI::CreateNew=0;
   %count=MonsterPartyList.getSelectedItem();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select MonsterPartyID from MonsterParty;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      // attempt to retrieve result data
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         $MonsterPartyGUI::SAVEID = sqlite.getColumn(%result, "MonsterPartyID");
         %query = "Delete from MonsterParty where MonsterPartyID="@$MonsterPartyGUI::SAVEID@";";
         %result = sqlite.query(%query, 0);   
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   MonsterPartyGui.LoadMonsterParty();
         $MonsterPartyGUI::CreateNew=1;
   MonsterPartyName.setText("");
   EncounterRate10.setText("");
   MapID10.setText("");
   Monster1.clearSelection();
   Monster2.clearSelection();
   Monster3.clearSelection();
   Monster4.clearSelection();
   Monster5.clearSelection();
   Monster6.clearSelection();
   Monster7.clearSelection();
   Monster1.setCurSel(0);
   Monster2.setCurSel(0);
   Monster3.setCurSel(0);
   Monster4.setCurSel(0);
   Monster5.setCurSel(0);
   Monster6.setCurSel(0);
   Monster7.setCurSel(0);
}
