//------------------------------------------------------------------------------
// Torque        Engine
// Copyright (C) GarageGames.com, Inc.
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// OnclassLoad methods
//------------------------------------------------------------------------------

$CLASSGUI::CLASSID="";
$CLASSGUI::SAVEID="";
$CLASSGUI::CreateNew=1;

function ClassGui::LoadClasses()
{
   ClassList.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ClassID, Name from Classes;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      $CLASSGUI::CLASSID=%result;
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ClassList.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}
function ClassGui::onWake(%this)
{
   ClassGui.LoadClasses();
   ClassGui.LoadAttackGrade();
   ClassGui.LoadDefenseGrade();
   ClassGui.LoadMAttackGrade();
   ClassGui.LoadMDefenseGrade();
   ClassGui.LoadVitalityGrade();
   ClassGui.LoadMagicGrade();
   ClassGui.LoadEvasionGrade();
   ClassGui.LoadAccuracyGrade();
}


function ClassGui::LoadAttackGrade()
{
   AttackGrade.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "GradeLetter");
         AttackGrade.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   AttackGrade.clearSelection();
   AttackGrade.setCurSel(0);
}




function ClassGui::LoadDefenseGrade()
{
   DefenseGrade.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "GradeLetter");
         DefenseGrade.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   DefenseGrade.clearSelection();
   DefenseGrade.setCurSel(0);
}




function ClassGui::LoadMAttackGrade()
{
   MAttackGrade.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "GradeLetter");
         MAttackGrade.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   MAttackGrade.clearSelection();
   MAttackGrade.setCurSel(0);
}




function ClassGui::LoadMDefenseGrade()
{
   MDefenseGrade.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "GradeLetter");
         MDefenseGrade.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   MDefenseGrade.clearSelection();
   MDefenseGrade.setCurSel(0);
}




function ClassGui::LoadVitalityGrade()
{
   VitalityGrade.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "GradeLetter");
         VitalityGrade.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   VitalityGrade.clearSelection();
   VitalityGrade.setCurSel(0);
}




function ClassGui::LoadMagicGrade()
{
   MagicGrade.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "GradeLetter");
         MagicGrade.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   MagicGrade.clearSelection();
   MagicGrade.setCurSel(0);
}




function ClassGui::LoadEvasionGrade()
{
   EvasionGrade.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "GradeLetter");
         EvasionGrade.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   EvasionGrade.clearSelection();
   EvasionGrade.setCurSel(0);
}






function ClassGui::LoadAccuracyGrade()
{
   AccuracyGrade.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "GradeLetter");
         AccuracyGrade.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   AccuracyGrade.clearSelection();
   AccuracyGrade.setCurSel(0);
}


//------------------------------------------------------------------------------
// global methods
//------------------------------------------------------------------------------

/// Callback from the shell button for triggering single player.
function ClassGui::LoadMain()
{
   Canvas.setContent(DBMODGui);
}

function ClassGui::SaveClass()
{
      %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
      %CN = className.getText();
      %CRT= critPercent.getText();
      // create a new simple table for demonstration purposes
      if($CLASSGUI::CreateNew==0){
         %query = "Update Classes set Name='"@ %CN @"', CriticalRate="@ %CRT @" where ClassID="@ $CLASSGUI::SAVEID @";";
      }else{
         %query = "Insert into Classes(Name, CriticalRate) Values('"@ %CN @"', "@ %CRT @");";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from users table.");
      }else{
            
            %ATKGRD = AttackGrade.getSelectedItem()+1;   
            %DEFGRD = DefenseGrade.getSelectedItem()+1;   
            %MATKGRD = MAttackGrade.getSelectedItem()+1;   
            %MDEFGRD = MDefenseGrade.getSelectedItem()+1;   
            %VITGRD = VitalityGrade.getSelectedItem()+1;   
            %MAGGRD = MagicGrade.getSelectedItem()+1;   
            %EVAGRD = EvasionGrade.getSelectedItem()+1;   
            %ACCGRD = AccuracyGrade.getSelectedItem()+1;            
            
            %query = "Select ClassID from Classes where Name='"@ %CN @"' and CriticalRate='"@ %CRT @"';";
            %result = sqlite.query(%query, 0);            
            $CLASSGUI::SAVEID  = sqlite.getColumn(%result, "ClassID");
            // create a new simple table for demonstration purposes
            if($CLASSGUI::CreateNew==0){
               %query = "Update ClassGrades set GradeID='"@ %ATKGRD @"' where ClassID='"@ $CLASSGUI::SAVEID @"' and GradeTypeID=1;";
            }else{
               %query = "Insert into ClassGrades(ClassID, GradeTypeID, GradeID) Values('"@ $CLASSGUI::SAVEID @"', 1, '"@ %ATKGRD @"');";
            }
            %result = sqlite.query(%query, 0);
         
            if($CLASSGUI::CreateNew==0){
               %query = "Update ClassGrades set GradeID='"@ %DEFGRD @"' where ClassID='"@ $CLASSGUI::SAVEID @"' and GradeTypeID=2;";
            }else{
               %query = "Insert into ClassGrades(ClassID, GradeTypeID, GradeID) Values('"@ $CLASSGUI::SAVEID @"', 2, '"@ %DEFGRD @"');";
            }
            %result = sqlite.query(%query, 0);
         
            if($CLASSGUI::CreateNew==0){
               %query = "Update ClassGrades set GradeID='"@ %MATKGRD @"' where ClassID='"@ $CLASSGUI::SAVEID @"' and GradeTypeID=3;";
            }else{
               %query = "Insert into ClassGrades(ClassID, GradeTypeID, GradeID) Values('"@ $CLASSGUI::SAVEID @"', 3, '"@ %MATKGRD @"');";
            }
            %result = sqlite.query(%query, 0);
         
            if($CLASSGUI::CreateNew==0){
               %query = "Update ClassGrades set GradeID='"@ %MDEFGRD @"' where ClassID='"@ $CLASSGUI::SAVEID @"' and GradeTypeID=4;";
            }else{
               %query = "Insert into ClassGrades(ClassID, GradeTypeID, GradeID) Values('"@ $CLASSGUI::SAVEID @"', 4, '"@ %MDEFGRD @"');";
            }
            %result = sqlite.query(%query, 0);
         
            if($CLASSGUI::CreateNew==0){
               %query = "Update ClassGrades set GradeID='"@ %VITGRD @"' where ClassID='"@ $CLASSGUI::SAVEID @"' and GradeTypeID=5;";
            }else{
               %query = "Insert into ClassGrades(ClassID, GradeTypeID, GradeID) Values('"@ $CLASSGUI::SAVEID @"', 5, '"@ %VITGRD @"');";
            }
            %result = sqlite.query(%query, 0);
         
            if($CLASSGUI::CreateNew==0){
               %query = "Update ClassGrades set GradeID='"@ %MAGGRD @"' where ClassID='"@ $CLASSGUI::SAVEID @"' and GradeTypeID=6;";
            }else{
               %query = "Insert into ClassGrades(ClassID, GradeTypeID, GradeID) Values('"@ $CLASSGUI::SAVEID @"', 6, '"@ %MAGGRD @"');";
            }
            %result = sqlite.query(%query, 0);
         
            if($CLASSGUI::CreateNew==0){
               %query = "Update ClassGrades set GradeID='"@ %EVAGRD @"' where ClassID='"@ $CLASSGUI::SAVEID @"' and GradeTypeID=7;";
            }else{
               %query = "Insert into ClassGrades(ClassID, GradeTypeID, GradeID) Values('"@ $CLASSGUI::SAVEID @"', 7, '"@ %EVAGRD @"');";
            }
            %result = sqlite.query(%query, 0);
         
            if($CLASSGUI::CreateNew==0){
               %query = "Update ClassGrades set GradeID='"@ %ACCGRD @"' where ClassID='"@ $CLASSGUI::SAVEID @"' and GradeTypeID=8;";
            }else{
               %query = "Insert into ClassGrades(ClassID, GradeTypeID, GradeID) Values('"@ $CLASSGUI::SAVEID @"', 8, '"@ %ACCGRD @"');";
            }
            %result = sqlite.query(%query, 0);
         
         $CLASSGUI::CreateNew=1;
         className.setText("");
         critPercent.setText("");
         
         AttackGrade.clearSelection();
         AttackGrade.setCurSel(0);
         DefenseGrade.clearSelection();
         DefenseGrade.setCurSel(0);  
         MAttackGrade.clearSelection();
         MAttackGrade.setCurSel(0); 
         MDefenseGrade.clearSelection();
         MDefenseGrade.setCurSel(0);
         VitalityGrade.clearSelection();
         VitalityGrade.setCurSel(0); 
         MagicGrade.clearSelection();
         MagicGrade.setCurSel(0);
         EvasionGrade.clearSelection();
         EvasionGrade.setCurSel(0); 
         AccuracyGrade.clearSelection();
         AccuracyGrade.setCurSel(0);
      }
   sqlite.closeDatabase();
   sqlite.delete();
   ClassGui.LoadClasses();
}

function ClassGui::LoadSelectedClass(){
   // attempt to retrieve result data
   %result=$CLASSGUI::CLASSID;
   $CLASSGUI::CreateNew=0;

   %count=ClassList.getSelectedItem();

   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ClassID, Name, CriticalRate from Classes;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      // attempt to retrieve result data
      $CLASSGUI::CLASSID=%result;
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      $CLASSGUI::SAVEID = sqlite.getColumn(%result, "ClassID");
      %Name = sqlite.getColumn(%result, "Name");
      %Crit = sqlite.getColumn(%result, "CriticalRate");
      
      %query = "Select GradeID from ClassGrades where ClassID="@ $CLASSGUI::SAVEID @";";
      %result = sqlite.query(%query, 0);
      %ATKGRD = sqlite.getColumn(%result, "GradeID");
      sqlite.nextRow(%result);
      %DEFGRD = sqlite.getColumn(%result, "GradeID");
      sqlite.nextRow(%result);
      %MATKGRD = sqlite.getColumn(%result, "GradeID");
      sqlite.nextRow(%result);
      %MDEFGRD = sqlite.getColumn(%result, "GradeID");
      sqlite.nextRow(%result);
      %VITGRD = sqlite.getColumn(%result, "GradeID");
      sqlite.nextRow(%result);
      %MAGGRD = sqlite.getColumn(%result, "GradeID");
      sqlite.nextRow(%result);
      %EVAGRD = sqlite.getColumn(%result, "GradeID");
      sqlite.nextRow(%result);
      %ACCGRD = sqlite.getColumn(%result, "GradeID"); 
            
      AttackGrade.clearSelection();
      AttackGrade.setCurSel(%ATKGRD-1);
      DefenseGrade.clearSelection();
      DefenseGrade.setCurSel(%DEFGRD-1);  
      MAttackGrade.clearSelection();
      MAttackGrade.setCurSel(%MATKGRD-1); 
      MDefenseGrade.clearSelection();
      MDefenseGrade.setCurSel(%MDEFGRD-1);
      VitalityGrade.clearSelection();
      VitalityGrade.setCurSel(%VITGRD-1); 
      MagicGrade.clearSelection();
      MagicGrade.setCurSel(%MAGGRD-1);
      EvasionGrade.clearSelection();
      EvasionGrade.setCurSel(%EVAGRD-1); 
      AccuracyGrade.clearSelection();
      AccuracyGrade.setCurSel(%ACCGRD-1);
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
   className.setText(%Name);
   critPercent.setText(%Crit);
}
   
function ClassGui::New()
{
   $CLASSGUI::CreateNew=1;
   className.setText("");
   critPercent.setText("");
   AttackGrade.clearSelection();
   AttackGrade.setCurSel(0);
   DefenseGrade.clearSelection();
   DefenseGrade.setCurSel(0);  
   MAttackGrade.clearSelection();
   MAttackGrade.setCurSel(0); 
   MDefenseGrade.clearSelection();
   MDefenseGrade.setCurSel(0);
   VitalityGrade.clearSelection();
   VitalityGrade.setCurSel(0); 
   MagicGrade.clearSelection();
   MagicGrade.setCurSel(0);
   EvasionGrade.clearSelection();
   EvasionGrade.setCurSel(0); 
   AccuracyGrade.clearSelection();
   AccuracyGrade.setCurSel(0);
}

function ClassGui::Delete()
{
   // attempt to retrieve result data
   %result=$CLASSGUI::CLASSID;
   $CLASSGUI::CreateNew=0;

   %count=ClassList.getSelectedItem();
      
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select ClassID, Name, CriticalRate from Classes;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      // attempt to retrieve result data
      $CLASSGUI::CLASSID=%result;
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         $CLASSGUI::SAVEID = sqlite.getColumn(%result, "ClassID");
         %query = "Delete from Classes where ClassID="@$CLASSGUI::SAVEID@";";
         %result = sqlite.query(%query, 0);   
         %query = "Delete from ClassGrades where ClassID="@$CLASSGUI::SAVEID@";";
         %result = sqlite.query(%query, 0);   
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   ClassGui.LoadClasses();
   
   
   $CLASSGUI::CreateNew=1;
   className.setText("");
   critPercent.setText("");
   
   AttackGrade.clearSelection();
   AttackGrade.setCurSel(0);
   DefenseGrade.clearSelection();
   DefenseGrade.setCurSel(0);  
   MAttackGrade.clearSelection();
   MAttackGrade.setCurSel(0); 
   MDefenseGrade.clearSelection();
   MDefenseGrade.setCurSel(0);
   VitalityGrade.clearSelection();
   VitalityGrade.setCurSel(0); 
   MagicGrade.clearSelection();
   MagicGrade.setCurSel(0);
   EvasionGrade.clearSelection();
   EvasionGrade.setCurSel(0); 
   AccuracyGrade.clearSelection();
   AccuracyGrade.setCurSel(0);
}
