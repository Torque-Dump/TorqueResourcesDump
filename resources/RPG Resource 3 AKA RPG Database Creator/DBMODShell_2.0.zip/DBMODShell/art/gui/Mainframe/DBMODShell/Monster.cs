//------------------------------------------------------------------------------
// Torque        Engine
// Copyright (C) GarageGames.com, Inc.
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// OnMonsterLoad methods
//------------------------------------------------------------------------------

$MonsterGUI::MonsterID="";
$MonsterGUI::SAVEID="";
$MonsterGUI::CreateNew=1;

function MonsterGui::LoadMonsters()
{
   MonsterList.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select MonsterID, Name from Monsters;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      $MonsterGUI::MonsterID=%result;
      while (!sqlite.endOfResult(%result))
      {
         %Monstername = sqlite.getColumn(%result, "Name");
         MonsterList.addItem(%Monstername);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}
function MonsterGui::onWake(%this)
{
   MonsterGui.LoadMonsters();
   MonsterGui.LoadAttackGrade();
   MonsterGui.LoadDefenseGrade();
   MonsterGui.LoadMAttackGrade();
   MonsterGui.LoadMDefenseGrade();
   MonsterGui.LoadVitalityGrade();
   MonsterGui.LoadMagicGrade();
   MonsterGui.LoadEvasionGrade();
   MonsterGui.LoadAccuracyGrade();
   MonsterGui.LoadItems();
      MonsterName.setText("");
      Level9.setText("");
      DataBlockMOB.setText("");
      Money9.setText("");
      Exp9.setText("");
      critPercent9.setText("");
      dropRate9.setText("");
}


function MonsterGui::LoadAttackGrade()
{
   AttackGrade9.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %Monstername = sqlite.getColumn(%result, "GradeLetter");
         AttackGrade9.addItem(%Monstername);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   AttackGrade9.clearSelection();
   AttackGrade9.setCurSel(0);
}



function MonsterGui::LoadItems()
{
   ItemList9.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Items;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
         ItemList9.addItem("None");
      while (!sqlite.endOfResult(%result))
      {
         %Itemname = sqlite.getColumn(%result, "Name");
         ItemList9.addItem(%Itemname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   ItemList9.clearSelection();
   ItemList9.setCurSel(0);
}




function MonsterGui::LoadDefenseGrade()
{
   DefenseGrade.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %Monstername = sqlite.getColumn(%result, "GradeLetter");
         DefenseGrade9.addItem(%Monstername);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   DefenseGrade9.clearSelection();
   DefenseGrade9.setCurSel(0);
}




function MonsterGui::LoadMAttackGrade()
{
   MAttackGrade9.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %Monstername = sqlite.getColumn(%result, "GradeLetter");
         MAttackGrade9.addItem(%Monstername);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   MAttackGrade9.clearSelection();
   MAttackGrade9.setCurSel(0);
}




function MonsterGui::LoadMDefenseGrade()
{
   MDefenseGrade9.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %Monstername = sqlite.getColumn(%result, "GradeLetter");
         MDefenseGrade9.addItem(%Monstername);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   MDefenseGrade9.clearSelection();
   MDefenseGrade9.setCurSel(0);
}




function MonsterGui::LoadVitalityGrade()
{
   VitalityGrade9.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %Monstername = sqlite.getColumn(%result, "GradeLetter");
         VitalityGrade9.addItem(%Monstername);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   VitalityGrade9.clearSelection();
   VitalityGrade9.setCurSel(0);
}




function MonsterGui::LoadMagicGrade()
{
   MagicGrade9.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %Monstername = sqlite.getColumn(%result, "GradeLetter");
         MagicGrade9.addItem(%Monstername);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   MagicGrade9.clearSelection();
   MagicGrade9.setCurSel(0);
}




function MonsterGui::LoadEvasionGrade()
{
   EvasionGrade9.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %Monstername = sqlite.getColumn(%result, "GradeLetter");
         EvasionGrade9.addItem(%Monstername);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   EvasionGrade9.clearSelection();
   EvasionGrade9.setCurSel(0);
}






function MonsterGui::LoadAccuracyGrade()
{
   AccuracyGrade9.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select GradeLetter from Grades;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %Monstername = sqlite.getColumn(%result, "GradeLetter");
         AccuracyGrade9.addItem(%Monstername);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   AccuracyGrade9.clearSelection();
   AccuracyGrade9.setCurSel(0);
}


//------------------------------------------------------------------------------
// global methods
//------------------------------------------------------------------------------

/// Callback from the shell button for triggering single player.
function MonsterGui::LoadMain()
{
   Canvas.setContent(DBMODGui);
}

function MonsterGui::SaveMonster()
{
      %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
      %MansterName = MonsterName.getText();
      %Level= Level9.getText();
      %Money= Money9.getText();
      %Exp= Exp9.getText();
      %critPercent= critPercent9.getText();
      %dropRate= dropRate9.getText();
      %ItemDropID = ItemList9.getSelectedItem();   
      %DB = DataBlockMOB.getText();   
         
      %query = "select ItemID from Items;";
      %result = sqlite.query(%query, 0);   
      if(%ItemDropID>0){
         if (%result == 0)
         {
            %ItemDropID=0;
            echo("ERROR: Failed to SELECT from Monsters table.");
         }else{
            // attempt to retrieve result data
            $MonsterGUI::MonsterID=%result;
            for(%i = 0 ;%i< %ItemDropID-1;%i++)
            {
               sqlite.nextRow(%result);
            }
            %ItemDropID = sqlite.getColumn(%result, "ItemID");
         }
      }
      // create a new simple table for demonstration purposes
      if($MonsterGUI::CreateNew==0){
         %query = "Update Monsters set Name='"@ %MansterName @"', Level='"@ %Level @"', ItemDropID='"@ %ItemDropID @"', Money='"@ %Money @"', Exp='"@ %Exp @"', CriticalRate='"@ %critPercent @"', DropRate='"@ %dropRate @"', DataBlock='"@ %DB @"' where MonsterID="@ $MonsterGUI::SAVEID @";";
      }else{
         %query = "Insert into Monsters(Name, Level, ItemDropID, Money, Exp, CriticalRate, DropRate, DataBlock) Values('"@ %MansterName @"', '"@ %Level @"', '"@ %ItemDropID @"', '"@ %Money @"', '"@ %Exp @"', '"@ %critPercent @"', '"@ %dropRate @"', '"@ %DB @"');";
      }
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from users table.");
      }else{
            
            %ATKGRD = AttackGrade9.getSelectedItem()+1;
            %DEFGRD = DefenseGrade9.getSelectedItem()+1;
            %MATKGRD = MAttackGrade9.getSelectedItem()+1;
            %MDEFGRD = MDefenseGrade9.getSelectedItem()+1;
            %VITGRD = VitalityGrade9.getSelectedItem()+1;
            %MAGGRD = MagicGrade9.getSelectedItem()+1;
            %EVAGRD = EvasionGrade9.getSelectedItem()+1;
            %ACCGRD = AccuracyGrade9.getSelectedItem()+1;
            
            %query = "Select MonsterID from Monsters where Name='"@ %MansterName @"' and Level='"@ %Level @"' and ItemDropID='"@ %ItemDropID @"' and Money='"@ %Money @"' and Exp='"@ %Exp @"' and CriticalRate='"@ %critPercent @"' and DropRate='"@ %dropRate @"';";
            %result = sqlite.query(%query, 0);            
            $MonsterGUI::SAVEID  = sqlite.getColumn(%result, "MonsterID");
            // create a new simple table for demonstration purposes
            if($MonsterGUI::CreateNew==0){
               %query = "Update MonsterGrades set GradeID="@ %ATKGRD @" where MonsterID="@ $MonsterGUI::SAVEID @" and GradeTypeID=1;";
            }else{
               %query = "Insert into MonsterGrades(MonsterID, GradeTypeID, GradeID) Values("@ $MonsterGUI::SAVEID @", 1, "@ %ATKGRD @");";
            }
            %result = sqlite.query(%query, 0);
         
            if($MonsterGUI::CreateNew==0){
               %query = "Update MonsterGrades set GradeID="@ %DEFGRD @" where MonsterID="@ $MonsterGUI::SAVEID @" and GradeTypeID=2;";
            }else{
               %query = "Insert into MonsterGrades(MonsterID, GradeTypeID, GradeID) Values("@ $MonsterGUI::SAVEID @", 2, "@ %DEFGRD @");";
            }
            %result = sqlite.query(%query, 0);
         
            if($MonsterGUI::CreateNew==0){
               %query = "Update MonsterGrades set GradeID="@ %MATKGRD @" where MonsterID="@ $MonsterGUI::SAVEID @" and GradeTypeID=3;";
            }else{
               %query = "Insert into MonsterGrades(MonsterID, GradeTypeID, GradeID) Values("@ $MonsterGUI::SAVEID @", 3, "@ %MATKGRD @");";
            }
            %result = sqlite.query(%query, 0);
         
            if($MonsterGUI::CreateNew==0){
               %query = "Update MonsterGrades set GradeID="@ %MDEFGRD @" where MonsterID="@ $MonsterGUI::SAVEID @" and GradeTypeID=4;";
            }else{
               %query = "Insert into MonsterGrades(MonsterID, GradeTypeID, GradeID) Values("@ $MonsterGUI::SAVEID @", 4, "@ %MDEFGRD @");";
            }
            %result = sqlite.query(%query, 0);
         
            if($MonsterGUI::CreateNew==0){
               %query = "Update MonsterGrades set GradeID="@ %VITGRD @" where MonsterID="@ $MonsterGUI::SAVEID @" and GradeTypeID=5;";
            }else{
               %query = "Insert into MonsterGrades(MonsterID, GradeTypeID, GradeID) Values("@ $MonsterGUI::SAVEID @", 5, "@ %VITGRD @");";
            }
            %result = sqlite.query(%query, 0);
         
            if($MonsterGUI::CreateNew==0){
               %query = "Update MonsterGrades set GradeID="@ %MAGGRD @" where MonsterID="@ $MonsterGUI::SAVEID @" and GradeTypeID=6;";
            }else{
               %query = "Insert into MonsterGrades(MonsterID, GradeTypeID, GradeID) Values("@ $MonsterGUI::SAVEID @", 6, "@ %MAGGRD @");";
            }
            %result = sqlite.query(%query, 0);
         
            if($MonsterGUI::CreateNew==0){
               %query = "Update MonsterGrades set GradeID="@ %EVAGRD @" where MonsterID="@ $MonsterGUI::SAVEID @" and GradeTypeID=7;";
            }else{
               %query = "Insert into MonsterGrades(MonsterID, GradeTypeID, GradeID) Values("@ $MonsterGUI::SAVEID @", 7, "@ %EVAGRD @");";
            }
            %result = sqlite.query(%query, 0);
         
            if($MonsterGUI::CreateNew==0){
               %query = "Update MonsterGrades set GradeID="@ %ACCGRD @" where MonsterID="@ $MonsterGUI::SAVEID @" and GradeTypeID=8;";
            }else{
               %query = "Insert into MonsterGrades(MonsterID, GradeTypeID, GradeID) Values("@ $MonsterGUI::SAVEID @", 8, "@ %ACCGRD @");";
            }
            %result = sqlite.query(%query, 0);
         
         $MonsterGUI::CreateNew=1;
         MonsterName.setText("");
         Level9.setText("");
         DataBlockMOB.setText("");
         Money9.setText("");
         Exp9.setText("");
         critPercent9.setText("");
         dropRate9.setText("");
         AttackGrade9.clearSelection();
         AttackGrade9.setCurSel(0);
         DefenseGrade9.clearSelection();
         DefenseGrade9.setCurSel(0);  
         MAttackGrade9.clearSelection();
         MAttackGrade9.setCurSel(0); 
         MDefenseGrade9.clearSelection();
         MDefenseGrade9.setCurSel(0);
         VitalityGrade9.clearSelection();
         VitalityGrade9.setCurSel(0); 
         MagicGrade9.clearSelection();
         MagicGrade9.setCurSel(0);
         EvasionGrade9.clearSelection();
         EvasionGrade9.setCurSel(0); 
         AccuracyGrade9.clearSelection();
         AccuracyGrade9.setCurSel(0);
         ItemList9.clearSelection();
         ItemList9.setCurSel(0);
      }
   sqlite.closeDatabase();
   sqlite.delete();
   MonsterGui.LoadMonsters();
}

function MonsterGui::LoadSelectedMonster(){
   // attempt to retrieve result data
   $MonsterGUI::CreateNew=0;

   %count=MonsterList.getSelectedItem();

   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select MonsterID, Name, Level, ItemDropID, Money, Exp, CriticalRate, DropRate, DataBlock from Monsters;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Monsters table.");
   }else{
      // attempt to retrieve result data
      $MonsterGUI::MonsterID=%result;
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      $MonsterGUI::SAVEID = sqlite.getColumn(%result, "MonsterID");
      %Name = sqlite.getColumn(%result, "Name");
      %Level= sqlite.getColumn(%result, "Level");
      %ItemDropID= sqlite.getColumn(%result, "ItemDropID");
      %Money= sqlite.getColumn(%result, "Money");
      %Exp= sqlite.getColumn(%result, "Exp");
      %Crit = sqlite.getColumn(%result, "CriticalRate");
      %DropRate= sqlite.getColumn(%result, "DropRate");
      %DB= sqlite.getColumn(%result, "DataBlock");
      
            // create a new simple table for demonstration purposes
            %query = "select ItemID from Items;";
            %result = sqlite.query(%query, 0);   
            if (%result == 0)
            {
               echo("ERROR: Failed to SELECT from Monsters table.");
            }else{
               // attempt to retrieve result data
               $MonsterGUI::MonsterID=%result;
               for(%i = 1 ;!sqlite.endOfResult(%result);%i++)
               {
                  %RealID=sqlite.getColumn(%result, "ItemID");
                  if(%ItemDropID==%RealID){
                     ItemList9.clearSelection();
                     ItemList9.setCurSel(%i);  
                     break;       
                  }
                  sqlite.nextRow(%result);
               }
               
            }      
      
      %query = "Select GradeID from MonsterGrades where MonsterID="@ $MonsterGUI::SAVEID @";";
      %result = sqlite.query(%query, 0);
      %ATKGRD = sqlite.getColumn(%result, "GradeID");
      sqlite.nextRow(%result);
      %DEFGRD = sqlite.getColumn(%result, "GradeID");
      sqlite.nextRow(%result);
      %MATKGRD = sqlite.getColumn(%result, "GradeID");
      sqlite.nextRow(%result);
      %MDEFGRD = sqlite.getColumn(%result, "GradeID");
      sqlite.nextRow(%result);
      %VITGRD = sqlite.getColumn(%result, "GradeID");
      sqlite.nextRow(%result);
      %MAGGRD = sqlite.getColumn(%result, "GradeID");
      sqlite.nextRow(%result);
      %EVAGRD = sqlite.getColumn(%result, "GradeID");
      sqlite.nextRow(%result);
      %ACCGRD = sqlite.getColumn(%result, "GradeID"); 
            
      AttackGrade9.clearSelection();
      AttackGrade9.setCurSel(%ATKGRD-1);
      DefenseGrade9.clearSelection();
      DefenseGrade9.setCurSel(%DEFGRD-1);  
      MAttackGrade9.clearSelection();
      MAttackGrade9.setCurSel(%MATKGRD-1); 
      MDefenseGrade9.clearSelection();
      MDefenseGrade9.setCurSel(%MDEFGRD-1);
      VitalityGrade9.clearSelection();
      VitalityGrade9.setCurSel(%VITGRD-1); 
      MagicGrade9.clearSelection();
      MagicGrade9.setCurSel(%MAGGRD-1);
      EvasionGrade9.clearSelection();
      EvasionGrade9.setCurSel(%EVAGRD-1); 
      AccuracyGrade9.clearSelection();
      AccuracyGrade9.setCurSel(%ACCGRD-1);
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
   MonsterName.setText(%Name);
   Level9.setText(%Level);
   DataBlockMOB.setText(%DB);
   Money9.setText(%Money);
   Exp9.setText(%Exp);
   critPercent9.setText(%Crit);
   dropRate9.setText(%DropRate);

   
   
   
}
   
function MonsterGui::New()
{
         $MonsterGUI::CreateNew=1;
         MonsterName.setText("");
         Level9.setText("");
         DataBlockMOB.setText("");
         Money9.setText("");
         Exp9.setText("");
         critPercent9.setText("");
         dropRate9.setText("");
         AttackGrade9.clearSelection();
         AttackGrade9.setCurSel(0);
         DefenseGrade9.clearSelection();
         DefenseGrade9.setCurSel(0);  
         MAttackGrade9.clearSelection();
         MAttackGrade9.setCurSel(0); 
         MDefenseGrade9.clearSelection();
         MDefenseGrade9.setCurSel(0);
         VitalityGrade9.clearSelection();
         VitalityGrade9.setCurSel(0); 
         MagicGrade9.clearSelection();
         MagicGrade9.setCurSel(0);
         EvasionGrade9.clearSelection();
         EvasionGrade9.setCurSel(0); 
         AccuracyGrade9.clearSelection();
         AccuracyGrade9.setCurSel(0);
         ItemList9.clearSelection();
         ItemList9.setCurSel(0);
}

function MonsterGui::Delete()
{
   // attempt to retrieve result data
   %result=$MonsterGUI::MonsterID;
   $MonsterGUI::CreateNew=0;

   %count=MonsterList.getSelectedItem();
      
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select MonsterID, Name, CriticalRate from Monsters;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Monsters table.");
   }else{
      // attempt to retrieve result data
      $MonsterGUI::MonsterID=%result;
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         $MonsterGUI::SAVEID = sqlite.getColumn(%result, "MonsterID");
         %query = "Delete from Monsters where MonsterID="@$MonsterGUI::SAVEID@";";
         %result = sqlite.query(%query, 0);   
         %query = "Delete from MonsterGrades where MonsterID="@$MonsterGUI::SAVEID@";";
         %result = sqlite.query(%query, 0);   
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   MonsterGui.LoadMonsters();
   
   
   $MonsterGUI::CreateNew=1;
   MonsterName.setText("");
   critPercent.setText("");
   
   AttackGrade.clearSelection();
   AttackGrade.setCurSel(0);
   DefenseGrade.clearSelection();
   DefenseGrade.setCurSel(0);  
   MAttackGrade.clearSelection();
   MAttackGrade.setCurSel(0); 
   MDefenseGrade.clearSelection();
   MDefenseGrade.setCurSel(0);
   VitalityGrade.clearSelection();
   VitalityGrade.setCurSel(0); 
   MagicGrade.clearSelection();
   MagicGrade.setCurSel(0);
   EvasionGrade.clearSelection();
   EvasionGrade.setCurSel(0); 
   AccuracyGrade.clearSelection();
   AccuracyGrade.setCurSel(0);
   ItemList9.clearSelection();
   ItemList9.setCurSel(0);
}
