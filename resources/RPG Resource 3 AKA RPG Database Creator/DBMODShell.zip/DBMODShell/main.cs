//-----------------------------------------------------------------------------
// Torque        Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

function DBMODloadShell()
{
   exec("./profiles.cs");

   exec("./DBMOD.cs");
   exec("./DBMODGui.gui");
   exec("./Class.cs");
   exec("./Class.gui");
   exec("./Item.cs");
   exec("./ItemGui.gui");
   exec("./Armor.cs");
   exec("./ArmorGui.gui");
   exec("./Monster.cs");
   exec("./MonsterGui.gui");
   exec("./MonsterParty.cs");
   exec("./MonsterPartyGui.gui");
   exec("./Player.cs");
   exec("./PlayerGui.gui");
   exec("./Spell.cs");
   exec("./SpellGui.gui");
   exec("./HiddenArts.cs");
   exec("./HiddenArtsGui.gui");
}

DBMODloadShell();
