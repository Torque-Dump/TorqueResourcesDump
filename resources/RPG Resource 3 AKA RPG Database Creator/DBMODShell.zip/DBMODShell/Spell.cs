//------------------------------------------------------------------------------
// Torque        Engine
// Copyright (C) GarageGames.com, Inc.
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// OnclassLoad methods
//------------------------------------------------------------------------------

$SpellGui::SAVEID="";
$SpellGui::CreateNew=1;

function SpellGui::LoadSpells()
{
   SpellList.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Spells;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         SpellList.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}



function SpellGui::LoadClasses()
{
   ClassList5.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Classes;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ClassList5.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   ClassList5.clearSelection();
   ClassList5.setCurSel(0);
}


function SpellGui::LoadArcana()
{
   ArcanaList5.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Arcana;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      ArcanaList5.addItem("None");
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ArcanaList5.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   ArcanaList5.clearSelection();
   ArcanaList5.setCurSel(0);
}


function SpellGui::LoadStatus()
{
   StatusList5.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Statuses;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      StatusList5.addItem("None");
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         StatusList5.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   StatusList5.clearSelection();
   StatusList5.setCurSel(0);
}


function SpellGui::LoadParams()
{
   ParamList5.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Parameters;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      
      ParamList5.addItem("None");
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ParamList5.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   ParamList5.clearSelection();
   ParamList5.setCurSel(0);
}


function SpellGui::LoadRanges()
{
   RangeList5.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Ranges;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         RangeList5.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   RangeList5.clearSelection();
   RangeList5.setCurSel(0);
}


function SpellGui::onWake(%this)
{
   SpellGui.LoadSpells();
   SpellGui.LoadClasses();
   SpellGui.LoadArcana();
   SpellGui.LoadStatus();
   SpellGui.LoadParams();
   SpellGui.LoadRanges();
   SpellName.setText("");
   Power5.setText("");
   Level5.setText("");
   Cost5.setText("");
   CastUsage5.setText("");
   CastTime.setText("");
   Description5.setText("");
   Image5.setText("");
   Animation5.setText("");
}

//------------------------------------------------------------------------------
// global methods
//------------------------------------------------------------------------------

/// Callback from the shell button for triggering single Item.
function SpellGui::LoadMain()
{
   Canvas.setContent(DBMODGui);
}

function SpellGui::SaveSpell()
{
      %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   %ClassCount=ClassList5.getSelCount();
   %ClassIDs=ClassList5.getSelectedItems();
   %ArcanaID=ArcanaList5.getSelectedItem();
   %StatusID=StatusList5.getSelectedItem();
   %ParamID=ParamList5.getSelectedItem();
   %RangeID=RangeList5.getSelectedItem()+1;
   
   %SpellName = SpellName.getText();
   %Power5 = Power5.getText();
   %Level5 = Level5.getText();
   %Cost2 = Cost5.getText();
   %CastUsage5 = CastUsage5.getText();
   %CastTime = CastTime.getText();
   %Description5 = Description5.getText();
   %Image5 = Image5.getText();
   %Animation5 = Animation5.getText();
      
      // create a new simple table for demonstration purposes
      if($SpellGui::CreateNew==0){
         %query = "Update Spells set Name='"@%SpellName@"', Power='"@%Power5@"', Level='"@%Level5@"', Cost='"@%Cost2@"', CastUsage='"@%CastUsage5@"', CastTime='"@%CastTime@"', Description='"@%Description5@"', Image='"@%Image5@"', Animation='"@%Animation5@"',  StatusID='"@%StatusID@"', ArcanaID='"@%ArcanaID@"', RangeID='"@%RangeID@"', ParamID='"@%ParamID@"'  where SpellID='"@ $SpellGui::SAVEID @"';";
      }else{
         %query = "Insert into Spells(Name, Power, Level, Cost, CastUsage, CastTime, Description, Image, Animation, StatusID, ArcanaID, RangeID, ParamID) Values('"@ %SpellName @"', '"@%Power5@"', '"@%Level5@"', '"@%Cost2@"', '"@%CastUsage5@"', '"@%CastTime@"', '"@%Description5@"', '"@%Image5@"', '"@%Animation5@"',  '"@%StatusID@"', '"@%ArcanaID@"', '"@%RangeID@"', '"@%ParamID@"' );";
      }
      echo(%query);
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from users table.");
      }else{
         %query = "select SpellID from Spells where Name='"@%SpellName@"' and Power='"@%Power5@"' and Level='"@%Level5@"' and Cost='"@%Cost2@"' and CastUsage='"@%CastUsage5@"' and CastTime='"@%CastTime@"' and Description='"@%Description5@"' and Image='"@%Image5@"' and Animation='"@%Animation5@"' and StatusID='"@%StatusID@"' and ArcanaID='"@%ArcanaID@"' and RangeID='"@%RangeID@"' and ParamID='"@%ParamID@"';";
         echo(%query);                     
         %result = sqlite.query(%query, 0);   
         %SpellID = sqlite.getColumn(%result, "SpellID");
         

            %query = "Delete from SpellClass where SpellID='"@%SpellID@"';";  
            %result = sqlite.query(%query, 0);   
            
            
            for(%i =0;%i < %ClassCount ; %i++){
               %query = "select ClassID from Classes;";
               echo(%query);            
               %result = sqlite.query(%query, 0);   
               if (%result == 0)
               {
                  echo("ERROR: Failed to SELECT from Classes table.");
               }else{
                  // attempt to retrieve result data
                  for(%c = 0 ;%c< getWord(%ClassIDs, %i);%c++)
                  {
                     sqlite.nextRow(%result);
                  }
               }
               
               %REALCLASSID = sqlite.getColumn(%result, "ClassID");
               %query = "Insert into SpellClass(SpellID, ClassID) Values('"@%SpellID@"', '"@%REALCLASSID@"');";
               echo(%query);            
               %result = sqlite.query(%query, 0);
            }
         
         $SpellGui::CreateNew=1;
         SpellName.setText("");
         Power5.setText("");
         Level5.setText("");
         Cost5.setText("");
         CastUsage5.setText("");
         CastTime.setText("");
         Description5.setText("");
         Image5.setText("");
         Animation5.setText("");
         
         ClassList5.clearSelection();
         ArcanaList5.clearSelection();
         StatusList5.clearSelection();
         ParamList5.clearSelection();
         RangeList5.clearSelection();
         
         ClassList5.setCurSel(0);
         ArcanaList5.setCurSel(0);
         StatusList5.setCurSel(0);
         ParamList5.setCurSel(0);
         RangeList5.setCurSel(0);
      }
   sqlite.closeDatabase();
   sqlite.delete();
   SpellGui.LoadSpells();
}

function SpellGui::LoadSelectedSpell(){

   // attempt to retrieve result data
   $SpellGui::CreateNew=0;

   %count=SpellList.getSelectedItem();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select SpellID, Name, Power, Level, Cost, CastUsage, CastTime, Description, Image, Animation, StatusID, ArcanaID, RangeID, ParamID from Spells;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      // attempt to retrieve result data
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      $SpellGui::SAVEID = sqlite.getColumn(%result, "SpellID");
      
      %Name = sqlite.getColumn(%result, "Name");
      %Power = sqlite.getColumn(%result, "Power");
      %Level = sqlite.getColumn(%result, "Level");
      %Cost = sqlite.getColumn(%result, "Cost");
      %CastUsage = sqlite.getColumn(%result, "CastUsage");
      %CastTime = sqlite.getColumn(%result, "CastTime");
      %Description = sqlite.getColumn(%result, "Description");
      %Image = sqlite.getColumn(%result, "Image");
      %Animation = sqlite.getColumn(%result, "Animation");
      %StatusID = sqlite.getColumn(%result, "StatusID");
      %ArcanaID = sqlite.getColumn(%result, "ArcanaID");
      %RangeID = sqlite.getColumn(%result, "RangeID")-1;
      %ParamID = sqlite.getColumn(%result, "ParamID");
      
      %query = "select ClassID from SpellClass where SpellID='"@$SpellGui::SAVEID@"';";
      echo(%query);            
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
           echo("ERROR: Failed to SELECT from Classes table.");
      }else{
           %a=0;
           while (!sqlite.endOfResult(%result))
           {
              %ClassIDs[%a] = sqlite.getColumn(%result, "ClassID");
               sqlite.nextRow(%result);
               %a++;
           }
      }               
               
               
      
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
         $SpellGui::CreateNew=0;
         SpellName.setText(%Name);
         Power5.setText(%Power);
         Level5.setText(%Level);
         Cost5.setText(%Cost);
         CastUsage5.setText(%CastUsage);
         CastTime.setText(%CastTime);
         Description5.setText(%Description);
         Image5.setText(%Image);
         Animation5.setText(%Animation);
         
         ClassList5.clearSelection();
         ArcanaList5.clearSelection();
         StatusList5.clearSelection();
         ParamList5.clearSelection();
         RangeList5.clearSelection();
         
         ClassList5.clearSelection();
         for(%f =0 ; %f< %a ; %f++){
            ClassList5.setCurSel(%ClassIDs[%f]-1);
         }
         ArcanaList5.setCurSel(%ArcanaID);
         StatusList5.setCurSel(%StatusID);
         ParamList5.setCurSel(%ParamID);
         RangeList5.setCurSel(%RangeID);
}
   
function SpellGui::New()
{
         $SpellGui::CreateNew=1;
         SpellName.setText("");
         Power5.setText("");
         Level5.setText("");
         Cost5.setText("");
         CastUsage5.setText("");
         CastTime.setText("");
         Description5.setText("");
         Image5.setText("");
         Animation5.setText("");
         
         ClassList5.clearSelection();
         ArcanaList5.clearSelection();
         StatusList5.clearSelection();
         ParamList5.clearSelection();
         RangeList5.clearSelection();
         
         ClassList5.setCurSel(0);
         ArcanaList5.setCurSel(0);
         StatusList5.setCurSel(0);
         ParamList5.setCurSel(0);
         RangeList5.setCurSel(0);
}

function SpellGui::Delete()
{
   // attempt to retrieve result data
   $SpellGui::CreateNew=1;
   %count=SpellList.getSelectedItem();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select SpellID from Spells;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      // attempt to retrieve result data
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         $SpellGui::SAVEID = sqlite.getColumn(%result, "SpellID");
         %query = "Delete from Spells where SpellID="@$SpellGui::SAVEID@";";
         %result = sqlite.query(%query, 0);
         %query = "Delete from SpellClass where SpellID="@$SpellGui::SAVEID@";";
         %result = sqlite.query(%query, 0);
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   SpellGui.LoadSpells();
   
         $SpellGui::CreateNew=1;
         SpellName.setText("");
         Power5.setText("");
         Level5.setText("");
         Cost5.setText("");
         CastUsage5.setText("");
         CastTime.setText("");
         Description5.setText("");
         Image5.setText("");
         Animation5.setText("");
         
         ClassList5.clearSelection();
         ArcanaList5.clearSelection();
         StatusList5.clearSelection();
         ParamList5.clearSelection();
         RangeList5.clearSelection();
         
         ClassList5.setCurSel(0);
         ArcanaList5.setCurSel(0);
         StatusList5.setCurSel(0);
         ParamList5.setCurSel(0);
         RangeList5.setCurSel(0);
}
