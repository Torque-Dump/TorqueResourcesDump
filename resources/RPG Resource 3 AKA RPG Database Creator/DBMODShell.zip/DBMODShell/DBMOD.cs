//------------------------------------------------------------------------------
// Torque        Engine
// Copyright (C) GarageGames.com, Inc.
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// ListMenu methods
//------------------------------------------------------------------------------

/// Callback when this gui is added to the sim.
function ListMenuLeft::onAdd(%this)
{
   %this.addRow("Setup Classes", "LoadClass", 0);
   %this.addRow("Setup Players", "LoadPlayer", 2, -15);
   %this.addRow("Setup Items", "LoadItem", 4, -15);
   %this.addRow("Setup Armors", "LoadArmor", 6, -15);
}

function ListMenuRight::onAdd(%this)
{
   %this.addRow("Setup Spells", "LoadSpell", 0);
   %this.addRow("Setup HiddenArt", "LoadHiddenArt", 2, -15);
   %this.addRow("Setup Monsters", "LoadMonsters", 4, -15);
   %this.addRow("Setup Parties", "LoadMonstersParties", 6, -15);
}

//------------------------------------------------------------------------------
// MainMenuButtonHolder methods
//------------------------------------------------------------------------------

function DBMODGui::onWake(%this)
{

}

//------------------------------------------------------------------------------
// global methods
//------------------------------------------------------------------------------

/// Callback from the shell button for triggering single player.
function LoadClass()
{
   Canvas.setContent(ClassGui);
}

/// Callback from the shell button to bring up the object picker.
function LoadPlayer()
{
   Canvas.setContent(PlayerGui);
}

/// Callback from the shell button to bring up the options gui.
function LoadItem()
{
   Canvas.setContent(ItemGui);
}

/// Callback from the shell "quit" button.
function LoadArmor()
{
   Canvas.setContent(ArmorGui);
}
/// Callback from the shell "quit" button.
function LoadSpell()
{
   Canvas.setContent(SpellGui);
}
/// Callback from the shell "quit" button.
function LoadHiddenArt()
{
   Canvas.setContent(HiddenArtGui);
}
/// Callback from the shell "quit" button.
function LoadMonsters()
{
   Canvas.setContent(MonsterGui);
}

/// Callback from the shell "quit" button.
function LoadMonstersParties()
{
   Canvas.setContent(MonsterPartyGui);
}

