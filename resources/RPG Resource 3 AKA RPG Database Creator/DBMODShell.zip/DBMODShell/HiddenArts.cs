//------------------------------------------------------------------------------
// Torque        Engine
// Copyright (C) GarageGames.com, Inc.
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// OnclassLoad methods
//------------------------------------------------------------------------------

$HiddenArtGui::SAVEID="";
$HiddenArtGui::CreateNew=1;

function HiddenArtGui::LoadHiddenArts()
{
   HiddenArtList.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from HiddenArts;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         HiddenArtList.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
}



function HiddenArtGui::LoadClasses()
{
   ClassList6.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Classes;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ClassList6.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   ClassList6.clearSelection();
   ClassList6.setCurSel(0);
}


function HiddenArtGui::LoadArcana()
{
   ArcanaList6.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Arcana;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      ArcanaList6.addItem("None");
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ArcanaList6.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   ArcanaList6.clearSelection();
   ArcanaList6.setCurSel(0);
}


function HiddenArtGui::LoadStatus()
{
   StatusList6.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Statuses;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      StatusList6.addItem("None");
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         StatusList6.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   StatusList6.clearSelection();
   StatusList6.setCurSel(0);
}


function HiddenArtGui::LoadParams()
{
   ParamList6.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Parameters;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      
      ParamList6.addItem("None");
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         ParamList6.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   ParamList6.clearSelection();
   ParamList6.setCurSel(0);
}


function HiddenArtGui::LoadRanges()
{
   RangeList6.clearItems();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select Name from Ranges;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      while (!sqlite.endOfResult(%result))
      {
         %classname = sqlite.getColumn(%result, "Name");
         RangeList6.addItem(%classname);
         sqlite.nextRow(%result);
      }
   }
   sqlite.closeDatabase();
   sqlite.delete();
   RangeList6.clearSelection();
   RangeList6.setCurSel(0);
}


function HiddenArtGui::onWake(%this)
{
   HiddenArtGui.LoadHiddenArts();
   HiddenArtGui.LoadClasses();
   HiddenArtGui.LoadArcana();
   HiddenArtGui.LoadStatus();
   HiddenArtGui.LoadParams();
   HiddenArtGui.LoadRanges();
   HiddenArtName.setText("");
   Power6.setText("");
   Level6.setText("");
   Cost6.setText("");
   CastUsage6.setText("");
   CastTime6.setText("");
   Description6.setText("");
   Image6.setText("");
   Animation6.setText("");
}

//------------------------------------------------------------------------------
// global methods
//------------------------------------------------------------------------------

/// Callback from the shell button for triggering single Item.
function HiddenArtGui::LoadMain()
{
   Canvas.setContent(DBMODGui);
}

function HiddenArtGui::SaveHiddenArt()
{
      %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   %ClassCount=ClassList6.getSelCount();
   %ClassIDs=ClassList6.getSelectedItems();
   %ArcanaID=ArcanaList6.getSelectedItem();
   %StatusID=StatusList6.getSelectedItem();
   %ParamID=ParamList6.getSelectedItem();
   %RangeID=RangeList6.getSelectedItem()+1;
   
   %HiddenArtName = HiddenArtName.getText();
   %Power5 = Power6.getText();
   %Level5 = Level6.getText();
   %Cost2 = Cost6.getText();
   %CastUsage5 = CastUsage6.getText();
   %CastTime = CastTime6.getText();
   %Description5 = Description6.getText();
   %Image5 = Image6.getText();
   %Animation5 = Animation6.getText();
      
      // create a new simple table for demonstration purposes
      if($HiddenArtGui::CreateNew==0){
         %query = "Update HiddenArts set Name='"@%HiddenArtName@"', Power='"@%Power5@"', Level='"@%Level5@"', Cost='"@%Cost2@"', CastUsage='"@%CastUsage5@"', CastTime='"@%CastTime@"', Description='"@%Description5@"', Image='"@%Image5@"', Animation='"@%Animation5@"',  StatusID='"@%StatusID@"', ArcanaID='"@%ArcanaID@"', RangeID='"@%RangeID@"', ParamID='"@%ParamID@"'  where HiddenArtID='"@ $HiddenArtGui::SAVEID @"';";
      }else{
         %query = "Insert into HiddenArts(Name, Power, Level, Cost, CastUsage, CastTime, Description, Image, Animation, StatusID, ArcanaID, RangeID, ParamID) Values('"@ %HiddenArtName @"', '"@%Power5@"', '"@%Level5@"', '"@%Cost2@"', '"@%CastUsage5@"', '"@%CastTime@"', '"@%Description5@"', '"@%Image5@"', '"@%Animation5@"',  '"@%StatusID@"', '"@%ArcanaID@"', '"@%RangeID@"', '"@%ParamID@"' );";
      }
      echo(%query);
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
         echo("ERROR: Failed to SELECT from users table.");
      }else{
         %query = "select HiddenArtID from HiddenArts where Name='"@%HiddenArtName@"' and Power='"@%Power5@"' and Level='"@%Level5@"' and Cost='"@%Cost2@"' and CastUsage='"@%CastUsage5@"' and CastTime='"@%CastTime@"' and Description='"@%Description5@"' and Image='"@%Image5@"' and Animation='"@%Animation5@"' and StatusID='"@%StatusID@"' and ArcanaID='"@%ArcanaID@"' and RangeID='"@%RangeID@"' and ParamID='"@%ParamID@"';";
         echo(%query);                     
         %result = sqlite.query(%query, 0);   
         %HiddenArtID = sqlite.getColumn(%result, "HiddenArtID");
         

            %query = "Delete from HiddenArtClass where HiddenArtID='"@%HiddenArtID@"';";  
            %result = sqlite.query(%query, 0);   
            
            
            for(%i =0;%i < %ClassCount ; %i++){
               %query = "select ClassID from Classes;";
               echo(%query);            
               %result = sqlite.query(%query, 0);   
               if (%result == 0)
               {
                  echo("ERROR: Failed to SELECT from Classes table.");
               }else{
                  // attempt to retrieve result data
                  for(%c = 0 ;%c< getWord(%ClassIDs, %i);%c++)
                  {
                     sqlite.nextRow(%result);
                  }
               }
               
               %REALCLASSID = sqlite.getColumn(%result, "ClassID");
               %query = "Insert into HiddenArtClass(HiddenArtID, ClassID) Values('"@%HiddenArtID@"', '"@%REALCLASSID@"');";
               echo(%query);            
               %result = sqlite.query(%query, 0);
            }
         
         $HiddenArtGui::CreateNew=1;
         HiddenArtName.setText("");
         Power6.setText("");
         Level6.setText("");
         Cost6.setText("");
         CastUsage6.setText("");
         CastTime6.setText("");
         Description6.setText("");
         Image6.setText("");
         Animation6.setText("");
         
         ClassList6.clearSelection();
         ArcanaList6.clearSelection();
         StatusList6.clearSelection();
         ParamList6.clearSelection();
         RangeList6.clearSelection();
         
         ClassList6.setCurSel(0);
         ArcanaList6.setCurSel(0);
         StatusList6.setCurSel(0);
         ParamList6.setCurSel(0);
         RangeList6.setCurSel(0);
      }
   sqlite.closeDatabase();
   sqlite.delete();
   HiddenArtGui.LoadHiddenArts();
}

function HiddenArtGui::LoadSelectedHiddenArt(){

   // attempt to retrieve result data
   $HiddenArtGui::CreateNew=0;

   %count=HiddenArtList.getSelectedItem();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select HiddenArtID, Name, Power, Level, Cost, CastUsage, CastTime, Description, Image, Animation, StatusID, ArcanaID, RangeID, ParamID from HiddenArts;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      // attempt to retrieve result data
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
      $HiddenArtGui::SAVEID = sqlite.getColumn(%result, "HiddenArtID");
      
      %Name = sqlite.getColumn(%result, "Name");
      %Power = sqlite.getColumn(%result, "Power");
      %Level = sqlite.getColumn(%result, "Level");
      %Cost = sqlite.getColumn(%result, "Cost");
      %CastUsage = sqlite.getColumn(%result, "CastUsage");
      %CastTime = sqlite.getColumn(%result, "CastTime");
      %Description = sqlite.getColumn(%result, "Description");
      %Image = sqlite.getColumn(%result, "Image");
      %Animation = sqlite.getColumn(%result, "Animation");
      %StatusID = sqlite.getColumn(%result, "StatusID");
      %ArcanaID = sqlite.getColumn(%result, "ArcanaID");
      %RangeID = sqlite.getColumn(%result, "RangeID")-1;
      %ParamID = sqlite.getColumn(%result, "ParamID");
      
      %query = "select ClassID from HiddenArtClass where HiddenArtID='"@$HiddenArtGui::SAVEID@"';";
      echo(%query);            
      %result = sqlite.query(%query, 0);   
      if (%result == 0)
      {
           echo("ERROR: Failed to SELECT from Classes table.");
      }else{
           %a=0;
           while (!sqlite.endOfResult(%result))
           {
              %ClassIDs[%a] = sqlite.getColumn(%result, "ClassID");
               sqlite.nextRow(%result);
               %a++;
           }
      }               
               
               
      
   }
   %result="";
   
   sqlite.closeDatabase();
   sqlite.delete();
         $HiddenArtGui::CreateNew=0;
         HiddenArtName.setText(%Name);
         Power6.setText(%Power);
         Level6.setText(%Level);
         Cost6.setText(%Cost);
         CastUsage6.setText(%CastUsage);
         CastTime6.setText(%CastTime);
         Description6.setText(%Description);
         Image6.setText(%Image);
         Animation6.setText(%Animation);
         
         ClassList6.clearSelection();
         ArcanaList6.clearSelection();
         StatusList6.clearSelection();
         ParamList6.clearSelection();
         RangeList6.clearSelection();
         
         ClassList6.clearSelection();
         for(%f =0 ; %f< %a ; %f++){
            ClassList6.setCurSel(%ClassIDs[%f]-1);
         }
         ArcanaList6.setCurSel(%ArcanaID);
         StatusList6.setCurSel(%StatusID);
         ParamList6.setCurSel(%ParamID);
         RangeList6.setCurSel(%RangeID);
}
   
function HiddenArtGui::New()
{
         $HiddenArtGui::CreateNew=1;
         HiddenArtName.setText("");
         Power6.setText("");
         Level6.setText("");
         Cost6.setText("");
         CastUsage6.setText("");
         CastTime6.setText("");
         Description6.setText("");
         Image6.setText("");
         Animation6.setText("");
         
         ClassList6.clearSelection();
         ArcanaList6.clearSelection();
         StatusList6.clearSelection();
         ParamList6.clearSelection();
         RangeList6.clearSelection();
         
         ClassList6.setCurSel(0);
         ArcanaList6.setCurSel(0);
         StatusList6.setCurSel(0);
         ParamList6.setCurSel(0);
         RangeList6.setCurSel(0);
}

function HiddenArtGui::Delete()
{
   // attempt to retrieve result data
   $HiddenArtGui::CreateNew=1;
   %count=HiddenArtList.getSelectedItem();
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   
   // create a new simple table for demonstration purposes
   %query = "select HiddenArtID from HiddenArts;";
   %result = sqlite.query(%query, 0);   
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from Classes table.");
   }else{
      // attempt to retrieve result data
      for(%i = 0 ;%i< %count;%i++)
      {
         sqlite.nextRow(%result);
      }
         $HiddenArtGui::SAVEID = sqlite.getColumn(%result, "HiddenArtID");
         %query = "Delete from HiddenArts where HiddenArtID="@$HiddenArtGui::SAVEID@";";
         %result = sqlite.query(%query, 0);
         %query = "Delete from HiddenArtClass where HiddenArtID="@$HiddenArtGui::SAVEID@";";
         %result = sqlite.query(%query, 0);
   }
   
   sqlite.closeDatabase();
   sqlite.delete();
   HiddenArtGui.LoadHiddenArts();
   
         $HiddenArtGui::CreateNew=1;
         HiddenArtName.setText("");
         Power6.setText("");
         Level6.setText("");
         Cost6.setText("");
         CastUsage6.setText("");
         CastTime6.setText("");
         Description6.setText("");
         Image6.setText("");
         Animation6.setText("");
         
         ClassList6.clearSelection();
         ArcanaList6.clearSelection();
         StatusList6.clearSelection();
         ParamList6.clearSelection();
         RangeList6.clearSelection();
         
         ClassList6.setCurSel(0);
         ArcanaList6.setCurSel(0);
         StatusList6.setCurSel(0);
         ParamList6.setCurSel(0);
         RangeList6.setCurSel(0);
}
