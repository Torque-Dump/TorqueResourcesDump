#include "platform/platform.h"  
#include "renderInstance/renderSelectionMgr.h"  
  
#include "sceneGraph/sceneGraph.h"  
#include "sceneGraph/sceneState.h"  
#include "materials/sceneData.h"  
#include "materials/matInstance.h"  
//#include "materials/materialFeatureTypes.h"  
#include "materials/processedMaterial.h"  
#include "postFx/postEffect.h"  
#include "gfx/gfxTransformSaver.h"  
#include "gfx/gfxDebugEvent.h"  
  
IMPLEMENT_CONOBJECT( RenderSelectionMgr );  
  
RenderSelectionMgr::RenderSelectionMgr()  
   : RenderTexTargetBinManager(  RenderPassManager::RIT_Mesh,   
                                 1.0f,   
                                 1.0f,  
                                 GFXFormatR8G8B8A8,  
                                 Point2I( 512, 512 ) )  
{  
   mTargetSizeType = WindowSize;  
   MatTextureTarget::registerTarget( "selection", this );  
}  
  
RenderSelectionMgr::~RenderSelectionMgr()  
{  
   MatTextureTarget::unregisterTarget( "selection", this );     
}  
  
bool RenderSelectionMgr::isSelectionEnabled()  
{  
   if ( !mSelectionEffect )  
      mSelectionEffect = dynamic_cast<PostEffect*>( Sim::findObject( "SelectionPostFx" ) );  
  
   return mSelectionEffect && mSelectionEffect->isEnabled();  
}  
  
RenderBinManager::AddInstResult RenderSelectionMgr::addElement( RenderInst *inst )  
{  
   if ( !isSelectionEnabled() )  
      return RenderBinManager::arSkipped;  
  
	BaseMatInstance* matInst = getMaterial(inst);  
	bool hasSelection = matInst && matInst->hasSelection();  
   if ( !hasSelection )
      return RenderBinManager::arSkipped;  
  
   internalAddElement(inst);
  
   return RenderBinManager::arAdded;  
}  
  
  
void RenderSelectionMgr::render( SceneState *state )  
{  
   PROFILE_SCOPE( RenderSelectionMgr_Render );  

   // Don't allow non-diffuse passes.  
   if ( !state->isDiffusePass() )  
      return;  
  
   GFXDEBUGEVENT_SCOPE( RenderSelectionMgr_Render, ColorI::GREEN );  
  
   GFXTransformSaver saver;  
  
   // Tell the superclass we're about to render, preserve contents  
   const bool isRenderingToTarget = _onPreRender( state );  
  
   // Clear all the buffers to black.  
   GFX->clear( GFXClearTarget, ColorI::BLACK, 1.0f, 0);  
  
   // init loop data  
   SceneGraphData sgData;  
   U32 binSize = mElementList.size();  
  
   for( U32 j=0; j<binSize; )  
   {  
      MeshRenderInst *ri = static_cast<MeshRenderInst*>(mElementList[j].inst);  
  
      // temp fix - these shouldn't submit glow ri's...  
      if(ri->dynamicLight)  
      {  
         j++;  
         continue;  
      }  
  
      setupSGData( ri, sgData );  
      sgData.binType = SceneGraphData::SelectionBin;  
  
      BaseMatInstance *mat = ri->matInst;  
  
      U32 matListEnd = j;  
  
      while( mat->setupPass( state, sgData ) )  
      {  
         U32 a;  
         for( a=j; a<binSize; a++ )  
         {  
            MeshRenderInst *passRI = static_cast<MeshRenderInst*>(mElementList[a].inst);  
  
            if (newPassNeeded(mat, passRI))  
               break;  
  
            mat->setTransforms(*passRI->objectToWorld, *passRI->worldToCamera, *passRI->projection);  
            mat->setEyePosition(*passRI->objectToWorld, state->getCameraPosition());  
            mat->setBuffers(passRI->vertBuff, passRI->primBuff);  
  
            if ( passRI->prim )  
               GFX->drawPrimitive( *passRI->prim );  
            else  
               GFX->drawPrimitive( passRI->primBuffIndex );  
         }  
         matListEnd = a;  
      }  
  
      // force increment if none happened, otherwise go to end of batch  
      j = ( j == matListEnd ) ? j+1 : matListEnd;  
   }  
  
   // Finish up.  
   if ( isRenderingToTarget )  
      _onPostRender();  
}  