#ifndef _TEXTARGETBIN_MGR_H_  
#include "renderInstance/renderTexTargetBinManager.h"  
#endif  
  
class PostEffect;  
  
class RenderSelectionMgr : public RenderTexTargetBinManager  
{    
   typedef RenderTexTargetBinManager Parent;  
  
public:  
  
   RenderSelectionMgr();  
   virtual ~RenderSelectionMgr();  
  
   /// Returns true if the selection post effect is  
   /// enabled and the selection buffer should be updated.  
   bool isSelectionEnabled();  
  
   // RenderBinManager  
   virtual RenderBinManager::AddInstResult addElement( RenderInst *inst );  
   virtual void render( SceneState *state );  
  
   // ConsoleObject  
   DECLARE_CONOBJECT( RenderSelectionMgr );  
  
protected:  
  
   SimObjectPtr<PostEffect> mSelectionEffect;  
  
};  