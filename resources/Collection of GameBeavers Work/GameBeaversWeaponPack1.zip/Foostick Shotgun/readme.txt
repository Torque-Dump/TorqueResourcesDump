Foostick By Britton LaRoche 
Date 08/20/2004

I never claimed to be an artist, but thought it would be fun to try to make a weapon model.  
I made this in 2 hours, including the texture.

Foostick comes with a fully animated max file

1. Bob (idle)
2. Fire
3. Reload
4. Select

Exported into dts format and game ready for the TGE.

Foostick is released into the public domain with out any restictions.
You may do what ever you please.  
Use it royalty free for commercial purposes.


------- *** Fun Stuff Below, check out these sites *** ------------------

Want to make your own game? I highly recommend joining Game Beavers! 
http://www.gamebeavers.org

If you need content packs for Game Design, then take a look at Amped Labs.
http://www.ampedlabs.com

Need a professional game engine at rock bottom prices?
http://www.garagegames.com

-------------------------------------------------------------------------