function CreateAIWheeledVehicle2(%name, %botPath, %spawnPoint)
{
	// Create the A.I. driven bot object...	
	%player = new AIWheeledVehicle2()
	{
		dataBlock = DefaultCar;
		path = %botPath;
	};

	MissionCleanup.add( %player );
	%player.setShapeName( %name );
  
  %node = %botPath.getObject(0);  
  
  for(%i=0;%i<%botPath.getCount();%i++)
  {
	%node = %botPath.GetObject(%i);
	%player.addPathPoint(%node.getTransform(),%node.speed);	
  }
  
	%player.setTransform( %spawnPoint);
	
  %player.curentNode = 0;    // current node
  %player.setMoveTolerance(10.0);
  
  %player.score = 0;
 
    
	return %player;
}



function AIWheeledVehicle2::followPath( %this, %path, %node )
{
	echo("followPath()");
  // Start the bot following a path
  %this.stopThread(0);

   // Make sure our path is valid
  if( !isObject( %path ) )
  {
    echo( "AIWheeledVehicle::followPath failed - Bad Path!" );
    %this.path = "";
    return;
	}
	else
	{
		echo("Found valid path "@ %path);
	}

	%this.setStartNode(0);
	%this.init();
}
