//*****************************************************************************
// Enhanced Weapons System by Ron Nelson
//*****************************************************************************
//How fast the crosshairs close to lockon - range 0(Never lock) to 1(Instant lock)
//You should always use a value that can divide evenly into 1
$lockingSpeed = 0.05; 

//Minimum heat signature required to lock on in heatseeking mode
$minHeatSig = 50.0; //Player cross hair
$minHeatVehicleSig = 50.0; //Vehicle cross hair

//Detection mode for all gui
//0 = Player Only
//1 = Vehicle Only
//2 = Player and Vehicle
//3 = Everything detected in range finder and all others Player and Vehicle only
$detectionMode = 0; //Player cross hair
$detectionModeV  = 1; //Vehicle cross hair

function clientCmdTargetLockedOn(%locked)
{
   //sfxPlay(AudioTargetLockOn);
}

// Server tells us we got missile lock on by another ship (no threat yet, just lock on)
function clientCmdMissileLockOn(%locked)
{
	//sfxPlay(AudioMissileLockOn);
}

// Server tells us we got tracked by a missile
function clientCmdMissileFire(%sourceProjectile)
{
	//sfxPlay(AudioMissileFire);
}

function clientCmdStartTargetingCycle(%guided, %heatseeker, %range, %teamMode, %clientTeam)
{
   VehicleCrosshair.setVisible(false);
   VehicleLockonCrosshair.setVisible(false);

   Crosshair.setVisible(false);
   Crosshair.setLockingSpeed($lockingSpeed);
   
   LockonCrosshair.setVisible(%guided);
   LockonCrosshair.setLockingSpeed($lockingSpeed);
   LockonCrosshair.setLockonMode(%guided);
   LockonCrosshair.setMaxLockonRange(%range);
   LockonCrosshair.setTeamMode(%teamMode);
   LockonCrosshair.setClientTeam(%clientTeam);
   LockonCrosshair.setMinHeatSignature($detectionMode);
   LockonCrosshair.setDetectionMode($detectionMode);
   LockonCrosshair.setHeatSeekMode(%heatseeker);
  
   RangeFinder.setVisible(%guided);
   RangeFinder.setDetectionMode($detectionMode);

   ReticleHUD.setVisible(%guided);
   ReticleHUD.setTeamMode(%teamMode);
   ReticleHUD.setClientTeam(%clientTeam);
   ReticleHUD.setDetectionMode($detectionMode);
   ReticleHUD.setControlledTargetsOnly(false);
   ReticleHUD.setAutoTargeting(true);
  
   StartTargetingCycle();
}
function clientCmdStopTargetingCycle()
{
   VehicleCrosshair.setVisible(false);
   VehicleLockonCrosshair.setVisible(false);

   Crosshair.setVisible(true);
   RangeFinder.setVisible(false);
   LockonCrosshair.setVisible(false);
   LockonCrosshair.setLockonMode(false);
   LockonCrosshair.setHeatSeekMode(false);
   ReticleHUD.setVisible(false);
   ReticleHUD.setAutoTargeting(false);
   cancel($TargetingCycle);
}

function StartTargetingCycle()
{ 
   %lockonStatus = LockonCrosshair.getLockonStatus();
   %clientGhostID = LockonCrosshair.getTarget();
   
   if(isObject(ServerConnection))
   {
      %ghostIndex = ServerConnection.GetGhostIndex(%clientGhostID);
      if (%clientGhostID != 0)  // don't make it worse by looking up a zero object
         commandToServer('setCrosshairTarget', %ghostIndex, %lockonStatus); 
      else
         commandToServer('setCrosshairTarget', 0, false);
   }
      
   $TargetingCycle = schedule(500, 0, "StartTargetingCycle");
}

function clientCmdStartVTargetingCycle(%guided, %heatseeker, %range, %teamMode, %clientTeam)
{
   Crosshair.setVisible(false);
   LockonCrosshair.setVisible(false);

   VehicleCrosshair.setVisible(false);
   VehicleCrosshair.setLockingSpeed($lockingSpeed);
   
   VehicleLockonCrosshair.setVisible(%guided);
   VehicleLockonCrosshair.setLockingSpeed($lockingSpeed);
   VehicleLockonCrosshair.setLockonMode(true);
   VehicleLockonCrosshair.setMaxLockonRange(%range);
   VehicleLockonCrosshair.setTeamMode(%teamMode);
   VehicleLockonCrosshair.setClientTeam(%clientTeam);
   VehicleLockonCrosshair.setMinHeatSignature($minHeatVehicleSig);
   VehicleLockonCrosshair.setDetectionMode($detectionModeV);
   VehicleLockonCrosshair.setHeatSeekMode(%heatseeker);
   
   RangeFinder.setVisible(%guided);
   RangeFinder.setDetectionMode($detectionModeV);

   ReticleHUD.setVisible(%guided);
   ReticleHUD.setTeamMode(%teamMode);
   ReticleHUD.setClientTeam(%clientTeam);
   ReticleHUD.setDetectionMode($detectionModeV);
   ReticleHUD.setControlledTargetsOnly(true);
   ReticleHUD.setAutoTargeting(true);
  
   StartTargetingCycle();
}

function clientCmdStopVTargetingCycle()
{
   Crosshair.setVisible(false);
   LockonCrosshair.setVisible(false);

   VehicleCrosshair.setVisible(true);
   RangeFinder.setVisible(false);
   VehicleLockonCrosshair.setVisible(false);
   VehicleLockonCrosshair.setLockonMode(false);
   VehicleLockonCrosshair.setHeatSeekMode(false);
   ReticleHUD.setVisible(false);
   ReticleHUD.setAutoTargeting(false);
   cancel($TargetingCycle);
}

function clientCmdCancelTargetingCycle()
{
   cancel($TargetingCycle);
}

function StartVTargetingCycle()
{ 
   %lockonStatus = VehicleLockonCrosshair.getLockonStatus();

   %clientGhostID = VehicleLockonCrosshair.getTarget();

   if(isObject(ServerConnection))
   {
      %ghostIndex = ServerConnection.GetGhostIndex(%clientGhostID);
      if (%clientGhostID != 0)  // don't make it worse by looking up a zero object
         commandToServer('setCrosshairTarget', %ghostIndex, %lockonStatus); 
      else
         commandToServer('setCrosshairTarget', 0, false);
   }
      
   $TargetingCycle = schedule(500, 0, "StartVTargetingCycle");
}