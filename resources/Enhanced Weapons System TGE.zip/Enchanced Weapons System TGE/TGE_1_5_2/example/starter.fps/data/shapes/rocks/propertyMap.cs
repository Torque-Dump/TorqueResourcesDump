addMaterialMapping( "MossyRock02" , "sound: 0", "bulletType: 3" );
addMaterialMapping( "rock" , "sound: 0", "bulletType: 3" );
addMaterialMapping( "rock2" , "sound: 0", "bulletType: 3" );
