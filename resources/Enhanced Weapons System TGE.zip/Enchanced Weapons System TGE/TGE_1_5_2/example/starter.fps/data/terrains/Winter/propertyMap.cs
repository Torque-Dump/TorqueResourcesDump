//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

addMaterialMapping( "Dirt01" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 
addMaterialMapping( "PatchySnow02Colored" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 
addMaterialMapping( "Snow01Colored" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 
addMaterialMapping( "Snow02Colored" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 
addMaterialMapping( "Snow03Colored" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 
addMaterialMapping( "Snow06Colored" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 
addMaterialMapping( "WinterRock03" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 