//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

addMaterialMapping( "grass" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 
addMaterialMapping( "rock" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 
addMaterialMapping( "stone" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 
addMaterialMapping( "patchy" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 
addMaterialMapping( "scorched" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 
addMaterialMapping( "Dirt02" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" );
addMaterialMapping( "FarmLand03" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" );  