//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

addMaterialMapping( "path" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 
addMaterialMapping( "rock" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 
addMaterialMapping( "snow" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 
addMaterialMapping( "stones" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0", "bulletType: 4" ); 