//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Bullet Material Identifiers
//-----------------------------------------------------------------------------
//0 = Metal
//1 = Glass
//2 = Wood
//3 = Concrete/Stone/Rock/Asphault
//4 = Dirt Terrain
//5 = Generic
//6 = None


// A temporary hack until we can find a better way to initialize
// material properties.
exec( "./terrains/grassland/propertyMap.cs" );
//exec( "./terrains/highlands/propertyMap.cs" );
//exec( "./terrains/orctown/propertyMap.cs" );
exec( "./terrains/Winter/propertyMap.cs" );

exec( "./interiors/propertyMap.cs" ); 

exec( "./interiors/gunRange/propertyMap.cs" ); 

exec( "./shapes/ShapeMats.cs" ); 
