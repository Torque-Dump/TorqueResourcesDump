#include "gui/controls/guiTextCtrl.h"   
  
#include "console/consoleTypes.h"   
#include "console/console.h"   
#include "game/gameConnection.h"   
#include "game/gamebase.h"   
  
class GuiRangeFinderHud : public GuiTextCtrl   
{   
   typedef GuiTextCtrl Parent;   
  
    F32 mMaxRange;     // Max Range for our finder 
    bool vehiclesOnlyMode;
  
public:   
    GuiRangeFinderHud();   
    
    void setVehicleOnlyMode(bool flag) { vehiclesOnlyMode = flag; }
  
    void onRender( Point2I, const RectI &);   
    static void initPersistFields();   
    DECLARE_CONOBJECT( GuiRangeFinderHud );   
};   
  
  
//-----------------------------------------------------------------------------   
  
IMPLEMENT_CONOBJECT( GuiRangeFinderHud );   
  
GuiRangeFinderHud::GuiRangeFinderHud()   
{   
    mMaxRange = 1000;   //Max range we search for a collision   
	vehiclesOnlyMode = false;
}   
  
void GuiRangeFinderHud::initPersistFields()   
{   
    Parent::initPersistFields();   
  
    addGroup("RangeFinder");   
    addField("maxRange",    TypeF32,        Offset(mMaxRange,       GuiRangeFinderHud));   
    endGroup("RangeFinder");   
}   
  
void GuiRangeFinderHud::onRender(Point2I offset, const RectI &updateRect)   
{   
  // Must have a connection and game base control object   
   GameConnection* conn = GameConnection::getConnectionToServer();   
   if (!conn)   
      return;   
  
   GameBase* control = dynamic_cast<GameBase*>(conn->getControlObject());   
   if (!control)   
      return;   
  
   MatrixF cam;   
   Point3F dir;   
  
   Point3F startPos;   
   Point3F endPos;   
  
   // Get the camera's tranform,   
   conn->getControlCameraTransform(0,&cam);   
   cam.getColumn(3, &startPos); //Camera Position   
   cam.getColumn(1, &dir);      //Camera forward vector   
      
   //Calculate the point mMaxRange in front of camera.   
   endPos = startPos + dir * mMaxRange;   
  
   //Store the state of the collision   
   bool collisionEnabled = control->isCollisionEnabled();   
  
   //Disable collision so we don't collide with ourself.   
   if(collisionEnabled)   
      control->disableCollision();   
  
   //These are the items that we will consider to collide with   
   static U32 mask = TerrainObjectType |   
               InteriorObjectType |   
               WaterObjectType |   
               StaticShapeObjectType |   
               StaticTSObjectType |   
               PlayerObjectType |   
               ItemObjectType |   
               VehicleObjectType;   
  
    //Get out container, copied from camera.cpp, I think I need it :p   
    RayInfo collision;   
    Container* pContainer = control->isServerObject() ? &gServerContainer : &gClientContainer;   
  
    //Cast our ray and see what we hit 
    if(vehiclesOnlyMode)
    {
        if (pContainer->castRay(startPos, endPos, VehicleObjectType, &collision))   
        {   
            //If our ray hits, set our text   
            char text[32];   
            dSprintf(text, 32,"%.0f", (collision.point - startPos).len());   
            setText(text);   
        }   
        else    
        {   
            //Otherwise, set the range to maxRange+, ie: 1000+   
            char text[32];   
            dSprintf(text, 32,"");   
            setText(text);   
        }
    }
    else
    {
        if (pContainer->castRay(startPos, endPos, mask, &collision))   
        {   
            //If our ray hits, set our text   
            char text[32];   
            dSprintf(text, 32,"%.0f", (collision.point - startPos).len());   
            setText(text);   
        }   
        else    
        {   
            //Otherwise, set the range to maxRange+, ie: 1000+   
            char text[32];   
            dSprintf(text, 32,"");   
            setText(text);   
        }
    }
 
    //Enable collision if we need to   
    if(collisionEnabled)   
        control->enableCollision();   
  
    //Let the parent take care of rendering   
    Parent::onRender(offset,updateRect);   
}  

ConsoleMethod(GuiRangeFinderHud, setVehicleOnlyMode, void, 3, 3, "GuiRangeFinderHud.setVehicleOnlyMode(bool) - Sets vehicles only mode")
{
    object->setVehicleOnlyMode(dAtob(argv[2]));
}
