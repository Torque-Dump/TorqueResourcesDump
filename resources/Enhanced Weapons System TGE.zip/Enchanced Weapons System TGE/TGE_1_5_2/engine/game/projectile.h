//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _PROJECTILE_H_
#define _PROJECTILE_H_

#ifndef _GAMEBASE_H_
#include "game/gameBase.h"
#endif
#ifndef _TSSHAPE_H_
#include "ts/tsShape.h"
#endif
#ifndef _PLATFORMAUDIO_H_
#include "platform/platformAudio.h"
#endif

#include "lightingSystem/sgLightManager.h"
#include "game/fx/particleEmitter.h"

class ExplosionData;
class SplashData;
class DecalData;
class ShapeBase;
class TSShapeInstance;
class TSThread;
class TSStatic;

//--------------------------------------------------------------------------
/// Datablock for projectiles.  This class is the base class for all other projectiles.
class ProjectileData : public GameBaseData
{
   typedef GameBaseData Parent;

protected:
   bool onAdd();

public:
   // variables set in datablock definition:
   // Shape related
   const char* projectileShapeName;

   bool hasLight;
   F32 lightRadius;
   ColorF lightColor;

   bool hasWaterLight;
   ColorF waterLightColor;

   /// Set to true if it is a billboard and want it to always face the viewer, false otherwise
   bool faceViewer;
   Point3F scale;

   /// [0,1] scale of how much velocity should be inherited from the parent object
   F32 velInheritFactor;
   /// Speed of the projectile when fired
   F32 muzzleVelocity;
   // Explode on explodetime expiration - T_F -Cozz
   bool explodeOnExplodeTime;

   /// Should it arc?
   bool isBallistic;

   //Guided or Seeker Projectiles
   bool isGuided;
   bool isHeatSeeker;
   F32 sweepRadius;
   F32 precision; 
   S32 trackDelay;

   /// Should it follow the terrain?
   bool isTerrainFollowing; 
   /// How close can it be to the terrain?
   F32 minTerrainHeight;
   /// How far can it be from the terrain?
   F32 maxTerrainHeight;
   /// If outside these bounds, how quickly does it return?
   F32 speedTerrainFollowing;   
   
   //Sidewinder Stuff
   bool isSidewinder;
   F32 crazyness;  //This effects the random number generator
   S32 sideDelay;  //Delay control
   F32 multiplier; //Controls the intensity

   //Water explosion and stopping
   bool explodeOnWater;
   bool stoppedByWater;

   //Ballistic Coefficients
   F32 ballisticCoefficient;

   /// Should wind affect it?
   bool useWind;
   /// WindEffect
   F32 windEffect;

   //Piercing Projectile variables
   F32 mPierceWidth; //Offset to adjust allowed object width for armor piercing
   F32 mPlayerRearScanDist; //Offset for distance behind player to look for object to place blood splatter on


   /// How HIGH should it bounce (parallel to normal), [0,1]
   F32 bounceElasticity;
   /// How much momentum should be lost when it bounces (perpendicular to normal), [0,1]
   F32 bounceFriction;

   /// Should this projectile fall/rise different than a default object?
   F32 gravityMod;

   /// How long the projectile should exist before deleting itself
   U32 lifetime;     // all times are internally represented as ticks
   /// How long the projectile should exist before blowing up (**should always be less than lifetime**)
   U32 explodetime;     // all times are internally represented as ticks -Cozz
   /// How long it should not detonate on impact
   S32 armingDelay;  // the values are converted on initialization with
   S32 fadeDelay;    // the IRangeValidatorScaled field validator

   //RJN Start
   //Projectile FX Constants
   enum fxConstants {               // Number of decals constant
      NumFX = 6,
   };

   //Arrayed Interior/Static/Terrain Object Projectile Decal/Explosion set
   DecalData* decalSetOne[NumFX];       // Decal Datablocks
   DecalData* decalSetTwo[NumFX];       // Decal Datablocks
   DecalData* decalSetThree[NumFX];       // Decal Datablocks
   DecalData* decalSetFour[NumFX];       // Decal Datablocks
   DecalData* decalSetFive[NumFX];       // Decal Datablocks
   DecalData* decalSetSix[NumFX];       // Decal Datablocks

   S32 decalIdOne[NumFX];             // Decal IDs
   S32 decalIdTwo[NumFX];             // Decal IDs
   S32 decalIdThree[NumFX];             // Decal IDs
   S32 decalIdFour[NumFX];             // Decal IDs
   S32 decalIdFive[NumFX];             // Decal IDs
   S32 decalIdSix[NumFX];             // Decal IDs

   ExplosionData* explosionSetOne[NumFX];       // Explosion Datablock
   S32 explosionIdOne[NumFX];             // Explosion IDs
   ExplosionData* explosionSetTwo[NumFX];       // Explosion Datablock
   S32 explosionIdTwo[NumFX];             // Explosion IDs
   ExplosionData* explosionSetThree[NumFX];       // Explosion Datablock
   S32 explosionIdThree[NumFX];             // Explosion IDs
   ExplosionData* explosionSetFour[NumFX];       // Explosion Datablock
   S32 explosionIdFour[NumFX];             // Explosion IDs
   ExplosionData* explosionSetFive[NumFX];       // Explosion Datablock
   S32 explosionIdFive[NumFX];             // Explosion IDs
   ExplosionData* explosionSetSix[NumFX];       // Explosion Datablock
   S32 explosionIdSix[NumFX];             // Explosion IDs
   //RJN Stop
   
   //Arrayed Player Object Projectile Decal/Exposion set
   DecalData* bloodSplatter[NumFX];       // Blood Spatter Decal Datablocks
   S32 bloodSplatterId[NumFX];             // Blood Spatter Decal IDs
   S32 bloodExplosionId;               // Blood Explosion ID
   ExplosionData* bloodExplosion;       // Explosion Datablock
   
   ExplosionData* waterExplosion;      // Water Explosion Datablock
   S32 waterExplosionId;               // Water Explosion ID

   SplashData* splash;                 // Water Splash Datablock
   S32 splashId;                       // Water splash ID

   AudioProfile* sound;                // Projectile Sound
   S32 soundId;                        // Projectile Sound ID

   // variables set on preload:
   Resource<TSShape> projectileShape;
   S32 activateSeq;
   S32 maintainSeq;

   ParticleEmitterData* particleEmitter;
   S32 particleEmitterId;
   ParticleEmitterData* particleWaterEmitter;
   S32 particleWaterEmitterId;

   ProjectileData();

   void packData(BitStream*);
   void unpackData(BitStream*);
   bool preload(bool server, char errorBuffer[256]);

   static void initPersistFields();
   DECLARE_CONOBJECT(ProjectileData);
};
DECLARE_CONSOLETYPE(ProjectileData)


//--------------------------------------------------------------------------
/// Base class for all projectiles.
class Projectile : public GameBase
{
   typedef GameBase Parent;

public:
   // Initial conditions
   enum ProjectileConstants {
      SourceIdTimeoutTicks = 7,   // = 231 ms
      DeleteWaitTime       = 500, ///< 500 ms delete timeout (for network transmission delays)
      ExcessVelDirBits     = 7,
      MaxLivingTicks       = 4095,
   };
   enum UpdateMasks {
      BounceMask    = Parent::NextFreeMask,
      ExplosionMask = Parent::NextFreeMask << 1,
      GuideMask = Parent::NextFreeMask << 2, //Guided or Seeker Projectiles
	  NextFreeMask  = Parent::NextFreeMask << 3 
   };
protected:
   ProjectileData* mDataBlock;

   //Guided or Seeker Projectiles
   GameBase *mTarget;
   S32 mTargetId;

   ParticleEmitter* mParticleEmitter;
   ParticleEmitter* mParticleWaterEmitter;

   AUDIOHANDLE mSoundHandle;

   Point3F  mCurrPosition;
   Point3F  mInitialPosition;
   Point3F  mCurrVelocity;
   S32      mSourceObjectId;
   S32      mSourceObjectSlot;

   // Time related variables common to all projectiles, managed by processTick

   U32 mCurrTick;                         ///< Current time in ticks
   SimObjectPtr<ShapeBase> mSourceObject; ///< Actual pointer to the source object, times out after SourceIdTimeoutTicks

   // Rendering related variables
   TSShapeInstance* mProjectileShape;
   TSThread*        mActivateThread;
   TSThread*        mMaintainThread;

   Point3F          mLastRenderPos;

   void registerLights(LightManager * lm, bool lightingScene);
   LightInfo mLight;

   bool             mHidden;        ///< set by the derived class, if true, projectile doesn't render
   F32              mFadeValue;     ///< set in processTick, interpolation between fadeDelay and lifetime
                                 ///< in data block

   U32              pMatType;
   Point3F          mBloodRearPosition;
   Point3F          mBloodObjPosition;
   Point3F          mBloodVelocity;
   bool             armorPiercing;
   bool             mWrappedDecals;
   S32              mControlClient;

   bool             addPierce;
   Point3F          mPiercePoint;
   Point3F          mPierceNormal;
   Point3F          mPierceINormal;

   bool             useDecal;
   bool             transDecal;
   U32              transObjectId;
   SceneObject      *transObject;

   // Warping and back delta variables.  Only valid on the client
   //
   Point3F mWarpStart;
   Point3F mWarpEnd;
   U32     mWarpTicksRemaining;

   Point3F mCurrDeltaBase;
   Point3F mCurrBackDelta;

   Point3F mExplosionPosition;
   Point3F mExplosionNormal;
   U32     mCollideHitType;
   // drm - improved decals
   Point3F mImpactNormal;

   bool onAdd();
   void onRemove();
   bool onNewDataBlock(GameBaseData *dptr);

   void processTick(const Move *move);
   void advanceTime(F32 dt);
   void interpolateTick(F32 delta);

   //RJN Start 
   /// For armor piercing rounds
   virtual void onPierce(const Point3F& pos, const Point3F& vel);

   /// What to do once this projectile collides with something
   virtual void onCollision(const Point3F& p, const Point3F& n, SceneObject*);

   /// What to do when this projectile explodes
   virtual void explode(const Point3F& p, const Point3F& n, const Point3F &iN, const U32 collideType, U32 pMatType, bool transDec, SceneObject*);
   virtual void addPierceDecal(const Point3F& p, const Point3F& n, const Point3F &iN, const U32 collideType, U32 pMatType);
   //RJN Stop 

   /// Returns the velocity of the projectile
   Point3F getVelocity() const;
   void waterSurfaceExplosionCheck(const Point3F&, const Point3F&);
   bool pointInWater(const Point3F &point);
   void emitParticles(const Point3F&, const Point3F&, const Point3F&, const U32);
   void updateSound();

   // Rendering
   void prepModelView    ( SceneState *state);
   bool prepRenderImage  ( SceneState *state, const U32 stateKey, const U32 startZone, const bool modifyBaseZoneState=false);
   void renderObject     ( SceneState *state, SceneRenderImage *image);


   U32  packUpdate  (NetConnection *conn, U32 mask, BitStream *stream);
   void unpackUpdate(NetConnection *conn,           BitStream *stream);

public:
   F32 getUpdatePriority(CameraScopeQuery *focusObject, U32 updateMask, S32 updateSkips);

   Projectile();
   ~Projectile();

   DECLARE_CONOBJECT(Projectile);
   static void initPersistFields();

   virtual bool calculateImpact(float    simTime,
                                Point3F& pointOfImpact,
                                float&   impactTime);

   static U32 smProjectileWarpTicks;

protected:
   static const U32 csmStaticCollisionMask;
   static const U32 csmDynamicCollisionMask;
   static const U32 csmDamageableMask;
};

#endif // _H_PROJECTILE

