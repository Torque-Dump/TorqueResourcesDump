//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "math/mMath.h"
#include "math/mathUtils.h"
#include "math/mRandom.h"

namespace MathUtils
{

MRandomLCG sgRandom(0xdeadbeef); ///< Our random number generator.

//------------------------------------------------------------------------------
// Creates orientation matrix from a direction vector.  Assumes ( 0 0 1 ) is up.
//------------------------------------------------------------------------------
MatrixF createOrientFromDir( Point3F &direction )
{
	Point3F j = direction;
	Point3F k(0.0f, 0.0f, 1.0f);
	Point3F i;
	
	mCross( j, k, &i );

	if( i.magnitudeSafe() == 0.0f )
	{
		i.set( 0.0f, -1.0f, 0.0f );
	}

	i.normalizeSafe();
	mCross( i, j, &k );

   MatrixF mat( true );
   mat.setColumn( 0, i );
   mat.setColumn( 1, j );
   mat.setColumn( 2, k );

	return mat;
}


//------------------------------------------------------------------------------
// Creates random direction given angle parameters similar to the particle system.
// The angles are relative to the specified axis.
//------------------------------------------------------------------------------
Point3F randomDir( Point3F &axis, F32 thetaAngleMin, F32 thetaAngleMax,
                                 F32 phiAngleMin, F32 phiAngleMax )
{
   MatrixF orient = createOrientFromDir( axis );
   Point3F axisx;
   orient.getColumn( 0, &axisx );

   F32 theta = (thetaAngleMax - thetaAngleMin) * sgRandom.randF() + thetaAngleMin;
   F32 phi = (phiAngleMax - phiAngleMin) * sgRandom.randF() + phiAngleMin;

   // Both phi and theta are in degs.  Create axis angles out of them, and create the
   //  appropriate rotation matrix...
   AngAxisF thetaRot(axisx, theta * (M_PI_F / 180.0f));
   AngAxisF phiRot(axis,    phi   * (M_PI_F / 180.0f));

   Point3F ejectionAxis = axis;

   MatrixF temp(true);
   thetaRot.setMatrix(&temp);
   temp.mulP(ejectionAxis);
   phiRot.setMatrix(&temp);
   temp.mulP(ejectionAxis);

   return ejectionAxis;
}


//------------------------------------------------------------------------------
// Returns yaw and pitch angles from a given vector.  Angles are in RADIANS.
// Assumes north is (0.0, 1.0, 0.0), the degrees move upwards clockwise.
// The range of yaw is 0 - 2PI.  The range of pitch is -PI/2 - PI/2.
// ASSUMES Z AXIS IS UP
//------------------------------------------------------------------------------
void getAnglesFromVector( VectorF &vec, F32 &yawAng, F32 &pitchAng )
{
   yawAng = mAtan( vec.x, vec.y );

   if( yawAng < 0.0f )
   {
      yawAng += M_2PI_F;
   }

   if( fabs(vec.x) > fabs(vec.y) )
   {
      pitchAng = mAtan( fabs(vec.z), fabs(vec.x) );
   }
   else
   {
      pitchAng = mAtan( fabs(vec.z), fabs(vec.y) );
   }

   if( vec.z < 0.0f )
   {
      pitchAng = -pitchAng;
   }
}


//------------------------------------------------------------------------------
// Returns vector from given yaw and pitch angles.  Angles are in RADIANS.
// Assumes north is (0.0, 1.0, 0.0), the degrees move upwards clockwise.
// The range of yaw is 0 - 2PI.  The range of pitch is -PI/2 - PI/2.
// ASSUMES Z AXIS IS UP
//------------------------------------------------------------------------------
void getVectorFromAngles( VectorF &vec, F32 &yawAng, F32 &pitchAng )
{
   VectorF  pnt( 0.0f, 1.0f, 0.0f );

   EulerF   rot( -pitchAng, 0.0f, 0.0f );
   MatrixF  mat( rot );

   rot.set( 0.0f, 0.0f, yawAng );
   MatrixF   mat2( rot );

   mat.mulV( pnt );
   mat2.mulV( pnt );

   vec = pnt;
}


// transform bounding box making sure to keep original box entirely contained - JK...
void transformBoundingBox(const Box3F &sbox, const MatrixF &mat, const Point3F scale, Box3F &dbox)
{
	Point3F center;

	// set transformed center...
	sbox.getCenter(&center);
   center.convolve(scale);
	mat.mulP(center);
	dbox.min = center;
	dbox.max = center;

	Point3F val;
	for(U32 ix=0; ix<2; ix++)
	{
		if(ix & 0x1)
			val.x = sbox.min.x;
		else
			val.x = sbox.max.x;

		for(U32 iy=0; iy<2; iy++)
		{
			if(iy & 0x1)
				val.y = sbox.min.y;
			else
				val.y = sbox.max.y;

			for(U32 iz=0; iz<2; iz++)
			{
				if(iz & 0x1)
					val.z = sbox.min.z;
				else
					val.z = sbox.max.z;

				Point3F v1, v2;
            v1 = val;
            v1.convolve(scale);
				mat.mulP(v1, &v2);
				dbox.min.setMin(v2);
				dbox.max.setMax(v2);
			}
		}
	}
}

//Enhanced Projectiles
F32 getArea( const Point3F* verts, S32 count )
{
	// Vector whose length will be area^2.
	Point3F vec( 0, 0, 0 );
	for ( S32 i = 0; i < count; i++ ) {

      S32 j = i ? i - 1 : count - 1;

      // Add cross_product(pnts[j],pnts[i]).
		vec.x += verts[j].y * verts[i].z - verts[j].z * verts[i].y;
		vec.y += verts[j].z * verts[i].x - verts[j].x * verts[i].z;
		vec.z += verts[j].x * verts[i].y - verts[j].y * verts[i].x;
	}
   
	// Find length of vector, return it.
	return mSqrt( vec.x * vec.x + vec.y * vec.y + vec.z * vec.z ) / 2.0f;
}

Point3F getBarrycentricCoord( const Point3F& point, const Point3F* tri )
{
	// If the area of the triangle is zero... return 0.
	const F32 a = getArea( tri, 3 );

	if ( a <= 0.0f )
      return Point3F( 0, 0, 0 );

	Point3F b;
	{
      Point3F temp[3] =
      {
         tri[1],
         tri[2],
         point
      };
		b.x = getArea( temp, 3 ) / a;
	}
	{
      Point3F temp[3] =
      {
         tri[2],
         tri[0],
         point
      };
		b.y = getArea( temp, 3 ) / a;
	}
	{
      Point3F temp[3] =
      {
         tri[0],
         tri[1],
         point
      };
		b.z = getArea( temp, 3 ) / a;
	}

   return b;
}

bool rayTriangleIntersect( const Point3F& orig, const Point3F& dir,
   const Point3F& vert0, const Point3F& vert1, const Point3F& vert2,
   F32 *t, F32 *u, F32 *v )
{
   const F32 EPSILON = __EQUAL_CONST_F;

   /* find vectors for two edges sharing vert0 */
   Point3F edge1( vert1 -  vert0 );
   Point3F edge2( vert2 -  vert0 );

   /* begin calculating determinant - also used to calculate U parameter */
   Point3F pvec( mCross( dir, edge2 ) );

   /* if determinant is near zero, ray lies in plane of triangle */
   F32 det = mDot( edge1, pvec );

   if (det < EPSILON)
      return 0;

   /* calculate distance from vert0 to ray origin */
   Point3F tvec( orig - vert0 );

   /* calculate U parameter and test bounds */
   *u = mDot( tvec, pvec );
   if (*u < 0.0 || *u > det)
      return false;

   /* prepare to test V parameter */
   Point3F qvec( mCross( tvec, edge1 ) );

   /* calculate V parameter and test bounds */
   *v = mDot( dir, qvec );
   if (*v < 0.0 || *u + *v > det)
      return false;

   /* calculate t, scale parameters, ray intersects triangle */
   F32 inv_det = 1.0 / det;
   *t = mDot( edge2, qvec ) * inv_det;
   *u *= inv_det;
   *v *= inv_det;

   return true;
}
//Enhanced Projectiles
} // end namespace MathUtils
