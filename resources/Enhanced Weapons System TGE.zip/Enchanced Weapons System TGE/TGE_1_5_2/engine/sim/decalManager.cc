//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "sim/decalManager.h"
#include "dgl/dgl.h"
#include "sceneGraph/sceneGraph.h"
#include "sceneGraph/sceneState.h"
#include "ts/tsShapeInstance.h"
#include "core/bitStream.h"
#include "console/consoleTypes.h"

#include "sim/sceneObject.h"

bool DecalManager::smDecalsOn = true;
bool DecalManager::sgThisIsSelfIlluminated = false;
bool DecalManager::sgLastWasSelfIlluminated = false;
//********************************************************************************************
//Wrapping Decals
//********************************************************************************************
const U32 DecalManager::csmFreePoolBlockSize = 256;
const U32 DecalManager::csmFreeWrapPoolBlockSize = 256;

U32       DecalManager::smMaxNumDecals = 256;
U32       DecalManager::smDecalTimeout = 5000;

DepthSortList DecalManager::smDepthSortList;
U32 DecalManager::smDecalMask = TerrainObjectType | InteriorObjectType | StaticObjectType | ShapeBaseObjectType;
Box3F gDecalBox;
SphereF gDecalSphere;
Point3F gDecalPoly[4];
//********************************************************************************************
//Wrapping Decals
//********************************************************************************************

DecalManager* gDecalManager = NULL;
IMPLEMENT_CONOBJECT(DecalManager);
IMPLEMENT_CO_DATABLOCK_V1(DecalData);

namespace {

   int QSORT_CALLBACK cmpDecalInstance(const void* p1, const void* p2)
   {
      const DecalInstance** pd1 = (const DecalInstance**)p1;
      const DecalInstance** pd2 = (const DecalInstance**)p2;

      return int(((char *)(*pd1)->decalData) - ((char *)(*pd2)->decalData));
   }

} // namespace {}


//--------------------------------------------------------------------------
DecalData::DecalData()
{
   sizeX = 1;
   sizeY = 1;
   textureName = "";
   
	selfIlluminated = false;
	lifeSpan = DecalManager::smDecalTimeout;
}

DecalData::~DecalData()
{
   if(gDecalManager)
      gDecalManager->dataDeleted(this);
}


void DecalData::packData(BitStream* stream)
{
   Parent::packData(stream);

   stream->write(sizeX);
   stream->write(sizeY);
   stream->writeString(textureName);
   
	stream->write(selfIlluminated);
	stream->write(lifeSpan);
}

void DecalData::unpackData(BitStream* stream)
{
   Parent::unpackData(stream);

   stream->read(&sizeX);
   stream->read(&sizeY);
   textureName = stream->readSTString();

	stream->read(&selfIlluminated);
	stream->read(&lifeSpan);
}

bool DecalData::preload(bool server, char errorBuffer[256])
{
   if (Parent::preload(server, errorBuffer) == false)
      return false;

   if (sizeX < 0.0) {
      Con::warnf("DecalData::preload: sizeX < 0");
      sizeX = 0;
   }
   if (sizeY < 0.0) {
      Con::warnf("DecalData::preload: sizeX < 0");
      sizeY = 0;
   }
   if (textureName == NULL || textureName[0] == '\0') {
      Con::errorf("No texture name for decal!");
      return false;
   }

   if (!server) {
      textureHandle = TextureHandle(textureName, MeshTexture);
      if (textureHandle.getGLName() == 0) {
         Con::errorf("Unable to load texture: %s for decal!", textureName);
         return false;
      }
   }

   return true;
}

IMPLEMENT_CONSOLETYPE(DecalData)
IMPLEMENT_SETDATATYPE(DecalData)
IMPLEMENT_GETDATATYPE(DecalData)

void DecalData::initPersistFields()
{
   addField("sizeX",       TypeF32,       Offset(sizeX,       DecalData));
   addField("sizeY",       TypeF32,       Offset(sizeY,       DecalData));
   addField("textureName", TypeFilename,  Offset(textureName, DecalData));

	addField("SelfIlluminated", TypeBool, Offset(selfIlluminated, DecalData));
	addField("LifeSpan", TypeS32, Offset(lifeSpan, DecalData));
}

//********************************************************************************************
//Wrapping Decals
//********************************************************************************************
DecalInstance::DecalInstance()
{
	exData=NULL;

	dynamic = false;
	decObject = NULL;
}

DecalInstance::~DecalInstance()
{
   if (exData)
   {
      delete exData;
      exData=NULL;
   }
   decObject = NULL;
}
//********************************************************************************************
//Wrapping Decals
//********************************************************************************************

DecalManager::DecalManager()
{
   mTypeMask |= DecalManagerObjectType;

   mObjBox.min.set(-1e7, -1e7, -1e7);
   mObjBox.max.set( 1e7,  1e7,  1e7);
   mWorldBox.min.set(-1e7, -1e7, -1e7);
   mWorldBox.max.set( 1e7,  1e7,  1e7);

   mFreePool = NULL;
   VECTOR_SET_ASSOCIATION(mDecalQueue);
   VECTOR_SET_ASSOCIATION(mFreePoolBlocks);
//********************************************************************************************
//Wrapping Decals
//********************************************************************************************
   mFreeWrapPool = NULL;
   VECTOR_SET_ASSOCIATION(mWrapDecalQueue);
   VECTOR_SET_ASSOCIATION(mFreeWrapPoolBlocks);
//********************************************************************************************
//Wrapping Decals
//********************************************************************************************
}

//********************************************************************************************
//Wrapping Decals
//********************************************************************************************
DecalManager::~DecalManager()
{
   mFreePool = NULL;
   mFreeWrapPool = NULL;
   for (S32 i = 0; i < mFreePoolBlocks.size(); i++)
   {
      delete [] mFreePoolBlocks[i];
   }
   for (S32 a = 0; a < mFreeWrapPoolBlocks.size(); a++)
   {
      delete [] mFreeWrapPoolBlocks[a];
   }

   mDecalQueue.clear();
   mWrapDecalQueue.clear();
}
//********************************************************************************************
//Wrapping Decals
//********************************************************************************************

DecalInstance* DecalManager::allocateDecalInstance()
{
   if (mFreePool == NULL)
   {
      // Allocate a new block of decals
      mFreePoolBlocks.push_back(new DecalInstance[csmFreePoolBlockSize]);

      // Init them onto the free pool chain
      DecalInstance* pNewInstances = mFreePoolBlocks.last();
      for (U32 i = 0; i < csmFreePoolBlockSize - 1; i++)
         pNewInstances[i].next = &pNewInstances[i + 1];
      pNewInstances[csmFreePoolBlockSize - 1].next = NULL;
      mFreePool = pNewInstances;
   }
   AssertFatal(mFreePool != NULL, "Error, should always have a free pool available here!");

   DecalInstance* pRet = mFreePool;
   mFreePool = pRet->next;
   pRet->next = NULL;
   return pRet;
}

void DecalManager::freeDecalInstance(DecalInstance* trash)
{
   AssertFatal(trash != NULL, "Error, no trash pointer to free!");

   trash->next = mFreePool;
   mFreePool = trash;
}


void DecalManager::dataDeleted(DecalData *data)
{
   for(S32 i = mDecalQueue.size() - 1; i >= 0; i--)
   {
      DecalInstance *inst = mDecalQueue[i];
      if(inst->decalData == data)
      {
         freeDecalInstance(inst);
         mDecalQueue.erase(U32(i));
      }
   }
}

void DecalManager::consoleInit()
{
   Con::addVariable("$pref::decalsOn",     TypeBool, &smDecalsOn);
   Con::addVariable("$pref::Decal::maxNumDecals", TypeS32, &smMaxNumDecals);
   Con::addVariable("$pref::Decal::decalTimeout", TypeS32, &smDecalTimeout);
}

void DecalManager::addDecal(const Point3F& pos,
                            Point3F normal,
                            DecalData* decalData)
{
   if (smMaxNumDecals == 0)
      return;

   // DMM: Rework this, should be based on time
   if(mDecalQueue.size() >= smMaxNumDecals)
   {
      findSpace();
   }

   Point3F vecX, vecY;
   DecalInstance* newDecal = allocateDecalInstance();
   newDecal->decalData = decalData;
   newDecal->allocTime = Platform::getVirtualMilliseconds();

   if(mFabs(normal.z) > 0.9f)
      mCross(normal, Point3F(0.0f, 1.0f, 0.0f), &vecX);
   else
      mCross(normal, Point3F(0.0f, 0.0f, 1.0f), &vecX);

   mCross(vecX, normal, &vecY);

   normal.normalizeSafe();
   Point3F position = Point3F(pos.x + (normal.x * 0.008), pos.y + (normal.y * 0.008), pos.z + (normal.z * 0.008));

   vecX.normalizeSafe();
   vecY.normalizeSafe();

   vecX *= decalData->sizeX;
   vecY *= decalData->sizeY;

   newDecal->point[0] = position + vecX + vecY;
   newDecal->point[1] = position + vecX - vecY;
   newDecal->point[2] = position - vecX - vecY;
   newDecal->point[3] = position - vecX + vecY;

   mDecalQueue.push_back(newDecal);
   mQueueDirty = true;
}

void DecalManager::addDecal(const Point3F& pos,
                            const Point3F& rot,
                            Point3F normal,
                            DecalData* decalData)
{
   if (smMaxNumDecals == 0)
      return;

   addDecal( pos, rot, normal, Point3F( 1, 1, 1 ), decalData );
}

void DecalManager::addDecal(const Point3F& pos,
                            const Point3F& rot,
                            Point3F normal,
                            const Point3F& scale,
                            DecalData* decalData)
{
   if (smMaxNumDecals == 0)
      return;

   if(mDot(rot, normal) < 0.98)
   {
      // DMM: Rework this, should be based on time
      if(mDecalQueue.size() >= smMaxNumDecals)
      {
         findSpace();
      }

      Point3F vecX, vecY;
      DecalInstance* newDecal = allocateDecalInstance();
      newDecal->decalData = decalData;
      newDecal->allocTime = Platform::getVirtualMilliseconds();

      mCross(rot, normal, &vecX);
      mCross(normal, vecX, &vecY);

      normal.normalize();
      Point3F position = Point3F(pos.x + (normal.x * 0.008), pos.y + (normal.y * 0.008), pos.z + (normal.z * 0.008));

      vecX.normalize();
      vecX.convolve( scale );
      vecY.normalize();
      vecY.convolve( scale );

      vecX *= decalData->sizeX;
      vecY *= decalData->sizeY;

      newDecal->point[0] = position + vecX + vecY;
      newDecal->point[1] = position + vecX - vecY;
      newDecal->point[2] = position - vecX - vecY;
      newDecal->point[3] = position - vecX + vecY;

      mDecalQueue.push_back(newDecal);
      mQueueDirty = true;
   }
}

bool DecalManager::prepRenderImage(SceneState* state, const U32 stateKey,
                                   const U32 /*startZone*/, const bool /*modifyBaseState*/)
{
   if (!smDecalsOn) return false;

   if (isLastState(state, stateKey))
      return false;
   setLastState(state, stateKey);

   if (mDecalQueue.size() == 0 && mWrapDecalQueue.size() == 0) //Wrapping Decals
      return false;

   // This should be sufficient for most objects that don't manage zones, and
   //  don't need to return a specialized RenderImage...
   SceneRenderImage* image = new SceneRenderImage;
   image->obj = this;
   image->isTranslucent = true;
   image->sortType      = SceneRenderImage::BeginSort;
   state->insertRenderImage(image);

   U32 currMs = Platform::getVirtualMilliseconds();
   for (S32 i = mDecalQueue.size() - 1; i >= 0; i--)
   {
      U32 age = currMs - mDecalQueue[i]->allocTime;
	  U32 timeout = mDecalQueue[i]->decalData->lifeSpan;
      if (age > timeout)
      {
         freeDecalInstance(mDecalQueue[i]);
         mDecalQueue.erase(i);
      }
      else if (age > ((3 * timeout) / 4))
      {
         mDecalQueue[i]->fade = 1.0f - (F32(age - ((3 * timeout) / 4)) / F32(timeout / 4));
      }
      else
      {
         mDecalQueue[i]->fade = 1.0f;
      }
   }
//********************************************************************************************
//Wrapping Decals
//********************************************************************************************
   for (S32 i = mWrapDecalQueue.size() - 1; i >= 0; i--)
   {
      U32 ageWrap = currMs - mWrapDecalQueue[i]->allocTime;
	  U32 timeoutWrap = mWrapDecalQueue[i]->decalData->lifeSpan;
      if (ageWrap > timeoutWrap)
      {
         freeWrapDecalInstance(mWrapDecalQueue[i]);
         mWrapDecalQueue.erase(i);
      }
      else if (ageWrap > ((3 * timeoutWrap) / 4))
      {
         mWrapDecalQueue[i]->fade = 1.0f - (F32(ageWrap - ((3 * timeoutWrap) / 4)) / F32(timeoutWrap / 4));
      }
      else
      {
         mWrapDecalQueue[i]->fade = 1.0f;
      }
   }
//********************************************************************************************
//Wrapping Decals
//********************************************************************************************
   if (mQueueDirty == true)
   {
      // Sort the decals based on the data pointers...
      dQsort(mDecalQueue.address(),
             mDecalQueue.size(),
             sizeof(DecalInstance*),
             cmpDecalInstance);
      mQueueDirty = false;
   }
//********************************************************************************************
//Wrapping Decals
//********************************************************************************************
   if (mWrapQueueDirty == true)
   {
      // Sort the decals based on the data pointers...
      dQsort(mWrapDecalQueue.address(),
             mWrapDecalQueue.size(),
             sizeof(DecalInstance*),
             cmpDecalInstance);
      mWrapQueueDirty = false;
   }
//********************************************************************************************
//Wrapping Decals
//********************************************************************************************

   return false;
}

void DecalManager::renderObject(SceneState* state, SceneRenderImage*)
{
   if (!smDecalsOn) return;

   AssertFatal(dglIsInCanonicalState(), "Error, GL not in canonical state on entry");

   RectI viewport;
   glMatrixMode(GL_PROJECTION);
   glPushMatrix();
   dglGetViewport(&viewport);

   state->setupBaseProjection();

   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();

   renderDecal();
//********************************************************************************************
//Wrapping Decals
//********************************************************************************************
   renderWrapDecal();
//********************************************************************************************
//Wrapping Decals
//********************************************************************************************
   glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

   glMatrixMode(GL_MODELVIEW);
   glPopMatrix();

   glMatrixMode(GL_PROJECTION);
   glPopMatrix();
   glMatrixMode(GL_MODELVIEW);
   dglSetViewport(viewport);

   AssertFatal(dglIsInCanonicalState(), "Error, GL not in canonical state on exit");
}

void DecalManager::renderDecal()
{
   glEnable(GL_TEXTURE_2D);
   glEnable(GL_BLEND);
   glEnable(GL_ALPHA_TEST);
   glDepthMask(GL_FALSE);
   glAlphaFunc(GL_GREATER, 0.1f);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
   glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

   sgThisIsSelfIlluminated = false;
   sgLastWasSelfIlluminated = false;
   glEnable(GL_POLYGON_OFFSET_FILL);
   glPolygonOffset(-1,-1);
   glDepthMask(GL_FALSE);
	
   DecalData* pLastData = NULL;
   for (S32 x = 0; x < mDecalQueue.size(); x++)
   {
      if (mDecalQueue[x]->decalData != pLastData)
      {
         glBindTexture(GL_TEXTURE_2D, mDecalQueue[x]->decalData->textureHandle.getGLName());
         pLastData = mDecalQueue[x]->decalData;
      }

	  sgThisIsSelfIlluminated = mDecalQueue[x]->decalData->selfIlluminated;
	  if(sgThisIsSelfIlluminated != sgLastWasSelfIlluminated)
	  {
		  if(sgThisIsSelfIlluminated)
			  glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		  else
			  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		  sgLastWasSelfIlluminated = sgThisIsSelfIlluminated;
	  }
      if(mDecalQueue[x]->dynamic == true)
	  {
		  glPushMatrix();
		  dglMultMatrix(&mDecalQueue[x]->decObject->getRenderTransform());
		  
		  glColor4f(1, 1, 1, mDecalQueue[x]->fade);
		  glBegin(GL_TRIANGLE_FAN);
		  {
			  glTexCoord2f(0, 0); glVertex3fv(mDecalQueue[x]->point[3]);
			  glTexCoord2f(0, 1); glVertex3fv(mDecalQueue[x]->point[2]);
			  glTexCoord2f(1, 1); glVertex3fv(mDecalQueue[x]->point[1]);
			  glTexCoord2f(1, 0); glVertex3fv(mDecalQueue[x]->point[0]);
		  }
		  glEnd();
		  
		  glPopMatrix();
	  }
	  else
	  {
		  glColor4f(1, 1, 1, mDecalQueue[x]->fade);
		  glBegin(GL_TRIANGLE_FAN);
		  {
			  glTexCoord2f(0, 0); glVertex3fv(mDecalQueue[x]->point[3]);
			  glTexCoord2f(0, 1); glVertex3fv(mDecalQueue[x]->point[2]);
			  glTexCoord2f(1, 1); glVertex3fv(mDecalQueue[x]->point[1]);
			  glTexCoord2f(1, 0); glVertex3fv(mDecalQueue[x]->point[0]);
		  }
		  glEnd();
	  }

   }

   glDisable(GL_POLYGON_OFFSET_FILL);
   glDepthMask(GL_TRUE);

   glDepthMask(GL_TRUE);
   glDisable(GL_BLEND);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_ALPHA_TEST);
}

void DecalManager::findSpace()
{
	S32 besttime = S32_MAX;
	U32 bestindex = 0;
	DecalInstance *bestdecal = NULL;

	U32 time = Platform::getVirtualMilliseconds();

	for(U32 i=0; i<mDecalQueue.size(); i++)
	{
		DecalInstance *inst = mDecalQueue[i];
		U32 age = time - inst->allocTime;
		U32 timeleft = inst->decalData->lifeSpan - age;
		if(besttime > timeleft)
		{
			besttime = timeleft;
			bestindex = i;
			bestdecal = inst;
		}
	}

	AssertFatal((bestdecal), "No good decals?");

	mDecalQueue.erase_fast(bestindex);
	freeDecalInstance(bestdecal);
}

void DecalManager::addDecal(const Point3F& pos, const Point3F& rot, Point3F normal,
							  const Point3F& scale, DecalData *decaldata, U32 ownerid)
{
	if(smMaxNumDecals == 0)
		return;

	if(mDot(rot, normal) < 0.98)
	{
		if(mDecalQueue.size() >= smMaxNumDecals)
			findSpace();

		Point3F vecX, vecY;
		DecalInstance* newDecal = allocateDecalInstance();
		newDecal->decalData = decaldata;
		newDecal->allocTime = Platform::getVirtualMilliseconds();
		newDecal->ownerId = ownerid;

		mCross(rot, normal, &vecX);
		mCross(normal, vecX, &vecY);

		normal.normalize();
		Point3F position = Point3F(pos.x + (normal.x * 0.008), pos.y + (normal.y * 0.008), pos.z + (normal.z * 0.008));

		vecX.normalize();
		vecX.convolve( scale );
		vecY.normalize();
		vecY.convolve( scale );

		vecX *= decaldata->sizeX;
		vecY *= decaldata->sizeY;

		newDecal->point[0] = position + vecX + vecY;
		newDecal->point[1] = position + vecX - vecY;
		newDecal->point[2] = position - vecX - vecY;
		newDecal->point[3] = position - vecX + vecY;

		mDecalQueue.push_back(newDecal);
		mQueueDirty = true;
	}
}

void DecalManager::ageDecal(U32 ownerid)
{
	for(U32 i=0; i<mDecalQueue.size(); i++)
	{
		DecalInstance *inst = mDecalQueue[i];
		if(inst->ownerId == ownerid)
		{
			freeDecalInstance(inst);
			mDecalQueue.erase(U32(i));
		}
	}
}

//********************************************************************************************
//Clear Decals in an area
//********************************************************************************************
void DecalManager::clearDecalsInArea(Point3F pos, F32 half_X, F32 half_Y, F32 half_Z)
{
	Point3F pOne;
	Point3F pTwo;
	Point3F pThree;
	Point3F pFour;

	F32 XMin = pos.x - half_X;
	F32 XMax = pos.x + half_X;

	F32 YMin = pos.y - half_Y;
	F32 YMax = pos.y + half_Y;

	F32 ZMin = pos.z - half_Z;
	F32 ZMax = pos.z + half_Z;

	for(U32 i=0; i<mDecalQueue.size(); i++)
	{
		DecalInstance *inst = mDecalQueue[i];

		bool flag = false;


		pOne = inst->point[0];
		pTwo = inst->point[1];
		pThree = inst->point[2];
		pFour = inst->point[3];

		if((pOne.x >= XMin) && (pOne.x <= XMax) && (pOne.y >= YMin) && (pOne.y <= YMax) && (pOne.z >= ZMin) && (pOne.z <= ZMax))
			flag = true;

		if((pTwo.x >= XMin) && (pTwo.x <= XMax) && (pTwo.y >= YMin) && (pTwo.y <= YMax) && (pTwo.z >= ZMin) && (pTwo.z <= ZMax))
			flag = true;

		if((pThree.x >= XMin) && (pThree.x <= XMax) && (pThree.y >= YMin) && (pThree.y <= YMax) && (pThree.z >= ZMin) && (pThree.z <= ZMax))
			flag = true;

		if((pFour.x >= XMin) && (pFour.x <= XMax) && (pFour.y >= YMin) && (pFour.y <= YMax) && (pFour.z >= ZMin) && (pFour.z <= ZMax))
			flag = true;

		if(flag)
		{
			//Con::errorf(ConsoleLogEntry::General, "Decal Detected");
			freeDecalInstance(inst);
			mDecalQueue.erase_fast(i);

			mQueueDirty = true;

			if (mQueueDirty == true)
			{
				// Sort the decals based on the data pointers...
				dQsort(mDecalQueue.address(),
					mDecalQueue.size(),
					sizeof(DecalInstance*),
					cmpDecalInstance);
				mQueueDirty = false;
			}
		}
		
	}
}
//********************************************************************************************
//Clear Decals in an area
//********************************************************************************************

//********************************************************************************************
//Skid mark decals
//********************************************************************************************
void DecalManager::addSkidDecal(const Point3F& pos,
                            const Point3F& rot,
                            Point3F normal,
							const Point3F& oldPos,
							const Point3F& oldRot,
							Point3F oldNormal,
                            const Point3F& scale,
                            DecalData* decalData)
{
   if (smMaxNumDecals == 0)
      return;

   if(mDot(rot, normal) < 0.98f)
   {
      // DMM: Rework this, should be based on time
      if(mDecalQueue.size() >= smMaxNumDecals)
      {
         findSpace();
      }

      Point3F vecX, vecY;

      DecalInstance* newDecal = allocateDecalInstance();
      newDecal->decalData = decalData;
      newDecal->allocTime = Platform::getVirtualMilliseconds();

      mCross(rot, normal, &vecX);
      mCross(normal, vecX, &vecY);

      normal.normalize();
      Point3F position = Point3F(pos.x + (normal.x * 0.008f), pos.y + (normal.y * 0.008f), pos.z + (normal.z * 0.008f));

      vecX.normalize();
      vecX.convolve( scale );
      vecY.normalize();
      vecY.convolve( scale );

      vecX *= decalData->sizeX;
      vecY *= decalData->sizeY;

	  //Skid Decal old position calculations
	  Point3F oldVecX, oldVecY;

	  mCross(oldRot, oldNormal, &oldVecX);
      mCross(oldNormal, oldVecX, &oldVecY);

      oldNormal.normalize();
      Point3F oldPosition = Point3F(oldPos.x + (oldNormal.x * 0.008f), oldPos.y + (oldNormal.y * 0.008f), oldPos.z + (oldNormal.z * 0.008f));

      oldVecX.normalize();
      oldVecX.convolve( scale );
      oldVecY.normalize();
      oldVecY.convolve( scale );

      oldVecX *= decalData->sizeX;
      oldVecY *= decalData->sizeY;


	  //Determine if there was a previous decal to determine decal vertice points
	  if(oldPosition.x == 0 && oldPosition.y == 0 && oldPosition.x == 0)
	  {
		  newDecal->point[0] = position + vecX + vecY;
		  newDecal->point[1] = position + vecX - vecY;
		  newDecal->point[2] = position - vecX - vecY;
		  newDecal->point[3] = position - vecX + vecY;
	  }
	  else
	  {
		  newDecal->point[0] = oldPosition + oldVecX - oldVecY; //1,0
		  newDecal->point[1] = position + vecX - vecY; //1,1
		  newDecal->point[2] = position - vecX - vecY; //0,1
		  newDecal->point[3] = oldPosition - oldVecX - oldVecY; //0,0
	  }

      mDecalQueue.push_back(newDecal);
      mQueueDirty = true;
   }
}
//********************************************************************************************
//Skid mark decals
//********************************************************************************************

//********************************************************************************************
//Object transform decals
//********************************************************************************************
void DecalManager::addObjectDecal(const Point3F& pos,
                            Point3F normal,
                            DecalData* decalData, SceneObject * decObj)
{
   if (smMaxNumDecals == 0)
      return;

   // DMM: Rework this, should be based on time
   if(mDecalQueue.size() >= smMaxNumDecals)
   {
      findSpace();
   }

   Point3F vecX, vecY;
   DecalInstance* newDecal = allocateDecalInstance();
   newDecal->decalData = decalData;
   newDecal->allocTime = Platform::getVirtualMilliseconds();

   newDecal->dynamic = true;
   newDecal->decObject = decObj;
   MatrixF worldMat = decObj->getWorldTransform();
   Point3F tPos = pos;
   worldMat.mulP(tPos);
   worldMat.mulV(normal);


   if(mFabs(normal.z) > 0.9f)
      mCross(normal, Point3F(0.0f, 1.0f, 0.0f), &vecX);
   else
      mCross(normal, Point3F(0.0f, 0.0f, 1.0f), &vecX);

   mCross(vecX, normal, &vecY);

   normal.normalizeSafe();
   Point3F position = Point3F(tPos.x + (normal.x * 0.008), tPos.y + (normal.y * 0.008), tPos.z + (normal.z * 0.008));

   vecX.normalizeSafe();
   vecY.normalizeSafe();

   vecX *= decalData->sizeX;
   vecY *= decalData->sizeY;

   newDecal->point[0] = position + vecX + vecY;
   newDecal->point[1] = position + vecX - vecY;
   newDecal->point[2] = position - vecX - vecY;
   newDecal->point[3] = position - vecX + vecY;

   mDecalQueue.push_back(newDecal);
   mQueueDirty = true;
}
//********************************************************************************************
//Object transform decals
//********************************************************************************************

//********************************************************************************************
//Wrapping Decals
//********************************************************************************************
DecalInstance* DecalManager::allocateWrapDecalInstance()
{
   if (mFreeWrapPool == NULL)
   {
      // Allocate a new block of decals
      mFreeWrapPoolBlocks.push_back(new DecalInstance[csmFreeWrapPoolBlockSize]);

      // Init them onto the free pool chain
      DecalInstance* pNewInstances = mFreeWrapPoolBlocks.last();
      for (U32 i = 0; i < csmFreeWrapPoolBlockSize - 1; i++)
         pNewInstances[i].next = &pNewInstances[i + 1];
      pNewInstances[csmFreeWrapPoolBlockSize - 1].next = NULL;
      mFreeWrapPool = pNewInstances;
   }
   AssertFatal(mFreeWrapPool != NULL, "Error, should always have a free wrap pool available here!");

   DecalInstance* pRet = mFreeWrapPool;
   mFreeWrapPool = pRet->next;
   pRet->next = NULL;
   return pRet;
}

void DecalManager::freeWrapDecalInstance(DecalInstance* trash)
{
   AssertFatal(trash != NULL, "Error, no trash pointer to free!");

   trash->next = mFreeWrapPool;
   mFreeWrapPool = trash;
   //trash->exData->mPartition.clear();
}

void DecalManager::wrapDataDeleted(DecalData *data)
{
   for(S32 i = mWrapDecalQueue.size() - 1; i >= 0; i--)
   {
      DecalInstance *inst = mWrapDecalQueue[i];
      if(inst->decalData == data)
      {
         freeWrapDecalInstance(inst);
         mWrapDecalQueue.erase(U32(i));
      }
   }
}

void DecalManager::collisionCallback(SceneObject * obj, void* thisPtr)
{
   if (obj->getWorldBox().isOverlapped(gDecalBox))
      obj->buildPolyList(&smDepthSortList,gDecalBox,gDecalSphere);
}

void DecalManager::renderWrapDecal()
{
   glEnable(GL_TEXTURE_2D);
   glEnable(GL_BLEND);
   glEnable(GL_ALPHA_TEST);
   glDepthMask(GL_FALSE);
   glAlphaFunc(GL_GREATER, 0.1f);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
   glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

   sgThisIsSelfIlluminated = false;
   sgLastWasSelfIlluminated = false;
   glEnable(GL_POLYGON_OFFSET_FILL);
   glPolygonOffset(-1,-1);
   glDepthMask(GL_FALSE);
	
   DecalData* pLastData = NULL;
   for(S32 x=0; x<mWrapDecalQueue.size(); x++)
   {
      if(mWrapDecalQueue[x]->decalData != pLastData)
      {
         glBindTexture(GL_TEXTURE_2D, mWrapDecalQueue[x]->decalData->textureHandle.getGLName());
         pLastData = mWrapDecalQueue[x]->decalData;
      }

	  sgThisIsSelfIlluminated = mWrapDecalQueue[x]->decalData->selfIlluminated;
	  if(sgThisIsSelfIlluminated != sgLastWasSelfIlluminated)
	  {
		  if(sgThisIsSelfIlluminated)
			  glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		  else
			  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		  sgLastWasSelfIlluminated = sgThisIsSelfIlluminated;
	  }
      if (mWrapDecalQueue[x]->exData)
      {
		  if(mWrapDecalQueue[x]->dynamic == true)
		  {
			  DecalExData *exData=mWrapDecalQueue[x]->exData;
			  
			  glPushMatrix();
			  dglMultMatrix(&mWrapDecalQueue[x]->decObject->getRenderTransform());
			  
			  glEnableClientState(GL_VERTEX_ARRAY);
			  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
			  glVertexPointer(3,GL_FLOAT,0,exData->mPartitionVerts.address());
			  glTexCoordPointer(2,GL_FLOAT,0,exData->mPartitionTVerts.address());
			  bool lockArrays = dglDoesSupportCompiledVertexArray();
			  if (lockArrays)
				  glLockArraysEXT(0,exData->mPartitionVerts.size());
			  
			  glColor4f(1, 1, 1, mWrapDecalQueue[x]->fade);
			  
			  for (S32 i=0; i<exData->mPartition.size(); i++)
				  glDrawArrays(GL_POLYGON,exData->mPartition[i].vertexStart,exData->mPartition[i].vertexCount);
			  
			  if (lockArrays)
				  glUnlockArraysEXT();
			  
			  glDisableClientState(GL_VERTEX_ARRAY);
			  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
			  
			  glPopMatrix();
		  }
		  else
		  {
			  DecalExData *exData=mWrapDecalQueue[x]->exData;
			  
			  glPushMatrix();
			  dglMultMatrix(&exData->mTransform);
			  
			  glEnableClientState(GL_VERTEX_ARRAY);
			  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
			  glVertexPointer(3,GL_FLOAT,0,exData->mPartitionVerts.address());
			  glTexCoordPointer(2,GL_FLOAT,0,exData->mPartitionTVerts.address());
			  bool lockArrays = dglDoesSupportCompiledVertexArray();
			  if (lockArrays)
				  glLockArraysEXT(0,exData->mPartitionVerts.size());
			  
			  glColor4f(1, 1, 1, mWrapDecalQueue[x]->fade);
			  
			  for (S32 i=0; i<exData->mPartition.size(); i++)
				  glDrawArrays(GL_POLYGON,exData->mPartition[i].vertexStart,exData->mPartition[i].vertexCount);
			  
			  if (lockArrays)
				  glUnlockArraysEXT();
			  
			  glDisableClientState(GL_VERTEX_ARRAY);
			  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
			  
			  glPopMatrix();
		  }
      }
   }

   glDisable(GL_POLYGON_OFFSET_FILL);
   glDepthMask(GL_TRUE);

   glDepthMask(GL_TRUE);
   glDisable(GL_BLEND);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_ALPHA_TEST);
}

void DecalManager::findWrapSpace()
{
   S32 besttime = S32_MAX;
   U32 bestindex = 0;
   DecalInstance *bestdecal = NULL;

   U32 time = Platform::getVirtualMilliseconds();

   for(U32 i=0; i<mWrapDecalQueue.size(); i++)
   {
      DecalInstance *inst = mWrapDecalQueue[i];
      U32 age = time - inst->allocTime;
      U32 timeleft = inst->decalData->lifeSpan - age;
      if(besttime > timeleft)
      {
         besttime = timeleft;
         bestindex = i;
         bestdecal = inst;
      }
   }

   AssertFatal((bestdecal), "No good wrap decals?");

   mWrapDecalQueue.erase_fast(bestindex);
   freeWrapDecalInstance(bestdecal);
}

void DecalManager::ageWrapDecal(U32 ownerid)
{
	for(U32 i=0; i<mWrapDecalQueue.size(); i++)
	{
		DecalInstance *inst = mWrapDecalQueue[i];
		if(inst->ownerId == ownerid)
		{
			freeWrapDecalInstance(inst);
			mWrapDecalQueue.erase(U32(i));
		}
	}
}

void DecalManager::addObjectWrapDecal(const Point3F& pos,
                            Point3F normal,
                            Point3F impactNormal,
                            DecalData *decalData, SceneObject * decObj)
{
   if (smMaxNumDecals == 0)
      return;

   if(mWrapDecalQueue.size() >= smMaxNumDecals)
   {
      findWrapSpace();
   }
   DecalInstance* newDecal = allocateWrapDecalInstance();
   newDecal->decalData = decalData;
   newDecal->allocTime = Platform::getVirtualMilliseconds();

   newDecal->dynamic = true;
   newDecal->decObject = decObj;
   MatrixF worldMat = decObj->getWorldTransform();
   Point3F tPos = pos;
   worldMat.mulP(tPos);
   worldMat.mulV(normal);
   worldMat.mulV(impactNormal);

   DecalExData *exData=new DecalExData;
   newDecal->exData=exData;

   // construct matrix
   Point3F x,y,z;
   y = impactNormal;
   if (mFabs(y.z)>0.001f)
   {
      //mCross(y,Point3F(1,0,0),&z);
      z.set(0,y.z,-y.x);
      z.normalizeSafe();
      mCross(y,z,&x);
      x.normalizeSafe();
   }
   else
   {
      //mCross(y,Point3F(0,0,1),&x);
      x.set(y.y,-y.x,0);
      x.normalizeSafe();
      mCross(x,y,&z);
      z.normalizeSafe();
   }

   F32 ySkew = mFabs(mDot(impactNormal,normal));
   F32 xFactor, yFactor;
   if (ySkew>0)
   {
      xFactor=2*ySkew;
      yFactor=2/ySkew;
   }
   else
   {
      xFactor=2;
      yFactor=2;
   }

   // backup a bit (for the transforms) so that we can see the polys
   Point3F position = Point3F(tPos.x + (-impactNormal.x * decalData->sizeX*2), 
                              tPos.y + (-impactNormal.y * decalData->sizeY*2), 
                              tPos.z + (-impactNormal.z * decalData->sizeX*2));

   MatrixF decalToWorld(true);
   decalToWorld.setColumn(0,x);
   decalToWorld.setColumn(1,y);
   decalToWorld.setColumn(2,z);
   decalToWorld.setColumn(3,position);

   exData->mTransform = decalToWorld;

   MatrixF worldToDecal = decalToWorld;
   worldToDecal.inverse();

   // setup depth sort list
   // expanded allow the image to stretch
   Point3F extent(decalData->sizeX*5,decalData->sizeY*5,decalData->sizeX*5);
   smDepthSortList.clear();
   smDepthSortList.set(worldToDecal,extent);
   smDepthSortList.setInterestNormal(impactNormal);

   // build world space box and sphere around decal
   x *= decalData->sizeX*2;
   y *= decalData->sizeY*2;
   z *= decalData->sizeX*2;
   gDecalBox.max.set(mFabs(x.x)+mFabs(y.x)+mFabs(z.x),
                     mFabs(x.y)+mFabs(y.y)+mFabs(z.y),
                     mFabs(x.z)+mFabs(y.z)+mFabs(z.z));
   gDecalSphere.radius = gDecalBox.max.len();
   gDecalSphere.center = pos;
   gDecalBox.min  = pos - gDecalBox.max;
   gDecalBox.max += pos;

   // get polys
   gClientContainer.findObjects(smDecalMask,DecalManager::collisionCallback,this);

   // setup partition list
   gDecalPoly[0].set(-decalData->sizeX,0,-decalData->sizeY);
   gDecalPoly[1].set(-decalData->sizeX,0,decalData->sizeY);
   gDecalPoly[2].set(decalData->sizeX,0,decalData->sizeY);
   gDecalPoly[3].set(decalData->sizeX,0,-decalData->sizeY);

   exData->mPartition.clear();
   exData->mPartitionVerts.clear();
   smDepthSortList.depthPartition(gDecalPoly,4,exData->mPartition,exData->mPartitionVerts);

   if (exData->mPartitionVerts.size()>0)
   {
      // now set up tverts
      exData->mPartitionTVerts.setSize(exData->mPartitionVerts.size());
      if (exData->mPartitionVerts.size()==4)
      {
         exData->mPartitionTVerts[0].set(0,1);
         exData->mPartitionTVerts[1].set(1,1);
         exData->mPartitionTVerts[2].set(1,0);
         exData->mPartitionTVerts[3].set(0,0);
      }
      else
      {
         F32 invSizeX = 1.0f / (decalData->sizeX);
         F32 invSizeY = 1.0f / (decalData->sizeY);
         for (S32 i=0; i<exData->mPartitionVerts.size(); i++)
            exData->mPartitionTVerts[i].set(0.5f + 0.5f * exData->mPartitionVerts[i].x * invSizeX,
                                            0.5f + 0.5f * exData->mPartitionVerts[i].z * invSizeY);
      }
   }
   else
   {
      delete exData;
      newDecal->exData=NULL;
      // do it the old fashioned way
      Point3F vecX, vecY;
      if(mFabs(normal.z) > 0.9f)
         mCross(normal, Point3F(0.0f, 1.0f, 0.0f), &vecX);
      else
         mCross(normal, Point3F(0.0f, 0.0f, 1.0f), &vecX);
      mCross(vecX, normal, &vecY);

      normal.normalizeSafe();

      Point3F position = Point3F(pos.x + (normal.x * 0.008), pos.y + (normal.y * 0.008), pos.z + (normal.z * 0.008));

      vecX.normalizeSafe();
      vecY.normalizeSafe();

      vecX *= decalData->sizeX;
      vecY *= decalData->sizeY;

      newDecal->point[0] = position + vecX + vecY;
      newDecal->point[1] = position + vecX - vecY;
      newDecal->point[2] = position - vecX - vecY;
      newDecal->point[3] = position - vecX + vecY;
   }

   // finish
   mWrapDecalQueue.push_back(newDecal);
   mWrapQueueDirty = true;
}

void DecalManager::addWrapDecal(const Point3F& pos,
                            Point3F normal,
                            Point3F impactNormal,
                            DecalData *decalData)
{
   if (smMaxNumDecals == 0)
      return;

   if(mWrapDecalQueue.size() >= smMaxNumDecals)
   {
      findWrapSpace();
   }

   Point3F vecX, vecY;
   DecalInstance* newDecal = allocateWrapDecalInstance();
   newDecal->decalData = decalData;
   newDecal->allocTime = Platform::getVirtualMilliseconds();

   DecalExData *exData = new DecalExData;
   newDecal->exData=exData;

   // construct matrix
   Point3F x,y,z;
   y = impactNormal;
   if (mFabs(y.z)>0.001f)
   {
      //mCross(y,Point3F(1,0,0),&z);
      z.set(0,y.z,-y.x);
      z.normalizeSafe();
      mCross(y,z,&x);
      x.normalizeSafe();
   }
   else
   {
      //mCross(y,Point3F(0,0,1),&x);
      x.set(y.y,-y.x,0);
      x.normalizeSafe();
      mCross(x,y,&z);
      z.normalizeSafe();
   }

   F32 ySkew = mFabs(mDot(impactNormal,normal));
   F32 xFactor, yFactor;
   if (ySkew>0)
   {
      xFactor=2*ySkew;
      yFactor=2/ySkew;
   }
   else
   {
      xFactor=2;
      yFactor=2;
   }

   // backup a bit (for the transforms) so that we can see the polys
   Point3F position = Point3F(pos.x + (-impactNormal.x * decalData->sizeX*2), 
                              pos.y + (-impactNormal.y * decalData->sizeY*2), 
                              pos.z + (-impactNormal.z * decalData->sizeX*2));

   MatrixF decalToWorld(true);
   decalToWorld.setColumn(0,x);
   decalToWorld.setColumn(1,y);
   decalToWorld.setColumn(2,z);
   decalToWorld.setColumn(3,position);

   exData->mTransform = decalToWorld;

   MatrixF worldToDecal = decalToWorld;
   worldToDecal.inverse();

   // setup depth sort list
   // expanded allow the image to stretch
   Point3F extent(decalData->sizeX*5,decalData->sizeY*5,decalData->sizeX*5);
   smDepthSortList.clear();
   smDepthSortList.set(worldToDecal,extent);
   smDepthSortList.setInterestNormal(impactNormal);

   // build world space box and sphere around decal
   x *= decalData->sizeX*2;
   y *= decalData->sizeY*2;
   z *= decalData->sizeX*2;
   gDecalBox.max.set(mFabs(x.x)+mFabs(y.x)+mFabs(z.x),
                     mFabs(x.y)+mFabs(y.y)+mFabs(z.y),
                     mFabs(x.z)+mFabs(y.z)+mFabs(z.z));
   gDecalSphere.radius = gDecalBox.max.len();
   gDecalSphere.center = pos;
   gDecalBox.min  = pos - gDecalBox.max;
   gDecalBox.max += pos;

   // get polys
   gClientContainer.findObjects(smDecalMask,DecalManager::collisionCallback,this);

   // setup partition list
   gDecalPoly[0].set(-decalData->sizeX,0,-decalData->sizeY);
   gDecalPoly[1].set(-decalData->sizeX,0,decalData->sizeY);
   gDecalPoly[2].set(decalData->sizeX,0,decalData->sizeY);
   gDecalPoly[3].set(decalData->sizeX,0,-decalData->sizeY);

   exData->mPartition.clear();
   exData->mPartitionVerts.clear();
   smDepthSortList.depthPartition(gDecalPoly,4,exData->mPartition,exData->mPartitionVerts);

   if (exData->mPartitionVerts.size()>0)
   {
      // now set up tverts
      exData->mPartitionTVerts.setSize(exData->mPartitionVerts.size());
      if (exData->mPartitionVerts.size()==4)
      {
         exData->mPartitionTVerts[0].set(0,1);
         exData->mPartitionTVerts[1].set(1,1);
         exData->mPartitionTVerts[2].set(1,0);
         exData->mPartitionTVerts[3].set(0,0);
      }
      else
      {
         F32 invSizeX = 1.0f / (decalData->sizeX);
         F32 invSizeY = 1.0f / (decalData->sizeY);
         for (S32 i=0; i<exData->mPartitionVerts.size(); i++)
            exData->mPartitionTVerts[i].set(0.5f + 0.5f * exData->mPartitionVerts[i].x * invSizeX,
                                            0.5f + 0.5f * exData->mPartitionVerts[i].z * invSizeY);
      }
   }
   else
   {
      delete exData;
      newDecal->exData=NULL;
      // do it the old fashioned way
      if(mFabs(normal.z) > 0.9f)
         mCross(normal, Point3F(0.0f, 1.0f, 0.0f), &vecX);
      else
         mCross(normal, Point3F(0.0f, 0.0f, 1.0f), &vecX);

      mCross(vecX, normal, &vecY);

      normal.normalizeSafe();

      Point3F position = Point3F(pos.x + (normal.x * 0.008), pos.y + (normal.y * 0.008), pos.z + (normal.z * 0.008));

      vecX.normalizeSafe();
      vecY.normalizeSafe();

      vecX *= decalData->sizeX;
      vecY *= decalData->sizeY;

      newDecal->point[0] = position + vecX + vecY;
      newDecal->point[1] = position + vecX - vecY;
      newDecal->point[2] = position - vecX - vecY;
      newDecal->point[3] = position - vecX + vecY;
   }

   mWrapDecalQueue.push_back(newDecal);
   mWrapQueueDirty = true;
}
//********************************************************************************************
//Wrapping Decals
//********************************************************************************************

