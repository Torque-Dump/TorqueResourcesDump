(original thread: http://www.torquepowered.com/community/forums/viewthread/98745/)
INSTALLATION:
Copy "core" and "shaders" to your game/ directory,
Optional: Copy "T3D" to engine/sources and replace precipitation.cpp

INFO:
When copying "core" and "shaders" to your game, you will be able to go
in-game and type "WetnessPostFX.enable" in the console to activate the effect.

Inside "core" you will have:
	wetness.cs; Contains all the PostFX definitions.
	wetMap.png; The normal map that is added as a wetness layer.
	rainfall.png; The scrolling rain texture.
	splashNormal.png; The normal map of the rain splashes.

Inside "shaders" you will have:
	wet_lightrefractP.hlsl; The shader that refracts light ingame.
	wet_lightrefractV.hlsl; The vertex shader.
	wet_rainfallP.hlsl; The downscrolling rain shader.
	wet_splashP.hlsl; The splash shader.
	wet_surfP.hlsl; The wet surface shader.

Inside "T3D" you will have:
	precipitation.cpp; The updated precipitation object.

If there is an effect you don't like, or is to demanding, you can remove them from wetness.cs.
What the optional precipitation.cpp does, is automatic enabling of the wetness post effect when
adding a precipitation in your game.

TWO TIPS:
You should plan your lights carefully.
All the materials being affected by this effect should be normal mapped.


ISSUES:
The rain scrolling shader does still render if you look up or down; it looks unnatural.
Some rendering issue with the splash shader.

DISCLAIMER:
You are free to use/sell/modify this effect within-your-game. The only thing i would like you
as a user to do is to tell me that you use my effect, maybe credit me, and if you have
anything cool, I'd like it if you could share it with me.
(email: marcusloovergara@hotmail.com)

Thanks,
Marcus L.