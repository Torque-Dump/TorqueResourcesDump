// ============================================================
// File               :  ~\server\scripts\callbackManager.cs
// Author             :  Kent Butler
// Created on         :  Sunday, November 28, 2010
// Version            :  1.0
//
// Editor             :  TorqueDev v. 1.2.3430.42233
// ============================================================
// The callback manager object allows registration of sim objects
// to receive script callbacks. The object must implement a 
// function "onCallbackName(%this, %vars ...)" which is called
// when a callback with name matching "CallbackName" is posted
// to the manager. Any sim object can register for callback events
// and there can be multiple managers implemented within a game.
//
// The callbackManager listener array can not be modified while in the
// process of issuing a callback. The system cues any add/remove/post
// requests and processes them immediately after the callback is executed
// on all listeners. All add/remove actions are executed immediately.
// Post actions are put back on the actionQue and the first pending
// action is sent to the postCallback function on callbackManager. This
// process loop continues until all postCallback reqests have been processed
// with any add/remove actions generated from each postCallback action
// processed every iteration (and any additional callbackPosts cued).
//
// Fields
//-------
// bool debugOutput - turns debugging console spam on/off
//
// Method List
// -----------
// Register an object to listen for a specific callback event
// void $CallbackManager.registerCallbackListener( SimObject object, Const Char * callbackName )
//
// Register an object to listen for a all callback events handled by the manager
// void $CallbackManager.registerListener( SimObject object, Const Char * callbackName )
//
// Unregister all callback events handled by the Callback manager for the object.
// void $CallbackManager.unregisterListener( SimObject object )
//
// Unregister all listeners handled by the Callback manager for the specified callback.
// void $CallbackManager.unregisterCallback( Const Char * callbackName )
//
// Unregister the specified callback event handled by the Callback manager for the object.
// void $CallbackManager.unregisterCallbackListener( SimObject object, Const Char * callbackName )
//
// Returns true if the requested object is registered to handle the specified callback.
// bool $CallbackManager.isRegisteredListener( SimObject object, Const Char * callbackName )
//
// Request that the callback manager post the requested callback and arguments to all registered listeners
// void $CallbackManager.postCallback(command, <arg1...argN>)
//
// Utility function to list all the registered listeners to the console
// void $CallbackManager.listListeners();
//
// ============================================================
//Example Implementation:
//-----------------------
// The example script sets up a global callback manager and
// defines a simple script object as a basc callback
// listener with a utility example function for executing
// the callback.
//
// The advanced example tests nested manipulation calls to the CallbackManager
// from within callback routines and uses three objects. To run the example
// execute "cbmRunTest" from the command line.
//-------------------------------------------------------------

// Set global callback manager object
$CallbackManager = new CallbackManager(){
	debugOutput = true;
};

//Simple Example:
//----------------
new ScriptObject(TestListener);	// Create generic script object to use as a listener
$CallbackManager.registerCallbackListener(TestListener.getId(),"CallbackEvent"); // Register the script object with the callback manager

// Function to handle the callback
function TestListener::onCallbackEvent(%this,%val1,%val2){
	echo("Scriptobject listener (" @ %this @ ") - Example callback event: Val1=" @ %val1 SPC "Val2=" @ %val2);
}
// Simple example function that posts an event with 2 variables for the listener.
function sendCallback(%var1, %var2){
	$CallbackManager.postCallback("CallbackEvent", %var1, %var2);
}

//Advanced Example:
//----------------
new ScriptObject(TestListener2);
new ScriptObject(TestListener3);

//-------------------------------------------------------------------------
// Test Listener Callbacks
//----------------------------------------------- --------------------------
$CallbackManager.registerCallbackListener(TestListener.getId(),"RemoveSelf");
function TestListener::onRemoveSelf(%this,%val1,%val2){
	warn ("Scriptobject listener: Remove Self");
	$CallbackManager.unregisterCallbackListener(TestListener.getId(),"RemoveSelf");
}
$CallbackManager.registerCallbackListener(TestListener.getId(),"Report");
function TestListener::onReport(%this,%val1){
	warn ("Scriptobject listener - Reporting:"@%val1);	
}
//---------------------------------------------- ---------------------------
// TestListener2 Callbacks
//-------------------------------------------------------------------------
$CallbackManager.registerCallbackListener(TestListener2.getId(),"IssueCallback");
function TestListener2::onIssueCallback(%this,%val1,%val2){
	warn ("Scriptobject listener2: IssueCallback");
	$CallbackManager.PostCallback("Report", "TestListener2::onIssueCallback");
	$CallbackManager.PostCallback("FinalCommand", "TestListener2::FinalCommand");
}
$CallbackManager.registerCallbackListener(TestListener2.getId(),"RemoveSelf");
function TestListener2::onRemoveSelf(%this,%val1,%val2){
	warn ("Scriptobject listener2: RemoveSelf");
	$CallbackManager.unregisterListener(TestListener2.getId());
}

//-------------------------------------------------------------------------
// TestListener3 Callbacks (registered to listen *all*)
//-------------------------------------------------------------------------
$CallbackManager.registerListener(TestListener3.getId());
function TestListener3::onIssueCallback(%this,%val1,%val2){
	warn ("Scriptobject listener3: IssueCallback");
	$CallbackManager.PostCallback("Report", "TestListener3::onIssueCallback");
}
function TestListener3::onFinalCommand(%this,%val1,%val2){
	warn ("Scriptobject listener3: FinalCommand");
	$CallbackManager.PostCallback("RemoveSelf", "TestListener3::FinalCommand");
}
function TestListener3::onRemoveSelf(%this,%val1,%val2){
	warn ("Scriptobject listener3: RemoveSelf");
	$CallbackManager.unregisterListener(TestListener3.getId());
}
function TestListener3::onReport(%this,%val1){
	warn ("Scriptobject listener3 - Reporting:"@%val1);	
}

// Ugly but, hey ... it's example code.
function cbmReset(){
	if(isObject($Callbackmanager)){
		$Callbackmanager.delete();
	}
	exec("./callbackManager.cs");
}

function cbmRunTest(){
	cbmReset();
	//$callbackManager.setDebug(false);	
	echo("Running Callback Manager Test");
	echo("---- Starting  Listeners ----");	
	$Callbackmanager.listListeners();
	echo("-----------------------------");
	
	$Callbackmanager.postCallback("IssueCallback");	// Start the action
	
	echo("---- Ending  Listeners ----");
	$Callbackmanager.listListeners();	
	echo("-----------------------------");
}