// ---------------------------------------
// simCallbackManager.cc
//
// Author: Kent Butler
//
// Date: Nov 26, 2010
//
// Version: 1.0
//
// ---------------------------------------
#include "console/simBase.h"
//#include "console/console.h"
#include "console/consoleTypes.h"
#include "game/objectTypes.h"
#include "game/gameBase.h"
#include "console/simCallbackManager.h"


IMPLEMENT_CONOBJECT(CallbackManager);

CallbackManager::CallbackManager(){
   isLocked = false;
   mDebugOutput = true;
}

CallbackManager::~CallbackManager(){
}

bool CallbackManager::onAdd(){
   return Parent::onAdd();
}

void CallbackManager::initPersistFields(){
   Parent::initPersistFields();
   addGroup("CallbackManager");      
      addField( "debugOutput",          TypeBool,    Offset(mDebugOutput, CallbackManager) );
   endGroup("CallbackManager");

}

// --------------------------------------------------------
void CallbackManager::notifyLocked(){
   notifyLocked("can not complete request.");
}
void CallbackManager::notifyLocked(const char * txt){
   if(!mDebugOutput) return;
   Con::errorf("Callback manager locked:%s",txt);
}

// --------------------------------------------------------
void CallbackManager::queAction(SimObject * refObj, S32 actionCmd){
   queAction(refObj,NULL,actionCmd);
}

void CallbackManager::queAction(const char * callbackName, S32 actionCmd){
   queAction(0, callbackName, actionCmd);
}

void CallbackManager::queAction(SimObject * refObj, const char * callbackName, S32 actionCmd){
   ActionQueItem * itm = new ActionQueItem();
   itm->actionCmd = actionCmd;
   itm->refObj = refObj;
   itm->argv = NULL;
   itm->argc = 0;
   if(callbackName==NULL){
      itm->callbackName = NULL;
   } else {
      itm->callbackName = new char[ dStrlen( callbackName ) + 1];
      dStrcpy ((char *)itm->callbackName, callbackName);
   }
   mActionQue.push_back(*itm);
}

// --------------------------------------------------------
void CallbackManager::queCallback(S32 argc, const char **argv){
   ActionQueItem * itm = new ActionQueItem();
   itm->actionCmd = ActionQueItem::cmdCallback;
   itm->refObj = NULL;
   itm->argv = NULL;
   itm->argc = argc;
   
   U32 totalSize = 0;
   S32 i;

   for(i = 0; i < argc; i++)
      totalSize += dStrlen(argv[i]) + 1;

   totalSize += sizeof(char *) * argc;
  
   char ** tmp = (char **) dMalloc(totalSize);
   char *argBase = (char *) &tmp[argc];
   for(i = 0; i < argc; i++)
   {  
      tmp[i] = argBase;    
      dStrcpy(tmp[i], argv[i]);
      argBase += dStrlen(argv[i]) + 1;
   }
   itm->argv = (const char **)tmp;
   mActionQue.push_back(*itm);
}

// --------------------------------------------------------
void CallbackManager::processActionQue(){
   if (mActionQue.size() == 0) return;
   

   // Callback que (for more than one callback)
   bool callbackSet = false;
   Vector <ActionQueItem> callbackList;
   ActionQueItem callback;  // This will be issued immediately upon the end of the que process ... additional events are copied back into the action que and will be executed in sequence until none are left.

   Vector <ActionQueItem> ::iterator iter=mActionQue.begin();   
	while (iter != mActionQue.end() )
	{ 
		ActionQueItem *itm = iter;
      switch (itm->actionCmd){
         case ActionQueItem::cmdCallback:
            if (callbackSet){
               callbackList.push_back(*itm);
            } else {
               callback = *itm;
               callbackSet = true;
            }
            break;
         case ActionQueItem::cmdRegisterCallbackListener:
            registerCallbackListener(itm->refObj, itm->callbackName);
            break;
         case ActionQueItem::cmdRegisterListener:
            registerListener(itm->refObj);
            break;
         case ActionQueItem::cmdUnregisterCallbackListener:
            unregisterCallbackListener(itm->refObj, itm->callbackName);
            break;
         case ActionQueItem::cmdUnregisterCallback:
            unregisterCallback(itm->callbackName);
            break;
         case ActionQueItem::cmdUnregisterListener:
            unregisterListener(itm->refObj);
            break;
         default:
            break;
      }      
		iter++;
	}
   mActionQue.clear();
   if(callbackSet){
      if (callbackList.size()>0){
         mActionQue = callbackList;
      }

      if(mDebugOutput) Con::printf("Executing callback from que(%s)",callback.argv[0]);

      postCallback(callback.argc, callback.argv);
      dFree(callback.argv);
      callback.argv = NULL;
   }
}

// --------------------------------------------------------
void CallbackManager::registerListener(SimObject * obj){
   if(isLocked == true){
      queAction(obj, ActionQueItem::cmdRegisterListener);
      notifyLocked("que registerListener");
      return;
   }
   if ( isRegisteredListener(obj, "*all*") ){
      Con::warnf("Object (%d) is already a listener for callback:*all*.", obj->getId() );
      return;   // Only register for callbacks once
   }

   ListenerItem *itm = new ListenerItem();
   itm->monitorAll = true;
   itm->refObj = obj;
   itm->callbackName = "*all*";   
   mListenerList.push_back(*itm);
   if(mDebugOutput) Con::printf("Added Listener:*all* for object:%d",obj->getId() );
}

void CallbackManager::registerCallbackListener(SimObject * obj, const char * callbackName){
   if(isLocked == true){
      queAction(obj, callbackName, ActionQueItem::cmdRegisterCallbackListener);
      notifyLocked("que registerListener.");
      return;
   }
   if ( isRegisteredListener(obj, callbackName) ){
      Con::warnf("Object (%d) is already a listener for callback:%s ", callbackName, obj->getId() );
      return;   // Only register for callbacks once      
   }

   ListenerItem * itm = new ListenerItem();
   itm->monitorAll = false;
   itm->refObj = obj;
   itm->callbackName = new char[ dStrlen( callbackName ) + 1];
   dStrcpy (itm->callbackName, callbackName);
   mListenerList.push_back(*itm);
   if(mDebugOutput) Con::printf("Added Listener:%s (%d)",itm->callbackName, obj->getId() );
}


// --------------------------------------------------------
void CallbackManager::unregisterListener(SimObject * obj){
   if(isLocked == true){
      queAction(obj, ActionQueItem::cmdUnregisterListener);
      notifyLocked("que unregisterListener.");
      return;
   }
   bool r;
   r = true;
   while(r == true){
      r = removeNextListener(obj);      
   }
}
// --------------------------------------------------------
bool CallbackManager::removeNextListener(SimObject * obj){
   Vector <ListenerItem>::iterator iter=mListenerList.begin();   
	while (iter != mListenerList.end() )
	{ 
		ListenerItem *itm = iter;      
      if ( itm->refObj == obj )
      {
         if(mDebugOutput) Con::printf("Removing listener:%s(%d)",itm->callbackName, itm->refObj->getId());
         mListenerList.erase(itm);
         return true;
      }
		iter++;
	}
   return false;
}
// --------------------------------------------------------
void CallbackManager::unregisterCallback(const char * callbackName){
   if(isLocked == true){
      queAction(callbackName, ActionQueItem::cmdUnregisterCallback);
      notifyLocked("que uregisterCallback.");
      return;
   }
   bool r=true;
   while(r==true){
      r = removeNextCallback(callbackName);
   }
}
// --------------------------------------------------------
bool CallbackManager::removeNextCallback(const char * callbackName){
   Vector <ListenerItem>::iterator iter=mListenerList.begin();   
	while (iter != mListenerList.end() )
	{ 
		ListenerItem *itm = iter;      
      S32 ti = dStrcmp( itm->callbackName, callbackName);
      if (ti == 0)      
      {
         if(mDebugOutput) Con::printf("Removing listener:%s(%d)",itm->callbackName, itm->refObj->getId());
         mListenerList.erase(itm);
         return true;
      }
		iter++;
	}
   return false;
}
// --------------------------------------------------------
void CallbackManager::unregisterCallbackListener(SimObject * obj, const char * callbackName){
   if(isLocked == true){
      queAction(obj, callbackName, ActionQueItem::cmdUnregisterCallbackListener);
      notifyLocked("que unregisterCallbackListener.");
      return;
   }
   Vector <ListenerItem>::iterator iter=mListenerList.begin();   
	while (iter != mListenerList.end() )
	{ 
		ListenerItem *itm = iter;      
      S32 ti = dStrcmp( itm->callbackName, callbackName);
      if ( itm->refObj == obj && ti == 0)
      {
         if(mDebugOutput) Con::printf("Removing listener:%s(%d)",itm->callbackName, itm->refObj->getId());
         mListenerList.erase(itm);
         return;
      }
		iter++;
	}
   return;
}

// --------------------------------------------------------
bool CallbackManager::isRegisteredListener(SimObject * obj, const char * callbackName){
   Vector <ListenerItem>::iterator iter=mListenerList.begin();   
	while (iter != mListenerList.end() )
	{ 
		ListenerItem *itm = iter;      
      S32 ti = dStrcmp( itm->callbackName, callbackName);
      if ( itm->refObj == obj && ti == 0)
      {         
         return true;
      }
		iter++;
	}
   return false;
}
// --------------------------------------------------------
void CallbackManager::listListeners(){
   if(mListenerList.size() == 0){
      Con::printf("No Callback Listeners");
      return;
   }

   Vector <ListenerItem>::iterator iter=mListenerList.begin();   
	while (iter != mListenerList.end() )
	{ 
		ListenerItem *itm = iter;
      Con::printf("Listener:%s (%d)",itm->callbackName, itm->refObj->getId() );      
		iter++;
	}
}
// --------------------------------------------------------

void CallbackManager::postCallback(S32 argc, const char **argv){
   if (isLocked == true){
      if(mDebugOutput) Con::errorf("CallbackManager locked: que Callback(%s)", argv[0] );
      queCallback(argc, argv);
      return;
   }

   S32 tArgc = argc;
   U32 totalSize = 0;
   S32 i;

   isLocked = true;  // Notify the object that we shouldnt mess with the list

   for(i = 0; i < argc; i++)
      totalSize += dStrlen(argv[i]) + 1;

   totalSize += sizeof(char *) * argc;
  
   char ** tArgv = (char **) dMalloc(totalSize);
   char *argBase = (char *) &tArgv[argc];

   for(i = 0; i < argc; i++)
   {
      tArgv[i] = argBase;
      dStrcpy(tArgv[i], argv[i]);
      argBase += dStrlen(argv[i]) + 1;
   }

   char buf[1024];
   dStrcpy(buf, "on");   
   dStrcat(buf, argv[0]);      
   tArgv[0] = buf;

   char cmd[1024];
   dStrcpy(cmd, argv[0]);

   // Notify the registered objects
   Vector <ListenerItem>::iterator iter=mListenerList.begin();   
	while (iter != mListenerList.end() )
	{       
      ListenerItem *itm = iter;
      if(itm->refObj != NULL){
         if(!itm->refObj->isDeleted()){
            S32 ti = dStrcmp( itm->callbackName, cmd );
            if ( ti == 0 || itm->monitorAll )
            {
               
               Con::execute(itm->refObj, tArgc, const_cast<const char**>( tArgv ));               
            }
         }
      }
		iter++;
	}
   dFree(tArgv);
   isLocked = false;  // Free up the object;
   processActionQue();
}

// ================================================
// **               Console Methods              **
// ================================================

ConsoleMethod( CallbackManager, registerCallbackListener, void, 4, 4, "( SimObject object, Const Char * callbackName )"
              "Register an object to listen for specified callback")
{
   SimObject *obj;   
   if (!Sim::findObject(argv[2],obj)) {            
      Con::errorf("Invalid object requested.");
      return;
   }

   object->registerCallbackListener(obj,argv[3]);
   return;
}

ConsoleMethod( CallbackManager, registerListener, void, 3, 3, "( SimObject object )"
              "Register an object to listen for all callback events issued by the Callback Manager")
{
   SimObject *obj;   
   if (!Sim::findObject(argv[2],obj)) {            
      Con::errorf("Invalid object requested.");
      return;
   }

   object->registerListener(obj);
   return;
}

// --------------------------------------------------------
ConsoleMethod( CallbackManager, listListeners, void, 2, 2, "( void )"
              "List all callback listeners for this manger")
{
   object->listListeners();
   return;
}

// --------------------------------------------------------
ConsoleMethod( CallbackManager, unregisterListener, void, 3, 3, "( SimObject object )"
              "unregister all callbacks for the specified object.")
{
   SimObject *obj;   
   if (!Sim::findObject(argv[2],obj)) {            
      Con::errorf("Invalid object requested.");
      return;
   }

   object->unregisterListener(obj);
   return;
}

// --------------------------------------------------------
ConsoleMethod( CallbackManager, unregisterCallbackListener, void, 4, 4, "( SimObject object, Const Char * callbackName )"
              "Unregister an object from listening for specified callback")
{
   SimObject *obj;   
   if (!Sim::findObject(argv[2],obj)) {            
      Con::errorf("Invalid object requested.");
      return;
   }
   object->unregisterCallbackListener(obj,argv[3]);
   return;
}

// --------------------------------------------------------
ConsoleMethod( CallbackManager, unregisterCallback, void, 3, 3, "( Const Char * callbackName )"
              "Unregister an object from listening for specified callback")
{
   object->unregisterCallback(argv[2]);
   return;
}

// --------------------------------------------------------
ConsoleMethod( CallbackManager, isRegisteredListener, bool, 4, 4, "( SimObject object, Const Char * callbackName )"
              "Returns true if the specified object is registered as a listener for the specified callback")
{
   SimObject *obj;   
   if (!Sim::findObject(argv[2],obj)) {            
      Con::errorf("Invalid object requested.");
      return false;
   }
   return object->isRegisteredListener(obj,argv[3]);  
}

// --------------------------------------------------------
ConsoleMethod( CallbackManager, clearListeners, void, 2, 2, "( void )"
              "Remove all callback listeners registered with this manager object.")
{
   object->clearListeners();
   return;
}

// --------------------------------------------------------
ConsoleMethod(CallbackManager, postCallback, void, 2, 0, "(command, <arg1...argN>)")
{   
   // Swap arg1 and arg2 using arg0 as a temp var
   argv[0] = argv[1];
   argv[1] = argv[2];
   argv[2] = argv[0];

   object->postCallback(argc - 1, argv + 1); // chop arg0 
   return;
}

