// ---------------------------------------
// simCallbackManager.h
//
// Author: Kent Butler
//
// Date: Nov 26, 2010
//
// Version: 1.0
//
// ---------------------------------------

#ifndef _SIMCALLBACKMANAGER_H_
#define _SIMCALLBACKMANAGER_H_

#ifndef _SIMBASE_H_
#include "console/simBase.h"
#endif


struct ListenerItem{
   SimObject * refObj;
   char * callbackName;
   bool monitorAll;
};

struct ActionQueItem{
   enum{
      cmdCallback                   = 1,
      cmdRegisterCallbackListener   = 2,
      cmdRegisterListener           = 3,
      cmdUnregisterCallbackListener = 4,
      cmdUnregisterCallback         = 5,
      cmdUnregisterListener         = 6
   };

   SimObject * refObj;
   const char * callbackName;
   S32 actionCmd;
   // to que callbacks
   const char **argv;
   S32 argc;
//   ~ActionQueItem(){
//      if (argv != NULL){
//         dFree(argv);
//      }
//   };
};


class CallbackManager: public SimObject{

private:
   typedef SimObject Parent;

public:   
   DECLARE_CONOBJECT(CallbackManager);
   CallbackManager();
   ~CallbackManager();
   
   bool onAdd();
   static void initPersistFields();

protected:
   Vector <ListenerItem> mListenerList;   // Vector holding the listeners
   Vector <ActionQueItem> mActionQue;     // Vector holding any commands qued while locked.
   bool isLocked;

private:   
   void queAction(SimObject * refObj, S32 actionCmd);
   void queAction(const char * callbackName, S32 actionCmd);
   void queAction(SimObject * refObj, const  char * callbackName, S32 actionCmd);
   void queCallback(S32 argc, const char **argv);
   void processActionQue();

   bool removeNextListener(SimObject * obj);
   bool removeNextCallback(const char * callbackName);   
   void notifyLocked(const char * txt);
   void notifyLocked();

   bool mDebugOutput;

public:
   void registerListener(SimObject * obj); // Register an object to the listener list
   void registerCallbackListener(SimObject * obj, const char * callbackName); // Register an object to the listener list
   void unregisterCallbackListener(SimObject * obj, const char * callbackName); // Unregister a single Callback being listened for by this object

   void unregisterListener(SimObject * obj);   // Unregister all Callbacks being listened for by this object
   void unregisterCallback(const char * callbackName);
   
   bool isRegisteredListener(SimObject * obj, const char * callbackName);
   void listListeners();
   void postCallback(S32 argc, const char **argv);
   void clearListeners(){mListenerList.clear();};   
};

#endif