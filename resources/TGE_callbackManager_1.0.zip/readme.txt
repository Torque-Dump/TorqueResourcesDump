CallbackManager 1.0
-------------------

This was created for TGE 1.5.2 codebase. Later versions of Torque have a built-in callback manager that is likely more robust.

For the engine files, put in the engine/console directory (or other location as approprate for your build) and add to the project.

The script file CallbackManager.cs contains documentation and provides an example implementation to demonstrate use of the object. This can be placed in the ~/server/scripts/ directory and exec'd from the proper place.