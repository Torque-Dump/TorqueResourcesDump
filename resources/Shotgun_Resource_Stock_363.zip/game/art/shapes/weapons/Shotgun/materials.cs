
singleton Material(shotgun_FP_shotFPMaterial__25)
{
   mapTo = "shotFPMaterial__25";
   diffuseColor[0] = "0.223529 0.223529 0.223529 1";
   specular[0] = "0.258824 0.258824 0.258824 1";
   specularPower[0] = "9";
   translucentBlendOp = "None";
   diffuseMap[0] = "art/shapes/weapons/Shotgun/images/MetalBare0104_2_thumblarge.jpg";
   normalMap[0] = "art/shapes/weapons/Shotgun/images/MetalBare0104_2_thumblarge_Normal.jpg";
   specularStrength[0] = "1.86275";
   pixelSpecular[0] = "1";
};

singleton Material(shotgun_FP_shotFP_1___Default)
{
   mapTo = "shotFP_1_-_Default";
   diffuseMap[0] = "art/shapes/weapons/Shotgun/images/0_wood1.png";
   specular[0] = "0.270588 0.270588 0.270588 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   diffuseColor[0] = "0.329412 0.329412 0.329412 1";
   pixelSpecular[0] = "1";
   normalMap[0] = "art/shapes/weapons/Shotgun/images/MetalBare0104_2_thumblarge_Normal.jpg";
   specularStrength[0] = "2.64706";
};
