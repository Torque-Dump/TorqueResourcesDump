
singleton Material(_1_-_Default_mat)
{
   mapTo = "unmapped_mat";
   diffuseMap[0] = "art/shapes/weapons/Shotgun/Shotgun_TP/images/0_wood1.png";
   effectColor[0] = "0 0 0 0";
   materialTag1 = "Weapon";
   materialTag0 = "Weapon";
};

singleton Material(newMaterial)
{
   mapTo = "_1_-_Default";
   diffuseMap[0] = "art/shapes/weapons/Shotgun/Shotgun_TP/images/0_wood1.png";
   materialTag1 = "Weapon";
   materialTag0 = "Weapon";
   normalMap[0] = "art/shapes/weapons/Shotgun/Shotgun_TP/images/MetalBare0104_2_thumblarge_Normal.jpg";
   diffuseColor[0] = "0.466667 0.466667 0.466667 1";
};

singleton Material(newMaterial2)
{
   mapTo = "Material__25";
   diffuseMap[0] = "art/shapes/weapons/Shotgun/Shotgun_TP/images/MetalBare0104_2_thumblarge.jpg";
   effectColor[0] = "0 0 0 0";
   materialTag0 = "Weapon";
   diffuseColor[0] = "0.337255 0.337255 0.337255 1";
   normalMap[0] = "art/shapes/weapons/Shotgun/Shotgun_TP/images/MetalBare0104_2_thumblarge_Normal.jpg";
   specularPower[0] = "51";
   specularStrength[0] = "2.15686";
   pixelSpecular[0] = "1";
   materialTag1 = "Weapon";
};
