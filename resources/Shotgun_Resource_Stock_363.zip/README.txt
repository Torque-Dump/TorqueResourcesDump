Liscense for Sounds
CC - Attribution 3.0


If you use the sound files please attribute 

Shotgun Fire Sound and Shotgun Reload Pump created by RA The Sun God from SoundBible.com

License
https://creativecommons.org/licenses/by/3.0/us/
https://creativecommons.org/licenses/by/3.0/de/deed.en

Original Files
http://soundbible.com/1959-Shotgun-Reload-Pump.html
http://soundbible.com/1960-Shotgun-Old-School.html

Shotgun Old School length was shortened.

