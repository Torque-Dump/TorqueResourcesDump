//-----------------------------------------------------------------------------
// Torque 3D
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "platform/platform.h"
#include "math/mathUtils.h"

#include "math/mMath.h"
#include "math/mRandom.h"

namespace MathUtils
{

MRandomLCG sgRandom(0xdeadbeef); ///< Our random number generator.

// Collide two capsules (sphere swept lines) against each other, reporting only if they intersect or not.
// Based on routine from "Real Time Collision Detection" by Christer Ericson pp 114.
bool capsuleCapsuleOverlap(const Point3F & a1, const Point3F & b1, F32 rad1, const Point3F & a2, const Point3F & b2, F32 rad2)
{
   F32 s,t;
   Point3F c1,c2;
   F32 dist = segmentSegmentNearest(a1,b1,a2,b2,s,t,c1,c2);
   return dist <= (rad1+rad2)*(rad1+rad2);
}

// Intersect two line segments (p1,q1) and (p2,q2), returning points on lines (c1 & c2) and line parameters (s,t).
// Based on routine from "Real Time Collision Detection" by Christer Ericson pp 149.
F32 segmentSegmentNearest(const Point3F & p1, const Point3F & q1, const Point3F & p2, const Point3F & q2, F32 & s, F32 & t, Point3F & c1, Point3F & c2)
{
   Point3F d1 = q1-p1;
   Point3F d2 = q2-p2;
   Point3F r = p1-p2;
   F32 a = mDot(d1,d1);
   F32 e = mDot(d2,d2);
   F32 f = mDot(d2,r);
   
   const F32 EPSILON = 0.001f;
   
   if (a <= EPSILON && e <= EPSILON)
   {
      s = t = 0.0f;
      c1 = p1;
      c2 = p2;
      return mDot(c1-c2,c1-c2);
   }
   
   if (a <= EPSILON)
   {
      s = 0.0f;
      t = mClampF(f/e,0.0f,1.0f);
   }
   else
   {
      F32 c = mDot(d1,r);
      if (e <= EPSILON)
      {
         t = 0.0f;
         s = mClampF(-c/a,0.0f,1.0f);
      }
      else
      {
         F32 b = mDot(d1,d2);
         F32 denom = a*e-b*b;
         if (denom != 0.0f)
            s = mClampF((b*f-c*e)/denom,0.0f,1.0f);
         else
            s = 0.0f;
         F32 tnom = b*s+f;
         if (tnom < 0.0f)
         {
            t = 0.0f;
            s = mClampF(-c/a,0.0f,1.0f);
         }
         else if (tnom>e)
         {
            t = 1.0f;
            s = mClampF((b-c)/a,0.0f,1.0f);
         }
         else
            t = tnom/e;
      }
   }
   
   c1 = p1 + d1*s;
   c2 = p2 + d2*t;
   return mDot(c1-c2,c1-c2);
}

//------------------------------------------------------------------------------
// Return capsule-sphere overlap.  Returns time of first overlap, where time
// is viewed as a sphere of radius radA moving from point A0 to A1.
//------------------------------------------------------------------------------
bool capsuleSphereNearestOverlap(const Point3F & A0, const Point3F A1, F32 radA, const Point3F & B, F32 radB, F32 & t)
{
   Point3F V = A1-A0;
   Point3F A0B = A0-B;
   F32 d1 = mDot(A0B,V);
   F32 d2 = mDot(A0B,A0B);
   F32 d3 = mDot(V,V);
   F32 R2 = (radA+radB)*(radA+radB);
   if (d2<R2)
   {
      // starting in collision state
      t=0;
      return true;
   }
   if (d3<0.01f)
      // no movement, and don't start in collision state, so no collision
      return false;

   F32 b24ac = mSqrt(d1*d1-d2*d3+d3*R2);
   F32 t1 = (-d1-b24ac)/d3;
   if (t1>0 && t1<1.0f)
   {
      t=t1;
      return true;
   }
   F32 t2 = (-d1+b24ac)/d3;
   if (t2>0 && t2<1.0f)
   {
      t=t2;
      return true;
   }
   if (t1<0 && t2>0)
   {
      t=0;
      return true;
   }
   return false;   
}

void getZBiasProjectionMatrix( F32 bias, const Frustum &frustum, MatrixF *outMat, bool rotate )
{

   F32 currNearDist = frustum.getNearDist();
   F32 currLeft = frustum.getNearLeft();
   F32 currBottom = frustum.getNearBottom();

   // Extract the fov and aspect ratio.
   F32 fovInRadians = ( mAtan2( currNearDist, currLeft ) * 2.0f ) - M_PI_F;
   F32 aspectRatio = currLeft / currBottom;

   F32 left    = -(currNearDist + bias) * mTan( fovInRadians / 2.0f );
   F32 right   = -left;
   F32 bottom  = left / aspectRatio;
   F32 top     = -bottom;

   F32 nearDist, farDist;

   nearDist = currNearDist + bias;
   farDist = frustum.getFarDist();

   Point4F row;
   row.x = 2.0 * nearDist / (right-left);
   row.y = 0.0;
   row.z = 0.0;
   row.w = 0.0;
   outMat->setRow( 0, row );

   row.x = 0.0;
   row.y = 2.0 * nearDist / (top-bottom);
   row.z = 0.0;
   row.w = 0.0;
   outMat->setRow( 1, row );

   row.x = (left+right) / (right-left);
   row.y = (top+bottom) / (top-bottom);
   row.z = farDist / (nearDist-farDist);
   row.w = -1.0;
   outMat->setRow( 2, row );

   row.x = 0.0;
   row.y = 0.0;
   row.z = nearDist * farDist / (nearDist-farDist);
   row.w = 0.0;
   outMat->setRow( 3, row );

   outMat->transpose();

   if ( rotate )
   {
      MatrixF rotMat(EulerF( (M_PI_F / 2.0f), 0.0f, 0.0f));
      outMat->mul( rotMat );
   }
}

MatrixF createOrientFromDir( const Point3F &direction )
{
	Point3F j = direction;
	Point3F k(0.0f, 0.0f, 1.0f);
	Point3F i;
	
	mCross( j, k, &i );

	if( i.magnitudeSafe() == 0.0f )
	{
		i.set( 0.0f, -1.0f, 0.0f );
	}

	i.normalizeSafe();
	mCross( i, j, &k );

   MatrixF mat( true );
   mat.setColumn( 0, i );
   mat.setColumn( 1, j );
   mat.setColumn( 2, k );

	return mat;
}

void getMatrixFromUpVector( const VectorF &up, MatrixF *outMat )
{
   AssertFatal( up.isUnitLength(), "MathUtils::getMatrixFromUpVector() - Up vector was not normalized!" );
   AssertFatal( outMat, "MathUtils::getMatrixFromUpVector() - Got null output matrix!" );
   AssertFatal( outMat->isAffine(), "MathUtils::getMatrixFromUpVector() - Got uninitialized matrix!" );

   VectorF forward = mPerp( up );
   VectorF right = mCross( forward, up );
   right.normalize();
   forward = mCross( up, right );
   forward.normalize();

   outMat->setColumn( 0, right );
   outMat->setColumn( 1, forward );
   outMat->setColumn( 2, up );
}

void getMatrixFromForwardVector( const VectorF &forward, MatrixF *outMat  )
{
   AssertFatal( forward.isUnitLength(), "MathUtils::getMatrixFromForwardVector() - Forward vector was not normalized!" );
   AssertFatal( outMat, "MathUtils::getMatrixFromForwardVector() - Got null output matrix!" );
   AssertFatal( outMat->isAffine(), "MathUtils::getMatrixFromForwardVector() - Got uninitialized matrix!" );

   VectorF up = mPerp( forward );
   VectorF right = mCross( forward, up );
   right.normalize();
   up = mCross( right, forward );
   up.normalize();

   outMat->setColumn( 0, right );
   outMat->setColumn( 1, forward );
   outMat->setColumn( 2, up );
}


//------------------------------------------------------------------------------
// Creates random direction given angle parameters similar to the particle system.
// The angles are relative to the specified axis.
//------------------------------------------------------------------------------
Point3F randomDir( const Point3F &axis, F32 thetaAngleMin, F32 thetaAngleMax,
                                        F32 phiAngleMin, F32 phiAngleMax )
{
   MatrixF orient = createOrientFromDir( axis );
   Point3F axisx;
   orient.getColumn( 0, &axisx );

   F32 theta = (thetaAngleMax - thetaAngleMin) * sgRandom.randF() + thetaAngleMin;
   F32 phi = (phiAngleMax - phiAngleMin) * sgRandom.randF() + phiAngleMin;

   // Both phi and theta are in degs.  Create axis angles out of them, and create the
   //  appropriate rotation matrix...
   AngAxisF thetaRot(axisx, theta * (M_PI_F / 180.0f));
   AngAxisF phiRot(axis,    phi   * (M_PI_F / 180.0f));

   Point3F ejectionAxis = axis;

   MatrixF temp(true);
   thetaRot.setMatrix(&temp);
   temp.mulP(ejectionAxis);
   phiRot.setMatrix(&temp);
   temp.mulP(ejectionAxis);

   return ejectionAxis;
}


//------------------------------------------------------------------------------
// Returns yaw and pitch angles from a given vector.  Angles are in RADIANS.
// Assumes north is (0.0, 1.0, 0.0), the degrees move upwards clockwise.
// The range of yaw is 0 - 2PI.  The range of pitch is -PI/2 - PI/2.
// ASSUMES Z AXIS IS UP
//------------------------------------------------------------------------------
void getAnglesFromVector( const VectorF &vec, F32 &yawAng, F32 &pitchAng )
{
   yawAng = mAtan2( vec.x, vec.y );
   if( yawAng < 0.0f )
      yawAng += M_2PI_F;

   if( mFabs(vec.x) > mFabs(vec.y) )
      pitchAng = mAtan2( mFabs(vec.z), mFabs(vec.x) );
   else
      pitchAng = mAtan2( mFabs(vec.z), mFabs(vec.y) );
   if( vec.z < 0.0f )
      pitchAng = -pitchAng;
}


//------------------------------------------------------------------------------
// Returns vector from given yaw and pitch angles.  Angles are in RADIANS.
// Assumes north is (0.0, 1.0, 0.0), the degrees move upwards clockwise.
// The range of yaw is 0 - 2PI.  The range of pitch is -PI/2 - PI/2.
// ASSUMES Z AXIS IS UP
//------------------------------------------------------------------------------
void getVectorFromAngles( VectorF &vec, F32 yawAng, F32 pitchAng )
{
   VectorF  pnt( 0.0f, 1.0f, 0.0f );

   EulerF   rot( -pitchAng, 0.0f, 0.0f );
   MatrixF  mat( rot );

   rot.set( 0.0f, 0.0f, yawAng );
   MatrixF   mat2( rot );

   mat.mulV( pnt );
   mat2.mulV( pnt );

   vec = pnt;
}


// transform bounding box making sure to keep original box entirely contained - JK...
void transformBoundingBox(const Box3F &sbox, const MatrixF &mat, const Point3F scale, Box3F &dbox)
{
	Point3F center;

	// set transformed center...
	sbox.getCenter(&center);
   center.convolve(scale);
	mat.mulP(center);
	dbox.minExtents = center;
	dbox.maxExtents = center;

	Point3F val;
	for(U32 ix=0; ix<2; ix++)
	{
		if(ix & 0x1)
			val.x = sbox.minExtents.x;
		else
			val.x = sbox.maxExtents.x;

		for(U32 iy=0; iy<2; iy++)
		{
			if(iy & 0x1)
				val.y = sbox.minExtents.y;
			else
				val.y = sbox.maxExtents.y;

			for(U32 iz=0; iz<2; iz++)
			{
				if(iz & 0x1)
					val.z = sbox.minExtents.z;
				else
					val.z = sbox.maxExtents.z;

				Point3F v1, v2;
            v1 = val;
            v1.convolve(scale);
				mat.mulP(v1, &v2);
				dbox.minExtents.setMin(v2);
				dbox.maxExtents.setMax(v2);
			}
		}
	}
}

bool mProjectWorldToScreen(   const Point3F &in, 
                              Point3F *out, 
                              const RectI &view, 
                              const MatrixF &world, 
                              const MatrixF &projection )
{
   MatrixF worldProjection = projection;
   worldProjection.mul(world);

   Point4F temp(in.x,in.y,in.z,1.0f);
   worldProjection.mul(temp);
   temp.x /= temp.w;
   temp.y /= temp.w;
   temp.z /= temp.w;

   out->x = (temp.x + 1.0f) / 2.0f * view.extent.x + view.point.x;
   out->y = (1.0f - temp.y) / 2.0f * view.extent.y + view.point.y;
   out->z = temp.z;

   if ( out->z < 0.0f || out->z > 1.0f || 
        out->x < (F32)view.point.x || out->x > (F32)view.point.x + (F32)view.extent.x ||
        out->y < (F32)view.point.y || out->y > (F32)view.point.y + (F32)view.extent.y )
      return false;

   return true;
}

void mProjectScreenToWorld(   const Point3F &in, 
                              Point3F *out, 
                              const RectI &view, 
                              const MatrixF &world, 
                              const MatrixF &projection, 
                              F32 zfar, 
                              F32 znear )
{
   MatrixF invWorldProjection = projection;
   invWorldProjection.mul(world);
   invWorldProjection.inverse();

   Point3F vec;
   vec.x = (in.x - view.point.x) * 2.0f / view.extent.x - 1.0f;
   vec.y = -(in.y - view.point.y) * 2.0f / view.extent.y + 1.0f;
   vec.z = (znear + in.z * (zfar - znear))/zfar;

   invWorldProjection.mulV(vec);
   vec *= 1.0f + in.z * zfar;

   invWorldProjection.getColumn(3, out);
   (*out) += vec;
}

bool pointInPolygon( const Point2F *verts, U32 vertCount, const Point2F &testPt )
{
  U32 i, j, c = 0;
  for ( i = 0, j = vertCount-1; i < vertCount; j = i++ ) 
  {
    if ( ( ( verts[i].y > testPt.y ) != ( verts[j].y > testPt.y ) ) &&
	         ( testPt.x <   ( verts[j].x - verts[i].x ) * 
                           ( testPt.y - verts[i].y ) / 
                           ( verts[j].y - verts[i].y ) + verts[i].x ) )
       c = !c;
  }
  
  return c != 0;
}  

F32 mTriangleDistance( const Point3F &A, const Point3F &B, const Point3F &C, const Point3F &P, IntersectInfo* info )
{
    Point3F diff = A - P;
    Point3F edge0 = B - A;
    Point3F edge1 = C - A;
    F32 a00 = edge0.lenSquared();
    F32 a01 = mDot( edge0, edge1 );
    F32 a11 = edge1.lenSquared();
    F32 b0 = mDot( diff, edge0 );
    F32 b1 = mDot( diff, edge1 );
    F32 c = diff.lenSquared();
    F32 det = mFabs(a00*a11-a01*a01);
    F32 s = a01*b1-a11*b0;
    F32 t = a01*b0-a00*b1;
    F32 sqrDistance;

    if (s + t <= det)
    {
        if (s < 0.0f)
        {
            if (t < 0.0f)  // region 4
            {
                if (b0 < 0.0f)
                {
                    t = 0.0f;
                    if (-b0 >= a00)
                    {
                        s = 1.0f;
                        sqrDistance = a00 + (2.0f)*b0 + c;
                    }
                    else
                    {
                        s = -b0/a00;
                        sqrDistance = b0*s + c;
                    }
                }
                else
                {
                    s = 0.0f;
                    if (b1 >= 0.0f)
                    {
                        t = 0.0f;
                        sqrDistance = c;
                    }
                    else if (-b1 >= a11)
                    {
                        t = 1.0f;
                        sqrDistance = a11 + 2.0f*b1 + c;
                    }
                    else
                    {
                        t = -b1/a11;
                        sqrDistance = b1*t + c;
                    }
                }
            }
            else  // region 3
            {
                s = 0.0f;
                if (b1 >= 0.0f)
                {
                    t = 0.0f;
                    sqrDistance = c;
                }
                else if (-b1 >= a11)
                {
                    t = 1.0f;
                    sqrDistance = a11 + 2.0f*b1 + c;
                }
                else
                {
                    t = -b1/a11;
                    sqrDistance = b1*t + c;
                }
            }
        }
        else if (t < 0.0f)  // region 5
        {
            t = 0.0f;
            if (b0 >= 0.0f)
            {
                s = 0.0f;
                sqrDistance = c;
            }
            else if (-b0 >= a00)
            {
                s = 1.0f;
                sqrDistance = a00 + 2.0f*b0 + c;
            }
            else
            {
                s = -b0/a00;
                sqrDistance = b0*s + c;
            }
        }
        else  // region 0
        {
            // minimum at interior point
            F32 invDet = 1.0f / det;
            s *= invDet;
            t *= invDet;
            sqrDistance = s * (a00*s + a01*t + 2.0f*b0) +
                t * (a01*s + a11*t + 2.0f*b1) + c;
        }
    }
    else
    {
        F32 tmp0, tmp1, numer, denom;

        if (s < 0.0f)  // region 2
        {
            tmp0 = a01 + b0;
            tmp1 = a11 + b1;
            if (tmp1 > tmp0)
            {
                numer = tmp1 - tmp0;
                denom = a00 - 2.0f*a01 + a11;
                if (numer >= denom)
                {
                    s = 1.0f;
                    t = 0.0f;
                    sqrDistance = a00 + 2.0f*b0 + c;
                }
                else
                {
                    s = numer/denom;
                    t = 1.0f - s;
                    sqrDistance = s * (a00*s + a01*t + 2.0f*b0) +
                                  t * (a01*s + a11*t + 2.0f*b1) + c;
                }
            }
            else
            {
                s = 0.0f;
                if (tmp1 <= 0.0f)
                {
                    t = 1.0f;
                    sqrDistance = a11 + 2.0f*b1 + c;
                }
                else if (b1 >= 0.0f)
                {
                    t = 0.0f;
                    sqrDistance = c;
                }
                else
                {
                    t = -b1/a11;
                    sqrDistance = b1*t + c;
                }
            }
        }
        else if (t < 0.0f)  // region 6
        {
            tmp0 = a01 + b1;
            tmp1 = a00 + b0;
            if (tmp1 > tmp0)
            {
                numer = tmp1 - tmp0;
                denom = a00 - 2.0f*a01 + a11;
                if (numer >= denom)
                {
                    t = 1.0f;
                    s = 0.0f;
                    sqrDistance = a11 + 2.0f*b1 + c;
                }
                else
                {
                    t = numer/denom;
                    s = 1.0f - t;
                    sqrDistance = s * (a00*s + a01*t + 2.0f*b0) +
                                  t * (a01*s + a11*t + 2.0f*b1) + c;
                }
            }
            else
            {
                t = 0.0f;
                if (tmp1 <= 0.0f)
                {
                    s = 1.0f;
                    sqrDistance = a00 + 2.0f*b0 + c;
                }
                else if (b0 >= 0.0f)
                {
                    s = 0.0f;
                    sqrDistance = c;
                }
                else
                {
                    s = -b0/a00;
                    sqrDistance = b0*s + c;
                }
            }
        }
        else  // region 1
        {
            numer = a11 + b1 - a01 - b0;
            if (numer <= 0.0f)
            {
                s = 0.0f;
                t = 1.0f;
                sqrDistance = a11 + 2.0f*b1 + c;
            }
            else
            {
                denom = a00 - 2.0f*a01 + a11;
                if (numer >= denom)
                {
                    s = 1.0f;
                    t = 0.0f;
                    sqrDistance = a00 + 2.0f*b0 + c;
                }
                else
                {
                    s = numer/denom;
                    t = 1.0f - s;
                    sqrDistance = s * (a00*s + a01*t + 2.0f*b0) +
                                  t * (a01*s + a11*t + 2.0f*b1) + c;
                }
            }
        }
    }

    // account for numerical round-off error
    if (sqrDistance < 0.0f)
        sqrDistance = 0.0f;

    // This also calculates the barycentric coordinates and the closest point!
    //m_kClosestPoint0 = P;
    //m_kClosestPoint1 = A + s*edge0 + t*edge1;
    //m_afTriangleBary[1] = s;
    //m_afTriangleBary[2] = t;
    //m_afTriangleBary[0] = (Real)1.0 - fS - fT;
    if(info)
    {
       info->segment.p0 = P;
       info->segment.p1 = A + s*edge0 + t*edge1;
       info->bary.x = s;
       info->bary.y = t;
       info->bary.z = 1.0f - s - t;
    }

    return sqrDistance;
}

Point3F mClosestPointOnSegment( const Point3F &a, const Point3F &b, const Point3F &p )
{
	Point3F c = p - a;               // Vector from a to Point
   Point3F v = (b - a);
	F32 d = v.len();           // Length of the line segment
   v.normalize();	                  // Unit Vector from a to b
	F32 t = mDot( v, c );            // Intersection point Distance from a

	// Check to see if the point is on the line
	// if not then return the endpoint
	if(t < 0) return a;
	if(t > d) return b;

	// get the distance to move from point a
	v *= t;

	// move from point a to the nearest point on the segment
	return a + v;
}

void mShortestSegmentBetweenLines( const Line &line0, const Line &line1, LineSegment *outSegment )
{   
   // compute intermediate parameters
   Point3F w0 = line0.origin - line1.origin;
   F32 a = mDot( line0.direction, line0.direction );
   F32 b = mDot( line0.direction, line1.direction );
   F32 c = mDot( line1.direction, line1.direction );
   F32 d = mDot( line0.direction, w0 );
   F32 e = mDot( line1.direction, w0 );

   F32 denom = a*c - b*b;

   if ( denom > -0.001f && denom < 0.001f )
   {
      outSegment->p0 = line0.origin;
      outSegment->p1 = line1.origin + (e/c)*line1.direction;
   }
   else
   {
      outSegment->p0 = line0.origin + ((b*e - c*d)/denom)*line0.direction;
      outSegment->p1 = line1.origin + ((a*e - b*d)/denom)*line1.direction;
   }
}

U32 greatestCommonDivisor( U32 u, U32 v )
{
   // http://en.wikipedia.org/wiki/Binary_GCD_algorithm
      
   int shift;

   /* GCD(0,x) := x */
   if (u == 0 || v == 0)
      return u | v;

   /* Left shift := lg K, where K is the greatest power of 2
   dividing both u and v. */
   for (shift = 0; ((u | v) & 1) == 0; ++shift) {
      u >>= 1;
      v >>= 1;
   }

   while ((u & 1) == 0)
      u >>= 1;

   /* From here on, u is always odd. */
   do {
      while ((v & 1) == 0)  /* Loop X */
         v >>= 1;

      /* Now u and v are both odd, so diff(u, v) is even.
      Let u = min(u, v), v = diff(u, v)/2. */
      if (u < v) {
         v -= u;
      } else {
         unsigned int diff = u - v;
         u = v;
         v = diff;
      }
      v >>= 1;
   } while (v != 0);

   return u << shift;
}


bool mLineTriangleCollide( const Point3F &p1, const Point3F &p2, 
                           const Point3F &t1, const Point3F &t2, const Point3F &t3,
                           Point3F *outUVW, F32 *outT )
{
   VectorF ab = t2 - t1;
   VectorF ac = t3 - t1;
   VectorF qp = p1 - p2;

   // Compute triangle normal. Can be precalculated or cached if
   // intersecting multiple segments against the same triangle
   VectorF n = mCross( ab, ac );

   // Compute denominator d. If d <= 0, segment is parallel to or points
   // away from triangle, so exit early
   F32 d = mDot( qp, n );
   if ( d <= 0.0f ) 
      return false;

   // Compute intersection t value of pq with plane of triangle. A ray
   // intersects if 0 <= t. Segment intersects iff 0 <= t <= 1. Delay
   // dividing by d until intersection has been found to pierce triangle
   VectorF ap = p1 - t1;
   F32 t = mDot( ap, n );
   if ( t < 0.0f ) 
      return false;      
   if ( t > d ) 
      return false; // For segment; exclude this code line for a ray test

   // Compute barycentric coordinate components and test if within bounds
   VectorF e = mCross( qp, ap );
   F32 v = mDot( ac, e );
   if ( v < 0.0f || v > d )
      return false;
   F32 w = -mDot( ab, e );
   if ( w < 0.0f || v + w > d ) 
      return false;

   // Segment/ray intersects triangle. Perform delayed division and
   // compute the last barycentric coordinate component
   const F32 ood = 1.0f / d;
   
   if ( outT )
      *outT = t * ood;
      
   if ( outUVW )
   {
      v *= ood;
      w *= ood;
      outUVW->set( 1.0f - v - w, v, w );
   }

   return true;
}

bool mRayQuadCollide(   const Quad &quad, 
                        const Ray &ray, 
                        Point2F *outUV,
                        F32 *outT )
{
   static const F32 eps = F32(10e-6);

   // Rejects rays that are parallel to Q, and rays that intersect the plane of
   // Q either on the left of the line V00V01 or on the right of the line V00V10.

   //   p01-----eXX-----p11
   //   ^            . ^ |
   //   |          .     |
   //   e03     e02     eXX
   //   |    .           |
   //   |  .             |
   //   p00-----e01---->p10

   VectorF e01 = quad.p10 - quad.p00;
   VectorF e03 = quad.p01 - quad.p00;

   // If the ray is perfectly perpendicular to e03, which 
   // represents the entire planes tangent, then the 
   // result of this cross product (P) will equal e01
   // If it is parallel it will result in a vector opposite e01.

   // If the ray is heading DOWN the cross product will point to the RIGHT
   // If the ray is heading UP the cross product will point to the LEFT
   // We do not reject based on this though...
   //
   // In either case cross product will be more parallel to e01 the more
   // perpendicular the ray is to e03, and it will be more perpendicular to
   // e01 the more parallel it is to e03.
   VectorF P = mCross(ray.direction, e03);

   // det can be seen as 'the amount of vector e01 in the direction P'
   F32 det = mDot(e01, P);

   // Take a Abs of the dot because we do not care if the ray is heading up or down,
   // but if it is perfectly parallel to the quad we want to reject it.
   if ( mFabs(det) < eps ) 
      return false;

   F32 inv_det = 1.0f / det;

   VectorF T = ray.origin - quad.p00;

   // alpha can be seen as 'the amount of vector T in the direction P'
   // T is a vector up from the quads corner point 00 to the ray's origin.
   // P is the cross product of the ray and e01, which should be "roughly"
   // parallel with e03 but might be of either positive or negative magnitude.
   F32 alpha = mDot(T, P) * inv_det;
   if ( alpha < 0.0f ) 
      return false;

   // if (alpha > real(1.0)) return false; // Uncomment if VR is used.

   // The cross product of T and e01 should be roughly parallel to e03
   // and of either positive or negative magnitude.
   VectorF Q = mCross(T, e01);
   F32 beta = mDot(ray.direction, Q) * inv_det;
   if ( beta < 0.0f ) 
      return false; 

   // if (beta > real(1.0)) return false; // Uncomment if VR is used.

   if ( alpha + beta > 1.0f ) 
   //if ( false )
   {
      // Rejects rays that intersect the plane of Q either on the
      // left of the line V11V10 or on the right of the line V11V01.

      VectorF e23 = quad.p01 - quad.p11;
      VectorF e21 = quad.p10 - quad.p11;
      VectorF P_prime = mCross(ray.direction, e21);
      F32 det_prime = mDot(e23, P_prime);
      if ( mFabs(det_prime) < eps) 
         return false;
      F32 inv_det_prime = 1.0f / det_prime;
      VectorF T_prime = ray.origin - quad.p11;
      F32 alpha_prime = mDot(T_prime, P_prime) * inv_det_prime;
      if (alpha_prime < 0.0f) 
         return false;
      VectorF Q_prime = mCross(T_prime, e23);
      F32 beta_prime = mDot(ray.direction, Q_prime) * inv_det_prime;
      if (beta_prime < 0.0f) 
         return false;
   }

   // Compute the ray parameter of the intersection point, and
   // reject the ray if it does not hit Q.

   F32 t = mDot(e03, Q) * inv_det;
   if ( t < 0.0f ) 
      return false; 


   // Compute the barycentric coordinates of the fourth vertex.
   // These do not depend on the ray, and can be precomputed
   // and stored with the quadrilateral.  

   F32 alpha_11, beta_11;
   VectorF e02 = quad.p11 - quad.p00;
   VectorF n = mCross(e01, e03);

   if ( mFabs(n.x) >= mFabs(n.y) && 
      mFabs(n.x) >= mFabs(n.z) )
   {
      alpha_11 = ( e02.y * e03.z - e02.z * e03.y ) / n.x;
      beta_11  = ( e01.y * e02.z - e01.z * e02.y ) / n.x;
   }
   else if ( mFabs(n.y) >= mFabs(n.x) && 
      mFabs(n.y) >= mFabs(n.z) ) 
   {  
      alpha_11 = ((e02.z * e03.x) - (e02.x * e03.z)) / n.y;
      beta_11  = ((e01.z * e02.x) - (e01.x * e02.z)) / n.y;
   }
   else 
   {
      alpha_11 = ((e02.x * e03.y) - (e02.y * e03.x)) / n.z;
      beta_11  = ((e01.x * e02.y) - (e01.y * e02.x)) / n.z;
   }

   // Compute the bilinear coordinates of the intersection point.

   F32 u,v;

   if ( mFabs(alpha_11 - 1.0f) < eps) 
   {    
      // Q is a trapezium.
      u = alpha;
      if ( mFabs(beta_11 - 1.0f) < eps) 
         v = beta; // Q is a parallelogram.
      else 
         v = beta / ((u * (beta_11 - 1.0f)) + 1.0f); // Q is a trapezium.
   }
   else if ( mFabs(beta_11 - 1.0f) < eps) 
   {
      // Q is a trapezium.
      v = beta;
      u = alpha / ((v * (alpha_11 - 1.0f)) + 1.0f);
   }
   else 
   {
      F32 A = 1.0f - beta_11;
      F32 B = (alpha * (beta_11 - 1.0f))
         - (beta * (alpha_11 - 1.0f)) - 1.0f;
      F32 C = alpha;
      F32 D = (B * B) - (4.0f * A * C);
      F32 Q = -0.5f * (B + (B < 0.0f ? -1.0f : 1.0f) ) * mSqrt(D);
      u = Q / A;
      if ((u < 0.0f) || (u > 1.0f)) u = C / Q;
      v = beta / ((u * (beta_11 - 1.0f)) + 1.0f); 
   }

   if ( outUV )
      outUV->set( u, v );  
   if ( outT )
      *outT = t;

   return true;  
}

//Enhanced Projectiles
F32 getArea( const Point3F* verts, S32 count )
{
	// Vector whose length will be area^2.
	Point3F vec( 0, 0, 0 );
	for ( S32 i = 0; i < count; i++ ) {

      S32 j = i ? i - 1 : count - 1;

      // Add cross_product(pnts[j],pnts[i]).
		vec.x += verts[j].y * verts[i].z - verts[j].z * verts[i].y;
		vec.y += verts[j].z * verts[i].x - verts[j].x * verts[i].z;
		vec.z += verts[j].x * verts[i].y - verts[j].y * verts[i].x;
	}
   
	// Find length of vector, return it.
	return mSqrt( vec.x * vec.x + vec.y * vec.y + vec.z * vec.z ) / 2.0f;
}

Point3F getBarrycentricCoord( const Point3F& point, const Point3F* tri )
{
	// If the area of the triangle is zero... return 0.
	const F32 a = getArea( tri, 3 );

	if ( a <= 0.0f )
      return Point3F( 0, 0, 0 );

	Point3F b;
	{
      Point3F temp[3] =
      {
         tri[1],
         tri[2],
         point
      };
		b.x = getArea( temp, 3 ) / a;
	}
	{
      Point3F temp[3] =
      {
         tri[2],
         tri[0],
         point
      };
		b.y = getArea( temp, 3 ) / a;
	}
	{
      Point3F temp[3] =
      {
         tri[0],
         tri[1],
         point
      };
		b.z = getArea( temp, 3 ) / a;
	}

   return b;
}

bool rayTriangleIntersect( const Point3F& orig, const Point3F& dir,
   const Point3F& vert0, const Point3F& vert1, const Point3F& vert2,
   F32 *t, F32 *u, F32 *v )
{
   const F32 EPSILON = __EQUAL_CONST_F;

   /* find vectors for two edges sharing vert0 */
   Point3F edge1( vert1 -  vert0 );
   Point3F edge2( vert2 -  vert0 );

   /* begin calculating determinant - also used to calculate U parameter */
   Point3F pvec( mCross( dir, edge2 ) );

   /* if determinant is near zero, ray lies in plane of triangle */
   F32 det = mDot( edge1, pvec );

   if (det < EPSILON)
      return 0;

   /* calculate distance from vert0 to ray origin */
   Point3F tvec( orig - vert0 );

   /* calculate U parameter and test bounds */
   *u = mDot( tvec, pvec );
   if (*u < 0.0 || *u > det)
      return false;

   /* prepare to test V parameter */
   Point3F qvec( mCross( tvec, edge1 ) );

   /* calculate V parameter and test bounds */
   *v = mDot( dir, qvec );
   if (*v < 0.0 || *u + *v > det)
      return false;

   /* calculate t, scale parameters, ray intersects triangle */
   F32 inv_det = 1.0 / det;
   *t = mDot( edge2, qvec ) * inv_det;
   *u *= inv_det;
   *v *= inv_det;

   return true;
}
//Enhanced Projectiles

} // end namespace MathUtils
