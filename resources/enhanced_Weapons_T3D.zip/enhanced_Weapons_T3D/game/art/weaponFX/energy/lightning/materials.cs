//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Custom Materials
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Materials
//-----------------------------------------------------------------------------
new Material( lightning1F1_Mat )
{
   mapTo = "lightning1F1";
   baseTex[0] = "scriptsAndAssets/data/fx/weaponFX/energy/lightning/lightning1F1.png";
   translucent = true;
};

new Material( lightning1F2_Mat )
{
   mapTo = "lightning1F2";
   baseTex[0] = "scriptsAndAssets/data/fx/weaponFX/energy/lightning/lightning1F2.png";
   translucent = true;
};

new Material( lightning1F3_Mat )
{
   mapTo = "lightning1F3";
   baseTex[0] = "scriptsAndAssets/data/fx/weaponFX/energy/lightning/lightning1F3.png";
   translucent = true;
};