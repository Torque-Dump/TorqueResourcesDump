//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

// Load up all scripts.  This function is called when
// a server is constructed.
exec("./camera.cs");
exec("./markers.cs");
exec("./triggers.cs");
exec("./rigidShape.cs");
exec("./fxlights.cs");
exec("./car.cs");
exec("./inventory.cs");
exec("./shapeBase.cs");
exec("./staticShape.cs");
exec("./radiusDamage.cs");
exec("./item.cs");

// Load our supporting weapon script
exec("./weapons/weapon.cs");

   //Enhanced Weapons System
   exec("./weapons/missleLockOnSystem.cs");
   exec("./weapons/weaponDecals.cs");
   exec("./weapons/medWeaponExplosions.cs");
   exec("./weapons/EnergyExperiments.cs");

// Load our weapon scripts
// Note: if you add a new weapon and you want it
// to show up in the weapon picker then be sure to add
// your exec's to loadWeaponPickerData() over in
// <$defaultGame>/client/init.cs
exec("./weapons/SwarmGun.cs");
exec("./weapons/spaceRifle.cs");

// Load our default player script
exec("./players/player.cs");