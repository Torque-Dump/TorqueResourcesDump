//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//General Weapon decals for use in all weapons
//-----------------------------------------------------------------------------
//Wrap Test Decals
datablock DecalData(wrapTestDecal)
{
   sizeX       = 0.5;
   sizeY       = 0.5;
   textureName = "art/decals/wraptest.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

//-----------------------------------------------------------------------------
//Small caliber weapon decals
//-----------------------------------------------------------------------------
//Generic Decals
datablock DecalData(smallGenericDecal1)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletgeneric1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallGenericDecal2)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletgeneric1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallGenericDecal3)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletgeneric1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallGenericDecal4)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletgeneric1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
//Terrain Decals
datablock DecalData(smallTerrainDecal1)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletterrain1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallTerrainDecal2)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletterrain1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallTerrainDecal3)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletterrain1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallTerrainDecal4)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletterrain1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};


//Concrete Decals
datablock DecalData(smallConcreteDecal1)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletconcrete1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallConcreteDecal2)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletconcrete1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallConcreteDecal3)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletconcrete1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallConcreteDecal4)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletconcrete1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

//Metal Decals
datablock DecalData(smallMetalDecal1)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletmetal1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallMetalDecal2)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletmetal1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallMetalDecal3)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletmetal1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallMetalDecal4)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletmetal1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

//Wood Decals
datablock DecalData(smallWoodDecal1)
{
   sizeX       = 0.025;
   sizeY       = 0.025;
   textureName = "art/decals/bulletwood1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallWoodDecal2)
{
   sizeX       = 0.025;
   sizeY       = 0.025;
   textureName = "art/decals/bulletwood1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallWoodDecal3)
{
   sizeX       = 0.025;
   sizeY       = 0.025;
   textureName = "art/decals/bulletwood1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallWoodDecal4)
{
   sizeX       = 0.025;
   sizeY       = 0.025;
   textureName = "art/decals/bulletwood1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};


//Glass Decals
datablock DecalData(smallGlassDecal1)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/glass_bullet1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallGlassDecal2)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/glass_bullet1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallGlassDecal3)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/glass_bullet1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallGlassDecal4)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/glass_bullet1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(smallGlassDecal5)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/glass_bullet1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

/*
//Human Decals
datablock DecalData(smallBloodDecal1)
{
   sizeX       = 0.25;
   sizeY       = 0.25;
   textureName = "art/decals/blood/blood1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
datablock DecalData(smallBloodDecal2)
{
   sizeX       = 0.25;
   sizeY       = 0.25;
   textureName = "art/decals/blood/blood2.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
datablock DecalData(smallBloodDecal3)
{
   sizeX       = 0.25;
   sizeY       = 0.25;
   textureName = "art/decals/blood/blood3.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
datablock DecalData(smallBloodDecal4)
{
   sizeX       = 0.25;
   sizeY       = 0.25;
   textureName = "art/decals/blood/blood4.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
datablock DecalData(smallBloodDecal5)
{
   sizeX       = 0.25;
   sizeY       = 0.25;
   textureName = "art/decals/blood/blood5.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
datablock DecalData(smallBloodDecal6)
{
   sizeX       = 0.25;
   sizeY       = 0.25;
   textureName = "art/decals/blood/blood6.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
*/
//-----------------------------------------------------------------------------
//Medium caliber weapon decals
//-----------------------------------------------------------------------------

//Generic Decals
datablock DecalData(medGenericDecal1)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletgeneric1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medGenericDecal2)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletgeneric1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medGenericDecal3)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletgeneric1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medGenericDecal4)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletgeneric1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
//Terrain Decals
datablock DecalData(medTerrainDecal1)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletterrain1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medTerrainDecal2)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletterrain1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medTerrainDecal3)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletterrain1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medTerrainDecal4)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletterrain1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};


//Concrete Decals
datablock DecalData(medConcreteDecal1)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletconcrete1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medConcreteDecal2)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletconcrete1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medConcreteDecal3)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletconcrete1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medConcreteDecal4)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletconcrete1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

//Metal Decals
datablock DecalData(medMetalDecal1)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletmetal1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medMetalDecal2)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletmetal1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medMetalDecal3)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletmetal1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medMetalDecal4)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletmetal1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

//Wood Decals
datablock DecalData(medWoodDecal1)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletwood1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medWoodDecal2)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletwood1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medWoodDecal3)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletwood1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medWoodDecal4)
{
   sizeX       = 0.05;
   sizeY       = 0.05;
   textureName = "art/decals/bulletwood1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};


//Glass Decals
datablock DecalData(medGlassDecal1)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/glass_bullet1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medGlassDecal2)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/glass_bullet1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medGlassDecal3)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/glass_bullet1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medGlassDecal4)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/glass_bullet1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(medGlassDecal5)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/glass_bullet1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

/*
//Human Decals
datablock DecalData(medBloodDecal1)
{
   sizeX       = 0.5;
   sizeY       = 0.5;
   textureName = "art/decals/blood/blood1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
datablock DecalData(medBloodDecal2)
{
   sizeX       = 0.5;
   sizeY       = 0.5;
   textureName = "art/decals/blood/blood2.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
datablock DecalData(medBloodDecal3)
{
   sizeX       = 0.5;
   sizeY       = 0.5;
   textureName = "art/decals/blood/blood3.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
datablock DecalData(medBloodDecal4)
{
   sizeX       = 0.5;
   sizeY       = 0.5;
   textureName = "art/decals/blood/blood4.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
datablock DecalData(medBloodDecal5)
{
   sizeX       = 0.5;
   sizeY       = 0.5;
   textureName = "art/decals/blood/blood5.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
datablock DecalData(medBloodDecal6)
{
   sizeX       = 0.5;
   sizeY       = 0.5;
   textureName = "art/decals/blood/blood6.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
*/
//-----------------------------------------------------------------------------
//Large caliber weapon decals
//-----------------------------------------------------------------------------

//Generic Decals
datablock DecalData(largeGenericDecal1)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletgeneric1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeGenericDecal2)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletgeneric1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeGenericDecal3)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletgeneric1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeGenericDecal4)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletgeneric1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
//Terrain Decals
datablock DecalData(largeTerrainDecal1)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletterrain1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeTerrainDecal2)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletterrain1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeTerrainDecal3)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletterrain1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeTerrainDecal4)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletterrain1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};


//Concrete Decals
datablock DecalData(largeConcreteDecal1)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletconcrete1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeConcreteDecal2)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletconcrete1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeConcreteDecal3)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletconcrete1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeConcreteDecal4)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletconcrete1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

//Metal Decals
datablock DecalData(largeMetalDecal1)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletmetal1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeMetalDecal2)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletmetal1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeMetalDecal3)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletmetal1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeMetalDecal4)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/bulletmetal1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

//Wood Decals
datablock DecalData(largeWoodDecal1)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletwood1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeWoodDecal2)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletwood1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeWoodDecal3)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletwood1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeWoodDecal4)
{
   sizeX       = 0.1;
   sizeY       = 0.1;
   textureName = "art/decals/bulletwood1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};


//Glass Decals
datablock DecalData(largeGlassDecal1)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/glass_bullet1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeGlassDecal2)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/glass_bullet1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

datablock DecalData(largeGlassDecal3)
{
   sizeX       = 0.2;
   sizeY       = 0.2;
   textureName = "art/decals/glass_bullet1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};

/*
//Human Decals
datablock DecalData(largeBloodDecal1)
{
   sizeX       = 0.5;
   sizeY       = 0.5;
   textureName = "art/decals/blood/blood1.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
datablock DecalData(largeBloodDecal2)
{
   sizeX       = 0.5;
   sizeY       = 0.5;
   textureName = "art/decals/blood/blood2.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
datablock DecalData(largeBloodDecal3)
{
   sizeX       = 0.5;
   sizeY       = 0.5;
   textureName = "art/decals/blood/blood3.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
datablock DecalData(largeBloodDecal4)
{
   sizeX       = 0.5;
   sizeY       = 0.5;
   textureName = "art/decals/blood/blood4.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
datablock DecalData(largeBloodDecal5)
{
   sizeX       = 0.5;
   sizeY       = 0.5;
   textureName = "art/decals/blood/blood5.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
datablock DecalData(largeBloodDecal6)
{
   sizeX       = 0.5;
   sizeY       = 0.5;
   textureName = "art/decals/blood/blood6.png";
   //Overrides general timeout value
   //LifeSpan    = 300000;
};
*/
//-----------------------------------------------------------------------------
//Large bomb weapon decals
//-----------------------------------------------------------------------------

//Terrain Decals


//Water Decals


//Metal Decals


//Wood Decals


//Glass Decals


//Human Decals


