//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

function RocketLauncherImage::onFire(%this, %obj, %slot)
{
   %projectile = %this.projectile;

   // Determine initial projectile velocity based on the
   // gun's muzzle point and the object's current velocity
   %muzzleVector = %obj.getMuzzleVector(%slot);
   %objectVelocity = %obj.getVelocity();
   %muzzleVelocity = VectorAdd(
      VectorScale(%muzzleVector, %projectile.muzzleVelocity),
      VectorScale(%objectVelocity, %projectile.velInheritFactor));

   // Create the projectile object
   %p = new (%this.projectileType)() {
      dataBlock        = %projectile;
      initialVelocity  = %muzzleVelocity;
      initialPosition  = %obj.getMuzzlePoint(%slot);
      sourceObject     = %obj;
      sourceSlot       = %slot;
      client           = %obj.client;
      isArmorPiercing  = false;
      wrappedDecalsMode = false;
      target           = %obj.client.targetedObject;
   };

   MissionCleanup.add(%p);
   return %p;
}

function RocketLauncherImage::onDryFire(%this, %obj, %slot)
{
   error("No ammo!");
}
