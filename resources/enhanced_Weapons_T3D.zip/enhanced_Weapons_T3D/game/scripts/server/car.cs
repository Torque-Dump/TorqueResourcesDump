//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

function WheeledVehicleData::create(%block)
{
   %obj = new WheeledVehicle() {
      dataBlock = %block;
   };
   return(%obj);
}

function WheeledVehicleData::onAdd(%this,%obj)
{
   %obj.mountable = true;
   
   // Setup the car with some defaults tires & springs
   for (%i = %obj.getWheelCount() - 1; %i >= 0; %i--) {
      %obj.setWheelTire(%i,DefaultCarTire);
      %obj.setWheelSpring(%i,DefaultCarSpring);
      %obj.setWheelPowered(%i,false);
   }
   
   // Steer front tires
   %obj.setWheelSteering(0,1);
   %obj.setWheelSteering(1,1);

   // Only power the two rear wheels...
   %obj.setWheelPowered(2,true);
   %obj.setWheelPowered(3,true);
}

function WheeledVehicleData::onCollision(%this,%obj,%col,%vec,%speed)
{
   // Collision with other objects, including items
   %pos = %obj.getWorldBoxCenter();
   %impulseVec = VectorSub(%pos, %col.getWorldBoxCenter());
   %impulseVec = VectorNormalize(%impulseVec);
   %impulseVec = VectorScale(%impulseVec, 40);

   if(%col.getType() & $TypeMasks::ShapeBaseObjectType)
   {
      %col.applyImpulse(%pos, %impulseVec);
   }
}   

// Used to kick the players out of the car that your crosshair is over
function serverCmdcarUnmountObj(%client, %obj)
{
   %obj.unmount();
   %obj.setControlObject(%obj);

   %ejectpos = %obj.getPosition();
   %ejectpos = VectorAdd(%ejectpos, "0 0 5");
   %obj.setTransform(%ejectpos);

   %ejectvel = %obj.mVehicle.getVelocity();
   %ejectvel = VectorAdd(%ejectvel, "0 0 10");
   %ejectvel = VectorScale(%ejectvel, %obj.getDataBlock().mass);
   %obj.applyImpulse(%ejectpos, %ejectvel);
}

// Used to flip the car over if it manages to get stuck upside down
function serverCmdflipCar(%client)
{
   %car = %client.getControlObject();

   if (%car.getClassName() $= "WheeledVehicle")
   {
      %carPos = %car.getPosition();
      %carPos = VectorAdd(%carPos, "0 0 3");

      %car.setTransform(%carPos SPC "0 0 1 0");
   }
}

function serverCmdsetPlayerControl(%client)
{
     %client.setControlObject(%client.player);
}