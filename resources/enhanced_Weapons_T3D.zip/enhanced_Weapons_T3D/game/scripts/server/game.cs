//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// What kind of "player" is spawned is either controlled directly by the
// SpawnSphere or it defaults back to the values set here. This also controls
// which SimGroups to attempt to select the spawn sphere's from by walking down
// the list of SpawnGroups till it finds a valid spawn object.
// These override the values set in core/scripts/server/spawn.cs
//-----------------------------------------------------------------------------
$Game::DefaultPlayerClass = "Player";
$Game::DefaultPlayerDataBlock = "BoomBotData";
$Game::DefaultPlayerSpawnGroups = "PlayerSpawnPoints PlayerDropPoints";

//-----------------------------------------------------------------------------
// What kind of "camera" is spawned is either controlled directly by the
// SpawnSphere or it defaults back to the values set here. This also controls
// which SimGroups to attempt to select the spawn sphere's from by walking down
// the list of SpawnGroups till it finds a valid spawn object.
// These override the values set in core/scripts/server/spawn.cs
//-----------------------------------------------------------------------------
$Game::DefaultCameraClass = "Camera";
$Game::DefaultCameraDataBlock = "Observer";
$Game::DefaultCameraSpawnGroups = "CameraSpawnPoints PlayerSpawnPoints PlayerDropPoints";

//-----------------------------------------------------------------------------
// GameConnection manages the communication between the server's world and the
// client's simulation. These functions are responsible for maintaining the
// client's camera and player objects.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// This is the main entry point for spawning a control object for the client.
// The control object is the actual game object that the client is responsible
// for controlling in the client and server simulations. We also spawn a
// convenient camera object for use as an alternate control object. We do not
// have to spawn this camera object in order to function in the simulation.
//
// Called for each client after it's finished downloading the mission and is
// ready to start playing.
//-----------------------------------------------------------------------------
function GameConnection::onClientEnterGame(%this)
{
   // This function currently relies on some helper functions defined in
   // core/scripts/server/spawn.cs. For custom spawn behaviors one can either
   // override the properties on the SpawnSphere's or directly override the
   // functions themselves.

   // Sync the client's clocks to the server's
   commandToClient(%this, 'SyncClock', $Sim::Time - $Game::StartTime);

   // Start everyone with a zero score when they connect
   %this.score = 0;

   // Find a spawn point for the camera
   %cameraSpawnPoint = pickCameraSpawnPoint($Game::DefaultCameraSpawnGroups);
   // Spawn a camera for this client using the found %spawnPoint
   %this.spawnCamera(%cameraSpawnPoint);

   // Find a spawn point for the player
   %playerSpawnPoint = pickPlayerSpawnPoint($Game::DefaultPlayerSpawnGroups);
   // Spawn a camera for this client using the found %spawnPoint
   %this.spawnPlayer(%playerSpawnPoint);

   %this.player.setInventory(RocketLauncher, 1);
   %this.player.setInventory(RocketLauncherAmmo, %this.player.maxInventory(RocketLauncherAmmo));
   %this.player.mountImage(RocketLauncherImage, 0);
}

// Need to prepare the player for spawning for proper re-spawns.  Mainly this
// means finding a spawn point and passing that into spawnPlayer(), which is a
// helper function defined in core/scripts/server/spawn.cs.  This would also be
// a good place to give the player some starting equipment.
function GameConnection::preparePlayer(%this)
{
   // Find a spawn point for the player
   %playerSpawnPoint = pickPlayerSpawnPoint($Game::DefaultPlayerSpawnGroups);

   // Spawn a player/camera for this client using the found %spawnPoint
   %this.spawnPlayer(%playerSpawnPoint);

   // Could setup starting equipment here
   %this.player.setInventory(RocketLauncher, 1);
   %this.player.setInventory(RocketLauncherAmmo, %this.player.maxInventory(RocketLauncherAmmo));
   %this.player.mountImage(RocketLauncherImage, 0);
}

//-----------------------------------------------------------------------------
// Clean up the client's control objects
//-----------------------------------------------------------------------------
function GameConnection::onClientLeaveGame(%this)
{
   // Cleanup the camera
   if (isObject(%this.camera))
      %this.camera.delete();
   // Cleanup the player
   if (isObject(%this.player))
      %this.player.delete();
}

//-----------------------------------------------------------------------------
// Handle a player's death
//-----------------------------------------------------------------------------
function GameConnection::onDeath(%this, %sourceObject, %sourceClient, %damageType, %damLoc)
{
   // Clear out the name on the corpse
   if (isObject(%this.player))
   {
      if (%this.player.isMethod("setShapeName"))
         %this.player.setShapeName("");
   }

    // Switch the client over to the death cam
    if (isObject(%this.camera) && isObject(%this.player))
    {
        %this.camera.setMode("Corpse", %this.player);
        %this.setControlObject(%this.camera);
    }

    // Unhook the player object
    %this.player = 0;

   // Doll out points and display an appropriate message
   if (%damageType $= "Suicide" || %sourceClient == %this)
   {
      %this.incScore(-1);
      messageAll('MsgClientKilled', '%1 takes his own life!', %this.name);
   }
   else
   {
      %sourceClient.incScore(1);
      messageAll('MsgClientKilled', '%1 gets nailed by %2!', %this.name, %sourceClient.name);
      if (%sourceClient.score >= $Game::EndGameScore)
         cycleGame();
   }
}

//-----------------------------------------------------------------------------
//  Server, mission, and game management
//-----------------------------------------------------------------------------

// Game duration in secs, no limit if the duration is set to 0
$Game::Duration = 0;

// When a client score reaches this value, the game is ended.
$Game::EndGameScore = 30;

// Pause while looking over the end game screen (in secs)
$Game::EndGamePause = 10;

//-----------------------------------------------------------------------------
// The server has started up so do some game start up
//-----------------------------------------------------------------------------
function onServerCreated()
{
   // Server::GameType is sent to the master server.
   // This variable should uniquely identify your game and/or mod.
   $Server::GameType = "Torque 3D 2009";

   // Server::MissionType sent to the master server.  Clients can
   // filter servers based on mission type.
   $Server::MissionType = "Template";

   // GameStartTime is the sim time the game started. Used to calculated
   // game elapsed time.
   $Game::StartTime = 0;

   // Create the server physics world.
   physicsInitWorld( "server" );

   // Load up all datablocks, objects etc.  This function is called when
   // a server is constructed.
   exec("art/datablocks/datablockExec.cs");
   exec("./scriptExec.cs");

   // Keep track of when the game started
   $Game::StartTime = $Sim::Time;
}

//-----------------------------------------------------------------------------
// This function is called as part of a server shutdown
//-----------------------------------------------------------------------------
function onServerDestroyed()
{
   // Destroy the server physcis world
   physicsDestroyWorld( "server" );
}

//-----------------------------------------------------------------------------
// Called by loadMission() once the mission is finished loading
//-----------------------------------------------------------------------------
function onMissionLoaded()
{
   // Start the server side physics simulation
   physicsStartSimulation( "server" );

   // Nothing special for now, just start up the game play
   startGame();
}

//-----------------------------------------------------------------------------
// Called by endMission(), right before the mission is destroyed
//-----------------------------------------------------------------------------
function onMissionEnded()
{
   // Stop the server physics simulation
   physicsStopSimulation( "server" );

   // Inform the client the game is over
   for( %clientIndex = 0; %clientIndex < ClientGroup.getCount(); %clientIndex++ ) {
      %cl = ClientGroup.getObject( %clientIndex );
      commandToClient(%cl, 'CancelTargetingCycle');
   }

   // Normally the game should be ended first before the next
   // mission is loaded, this is here in case loadMission has been
   // called directly.  The mission will be ended if the server
   // is destroyed, so we only need to cleanup here.
   cancel($Game::Schedule);
   $Game::Running = false;
   $Game::Cycling = false;
}

//-----------------------------------------------------------------------------
// Called once the game has started
//-----------------------------------------------------------------------------
function startGame()
{
    if ($Game::Running)
    {
        error("startGame(): End the game first!");
        return;
    }

    // Inform the client we're starting up
    for(%clientIndex = 0; %clientIndex < ClientGroup.getCount(); %clientIndex++)
    {
        %cl = ClientGroup.getObject(%clientIndex);
        commandToClient(%cl, 'GameStart');

        // Other client specific setup..
        %cl.score = 0;
    }

    // Start the game timer
    if ($Game::Duration)
        $Game::Schedule = schedule($Game::Duration * 1000, 0, "onGameDurationEnd");
    $Game::Running = true;

   // Start the AIManager
   new ScriptObject(AIManager) {};
   MissionCleanup.add(AIManager);
   AIManager.think();
}

//-----------------------------------------------------------------------------
// Called once the game has ended
//-----------------------------------------------------------------------------
function endGame()
{
   if (!$Game::Running)
   {
      error("endGame(): No game running!");
      return;
   }

   // Stop the AIManager
   AIManager.delete();

   // Stop any game timers
   cancel($Game::Schedule);

   // Inform the client the game is over
   for( %clientIndex = 0; %clientIndex < ClientGroup.getCount(); %clientIndex++ )
   {
      %cl = ClientGroup.getObject( %clientIndex );
      commandToClient(%cl, 'GameEnd');
   }

   // Delete all the temporary mission objects
   resetMission();
   $Game::Running = false;
}

//-----------------------------------------------------------------------------
// This "redirect" is here so that we can abort the game cycle if the
// $Game::Duration variable has been cleared, without having to have a function
// to cancel the schedule.
//-----------------------------------------------------------------------------
function onGameDurationEnd()
{
   // If the game duration has been reached then cycle the level
   if ($Game::Duration && !isObject(EditorGui))
      cycleGame();
}

//-----------------------------------------------------------------------------
// This is setup as a schedule so that this function can be called directly
// from object callbacks. Object callbacks have to be carefull about invoking
// server functions that could cause their object to be deleted.
//-----------------------------------------------------------------------------
function cycleGame()
{
   // If we aren't already cycling the cycle the game
   if (!$Game::Cycling)
   {
      $Game::Cycling = true;
      $Game::Schedule = schedule(0, 0, "onCycleExec");
   }
}

//-----------------------------------------------------------------------------
// End the current game and start another one, we'll pause for a little so the
// end game victory screen can be examined by the clients.
//-----------------------------------------------------------------------------
function onCycleExec()
{
   endGame();
   $Game::Schedule = schedule($Game::EndGamePause * 1000, 0, "onCyclePauseEnd");
}

//-----------------------------------------------------------------------------
// Done pausing for the end game screen then cycle to the next level
//-----------------------------------------------------------------------------
function onCyclePauseEnd()
{
   $Game::Cycling = false;

   // Just cycle through the missions for now.
   %search = $Server::MissionFileSpec;

   for (%file = findFirstFile(%search); %file !$= ""; %file = findNextFile(%search))
   {
      if (%file $= $Server::MissionFile)
      {
         // Get the next one, back to the first if there is no next.
         %file = findNextFile(%search);

         if (%file $= "")
            %file = findFirstFile(%search);

         break;
      }
   }

   loadMission(%file);
}
