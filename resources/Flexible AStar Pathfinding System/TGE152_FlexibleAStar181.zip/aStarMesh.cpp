#include "game/aStar.h"
#include "console/consoleTypes.h"
#include "core/bitStream.h"
#include "sceneGraph/sceneGraph.h"
#include "sceneGraph/sgUtil.h"
#include "sceneGraph/sceneState.h"
#include "dgl/dgl.h"

//---------------------------------------------------------//
//                   Misc NavMesh Stuff                    //
//---------------------------------------------------------//

#define STEP_HEIGHT 0.4f

IMPLEMENT_CO_NETOBJECT_V1(NavMesh);

extern bool gEditingMission;

NavMesh::NavMesh()
{
   mTypeMask |= StaticObjectType;
   mNetFlags.set(Ghostable);
   interval = 3;
   xSize = 2;
   ySize = 2;
   height = 8;
   first = last = 0;
}

NavMesh::~NavMesh()
{
}

void NavMesh::consoleInit()
{
    Con::addVariable("$pref::AStar::Clearence", TypeF32, &(AStar::Get()->clearence));
}

void NavMesh::initPersistFields()
{
	Parent::initPersistFields();
    addField( "Interval",		TypeF32,		Offset( interval,			NavMesh ) );
    addField( "XSize",	    	TypeS32,		Offset( xSize,  			NavMesh ) );
    addField( "YSize",	    	TypeS32,		Offset( ySize,  			NavMesh ) );
    addField( "Height",	    	TypeF32,		Offset( height, 			NavMesh ) );
}

bool NavMesh::onAdd()
{
	if(!Parent::onAdd()) return(false);
    F32 x = (interval*((F32)xSize-1))/2;
    F32 y = (interval*((F32)ySize-1))/2;
	mObjBox.min.set( -x, -y, -(height/2));
	mObjBox.max.set(  x, y, height/2);
	resetWorldBox();
	setRenderTransform(mObjToWorld);
	addToScene();
    oldBox = mWorldBox;
    if (isServerObject())
        AStar::Get()->addMesh(this);
	return(true);
}

void NavMesh::onRemove()
{
	removeFromScene();
	Parent::onRemove();
    if (isServerObject() || gEditingMission)
        AStar::Get()->removeMesh(this);
}

void NavMesh::inspectPostApply()
{
	Parent::inspectPostApply();
	setMaskBits(NavMeshMask);
    if (oldBox.min != mWorldBox.min || oldBox.max != mWorldBox.max)
    {
        oldBox = mWorldBox;
        AStar::Get()->addMesh(this);
        AStar::Get()->reset();
    }
}

void NavMesh::onEditorEnable()
{
}

void NavMesh::onEditorDisable()
{
}

U32 NavMesh::packUpdate(NetConnection * con, U32 mask, BitStream * stream)
{
	U32 retMask = Parent::packUpdate(con, mask, stream);
	if (stream->writeFlag(mask & NavMeshMask))
	{
		stream->writeAffineTransform(mObjToWorld);
		stream->write(interval);
        stream->write(xSize);
        stream->write(ySize);
        stream->write(height);

        F32 x = (interval*((F32)xSize-1))/2;
        F32 y = (interval*((F32)ySize-1))/2;
	    mObjBox.min.set( -x, -y, -(height/2));
	    mObjBox.max.set(  x, y, height/2);
	    resetWorldBox();
	    setRenderTransform(mObjToWorld);
	}
	return(retMask);
}

void NavMesh::unpackUpdate(NetConnection * con, BitStream * stream)
{
	Parent::unpackUpdate(con, stream);

	if(stream->readFlag())
	{
		MatrixF		ObjectMatrix;
		stream->readAffineTransform(&ObjectMatrix);
		stream->read(&interval);
		stream->read(&xSize);
		stream->read(&ySize);
        stream->read(&height);
		setTransform(ObjectMatrix);

        F32 x = (interval*((F32)xSize-1))/2;
        F32 y = (interval*((F32)ySize-1))/2;
	    mObjBox.min.set( -x, -y, -(height/2));
	    mObjBox.max.set(  x, y, height/2);
	    resetWorldBox();
	    setRenderTransform(mObjToWorld);
	}
}

//---------------------------------------------------------//
//                  Mesh/Point Management                  //
//---------------------------------------------------------//

void AStar::removeMesh (NavMesh *mesh)
{
    if (meshes.empty())
        return; //wtflol?

    if (!mesh->first) //sanity check
        return;

    S32 i;
    for (i = 0; i < meshes.size(); ++i)
    {
        if (meshes[i] == mesh)
        {
            meshes.erase(i);
            break;
        }
    }
            
    if (mesh->first == list && !mesh->last->next) //only in list
        list = 0;
    else if (mesh->first == list) //first in list
        list = mesh->last->next;
    else //also works for last b/c mesh->last->next == 0
        mesh->first->prev->next = mesh->last->next; //lol

    if (mesh->last->next)
        mesh->last->next->prev = mesh->first->prev;

    NMPoint * delpt = mesh->first;
    NMPoint * delnext;

    while (1)
    {
        delnext = delpt->next;
        delete delpt;
        --points;
        if (delpt == mesh->last)
            break;
        delpt = delnext;
    }
    mesh->first = mesh->last = 0;

    reset();
}

void AStar::addMesh (NavMesh *mesh)
{
    processMesh(mesh);
}

void AStar::processMesh (NavMesh *mesh)
{
    NavMesh* itr;

    //cleanup
    if (!meshes.empty()) {
    for (S32 i = 0; i < meshes.size(); ++i)
    {
        itr = meshes[i];
        if (itr == mesh)
        {
            meshes.erase(i);

            if (!mesh->first) //sanity check
                continue;
            
            if (mesh->first == list && !mesh->last->next) //only in list
                list = 0;
            else if (mesh->first == list) //first in list
                list = mesh->last->next;
            else //also works for last b/c mesh->last->next == 0
                mesh->first->prev->next = mesh->last->next; //lol

            if (mesh->last->next)
                mesh->last->next->prev = mesh->first->prev;

            NMPoint * delpt = mesh->first;
            NMPoint * delnext;
            while (1)
            {
                delnext = delpt->next;
                delete delpt;
                --points;
                if (delpt == mesh->last)
                    break;
                delpt = delnext;
            }
            mesh->first = mesh->last = 0;
        }
    }
    }
    meshes.push_front(mesh);

    //add points
    Point3F wpt;
    NMPoint * newPt = 0;
    RayInfo rInfo;

    bool first = true;

    for (S32 j = 0; j < mesh->ySize; j++)
    {
        for (S32 i = 0; i < mesh->xSize; i++)
        {
            wpt.set(((F32)i - ((F32)mesh->xSize-1)/2)*mesh->interval, ((F32)j - ((F32)mesh->ySize-1)/2)*mesh->interval, mesh->height/2);
            mesh->mObjToWorld.mulP(wpt);
            if (!gServerContainer.castRay(wpt, Point3F(wpt.x, wpt.y, wpt.z - mesh->height), STATIC_COLLISION_MASK, &rInfo))
                continue;
            if (gServerContainer.castRay(rInfo.point + Point3F(0, 0, 2), rInfo.point + Point3F(0, 0, 0.01f), STATIC_COLLISION_MASK, &rInfo))
                continue;
            ++points;
            wpt = rInfo.point;
            wpt += Point3F(0, 0, 1); //move it off the ground a bit
            newPt = new NMPoint();
            dMemset(newPt, 0, sizeof(*newPt)); //friggin contructor doesnt work right
            newPt->loc = wpt;
            newPt->mesh = mesh;
			   newPt->interval = mesh->interval;
            if (list)
                list->prev = newPt;
            if (first) {
                mesh->last = newPt; first = false; } //b/c they're added in reverse order
            newPt->next = list;
            list = newPt;
        }
    }
    mesh->first = newPt;

	 Con::errorf("ADDING MESH");
}

ConsoleFunction(BuildPaths, void, 1, 1, "()")
{
    AStar::Get()->reset();
	 //AStar::Get()->linkMeshes();
}

void AStar::linkMeshes ()
{
    NMPoint* cur;
    NMPoint* tmp;
    Point2F tmpVec;
    int direc;
    RayInfo rInfo;
    Point3F yVec;
    Point3F offset;
    Point3F step(0,0,1.f-STEP_HEIGHT);

    int nodes = 0;
    
    sortVec.clear();

    const S32 time = Platform::getRealMilliseconds();

    for (cur = list; cur; cur = cur->next)
        cur->adjs[0] = cur->adjs[1] = cur->adjs[2] = cur->adjs[3] = cur->adjs[4] = cur->adjs[5] = cur->adjs[6] = cur->adjs[7] = 0;

    for (cur = list; cur; cur = cur->next)
    {
        nodes++;

        sortVec.push_back(cur); //might as well do it here

        for (tmp = list; tmp; tmp = tmp->next) //iterate thru list
        {
            if (tmp == cur)
                continue;

            tmpVec.set(cur->loc.x-tmp->loc.x, cur->loc.y-tmp->loc.y);
				if (cur->mesh)
					cur->mesh->mObjToWorld.getColumn(1, &yVec);
				else
					yVec.set(0, 1, 0);
            direc = ( findDirec(tmpVec) + (findDirec(yVec)&1) ) % 8;

            if (cur->adjs[direc])
                continue;

            if (tmp->loc.z - cur->loc.z < tmp->interval && tmpVec.len() < cur->interval*(direc&1 ? 1.5f : 1.1f))
            {
                offset.set(cur->loc.y - tmp->loc.y, tmp->loc.x - cur->loc.x, 0);
                offset.normalize(clearence);

                if (!gServerContainer.castRay(cur->loc + offset-step, tmp->loc + offset-step, STATIC_COLLISION_MASK, &rInfo) &&
                    !gServerContainer.castRay(cur->loc - offset-step, tmp->loc - offset-step, STATIC_COLLISION_MASK, &rInfo))
                    cur->adjs[direc] = tmp;
            }

            if (cur->adjs[0] && cur->adjs[1] && cur->adjs[2] && cur->adjs[3] &&
                cur->adjs[4] && cur->adjs[5] && cur->adjs[6] && cur->adjs[7])
                break;
        }
    }

    Con::printf("Built paths in %d ms; %d nodes.", Platform::getRealMilliseconds()-time, nodes);
}

void AStar::reLabel()
{
	int i = 0;
	for(NMPoint* pt = list; pt; pt = pt->next)
	{
		pt->id = i;
		i++;
	}
}

ConsoleFunction(deletePaths, void, 1, 1, "delete navmesh")
{
	AStar::Get()->deleteAll();
}

void AStar::deleteAll()
{
	if (!list)
		return;

	while(meshes.size())
	{
		//meshes.pop_front();
		meshes[0]->deleteObject();
		meshes.pop_front();
	}

	delete list;
	list = 0;
	points = 0;
}

//seems like a silly way to do this...
namespace {
Point3F qsLoc;
int qsLocCmp(const void* a, const void* b)
{
   F32 ad = disSqr((*(NMPoint**)a)->loc, qsLoc); //jeebus!
   F32 bd = disSqr((*(NMPoint**)b)->loc, qsLoc);
   return ad < bd ? -1 : (ad == bd ? 0 : 1);
}
}

void AStar::sortPoints(Point3F pt)
{
   if ((qsLoc - pt).len() < 4.f)
      return; //no need to sort
   qsLoc = pt;
   dQsort((void*)&sortVec[0], sortVec.size(), sizeof(NMPoint*), qsLocCmp);
}

NMPoint* AStar::findPoint (Point3F pt)
{
   RayInfo rInfo;
   bool found = false;
   NMPoint* nmp = list;
   for (NMPoint* tmp = list; tmp; tmp = tmp->next) //iterate thru list
   {
      if(tmp->loc.z - pt.z < 3 && disSqr(tmp->loc, pt) < LOOK_DIS_SQR &&
         disSqr(tmp->loc, pt) < disSqr(nmp->loc, pt) &&
         !gServerContainer.castRay(tmp->loc, pt, ( InteriorObjectType | StaticTSObjectType | StaticShapeObjectType  ), &rInfo)) //find closest one
      {
         nmp = tmp;
         found = true;
      }
   }
   if (found)
      return nmp;

   //didn't find anything, will do prioritized brute force now

   sortPoints(pt);

   for (int i=0; i<sortVec.size(); i++)
      if (disSqr(sortVec[i]->loc, pt) > LOOK_DIS_SQR && !gServerContainer.castRay(sortVec[i]->loc, pt, ( InteriorObjectType | StaticTSObjectType | StaticShapeObjectType  ), &rInfo))
         return sortVec[i];

   return 0; //give up
}

void AStar::reset() //called whenever points are added/removed/changed
{
    delete [] openList;
    openList = new AStarPoint[points];
    dMemset(openList, 0, sizeof(AStarPoint)*points);
	 
	 AStar::Get()->linkMeshes();
}

//---------------------------------------------------------//
//                          Viz                            //
//---------------------------------------------------------//

void AStar::render(SceneState* state) //, SceneRenderImage*)
{
	if (!gEditingMission || !renderInEditor)
        return;

    RayInfo rInfo;

	AssertFatal(dglIsInCanonicalState(), "Error, GL not in canonical state on entry");
	RectI viewport;
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	dglGetViewport(&viewport);
	state->setupBaseProjection();
	//glPushMatrix();
	//dglMultMatrix(&getTransform());
    glDisable(GL_CULL_FACE);

    int i;
    glBegin(GL_LINES);
    for (NMPoint* tmp = list; tmp; tmp = tmp->next) //iterate thru list
    {
        glColor3f(0,1,0);
        glVertex3f(tmp->loc.x, tmp->loc.y, tmp->loc.z);
        glVertex3f(tmp->loc.x, tmp->loc.y, tmp->loc.z-1);
        for (i=0; i<8; i++)
		{
            if (!tmp->adjs[i])
                continue;
            glColor3f(0,0,1);
            glVertex3f(tmp->loc.x, tmp->loc.y, tmp->loc.z);
            glVertex3f(tmp->adjs[i]->loc.x, tmp->adjs[i]->loc.y, tmp->adjs[i]->loc.z-1);
        }
    }
    glEnd();

	// Restore our canonical matrix state.
	//glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	dglSetViewport(viewport);
	AssertFatal(dglIsInCanonicalState(), "Error, GL not in canonical state on exit");
}