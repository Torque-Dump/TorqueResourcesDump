#include "game/aStar.h"
#include "core/fileStream.h"

ConsoleFunction(writePaths, void, 1, 1, "writes navmesh to file")
{
	AStar::Get()->write();
	AStar::Get()->read();
}

ConsoleFunction(readPaths, bool, 1, 1, "reads navmesh from file")
{
	return AStar::Get()->read();
}

void AStar::write()
{
   reLabel();
	if (!list)
		return;

	char misName[256];
	dSprintf(misName, sizeof(misName), "%s", Con::getVariable("$Server::MissionFile"));
	dSprintf(misName+dStrlen(misName), 256-dStrlen(misName), "%s", ".as");

	FileStream fs;
	if (!fs.open(misName, FileStream::Write))
		return;

	NMIDPoint * data = new NMIDPoint[points];

	dMemset(data, 0, sizeof(NMIDPoint)*points);

	int i = 0;
	for(NMPoint* pt = list; pt; pt = pt->next)
	{
		data[i].loc = pt->loc;
		data[i].interval = pt->interval;
		for (int j=0; j<8; j++)
			data[i].adjs[j] = pt->adjs[j] ? pt->adjs[j]->id + 1: 0;
		++i;
	}

	fs.write(points);

	fs.write(sizeof(NMIDPoint)*points, data);

	fs.close();

	delete [] data;

	deleteAll();

	Con::printf("Save the mission now.");
}

bool AStar::read()
{
	char misName[256];
	dSprintf(misName, sizeof(misName), "%s", Con::getVariable("$Server::MissionFile"));
	dSprintf(misName+dStrlen(misName), 256-dStrlen(misName), "%s", ".as");

	FileStream fs;
	if (!fs.open(misName, FileStream::Read))
		return false;

	fs.read(&points);
	NMIDPoint * data = new NMIDPoint[points];

	fs.read(sizeof(NMIDPoint)*points, data);

	fs.close();

	if (!points)
		return false;

   //allocate in a block so it's faster
	NMPoint* tmpList = new NMPoint[points];
   dMemset(tmpList, 0, sizeof(NMPoint)*points);

	list = tmpList;

   sortVec.clear();

	for (int i=0; i<points; i++)
	{
      sortVec.push_back(&tmpList[i]);

		tmpList[i].loc = data[i].loc;
		tmpList[i].id = i;
		tmpList[i].mesh = 0;
		tmpList[i].interval = data[i].interval;

		tmpList[i].next = &tmpList[i+1];
		tmpList[i].prev = &tmpList[i-1];
	}
    tmpList[0].prev = 0;
    tmpList[points-1].next = 0;
	
	for (int i=0; i<points; i++)
		for (int j=0; j<8; j++)
			tmpList[i].adjs[j] = data[i].adjs[j] ? &tmpList[data[i].adjs[j]-1] : 0;

   delete [] data;

   delete [] openList;
   openList = new AStarPoint[points];
   dMemset(openList, 0, sizeof(AStarPoint)*points);

	return true;
}