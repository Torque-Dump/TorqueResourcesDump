#include "game/aStar.h"

#include "console/consoleTypes.h"

extern bool gEditingMission;
 
AStar * AStar::singleton = NULL;

AStar::AStar()
{
    list = 0;
    points = 0;
    openList = 0;
    clearence = 0.4f;
	 renderInEditor = true;
}

//---------------------------------------------------------//
//                      Pathfinding                        //
//---------------------------------------------------------//

S32 AStar::findBasicPath (Point3F Pstart, Point3F Pend, Vector<Point3F> &Vpoints)
{
    if (!list)
        return -1;

    if (Pstart == Pend) //may seem stupid, but probably good to do
        return 1;

    NMPoint *start, *end;
    start = end = list;
    RayInfo rInfo;
    
    if (!(end = findPoint(Pend)) || !(start = findPoint(Pstart)))
       return -1;

    if (start == end)
    {
        return 1;
    }

    //ok, we've got start and end NMPoints, time for some a*

    S32 olSize = 1;
    AStarPoint *curpt = openList;
    curpt->pt = start;
    start->asp = curpt;

    curpt->f = (start->loc - end->loc).len();

    int i;

    do {
        BHPop(curpt+1, olSize-1);
        curpt->list = AStarPoint::closed;
        for (i=0;i<8;++i)
        {
            if (!curpt->pt->adjs[i]) //no point
                continue;
            if (!curpt->pt->adjs[i]->asp) //a new point
            {
                if (curpt->pt->adjs[i] == end) //woohoo!
                    goto found;
                curpt[olSize].pt = curpt->pt->adjs[i];
                curpt[olSize].pt->asp = &curpt[olSize];
                curpt[olSize].parent = curpt;
                curpt[olSize].list = AStarPoint::open;
                curpt[olSize].g = curpt->g + curpt->pt->interval*((i&1)?1.4f:1);
                curpt[olSize].f = curpt[olSize].g + (curpt[olSize].pt->loc - end->loc).len();
                BHAdd(curpt+1, olSize-1); //b/c curpt is the one *before* the first element
                olSize++;
            }
            else if ((curpt->pt->adjs[i]->asp->list == AStarPoint::open) &&
                     ((curpt->g + curpt->pt->interval*((i&1)?1.4f:1)) < curpt->pt->adjs[i]->asp->g))  //this is a better path
            {
                curpt->pt->adjs[i]->asp->parent = curpt;
                curpt->pt->adjs[i]->asp->g = curpt->g + curpt->pt->interval*((i&1)?1.4f:1);
                curpt->pt->adjs[i]->asp->f = curpt->pt->adjs[i]->asp->g +
                                             (curpt->pt->adjs[i]->loc - end->loc).len();
                BHAdd(curpt+1, curpt->pt->adjs[i]->asp - curpt - 1);
            }
        }
        ++curpt;
        --olSize;
     } while (olSize);

     for (AStarPoint *del = openList; del->pt; del++)
     {
        del->pt->asp = 0;
     }

     dMemset(openList, 0, sizeof(AStarPoint)*points);

     return -1;

found:

    Vpoints.clear();

    Vpoints.push_front(end->loc);


    while (curpt->pt != start)
    {
        Vpoints.push_front(curpt->pt->loc);
        curpt = curpt->parent;
    } 

    if (mAbs(findDirec(Vpoints[0] - start->loc) - findDirec(Pstart - start->loc)) > 2)
        Vpoints.push_front(start->loc);

	Vpoints.push_front(Pstart);

    for (AStarPoint *del = openList; del->pt; del++)
    {
       del->pt->asp = 0;
    }

    dMemset(openList, 0, sizeof(AStarPoint)*points);

    return 0;
}

S32 AStar::findCover (Point3F Pstart, Point3F Penemy, Vector<Point3F> &Vpoints)
{
    Point3F offset;
    offset.set(Pstart.y - Penemy.y, Penemy.x - Pstart.x, 0);
    offset.normalize(clearence);
    offset.set(offset.z, offset.y, 0.5f);
    Penemy += Point3F(0, 0, 0.5f);
    RayInfo rInfo;
    if (gServerContainer.castRay(Pstart + offset, Penemy, STATIC_COLLISION_MASK, &rInfo) &&
        findDirec(rInfo.normal) == findDirec(Pstart - Penemy) &&
        gServerContainer.castRay(Pstart - offset, Penemy, STATIC_COLLISION_MASK, &rInfo) &&
        findDirec(rInfo.normal) == findDirec(Pstart - Penemy)) //home free
        return 1;

    if (!list)
        return -1;

    NMPoint *start, *end;
    start = list;
    
    if (!(start = findPoint(Pstart)))
       return -1;

    S32 olSize = 1;
    AStarPoint *curpt = openList;
    curpt->pt = start;
    start->asp = curpt;

    int i;

    do {
        BHPop(curpt+1, olSize-1);
        curpt->list = AStarPoint::closed;
        for (i=0;i<8;++i)
        {
            if (!curpt->pt->adjs[i]) //no point
                continue;
            if (!curpt->pt->adjs[i]->asp) //a new point
            {
                offset.set(curpt->pt->adjs[i]->loc.y - Penemy.y, Penemy.x - curpt->pt->adjs[i]->loc.x, 0);
                offset.normalize(clearence);
                offset.set(offset.z, offset.y, 0.5f);
                if (gServerContainer.castRay(curpt->pt->adjs[i]->loc + offset, Penemy, STATIC_COLLISION_MASK, &rInfo) &&
                    findDirec(rInfo.normal) == findDirec(curpt->pt->adjs[i]->loc - Penemy) &&
                    gServerContainer.castRay(curpt->pt->adjs[i]->loc - offset, Penemy, STATIC_COLLISION_MASK, &rInfo) &&
                    findDirec(rInfo.normal) == findDirec(curpt->pt->adjs[i]->loc - Penemy)) //woohoo!
                {
                    end = curpt->pt->adjs[i];
                    goto found;
                }
                curpt[olSize].pt = curpt->pt->adjs[i];
                curpt[olSize].pt->asp = &curpt[olSize];
                curpt[olSize].parent = curpt;
                curpt[olSize].list = AStarPoint::open;
                curpt[olSize].g = curpt->g + curpt->pt->interval*((i&1)?1.4f:1);
                curpt[olSize].f = curpt[olSize].g - (curpt[olSize].pt->loc - Penemy).len();
                BHAdd(curpt+1, olSize-1); //b/c curpt is the one *before* the first element
                olSize++;
            }
            else if ((curpt->pt->adjs[i]->asp->list == AStarPoint::open) &&
                     ((curpt->g + curpt->pt->interval*((i&1)?1.4f:1)) < curpt->pt->adjs[i]->asp->g))  //this is a better path
            {
                curpt->pt->adjs[i]->asp->parent = curpt;
                curpt->pt->adjs[i]->asp->g = curpt->g + curpt->pt->interval*((i&1)?1.4f:1);
                curpt->pt->adjs[i]->asp->f = curpt->pt->adjs[i]->asp->g - (curpt->pt->adjs[i]->loc - Penemy).len();
                BHAdd(curpt+1, curpt->pt->adjs[i]->asp - curpt - 1);
            }
        }
        ++curpt;
        --olSize;
     } while (olSize);

     for (AStarPoint *del = openList; del->pt; del++)
     {
        del->pt->asp = 0;
     }

     dMemset(openList, 0, sizeof(AStarPoint)*points);

     return -1;

found:

    Vpoints.clear();

    Vpoints.push_front(end->loc);

    while (curpt->pt != start)
    {
        Vpoints.push_front(curpt->pt->loc);
        curpt = curpt->parent;
    } 

    if (mAbs(findDirec(Vpoints[0] - start->loc) - findDirec(Pstart - start->loc)) > 2)
        Vpoints.push_front(start->loc);

	Vpoints.push_front(Pstart);

    for (AStarPoint *del = openList; del->pt; del++)
    {
       del->pt->asp = 0;
    }

    dMemset(openList, 0, sizeof(AStarPoint)*points);

    return 0;
}

S32 AStar::sneakUp (Point3F Pstart, Point3F Penemy, VectorF Vlook, F32 okDist, Vector<Point3F> &Vpoints)
{
    if (!list)
        return -1;

    Penemy += Point3F(0,0,.5);
    Pstart += Point3F(0,0,.5);

    if (Pstart == Penemy) //may seem stupid, but probably good to do
        return 1;

    NMPoint *start, *end;
    start = end = list;
    RayInfo rInfo;
    
    VectorF vToPt(0,0,0);

    bool found = false;
    for (NMPoint* tmp = list; tmp; tmp = tmp->next) //iterate thru list
    {
       vToPt = (tmp->loc - Penemy);
       vToPt.normalize(); //vv because we can't go up
       if(tmp->loc.z - Penemy.z < 3 && mDot(Vlook, vToPt) < .8 && disSqr(tmp->loc, Penemy) < LOOK_DIS_SQR &&
          disSqr(tmp->loc, Penemy) < disSqr(end->loc, Penemy) &&
          !gServerContainer.castRay(tmp->loc, Penemy, ( InteriorObjectType | StaticTSObjectType | StaticShapeObjectType  ), &rInfo)) //find closest one
       {
          end = tmp;
          found = true;
       }
    }

    if (!found)
    {
        //didn't find anything, will do prioritized brute force now
        sortPoints(Penemy);

        for (int i=0; i<sortVec.size(); i++)
        {
            vToPt = (sortVec[i]->loc - Penemy);
            vToPt.normalize();
            if (sortVec[i]->loc.z - Penemy.z < 3 && mDot(Vlook, vToPt) < .8 &&
                !gServerContainer.castRay(sortVec[i]->loc, Penemy, ( InteriorObjectType | StaticTSObjectType | StaticShapeObjectType  ), &rInfo))
            {
            end = sortVec[i];
            break;
            }
        }
    }

    if (!(start = findPoint(Pstart)))
        return -1;

    vToPt = (start->loc - Penemy);
    vToPt.normalize();
    if (mDot(Vlook, vToPt) > .8 && !gServerContainer.castRay(start->loc, Penemy, STATIC_COLLISION_MASK, &rInfo))
        return -1;

    if (start == end)
        return 1;

    //ok, we've got start and end NMPoints, time for some a*

    S32 olSize = 1;
    AStarPoint *curpt = openList;
    curpt->pt = start;
    start->asp = curpt;

    curpt->f = (start->loc - end->loc).len();

    int i;

    do {
        BHPop(curpt+1, olSize-1);
        curpt->list = AStarPoint::closed;
        for (i=0;i<8;++i)
        {
            if (!curpt->pt->adjs[i]) //no point
                continue;
            if (curpt->pt->adjs[i] == end) //woohoo!
                goto found;
            vToPt = (curpt->pt->adjs[i]->loc - Penemy);
            vToPt.normalize();
            if (!curpt->pt->adjs[i]->asp && ((okDist ? (Penemy - curpt->pt->adjs[i]->loc).len() < okDist : 0) ||
                    (mDot(Vlook, vToPt) < .8 ) ||
                    gServerContainer.castRay(curpt->pt->adjs[i]->loc, Penemy, STATIC_COLLISION_MASK, &rInfo)))//a new point
            {
                curpt[olSize].pt = curpt->pt->adjs[i];
                curpt[olSize].pt->asp = &curpt[olSize];
                curpt[olSize].parent = curpt;
                curpt[olSize].list = AStarPoint::open;
                curpt[olSize].g = curpt->g + curpt->pt->interval*((i&1)?1.4f:1);
                curpt[olSize].f = curpt[olSize].g + (curpt[olSize].pt->loc - end->loc).len();
                BHAdd(curpt+1, olSize-1); //b/c curpt is the one *before* the first element
                olSize++;
            }
            else if (curpt->pt->adjs[i]->asp && (curpt->pt->adjs[i]->asp->list == AStarPoint::open) &&
                     ((curpt->g + curpt->pt->interval*((i&1)?1.4f:1)) < curpt->pt->adjs[i]->asp->g))  //this is a better path
            {
                curpt->pt->adjs[i]->asp->parent = curpt;
                curpt->pt->adjs[i]->asp->g = curpt->g + curpt->pt->interval*((i&1)?1.4f:1);
                curpt->pt->adjs[i]->asp->f = curpt->pt->adjs[i]->asp->g +
                                             (curpt->pt->adjs[i]->loc - end->loc).len();
                BHAdd(curpt+1, curpt->pt->adjs[i]->asp - curpt - 1);
            }
        }
        ++curpt;
        --olSize;
     } while (olSize);

     for (AStarPoint *del = openList; del->pt; del++)
     {
        del->pt->asp = 0;
     }

     dMemset(openList, 0, sizeof(AStarPoint)*points);

     return -1;

found:
    
    Vpoints.clear();

    Vpoints.push_front(end->loc);

    while (curpt->pt != start)
    {
        Vpoints.push_front(curpt->pt->loc);
        curpt = curpt->parent;
    } 

    if (mAbs(findDirec(Vpoints[0] - start->loc) - findDirec(Pstart - start->loc)) > 2)
        Vpoints.push_front(start->loc);

	Vpoints.push_front(Pstart);

    for (AStarPoint *del = openList; del->pt; del++)
    {
       del->pt->asp = 0;
    }

    dMemset(openList, 0, sizeof(AStarPoint)*points);

    return 0;
}

S32 AStar::wander (Point3F Pstart, U32 length, Vector<Point3F> &Vpoints)
{
    if (!list)
        return -1;

    if (length == 0)
        return 1;

    NMPoint *start;
    RayInfo rInfo;
    
    if (!(start = findPoint(Pstart)))
       return -1;

    //ok, we've got start and end NMPoints, time for some a*

    S32 olSize = 1;
    AStarPoint *curpt = openList;
    curpt->pt = start;
    start->asp = curpt;

    curpt->f = length;

    int i;

    do {
       BHPop(curpt+1, olSize-1);
       curpt->list = AStarPoint::closed;
       if (curpt->g - length > 0)
           break;
       for (i=0;i<8;++i)
       {
           if (!curpt->pt->adjs[i]) //no point
               continue;
           if (!curpt->pt->adjs[i]->asp) //a new point
           {
               curpt[olSize].pt = curpt->pt->adjs[i];
               curpt[olSize].pt->asp = &curpt[olSize];
               curpt[olSize].parent = curpt;
               curpt[olSize].list = AStarPoint::open;
               curpt[olSize].g = curpt->g + curpt->pt->interval*((i&1)?1.4f:1);
               curpt[olSize].f = curpt[olSize].g + gRandGen.randF(0, length);
               BHAdd(curpt+1, olSize-1); //b/c curpt is the one *before* the first element
               olSize++;
           }
           else if ((curpt->pt->adjs[i]->asp->list == AStarPoint::open) &&
                    ((curpt->g + curpt->pt->interval*((i&1)?1.4f:1)) < curpt->pt->adjs[i]->asp->g))  //this is a better path
           {
               curpt->pt->adjs[i]->asp->parent = curpt;
               curpt->pt->adjs[i]->asp->g = curpt->g + curpt->pt->interval*((i&1)?1.4f:1);
               curpt->pt->adjs[i]->asp->f = curpt->pt->adjs[i]->asp->g +
                                            gRandGen.randF(0, length);
               BHAdd(curpt+1, curpt->pt->adjs[i]->asp - curpt - 1);
           }
       }
       ++curpt;
       --olSize;
    } while (olSize);

    Vpoints.clear();

    if (!olSize) //if we run out of points, just start with the last one added
        curpt--;

    while (curpt->pt != start)
    {
        Vpoints.push_front(curpt->pt->loc);
        curpt = curpt->parent;
    }

    if (mAbs(findDirec(Vpoints[0] - start->loc) - findDirec(Pstart - start->loc)) > 2)
        Vpoints.push_front(start->loc);

	Vpoints.push_front(Pstart);

    for (AStarPoint *del = openList; del->pt; del++)
    {
       del->pt->asp = 0;
    }

    dMemset(openList, 0, sizeof(AStarPoint)*points);
    
    return 0;
}

ConsoleFunction(setNavMeshRenderState, void, 2, 2, "setNavMeshRenderState(true/false);")
{
	if(!gEditingMission)
		return;

	AStar::Get()->setRenderState(dAtob(argv[1]));
}

ConsoleFunction(getNavMeshRenderState, bool, 1, 1, "getNavMeshRenderState();")
{
	return AStar::Get()->getRenderState();
}