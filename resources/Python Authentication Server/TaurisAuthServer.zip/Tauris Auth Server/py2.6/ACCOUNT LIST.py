#==============================================================================
# Simple script to send a printList signal to the auth server
# just for a little bit of fun. :)
#==============================================================================

from socket import *
import struct

host = "127.0.0.1"
port = 21231
buf = 1024
addr = (host,port)

conn = socket (AF_INET, SOCK_DGRAM )

pkg = '4pyas'.encode('ascii')
conn.sendto(pkg, addr)
conn.close()
