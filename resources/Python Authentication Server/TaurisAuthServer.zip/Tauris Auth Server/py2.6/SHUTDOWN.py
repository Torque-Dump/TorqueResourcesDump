#==============================================================================
# Simple script to send a shutdown package to the auth server
# 
#==============================================================================

from socket import *

host = "127.0.0.1"
port = 21231
buf = 1024
addr = (host,port)

conn = socket (AF_INET, SOCK_DGRAM )

pkg = '3pyas'.encode('ascii')
conn.sendto(pkg, addr)
conn.close()
