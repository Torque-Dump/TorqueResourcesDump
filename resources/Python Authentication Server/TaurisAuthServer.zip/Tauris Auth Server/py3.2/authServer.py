#==============================================================================
# Name - Tauris Python Authentication Server (pyas)
# Version - 1.0
# Date - 11/23/2010
# Author - Alviss
# Python ver - 3.2

# Synopsis :
#   Server written to combine with a game server by right now, database connection
#   Could also work with socket coms to the game server

#==============================================================================


#------------------------------------------------------------------------------
#               Configuration

port = 21231               # port number to run on
run_server = True          # run boolean bit
admin_p = '2r23'           # admin password for server closing and accountlist

#------------------------------------------------------------------------------

import struct, time, sqlite3
from socket import *

#==============================================================================
#               Functions
#This function is used to digest the incoming packages, and arrange a return string
#in such a way that the main loop can handle them
#Package structure (# = func index ) :
#  --- login/register/remaccount - b'#pyasNAMEto8\x00\x00PASSto10\x00\x00'
#  --- checkpass (close server) - "b'#pyasPASSto10\x00\x00'
#  If the name or pass is less than their max (8 and 10) then the left overs are
#  filled with whitespace or ascii code - '\x00'
def crackPackage( string ):

   pack_len = len( string )
   pack_prefix_len = 5 ##pyas is the 'pack prefix' it signifies it's a PYAS package to the server

   i = pack_prefix_len #
   #Seperate the name and pass from the package
   if pack_len == pack_prefix_len + 18:
      name = ""
      passw = ""

      while (i < pack_prefix_len + 8):
         if not string[i].encode('ascii') == b'\x00':
            name = name + string[i]
         i+=1

      while (i < pack_prefix_len + 18):
         if not string[i].encode('ascii') == b'\x00':
            passw = passw + string[i]
         i+=1

      rstr = name, passw

   #Seperate the admin pass from the package
   else:
      rstr = ""
      
      while (i < pack_len): 
         print( "checkpass = ", string[i] )
         rstr = rstr + string[i] 
         i+=1

   #Return the digested string
   return rstr

#------------------------------------------------------------------------------
#Compares the given credentials to the stored data 1 = passed 0 = failed
def VarifyCreds( name, pword ):
   sql_cursor.execute('SELECT * FROM accounts')   

   for entry in sql_cursor:
      if entry[1] == name and entry[2] == pword:
         return True

   return False

#------------------------------------------------------------------------------
#'Print' a list of all the account entries
def postList():
   sql_cursor.execute('SELECT * FROM accounts')   

   for entry in sql_cursor:
      print( entry )

#------------------------------------------------------------------------------
#Adds an account entry into the account datase
def addAccount( name, pword ):
   #Update the table
   sql_cursor.execute('INSERT INTO accounts VALUES (null, ?, ?)', (name, pword)) 
   #Commit the changes
   sql_conn.commit() 

   #Make sure the account has been added to the database
   if VarifyCreds( name, pword ):
      return True
   else:
      return False

#------------------------------------------------------------------------------
#Remove an account
def remAccount( name ):
   #Delete the row with that name from the table
   sql_cursor.execute('DELETE FROM accounts WHERE name = name') 
   #Commit the changes
   sql_conn.commit() 

   sql_cursor.execute('SELECT * FROM accounts')   
   #Assure that the account is gone for good.
   for entry in sql_cursor:
      if entry[1] == name:
         return False
   
   return True

#==============================================================================
#               Run Loop

# Main runloop it will wait for all time for a connection if "run_server" remains true

#Prepare the sockets
a_ser = socket( AF_INET, SOCK_DGRAM )
a_ser.bind(("", port))

#Prepare the SQL database
#To write a hard-drive database
#sql_conn = sqlite.connect('pyas_entries.db')

#To write a virtual database
sql_conn = sqlite3.connect(':memory:')

sql_cursor = sql_conn.cursor()
sql_cursor.execute('CREATE TABLE accounts (id INTEGER PRIMARY KEY, name VARCHAR(50), password VARCHAR(50))')

try:
   
    print("Auth server running...")

    while run_server:
        
        #Wait for a connection to come
        Intent_raw, client = a_ser.recvfrom( 1024 )

        pkg_ip = client[0]
        pkg_port = client[1]

        ##print(Intent_raw)
        Intent_raw = Intent_raw.decode('ascii')
        func = Intent_raw[0]

        if func == '0':    # Login
            print( "Login request from IP:", pkg_ip, " Port:", pkg_port )

            name, passw = crackPackage( Intent_raw )

            if VarifyCreds( name, passw ):
               handoff_pkg = '1pyas'.encode('ascii')
               print( "Connection on IP:", pkg_ip, " Authenticated!" )

               # AUTHENTICATED!
               # Pass the IP unto the game server! or write into the database
               # that this player has logged in so the game server can read it

            else:
               handoff_pkg = '0'.encode('ascii')

            a_ser.sendto(handoff_pkg, client)
            
        elif func == '1':    # Register Entry
            print( "Register request from IP:", pkg_ip, " Port:", pkg_port )

            name, passw = crackPackage( Intent_raw )
            
            # Add the actual account to the datase
            if addAccount( name, passw ):
               # Alert the client to the success
               handoff_pkg = '1pyas'.encode('ascii')
               print( "Connection on IP: ", pkg_ip, " created a new account: ", name )
            else:
               handoff_pkg = '0'.encode('ascii')

            a_ser.sendto(handoff_pkg, client)

        elif func == '2':    # Remove Entry
            print( "Remove request from IP: ", pkg_ip, " Port:", pkg_port )
            name, passw = crackPackage( Intent_raw ) 

            # Check if the admin password is correct
            if passw == admin_p:
              # Remove the account from the table
              if remAccount( name ):
                print( "Account name: ", name, " successfully removed")
                rem_pkg = '1pyas'.encode('ascii')
                a_ser.sendto(rem_pkg, client)      

              else:
                handoff_pkg = '0'.encode('ascii')

        elif func == '3':    # Close server
            print( "Received request to terminate server" )
            run_server = False

        elif func == '4':    # Print account list
            postList()
            
        else:              # Handle a fuck-up
            print( "Unknown package: ", func, " from: ", pkg_ip )
            # Send the client a notification it failed so it's not waiting.
            fail_pkg = '0'.encode('ascii')
            a_ser.sendto(fail_pkg, client)


    print( "Auth server shutting down" )       

except:
    
    print( "FATAL ERROR OCCURRED" )
    a_ser.close()
    sql_cursor.close()
    sql_conn.close()
    raise

a_ser.close()
sql_cursor.close()
sql_conn.close()
