#==============================================================================
# Name - Tauris Python Authentication ~Test~ client (pyas)
# Version - 1.0
# Date - 11/23/2010
# Author - Alviss
# Python ver - 3.2

# Synopsis :
#   Basic framework client for PYAS to showcase the capabilities and the package
#   structure to be able to communicate with the server

#==============================================================================

from socket import *
import struct

def print_menu():
    print('1. Login')
    print('2. Register')
    print('3. Remove Account')
    print('4. Quit')
    print("")
 
addr = ("127.0.0.1", 21231)
a_conn = socket (AF_INET, SOCK_DGRAM )

wait = True

menu_choice = 0
print_menu()

while wait:
    menu_choice = input("Select Menu Item (1-4): ")

    if menu_choice == '1':
        print("Input name and password")
        name = input("Username: ")
        passw = input("Password: ")

        if len(name) == 0 or len(passw) == 0:
            print("ERROR - Cannot input blanks for username or password")
            continue  

        # Send a package with out intent and credentials
        intent_pkg = '0pyas'.encode("ascii") + struct.pack("8s10s", name, passw)
        ##print("ECHO - intent_pkg = ", intent_pkg)
        a_conn.sendto(intent_pkg, addr)

        # Get a package telling us if we passed
        pass_raw, server = a_conn.recvfrom( 1024 ) 
        ##print("ECHO - pass_raw = ", pass_raw)
        pass_raw = pass_raw.decode('ascii')
        handoff = pass_raw[0]

        if handoff == '1':
          print("NOTIFY - YEAAY! WE MADE IT! Put some sort of UI event, or tell the client to connect to the game server")
        else:
          print("ERROR - Either username or password is incorrect")

    elif menu_choice == '2':
        print("Input desired name and password twice")
        name = input("Username: ")
        passw = input("Password: ")
        passwtoo = input("Password again: ")

        if len(name) == 0 or len(passw) == 0:
            print("Cannot input blanks for username or password")
            continue  
        if not passw in passwtoo:
            print("Passwords do not match")
            continue  
        if not len(passw) == len(passwtoo):
            print("Passwords do not match")
            continue
        
        # Send a package with out intent and credentials
        intent_pkg = '1pyas'.encode("ascii") + struct.pack("8s10s", name, passw)
        ##print("ECHO - intent_pkg = ", intent_pkg)
        a_conn.sendto(intent_pkg, addr)

        # Get a package telling us if we passed
        pass_raw, server = a_conn.recvfrom( 1024 ) 
        ##print("ECHO - pass_raw = ", pass_raw)
        pass_raw = pass_raw.decode('ascii')
        handoff = pass_raw[0]

        if handoff == '1':
          print("NOTIFY - Account: ", name, " created!")
        else:
          print("ERROR - Either username or password is incorrect")

    elif menu_choice == '3':
        print("Input account name and admin password")
        name = input("Username: ")
        passw = input("Admin Password: ")
          
        if len(name) == 0 or len(passw) == 0:
            print("Cannot input blanks for username or password")
            continue  

        # Send a package with out intent and credentials
        intent_pkg = '2pyas'.encode("ascii") + struct.pack("8s10s", name, passw)
        ##print("ECHO - intent_pkg = ", intent_pkg)
        a_conn.sendto(intent_pkg, addr)

        # Get a package telling us if we passed
        pass_raw, server = a_conn.recvfrom( 1024 ) 
        ##print("ECHO - pass_raw = ", pass_raw)
        pass_raw = pass_raw.decode('ascii')
        handoff = pass_raw[0]

        if handoff == '1':
          print("NOTIFY - Account: ", name, " deleted")
        else:
          print("ERROR - Either username or password is incorrect")

    elif menu_choice == '4':
        print("Bye!")
        wait = False

    else:
        print_menu()  

a_conn.close()

