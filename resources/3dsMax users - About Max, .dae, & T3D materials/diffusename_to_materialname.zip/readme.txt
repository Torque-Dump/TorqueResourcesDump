This should work in almost every version of Maxscript after version 4 or 5.

-- ****************************************************
-- Website: www.gameartstore.com 
-- ****************************************************
-- Author :  eb
-- NO SUPPORT GIVEN FOR THIS SCRIPT AS IT IS FREE
-- Email: support@gameartstore.com 
-- **************************************************** 

 sorry that I have to make such a stupid set of rules..but unfortunately the world is not full of normal users whom have reasonable ethics.
-- you can use it for commercial or non-commercial projects
-- you can not seel this file
-- you can not edit or cut portions of it for sale
-- you can not package it for sale
-- you can not claim it as your own work
-- you can not include it, in whole or in part, in another package
-- you can not distribute the file or package containing the file
-- you use it at your own risk, in no way holding eb liable for anything coming about from it's use or attempt to use