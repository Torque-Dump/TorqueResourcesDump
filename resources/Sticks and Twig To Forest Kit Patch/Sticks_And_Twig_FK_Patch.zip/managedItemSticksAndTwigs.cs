
datablock TSForestItemData(FK_cliffBasic001A) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001A.dts";
internalName = "FK_cliffBasic001A";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001Aend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001Aend.dts";
internalName = "FK_cliffBasic001Aend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001AendLOW) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001AendLOW.dts";
internalName = "FK_cliffBasic001AendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001B) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001B.dts";
internalName = "FK_cliffBasic001B";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001Bend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001Bend.dts";
internalName = "FK_cliffBasic001Bend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001BendLOW) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001BendLOW.dts";
internalName = "FK_cliffBasic001BendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001C) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001C.dts";
internalName = "FK_cliffBasic001C";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001Cend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001Cend.dts";
internalName = "FK_cliffBasic001Cend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001CendLOW) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001CendLOW.dts";
internalName = "FK_cliffBasic001CendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001D) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001D.dts";
internalName = "FK_cliffBasic001D";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001Dend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001Dend.dts";
internalName = "FK_cliffBasic001Dend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001DendLOW) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001DendLOW.dts";
internalName = "FK_cliffBasic001DendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001E) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001E.dts";
internalName = "FK_cliffBasic001E";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001Eend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001Eend.dts";
internalName = "FK_cliffBasic001Eend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001EendLOW) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001EendLOW.dts";
internalName = "FK_cliffBasic001EendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001F) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001F.dts";
internalName = "FK_cliffBasic001F";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001Fend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001Fend.dts";
internalName = "FK_cliffBasic001Fend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001FendLOW) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001FendLOW.dts";
internalName = "FK_cliffBasic001FendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001G) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001G.dts";
internalName = "FK_cliffBasic001G";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001Gend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001Gend.dts";
internalName = "FK_cliffBasic001Gend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001GendLOW) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001GendLOW.dts";
internalName = "FK_cliffBasic001GendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001H) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001H.dts";
internalName = "FK_cliffBasic001H";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001Hend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001Hend.dts";
internalName = "FK_cliffBasic001Hend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001HendLOW) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001HendLOW.dts";
internalName = "FK_cliffBasic001HendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001I) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001I.dts";
internalName = "FK_cliffBasic001I";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001Iend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001Iend.dts";
internalName = "FK_cliffBasic001Iend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001IendLOW) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001IendLOW.dts";
internalName = "FK_cliffBasic001IendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001J) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001J.dts";
internalName = "FK_cliffBasic001J";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001Jend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001Jend.dts";
internalName = "FK_cliffBasic001Jend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001JendLOW) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001JendLOW.dts";
internalName = "FK_cliffBasic001JendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001K) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001K.dts";
internalName = "FK_cliffBasic001K";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001Kend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001Kend.dts";
internalName = "FK_cliffBasic001Kend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001KendLOW) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001KendLOW.dts";
internalName = "FK_cliffBasic001KendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MA) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MA.dts";
internalName = "FK_cliffBasic001MA";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MAend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MAend.dts";
internalName = "FK_cliffBasic001MAend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MAendLOW) {
shapeFile
	= "art/shapes/cliffPack/cliffBasic001/cliffBasic001MAendLOW.dts";
internalName = "FK_cliffBasic001MAendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MB) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MB.dts";
internalName = "FK_cliffBasic001MB";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MBend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MBend.dts";
internalName = "FK_cliffBasic001MBend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MBendLOW) {
shapeFile
	= "art/shapes/cliffPack/cliffBasic001/cliffBasic001MBendLOW.dts";
internalName = "FK_cliffBasic001MBendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MC) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MC.dts";
internalName = "FK_cliffBasic001MC";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MCend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MCend.dts";
internalName = "FK_cliffBasic001MCend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MCendLOW) {
shapeFile
	= "art/shapes/cliffPack/cliffBasic001/cliffBasic001MCendLOW.dts";
internalName = "FK_cliffBasic001MCendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MD) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MD.dts";
internalName = "FK_cliffBasic001MD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MDend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MDend.dts";
internalName = "FK_cliffBasic001MDend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MDendLOW) {
shapeFile
	= "art/shapes/cliffPack/cliffBasic001/cliffBasic001MDendLOW.dts";
internalName = "FK_cliffBasic001MDendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001ME) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001ME.dts";
internalName = "FK_cliffBasic001ME";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MEend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MEend.dts";
internalName = "FK_cliffBasic001MEend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MEendLOW) {
shapeFile
	= "art/shapes/cliffPack/cliffBasic001/cliffBasic001MEendLOW.dts";
internalName = "FK_cliffBasic001MEendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MF) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MF.dts";
internalName = "FK_cliffBasic001MF";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MFend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MFend.dts";
internalName = "FK_cliffBasic001MFend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MFendLOW) {
shapeFile
	= "art/shapes/cliffPack/cliffBasic001/cliffBasic001MFendLOW.dts";
internalName = "FK_cliffBasic001MFendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MG) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MG.dts";
internalName = "FK_cliffBasic001MG";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MGend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MGend.dts";
internalName = "FK_cliffBasic001MGend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MGendLOW) {
shapeFile
	= "art/shapes/cliffPack/cliffBasic001/cliffBasic001MGendLOW.dts";
internalName = "FK_cliffBasic001MGendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MH) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MH.dts";
internalName = "FK_cliffBasic001MH";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MHend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MHend.dts";
internalName = "FK_cliffBasic001MHend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MHendLOW) {
shapeFile
	= "art/shapes/cliffPack/cliffBasic001/cliffBasic001MHendLOW.dts";
internalName = "FK_cliffBasic001MHendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MI) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MI.dts";
internalName = "FK_cliffBasic001MI";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MIend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MIend.dts";
internalName = "FK_cliffBasic001MIend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MIendLOW) {
shapeFile
	= "art/shapes/cliffPack/cliffBasic001/cliffBasic001MIendLOW.dts";
internalName = "FK_cliffBasic001MIendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MJ) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MJ.dts";
internalName = "FK_cliffBasic001MJ";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MJend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MJend.dts";
internalName = "FK_cliffBasic001MJend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MJendLOW) {
shapeFile
	= "art/shapes/cliffPack/cliffBasic001/cliffBasic001MJendLOW.dts";
internalName = "FK_cliffBasic001MJendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MK) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MK.dts";
internalName = "FK_cliffBasic001MK";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MKend) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/cliffBasic001MKend.dts";
internalName = "FK_cliffBasic001MKend";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic001MKendLOW) {
shapeFile
	= "art/shapes/cliffPack/cliffBasic001/cliffBasic001MKendLOW.dts";
internalName = "FK_cliffBasic001MKendLOW";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_mesaBasic001B) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/mesaBasic001B.dts";
internalName = "FK_mesaBasic001B";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_mesaBasic001Btmp) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/mesaBasic001Btmp.dts";
internalName = "FK_mesaBasic001Btmp";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_mesaBasic001C) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/mesaBasic001C.dts";
internalName = "FK_mesaBasic001C";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_skull) {
shapeFile = "art/shapes/cliffPack/cliffBasic001/skull.dts";
internalName = "FK_skull";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic002) {
shapeFile = "art/shapes/cliffPack/cliffBasic002/cliffBasic002.dts";
internalName = "FK_cliffBasic002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic003) {
shapeFile = "art/shapes/cliffPack/cliffBasic003/cliffBasic003.dts";
internalName = "FK_cliffBasic003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cliffBasic004) {
shapeFile = "art/shapes/cliffPack/cliffBasic004/cliffBasic004.dts";
internalName = "FK_cliffBasic004";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_barrel003) {
shapeFile = "art/shapes/gameBasics/barrel003/barrel003.dts";
internalName = "FK_barrel003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_barrel003F_LOD) {
shapeFile = "art/shapes/gameBasics/barrel003/barrel003F_LOD.dts";
internalName = "FK_barrel003F_LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_barrel003_LOD) {
shapeFile = "art/shapes/gameBasics/barrel003/barrel003_LOD.dts";
internalName = "FK_barrel003_LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_35MPHyellow001) {
shapeFile = "art/shapes/gameBasics/signs/35MPHyellow001/35MPHyellow001.dts";
internalName = "FK_35MPHyellow001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_35MPHyellow001D) {
shapeFile
	= "art/shapes/gameBasics/signs/35MPHyellow001/35MPHyellow001D.dts";
internalName = "FK_35MPHyellow001D";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_woodBarrel01) {
shapeFile = "art/shapes/gameBasics/woodenBarrel01/woodBarrel01.dts";
internalName = "FK_woodBarrel01";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cached) {
shapeFile = "art/shapes/goldMine/wagon/wagon001N_5cc03f2a.cached.dts";
internalName = "FK_cached";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fencePillar001wFenceGateOnlyCLSDv2) {
shapeFile
	= "art/shapes/graveyard_2/fencePillar001wFenceGateOnlyCLSDv2/fencePillar001wFenceGateOnlyCLSDv2.dts";
internalName = "FK_fencePillar001wFenceGateOnlyCLSDv2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fencePillar001wFenceGateOnlyOPNv2) {
shapeFile
	= "art/shapes/graveyard_2/fencePillar001wFenceGateOnlyOPNv2/fencePillar001wFenceGateOnlyOPNv2.dts";
internalName = "FK_fencePillar001wFenceGateOnlyOPNv2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fencePillar001wFenceX1) {
shapeFile
	= "art/shapes/graveyard_2/fencePillar001wFenceX1/fencePillar001wFenceX1.dts";
internalName = "FK_fencePillar001wFenceX1";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cached) {
shapeFile
	= "art/shapes/graveyard_2/graveyardFencedv2/graveyardFencedv2.cached.dts";
internalName = "FK_cached";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_iceCliff01) {
shapeFile = "art/shapes/iceFlow/iceCliff01.dts";
internalName = "FK_iceCliff01";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_iceCliff02) {
shapeFile = "art/shapes/iceFlow/iceCliff02.dts";
internalName = "FK_iceCliff02";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_iceFlowChunk001) {
shapeFile = "art/shapes/iceFlow/iceFlowChunk001.dts";
internalName = "FK_iceFlowChunk001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_iceFlowChunk002) {
shapeFile = "art/shapes/iceFlow/iceFlowChunk002.dts";
internalName = "FK_iceFlowChunk002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_iceFlowChunk002SM) {
shapeFile = "art/shapes/iceFlow/iceFlowChunk002SM.dts";
internalName = "FK_iceFlowChunk002SM";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_iceFlowChunk002SM2) {
shapeFile = "art/shapes/iceFlow/iceFlowChunk002SM2.dts";
internalName = "FK_iceFlowChunk002SM2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_iceFlowChunk003) {
shapeFile = "art/shapes/iceFlow/iceFlowChunk003.dts";
internalName = "FK_iceFlowChunk003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_iceFlowChunk003_2) {
shapeFile = "art/shapes/iceFlow/iceFlowChunk003_2.dts";
internalName = "FK_iceFlowChunk003_2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_boulder) {
shapeFile = "art/shapes/rocks/boulder.dts";
internalName = "FK_boulder";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rock1) {
shapeFile = "art/shapes/rocks/rock1.dts";
internalName = "FK_rock1";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rock2) {
shapeFile = "art/shapes/rocks/rock2.dts";
internalName = "FK_rock2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rock3) {
shapeFile = "art/shapes/rocks/rock3.dts";
internalName = "FK_rock3";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_basicBushHightAnimated) {
shapeFile
	= "art/shapes/ST_items/basicBush_Bent001/basicBushHightAnimated.dts";
internalName = "FK_basicBushHightAnimated";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_grassGREEN001) {
shapeFile = "art/shapes/ST_items/grassGREEN001/grassGREEN001.dts";
internalName = "FK_grassGREEN001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LODTREEGRNO04) {
shapeFile = "art/shapes/ST_items/LODTREEGRNO04.txt/LODTREEGRNO04.dts";
internalName = "FK_LODTREEGRNO04";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_ROCKLR3D001LOD) {
shapeFile = "art/shapes/ST_items/Rocks/RRGTS_ROCKLR3D001LOD.dts";
internalName = "FK_RRGTS_ROCKLR3D001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_ROCKLR3D002LOD) {
shapeFile = "art/shapes/ST_items/Rocks/RRGTS_ROCKLR3D002LOD.dts";
internalName = "FK_RRGTS_ROCKLR3D002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_ROCKLR3D003LOD) {
shapeFile = "art/shapes/ST_items/Rocks/RRGTS_ROCKLR3D003LOD.dts";
internalName = "FK_RRGTS_ROCKLR3D003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_ROCKLR3D004LOD) {
shapeFile = "art/shapes/ST_items/Rocks/RRGTS_ROCKLR3D004LOD.dts";
internalName = "FK_RRGTS_ROCKLR3D004LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_ROCKLR3D006LOD) {
shapeFile = "art/shapes/ST_items/Rocks/RRGTS_ROCKLR3D006LOD.dts";
internalName = "FK_RRGTS_ROCKLR3D006LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_ROCKLR3D007LOD) {
shapeFile = "art/shapes/ST_items/Rocks/RRGTS_ROCKLR3D007LOD.dts";
internalName = "FK_RRGTS_ROCKLR3D007LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_ROCKLR3D008LOD) {
shapeFile = "art/shapes/ST_items/Rocks/RRGTS_ROCKLR3D008LOD.dts";
internalName = "FK_RRGTS_ROCKLR3D008LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cached) {
shapeFile = "art/shapes/ST_items/Rocks/RRGTS_ROCKLR3D014LOD.cached.dts";
internalName = "FK_cached";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_ROCKLR3D014LOD) {
shapeFile = "art/shapes/ST_items/Rocks/RRGTS_ROCKLR3D014LOD.dts";
internalName = "FK_RRGTS_ROCKLR3D014LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newBushes001) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_BUSHES/newBushes001.dts";
internalName = "FK_newBushes001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newBushes002) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_BUSHES/newBushes002.dts";
internalName = "FK_newBushes002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newBushes003) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_BUSHES/newBushes003.dts";
internalName = "FK_newBushes003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTSnewBUSH001) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_BUSHES/RRGTSnewBUSH001.dts";
internalName = "FK_RRGTSnewBUSH001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fern001) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/fern001.dts";
internalName = "FK_fern001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fern002) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/fern002.dts";
internalName = "FK_fern002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fern003) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/fern003.dts";
internalName = "FK_fern003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fern004) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/fern004.dts";
internalName = "FK_fern004";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fern005) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/fern005.dts";
internalName = "FK_fern005";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fern006) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/fern006.dts";
internalName = "FK_fern006";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fern007) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/fern007.dts";
internalName = "FK_fern007";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fern008) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/fern008.dts";
internalName = "FK_fern008";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fern009) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/fern009.dts";
internalName = "FK_fern009";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fern010) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/fern010.dts";
internalName = "FK_fern010";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fern011) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/fern011.dts";
internalName = "FK_fern011";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fern012) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/fern012.dts";
internalName = "FK_fern012";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fern013) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/fern013.dts";
internalName = "FK_fern013";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fern014) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/fern014.dts";
internalName = "FK_fern014";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fern015) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/fern015.dts";
internalName = "FK_fern015";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newFerns001) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/newFerns001.dts";
internalName = "FK_newFerns001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newFerns002) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/newFerns002.dts";
internalName = "FK_newFerns002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newFerns003) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/newFerns003.dts";
internalName = "FK_newFerns003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newFerns004) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/newFerns004.dts";
internalName = "FK_newFerns004";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newFerns005) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/newFerns005.dts";
internalName = "FK_newFerns005";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newFerns006) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_FERNS/newFerns006.dts";
internalName = "FK_newFerns006";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LR3D_ROCK001ALOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/LR3D_ROCK001ALOD.dts";
internalName = "FK_LR3D_ROCK001ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LR3D_ROCK001BLOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/LR3D_ROCK001BLOD.dts";
internalName = "FK_LR3D_ROCK001BLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LR3D_ROCK001LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/LR3D_ROCK001LOD.dts";
internalName = "FK_LR3D_ROCK001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LR3D_ROCK002ALOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/LR3D_ROCK002ALOD.dts";
internalName = "FK_LR3D_ROCK002ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LR3D_ROCK002BLOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/LR3D_ROCK002BLOD.dts";
internalName = "FK_LR3D_ROCK002BLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LR3D_ROCK002LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/LR3D_ROCK002LOD.dts";
internalName = "FK_LR3D_ROCK002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LR3D_ROCK003ALOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/LR3D_ROCK003ALOD.dts";
internalName = "FK_LR3D_ROCK003ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LR3D_ROCK003BLOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/LR3D_ROCK003BLOD.dts";
internalName = "FK_LR3D_ROCK003BLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LR3D_ROCK003LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/LR3D_ROCK003LOD.dts";
internalName = "FK_LR3D_ROCK003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_001ALOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_001ALOD.dts";
internalName = "FK_rockLR3D_001ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_001BLOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_001BLOD.dts";
internalName = "FK_rockLR3D_001BLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_001LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_001LOD.dts";
internalName = "FK_rockLR3D_001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_002ALOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_002ALOD.dts";
internalName = "FK_rockLR3D_002ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_002BLOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_002BLOD.dts";
internalName = "FK_rockLR3D_002BLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_002LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_002LOD.dts";
internalName = "FK_rockLR3D_002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_003ALOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_003ALOD.dts";
internalName = "FK_rockLR3D_003ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_003BLOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_003BLOD.dts";
internalName = "FK_rockLR3D_003BLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_003LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_003LOD.dts";
internalName = "FK_rockLR3D_003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_004ALOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_004ALOD.dts";
internalName = "FK_rockLR3D_004ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_004BLOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_004BLOD.dts";
internalName = "FK_rockLR3D_004BLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_004LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_004LOD.dts";
internalName = "FK_rockLR3D_004LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_005ALOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_005ALOD.dts";
internalName = "FK_rockLR3D_005ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_005BLOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_005BLOD.dts";
internalName = "FK_rockLR3D_005BLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_005LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_005LOD.dts";
internalName = "FK_rockLR3D_005LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_006ALOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_006ALOD.dts";
internalName = "FK_rockLR3D_006ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_006BLOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_006BLOD.dts";
internalName = "FK_rockLR3D_006BLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_006BURNTLOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_006BURNTLOD.dts";
internalName = "FK_rockLR3D_006BURNTLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_006LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_006LOD.dts";
internalName = "FK_rockLR3D_006LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockLR3D_007BURNTLOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockLR3D_007BURNTLOD.dts";
internalName = "FK_rockLR3D_007BURNTLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockwFlatBottom01) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockwFlatBottom01.dts";
internalName = "FK_rockwFlatBottom01";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockwFlatBottom02) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockwFlatBottom02.dts";
internalName = "FK_rockwFlatBottom02";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockwRoundBottom01three) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockwRoundBottom01three.dts";
internalName = "FK_rockwRoundBottom01three";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockwRoundBottom01threeWCOL) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockwRoundBottom01threeWCOL.dts";
internalName = "FK_rockwRoundBottom01threeWCOL";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockwRoundBottom01threeWCOL2) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockwRoundBottom01threeWCOL2.dts";
internalName = "FK_rockwRoundBottom01threeWCOL2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockwRoundBottom01threeWCOL3) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockwRoundBottom01threeWCOL3.dts";
internalName = "FK_rockwRoundBottom01threeWCOL3";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockwRoundBottom01twoWCOL) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockwRoundBottom01twoWCOL.dts";
internalName = "FK_rockwRoundBottom01twoWCOL";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockwRoundBottom01twoWCOL2) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockwRoundBottom01twoWCOL2.dts";
internalName = "FK_rockwRoundBottom01twoWCOL2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockwRoundBottom01twoWCOL3) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockwRoundBottom01twoWCOL3.dts";
internalName = "FK_rockwRoundBottom01twoWCOL3";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockwRoundBottom01twoWCOL3B) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockwRoundBottom01twoWCOL3B.dts";
internalName = "FK_rockwRoundBottom01twoWCOL3B";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockwRoundBottom01twoWCOL3C) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockwRoundBottom01twoWCOL3C.dts";
internalName = "FK_rockwRoundBottom01twoWCOL3C";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_rockwRoundBottom01twoWCOL3D) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/rockwRoundBottom01twoWCOL3D.dts";
internalName = "FK_rockwRoundBottom01twoWCOL3D";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_ROCK_GREEN001) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/RRGT_ROCK_GREEN001.dts";
internalName = "FK_RRGT_ROCK_GREEN001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_ROCK_SPIKE001) {
shapeFile
	= "art/shapes/ST_items/RRGTS_ASSORTED_ROCKS/RRGT_ROCK_SPIKE001.dts";
internalName = "FK_RRGT_ROCK_SPIKE001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newWeeds001) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_WEEDS/newWeeds001.dts";
internalName = "FK_newWeeds001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newWeeds002) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_WEEDS/newWeeds002.dts";
internalName = "FK_newWeeds002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newWeeds003) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_WEEDS/newWeeds003.dts";
internalName = "FK_newWeeds003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newWeeds004) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_WEEDS/newWeeds004.dts";
internalName = "FK_newWeeds004";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newWeeds005) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_WEEDS/newWeeds005.dts";
internalName = "FK_newWeeds005";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newWeeds006) {
shapeFile = "art/shapes/ST_items/RRGTS_ASSORTED_WEEDS/newWeeds006.dts";
internalName = "FK_newWeeds006";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_BUSHBRWN001) {
shapeFile = "art/shapes/ST_items/RRGTS_BUSHBRWN001/RRGTS_BUSHBRWN001.dts";
internalName = "FK_RRGTS_BUSHBRWN001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_BUSHBRWN002) {
shapeFile = "art/shapes/ST_items/RRGTS_BUSHBRWN002/RRGTS_BUSHBRWN002.dts";
internalName = "FK_RRGTS_BUSHBRWN002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_BUSHBRWN_MC001) {
shapeFile
	= "art/shapes/ST_items/RRGTS_BUSHBRWN_MC001/RRGTS_BUSHBRWN_MC001.dts";
internalName = "FK_RRGTS_BUSHBRWN_MC001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_BUSHGRN001) {
shapeFile = "art/shapes/ST_items/RRGTS_BUSHGRN001/RRGTS_BUSHGRN001.dts";
internalName = "FK_RRGTS_BUSHGRN001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_BUSHGRN002) {
shapeFile = "art/shapes/ST_items/RRGTS_BUSHGRN002/RRGTS_BUSHGRN002.dts";
internalName = "FK_RRGTS_BUSHGRN002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_cactus001LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_CACTUS001/cactus001LOD.dts";
internalName = "FK_cactus001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_CLUMPGRASSBRWN001) {
shapeFile
	= "art/shapes/ST_items/RRGTS_CLUMPGRASSGRN001/RRGTS_CLUMPGRASSBRWN001.dts";
internalName = "FK_RRGTS_CLUMPGRASSBRWN001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_CLUMPGRASSGRN001) {
shapeFile
	= "art/shapes/ST_items/RRGTS_CLUMPGRASSGRN001/RRGTS_CLUMPGRASSGRN001.dts";
internalName = "FK_RRGTS_CLUMPGRASSGRN001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_FERN1_001) {
shapeFile = "art/shapes/ST_items/RRGTS_FERN1_001/RRGTS_FERN1_001.dts";
internalName = "FK_RRGTS_FERN1_001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_FERN1_002) {
shapeFile = "art/shapes/ST_items/RRGTS_FERN1_002/RRGTS_FERN1_002.dts";
internalName = "FK_RRGTS_FERN1_002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_FERN1_003) {
shapeFile = "art/shapes/ST_items/RRGTS_FERN1_003/RRGTS_FERN1_003.dts";
internalName = "FK_RRGTS_FERN1_003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_FERN2_001) {
shapeFile = "art/shapes/ST_items/RRGTS_FERN2_001/RRGTS_FERN2_001.dts";
internalName = "FK_RRGTS_FERN2_001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_FERN2_002) {
shapeFile = "art/shapes/ST_items/RRGTS_FERN2_002/RRGTS_FERN2_002.dts";
internalName = "FK_RRGTS_FERN2_002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_FERN2_003) {
shapeFile = "art/shapes/ST_items/RRGTS_FERN2_003/RRGTS_FERN2_003.dts";
internalName = "FK_RRGTS_FERN2_003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_FERN3_001) {
shapeFile = "art/shapes/ST_items/RRGTS_FERN3_001/RRGTS_FERN3_001.dts";
internalName = "FK_RRGTS_FERN3_001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_FERN3_002) {
shapeFile = "art/shapes/ST_items/RRGTS_FERN3_002/RRGTS_FERN3_002.dts";
internalName = "FK_RRGTS_FERN3_002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_FERN3_003) {
shapeFile = "art/shapes/ST_items/RRGTS_FERN3_003/RRGTS_FERN3_003.dts";
internalName = "FK_RRGTS_FERN3_003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_JUNGLETREEGRN001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_JUNGLETREEGRN001.txt/RRGTS_JUNGLETREEGRN001LOD.dts";
internalName = "FK_RRGTS_JUNGLETREEGRN001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_JUNGLETREES002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_JUNGLETREES002.txt/RRGTS_JUNGLETREES002LOD.dts";
internalName = "FK_RRGTS_JUNGLETREES002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_LILYPAD2_001N) {
shapeFile
	= "art/shapes/ST_items/RRGTS_LILYPAD2_001N/RRGTS_LILYPAD2_001N.dts";
internalName = "FK_RRGTS_LILYPAD2_001N";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_LILYPAD2_001N2) {
shapeFile
	= "art/shapes/ST_items/RRGTS_LILYPAD2_001N/RRGTS_LILYPAD2_001N2.dts";
internalName = "FK_RRGTS_LILYPAD2_001N2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_LILYPAD2_002N) {
shapeFile
	= "art/shapes/ST_items/RRGTS_LILYPAD2_002N/RRGTS_LILYPAD2_002N.dts";
internalName = "FK_RRGTS_LILYPAD2_002N";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_LILYPAD_001) {
shapeFile = "art/shapes/ST_items/RRGTS_LILYPAD_001/RRGTS_LILYPAD_001.dts";
internalName = "FK_RRGTS_LILYPAD_001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_LILYPAD_001v3) {
shapeFile = "art/shapes/ST_items/RRGTS_LILYPAD_001/RRGTS_LILYPAD_001v3.dts";
internalName = "FK_RRGTS_LILYPAD_001v3";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_LILYPAD_002) {
shapeFile = "art/shapes/ST_items/RRGTS_LILYPAD_002/RRGTS_LILYPAD_002.dts";
internalName = "FK_RRGTS_LILYPAD_002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_LILYPAD_003) {
shapeFile = "art/shapes/ST_items/RRGTS_LILYPAD_003N/RRGTS_LILYPAD_003.dts";
internalName = "FK_RRGTS_LILYPAD_003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LR3D_ROCK001) {
shapeFile = "art/shapes/ST_items/RRGTS_LR3D_ROCK001/LR3D_ROCK001.dts";
internalName = "FK_LR3D_ROCK001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LR3D_ROCK001A) {
shapeFile = "art/shapes/ST_items/RRGTS_LR3D_ROCK001A/LR3D_ROCK001A.dts";
internalName = "FK_LR3D_ROCK001A";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LR3D_ROCK001ALOD) {
shapeFile = "art/shapes/ST_items/RRGTS_LR3D_ROCK001A/LR3D_ROCK001ALOD.dts";
internalName = "FK_LR3D_ROCK001ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LR3D_ROCK001BLOD) {
shapeFile = "art/shapes/ST_items/RRGTS_LR3D_ROCK001A/LR3D_ROCK001BLOD.dts";
internalName = "FK_LR3D_ROCK001BLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LR3D_ROCK001CLOD) {
shapeFile = "art/shapes/ST_items/RRGTS_LR3D_ROCK001A/LR3D_ROCK001CLOD.dts";
internalName = "FK_LR3D_ROCK001CLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_MUSHROOM_BRWN001) {
shapeFile
	= "art/shapes/ST_items/RRGTS_MUSHROOM_BRWN001/RRGTS_MUSHROOM_BRWN001.dts";
internalName = "FK_RRGTS_MUSHROOM_BRWN001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_MUSHROOM_BRWN002) {
shapeFile
	= "art/shapes/ST_items/RRGTS_MUSHROOM_BRWN002/RRGTS_MUSHROOM_BRWN002.dts";
internalName = "FK_RRGTS_MUSHROOM_BRWN002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_MUSHROOM_BRWN003) {
shapeFile
	= "art/shapes/ST_items/RRGTS_MUSHROOM_BRWN003/RRGTS_MUSHROOM_BRWN003.dts";
internalName = "FK_RRGTS_MUSHROOM_BRWN003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_MUSHROOM_BRWN004) {
shapeFile
	= "art/shapes/ST_items/RRGTS_MUSHROOM_BRWN004/RRGTS_MUSHROOM_BRWN004.dts";
internalName = "FK_RRGTS_MUSHROOM_BRWN004";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_MUSHROOM_WHT001) {
shapeFile
	= "art/shapes/ST_items/RRGTS_MUSHROOM_WHT001/RRGTS_MUSHROOM_WHT001.dts";
internalName = "FK_RRGTS_MUSHROOM_WHT001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_MUSHROOM_WHT002) {
shapeFile
	= "art/shapes/ST_items/RRGTS_MUSHROOM_WHT002/RRGTS_MUSHROOM_WHT002.dts";
internalName = "FK_RRGTS_MUSHROOM_WHT002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_MUSHROOM_WHT003) {
shapeFile
	= "art/shapes/ST_items/RRGTS_MUSHROOM_WHT003/RRGTS_MUSHROOM_WHT003.dts";
internalName = "FK_RRGTS_MUSHROOM_WHT003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_ROCK_GREEN001) {
shapeFile = "art/shapes/ST_items/RRGTS_ROCKS/RRGTS_ROCK_GREEN001.dts";
internalName = "FK_RRGTS_ROCK_GREEN001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_ROCK_SPIKE001) {
shapeFile = "art/shapes/ST_items/RRGTS_ROCKS/RRGT_ROCK_SPIKE001.dts";
internalName = "FK_RRGT_ROCK_SPIKE001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_ROCK_SPIKE002) {
shapeFile = "art/shapes/ST_items/RRGTS_ROCKS/RRGT_ROCK_SPIKE002.dts";
internalName = "FK_RRGT_ROCK_SPIKE002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_ROCKS2_001) {
shapeFile = "art/shapes/ST_items/RRGTS_ROCKS2_001/RRGTS_ROCKS2_001.dts";
internalName = "FK_RRGTS_ROCKS2_001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_ROCKS2_001LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ROCKS2_001/RRGTS_ROCKS2_001LOD.dts";
internalName = "FK_RRGTS_ROCKS2_001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_ROCKS3_001) {
shapeFile = "art/shapes/ST_items/RRGTS_ROCKS3_001/RRGTS_ROCKS3_001.dts";
internalName = "FK_RRGTS_ROCKS3_001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_ROCKS3_001LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_ROCKS3_001/RRGTS_ROCKS3_001LOD.dts";
internalName = "FK_RRGTS_ROCKS3_001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_ROCKS3_001) {
shapeFile = "art/shapes/ST_items/RRGTS_ROCKS3_003/RRGTS_ROCKS3_001.dts";
internalName = "FK_RRGTS_ROCKS3_001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_BAREWHT001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_BAREWHT001.txt/RRGTS_TREE_BAREWHT001LOD.dts";
internalName = "FK_RRGTS_TREE_BAREWHT001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_DEADSPLT001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_DEADSPLT001.txt/RRGTS_TREE_DEADSPLT001LOD.dts";
internalName = "FK_RRGTS_TREE_DEADSPLT001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_DEADSPLT002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_DEADSPLT002.txt/RRGTS_TREE_DEADSPLT002LOD.dts";
internalName = "FK_RRGTS_TREE_DEADSPLT002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNARCH001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNARCH001.txt/RRGTS_TREE_GRNARCH001LOD.dts";
internalName = "FK_RRGTS_TREE_GRNARCH001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNARCH002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNARCH002.txt/RRGTS_TREE_GRNARCH002LOD.dts";
internalName = "FK_RRGTS_TREE_GRNARCH002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNARCH003LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNARCH003.txt/RRGTS_TREE_GRNARCH003LOD.dts";
internalName = "FK_RRGTS_TREE_GRNARCH003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNARCH004LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNARCH004.txt/RRGTS_TREE_GRNARCH004LOD.dts";
internalName = "FK_RRGTS_TREE_GRNARCH004LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNARCH007LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNARCH007.txt/RRGTS_TREE_GRNARCH007LOD.dts";
internalName = "FK_RRGTS_TREE_GRNARCH007LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNARCH008LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNARCH008.txt/RRGTS_TREE_GRNARCH008LOD.dts";
internalName = "FK_RRGTS_TREE_GRNARCH008LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNARCH008NRLOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNARCH008NR.txt/RRGTS_TREE_GRNARCH008NRLOD.dts";
internalName = "FK_RRGTS_TREE_GRNARCH008NRLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNARCH009LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNARCH009.txt/RRGTS_TREE_GRNARCH009LOD.dts";
internalName = "FK_RRGTS_TREE_GRNARCH009LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNJNGLE001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNJNGLE001.txt/RRGTS_TREE_GRNJNGLE001LOD.dts";
internalName = "FK_RRGTS_TREE_GRNJNGLE001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNJNGLE002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNJNGLE002.txt/RRGTS_TREE_GRNJNGLE002LOD.dts";
internalName = "FK_RRGTS_TREE_GRNJNGLE002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNPINE001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNPINE001.txt/RRGTS_TREE_GRNPINE001LOD.dts";
internalName = "FK_RRGTS_TREE_GRNPINE001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNPINE002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNPINE002.txt/RRGTS_TREE_GRNPINE002LOD.dts";
internalName = "FK_RRGTS_TREE_GRNPINE002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNPINE003LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNPINE003.txt/RRGTS_TREE_GRNPINE003LOD.dts";
internalName = "FK_RRGTS_TREE_GRNPINE003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNPINE004LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNPINE004.txt/RRGTS_TREE_GRNPINE004LOD.dts";
internalName = "FK_RRGTS_TREE_GRNPINE004LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNPINE005LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNPINE005.txt/RRGTS_TREE_GRNPINE005LOD.dts";
internalName = "FK_RRGTS_TREE_GRNPINE005LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNPINE006LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNPINE006.txt/RRGTS_TREE_GRNPINE006LOD.dts";
internalName = "FK_RRGTS_TREE_GRNPINE006LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNPINE006LODlow) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNPINE006.txt/RRGTS_TREE_GRNPINE006LODlow.dts";
internalName = "FK_RRGTS_TREE_GRNPINE006LODlow";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNPINE006LODlowBB) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNPINE006.txt/RRGTS_TREE_GRNPINE006LODlowBB.dts";
internalName = "FK_RRGTS_TREE_GRNPINE006LODlowBB";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNPINE007) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNPINE007.txt/RRGTS_TREE_GRNPINE007.dts";
internalName = "FK_RRGTS_TREE_GRNPINE007";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNPINE007low) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNPINE007.txt/RRGTS_TREE_GRNPINE007low.dts";
internalName = "FK_RRGTS_TREE_GRNPINE007low";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNPINE007lowBB) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNPINE007.txt/RRGTS_TREE_GRNPINE007lowBB.dts";
internalName = "FK_RRGTS_TREE_GRNPINE007lowBB";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNPINE008LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNPINE008.txt/RRGTS_TREE_GRNPINE008LOD.dts";
internalName = "FK_RRGTS_TREE_GRNPINE008LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNPINE008LODlow) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNPINE008.txt/RRGTS_TREE_GRNPINE008LODlow.dts";
internalName = "FK_RRGTS_TREE_GRNPINE008LODlow";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNPINE008LODlowBB) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNPINE008.txt/RRGTS_TREE_GRNPINE008LODlowBB.dts";
internalName = "FK_RRGTS_TREE_GRNPINE008LODlowBB";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNSPTL001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNSPLT001.txt/RRGTS_TREE_GRNSPTL001LOD.dts";
internalName = "FK_RRGTS_TREE_GRNSPTL001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNSPLT002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNSPLT002.txt/RRGTS_TREE_GRNSPLT002LOD.dts";
internalName = "FK_RRGTS_TREE_GRNSPLT002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNSPLT003LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNSPLT003.txt/RRGTS_TREE_GRNSPLT003LOD.dts";
internalName = "FK_RRGTS_TREE_GRNSPLT003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNSWMP001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNSWMP001.txt/RRGTS_TREE_GRNSWMP001LOD.dts";
internalName = "FK_RRGTS_TREE_GRNSWMP001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNSWMP002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNSWMP002.txt/RRGTS_TREE_GRNSWMP002LOD.dts";
internalName = "FK_RRGTS_TREE_GRNSWMP002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNSWMP003LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNSWMP003.txt/RRGTS_TREE_GRNSWMP003LOD.dts";
internalName = "FK_RRGTS_TREE_GRNSWMP003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNSWMP004LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNSWMP004.txt/RRGTS_TREE_GRNSWMP004LOD.dts";
internalName = "FK_RRGTS_TREE_GRNSWMP004LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNTALL001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNTALL001.txt/RRGTS_TREE_GRNTALL001LOD.dts";
internalName = "FK_RRGTS_TREE_GRNTALL001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNTHIN001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNTHIN001.txt/RRGTS_TREE_GRNTHIN001LOD.dts";
internalName = "FK_RRGTS_TREE_GRNTHIN001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNTHIN001LOD_HOLD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNTHIN001.txt/RRGTS_TREE_GRNTHIN001LOD.dts_HOLD";
internalName = "FK_RRGTS_TREE_GRNTHIN001LOD_HOLD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNTHIN002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNTHIN002.txt/RRGTS_TREE_GRNTHIN002LOD.dts";
internalName = "FK_RRGTS_TREE_GRNTHIN002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_GRNTHIN003LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_GRNTHIN003.txt/RRGTS_TREE_GRNTHIN003LOD.dts";
internalName = "FK_RRGTS_TREE_GRNTHIN003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_JUNGLE003LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_JUNGLE003.txt/RRGTS_TREE_JUNGLE003LOD.dts";
internalName = "FK_RRGTS_TREE_JUNGLE003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_JUNGLE004LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_JUNGLE004.txt/RRGTS_TREE_JUNGLE004LOD.dts";
internalName = "FK_RRGTS_TREE_JUNGLE004LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_JUNGLE005LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_JUNGLE005.txt/RRGTS_TREE_JUNGLE005LOD.dts";
internalName = "FK_RRGTS_TREE_JUNGLE005LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_JUNGLE006LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_JUNGLE006.txt/RRGTS_TREE_JUNGLE006LOD.dts";
internalName = "FK_RRGTS_TREE_JUNGLE006LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_JUNGLE007LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_JUNGLE007.txt/RRGTS_TREE_JUNGLE007LOD.dts";
internalName = "FK_RRGTS_TREE_JUNGLE007LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_JUNGLE008LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_JUNGLE008.txt/RRGTS_TREE_JUNGLE008LOD.dts";
internalName = "FK_RRGTS_TREE_JUNGLE008LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_LOG001) {
shapeFile = "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_LOG001.dts";
internalName = "FK_RRGTS_TREE_LOG001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_LOG001LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_LOG001LOD.dts";
internalName = "FK_RRGTS_TREE_LOG001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_LOG002) {
shapeFile = "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_LOG002.dts";
internalName = "FK_RRGTS_TREE_LOG002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_LOG002LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_LOG002LOD.dts";
internalName = "FK_RRGTS_TREE_LOG002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_LOG003) {
shapeFile = "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_LOG003.dts";
internalName = "FK_RRGTS_TREE_LOG003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_LOG003LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_LOG003LOD.dts";
internalName = "FK_RRGTS_TREE_LOG003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_LOG004) {
shapeFile = "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_LOG004.dts";
internalName = "FK_RRGTS_TREE_LOG004";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_LOG004LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_LOG004LOD.dts";
internalName = "FK_RRGTS_TREE_LOG004LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_LOG005) {
shapeFile = "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_LOG005.dts";
internalName = "FK_RRGTS_TREE_LOG005";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_LOG005LOD) {
shapeFile = "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_LOG005LOD.dts";
internalName = "FK_RRGTS_TREE_LOG005LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_STUMP001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_STUMP001LOD.dts";
internalName = "FK_RRGTS_TREE_STUMP001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_STUMP002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_STUMP002LOD.dts";
internalName = "FK_RRGTS_TREE_STUMP002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_STUMP003LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_STUMP003LOD.dts";
internalName = "FK_RRGTS_TREE_STUMP003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_STUMP004LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_STUMP004LOD.dts";
internalName = "FK_RRGTS_TREE_STUMP004LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_STUMP005LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_STUMP005LOD.dts";
internalName = "FK_RRGTS_TREE_STUMP005LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_STUMP006LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_LOGS/RRGTS_TREE_STUMP006LOD.dts";
internalName = "FK_RRGTS_TREE_STUMP006LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_OAKORG002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_OAKORG002.txt/RRGTS_TREE_OAKORG002LOD.dts";
internalName = "FK_RRGTS_TREE_OAKORG002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_OAKORG004LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_OAKORG004.txt/RRGTS_TREE_OAKORG004LOD.dts";
internalName = "FK_RRGTS_TREE_OAKORG004LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_OLDOAK005LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_OLDOAK005/RRGTS_TREE_OLDOAK005LOD.dts";
internalName = "FK_RRGTS_TREE_OLDOAK005LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_OLDOAK006LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_OLDOAK006.txt/RRGTS_TREE_OLDOAK006LOD.dts";
internalName = "FK_RRGTS_TREE_OLDOAK006LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_OLDOAK007LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_OLDOAK007.txt/RRGTS_TREE_OLDOAK007LOD.dts";
internalName = "FK_RRGTS_TREE_OLDOAK007LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_OLDOAK008LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_OLDOAK008.txt/RRGTS_TREE_OLDOAK008LOD.dts";
internalName = "FK_RRGTS_TREE_OLDOAK008LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_OLDOAKGRN001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_OLDOAKGRN001/RRGTS_TREE_OLDOAKGRN001LOD.dts";
internalName = "FK_RRGTS_TREE_OLDOAKGRN001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_OLDOAKGRN002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_OLDOAKGRN002.txt/RRGTS_TREE_OLDOAKGRN002LOD.dts";
internalName = "FK_RRGTS_TREE_OLDOAKGRN002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_OLDOAKGRN003LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_OLDOAKGRN003.txt/RRGTS_TREE_OLDOAKGRN003LOD.dts";
internalName = "FK_RRGTS_TREE_OLDOAKGRN003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_OLDOAKGRN004LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_OLDOAKGRN004.txt/RRGTS_TREE_OLDOAKGRN004LOD.dts";
internalName = "FK_RRGTS_TREE_OLDOAKGRN004LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_OLDOAKGRN005LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_OLDOAKGRN005.txt/RRGTS_TREE_OLDOAKGRN005LOD.dts";
internalName = "FK_RRGTS_TREE_OLDOAKGRN005LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALM005ALOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALM005.txt/RRGTS_TREE_PALM005ALOD.dts";
internalName = "FK_RRGTS_TREE_PALM005ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALM005LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALM005.txt/RRGTS_TREE_PALM005LOD.dts";
internalName = "FK_RRGTS_TREE_PALM005LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALMNEW001ALOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALMNEW001.txt/RRGTS_TREE_PALMNEW001ALOD.dts";
internalName = "FK_RRGTS_TREE_PALMNEW001ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALMNEW001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALMNEW001.txt/RRGTS_TREE_PALMNEW001LOD.dts";
internalName = "FK_RRGTS_TREE_PALMNEW001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALMNEW002A2LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALMNEW002.txt/RRGTS_TREE_PALMNEW002A2LOD.dts";
internalName = "FK_RRGTS_TREE_PALMNEW002A2LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALMNEW002ALOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALMNEW002.txt/RRGTS_TREE_PALMNEW002ALOD.dts";
internalName = "FK_RRGTS_TREE_PALMNEW002ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALMNEW002B2LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALMNEW002.txt/RRGTS_TREE_PALMNEW002B2LOD.dts";
internalName = "FK_RRGTS_TREE_PALMNEW002B2LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALMNEW002BLOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALMNEW002.txt/RRGTS_TREE_PALMNEW002BLOD.dts";
internalName = "FK_RRGTS_TREE_PALMNEW002BLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALMNEW002C2LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALMNEW002.txt/RRGTS_TREE_PALMNEW002C2LOD.dts";
internalName = "FK_RRGTS_TREE_PALMNEW002C2LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALMNEW002CLOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALMNEW002.txt/RRGTS_TREE_PALMNEW002CLOD.dts";
internalName = "FK_RRGTS_TREE_PALMNEW002CLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALMNEW003ALOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALMNEW003.txt/RRGTS_TREE_PALMNEW003ALOD.dts";
internalName = "FK_RRGTS_TREE_PALMNEW003ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALMNEW003LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALMNEW003.txt/RRGTS_TREE_PALMNEW003LOD.dts";
internalName = "FK_RRGTS_TREE_PALMNEW003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALMNEW004LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALMNEW004.txt/RRGTS_TREE_PALMNEW004LOD.dts";
internalName = "FK_RRGTS_TREE_PALMNEW004LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALMNEW005) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALMNEW005.txt/RRGTS_TREE_PALMNEW005.dts";
internalName = "FK_RRGTS_TREE_PALMNEW005";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALMNEW005BLOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALMNEW005.txt/RRGTS_TREE_PALMNEW005BLOD.dts";
internalName = "FK_RRGTS_TREE_PALMNEW005BLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_PALMNEW005CLOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_PALMNEW005.txt/RRGTS_TREE_PALMNEW005CLOD.dts";
internalName = "FK_RRGTS_TREE_PALMNEW005CLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_THINOAK002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_THINOAK002.txt/RRGTS_TREE_THINOAK002LOD.dts";
internalName = "FK_RRGTS_TREE_THINOAK002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_WHITEORG001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_WHITEORG001.txt/RRGTS_TREE_WHITEORG001LOD.dts";
internalName = "FK_RRGTS_TREE_WHITEORG001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TREE_WINTEROAK001) {
shapeFile
	= "art/shapes/ST_items/RRGTS_TREE_WINTEROAK001.txt/RRGTS_TREE_WINTEROAK001.dts";
internalName = "FK_RRGTS_TREE_WINTEROAK001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TWIG_GRN001) {
shapeFile = "art/shapes/ST_items/RRGTS_TWIG_GRN001/RRGTS_TWIG_GRN001.dts";
internalName = "FK_RRGTS_TWIG_GRN001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_TWIG_GRN002) {
shapeFile = "art/shapes/ST_items/RRGTS_TWIG_GRN002/RRGTS_TWIG_GRN002.dts";
internalName = "FK_RRGTS_TWIG_GRN002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_WEEDS_001) {
shapeFile = "art/shapes/ST_items/RRGTS_WEEDS_001/RRGTS_WEEDS_001.dts";
internalName = "FK_RRGTS_WEEDS_001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_WEEDS_001B) {
shapeFile = "art/shapes/ST_items/RRGTS_WEEDS_001B/RRGTS_WEEDS_001B.dts";
internalName = "FK_RRGTS_WEEDS_001B";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_WEEDS_002) {
shapeFile = "art/shapes/ST_items/RRGTS_WEEDS_002/RRGTS_WEEDS_002.dts";
internalName = "FK_RRGTS_WEEDS_002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_WEEDS_003) {
shapeFile = "art/shapes/ST_items/RRGTS_WEEDS_003/RRGTS_WEEDS_003.dts";
internalName = "FK_RRGTS_WEEDS_003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_WEEDS_003B) {
shapeFile = "art/shapes/ST_items/RRGTS_WEEDS_003B/RRGTS_WEEDS_003B.dts";
internalName = "FK_RRGTS_WEEDS_003B";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGTS_WEEDS_004B) {
shapeFile = "art/shapes/ST_items/RRGTS_WEEDS_004B/RRGTS_WEEDS_004B.dts";
internalName = "FK_RRGTS_WEEDS_004B";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_grassGREEN001) {
shapeFile = "art/shapes/ST_items/RRGT_GRASSGREEN001/grassGREEN001.dts";
internalName = "FK_grassGREEN001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LODTREEDRKOAK001) {
shapeFile
	= "art/shapes/ST_items/RRGT_LODTREEDRKOAK001.txt/LODTREEDRKOAK001.dts";
internalName = "FK_LODTREEDRKOAK001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LODTREEDRKOAK002) {
shapeFile
	= "art/shapes/ST_items/RRGT_LODTREEDRKOAK002.txt/LODTREEDRKOAK002.dts";
internalName = "FK_LODTREEDRKOAK002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_LODTREEGRNO04) {
shapeFile = "art/shapes/ST_items/RRGT_LODTREEGRNO04.txt/LODTREEGRNO04.dts";
internalName = "FK_LODTREEGRNO04";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newBushes001) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newBushes001.dts";
internalName = "FK_newBushes001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newBushes002) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newBushes002.dts";
internalName = "FK_newBushes002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newBushes003) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newBushes003.dts";
internalName = "FK_newBushes003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newFerns001) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newFerns001.dts";
internalName = "FK_newFerns001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newFerns002) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newFerns002.dts";
internalName = "FK_newFerns002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newFerns003) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newFerns003.dts";
internalName = "FK_newFerns003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newFerns004) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newFerns004.dts";
internalName = "FK_newFerns004";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newFerns005) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newFerns005.dts";
internalName = "FK_newFerns005";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newFerns006) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newFerns006.dts";
internalName = "FK_newFerns006";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
}
;
datablock TSForestItemData(FK_newTropicals001) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newTropicals001.dts";
internalName = "FK_newTropicals001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newWeeds001) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newWeeds001.dts";
internalName = "FK_newWeeds001";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newWeeds002) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newWeeds002.dts";
internalName = "FK_newWeeds002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newWeeds003) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newWeeds003.dts";
internalName = "FK_newWeeds003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newWeeds004) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newWeeds004.dts";
internalName = "FK_newWeeds004";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newWeeds005) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newWeeds005.dts";
internalName = "FK_newWeeds005";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_newWeeds006) {
shapeFile = "art/shapes/ST_items/RRGT_PLANTS/newWeeds006.dts";
internalName = "FK_newWeeds006";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_ASPEN001ALOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_ASPEN001.txt/RRGT_TREE_ASPEN001ALOD.dts";
internalName = "FK_RRGT_TREE_ASPEN001ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_ASPEN001BLOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_ASPEN001.txt/RRGT_TREE_ASPEN001BLOD.dts";
internalName = "FK_RRGT_TREE_ASPEN001BLOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_ASPEN001BLOD_HOLD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_ASPEN001.txt/RRGT_TREE_ASPEN001BLOD.dts_HOLD";
internalName = "FK_RRGT_TREE_ASPEN001BLOD_HOLD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_ASPEN002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_ASPEN002.txt/RRGT_TREE_ASPEN002LOD.dts";
internalName = "FK_RRGT_TREE_ASPEN002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_BARE001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_BARE001.txt/RRGT_TREE_BARE001LOD.dts";
internalName = "FK_RRGT_TREE_BARE001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_BARE002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_BARE002.txt/RRGT_TREE_BARE002LOD.dts";
internalName = "FK_RRGT_TREE_BARE002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_BURNT001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_BURNT001.txt/RRGT_TREE_BURNT001LOD.dts";
internalName = "FK_RRGT_TREE_BURNT001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_BURNT002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_BURNT001.txt/RRGT_TREE_BURNT002LOD.dts";
internalName = "FK_RRGT_TREE_BURNT002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
}
;
datablock TSForestItemData(FK_RRGT_TREE_GREEN001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_GREEN001.txt/RRGT_TREE_GREEN001LOD.dts";
internalName = "FK_RRGT_TREE_GREEN001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_GREEN002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_GREEN002.txt/RRGT_TREE_GREEN002LOD.dts";
internalName = "FK_RRGT_TREE_GREEN002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_GREEN003LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_GREEN003.txt/RRGT_TREE_GREEN003LOD.dts";
internalName = "FK_RRGT_TREE_GREEN003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_GREEN004LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_GREEN004.txt/RRGT_TREE_GREEN004LOD.dts";
internalName = "FK_RRGT_TREE_GREEN004LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_GREEN005LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_GREEN005.txt/RRGT_TREE_GREEN005LOD.dts";
internalName = "FK_RRGT_TREE_GREEN005LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_BRANCH007LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_GREEN007.txt/RRGT_TREE_BRANCH007LOD.dts";
internalName = "FK_RRGT_TREE_BRANCH007LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_OLDOAK002) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_OLDOAK002.txt/RRGT_TREE_OLDOAK002.dts";
internalName = "FK_RRGT_TREE_OLDOAK002";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_OLDOAK002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_OLDOAK002.txt/RRGT_TREE_OLDOAK002LOD.dts";
internalName = "FK_RRGT_TREE_OLDOAK002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_PALM001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_PALM001.txt/RRGT_TREE_PALM001LOD.dts";
internalName = "FK_RRGT_TREE_PALM001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_PALM002ALOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_PALM002.txt/RRGT_TREE_PALM002ALOD.dts";
internalName = "FK_RRGT_TREE_PALM002ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_PALM002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_PALM002.txt/RRGT_TREE_PALM002LOD.dts";
internalName = "FK_RRGT_TREE_PALM002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_PALM003ALOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_PALM003.txt/RRGT_TREE_PALM003ALOD.dts";
internalName = "FK_RRGT_TREE_PALM003ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_PALM003LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_PALM003.txt/RRGT_TREE_PALM003LOD.dts";
internalName = "FK_RRGT_TREE_PALM003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_PALM004ALOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_PALM004.txt/RRGT_TREE_PALM004ALOD.dts";
internalName = "FK_RRGT_TREE_PALM004ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_PALM004LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_PALM004.txt/RRGT_TREE_PALM004LOD.dts";
internalName = "FK_RRGT_TREE_PALM004LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_PALM005ALOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_PALM005.txt/RRGT_TREE_PALM005ALOD.dts";
internalName = "FK_RRGT_TREE_PALM005ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_PALM005LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_PALM005.txt/RRGT_TREE_PALM005LOD.dts";
internalName = "FK_RRGT_TREE_PALM005LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_PALM006ALOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_PALM006.txt/RRGT_TREE_PALM006ALOD.dts";
internalName = "FK_RRGT_TREE_PALM006ALOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_PALM006LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_PALM006.txt/RRGT_TREE_PALM006LOD.dts";
internalName = "FK_RRGT_TREE_PALM006LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_WHITE001LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_WHITE001.txt/RRGT_TREE_WHITE001LOD.dts";
internalName = "FK_RRGT_TREE_WHITE001LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_WHITE001LODv2) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_WHITE001.txt/RRGT_TREE_WHITE001LODv2.dts";
internalName = "FK_RRGT_TREE_WHITE001LODv2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_WHITE002LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_WHITE002.txt/RRGT_TREE_WHITE002LOD.dts";
internalName = "FK_RRGT_TREE_WHITE002LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_WHITE002LODv2) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_WHITE002.txt/RRGT_TREE_WHITE002LODv2.dts";
internalName = "FK_RRGT_TREE_WHITE002LODv2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_WHITE003LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_WHITE003.txt/RRGT_TREE_WHITE003LOD.dts";
internalName = "FK_RRGT_TREE_WHITE003LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_WHITE003LODv2) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_WHITE003.txt/RRGT_TREE_WHITE003LODv2.dts";
internalName = "FK_RRGT_TREE_WHITE003LODv2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_WHITE004LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_WHITE004.txt/RRGT_TREE_WHITE004LOD.dts";
internalName = "FK_RRGT_TREE_WHITE004LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_WHITE004LODv2) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_WHITE004.txt/RRGT_TREE_WHITE004LODv2.dts";
internalName = "FK_RRGT_TREE_WHITE004LODv2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_WHITE005LOD) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_WHITE005.txt/RRGT_TREE_WHITE005LOD.dts";
internalName = "FK_RRGT_TREE_WHITE005LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_RRGT_TREE_WHITE005LODv2) {
shapeFile
	= "art/shapes/ST_items/RRGT_TREE_WHITE005.txt/RRGT_TREE_WHITE005LODv2.dts";
internalName = "FK_RRGT_TREE_WHITE005LODv2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_waterfall) {
shapeFile = "art/shapes/WFsequence1/waterfall.dts";
internalName = "FK_waterfall";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_Barrel003) {
shapeFile = "art/shapes/WW2 Buildings/Barrel003/Barrel003.dts";
internalName = "FK_Barrel003";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_Barrel003F_LOD) {
shapeFile = "art/shapes/WW2 Buildings/Barrel003/Barrel003F_LOD.dts";
internalName = "FK_Barrel003F_LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_Barrel003_LOD) {
shapeFile = "art/shapes/WW2 Buildings/Barrel003/Barrel003_LOD.dts";
internalName = "FK_Barrel003_LOD";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_basic2Room01A) {
shapeFile = "art/shapes/WW2 Buildings/basic2Room01A/basic2Room01A.dts";
internalName = "FK_basic2Room01A";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_guardTowerWstairs2) {
shapeFile
	= "art/shapes/WW2 Buildings/guardTowerWstairs2/guardTowerWstairs2.dts";
internalName = "FK_guardTowerWstairs2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fencePostBasic00A) {
shapeFile = "art/shapes/WW2 Buildings/oldFence/fencePostBasic00A.dts";
internalName = "FK_fencePostBasic00A";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fencePostBasic00B) {
shapeFile = "art/shapes/WW2 Buildings/oldFence/fencePostBasic00B.dts";
internalName = "FK_fencePostBasic00B";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fencePostBasic00C) {
shapeFile = "art/shapes/WW2 Buildings/oldFence/fencePostBasic00C.dts";
internalName = "FK_fencePostBasic00C";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fencePostBasic00D) {
shapeFile = "art/shapes/WW2 Buildings/oldFence/fencePostBasic00D.dts";
internalName = "FK_fencePostBasic00D";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fenceSection2Post01) {
shapeFile = "art/shapes/WW2 Buildings/oldFence/fenceSection2Post01.dts";
internalName = "FK_fenceSection2Post01";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fenceSection2Post01A) {
shapeFile = "art/shapes/WW2 Buildings/oldFence/fenceSection2Post01A.dts";
internalName = "FK_fenceSection2Post01A";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fenceSection2Post01B) {
shapeFile = "art/shapes/WW2 Buildings/oldFence/fenceSection2Post01B.dts";
internalName = "FK_fenceSection2Post01B";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fenceSectionRails1B) {
shapeFile = "art/shapes/WW2 Buildings/oldFence/fenceSectionRails1B.dts";
internalName = "FK_fenceSectionRails1B";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fenceSectionRails1T) {
shapeFile = "art/shapes/WW2 Buildings/oldFence/fenceSectionRails1T.dts";
internalName = "FK_fenceSectionRails1T";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fenceSectionRails1Tshort) {
shapeFile
	= "art/shapes/WW2 Buildings/oldFence/fenceSectionRails1Tshort.dts";
internalName = "FK_fenceSectionRails1Tshort";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fenceSectionRails1Tshort2) {
shapeFile
	= "art/shapes/WW2 Buildings/oldFence/fenceSectionRails1Tshort2.dts";
internalName = "FK_fenceSectionRails1Tshort2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
datablock TSForestItemData(FK_fenceSectionRails2) {
shapeFile = "art/shapes/WW2 Buildings/oldFence/fenceSectionRails2.dts";
internalName = "FK_fenceSectionRails2";
windScale = "1";
trunkBendScale = "0.02";
branchAmp = "0.05";
detailAmp = "0.1";
detailFreq = "0.2";
mass = "5";
rigidity = "20";
dampingCoefficient = "0.2";
tightnessCoefficient = "4";
};
