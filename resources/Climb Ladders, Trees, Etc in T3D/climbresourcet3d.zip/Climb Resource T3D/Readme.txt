1. Winmerge or copy these files to the appropriate locations. 

2. Recompile

3. Run game
      Ladders are placed near station
      
4. To place own ladders:
      Press F11 for Editor 
      Select Library Tab on Scene Tree
      Select Scripted Tab
      Open ClimbableObjects folder
      Place Ladder in scene
      *Rotate Object so that it is not 90 degrees to ground
            