/**
PGDStore.cpp
Written By: Phantom139

Copywrite 2010, Phantom Games Development

**/
#include "console/PGDCrypto/PGDStore.h"
#include "console/PGDCrypto/cryptoPackage.h"

PGDStore *pgdrankstore = NULL;

PGDStore::PGDStore() {
   encEXP = "0";
   encOFF = "0";
   rsaVerificationKey = "";

   if(PGD_CONTAINER_DEBUG) {
      Con::printf("*** Rank Storage Container Initialized PGDStore::PGDStore()");
	  Con::printf("*** TEST %s, %s", encEXP.c_str(), encOFF.c_str());
   }
}

PGDStore::~PGDStore() {
   //Destructor functions here... but none are needed :P
   //Phantom139: Eh, I may at some point :)
}

void PGDStore::create() {
   //only one...
   if(pgdrankstore == NULL) {
      pgdrankstore = new PGDStore();
      Con::printf("*Rank Storage Container Initialized.");
   }
}

void PGDStore::destroy() {
   delete pgdrankstore;
   pgdrankstore = NULL;

   Con::printf("*Rank Container Has Been Deleted.");
}

void PGDStore::checkData() {
   //we could do some data validation here if we wanted...


   //debug portion
   if(PGD_CONTAINER_DEBUG) {
	  Con::printf("*** CONTAINER DATA ***");
	  Con::printf("SEXP: %s", encEXP.c_str());
	  Con::printf("SOFF: %s", encOFF.c_str());
   }
}

void PGDStore::loadStore(std::string guid, std::string data) {
   std::string signature = data.substr(0, data.find_first_of(":"));
   bool trueSource = verifyRecieveKey(rsaVerificationKey, signature);
   if(!trueSource) {
	  Con::executef("MessageBoxOk", "Phantom Games Development", "Invalid Rank Key Provided, Rank Load Terminated.");
	  return;
   }
   //remove it.
   std::string usableData = data.substr(data.find_first_of(":")+1, data.length());
   std::string decrypted;
   cryptoPackage->AESDecrypt(guid, usableData, decrypted, 2000);

   //break into the two seperate pieces
   encEXP = decrypted.substr(0, decrypted.find_first_of(":"));
   decrypted.assign(decrypted.substr(decrypted.find_first_of(":")+1, decrypted.length()));
   encOFF = decrypted.substr(0, decrypted.length()); 

   //affix fields
   if(encEXP.compare("") == 0) {
      encEXP = "0";
   }
   if(encOFF.compare("") == 0) {
      encOFF = "0";
   }
}

std::string PGDStore::packageStore(std::string guid) {
   std::string final, encrypted;
   //encrypt "0";
   if(encEXP.compare("0") == 0) {
      cryptoPackage->AESEncrypt(guid, "0", encEXP, 1024);
   }
   if(encOFF.compare("0") == 0) {
      cryptoPackage->AESEncrypt(guid, "0", encOFF, 1024);
   }
   final.assign(encEXP);
   final.append(":");
   final.append(encOFF);
   //encrypt it
   cryptoPackage->AESEncrypt(guid, final, encrypted, 2000);
   return encrypted;
}

void PGDStore::addToField(std::string field, const F64 add, string GUID) {
   //do not remove from a field...
   if(add <= 0) {
      return;
   }

   if(field.compare("encEXP") == 0) {
      std::string out;
      std::string bleh = getStoredField("encEXP", GUID);
	  const F64 before = dAtof(bleh.c_str());
      const F64 final = before + add;
	  checkForPromotion(before, final, GUID);

      char buff[256];
      dSprintf(buff, sizeof(buff), "%f", final);  
      cryptoPackage->AESEncrypt(GUID, string(buff), out, 1024);
      encEXP.assign(out);
   }   
}

void PGDStore::promoteOFF(string encrypted) {
   //string encryptedFinal;
   //cryptoPackage->AESEncrypt("StoredOFF", encrypted, encryptedFinal, 1024);

   encOFF = encrypted;
   encEXP = "0";
}

string PGDStore::getStoredField(std::string field, std::string guid) {
   if(field.compare("encEXP") == 0) {
      if(encEXP.compare("0") == 0) {
         return "0";
      }
      else {
	     std::string decrypted;
         cryptoPackage->AESDecrypt(guid, encEXP, decrypted, 1024);
		 decrypted.assign(decrypted.substr(0, decrypted.find_first_of(".")));
         return decrypted;
	  }
   }
   else if(field.compare("encOFF") == 0) {
      if(encOFF.compare("0") == 0) {
         return "0";
      }
      else {
	     std::string decrypted;
         cryptoPackage->AESDecrypt(guid, encOFF, decrypted, 1024);
         return decrypted;
	  }
   }
   else {
      return "UNKNOWN_FIELD_ENTRY";
   }
}

bool PGDStore::CanPromoteToOfficer(std::string guid) {
   std::string currentOfficer = getStoredField("encOFF", guid);
   std::string currentEXP = getStoredField("encEXP", guid);
   F64 currentEXPCheck = dAtof(currentEXP.c_str());
   F64 CO = dAtof(currentOfficer.c_str());

   //Con::printf("OFF: %s, EXP: %s", currentOfficer, currentEXP);

   Con::printf("OFFICER: %f", CO);
   if(CO >= 15) {
      //break....
	  Con::executef("MessageBoxOk", "Officer Promotion", "You are already at the highest officer level.");
	  return false;
   }
   else {
	  if(currentEXPCheck < 2000000) {
	     Con::executef("MessageBoxOk", "Officer Promotion", "Master Commander Rank Required.");
		 return false;
	  }
	  else {
	     return true;
	  }
   }
}

void PGDStore::setRSAVerificationKey(string key) {
   rsaVerificationKey.assign(key);
}

bool PGDStore::verifyRecieveKey(std::string message, std::string signature) {
   std::string dec, fin;
   fin.assign(rsaVerificationKey);
   fin.append("h");
   Integer rsaPub(fin.c_str()), rsaexp("65537");
   
   std::string holder;

   try {
      RSASSA_PKCS1v15_SHA_Verifier verifier;
      verifier.AccessKey().Initialize(rsaPub, rsaexp);

      cryptoPackage->HexDecode(signature, holder);

      StringSource(message+holder, true,
          new SignatureVerificationFilter(
              verifier, NULL,
              SignatureVerificationFilter::THROW_EXCEPTION
         ) // SignatureVerificationFilter
      ); // StringSource
   }
   catch(CryptoPP::Exception e) {
      cout << e.GetWhat() << endl;
      return false;
   }

   return true;
}

void PGDStore::checkForPromotion(const F64 before, const F64 final, std::string guid) {
   //step 1, find current rank value (before)
   int index = 61, current = 0, append = 0; //start at the end
   for(int i = index; i > 0; i--) {
	  if(before >= RankEXP[i]) {
	     current = i;   
	  }
	  if(final >= RankEXP[i]) {
	     append = i;   
	  }
   }   
   //now check to see if append is > current
   if(append > current) {
      //promoted!
      applyPromotion(append, guid);
   }
}

void PGDStore::applyPromotion(int newRank, std::string guid) {
   if(strcmp(Con::getVariable("$LocalRankNumber"), "") == 0) {
	  Con::executef("obtainLocalRank");
   }
   char newNumb[8], newMoney[8];
   sprintf(newNumb, "%i", newRank);
   // Money Bonus: Promotion
   const F32 oddPromoteMoney = 1000, evenPromoteMoney = 2500;
   if((newRank % 2) == 0) {
      sprintf(newMoney, "%i", evenPromoteMoney);
      addToField("encMoney", evenPromoteMoney, guid);
	  Con::executef("getPromoted", newNumb, newMoney);
   }
   else {
	  sprintf(newMoney, "%i", oddPromoteMoney);
      addToField("encMoney", oddPromoteMoney, guid);
	  Con::executef("getPromoted", newNumb, newMoney);
   }
   //
   Con::setVariable("$GameRank", newNumb);
}









//RANK SYSTEM DEFINITIONS
F64 PGDStore::RankEXP[] = {0, 25, 50, 100, 150, 200, 250, 300, 400, 500, 650, 800, 1000, 1250, 1500, 1750, 2000, 2500, 3000,
                   3500, 4000, 5000, 6000, 7000, 8000, 10000, 12000, 14000, 16000, 18000, 20000, 22000, 25000, 28000,
                   31000, 35000, 39000, 44000, 50000, 55000, 60000, 70000, 77500, 85000, 92500, 100000, 125000, 150000,
                   175000, 200000, 250000, 300000, 350000, 400000, 500000, 650000, 800000, 1000000, 1250000, 1500000,
                   1750000, 2000000};
String PGDStore::RankNames[] = {"Recruit", "Private", "Private Grade 1", "Private Grade 2", "Private Grade 3", "Private First Class",
                        "PFC Grade 1", "PFC Grade 2", "Corporal", "Corporal Grade 1", "Corporal Grade 2", "Corporal Grade 3",
                        "Sergeant", "Sergeant Grade 1", "Sergeant Grade 2", "Sergeant Grade 3", "Lieutenant", "Lieutenant Grade 1",
                        "Lieutenant Grade 2", "Lieutenant Grade 3", "First Lieutenant", "FL Grade 1", "FL Grade 2", "FL Grade 3",
                        "Captain", "Captain Grade 1", "Captain Grade 2", "Captain Grade 3", "Major", "Major Grade 1", "Major Grade 2",
                        "Major Grade 3", "Lieutenant Colonel", "Lt. Colonel 1", "Lt. Colonel 2", "Colonel", "Colonel 1", "Colonel 2",
                        "Brigadier", "Brigadier Grade 1", "Brigadier Grade 2", "Brigadier Grade 3", "Brigadier General", "Brig. Gen. 1"
                        "Brig. Gen. 2", "General", "2 Star General", "3 Star General", "4 Star General", "5 Star General",
                        "Master General", "Master General 1", "Master General 2", "Master General 3", "Gen. Of The Army", "Fleet Commander",
                        "Fleet Com. Grade 1", "Fleet Com. Grade 2", "Commander", "Commander Grade 1", "Commander Grade 2", "Master Commander"};

ConsoleFunction(OutRankName, const char *, 2, 2, "Outputs a rank name by index number") {
   argc;
   int numeric = atoi(argv[1]);
   if(numeric < 0 || numeric > 61) {
      return "INVALID";
   }
   return PGDStore::RankNames[numeric].c_str();
}

ConsoleFunction(OutRankEXP, F32, 2, 2, "Outputs the required experience for the given rank number") {
   argc;
   int numeric = atoi(argv[1]);
   if(numeric < 0 || numeric > 61) {
      return 0;
   }
   return PGDStore::RankEXP[numeric];
}

ConsoleFunction(findRankNumber, int, 2, 2, "Returns the current rank index value of a given EXP value") {
   argc;
   std::string exp = argv[1];
   //
   int index = 61; //start at the end
   for(int i = index; i > 0; i--) {
	  if(dAtof(exp.c_str()) >= PGDStore::RankEXP[i]) {
	     return i;
	  }
   }
   return 0;
}

ConsoleFunction(obtainLocalRank, const char *, 1, 1, "Return the current rank name, store rank value") {
   argc;
   std::string guid = Con::getVariable("$ConnStore::guid");
   std::string exp = pgdrankstore->getStoredField("encEXP", guid);
   //
   int index = 61; //start at the end
   int final = 0;
   char numeric[8];
   for(int i = 0; i < index; i++) {
	  if(dAtof(exp.c_str()) >= PGDStore::RankEXP[i]) {
		 Con::setVariable("$LocalRank", PGDStore::RankNames[i]);
		 //
		 sprintf(numeric, "%i", i);
		 //
		 Con::setVariable("$LocalRankNumber", numeric);
		 final = i;
	  }
	  else {
	     i = index; //break out;
	  }
   }
   return PGDStore::RankNames[final];
}