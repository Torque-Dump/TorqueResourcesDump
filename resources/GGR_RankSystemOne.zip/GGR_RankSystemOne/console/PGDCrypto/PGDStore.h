#ifndef pgdstore_H
#define pgdstore_H

#include <string>

#ifndef _CONSOLE_H_
#include "console/console.h"
#include "console/consoleInternal.h"
#endif
 
#define PGD_CONTAINER_DEBUG 0
 
using namespace std;

class PGDStore {

private:
   string encEXP;
   string encOFF;

   string rsaVerificationKey;

public:
   void addToField(std::string field, const F64 add, string GUID);
   void promoteOFF(string encrypted);
   string getStoredField(std::string field, std::string guid);
   bool CanPromoteToOfficer(std::string guid);

   std::string packageStore(std::string guid);
   void loadStore(std::string guid, std::string data);

   void checkForPromotion(const F64 current, const F64 final, std::string GUID);
   void applyPromotion(int newRank, std::string guid);

   void checkData();

   static void create();
   static void destroy();

   static F64 RankEXP[];
   static String RankNames[];

   void setRSAVerificationKey(string key);
   bool verifyRecieveKey(std::string message, std::string signature);

   PGDStore();
   ~PGDStore();
};

extern PGDStore *pgdrankstore;

#endif