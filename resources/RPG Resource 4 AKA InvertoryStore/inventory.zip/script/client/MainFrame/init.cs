//exec("./BattleSteps.cs");
exec("./Globals.cs");
exec("./Inventory.cs");
exec("./PlayerObject.cs");
exec("./MonsterObject.cs");
exec("./fxProfiles.cs");
exec("./DamageSystem.cs");

function loadNewGameMission(%Map)
{

   // first check if we have a level file to load
   if (%Map !$= "")
   {
      %levelFile = "levels/";
      %ext = getSubStr(%Map, strlen(%Map) - 3, 3);
      if(%ext !$= "mis")
         %levelFile = %levelFile@ %Map @ "/" @ %Map @ ".mis";
      else
         %levelFile = %levelFile @ %Map;

      // let's make sure the file exists
      echo(%levelFile);
      %file = findFirstFile(%levelFile);

      if(%file !$= "")
      {
         createServer( "SinglePlayer", %file );

         %conn = new GameConnection(ServerConnection);
         RootGroup.add(ServerConnection);
         %conn.setConnectArgs($pref::Player::Name);
         %conn.setJoinPassword($Client::Password);
         %conn.connectLocal();
      }
   }

}


function MoveToNewMap(%MapName)
{
   // Delete the connection if it's still there.
   if (isObject(ServerConnection))
      ServerConnection.delete();

   // Call destroyServer in case we're hosting
   destroyServer();
   
   // Clean up any client-side stuff left over
   MoveToNewMapCleanup(%MapName);
}

function MoveToNewMapCleanup(%MapName)
{
   if( isObject(ClientMissionCleanup) )
   {
      ClientMissionCleanup.delete();
   }
   clearClientPaths();

   // Terminate all playing sounds
   if (isObject(MusicPlayer))
      MusicPlayer.stop();

   // No longer worried about lag
   LagIcon.setVisible(false);
   
   // Dump anything we're not using
   purgeResources();

   schedule(1,0,"loadNewGameMission",%MapName);
}