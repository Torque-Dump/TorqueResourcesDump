$InventoryObject::MyInventory="";
$InventoryObject::InventoryCount=0;
$InventoryObject::ITEM_ENUM=1;
$InventoryObject::ARMOR_ENUM=2;
$InventoryObject::EVENTITEM_ENUM=3;
new ScriptObject(Inventory){
   Name="";
   ID="";
   Type="";
   TypeID="";
   Quantity="";
   MaxQuantity="";
   Cost="";
   Description="";
   Image="";
};
function InitalizeInventory(){
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   %query = "Select ItemID, ArmorID, EventItemID FROM InventoryInit;";
   %result = sqlite.query(%query, 0);
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      %i=0;
      while (!sqlite.endOfResult(%result))
      {
         %ItemID = sqlite.getColumn(%result, "ItemID");
         %ArmorID = sqlite.getColumn(%result, "ArmorID");
         %EventItemID = sqlite.getColumn(%result, "EventItemID");
        $InventoryObject::MyInventory[%i] = new ScriptObject(){
            class=Inventory;
         };
         $InventoryObject::InventoryCount=%i;
         %i++;
         sqlite.nextRow(%result);
      }
   }
   sqlite.clearResult(%result);
   sqlite.closeDatabase();
   sqlite.delete();
   PopulateInventory();
}

function PopulateInventory(){
      
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   %query = "Select ItemID, ArmorID, EventItemID, Quantity FROM InventoryInit;";
   %result = sqlite.query(%query, 0);
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      // attempt to retrieve result data
      %i=0;
      while (!sqlite.endOfResult(%result))
      {
         %ItemID = sqlite.getColumn(%result, "ItemID");
         %ArmorID = sqlite.getColumn(%result, "ArmorID");
         %EventItemID = sqlite.getColumn(%result, "EventItemID");
         %Quantity = sqlite.getColumn(%result, "Quantity");
         if(%ItemID != 0){
               $InventoryObject::MyInventory[%i].setID(%ItemID);
               $InventoryObject::MyInventory[%i].setType($InventoryObject::ITEM_ENUM);
               $InventoryObject::MyInventory[%i].setQuantity(%Quantity);
         }else if(%ArmorID != 0){
               $InventoryObject::MyInventory[%i].setID(%ArmorID);
               $InventoryObject::MyInventory[%i].setType($InventoryObject::ARMOR_ENUM);
               $InventoryObject::MyInventory[%i].setQuantity(%Quantity);
         }else if(%EventItemID != 0){
               $InventoryObject::MyInventory[%i].setID(%EventItemID);
               $InventoryObject::MyInventory[%i].setType($InventoryObject::EVENTITEM_ENUM);
               $InventoryObject::MyInventory[%i].setQuantity(%Quantity);
        }   
        %i++;
        sqlite.nextRow(%result);
      }
   }
   sqlite.clearResult(%result);
   sqlite.closeDatabase();
   sqlite.delete();
   PopulateInventoryNames();
}


function PopulateInventoryNames(){
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   for(%i=0;%i<$InventoryObject::InventoryCount;%i++){
      if($InventoryObject::MyInventory[%i].getType()==1){
           %query2 = "Select Name, ItemTypeID, MaxQuantity, Cost, Description, Image FROM Items where ItemID="@$InventoryObject::MyInventory[%i].getID()@";";
           %result2 = sqlite.query(%query2, 0);
           if (%result2 == 0)
           {
              echo("ERROR: Failed to SELECT from users table.");
           }else{
              $InventoryObject::MyInventory[%i].setName(sqlite.getColumn(%result2, "Name"));
              $InventoryObject::MyInventory[%i].setTypeID(sqlite.getColumn(%result2, "ItemTypeID"));
              $InventoryObject::MyInventory[%i].setMaxQuantity(sqlite.getColumn(%result2, "MaxQuantity"));
              $InventoryObject::MyInventory[%i].setCost(sqlite.getColumn(%result2, "Cost"));
              $InventoryObject::MyInventory[%i].setDescription(sqlite.getColumn(%result2, "Description"));
              $InventoryObject::MyInventory[%i].setImage(sqlite.getColumn(%result2, "Image"));
              sqlite.clearResult(%result2);
           }
      }else if($InventoryObject::MyInventory[%i].getType()==2){
           %query2 = "Select Name, ArmorTypeID, MaxQuantities, Cost, Description, Image FROM Armors where ArmorID="@$InventoryObject::MyInventory[%i].getID()@";";
           %result2 = sqlite.query(%query2, 0);
           if (%result2 == 0)
           {
              echo("ERROR: Failed to SELECT from users table.");
           }else{
              $InventoryObject::MyInventory[%i].setName(sqlite.getColumn(%result2, "Name"));
              $InventoryObject::MyInventory[%i].setTypeID(sqlite.getColumn(%result2, "ArmorTypeID"));
              $InventoryObject::MyInventory[%i].setMaxQuantity(sqlite.getColumn(%result2, "MaxQuantities"));
              $InventoryObject::MyInventory[%i].setCost(sqlite.getColumn(%result2, "Cost"));
              $InventoryObject::MyInventory[%i].setDescription(sqlite.getColumn(%result2, "Description"));
              $InventoryObject::MyInventory[%i].setImage(sqlite.getColumn(%result2, "Image"));
              sqlite.clearResult(%result2);
           }
      }else if($InventoryObject::MyInventory[%i].getType()==3){
           %query2 = "Select Name, Quantity FROM Items where ItemID="@$InventoryObject::MyInventory[%i].getID()@";";
           %result2 = sqlite.query(%query2, 0);
           if (%result2 == 0)
           {
              echo("ERROR: Failed to SELECT from users table.");
           }else{
              $InventoryObject::MyInventory[%i].setName(sqlite.getColumn(%result2, "Name"));
           }
      }
   }
   
   //sqlite.clearResult(%result);
   sqlite.closeDatabase();
   sqlite.delete();
}

function Inventory::getID(%this){
   return %this.ID;  
}

function Inventory::getName(%this){
   return %this.Name;  
}

function Inventory::getType(%this){
   return %this.Type;  
}

function Inventory::getTypeID(%this){
   return %this.TypeID;  
}

function Inventory::getQuantity(%this){
   return %this.Quantity;  
}

function Inventory::setID(%this, %value){
   %this.ID=%value;  
}

function Inventory::setName(%this, %value){
   %this.Name=%value;  
}

function Inventory::setType(%this, %value){
   %this.Type=%value;  
}

function Inventory::setTypeID(%this, %value){
   %this.TypeID=%value;  
}


function Inventory::setQuantity(%this, %value){
   %this.Quantity=%value;  
}

function Inventory::getMaxQuantity(%this){
   return %this.MaxQuantity;  
}

function Inventory::setMaxQuantity(%this, %value){
   %this.MaxQuantity=%value;  
}

function Inventory::getCost(%this){
   return %this.Cost;  
}

function Inventory::setCost(%this, %value){
   %this.Cost=%value;  
}

function Inventory::getDescription(%this){
   return %this.Description;  
}

function Inventory::setDescription(%this, %value){
   %this.Description=%value;  
}
function Inventory::getImage(%this){
   return %this.Image;  
}

function Inventory::setImage(%this, %value){
   %this.Image=%value;  
}

function CheckInventory(%Name){
   %hasItem=false;
   for(%i=0;%i<$InventoryObject::InventoryCount;%i++){
      if(%Name $= $InventoryObject::MyInventory[%i].getName()){
         %hasItem=true;
         return $InventoryObject::MyInventory[%i].getQuantity(); 
      }
   }
   return -1;
}

function AddInventory(%Type,%Name, %Quantity){
   for(%i=0;%i<$InventoryObject::InventoryCount;%i++){
      if(%Name $= $InventoryObject::MyInventory[%i].getName()){
         $InventoryObject::MyInventory[%i].setQuantity($InventoryObject::MyInventory[%i].getQuantity()+%Quantity);
         return;
      }
   }
   InsertInventoryName(%Type,%Name,%Quantity);
}

function InsertInventoryName(%Type,%Name,%Quantity){
   
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   %i=$InventoryObject::InventoryCount;
      if(%Type==1){
           %query2 = "Select Name,ItemID,ItemTypeID,MaxQuantity,Cost, Description, Image FROM Items where Name=\""@%Name@"\";";
           %result2 = sqlite.query(%query2, 0);
           if (%result2 == 0)
           {
              echo("ERROR: Failed to SELECT from users table.");
           }else{
              $InventoryObject::MyInventory[%i].setName(sqlite.getColumn(%result2, "Name"));
              $InventoryObject::MyInventory[%i].setID(sqlite.getColumn(%result2, "ItemID"));
              $InventoryObject::MyInventory[%i].setType(1);
              $InventoryObject::MyInventory[%i].setTypeID(sqlite.getColumn(%result2, "ItemTypeID"));
              $InventoryObject::MyInventory[%i].setMaxQuantity(sqlite.getColumn(%result2, "MaxQuantity"));
              $InventoryObject::MyInventory[%i].setCost(sqlite.getColumn(%result2, "Cost"));
              $InventoryObject::MyInventory[%i].setDescription(sqlite.getColumn(%result2, "Description"));
              $InventoryObject::MyInventory[%i].setImage(sqlite.getColumn(%result2, "Image"));
              $InventoryObject::MyInventory[%i].setQuantity(%Quantity);
              $InventoryObject::InventoryCount++;
           }
      }else if(%Type==2){
           %query2 = "Select Name, ArmorID, ArmorTypeID, MaxQuantities,Cost, Description, Image FROM Armors where %Name="@%Name@";";
           %result2 = sqlite.query(%query2, 0);
           if (%result2 == 0)
           {
              echo("ERROR: Failed to SELECT from users table.");
           }else{
              $InventoryObject::MyInventory[%i].setName(sqlite.getColumn(%result2, "Name"));
              $InventoryObject::MyInventory[%i].setID(sqlite.getColumn(%result2, "ArmorID"));
              $InventoryObject::MyInventory[%i].setType(2);
              $InventoryObject::MyInventory[%i].setTypeID(sqlite.getColumn(%result2, "ItemTypeID"));
              $InventoryObject::MyInventory[%i].setMaxQuantity(sqlite.getColumn(%result2, "MaxQuantities"));
              $InventoryObject::MyInventory[%i].setCost(sqlite.getColumn(%result2, "Cost"));
              $InventoryObject::MyInventory[%i].setDescription(sqlite.getColumn(%result2, "Description"));
              $InventoryObject::MyInventory[%i].setImage(sqlite.getColumn(%result2, "Image"));
              $InventoryObject::MyInventory[%i].setQuantity(%Quantity);
              $InventoryObject::InventoryCount++;
           }
      }else if(%Type==3){
           %query2 = "Select Name, Quantity FROM Items where ItemID="@%Name@";";
           %result2 = sqlite.query(%query2, 0);
           if (%result2 == 0)
           {
              echo("ERROR: Failed to SELECT from users table.");
           }else{
              $InventoryObject::MyInventory[%i].setName(sqlite.getColumn(%result, "Name"));
           }
      }
   for(%h=0;%h<$InventoryObject::InventoryCount;%h++){
      echo("Echo ItemNumber "@%h@": "@$InventoryObject::MyInventory[%h].getName() @" - "@ $InventoryObject::MyInventory[%h].getTypeID() @" - "@ $InventoryObject::MyInventory[%h].getQuantity());
   }
}


function RemoveInventory(%Name, %Quantity){
   for(%i=0;%i<$InventoryObject::InventoryCount;%i++){
      if(%Name $= $InventoryObject::MyInventory[%i].getName()){
          $InventoryObject::MyInventory[%i].setQuantity($InventoryObject::MyInventory[%i].getQuantity()-%Quantity); 
      }
   }
}

InitalizeInventory();