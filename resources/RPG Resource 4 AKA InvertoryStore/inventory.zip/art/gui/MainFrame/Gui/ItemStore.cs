//------------------------------------------------------------------------------
// Pause Menu Image Base
//------------------------------------------------------------------------------

$ItemStoreOBJ::BUYIMAGE="art/gui/MainFrame/Gui/images/StoreMenu/Buy";
$ItemStoreOBJ::CANCELIMAGE="art/gui/MainFrame/Gui/images/StoreMenu/Cancel";
$ItemStoreOBJ::SELLIMAGE="art/gui/MainFrame/Gui/images/StoreMenu/Sell";
$ItemStoreOBJ::ITEMSELIMAGE="art/gui/MainFrame/Gui/images/StoreMenu/Item";

//=========================================================================
//GUI Positions ActionMap
//=========================================================================
$ItemStoreOBJ_OptionsStore::GUIPOS=0;
$ItemStoreOBJ_ItemSelect::GUIPOS=0;
new ScriptObject(ItemStoreOBJ){
};

function ItemStore::onWake(%this)
{
 ISOptionsActionMap.push();
 ItemStoreOBJ.ProcessOptionSelection();
 OptionsControl.setVisible(true);
}

function ItemStore::onSleep(%this)
{
 ISOptionsActionMap.pop();
}


function ItemStoreOBJ::LoadOptions(){
   SFXPlay(CancelFX);
   $ItemStoreOBJ_OptionsStore::GUIPOS=0;
   $ItemStoreOBJ_ItemSelect::GUIPOS=0;
   $ItemStoreOBJ::PageShift=0;
   $ItemStoreOBJ::COLPOS=0;
   $ItemStoreOBJ::ROWPOS=0;
   $ItemStoreOBJ::ITEMNUM=0;
   SideControl.setVisible(false);
   DescptionControl.setVisible(false);
   ItemListControl.setVisible(false);
   OptionsControl.setVisible(true);
   BuyBTN.setBitmap($ItemStoreOBJ::BUYIMAGE@"_h");
   SellBTN.setBitmap($ItemStoreOBJ::SELLIMAGE@"_n");
   CancelBTN.setBitmap($ItemStoreOBJ::CANCELIMAGE@"_n");
   ISSelectListActionMap.pop();
   ISSellSelectListActionMap.pop();
   ISOptionsActionMap.push();
}

function ItemStoreOBJ::onBuyItems(){
   SFXPlay(AcceptFX);
   ISOptionsActionMap.pop();
   ISSelectListActionMap.push();
   OptionsControl.setVisible(false);
   ItemStoreOBJ.LoadItemDisplays();
}

function ItemStoreOBJ::onSellItems(){
   ISOptionsActionMap.pop();
   ISSellSelectListActionMap.push();
   OptionsControl.setVisible(false);
   ItemStoreOBJ.LoadSellItemDisplays();
}

function ItemStoreOBJ::onLoadPlayGui(){
   SFXPlay(CancelFX);
   ISOptionsActionMap.pop();
   //LoadGui
   Canvas.setContent(PlayGui);
}

//=========================================================================
//ItemStoreOBJ Menu ActionMap
//=========================================================================

new ActionMap(ISOptionsActionMap);
ISOptionsActionMap.bindCmd(keyboard, "w", "ItemStoreOBJ.OptionSelectUp();","");
ISOptionsActionMap.bindCmd(keyboard, "s", "ItemStoreOBJ.OptionSelectDown();","");
ISOptionsActionMap.bindCmd(keyboard, "k", "ItemStoreOBJ.SelectOption();","ItemStoreOBJ.HilightOption();");
ISOptionsActionMap.bindCmd(keyboard, "l", "ItemStoreOBJ.onLoadPlayGui();","");


function ItemStoreOBJ::ProcessOptionSelection(){
   switch($ItemStoreOBJ_OptionsStore::GUIPOS){
      case 0:
         BuyBTN.setBitmap($ItemStoreOBJ::BUYIMAGE@"_h");
         SellBTN.setBitmap($ItemStoreOBJ::SELLIMAGE@"_n");
         CancelBTN.setBitmap($ItemStoreOBJ::CANCELIMAGE@"_n");
      
      case 1:
         BuyBTN.setBitmap($ItemStoreOBJ::BUYIMAGE@"_n");
         SellBTN.setBitmap($ItemStoreOBJ::SELLIMAGE@"_h");
         CancelBTN.setBitmap($ItemStoreOBJ::CANCELIMAGE@"_n");
      
      case 2:
         BuyBTN.setBitmap($ItemStoreOBJ::BUYIMAGE@"_n");
         SellBTN.setBitmap($ItemStoreOBJ::SELLIMAGE@"_n");
         CancelBTN.setBitmap($ItemStoreOBJ::CANCELIMAGE@"_h");
   }
}

function ItemStoreOBJ::OptionSelectUp(){
   $ItemStoreOBJ_OptionsStore::GUIPOS--;
   // Play sound...
   SFXPlay(AcceptFX);
   if($ItemStoreOBJ_OptionsStore::GUIPOS==-1)
   {
      $ItemStoreOBJ_OptionsStore::GUIPOS=2;
   }
   ItemStoreOBJ.ProcessOptionSelection();
}
function ItemStoreOBJ::OptionSelectDown(){
   $ItemStoreOBJ_OptionsStore::GUIPOS++;
   SFXPlay(AcceptFX);
   if($ItemStoreOBJ_OptionsStore::GUIPOS>2)
   {
      $ItemStoreOBJ_OptionsStore::GUIPOS=0;
   }
   ItemStoreOBJ.ProcessOptionSelection();
}

function ItemStoreOBJ::HilightOption(){
   switch($ItemStoreOBJ_OptionsStore::GUIPOS){
      case 0:
         ItemStoreOBJ.onBuyItems();
         BuyBTN.setBitmap($ItemStoreOBJ::BUYIMAGE@"_h");
      
      case 1:
         ItemStoreOBJ.onSellItems();
         SellBTN.setBitmap($ItemStoreOBJ::SELLIMAGE@"_h");
      
      case 2:
         ItemStoreOBJ.onLoadPlayGui();
         CancelBTN.setBitmap($ItemStoreOBJ::CANCELIMAGE@"_h");
        
   }
}

function ItemStoreOBJ::SelectOption(){
   switch($ItemStoreOBJ_OptionsStore::GUIPOS){
      case 0:
         BuyBTN.setBitmap($ItemStoreOBJ::BUYIMAGE@"_d");
      
      case 1:
         SellBTN.setBitmap($ItemStoreOBJ::SELLIMAGE@"_d");
      
      case 2:
         CancelBTN.setBitmap($ItemStoreOBJ::CANCELIMAGE@"_d");
      
   }
}

//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////Select Options End//////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////

new ActionMap(ISSelectListActionMap);
ISSelectListActionMap.bindCmd(keyboard, "a", "ItemStoreOBJ.ItemSelectLeft();","");
ISSelectListActionMap.bindCmd(keyboard, "d", "ItemStoreOBJ.ItemSelectionRight();","");
ISSelectListActionMap.bindCmd(keyboard, "w", "ItemStoreOBJ.ItemSelectionUp();","");
ISSelectListActionMap.bindCmd(keyboard, "s", "ItemStoreOBJ.ItemSelectionDown();","");
ISSelectListActionMap.bindCmd(keyboard, "k", "ItemStoreOBJ.BuySelectedItem();","");
ISSelectListActionMap.bindCmd(keyboard, "l", "ItemStoreOBJ.LoadOptions();","");





function ItemStoreOBJ::LoadItemDisplays(){
   SideControl.setVisible(true);
   DescptionControl.setVisible(true);
   ItemListControl.setVisible(true);
   ItemStoreOBJ.LoadSectionItems(0);
   if($ItemStoreOBJ::PageShift>0){
      Arrow_UP.setVisible(true);
   }else{
      Arrow_UP.setVisible(false);
   }
   echo("Calc: "@(($ItemStoreOBJ::PageShift)+14)@" of "@$ItemStoreOBJ::ITEMCOUNT);
   if($ItemStoreOBJ::ITEMCOUNT<=($ItemStoreOBJ::PageShift+14)){
      Arrow_DOWN.setVisible(false);
   }else{
      Arrow_DOWN.setVisible(true);
   }
   MoneyL.setText($Globals::Money);
}

   $ItemStoreOBJ::PageShift=0;
   $ItemStoreOBJ::COLPOS=0;
   $ItemStoreOBJ::ROWPOS=0;
   $ItemStoreOBJ::ITEMNUM=0;
function ItemStoreOBJ::ItemSelectLeft(){
   $ItemStoreOBJ::COLPOS--;
   if($ItemStoreOBJ::COLPOS==-1)
   {
      $ItemStoreOBJ::COLPOS=1;
   }
   if(($ItemStoreOBJ::ROWPOS*2)+$ItemStoreOBJ::COLPOS> $ItemStoreOBJ::ITEMCOUNT-1){         
       $ItemStoreOBJ::COLPOS++;
       SFXPlay(CancelFX);
   }else{
       SFXPlay(AcceptFX);
   }
   ItemStoreOBJ.HighLightSeletedItem(($ItemStoreOBJ::ROWPOS*2)+$ItemStoreOBJ::COLPOS);
}
function ItemStoreOBJ::ItemSelectionRight(){
   $ItemStoreOBJ::COLPOS++;
   if($ItemStoreOBJ::COLPOS>1)
   {
      $ItemStoreOBJ::COLPOS=0;
   }
   if(($ItemStoreOBJ::ROWPOS*2)+$ItemStoreOBJ::COLPOS> $ItemStoreOBJ::ITEMCOUNT-1){         
       $ItemStoreOBJ::COLPOS--;
       SFXPlay(CancelFX);
   }else{
       SFXPlay(AcceptFX);
   }
   ItemStoreOBJ.HighLightSeletedItem(($ItemStoreOBJ::ROWPOS*2)+$ItemStoreOBJ::COLPOS);
}


function ItemStoreOBJ::ItemSelectionUp(){
   $ItemStoreOBJ::ROWPOS--;
   $ItemStoreOBJ::ITEMNUM--;
   
   if($ItemStoreOBJ::ROWPOS<0)
   {
      if($ItemStoreOBJ::PageShift<1){
         $ItemStoreOBJ::ITEMNUM=0;
         $ItemStoreOBJ::PageShift=0;
         SFXPlay(CancelFX);        
      }else{
         SFXPlay(AcceptFX);
         $ItemStoreOBJ::PageShift--;
         $ItemStoreOBJ::PageShift--;
         $ItemStoreOBJ::ROWPOS=0;
         ItemStoreOBJ.clearDisplayItems();
         ItemStoreOBJ.DisplayItems();
      }
      $ItemStoreOBJ::ITEMNUM=0;
      $ItemStoreOBJ::ROWPOS=0;
   }else{
      SFXPlay(AcceptFX);
   }
   if($ItemStoreOBJ::PageShift>0){
      Arrow_UP.setVisible(true);
   }else{
      Arrow_UP.setVisible(false);
   }
   echo("Calc: "@(($ItemStoreOBJ::PageShift)+14)@" of "@$ItemStoreOBJ::ITEMCOUNT);
   if($ItemStoreOBJ::ITEMCOUNT<=($ItemStoreOBJ::PageShift+14)){
      Arrow_DOWN.setVisible(false);
   }else{
      Arrow_DOWN.setVisible(true);
   }
   ItemStoreOBJ.HighLightSeletedItem(($ItemStoreOBJ::ROWPOS*2)+$ItemStoreOBJ::COLPOS);
}
function ItemStoreOBJ::ItemSelectionDown(){
   $ItemStoreOBJ::ROWPOS++;
   $ItemStoreOBJ::ITEMNUM++;
   
   if($ItemStoreOBJ::ROWPOS>6)
   {
      if($ItemStoreOBJ::ITEMCOUNT> (($ItemStoreOBJ::PageShift)+14)){
         SFXPlay(AcceptFX);
         $ItemStoreOBJ::PageShift++;
         $ItemStoreOBJ::PageShift++;
         $ItemStoreOBJ::ROWPOS--;
         ItemStoreOBJ.clearDisplayItems();
         ItemStoreOBJ.DisplayItems();
      }else{
         SFXPlay(CancelFX);
         $ItemStoreOBJ::ITEMNUM--;
         $ItemStoreOBJ::ROWPOS--;
      }
   }else{
      if(($ItemStoreOBJ::ROWPOS*2)+$ItemStoreOBJ::COLPOS> $ItemStoreOBJ::ITEMCOUNT-1){         
         $ItemStoreOBJ::ROWPOS--;
         $ItemStoreOBJ::ITEMNUM--;
         SFXPlay(CancelFX);
      }else{
         SFXPlay(AcceptFX);
      }
   }
   if($ItemStoreOBJ::PageShift>0){
      Arrow_UP.setVisible(true);
   }else{
      Arrow_UP.setVisible(false);
   }
   echo("Calc: "@(($ItemStoreOBJ::PageShift)+14)@" of "@$ItemStoreOBJ::ITEMCOUNT);
   if($ItemStoreOBJ::ITEMCOUNT<=($ItemStoreOBJ::PageShift+14)){
      Arrow_DOWN.setVisible(false);
   }else{
      Arrow_DOWN.setVisible(true);
   }
   ItemStoreOBJ.HighLightSeletedItem(($ItemStoreOBJ::ROWPOS*2)+$ItemStoreOBJ::COLPOS);
}



$ItemStoreOBJ::ITEMLIST="";
$ItemStoreOBJ::ITEMCOUNT=0;
function ItemStoreOBJ::LoadSectionItems(%this,%section){
   $ItemStoreOBJ::ITEMCOUNT=0;
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
      switch(%section){
        case 0:
   
            // retrieve some data from the table
            %query = "SELECT Name, Cost, Description, MaxQuantity, Image from Items order by Cost;";
            %result = sqlite.query(%query, 0);
            if (%result == 0)
            {
               echo("ERROR: Failed to SELECT from users table.");
            }else{
               // attempt to retrieve result data
                  %i=0;
               while (!sqlite.endOfResult(%result))
               {
                  $ItemStoreOBJ::ITEMLIST[%i]= sqlite.getColumn(%result, "Name") NL sqlite.getColumn(%result, "Cost") NL sqlite.getColumn(%result, "Description") NL sqlite.getColumn(%result, "MaxQuantity") NL sqlite.getColumn(%result, "Image");
                  %i++;
                  $ItemStoreOBJ::ITEMCOUNT=%i;
                  sqlite.nextRow(%result);
               }
               sqlite.clearResult(%result);
            }
            
        case 1:
   
            // retrieve some data from the table
            %query = "SELECT Armors.Name, InventoryInit.Quantity from InventoryInit inner join Armors on InventoryInit.ArmorID=Armors.ArmorID where InventoryInit.ArmorID>0;";
            %result = sqlite.query(%query, 0);
            if (%result == 0)
            {
               echo("ERROR: Failed to SELECT from users table.");
            }else{
               // attempt to retrieve result data
                  %i=0;
               while (!sqlite.endOfResult(%result))
               {
                  $ItemStoreOBJ::ITEMLIST[%i]= sqlite.getColumn(%result, "Name") NL sqlite.getColumn(%result, "Quantity");
                  %i++;
                  $ItemStoreOBJ::ITEMCOUNT=%i;
                  sqlite.nextRow(%result);
               }
               sqlite.clearResult(%result);
            }
        
        case 2:
            // retrieve some data from the table
//            %query = "SELECT Items.Name, Inventory.Quantity from Inventory inner join Items on Inventory.ItemID=Items.ItemID where Inventory.EventID>0;";
//            %result = sqlite.query(%query, 0);
//            if (%result == 0)
//            {
//               echo("ERROR: Failed to SELECT from users table.");
//            }else{
//               // attempt to retrieve result data
                  %i=0;
               for(%k=0;%k<$InventoryObject::InventoryCount;%k++)
               {
                  if($InventoryObject::MyInventory[%k].getType()==$InventoryObject::ITEM_ENUM && $InventoryObject::MyInventory[%k].getQuantity()>0)
                  {                     
                     $ItemStoreOBJ::ITEMLIST[%i]= $InventoryObject::MyInventory[%k].getName() NL $InventoryObject::MyInventory[%k].getCost()*0.4 NL $InventoryObject::MyInventory[%k].getDescription() NL $InventoryObject::MyInventory[%k].getQuantity() NL $InventoryObject::MyInventory[%k].getImage();
                     %i++;
                     $ItemStoreOBJ::ITEMCOUNT=%i;
                  }
               }
//               sqlite.clearResult(%result);
//            }
        
       }
       
   sqlite.closeDatabase();
   sqlite.delete();
   ItemStoreOBJ.clearDisplayItems();
   ItemStoreOBJ.DisplayItems();
   ItemStoreOBJ.HighLightSeletedItem(0);
}

function ItemStoreOBJ::clearDisplayItems(){
            ItemText1.setText(""); 
            IS_Image1.setBitmap("");
            ItemText1.setVisible(false);
            IS_Image1.setVisible(false);
            SelectItem1.setVisible(false);
            
            ItemText2.setText(""); 
            IS_Image2.setBitmap("");
            ItemText2.setVisible(false);
            IS_Image2.setVisible(false);
            SelectItem2.setVisible(false);
            
            ItemText3.setText("");
            IS_Image3.setBitmap("");
            ItemText3.setVisible(false);
            IS_Image3.setVisible(false);
            SelectItem3.setVisible(false);
            
            ItemText4.setText("");
            IS_Image4.setBitmap("");
            ItemText4.setVisible(false);
            IS_Image4.setVisible(false);
            SelectItem4.setVisible(false);
            
            ItemText5.setText("");
            IS_Image5.setBitmap("");
            ItemText5.setVisible(false);
            IS_Image5.setVisible(false);
            SelectItem5.setVisible(false);
            
            ItemText6.setText("");
            IS_Image6.setBitmap("");
            ItemText6.setVisible(false);
            IS_Image6.setVisible(false);
            SelectItem6.setVisible(false);
            
            ItemText7.setText("");
            IS_Image7.setBitmap("");
            ItemText7.setVisible(false);
            IS_Image7.setVisible(false);
            SelectItem7.setVisible(false);
            
            ItemText8.setText("");
            IS_Image8.setBitmap("");
            ItemText8.setVisible(false);
            IS_Image8.setVisible(false);
            SelectItem8.setVisible(false);
            
            ItemText9.setText("");
            IS_Image9.setBitmap("");
            ItemText9.setVisible(false);
            IS_Image9.setVisible(false);
            SelectItem9.setVisible(false);
            
            ItemText10.setText("");
            IS_Image10.setBitmap("");
            ItemText10.setVisible(false);
            IS_Image10.setVisible(false);
            SelectItem10.setVisible(false);
            
            ItemText11.setText("");
            IS_Image11.setBitmap("");
            ItemText11.setVisible(false);
            IS_Image11.setVisible(false);
            SelectItem11.setVisible(false);
            
            ItemText12.setText("");
            IS_Image12.setBitmap("");
            ItemText12.setVisible(false);
            IS_Image12.setVisible(false);
            SelectItem12.setVisible(false);
            
            ItemText13.setText("");
            IS_Image13.setBitmap("");
            ItemText13.setVisible(false);
            IS_Image13.setVisible(false);
            SelectItem13.setVisible(false);
            
            ItemText14.setText("");
            IS_Image14.setBitmap("");
            ItemText14.setVisible(false);
            IS_Image14.setVisible(false);
            SelectItem14.setVisible(false);
}
function ItemStoreOBJ::DisplayItems(){
   for(%i=(0+$ItemStoreOBJ::PageShift);%i<$ItemStoreOBJ::ITEMCOUNT;%i++){
      switch(%i-$ItemStoreOBJ::PageShift){
        case 0:
            IS_Image1.setBitmap("scriptsAndAssets/"@getRecords( $ItemStoreOBJ::ITEMLIST[0+$ItemStoreOBJ::PageShift] , 4, 4));
            ItemText1.setText(getRecords( $ItemStoreOBJ::ITEMLIST[0+$ItemStoreOBJ::PageShift] , 0, 0));
            ItemText1.setVisible(true);
            IS_Image1.setVisible(true);
            SelectItem1.setVisible(true);
        case 1:
            IS_Image2.setBitmap("scriptsAndAssets/"@getRecords( $ItemStoreOBJ::ITEMLIST[1+$ItemStoreOBJ::PageShift] , 4, 4));
            ItemText2.setText(getRecords( $ItemStoreOBJ::ITEMLIST[1+$ItemStoreOBJ::PageShift] , 0, 0));
            ItemText2.setVisible(true);
            IS_Image2.setVisible(true);
            SelectItem2.setVisible(true);
        case 2:
            IS_Image3.setBitmap("scriptsAndAssets/"@getRecords( $ItemStoreOBJ::ITEMLIST[2+$ItemStoreOBJ::PageShift] , 4, 4));
            ItemText3.setText(getRecords( $ItemStoreOBJ::ITEMLIST[2+$ItemStoreOBJ::PageShift] , 0, 0));
            ItemText3.setVisible(true);
            IS_Image3.setVisible(true);
            SelectItem3.setVisible(true);
        case 3:
            IS_Image4.setBitmap("scriptsAndAssets/"@getRecords( $ItemStoreOBJ::ITEMLIST[3+$ItemStoreOBJ::PageShift] , 4, 4));
            ItemText4.setText(getRecords( $ItemStoreOBJ::ITEMLIST[3+$ItemStoreOBJ::PageShift] , 0, 0));
            ItemText4.setVisible(true);
            IS_Image4.setVisible(true);
            SelectItem4.setVisible(true);
        case 4:
            IS_Image5.setBitmap("scriptsAndAssets/"@getRecords( $ItemStoreOBJ::ITEMLIST[4+$ItemStoreOBJ::PageShift] , 4, 4));
            ItemText5.setText(getRecords( $ItemStoreOBJ::ITEMLIST[4+$ItemStoreOBJ::PageShift] , 0, 0));
            ItemText5.setVisible(true);
            IS_Image5.setVisible(true);
            SelectItem5.setVisible(true);
        case 5:
            IS_Image6.setBitmap("scriptsAndAssets/"@getRecords( $ItemStoreOBJ::ITEMLIST[5+$ItemStoreOBJ::PageShift] , 4, 4));
            ItemText6.setText(getRecords( $ItemStoreOBJ::ITEMLIST[5+$ItemStoreOBJ::PageShift] , 0, 0));
            ItemText6.setVisible(true);
            IS_Image6.setVisible(true);
            SelectItem6.setVisible(true);
        case 6:
            IS_Image7.setBitmap("scriptsAndAssets/"@getRecords( $ItemStoreOBJ::ITEMLIST[6+$ItemStoreOBJ::PageShift] , 4, 4));
            ItemText7.setText(getRecords( $ItemStoreOBJ::ITEMLIST[6+$ItemStoreOBJ::PageShift] , 0, 0));
            ItemText7.setVisible(true);
            IS_Image7.setVisible(true);
            SelectItem7.setVisible(true);
        case 7:
            IS_Image8.setBitmap("scriptsAndAssets/"@getRecords( $ItemStoreOBJ::ITEMLIST[7+$ItemStoreOBJ::PageShift] , 4, 4));
            ItemText8.setText(getRecords( $ItemStoreOBJ::ITEMLIST[7+$ItemStoreOBJ::PageShift] , 0, 0));
            ItemText8.setVisible(true);
            IS_Image8.setVisible(true);
            SelectItem8.setVisible(true);
        case 8:
            IS_Image9.setBitmap("scriptsAndAssets/"@getRecords( $ItemStoreOBJ::ITEMLIST[8+$ItemStoreOBJ::PageShift] , 4, 4));
            ItemText9.setText(getRecords( $ItemStoreOBJ::ITEMLIST[8+$ItemStoreOBJ::PageShift] , 0, 0));
            ItemText9.setVisible(true);
            IS_Image9.setVisible(true);
            SelectItem9.setVisible(true);
        case 9:
            IS_Image10.setBitmap("scriptsAndAssets/"@getRecords( $ItemStoreOBJ::ITEMLIST[9+$ItemStoreOBJ::PageShift] , 4, 4));
            ItemText10.setText(getRecords( $ItemStoreOBJ::ITEMLIST[9+$ItemStoreOBJ::PageShift] , 0, 0));
            ItemText10.setVisible(true);
            IS_Image10.setVisible(true);
            SelectItem10.setVisible(true);
        case 10:
            IS_Image11.setBitmap("scriptsAndAssets/"@getRecords( $ItemStoreOBJ::ITEMLIST[10+$ItemStoreOBJ::PageShift] , 4, 4));
            ItemText11.setText(getRecords( $ItemStoreOBJ::ITEMLIST[10+$ItemStoreOBJ::PageShift] , 0, 0));
            ItemText11.setVisible(true);
            IS_Image11.setVisible(true);
            SelectItem11.setVisible(true);
        case 11:
            IS_Image12.setBitmap("scriptsAndAssets/"@getRecords( $ItemStoreOBJ::ITEMLIST[11+$ItemStoreOBJ::PageShift] , 4, 4));
            ItemText12.setText(getRecords( $ItemStoreOBJ::ITEMLIST[11+$ItemStoreOBJ::PageShift] , 0, 0));
            ItemText12.setVisible(true);
            IS_Image12.setVisible(true);
            SelectItem12.setVisible(true);
        case 12:
            IS_Image13.setBitmap("scriptsAndAssets/"@getRecords( $ItemStoreOBJ::ITEMLIST[12+$ItemStoreOBJ::PageShift] , 4, 4));
            ItemText13.setText(getRecords( $ItemStoreOBJ::ITEMLIST[12+$ItemStoreOBJ::PageShift] , 0, 0));
            ItemText13.setVisible(true);
            IS_Image13.setVisible(true);
            SelectItem13.setVisible(true);
        case 13:
            IS_Image14.setBitmap("scriptsAndAssets/"@getRecords( $ItemStoreOBJ::ITEMLIST[13+$ItemStoreOBJ::PageShift] , 4, 4));
            ItemText14.setText(getRecords( $ItemStoreOBJ::ITEMLIST[13+$ItemStoreOBJ::PageShift] , 0, 0));
            ItemText14.setVisible(true);
            IS_Image14.setVisible(true);
            SelectItem14.setVisible(true);
        }
   }
   
}


function ItemStoreOBJ::HighLightSeletedItem(%this, %pos){
   %asd=2;
      switch(%pos){
        case 0:
            SelectItem1.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_h");
            SelectItem2.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem3.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem4.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem5.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem6.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem7.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem8.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem9.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem10.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem11.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem12.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem13.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem14.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            $ItemStoreOBJ::MaxQuantity=getRecords( $ItemStoreOBJ::ITEMLIST[0+$ItemStoreOBJ::PageShift] , 3, 3);
            $ItemStoreOBJ::SelectedItem=getRecords($ItemStoreOBJ::ITEMLIST[0+$ItemStoreOBJ::PageShift] , 0, 0);
            %owned=CheckInventory(getRecords($ItemStoreOBJ::ITEMLIST[0+$ItemStoreOBJ::PageShift] , 0, 0));
            if(%owned==-1){
               %owned=0;
            }
            OwnedL.setText(%owned);
            CostL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[0+$ItemStoreOBJ::PageShift] , 1, 1));
            DescriptionL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[0+$ItemStoreOBJ::PageShift] , 2, 2));
        case 1:
            SelectItem1.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem2.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_h");
            SelectItem3.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem4.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem5.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem6.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem7.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem8.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem9.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem10.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem11.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem12.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem13.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem14.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            $ItemStoreOBJ::MaxQuantity=getRecords( $ItemStoreOBJ::ITEMLIST[1+$ItemStoreOBJ::PageShift] , 3, 3);
            $ItemStoreOBJ::SelectedItem=getRecords($ItemStoreOBJ::ITEMLIST[1+$ItemStoreOBJ::PageShift] , 0, 0);
            %owned=CheckInventory(getRecords($ItemStoreOBJ::ITEMLIST[1+$ItemStoreOBJ::PageShift] , 0, 0));
            if(%owned==-1){
               %owned=0;
            }
            OwnedL.setText(%owned);
            CostL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[1+$ItemStoreOBJ::PageShift] , 1, 1));
            DescriptionL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[1+$ItemStoreOBJ::PageShift] , 2, 2));
        case 2:
            SelectItem1.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem2.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem3.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_h");
            SelectItem4.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem5.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem6.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem7.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem8.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem9.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem10.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem11.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem12.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem13.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem14.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            $ItemStoreOBJ::MaxQuantity=getRecords( $ItemStoreOBJ::ITEMLIST[2+$ItemStoreOBJ::PageShift] , 3, 3);
            $ItemStoreOBJ::SelectedItem=getRecords($ItemStoreOBJ::ITEMLIST[2+$ItemStoreOBJ::PageShift] , 0, 0);
            %owned=CheckInventory(getRecords($ItemStoreOBJ::ITEMLIST[2+$ItemStoreOBJ::PageShift] , 0, 0));
            if(%owned==-1){
               %owned=0;
            }
            OwnedL.setText(%owned);
            CostL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[2+$ItemStoreOBJ::PageShift] , 1, 1));
            DescriptionL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[2+$ItemStoreOBJ::PageShift] , 2, 2));
        case 3:
            SelectItem1.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem2.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem3.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem4.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_h");
            SelectItem5.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem6.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem7.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem8.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem9.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem10.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem11.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem12.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem13.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem14.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            $ItemStoreOBJ::MaxQuantity=getRecords( $ItemStoreOBJ::ITEMLIST[3+$ItemStoreOBJ::PageShift] , 3, 3);
            $ItemStoreOBJ::SelectedItem=getRecords($ItemStoreOBJ::ITEMLIST[3+$ItemStoreOBJ::PageShift] , 0, 0);
            %owned=CheckInventory(getRecords($ItemStoreOBJ::ITEMLIST[3+$ItemStoreOBJ::PageShift] , 0, 0));
            if(%owned==-1){
               %owned=0;
            }
            OwnedL.setText(%owned);
            CostL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[3+$ItemStoreOBJ::PageShift] , 1, 1));
            DescriptionL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[3+$ItemStoreOBJ::PageShift] , 2, 2));
        case 4:
            SelectItem1.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem2.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem3.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem4.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem5.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_h");
            SelectItem6.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem7.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem8.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem9.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem10.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem11.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem12.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem13.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem14.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            $ItemStoreOBJ::MaxQuantity=getRecords( $ItemStoreOBJ::ITEMLIST[4+$ItemStoreOBJ::PageShift] , 3, 3);
            $ItemStoreOBJ::SelectedItem=getRecords($ItemStoreOBJ::ITEMLIST[4+$ItemStoreOBJ::PageShift] , 0, 0);
            %owned=CheckInventory(getRecords($ItemStoreOBJ::ITEMLIST[4+$ItemStoreOBJ::PageShift] , 0, 0));
            if(%owned==-1){
               %owned=0;
            }
            OwnedL.setText(%owned);
            CostL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[4+$ItemStoreOBJ::PageShift] , 1, 1));
            DescriptionL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[4+$ItemStoreOBJ::PageShift] , 2, 2));
        case 5:
            SelectItem1.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem2.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem3.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem4.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem5.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem6.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_h");
            SelectItem7.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem8.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem9.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem10.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem11.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem12.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem13.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem14.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            $ItemStoreOBJ::MaxQuantity=getRecords( $ItemStoreOBJ::ITEMLIST[5+$ItemStoreOBJ::PageShift] , 3, 3);
            $ItemStoreOBJ::SelectedItem=getRecords($ItemStoreOBJ::ITEMLIST[5+$ItemStoreOBJ::PageShift] , 0, 0);
            %owned=CheckInventory(getRecords($ItemStoreOBJ::ITEMLIST[5+$ItemStoreOBJ::PageShift] , 0, 0));
            if(%owned==-1){
               %owned=0;
            }
            OwnedL.setText(%owned);
            CostL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[5+$ItemStoreOBJ::PageShift] , 1, 1));
            DescriptionL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[5+$ItemStoreOBJ::PageShift] , 2, 2));
        case 6:
            SelectItem1.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem2.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem3.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem4.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem5.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem6.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem7.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_h");
            SelectItem8.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem9.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem10.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem11.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem12.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem13.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem14.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            $ItemStoreOBJ::MaxQuantity=getRecords( $ItemStoreOBJ::ITEMLIST[6+$ItemStoreOBJ::PageShift] , 3, 3);
            $ItemStoreOBJ::SelectedItem=getRecords($ItemStoreOBJ::ITEMLIST[6+$ItemStoreOBJ::PageShift] , 0, 0);
            %owned=CheckInventory(getRecords($ItemStoreOBJ::ITEMLIST[6+$ItemStoreOBJ::PageShift] , 0, 0));
            if(%owned==-1){
               %owned=0;
            }
            OwnedL.setText(%owned);
            CostL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[6+$ItemStoreOBJ::PageShift] , 1, 1));
            DescriptionL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[6+$ItemStoreOBJ::PageShift] , 2, 2));
        case 7:
            SelectItem1.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem2.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem3.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem4.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem5.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem6.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem7.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem8.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_h");
            SelectItem9.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem10.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem11.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem12.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem13.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem14.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            $ItemStoreOBJ::MaxQuantity=getRecords( $ItemStoreOBJ::ITEMLIST[7+$ItemStoreOBJ::PageShift] , 3, 3);
            $ItemStoreOBJ::SelectedItem=getRecords($ItemStoreOBJ::ITEMLIST[7+$ItemStoreOBJ::PageShift] , 0, 0);
            %owned=CheckInventory(getRecords($ItemStoreOBJ::ITEMLIST[7+$ItemStoreOBJ::PageShift] , 0, 0));
            if(%owned==-1){
               %owned=0;
            }
            OwnedL.setText(%owned);
            CostL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[7+$ItemStoreOBJ::PageShift] , 1, 1));
            DescriptionL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[7+$ItemStoreOBJ::PageShift] , 2, 2));
        case 8:
            SelectItem1.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem2.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem3.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem4.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem5.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem6.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem7.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem8.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem9.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_h");
            SelectItem10.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem11.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem12.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem13.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem14.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            $ItemStoreOBJ::MaxQuantity=getRecords( $ItemStoreOBJ::ITEMLIST[8+$ItemStoreOBJ::PageShift] , 3, 3);
            $ItemStoreOBJ::SelectedItem=getRecords($ItemStoreOBJ::ITEMLIST[8+$ItemStoreOBJ::PageShift] , 0, 0);
            %owned=CheckInventory(getRecords($ItemStoreOBJ::ITEMLIST[8+$ItemStoreOBJ::PageShift] , 0, 0));
            if(%owned==-1){
               %owned=0;
            }
            OwnedL.setText(%owned);
            CostL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[8+$ItemStoreOBJ::PageShift] , 1, 1));
            DescriptionL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[8+$ItemStoreOBJ::PageShift] , 2, 2));
        case 9:
            SelectItem1.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem2.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem3.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem4.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem5.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem6.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem7.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem8.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem9.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem10.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_h");
            SelectItem11.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem12.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem13.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem14.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            $ItemStoreOBJ::MaxQuantity=getRecords( $ItemStoreOBJ::ITEMLIST[9+$ItemStoreOBJ::PageShift] , 3, 3);
            $ItemStoreOBJ::SelectedItem=getRecords($ItemStoreOBJ::ITEMLIST[9+$ItemStoreOBJ::PageShift] , 0, 0);
            %owned=CheckInventory(getRecords($ItemStoreOBJ::ITEMLIST[9+$ItemStoreOBJ::PageShift] , 0, 0));
            if(%owned==-1){
               %owned=0;
            }
            OwnedL.setText(%owned);
            CostL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[9+$ItemStoreOBJ::PageShift] , 1, 1));
            DescriptionL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[9+$ItemStoreOBJ::PageShift] , 2, 2));
        case 10:
            SelectItem1.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem2.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem3.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem4.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem5.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem6.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem7.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem8.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem9.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem10.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem11.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_h");
            SelectItem12.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem13.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem14.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            $ItemStoreOBJ::MaxQuantity=getRecords( $ItemStoreOBJ::ITEMLIST[10+$ItemStoreOBJ::PageShift] , 3, 3);
            $ItemStoreOBJ::SelectedItem=getRecords($ItemStoreOBJ::ITEMLIST[10+$ItemStoreOBJ::PageShift] , 0, 0);
            %owned=CheckInventory(getRecords($ItemStoreOBJ::ITEMLIST[10+$ItemStoreOBJ::PageShift] , 0, 0));
            if(%owned==-1){
               %owned=0;
            }
            OwnedL.setText(%owned);
            CostL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[10+$ItemStoreOBJ::PageShift] , 1, 1));
            DescriptionL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[10+$ItemStoreOBJ::PageShift] , 2, 2));
        case 11:
            SelectItem1.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem2.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem3.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem4.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem5.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem6.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem7.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem8.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem9.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem10.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem11.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem12.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_h");
            SelectItem13.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem14.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            $ItemStoreOBJ::MaxQuantity=getRecords( $ItemStoreOBJ::ITEMLIST[11+$ItemStoreOBJ::PageShift] , 3, 3);
            $ItemStoreOBJ::SelectedItem=getRecords($ItemStoreOBJ::ITEMLIST[11+$ItemStoreOBJ::PageShift] , 0, 0);
            %owned=CheckInventory(getRecords($ItemStoreOBJ::ITEMLIST[11+$ItemStoreOBJ::PageShift] , 0, 0));
            if(%owned==-1){
               %owned=0;
            }
            OwnedL.setText(%owned);
            CostL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[11+$ItemStoreOBJ::PageShift] , 1, 1));
            DescriptionL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[11+$ItemStoreOBJ::PageShift] , 2, 2));
        case 12:
            SelectItem1.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem2.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem3.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem4.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem5.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem6.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem7.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem8.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem9.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem10.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem11.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem12.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem13.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_h");
            SelectItem14.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            $ItemStoreOBJ::MaxQuantity=getRecords( $ItemStoreOBJ::ITEMLIST[12+$ItemStoreOBJ::PageShift] , 3, 3);
            $ItemStoreOBJ::SelectedItem=getRecords($ItemStoreOBJ::ITEMLIST[12+$ItemStoreOBJ::PageShift] , 0, 0);
            %owned=CheckInventory(getRecords($ItemStoreOBJ::ITEMLIST[12+$ItemStoreOBJ::PageShift] , 0, 0));
            if(%owned==-1){
               %owned=0;
            }
            OwnedL.setText(%owned);
            CostL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[12+$ItemStoreOBJ::PageShift] , 1, 1));
            DescriptionL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[12+$ItemStoreOBJ::PageShift] , 2, 2));
        case 13:
            SelectItem1.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem2.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem3.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem4.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem5.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem6.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem7.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem8.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem9.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem10.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem11.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem12.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem13.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_n");
            SelectItem14.setBitmap($ItemStoreOBJ::ITEMSELIMAGE@"_h");
            $ItemStoreOBJ::MaxQuantity=getRecords( $ItemStoreOBJ::ITEMLIST[13+$ItemStoreOBJ::PageShift] , 3, 3);
            $ItemStoreOBJ::SelectedItem=getRecords($ItemStoreOBJ::ITEMLIST[13+$ItemStoreOBJ::PageShift] , 0, 0);
            %owned=CheckInventory(getRecords($ItemStoreOBJ::ITEMLIST[13+$ItemStoreOBJ::PageShift] , 0, 0));
            if(%owned==-1){
               %owned=0;
            }
            OwnedL.setText(%owned);
            CostL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[13+$ItemStoreOBJ::PageShift] , 1, 1));
            DescriptionL.setText(getRecords( $ItemStoreOBJ::ITEMLIST[13+$ItemStoreOBJ::PageShift] , 2, 2));
      }
}

   $ItemStoreOBJ::SelectedItem="";
   $ItemStoreOBJ::TotalQuantity=0;
   $ItemStoreOBJ::MaxQuantity=0;
   $ItemStoreOBJ::TotalCost=0;
   $ItemStoreOBJ::Cost=0;
function ItemStoreOBJ::BuySelectedItem(){
   SFXPlay(AcceptFX);
   ISSelectListActionMap.pop();
   ISTotalActionMap.push(); 
   TotalControl.setVisible(true);
   $ItemStoreOBJ::TotalQuantity=0;
   $ItemStoreOBJ::TotalCost=0;
   $ItemStoreOBJ::Cost=0;
   $ItemStoreOBJ::Cost=CostL.getValue();
   TotalQuantity.setText($ItemStoreOBJ::TotalQuantity);
   TotalTotal.setText($ItemStoreOBJ::TotalCost);
   TotalCost.setText($ItemStoreOBJ::Cost);
}

function ItemStoreOBJ::BackBuy(){
   SFXPlay(CancelFX);
   ISTotalActionMap.pop(); 
   ISSelectListActionMap.push();
   TotalControl.setVisible(false);
   $ItemStoreOBJ::TotalQuantity=0;
   $ItemStoreOBJ::TotalCost=0;
   $ItemStoreOBJ::Cost=0;
}

function ItemStoreOBJ::CommitBuy(){
   if($ItemStoreOBJ::TotalQuantity==0){
      SFXPlay(CancelFX);
      ItemStoreOBJ.BackBuy();
   }else{
   SFXPlay(SpendFX);
   $Globals::Money-=$ItemStoreOBJ::TotalCost;
   AddInventory(1,$ItemStoreOBJ::SelectedItem,$ItemStoreOBJ::TotalQuantity);
   $ItemStoreOBJ::TotalQuantity=0;
   $ItemStoreOBJ::TotalCost=0;
   $ItemStoreOBJ::Cost=0;
   $ItemStoreOBJ_OptionsStore::GUIPOS=0;
   $ItemStoreOBJ_ItemSelect::GUIPOS=0;
   $ItemStoreOBJ::PageShift=0;
   $ItemStoreOBJ::COLPOS=0;
   $ItemStoreOBJ::ROWPOS=0;
   $ItemStoreOBJ::ITEMNUM=0;
   MoneyL.setText($Globals::Money);
   TotalControl.setVisible(false);
   SideControl.setVisible(false);
   DescptionControl.setVisible(false);
   ItemListControl.setVisible(false);
   OptionsControl.setVisible(true);
   ISTotalActionMap.pop();
   ISOptionsActionMap.push();
   }
}

new ActionMap(ISTotalActionMap);
ISTotalActionMap.bindCmd(keyboard, "w", "ItemStoreOBJ.IncreaseQuantity();","");
ISTotalActionMap.bindCmd(keyboard, "s", "ItemStoreOBJ.DecreaseQuantity();","");
ISTotalActionMap.bindCmd(keyboard, "k", "ItemStoreOBJ.CommitBuy();","");
ISTotalActionMap.bindCmd(keyboard, "l", "ItemStoreOBJ.BackBuy();","");


function ItemStoreOBJ::IncreaseQuantity(){
   $ItemStoreOBJ::TotalQuantity++;
   %nonCanceled=true;
   if($ItemStoreOBJ::TotalQuantity<0)
   {
      SFXPlay(CancelFX);
      %nonCanceled=false;
      $ItemStoreOBJ::TotalQuantity=0;
   }
   if($ItemStoreOBJ::TotalQuantity>$ItemStoreOBJ::MaxQuantity)
   {
      SFXPlay(CancelFX);
      %nonCanceled=false;
      $ItemStoreOBJ::TotalQuantity--;
   }
   
   $ItemStoreOBJ::TotalCost=$ItemStoreOBJ::TotalQuantity*$ItemStoreOBJ::Cost;
   if($ItemStoreOBJ::TotalCost>$Globals::Money)
   {
      SFXPlay(CancelFX);
      %nonCanceled=false;
      $ItemStoreOBJ::TotalQuantity--;
   }
   
   if(%nonCanceled==true){
      SFXPlay(AcceptFX);
   }
   $ItemStoreOBJ::TotalCost=$ItemStoreOBJ::TotalQuantity*$ItemStoreOBJ::Cost;
   
   TotalQuantity.setText($ItemStoreOBJ::TotalQuantity);
   TotalTotal.setText($ItemStoreOBJ::TotalCost);
   TotalCost.setText($ItemStoreOBJ::Cost);
}
function ItemStoreOBJ::DecreaseQuantity(){
 
   %nonCanceled=true;
   $ItemStoreOBJ::TotalQuantity--;
   if($ItemStoreOBJ::TotalQuantity<0)
   {
      SFXPlay(CancelFX);
   %nonCanceled=false;
      $ItemStoreOBJ::TotalQuantity=0;
   }
   if(%nonCanceled==true){
      SFXPlay(AcceptFX);
   }
   $ItemStoreOBJ::TotalCost=$ItemStoreOBJ::TotalQuantity*$ItemStoreOBJ::Cost;
   
   TotalQuantity.setText($ItemStoreOBJ::TotalQuantity);
   TotalTotal.setText($ItemStoreOBJ::TotalCost);
   TotalCost.setText($ItemStoreOBJ::Cost);
}





new ActionMap(ISSellSelectListActionMap);
ISSellSelectListActionMap.bindCmd(keyboard, "a", "ItemStoreOBJ.ItemSelectLeft();","");
ISSellSelectListActionMap.bindCmd(keyboard, "d", "ItemStoreOBJ.ItemSelectionRight();","");
ISSellSelectListActionMap.bindCmd(keyboard, "w", "ItemStoreOBJ.ItemSelectionUp();","");
ISSellSelectListActionMap.bindCmd(keyboard, "s", "ItemStoreOBJ.ItemSelectionDown();","");
ISSellSelectListActionMap.bindCmd(keyboard, "k", "ItemStoreOBJ.SellSelectedItem();","");
ISSellSelectListActionMap.bindCmd(keyboard, "l", "ItemStoreOBJ.LoadOptions();","");




new ActionMap(ISSellTotalActionMap);
ISSellTotalActionMap.bindCmd(keyboard, "w", "ItemStoreOBJ.IncreaseQuantity();","");
ISSellTotalActionMap.bindCmd(keyboard, "s", "ItemStoreOBJ.DecreaseQuantity();","");
ISSellTotalActionMap.bindCmd(keyboard, "k", "ItemStoreOBJ.CommitSell();","");
ISSellTotalActionMap.bindCmd(keyboard, "l", "ItemStoreOBJ.BackSell();","");



function ItemStoreOBJ::LoadSellItemDisplays(){
   OptionsControl.setVisible(false);
   SideControl.setVisible(true);
   DescptionControl.setVisible(true);
   ItemListControl.setVisible(true);
   ItemStoreOBJ.LoadSectionItems(2);
   if($ItemStoreOBJ::PageShift>0){
      Arrow_UP.setVisible(true);
   }else{
      Arrow_UP.setVisible(false);
   }
   echo("Calc: "@(($ItemStoreOBJ::PageShift)+14)@" of "@$ItemStoreOBJ::ITEMCOUNT);
   if($ItemStoreOBJ::ITEMCOUNT<=($ItemStoreOBJ::PageShift+14)){
      Arrow_DOWN.setVisible(false);
   }else{
      Arrow_DOWN.setVisible(true);
   }
   MoneyL.setText($Globals::Money);
}


function ItemStoreOBJ::SellSelectedItem(){
   SFXPlay(AcceptFX);
   ISSellSelectListActionMap.pop();
   ISSellTotalActionMap.push(); 
   TotalControl.setVisible(true);
   $ItemStoreOBJ::TotalQuantity=0;
   $ItemStoreOBJ::TotalCost=0;
   $ItemStoreOBJ::Cost=0;
   $ItemStoreOBJ::Cost=CostL.getValue();
   TotalQuantity.setText($ItemStoreOBJ::TotalQuantity);
   TotalTotal.setText($ItemStoreOBJ::TotalCost);
   TotalCost.setText($ItemStoreOBJ::Cost);
}

function ItemStoreOBJ::BackSell(){
   SFXPlay(CancelFX);
   ISTotalActionMap.pop(); 
   ISSelectListActionMap.push();
   TotalControl.setVisible(false);
   $ItemStoreOBJ::TotalQuantity=0;
   $ItemStoreOBJ::TotalCost=0;
   $ItemStoreOBJ::Cost=0;
}

function ItemStoreOBJ::CommitSell(){
   if($ItemStoreOBJ::TotalQuantity==0){
      SFXPlay(CancelFX);
      ItemStoreOBJ.BackSell();
   }else{
   SFXPlay(SpendFX);
   $Globals::Money+=$ItemStoreOBJ::TotalCost;
   RemoveInventory($ItemStoreOBJ::SelectedItem,$ItemStoreOBJ::TotalQuantity);
   $ItemStoreOBJ::TotalQuantity=0;
   $ItemStoreOBJ::TotalCost=0;
   $ItemStoreOBJ::Cost=0;
   $ItemStoreOBJ_OptionsStore::GUIPOS=0;
   $ItemStoreOBJ_ItemSelect::GUIPOS=0;
   $ItemStoreOBJ::PageShift=0;
   $ItemStoreOBJ::COLPOS=0;
   $ItemStoreOBJ::ROWPOS=0;
   $ItemStoreOBJ::ITEMNUM=0;
   MoneyL.setText($Globals::Money);
   TotalControl.setVisible(false);
   SideControl.setVisible(false);
   DescptionControl.setVisible(false);
   ItemListControl.setVisible(false);
   OptionsControl.setVisible(true);
   BuyBTN.setBitmap($ItemStoreOBJ::BUYIMAGE@"_h");
   SellBTN.setBitmap($ItemStoreOBJ::SELLIMAGE@"_n");
   CancelBTN.setBitmap($ItemStoreOBJ::CANCELIMAGE@"_n");
   ISSellTotalActionMap.pop();
   ISOptionsActionMap.push();
   }
}