function loadAddons()
{
   deleteVariables( "$luaChatCommands*" ); 
   $luaChatCommandsCt = 0;
   
   %i = 0;
   %base = "main/addons/*.lua"; // CHANGE THE ADDON FOLDER HERE

   for (%file = findFirstFile(%base); %file !$= ""; %file = findNextFile(%base)) 
   {
      luaFile(%file);
      %i++;
   }
   echo(%i @ " Addons loaded.");
}

function reloadlua()
{
   lua_reload();
}