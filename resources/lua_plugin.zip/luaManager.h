#ifndef _LUA_H_
#define _LUA_H_

extern "C" {
	#include "lua.h"
	#include "lauxlib.h"
	#include "lualib.h"
}

#include "game/gameBase.h"

struct LuaScript
{
	lua_State* state;
	const char* script;
};

class LuaManager
{
private:
public:
	
	static Vector<LuaScript*> scripts;
	static void init();
	static LuaScript* newScript();

	static int getStateIndex(lua_State*);

	static void LuaError(const char* err);

};

#endif