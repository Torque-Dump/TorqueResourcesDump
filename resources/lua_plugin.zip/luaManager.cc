#include "luaManager.h"
#include "sim/sceneObject.h"
#include "sceneGraph/sceneGraph.h"
#include "game/gameBase.h"
#include "game/gameConnection.h"


extern "C" {
	#include "lua.h"
	#include "lauxlib.h"
	#include "lualib.h"
}

static const luaL_Reg lualibs[] = {
	{"", luaopen_base},
	{LUA_LOADLIBNAME, luaopen_package},
	{LUA_TABLIBNAME, luaopen_table},
	{LUA_IOLIBNAME, luaopen_io},
	{LUA_OSLIBNAME, luaopen_os},
	{LUA_STRLIBNAME, luaopen_string},
	{LUA_MATHLIBNAME, luaopen_math},
	{LUA_DBLIBNAME, luaopen_debug},
	{NULL, NULL}
};


LUALIB_API void luaL_openlibs (lua_State *L) {
	const luaL_Reg *lib = lualibs;
	for (; lib->func; lib++) {
		lua_pushcfunction(L, lib->func);
		lua_pushstring(L, lib->name);
		lua_call(L, 1, 0);
	}
}

Vector<LuaScript*> LuaManager::scripts;


extern "C"
{
	static int Print_LUA (lua_State *L)
	{
		const char *s = lua_tostring(L, 1);
		Con::printf(s);

		return 0;
	}	
}

int registerFunctions (lua_State *L)
{
	// Print to console
	lua_pushcfunction(L, Print_LUA);
	lua_setglobal(L, "print");

	return 0;
}


LuaScript* LuaManager::newScript()
{
	lua_State* L = lua_open();

	LuaScript* script = new LuaScript;
	script->state = L;
	scripts.push_back(script);
	luaL_openlibs(L);
	registerFunctions(L);

	return script;
}

void LuaManager::init()
{

}

int LuaManager::getStateIndex(lua_State* state)
{
	for(int x=0; x< LuaManager::scripts.size(); x++)
	{
		lua_State* L = LuaManager::scripts[x]->state;

		if(L == state)
				return x;
	}
	
	return -1;
}

void LuaManager::LuaError(const char* err)
{
	Con::errorf(err);
}

void call_va (lua_State* L, const char *func, int argCount, ...)
{		
		va_list vl;
      int narg, nres;  /* number of arguments and results */
    
      va_start(vl, argCount);
      lua_getglobal(L, func);  /* get function */

		if( !lua_isfunction(L,lua_gettop(L)))
		{
			lua_pop(L, 1);
			return;
		}
    
      /* push arguments */
      for(int z=0; z<argCount; z++)
		{  /* push arguments */
			char * arg = va_arg(vl, char *);
            lua_pushstring(L, arg);
      }
    
      if (lua_pcall(L, argCount, 0, 0) != 0)  /* do the call */
		{
			lua_pop(L, 1);  /* pop error message from the stack */
         Con::errorf("error running function `%s': %s", func, lua_tostring(L, -1));
			return;
		}

		va_end(vl);     
    }


ConsoleFunction(lua_onLoaded, void, 1, 1, "()")
{
	for(int x=0; x< LuaManager::scripts.size(); x++)
	{
		lua_State* L = LuaManager::scripts[x]->state;
 		call_va(L, "onLoaded", 0, 0);
	}
}


ConsoleFunction(lua_reload, void, 1, 1, "()")
{
	for(int x=0; x< LuaManager::scripts.size(); x++)
	{
		lua_State* L = LuaManager::scripts[x]->state;

			int error = luaL_dofile(L, LuaManager::scripts[x]->script);

			if (error) {
				Con::errorf(lua_tostring(L, -1));
				lua_pop(L, 1);  /* pop error message from the stack */
			}
	}
}

ConsoleFunction(lua_event, void, 2, 10, "function name, args...")
{
	char* cmd = new char[64];

	char* arg1 = new char[1024];
	char* arg2 = new char[1024];
	char* arg3 = new char[1024];
	char* arg4 = new char[1024];
	char* arg5 = new char[1024];
	char* arg6 = new char[1024];
	char* arg7 = new char[1024];
	char* arg8 = new char[1024];


	dStrcpy(cmd, argv[1]);

	dStrcpy(arg1, argv[2]);
	dStrcpy(arg2, argv[3]);
	dStrcpy(arg3, argv[4]);
	dStrcpy(arg4, argv[5]);
	dStrcpy(arg5, argv[6]);
	dStrcpy(arg6, argv[7]);
	dStrcpy(arg7, argv[8]);
	dStrcpy(arg8, argv[9]);

	for(int x=0; x< LuaManager::scripts.size(); x++)
	{
		lua_State* L = LuaManager::scripts[x]->state;

		if(argc == 2)
			call_va(L, cmd, 0);
		else	if(argc == 3)
			call_va(L, cmd, 1, arg1);
		else	if(argc == 4)
			call_va(L, cmd, 2, arg1, arg2);
		else	if(argc == 5)
			call_va(L, cmd, 3, arg1, arg2, arg3);
		else	if(argc == 6)
			call_va(L, cmd, 4, arg1, arg2, arg3, arg4);
		else	if(argc == 7)
			call_va(L, cmd, 5, arg1, arg2, arg3, arg4, arg5);
		else	if(argc == 8)
			call_va(L, cmd, 6, arg1, arg2, arg3, arg4, arg5, arg6);
		else	if(argc == 9)
			call_va(L, cmd, 7, arg1, arg2, arg3, arg4, arg5, arg6, arg7);
		else	if(argc == 10)
			call_va(L, cmd, 8, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8);

	}	
}
ConsoleFunction(luaFile, void, 2, 2, "(string filename)")
{
	LuaScript* script = LuaManager::newScript();
	lua_State* L = script->state;
	int error;
	error = luaL_dofile(L, argv[1]);

	char* scriptname = new char[128];
	dStrcpy(scriptname, argv[1]);
	script->script = scriptname;

	if (error) {
		Con::errorf(lua_tostring(L, -1));
		lua_pop(L, 1);  /* pop error message from the stack */
   }
}


ConsoleFunction(luaFunction, void, 4, 4, "script number, function, arg string")
{
	int scriptNumber = dAtoi(argv[1]);
	lua_State* L = LuaManager::scripts[scriptNumber]->state;
	
	const char* cmd = argv[2];
	const char* args = argv[3];

	call_va(L, cmd, 1, args);
}