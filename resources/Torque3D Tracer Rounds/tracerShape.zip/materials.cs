singleton Material(tracerMat)
{
   mapTo = "tracer";
   diffuseMap[0] = "./tracer.png";
   glow[0] = "1";
   emissive[0] = "1";
};
