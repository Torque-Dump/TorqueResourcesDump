function C4ThrowerImage::tossC4(%data, %obj, %slot)
{
	//echo("ShapeBase::throwC4, creating item");
	%item = new Item()   
	{     
		datablock      = %data.thrownItem;   
		rotation       = "0 0 1 " @ (getRandom() * 360);
      scale          = "1 1 1";  
		position       = %obj.getMuzzlePoint(%slot);
		sourceObject   = %obj;  
		client         = %obj.client;
	};  
	MissionCleanup.add(%item);

	%obj.C4 = %obj.C4 SPC %item;

	//call the more general throwObject
	%temp = %obj.throwForce;
	%obj.throwForce = %data.throwForce;
	%obj.throwObject(%item);
	%obj.throwForce = %temp;

	%obj.decInventory(C4Ammo, 1);
}

function C4DetonatorImage::ExplodeC4(%data, %obj, %slot)
{

	for (%i = 1; %i < getWordCount(%obj.C4); %i++)
   {
	   %item = getWord(%obj.C4, %i);
	   C4Projectile.schedule(100 * %i, Explode, %item);
   }
	%obj.C4 = "";
}

function C4ThrowerImage::switchToPairedWeapon(%data, %obj, %slot)
{
   if (%obj.hasInventory(C4DetonatorImage))
   {
	   %obj.mountImage(C4DetonatorImage, %slot);
   }
   else
   {
      serverCmdCycleWeapon(%obj.client, "next");
   }
}

function C4DetonatorImage::switchToPairedWeapon(%data, %obj, %slot)
{
	if (%obj.hasInventory(C4Ammo))
	   %obj.mountImage(C4ThrowerImage, %slot);
}