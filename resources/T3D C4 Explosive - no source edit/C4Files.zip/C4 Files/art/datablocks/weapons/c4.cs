//-----------------------------------------------------------
//  C4s.cs - Class to add grenades to torque via script
//-----------------------------------------------------------
// This script file is an easy way to add grenades to your
// FPS.  Just exec this script from game.cs and bind a key 
// to call the throwC4DB function
//-----------------------------------------------------------

datablock ItemData(C4Projectile)
{   
	category = "Projectile";   
   className = "Projectile";
	shapeFile = "art/shapes/weapons/C4/C4Projectile.dts";
	pickUpName = 'C4';
   computeCRC = false;
   emap = true;
   renderWhenDestroyed = false;
	mass = 0.7;   
	friction = 1;   
	elasticity = 0;
	
	sticky = 1;
	repairAmount = 999999;   
	maxDamage = 999999;   
	directDamage = 30;   
	damageRadius = 12;   
	radiusDamage = 50;   
	areaImpulse = 3000;   
	dynamicType = $TypeMasks::DamagableItemObjectType;   
	explosion = RocketLauncherExplosion;
	waterExplosion = RocketLauncherWaterExplosion;
   decal = ScorchRXDecal;
	fadeIn = 0;

   gravityMod = 1;
   maxVelocity = 100;

   hasLight = false;
   lightType = NoLight; // NoLight, ConstantLight, PulsingLight
   lightRadius = 1;
   lightColor = "0.8 0.8 0.8 1";
   lightOnlyStatic = false;

	pickupSound = WeaponPickupSound;
	throwSound = WeaponThrowSound;

};

datablock ItemData(C4Ammo)
{   

	category = "Ammo";   
   className = "Ammo";
	shapeFile = "art/shapes/weapons/C4/C4.dts";
	pickUpName = 'C4';
   computeCRC = false;
   emap = true;
   renderWhenDestroyed = false;
	mass = 0.7;   
	friction = 1;   
	elasticity = 0.4;
	  
	dynamicType = $TypeMasks::ItemObjectType; 
	fadeIn = 0;

   gravityMod = 1;
   maxVelocity = 100;

   hasLight = false;
   lightType = NoLight; // NoLight, ConstantLight, PulsingLight
   lightRadius = 1;
   lightColor = "0.8 0.8 0.8 1";
   lightOnlyStatic = false;

	pickupSound = WeaponPickupSound;
	throwSound = WeaponThrowSound;

};

datablock ItemData(C4Weapon)
{
	shapeFile = "art/shapes/weapons/C4/C4.dts";
   pickUpName = "C4";
   description = "C4";
   image = C4ThrowerImage;
   category = "Weapon";
   className = "Weapon";
   computeCRC = false;
   emap = 1;
   mass = 5;
   drag = 0.5;
   density = 2;
   elasticity = 0.2;
   friction = 0.6;
   sticky = false;
   gravityMod = 1;
   maxVelocity = 100;
   dynamicType = $TypeMasks::ItemObjectType;

   hasLight = false; // Dynamic light
   lightType = NoLight; // NoLight, ConstantLight, PulsingLight
   lightColor = "0 0 0.5 1";
   lightRadius = 1;
   lightOnlyStatic = false;

   // Dynamic properties defined by the scripts
   pickupSound = WeaponPickupSound;
   throwSound = WeaponThrowSound;
};

datablock ShapeBaseImageData(C4ThrowerImage)
{
   throwForce = 6;

   className = WeaponImage;
	shapeFile = "art/shapes/weapons/C4/C4.dts";
   computeCRC = false;
   emap = true;
   cloakable = true;
   mass = 5;

   mountpoint = 0;
   offset = "0 0 0"; // L/R - F/B - T/B
   rotation = "1 0 0 0";
   eyeOffset = "0 0 0";
   eyeRotation = "1 0 0 0";
   useEyeOffset = false;
   firstPerson = true;

   correctMuzzleVector = true;
   armThread = lookms;

   usesEnergy = false;
   accuFire = true;

   item = C4Weapon;
   ammo = C4Ammo;
   thrownItem = C4Projectile;

   lightType = "NoLight";

   stateName[0]                    = "Preactivate";
   stateTransitionOnLoaded[0]      = "Activate";
   stateTransitionOnNoAmmo[0]      = "NoAmmo";

   stateName[1]                    = "Activate";
   stateTransitionOnTimeout[1]     = "Ready";
   stateTimeoutValue[1]            = 0.5;
   //stateSequence[1]                = "Activate";

   stateName[2]                    = "Ready";
   stateTransitionOnNoAmmo[2]      = "NoAmmo";
   stateTransitionOnTriggerDown[2] = "Fire";
   stateTransitionOnAltTriggerDown[2] = "Switch";
   //stateSequence[2]              = "Ready";

   stateName[3]                    = "Fire";
   stateTransitionOnTimeout[3]     = "Reload";
   stateTimeoutValue[3]            = 0.4;
   stateFire[3]                    = true;
   stateAllowImageChange[3]        = false;
   stateScript[3]                  = "tossC4";
   //stateSequence[3] = "Fire";

   stateName[4]                    = "Reload";
   stateTransitionOnNoAmmo[4]      = "NoAmmo";
   stateTransitionOnTimeout[4]     = "Ready";
   stateTimeoutValue[4]            = 0.8;
   stateAllowImageChange[4]        = false;
   //stateSequence[4]                = "Reload";

   stateName[5]                    = "NoAmmo";
   stateTransitionOnLoaded[5]      = "Switch";
   stateTransitionOnAmmo[5]        = "Reload";

   stateName[6]                    = "Switch";
   stateAllowImageChange[6]        = true;
   stateScript[6]                  = "switchToPairedWeapon";
};

datablock ItemData(C4DetonatorWeapon : C4Weapon)
{
   shapeFile = "art/shapes/weapons/C4/C4Detonator.dts";
   computeCRC = true;
   pickUpName = "C4Detonator";
   description = "C4 Detonator";
   image = C4DetonatorImage;
};

datablock ShapeBaseImageData(C4DetonatorImage)
{
   className = WeaponImage;
   shapeFile = "art/shapes/weapons/C4/C4Detonator.dts";
   computeCRC = false;
   emap = true;
   cloakable = true;
   mass = 5;

   mountpoint = 0;
   offset = "0 0 0"; // L/R - F/B - T/B
   rotation = "1 0 0 0";
   eyeOffset = "0 0 0";
   eyeRotation = "1 0 0 0";
   useEyeOffset = false;
   firstPerson = true;

   correctMuzzleVector = true;
   armThread = lookms;

   usesEnergy = false;
   accuFire = true;

   item = C4DetonatorWeapon;
   usesEnergy = true;
   minEnergy = 0;
   energyUsed = 0;

   lightType = "NoLight";

   stateName[0]                    = "Preactivate";
   stateTransitionOnLoaded[0]      = "Activate";

   stateName[1]                    = "Activate";
   stateTransitionOnTimeout[1]     = "Ready";
   stateTimeoutValue[1]            = 0.5;
   //stateSequence[1]                = "Activate";
   //stateSound[1]                   = WeaponSwitchSound;

   stateName[2]                    = "Ready";
   stateTransitionOnTriggerDown[2] = "Fire";
   stateTransitionOnAltTriggerDown[2] = "Switch";

   stateName[3]                    = "Fire";
   stateTransitionOnTimeout[3]     = "Switch";
   stateTimeoutValue[3]            = 0.4;
   stateFire[3]                    = false;
   stateAllowImageChange[3]        = false;
   stateScript[3]                  = "ExplodeC4";
   //stateSound[3]                   = GrenadeFireSound;

   stateName[4]                    = "Switch";
   stateAllowImageChange[4]        = true;
   stateScript[4]                  = "switchToPairedWeapon";
   stateTransitionOnTimeout[4]     = "Ready";
   stateTimeoutValue[4]            = 0.2;
};
	
function C4Projectile::Explode(%datablock, %obj)
{   

	//echo("C4Projectile::Explode called");
	%obj.setDamageState(Destroyed);

}

function C4Projectile::Damage(%this, %obj, %sourceObject, %position, %damage, %damageType)
{  
	if (!isObject(%obj) || %obj.destroyed)
	   return;
	//echo("C4Projectile::Damage called");
	//if (!%obj.destroyed)
	  // %obj.setDamageState(Destroyed);
}

function C4Projectile::onDestroyed(%data, %obj)
{
   //echo("C4Projectile::onDestroyed called");
   %obj.destroyed = true;

   %pos = %obj.getPosition();
   radiusDamage(%obj,%pos,%data.damageRadius,%data.radiusDamage,"C4",%data.areaimpulse);
   
   decalManagerAddDecal(%pos, "0 0 1", "1 0 0 0", "1 1 1", %data.decal);
   
   %obj.schedule(300, "delete"); 
}
