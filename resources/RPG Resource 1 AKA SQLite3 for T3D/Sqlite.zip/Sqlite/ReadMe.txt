To Create a new database file run the following in command line.

"sqlite3 database.db"


