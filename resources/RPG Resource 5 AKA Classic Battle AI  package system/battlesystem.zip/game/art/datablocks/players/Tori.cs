//-----------------------------------------------------------------------------
// Torque Game Engine Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

exec("art/shapes/players/Tori/Tori.cs");
datablock PlayerData(ToriData : DefaultPlayerData)
{
   className="ToriPlayer";
   renderFirstPerson = false;
   unit = 1;
   
   emap = true;
   density =1.1;
   airControl = 0.3;
   
   swimForce = 55.0 * 9.0;  
   maxUnderwaterForwardSpeed = 6.0;
   maxUnderwaterBackwardSpeed = 6.0;
   maxUnderwaterSideSpeed = 6.0;
   
   jetJumpForce       = 8.3 * 10;
   jetJumpEnergyDrain = 0.6;
   jetMinJumpEnergy   = 0;
   
   maxForwardSpeed = 24;
   jumpForce = 12.3 * 90;

   //className = Armor;
   shapeFile = "art/shapes/players/Tori/Tori.dae";
};

PlayerDatasGroup.add(ToriData);

datablock PlayerData(BattleMonster : DefaultPlayerData)
{
   category= "NPC_MOBS"; // Add to editor  
   shapeFile = "art/shapes/players/Tori/Tori.dae"; //Your Desired Chatacter Model
};

PlayerDatasGroup.add(BattleMonster);