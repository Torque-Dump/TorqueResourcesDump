//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

// Load up all datablocks.  This function is called when
// a server is constructed.
//exec("./NPCwonder.cs");
exec("./players/player.cs");
exec("./players/Tori.cs");
exec("./players/Mika.cs");
exec("./monsters/TinyBat.cs");
