$KEY::RPGMode = 0;
$KEY::BattleMode1 = 1;
$KEY::BattleMode2 = 2;
$KEY::SelectionMode = 3;
$KEY::ActionMode = 4;
$KEY::ItemMenuMode = 5;
$activeKeyPackage = $KEY::RPGMode;

function loadMyPackages()
{
   exec("./KeyMapBattleMode2.cs");
   exec("./KeyMapBattleMode1.cs");
   exec("./KeyMapRPGMode.cs");
   exec("./KeyMapSelectionMode.cs");
   exec("./KeyMapActionMenu.cs");
   exec("./KeyMapMenuSelectionMode.cs");
}

 function changeToPackage(%newOne)
{
	$lastPackage = $activeKeyPackage;
	$activeKeyPackage = %newOne;
	switch($lastPackage)
	{
      case 0:
      deactivatePackage(KeyMapRPGMode);
      case 1:
      deactivatePackage(KeyMapBattleMode1);
      case 2:
      deactivatePackage(KeyMapBattleMode2);
      case 3:
      deactivatePackage(KeyMapSelectionMode);   
      case 4:
      deactivatePackage(KeyMapActionMenu);   	
      case 5:
      deactivatePackage(KeyMapMenuSelectionMode);      
	   
	}
	
	switch($activeKeyPackage)
	{
      case 0:
      activatePackage(KeyMapRPGMode);
      case 1:
      activatePackage(KeyMapBattleMode1);
      case 2:
      activatePackage(KeyMapBattleMode2);
      case 3:
      activatePackage(KeyMapSelectionMode);  
      case 4:
      activatePackage(KeyMapActionMenu);   
      case 5:
      activatePackage(KeyMapMenuSelectionMode); 	 	   
	   
	}
	
	
}

loadMyPackages();
