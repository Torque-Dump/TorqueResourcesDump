//-----------------------------------------------------------------------------
// Torque        Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

function loadShell()
{
   exec("./profiles.cs");
   
   exec("./customProfiles.cs");
   exec("./Packages/init.cs");
   exec("./TitleScreen.cs");
   exec("./TitleScreen.gui");

   exec("./PauseMenu.cs");
   exec("./PauseMenu.gui");

   exec("./BattleGui.gui");
   exec("./BattleScreen.cs");
   
   exec("./VictoryGui.gui");
   exec("./VictoryScreen.cs");

//   exec("./MainMenuGui.cs");
//   exec("./MainMenuGui.gui");

//   exec("./playGui.gui");
   
//   exec("./OptionsGui.cs");
//   exec("./OptionsGui.gui");

//   exec("./GamepadButtonsGui.cs");
//   exec("./GamepadButtonsGui.gui");

//   exec("./ObjectPickerGui.cs");
//   exec("./ObjectPickerGui.gui");
   
//   exec("./ItemStore.cs");
//   exec("./ItemStoreGui.gui");
   
   
}

loadShell();
