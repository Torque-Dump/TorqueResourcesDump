package KeyMapMenuSelectionMode
{

function buttonleft(%val)
{

}

function buttonright(%val)
{
   
  

}

function buttonup(%val)
{
   if(%val)
   {
         $Battle::ItemMenuSlotNum--;
         
         %tempPos = getWord(SELTOOL.position,1);
         %tempPos-=20;         
         if($Battle::ItemMenuSlotNum<0)
         {
            $Battle::ItemMenuSlotNum=0;
            %tempPos=getWord($Battle::SelectionToolItemPosC1,1);
         }
         if($Battle::ItemMenuSlotNum>9)
         {
               %currentcol=  getWord($Battle::SelectionToolItemPosC2,0);          
         }
         else
         {
               %currentcol=  getWord($Battle::SelectionToolItemPosC1,0);  
         }
         SELTOOL.position=%currentcol@ " "@ %tempPos; 
   }
}

function buttondown(%val)
{
   
   if(%val)
   {
         $Battle::ItemMenuSlotNum++;
         %tempPos = getWord(SELTOOL.position,1);
         %tempPos+=20;         
         if($Battle::ItemMenuSlotNum>=$Battle::ItemCount-1)
         {
            $Battle::ItemMenuSlotNum=$Battle::ItemCount-1;
            %tempPos-=20; 
         }
         if($Battle::ItemMenuSlotNum>9)
         {
               %currentcol=  getWord($Battle::SelectionToolItemPosC2,0);          
         }
         else
         {
               %currentcol=  getWord($Battle::SelectionToolItemPosC1,0);  
         }
         SELTOOL.position=%currentcol@ " " @ %tempPos; 
   }
}

function buttonL(%val)
{
   
}
function buttonR(%val)
{
}

function buttonA(%val)
{
   
}

function buttonB(%val)
{

}

function buttonC(%val)
{
   if(%val)
   {
         BattleGui::Selection($Battle::ItemID[$Battle::ItemMenuSlotNum]);
   }
}

//jump function
function buttonD(%val)
{

}


//options screen
function buttonStart(%val)
{

}



};//package

