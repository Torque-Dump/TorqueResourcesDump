//-----------------------------------------------------------------------------
// Torque        Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Gui Profiles for the unified shell
//------------------------------------------------------------------------------
if(!isObject(GuiDefaultProfileTest)) new GuiControlProfile (GuiDefaultProfileTest)
{
   tab = false;
   canKeyFocus = false;
   hasBitmapArray = false;
   mouseOverSelected = false;

   // fill color
   opaque = false;
   fillColor = "127 136 153";
   fillColorHL = "197 202 211";
   fillColorNA = "144 154 171";

   // border color
   border = 0;
   borderColor   = "0 0 0"; 
   borderColorHL = "197 202 211";
   borderColorNA = "91 101 119";

   // font
   fontType = "Arial";
   fontSize = 14;
   fontCharset = ANSI;

   fontColor = "0 0 0";
   fontColorHL = "23 32 47";
   fontColorNA = "0 0 0";
   fontColorSEL= "126 137 155";

   // bitmap information
   bitmap = "";
   bitmapBase = "";
   textOffset = "0 0";

   // used by guiTextControl
   modal = true;
   justify = "left";
   autoSizeWidth = false;
   autoSizeHeight = false;
   returnTab = false;
   numbersOnly = false;
   cursorColor = "0 0 0 255";

   // sounds
   soundButtonDown = "";
   soundButtonOver = "";
};
if(!isObject(DefaultListMenuProfile)) new GuiGameListMenuProfile(DefaultListMenuProfile)
{
   fontType = "Arial Bold";
   fontSize = 20;
   fontColor = "120 120 120";
   fontColorSEL = "16 16 16";
   fontColorNA = "200 200 200";
   fontColorHL = "100 100 120";
   HitAreaUpperLeft = "16 20";
   HitAreaLowerRight = "503 74";
   IconOffset = "40 0";
   TextOffset = "100 0";
   RowSize = "525 93";
   bitmap = "./images/listMenuArray";
   canKeyFocus = true;
};

if(!isObject(DefaultOptionsMenuProfile)) new GuiGameListOptionsProfile(DefaultOptionsMenuProfile)
{
   fontType = "Arial Bold";
   fontSize = 20;
   fontColor = "120 120 120";
   fontColorSEL = "16 16 16";
   fontColorNA = "200 200 200";
   fontColorHL = "100 100 120";
   HitAreaUpperLeft = "16 20";
   HitAreaLowerRight = "503 74";
   IconOffset = "40 0";
   TextOffset = "90 0";
   RowSize = "525 93";
   ColumnSplit = "220";
   RightPad = "20";
   bitmap = "./images/listMenuArray";
   canKeyFocus = true;
};

if(!isObject(GamepadDefaultProfile)) new GuiControlProfile(GamepadDefaultProfile)
{
   border = 0;
};

if(!isObject(GamepadButtonTextLeft)) new GuiControlProfile(GamepadButtonTextLeft)
{
   fontType = "Arial Bold";
   fontSize = 20;
   fontColor = "255 255 255";
   justify = "left";
};

if(!isObject(GamepadButtonTextRight)) new GuiControlProfile(GamepadButtonTextRight : GamepadButtonTextLeft)
{
   justify = "right";
};

