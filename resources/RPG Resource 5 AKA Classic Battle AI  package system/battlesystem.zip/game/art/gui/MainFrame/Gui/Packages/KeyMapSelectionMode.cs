
package KeyMapSelectionMode
{

function buttonleft(%val)
{

}

function buttonright(%val)
{
   
  

}

function buttonup(%val)
{
   if(%val)
   {
      
      if($Battle::MenuAction$="Attack")
      {
         %tempPos = getWord(SELTOOL.position,1);
         %tempPos-=20;
         $Battle::SelectionMob--;
         if($Battle::SelectionMob<0)
         {
            $Battle::SelectionMob=$Battle::MonsterCount-1;
            %tempPos=getWord($Battle::SelectionToolObjectPos,1);
            %tempPos+=(20*($Battle::MonsterCount-1));
         }
         SELTOOL.position="442 " @ %tempPos; 
      }
      if($Battle::MenuAction$="Item")
      {
         
         %tempPos = getWord(SELTOOL.position,1);
         %tempPos-=20;         
         
         $Battle::SelectionPlayer--;
         if($Battle::SelectionPlayer<0)
         {
            $Battle::SelectionPlayer=$Pla::PartyCount-1;
            %tempPos=getWord($Battle::SelectionToolObjectPos,1);
            %tempPos+=(20*($Pla::PartyCount-1));
         }
         SELTOOL.position="442 " @ %tempPos; 
      }
      if($Battle::MenuAction$="Kouyou")
      {
         %tempPos = getWord(SELTOOL.position,1);
         %tempPos-=20;        
         $Battle::SelectionMob--;
         if($Battle::SelectionMob<0)
         {
            $Battle::SelectionMob=$Battle::MonsterCount-1;
            %tempPos=getWord($Battle::SelectionToolObjectPos,1);
            %tempPos+=(20*($Battle::MonsterCount-1));
         }
         SELTOOL.position="442 " @ %tempPos; 
      }
      
      if($Battle::MenuAction$="Arcana")
      {
         
         %tempPos = getWord(SELTOOL.position,1);
         %tempPos-=20;        
         $Battle::SelectionMob--;
         if($Battle::SelectionMob<0)
         {
            $Battle::SelectionMob=$Battle::MonsterCount-1;
            %tempPos=getWord($Battle::SelectionToolObjectPos,1);
            %tempPos+=(20*($Battle::MonsterCount-1));
         }
      }
      
   }
}

function buttondown(%val)
{
   if(%val)
   {
      if($Battle::MenuAction$="Attack"){
         %tempPos = getWord(SELTOOL.position,1);
         %tempPos+=20;         
         
         $Battle::SelectionMob++;
         if($Battle::SelectionMob>$Battle::MonsterCount-1)
         {
            $Battle::SelectionMob=0;
            %tempPos=getWord($Battle::SelectionToolObjectPos,1);
         }
         SELTOOL.position="442 " @ %tempPos;  
         //$Battle::GlobalClient.trackCamera.setTrackObject($Battle::MonsterHandel[$Battle::SelectionMob]);
         //$Battle::GlobalClient.setCameraObject($Battle::GlobalClient.trackCamera);
      }
      
      if($Battle::MenuAction$="Item")
      {
         
         
         %tempPos = getWord(SELTOOL.position,1);
         %tempPos+=20;         
         
         $Battle::SelectionPlayer++;
         if($Battle::SelectionPlayer>$Pla::PartyCount -1)
         {
            $Battle::SelectionPlayer=0;
            %tempPos=getWord($Battle::SelectionToolObjectPos,1);
         }
         SELTOOL.position="442 " @ %tempPos;  
            
         //$Battle::GlobalClient.trackCamera.setTrackObject($Battle::PlayerHandel::Player[$Battle::SelectionPlayer]);
         //$Battle::GlobalClient.setCameraObject($Battle::GlobalClient.trackCamera);
         
         
      }
      
      if($Battle::MenuAction$="Kouyou")
      {
         %tempPos = getWord(SELTOOL.position,1);
         %tempPos+=20;         
         
         $Battle::SelectionMob++;
         if($Battle::SelectionMob>$Battle::MonsterCount-1)
         {
            $Battle::SelectionMob=0;
            %tempPos=getWord($Battle::SelectionToolObjectPos,1);
         }
         SELTOOL.position="442 " @ %tempPos;  
         //$Battle::GlobalClient.trackCamera.setTrackObject($Battle::MonsterHandel[$Battle::SelectionMob]);
         //$Battle::GlobalClient.setCameraObject($Battle::GlobalClient.trackCamera);
      }
      
      if($Battle::MenuAction$="Arcana")
      {
         %tempPos = getWord(SELTOOL.position,1);
         %tempPos+=20;         
         
         $Battle::SelectionMob++;
         if($Battle::SelectionMob>$Battle::MonsterCount-1)
         {
            $Battle::SelectionMob=0;
            %tempPos=getWord($Battle::SelectionToolObjectPos,1);
         }
         SELTOOL.position="442 " @ %tempPos;  
         //$Battle::GlobalClient.trackCamera.setTrackObject($Battle::MonsterHandel[$Battle::SelectionMob]);
         //$Battle::GlobalClient.setCameraObject($Battle::GlobalClient.trackCamera);
      }
   }
}

function buttonL(%val)
{
   
}
function buttonR(%val)
{
}

function buttonA(%val)
{
   
}

function buttonB(%val)
{

}

function buttonC(%val)
{
   if(%val)
   {
      if($Battle::MenuAction$="Attack")
      {
         if($Battle::MonsterHandel[$Battle::SelectionMob].DEAD==0)
         {
            Battlegui::ToggleSelectionGui(0);
            BattleGui::Selection($Battle::SelectionMob);
            $Battle::SelectionMob=0;
         }
      } 
      
      if($Battle::MenuAction$="Item")
      {
         
         BattleGui::SelectItemTarget($Battle::SelectionPlayer);
         $Battle::SelectionPlayer=0;
      }
      
      if($Battle::MenuAction$="Kouyou")
      {
         if($Battle::MonsterHandel[$Battle::SelectionMob].DEAD==0)
         {
            BattleGui::SelectMobTarget($Battle::SelectionMob);
            $Battle::SelectionMob=0;
         }
      }
      if($Battle::MenuAction$="Arcana")
      {
         if($Battle::MonsterHandel[$Battle::SelectionMob].DEAD==0)
         {
            BattleGui::SelectMobTargetMagic($Battle::SelectionMob);
            $Battle::SelectionMob=0;
         }
      }
   }
}

//jump function
function buttonD(%val)
{

}


//options screen
function buttonStart(%val)
{

}



};//package

