
package KeyMapRPGMode
{
   
function startMenu()
{
quit();
}

function buttonleft(%val)
{
   $mvLeftAction = %val * $movementSpeed;
}

function buttonright(%val)
{
   $mvRightAction = %val * $movementSpeed;
}

function buttonup(%val)
{
   $mvForwardAction = %val * $movementSpeed;
}

function buttondown(%val)
{
   $mvBackwardAction = %val * $movementSpeed;
}




//alt shoot function
function buttonL(%val)
{

   $mvYawRightSpeed = %val ? $Pref::Input::KeyboardTurnSpeed : 0;
  
}

function buttonR(%val)
{
   $mvYawLeftSpeed = %val ? $Pref::Input::KeyboardTurnSpeed : 0;
}


//shoot function
function buttonA(%val)
{
   if(%val){
      Canvas.setContent(PauseMenu);
   }
}

function buttonB(%val)
{
   $mvTriggerCount2++;
}

function buttonC(%val)
{
   if(%val){
      if($Interaction::ItemStore){
         Canvas.setContent(ItemStore);
      }
   }
}

//jump function
function buttonD(%val)
{
   if(%val){
      Canvas.setContent(BattleGui); 
   }
}


//options screen
function buttonStart(%val)
{
   
}



};//package


