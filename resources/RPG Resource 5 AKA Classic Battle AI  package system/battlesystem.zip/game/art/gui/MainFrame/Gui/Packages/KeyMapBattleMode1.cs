package KeyMapBattleMode1
{

   function buttonleft(%val)
   {

   }

   function buttonright(%val)
   {

   }

   function buttonup(%val)
   {

   }

   function buttondown(%val)
   {

   }

   function buttonL(%val)
   {


   }
   function buttonR(%val)
   {


   }

   function buttonA(%val)
   {


   }

   function buttonB(%val)
   {

   }

   function buttonC(%val)
   {


   }

   //jump function
   function buttonD(%val)
   {

   }


   //options screen
   function buttonStart(%val)
   {

   }
}; //package


