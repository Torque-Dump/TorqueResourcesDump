
//===========================================================================
//                              Static Functions
//===========================================================================
$Victory::LIVINGMEMBERS=0;
$Victory::LIVINGENEMIES=0;
$Battle::MonsterHandel="";
$Battle::MonsterCount=0;
$Battle::PlayerCount=0;
$Battle::Menu="";
$Battle::MenuPos=0;

$Battle::SelectionMob=0;
$Battle::GlobalClient=0;
$Battle::StartBattle=0;

$Battle::HPOrgin=0;
$Battle::MPOrgin=0;
$Battle::KPOrgin=0;


$Battle::PlayerHandel="";

$Battle::MonsterHandel="";
$Battle::MonsterCount=0;

$Battle::Que0=0;
$Battle::Que1=0;
$Battle::Que2=0;
$Battle::Que3=0;
$Battle::Que4=0;
$Battle::Que5=0;
$Battle::Que6=0;
$Battle::Que7=0;
$Battle::Que8=0;

$Battle::HPOrginMob=0;
$Battle::ItemsSelection=0;
$Battle::Page=0;
$Battle::SelectionPlayer=0;
$Battle::MenuAction=" ";
$Battle::MenuCharacter=0;
$Battle::MoveSelection=0;
$Battle::MagicSelection=0;

$Battle::SelectionToolObjectPos="442 198";

$Battle::SelectionToolItemPosC1="17 185";

$Battle::SelectionToolItemPosC2="214 185";

$Battle::ItemMenuSlotNum=0;

$Battle::ItemID="";

$Battle::KouyouID="";


$Battle::AQueInit=0;
$Battle::AQueCounter=0;
$Battle::AttackQue="";


$Battle::MonsterPartyID=1;

function BattleGui::onWake(%this)
{
   // Turn off any shell sounds...
   // alxStop( ... );
   $enableDirectInput = "1";
   activateDirectInput();
if($Battle::StartBattle==0)
{
   $Battle::StartBattle=1;
   %this.initalize();
}
   // Activate the game's action map
   moveMap.push();
}

function BattleGui::onSleep(%this)
{
   // Pop the keymap
   moveMap.pop();
}

//===========================================================================
//                                 INIT BATTLE
//===========================================================================

function BattleGui::initalize(%this)
{
%this.HideAll();

   $BattleGroup = new SimGroup(BattleCleanup) {
   };     
   
   MissionGroup.add($BattleGroup);

   $Battle::Menu[0]="Attack";
   $Battle::Menu[1]="Arcana";
   $Battle::Menu[2]="Kouyou";
   $Battle::Menu[3]="Combo";
   $Battle::Menu[4]="Item";
   $Battle::Menu[5]="Defend";
   $Battle::Menu[6]="Escape";
   
   for(%i=0;%i<$PlayerObject::PlayerCount;%i++){
      if($PlayerObject::Player[%i].InBattle==true){
         $Victory::LIVINGMEMBERS++;
         $Battle::PlayerCount++;
      }
   }
   if($DEBUGMAP==0)
   {         
         %this.createPlayers();
         %this.createMonsters();   
   }
   BattleGui::ToggleP1Gui(1);
   BattleGui::SetUpP1();
   
   if($DEBUGMAP==0)
   {
         BattleTick();
   }

}

function BattleGui::SetUpP1(){
               P1HPTXT.setText($PlayerObject::Player[0].CurrentHP);
               P1MPTXT.setText($PlayerObject::Player[0].CurrentMP);
               $Battle::HPOrgin=%temppercent = getWord(P1HP.Extent,0);
               %tempStaticHeight = getWord(P1HP.Extent,1);
               %temppercent= ((($PlayerObject::Player[0].CurrentHP)/$PlayerObject::Player[0].MaxHP)*$Battle::HPOrgin);
               P1HP.Extent=%temppercent @ " " @ %tempStaticHeight;
               $Battle::MPOrgin=%temppercent = getWord(P1MP.Extent,0);
               %tempStaticHeight = getWord(P1MP.Extent,1);
               %temppercent= (($PlayerObject::Player[0].CurrentMP/$PlayerObject::Player[0].MaxMP)*$Battle::MPOrgin);
               P1MP.Extent=%temppercent @ " " @ %tempStaticHeight;
}

function BattleGui::createPlayers(%this)
{
   echo(nameToID("PartyFormation"));
   %i = 0;
   for(%i2=0 ; %i2 <$PlayerObject::PlayerCount ; %i2++)
   {      
      if($PlayerObject::Player[%i2].InBattle==true){
         %group = nameToID("PartyFormation");
         %spawn = %group.getObject(%i);
         $PlayerObject::Player[%i2].Avatar=%this.spawnPlayers($PlayerObject::Player[%i2].Name,%spawn.getTransform(), $PlayerObject::Player[%i2].DataBlock);
         $PlayerObject::Player[%i2].StartThinking($PlayerObject::Player[%i2]);
         $Battle::PlayerHandel[%i]=$PlayerObject::Player[%i2];
         %i++;
      }
   }
}

function BattleGui::createMonsters(%this)
{
   InitializeMonsters($Battle::MonsterPartyID);
   for(%i = 0 ; %i <$MonsterObject::MonsterCount ; %i++){
      %group = nameToID("MonsterFormation");
      %spawn = %group.getObject(%i);
      $MonsterObject::Monster[%i].Avatar=%this.spawnPlayers($MonsterObject::Monster[%i].Name,%spawn.getTransform(),$MonsterObject::Monster[%i].DataBlock);
      $MonsterObject::Monster[%i].StartThinking($MonsterObject::Monster[%i]);
      $Battle::MonsterHandel[%i]=$MonsterObject::Monster[%i];
   }
   $Victory::LIVINGENEMIES=$Battle::MonsterCount=$MonsterObject::MonsterCount;
}

function BattleGui::spawnPlayers(%this,%name,%spawnPoint,%dataBlock)
{
   // Create the demo player object
   %player = new AiPlayer() {
      dataBlock = %dataBlock;
      Name=%name;
      orgin=%spawnPoint;
   };
      echo(%spawnPoint);
   $BattleGroup.add(%player);
   %player.setTransform(%spawnPoint);
   return %player;
}


function BattleMonster::onMoveStuck(%this, %obj){
}
function BattleMonster::onReachDestination(%this, %obj){
}
function BattleMonster::onAdd(%this,%obj)  
{   
   %obj.setTransform(%obj.orgin);
}  
function BattleGui::spawnMobs(%this,%name,%spawnPoint, %dataBlock)
{
   // Create the demo player object
   %player = new AiPlayer() {
      dataBlock = %dataBlock;
      Name=%name;
      orgin=%spawnPoint;
   };
   $BattleGroup.add(%player);
   %player.setTransform(%spawnPoint);
   return %player;
}
//===========================================================================
//                                 MENU OPTIONS
//===========================================================================

function BattleGui::Attack()
{
   BattleGui::HideMenu();
   BattleGui::ToggleSelectionGui(1);
   SELTOOL.position=$Battle::SelectionToolObjectPos;
   if($Battle::MonsterCount>0)
   OBJ1.SetText($Battle::MonsterHandel[0].Name);
   if($Battle::MonsterCount>1)
   OBJ2.SetText($Battle::MonsterHandel[1].Name);
   if($Battle::MonsterCount>2)
   OBJ3.SetText($Battle::MonsterHandel[2].Name);
   if($Battle::MonsterCount>3)
   OBJ4.SetText($Battle::MonsterHandel[3].Name);
   if($Battle::MonsterCount>4)
   OBJ5.SetText($Battle::MonsterHandel[4].Name);
   if($Battle::MonsterCount>5)
   OBJ6.SetText($Battle::MonsterHandel[5].Name);
   if($Battle::MonsterCount>6)
   OBJ7.SetText($Battle::MonsterHandel[6].Name);
   if($Battle::MonsterCount>7)
   OBJ8.SetText($Battle::MonsterHandel[7].Name);
   if($Battle::MonsterCount>8)
   OBJ9.SetText($Battle::MonsterHandel[8].Name);
   
   $Battle::MenuAction="Attack";
   changeToPackage($KEY::SelectionMode);
}


function BattleGui::Kouyou()
{
/*
   for(%i = 0 ; %i<$PlayerObject::Player[$Battle::MenuCharacter].NumOMoves ; %i++)
   {
      if((%i>=0&&%i<7)&&($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].Learned==1))
      {
            List1.addRow(%i,$PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].Name @ " KP " @ $PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].MoveCost ,%i);
      }
      
   }
   

   BattleGui::HideMenu();
   $Battle::MenuAction="Kouyou";
   BattleGui::ToggleItemGui(1);
   $Battle::ItemMenuSlotNum=0;
   SELTOOL.position=$Battle::SelectionToolItemPosC1;
%slot = 1;
   for(%i = 0 ; %i<$PlayerObject::Player[$Battle::MenuCharacter].NumOMoves ; %i++)
   {
     
      if(($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].Learned==1))
      {
         
            switch(%slot)
            {
               case 1:
               
               TextBlock1.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].Name);
               PREFIX1.setText(" KP ");
               QTY1.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].MoveCost);
               $Battle::ItemID[%slot-1]=%i;
               
               case 2:
               
               TextBlock2.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].Name);
               PREFIX2.setText(" KP ");
               QTY2.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].MoveCost);
               $Battle::ItemID[%slot-1]=%i;
               
               case 3:
               
               TextBlock3.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].Name);
               PREFIX3.setText(" KP ");
               QTY3.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].MoveCost);
               $Battle::ItemID[%slot-1]=%i;
               
               case 4:
               
               TextBlock4.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].Name);
               PREFIX4.setText(" KP ");
               QTY4.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].MoveCost);
               $Battle::ItemID[%slot-1]=%i;
               
               case 5:
               
               TextBlock5.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].Name);
               PREFIX5.setText(" KP ");
               QTY5.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].MoveCost);
               $Battle::ItemID[%slot-1]=%i;
               
               case 6:
               
               TextBlock6.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].Name);
               PREFIX6.setText(" KP ");
               QTY6.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].MoveCost);
               $Battle::ItemID[%slot-1]=%i;
               
               case 7:
               
               TextBlock7.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].Name);
               PREFIX7.setText(" KP ");
               QTY7.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].MoveCost);
               $Battle::ItemID[%slot-1]=%i;
               
               case 8:
               
               TextBlock8.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].Name);
               PREFIX8.setText(" KP ");
               QTY8.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].MoveCost);
               $Battle::ItemID[%slot-1]=%i;
               
               case 9:
               
               TextBlock9.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].Name);
               PREFIX9.setText(" KP ");
               QTY9.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].MoveCost);
               $Battle::ItemID[%slot-1]=%i;
               
               case 10:
               
               TextBlock10.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].Name);
               PREFIX10.setText(" KP ");
               QTY10.setText($PlayerObject::Player[$Battle::MenuCharacter].Moves[%i].MoveCost);
               $Battle::ItemID[%slot-1]=%i;
          
               
            }
            %slot++;
               
               
      }
   }
   */
   $Battle::ItemCount=%slot;
   changeToPackage($KEY::ItemMenuMode);   
}

function BattleGui::Defend()
{
   BattleGui::HideMenu();
   $Battle::MenuAction="Defend";
   $Battle::MenuCharacter.AIManualAction=$AISTATES::DEFEND;
}

function BattleGui::Arcana()
{
   BattleGui::HideMenu();
/*   
   $Battle::MenuAction="Arcana";
   Menu.Visible=1;  
   List1.Visible=1;
   List2.Visible=1;
   List3.Visible=1;

   List1.clear();
   List2.clear();
   List3.clear();

   SELTOOL.position=$Battle::SelectionToolItemPos;
   for(%i = 0 ; %i<$PlayerObject::Player[$Battle::MenuCharacter].NumOMagic ; %i++)
   {
      if((%i>=0&&%i<7)&&($PlayerObject::Player[$Battle::MenuCharacter].Magic[%i].Learned==1))
      {
            List1.addRow(%i,$PlayerObject::Player[$Battle::MenuCharacter].Magic[%i].Name @ " MP " @ $PlayerObject::Player[$Battle::MenuCharacter].Magic[%i].MpCost ,%i);
      }
   }
   */
}

function BattleGui::Items()
{
   BattleGui::HideMenu();
   $Battle::MenuAction="Item";
   BattleGui::ToggleItemGui(1);
   $Battle::ItemMenuSlotNum=0;
   SELTOOL.position=$Battle::SelectionToolItemPosC1;
%slot = 1;
   for(%i = 0 ; %i<$InventoryObject::InventoryCount; %i++)
   {
     
      if(($InventoryObject::MyInventory[%i].getType()==$InventoryObject::ITEM_ENUM)&&($InventoryObject::MyInventory[%i].getQuantity()>0))
      {
         
            switch(%slot)
            {
               case 1:
               
               TextBlock1.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX1.setText(" x ");
               QTY1.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 2:
               
               TextBlock2.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX2.setText(" x ");
               QTY2.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 3:
               
               TextBlock3.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX3.setText(" x ");
               QTY3.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 4:
               
               TextBlock4.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX4.setText(" x ");
               QTY4.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 5:
               
               TextBlock5.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX5.setText(" x ");
               QTY5.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 6:
               
               TextBlock6.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX6.setText(" x ");
               QTY6.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 7:
               
               TextBlock7.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX7.setText(" x ");
               QTY7.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 8:
               
               TextBlock8.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX8.setText(" x ");
               QTY8.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 9:
               
               TextBlock9.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX9.setText(" x ");
               QTY9.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 10:
               
               TextBlock10.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX10.setText(" x ");
               QTY10.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 11:
               
               TextBlock11.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX11.setText(" x ");
               QTY11.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 12:
               
               TextBlock12.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX12.setText(" x ");
               QTY12.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 13:
               
               TextBlock13.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX13.setText(" x ");
               QTY13.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 14:
               
               TextBlock14.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX14.setText(" x ");
               QTY1.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 15:
               
               TextBlock15.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX15.setText(" x ");
               QTY15.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 16:
               
               TextBlock16.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX16.setText(" x ");
               QTY16.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 17:
               
               TextBlock17.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX17.setText(" x ");
               QTY17.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               case 18:
               
               TextBlock18.setText($InventoryObject::MyInventory[%i].getName());
               PREFIX18.setText(" x ");
               QTY18.setText($InventoryObject::MyInventory[%i].getQuantity());
               $Battle::ItemID[%slot-1]=%i;
               
               
            }
            %slot++;
               
               
      }
   }
   $Battle::ItemCount=%slot;
   changeToPackage($KEY::ItemMenuMode);
}

function BattleGui::RunAway()
{
   %rand=getRandom(0, 100);
   
   if(%rand>20)
   {
      $BattleGroup.delete();
      $Battle::StartBattle=0;  
      $Victory::EXPPOOL=0;
      $Victory::StartCalculation=0;
      /*$Battle::GlobalClient.setCameraObject($Battle::GlobalClient.moveCamera);*/
      changeToPackage($KEY::RPGMode);
      Canvas.setContent(PlayGui); 
   }
   
}

//===================================================================
//                         Functionality
//===================================================================
function BattleGui::Selection(%id)
{
   
      if($Battle::MenuAction$="Attack")
      {
         changeToPackage($KEY::BattleMode1);
         $Battle::MenuCharacter.HaultAction=true;
         $Battle::MenuCharacter.AIManualAction=$AISTATES::ATTACK;
         $Battle::MenuCharacter.Target=$Battle::MonsterHandel[%id];
         //$Battle::PlayerHandel[$Battle::MenuCharacter].setMoveDestination($Battle::MonsterHandel[%id].getPosition());
         //$Battle::PlayerHandel[$Battle::MenuCharacter].DoAction();
         AttackQueAdd($Battle::MenuCharacter);
         $Que::Busy=1;
         DropFromQue();
         $Que::Busy=0;
      }

      if($Battle::MenuAction$="Item")
      {
         $Battle::Page=0;
         BattleGui::ToggleItemGui(0); 
         BattleGui::ToggleSelectionGui(1);
         SELTOOL.position=$Battle::SelectionToolObjectPos;
         if($Pla::PartyCount>0)
         OBJ1.SetText($PlayerObject::Player[0].Name);
         if($Pla::PartyCount>1)
         OBJ2.SetText($PlayerObject::Player[1].Name);
         if($Pla::PartyCount>2)
         OBJ3.SetText($PlayerObject::Player[2].Name);
         if($Pla::PartyCount>3)
         OBJ4.SetText($PlayerObject::Player[3].Name);
         if($Pla::PartyCount>4)
         OBJ5.SetText($PlayerObject::Player[4].Name);
         if($Pla::PartyCount>5)
         OBJ6.SetText($PlayerObject::Player[5].Name);
         if($Pla::PartyCount>6)
         OBJ7.SetText($PlayerObject::Player[6].Name);
         if($Pla::PartyCount>7)
         OBJ8.SetText($PlayerObject::Player[7].Name);
         if($Pla::PartyCount>8)
         OBJ9.SetText($PlayerObject::Player[8].Name);
         
        // $Battle::GlobalClient.trackCamera.setTrackObject($Battle::PlayerHandel[$Battle::SelectionPlayer]);
         //$Battle::GlobalClient.setCameraObject($Battle::GlobalClient.trackCamera);
         changeToPackage($KEY::SelectionMode);
         $Battle::ItemsSelection=%id;
      }
      
      if($Battle::MenuAction$="Kouyou")
      {
         BattleGui::HideMenu();
         BattleGui::ToggleItemGui(0); 
         BattleGui::ToggleSelectionGui(1);
         SELTOOL.position=$Battle::SelectionToolObjectPos;
         $Battle::MoveSelection=%id;
         
         if($Battle::MonsterCount>0)
         OBJ1.SetText($Battle::MonsterHandel[0].Name);
         if($Battle::MonsterCount>1)
         OBJ2.SetText($Battle::MonsterHandel[1].Name);
         if($Battle::MonsterCount>2)
         OBJ3.SetText($Battle::MonsterHandel[2].Name);
         if($Battle::MonsterCount>3)
         OBJ4.SetText($Battle::MonsterHandel[3].Name);
         if($Battle::MonsterCount>4)
         OBJ5.SetText($Battle::MonsterHandel[4].Name);
         if($Battle::MonsterCount>5)
         OBJ6.SetText($Battle::MonsterHandel[5].Name);
         if($Battle::MonsterCount>6)
         OBJ7.SetText($Battle::MonsterHandel[6].Name);
         if($Battle::MonsterCount>7)
         OBJ8.SetText($Battle::MonsterHandel[7].Name);
         if($Battle::MonsterCount>8)
         OBJ9.SetText($Battle::MonsterHandel[8].Name);
         
         changeToPackage($KEY::SelectionMode);
      }
      if($Battle::MenuAction$="Arcana")
      {
         BattleGui::HideMenu();
         BattleGui::ToggleItemGui(0); 
         BattleGui::ToggleSelectionGui(1);
         SELTOOL.position=$Battle::SelectionToolObjectPos;
         $Battle::MoveSelection=%id;
         
         if($Battle::MonsterCount>0)
         OBJ1.SetText($Battle::MonsterHandel[0].Name);
         if($Battle::MonsterCount>1)
         OBJ2.SetText($Battle::MonsterHandel[1].Name);
         if($Battle::MonsterCount>2)
         OBJ3.SetText($Battle::MonsterHandel[2].Name);
         if($Battle::MonsterCount>3)
         OBJ4.SetText($Battle::MonsterHandel[3].Name);
         if($Battle::MonsterCount>4)
         OBJ5.SetText($Battle::MonsterHandel[4].Name);
         if($Battle::MonsterCount>5)
         OBJ6.SetText($Battle::MonsterHandel[5].Name);
         if($Battle::MonsterCount>6)
         OBJ7.SetText($Battle::MonsterHandel[6].Name);
         if($Battle::MonsterCount>7)
         OBJ8.SetText($Battle::MonsterHandel[7].Name);
         if($Battle::MonsterCount>8)
         OBJ9.SetText($Battle::MonsterHandel[8].Name);
         
         changeToPackage($KEY::SelectionMode);
      }
}

function BattleGui::HideSlideMenu()
{
      BattleGui::ToggleItemGui(0);
}

function BattleGui::FollowCurrentObj(%this)
{
   
      //$Battle::GlobalClient.trackCamera.setPosition(VectorAdd("2 3 3", $Battle::PlayerHandel[$Battle::MenuCharacter].getPosition()));
      //$Battle::GlobalClient.trackCamera.setTrackObject($Battle::PlayerHandel[$Battle::MenuCharacter]);
      //$Battle::GlobalClient.setCameraObject($Battle::GlobalClient.trackCamera);  
      
}




function BattleGui::Next()
{
      if($Battle::MenuAction$="Item")
      {
         NexMem.Visible=0;
         PreMem.Visible=0;
         $Battle::Page++;
         BattleGui::ReloadList();
      }
   
}
function BattleGui::Prev()
{
      if($Battle::MenuAction$="Item")
      {
         NexMem.Visible=0;
         PreMem.Visible=0;
         $Battle::Page--;
         BattleGui::ReloadList();
      }
   
}
function BattleGui::ReloadList()
{
   if($Battle::Page==0)
   {
      PreMem.Visible=0;
   }
   else
   {
      PreMem.Visible=1;
   }

      if($Battle::MenuAction$="Item")
      {
         %addjust=$Battle::Page*7;

         for(%i = 0+%addjust ; %i<$Inv::Sys.HealingUsedSlots ; %i++)
         {
           
            if(%i>=(0+%addjust)&&%i<(7+%addjust))
            {
                  List1.addRow((%i-%addjust),$InventoryObject::MyInventory[%i].getName()@ " x " @ $Inv::HealingInv[%i].Quantity ,%i);
            }
            if(%i>=(7+%addjust)&&%i<(14+%addjust))
            {
                  List2.addRow((%i-%addjust),$InventoryObject::MyInventory[%i].getName()@ " x " @ $Inv::HealingInv[%i].Quantity ,%i);
            }
            if(%i>=(14+%addjust)&&%i<(21+%addjust))
            {
                  List3.addRow((%i-%addjust),$InventoryObject::MyInventory[%i].getName()@ " x " @ $Inv::HealingInv[%i].Quantity ,%i);
            }
            if(%i>=(21+%addjust))
            {
                  NexMem.Visible=1;
            }
            
         }
      }
   
}


function List1::onSelect(%this, %row)
{
    %row++;
    %addjust=$Battle::Page*7;
    %row+=%addjust;
    echo("Item #"@%row);
    BattleGui::Selection(%row);
   
}
function List2::onSelect(%this, %row)
{
   
   %row++;
   %addjust=$Battle::Page*7;
    %row+=%addjust;
    echo("Item #"@%row);
    BattleGui::Selection(%row);
   
}
function List3::onSelect(%this, %row)
{
   %row++;
   %addjust=$Battle::Page*7;
    %row+=%addjust;
    echo("Item #"@%row);
    BattleGui::Selection(%row);
   
}



function BattleGui::SelectItemTarget(%ID)
{

         BattleGui::ToggleSelectionGui(0);
         changeToPackage($KEY::BattleMode1);
         $Battle::MenuCharacter.HaultAction=true;
         $Battle::MenuCharacter.Action=$AISTATES::ITEM;
         $Battle::MenuCharacter.Item=$Battle::ItemsSelection;
         $Battle::MenuCharacter.Target=$Battle::PlayerHandel[%id];
         $Battle::PlayerHandel[$Battle::MenuCharacter].TargetID=%id;
         //$Battle::PlayerHandel[$Battle::MenuCharacter].DoAction();
         AttackQueAdd($Battle::MenuCharacter);
         $Que::Busy=1;
         DropFromQue();
         $Que::Busy=0;
}


function BattleGui::SelectMobTarget(%ID)
{
         BattleGui::ToggleSelectionGui(0);
         changeToPackage($KEY::BattleMode1);
         $Battle::MenuCharacter.HaultAction=true;
         $Battle::MenuCharacter.Action=$AISTATES::KOUYOU;
         $Battle::MenuCharacter.selectedSpecial=%ID;
         $Battle::MenuCharacter.Target=$Battle::MonsterHandel[%id];
         //$Battle::PlayerHandel[$Battle::MenuCharacter].setMoveDestination($Battle::MonsterHandel[%id].getPosition());
         //$Battle::PlayerHandel[$Battle::MenuCharacter].DoAction();
         AttackQueAdd($Battle::MenuCharacter);
         $Que::Busy=1;
         DropFromQue();
         $Que::Busy=0;
  
}

function BattleGui::SelectMobTargetMagic(%ID)
{

   
         BattleGui::ToggleSelectionGui(0);
         changeToPackage($KEY::BattleMode1);
         $Battle::MenuCharacter.Action=$AISTATES::ARCANA;
         $Battle::MenuCharacter.selectedMagic=$Battle::MagicSelection;
         $Battle::MenuCharacter.Target=$Battle::MonsterHandel[%id];
         AttackQueAdd($Battle::PlayerHandel[$Battle::MenuCharacter]);
         $Que::Busy=1;
         DropFromQue();
         $Que::Busy=0;
  
}


function BattleGui::HideAll()
{
         ActionMenuFront.Visible=0;
         ActionMenuText.Visible=0;
         ActionMenuBack.Visible=0;
         
         
         ObjectSelection.Visible=0;
         OBJ1.Visible=0;
         OBJ2.Visible=0;
         OBJ3.Visible=0;
         OBJ4.Visible=0;
         OBJ5.Visible=0;
         OBJ6.Visible=0;
         OBJ7.Visible=0;
         OBJ8.Visible=0;
         OBJ9.Visible=0;
         
         ItemMenu.Visible=0;
         PREFIX1.Visible=0;
         PREFIX2.Visible=0;
         PREFIX3.Visible=0;
         PREFIX4.Visible=0;
         PREFIX5.Visible=0;
         PREFIX6.Visible=0;
         PREFIX6.Visible=0;
         PREFIX7.Visible=0;
         PREFIX8.Visible=0;
         PREFIX9.Visible=0;
         PREFIX10.Visible=0;
         PREFIX12.Visible=0;
         PREFIX13.Visible=0;
         PREFIX14.Visible=0;
         PREFIX15.Visible=0;
         PREFIX16.Visible=0;
         PREFIX17.Visible=0;
         PREFIX18.Visible=0;
         QTY1.Visible=0;
         QTY2.Visible=0;
         QTY3.Visible=0;
         QTY4.Visible=0;
         QTY5.Visible=0;
         QTY6.Visible=0;
         QTY7.Visible=0;
         QTY8.Visible=0;
         QTY9.Visible=0;
         QTY10.Visible=0;
         QTY11.Visible=0;
         QTY12.Visible=0;
         QTY13.Visible=0;
         QTY14.Visible=0;
         QTY15.Visible=0;
         QTY16.Visible=0;
         QTY17.Visible=0;
         QTY18.Visible=0;
         TextBlock1.Visible=0;
         TextBlock2.Visible=0;
         TextBlock3.Visible=0;
         TextBlock4.Visible=0;
         TextBlock5.Visible=0;
         TextBlock6.Visible=0;
         TextBlock7.Visible=0;
         TextBlock8.Visible=0;
         TextBlock9.Visible=0;
         TextBlock10.Visible=0;
         TextBlock11.Visible=0;
         TextBlock12.Visible=0;
         TextBlock13.Visible=0;
         TextBlock14.Visible=0;
         TextBlock15.Visible=0;
         TextBlock16.Visible=0;
         TextBlock17.Visible=0;
         TextBlock18.Visible=0;
         
         SELTOOL.Visible=0;
         desc.Visible=0;
         
         P1HP.Visible=0;
         P1HPTXT.Visible=0;
         P1KP.Visible=0;
         P1KPTXT.Visible=0;
         P1MP.Visible=0;
         P1MPTXT.Visible=0;
         P1STAT.Visible=0;
         P1WAIT.Visible=0;

         P2HP.Visible=0;
         P2HPTXT.Visible=0;
         P2KP.Visible=0;
         P2KPTXT.Visible=0;
         P2MP.Visible=0;
         P2MPTXT.Visible=0;
         P2STAT.Visible=0;
         P2WAIT.Visible=0;
         
         P3HP.Visible=0;
         P3HPTXT.Visible=0;
         P3KP.Visible=0;
         P3KPTXT.Visible=0;
         P3MP.Visible=0;
         P3MPTXT.Visible=0;
         P3STAT.Visible=0;
         P3WAIT.Visible=0;
         
         P4HP.Visible=0;
         P4HPTXT.Visible=0;
         P4KP.Visible=0;
         P4KPTXT.Visible=0;
         P4MP.Visible=0;
         P4MPTXT.Visible=0;
         P4STAT.Visible=0;
         P4WAIT.Visible=0;
         
         P5HP.Visible=0;
         P5HPTXT.Visible=0;
         P5KP.Visible=0;
         P5KPTXT.Visible=0;
         P5MP.Visible=0;
         P5MPTXT.Visible=0;
         P5STAT.Visible=0;
         P5WAIT.Visible=0;
         
         P6HP.Visible=0;
         P6HPTXT.Visible=0;
         P6KP.Visible=0;
         P6KPTXT.Visible=0;
         P6MP.Visible=0;
         P6MPTXT.Visible=0;
         P6STAT.Visible=0;
         P6WAIT.Visible=0;
         
         P7HP.Visible=0;
         P7HPTXT.Visible=0;
         P7KP.Visible=0;
         P7KPTXT.Visible=0;
         P7MP.Visible=0;
         P7MPTXT.Visible=0;
         P7STAT.Visible=0;
         P7WAIT.Visible=0;
         
         P8HP.Visible=0;
         P8HPTXT.Visible=0;
         P8KP.Visible=0;
         P8KPTXT.Visible=0;
         P8MP.Visible=0;
         P8MPTXT.Visible=0;
         P8STAT.Visible=0;
         P8WAIT.Visible=0;
         
         P9HP.Visible=0;
         P9HPTXT.Visible=0;
         P9KP.Visible=0;
         P9KPTXT.Visible=0;
         P9MP.Visible=0;
         P9MPTXT.Visible=0;
         P9STAT.Visible=0;
         P9WAIT.Visible=0;
}

function BattleGui::ToggleActionGui(%ENA)
{
         ActionMenuFront.Visible=%ENA;
         ActionMenuText.Visible=%ENA;
         ActionMenuBack.Visible=%ENA;
}

function BattleGui::ToggleSelectionGui(%ENA)
{
         
         ObjectSelection.Visible=%ENA;
         OBJ1.Visible=%ENA;
         OBJ2.Visible=%ENA;
         OBJ3.Visible=%ENA;
         OBJ4.Visible=%ENA;
         OBJ5.Visible=%ENA;
         OBJ6.Visible=%ENA;
         OBJ7.Visible=%ENA;
         OBJ8.Visible=%ENA;
         OBJ9.Visible=%ENA;
         SELTOOL.Visible=%ENA;
            
}

function BattleGui::ToggleItemGui(%enable)
{
   
         
         ItemMenu.Visible=%enable;
         PREFIX1.Visible=%enable;
         PREFIX2.Visible=%enable;
         PREFIX3.Visible=%enable;
         PREFIX4.Visible=%enable;
         PREFIX5.Visible=%enable;
         PREFIX6.Visible=%enable;
         PREFIX6.Visible=%enable;
         PREFIX7.Visible=%enable;
         PREFIX8.Visible=%enable;
         PREFIX9.Visible=%enable;
         PREFIX10.Visible=%enable;
         PREFIX12.Visible=%enable;
         PREFIX13.Visible=%enable;
         PREFIX14.Visible=%enable;
         PREFIX15.Visible=%enable;
         PREFIX16.Visible=%enable;
         PREFIX17.Visible=%enable;
         PREFIX18.Visible=%enable;
         QTY1.Visible=%enable;
         QTY2.Visible=%enable;
         QTY3.Visible=%enable;
         QTY4.Visible=%enable;
         QTY5.Visible=%enable;
         QTY6.Visible=%enable;
         QTY7.Visible=%enable;
         QTY8.Visible=%enable;
         QTY9.Visible=%enable;
         QTY10.Visible=%enable;
         QTY11.Visible=%enable;
         QTY12.Visible=%enable;
         QTY13.Visible=%enable;
         QTY14.Visible=%enable;
         QTY15.Visible=%enable;
         QTY16.Visible=%enable;
         QTY17.Visible=%enable;
         QTY18.Visible=%enable;
         TextBlock1.Visible=%enable;
         TextBlock2.Visible=%enable;
         TextBlock3.Visible=%enable;
         TextBlock4.Visible=%enable;
         TextBlock5.Visible=%enable;
         TextBlock6.Visible=%enable;
         TextBlock7.Visible=%enable;
         TextBlock8.Visible=%enable;
         TextBlock9.Visible=%enable;
         TextBlock10.Visible=%enable;
         TextBlock11.Visible=%enable;
         TextBlock12.Visible=%enable;
         TextBlock13.Visible=%enable;
         TextBlock14.Visible=%enable;
         TextBlock15.Visible=%enable;
         TextBlock16.Visible=%enable;
         TextBlock17.Visible=%enable;
         TextBlock18.Visible=%enable;
         
         SELTOOL.Visible=%enable;
   
}

function BattleGui::ToggleP1Gui(%ENA)
{
         P1HP.Visible=%ENA;
         P1HPTXT.Visible=%ENA;
         P1KP.Visible=%ENA;
         P1KPTXT.Visible=%ENA;
         P1MP.Visible=%ENA;
         P1MPTXT.Visible=%ENA;
         P1STAT.Visible=%ENA;
         P1WAIT.Visible=%ENA;
}

function BattleGui::ToggleP2Gui(%ENA)
{
         P2HP.Visible=%ENA;
         P2HPTXT.Visible=%ENA;
         P2KP.Visible=%ENA;
         P2KPTXT.Visible=%ENA;
         P2MP.Visible=%ENA;
         P2MPTXT.Visible=%ENA;
         P2STAT.Visible=%ENA;
         P2WAIT.Visible=%ENA;
}

function BattleGui::ToggleP3Gui(%ENA)
{
         P3HP.Visible=%ENA;
         P3HPTXT.Visible=%ENA;
         P3KP.Visible=%ENA;
         P3KPTXT.Visible=%ENA;
         P3MP.Visible=%ENA;
         P3MPTXT.Visible=%ENA;
         P3STAT.Visible=%ENA;
         P3WAIT.Visible=%ENA;
}

function BattleGui::ToggleP4Gui(%ENA)
{
         P4HP.Visible=%ENA;
         P4HPTXT.Visible=%ENA;
         P4KP.Visible=%ENA;
         P4KPTXT.Visible=%ENA;
         P4MP.Visible=%ENA;
         P4MPTXT.Visible=%ENA;
         P4STAT.Visible=%ENA;
         P4WAIT.Visible=%ENA;
}

function BattleGui::ToggleP5Gui(%ENA)
{
         P5HP.Visible=%ENA;
         P5HPTXT.Visible=%ENA;
         P5KP.Visible=%ENA;
         P5KPTXT.Visible=%ENA;
         P5MP.Visible=%ENA;
         P5MPTXT.Visible=%ENA;
         P5STAT.Visible=%ENA;
         P5WAIT.Visible=%ENA;
}

function BattleGui::ToggleP6Gui(%ENA)
{
         P6HP.Visible=%ENA;
         P6HPTXT.Visible=%ENA;
         P6KP.Visible=%ENA;
         P6KPTXT.Visible=%ENA;
         P6MP.Visible=%ENA;
         P6MPTXT.Visible=%ENA;
         P6STAT.Visible=%ENA;
         P6WAIT.Visible=%ENA;
}

function BattleGui::ToggleP7Gui(%ENA)
{
         P7HP.Visible=%ENA;
         P7HPTXT.Visible=%ENA;
         P7KP.Visible=%ENA;
         P7KPTXT.Visible=%ENA;
         P7MP.Visible=%ENA;
         P7MPTXT.Visible=%ENA;
         P7STAT.Visible=%ENA;
         P7WAIT.Visible=%ENA;
}

function BattleGui::ToggleP8Gui(%ENA)
{
         P8HP.Visible=%ENA;
         P8HPTXT.Visible=%ENA;
         P8KP.Visible=%ENA;
         P8KPTXT.Visible=%ENA;
         P8MP.Visible=%ENA;
         P8MPTXT.Visible=%ENA;
         P8STAT.Visible=%ENA;
         P8WAIT.Visible=%ENA;
}

function BattleGui::ToggleP9Gui(%ENA)
{
         P9HP.Visible=%ENA;
         P9HPTXT.Visible=%ENA;
         P9KP.Visible=%ENA;
         P9KPTXT.Visible=%ENA;
         P9MP.Visible=%ENA;
         P9MPTXT.Visible=%ENA;
         P9STAT.Visible=%ENA;
         P9WAIT.Visible=%ENA;
}

function BattleGui::HideMenu(%this)
{
      BattleGui::ToggleActionGui(0);
}



function BattleGui::ShowMenu(%this)
{
      changeToPackage($KEY::ActionMode);
      ActionMenuText.SetText($Battle::Menu[$Battle::MenuPos]);
      BattleGui::ToggleActionGui(1);
}

function BattleGui::LowerTime(%size, %id)
{
   switch(%id)
   {
         case 1:
         P1WAIT.Extent=%size;
         case 2:
         P2WAIT.Extent=%size;
   }
}

function BattleGui::Victory(%this)
{
   Canvas.setContent(VictoryGui); 
}
//==================================================================
//                        Timing System
//==================================================================
$Que::Player0=0;
$Que::Player1=0;
$Que::Player2=0;
$Que::Player3=0;
$Que::Player4=0;
$Que::Player5=0;
$Que::Player6=0;
$Que::Player7=0;
$Que::Player8=0;
$Que::Busy=0;
$Que::NumOPlayers=0;

$TickWait=0;


function BattleTick(%this)
{
   AttackQueTick();
   LifeMonitor();
   if($Que::NumOPlayers>0)
   {
       $Battle::MenuCharacter=$Que::Player[0];
       if($Battle::MenuCharacter.IsDead==1)
       {
          $Que::Busy=1;
          DropFromQue();
          $Que::Busy=0;
       }
       else
       {
          BattleGui::ShowMenu();
          //BattleGui::FollowCurrentObj();
       }
       
   }
   else
   {
   	schedule(100, 0, "BattleTick");
   }
}

function LifeMonitor(%this)
{
      %MONSTERSDEAD=1;
      %PLAYERSDEAD=1;

      for(%i=0;%i<$Victory::LIVINGENEMIES;%i++)
      {       
         //echo("Name: "@$Battle::MonsterHandel[%i].Name@"_"@%i@"  HP: "@$Battle::MonsterHandel[%i].CurrentHP);
           if($Battle::MonsterHandel[%i].isDead==false)
           {
              %MONSTERSDEAD=0;
              if($Battle::MonsterHandel[%i].CurrentHP<=0)
              {
                 $Victory::LIVINGENEMIES--;
                 $Victory::EXPPOOL+=$Battle::MonsterHandel[%i].EXP;
                 echo("TOT EXP: "@$Victory::EXPPOOL @"   Mob: "@$Battle::MonsterHandel[%i].EXP);
                 $Battle::MonsterHandel[%i].AIState=$AISTATES::DIE;
                 
                  for(%b=%i;%b<$Victory::LIVINGENEMIES+1;%b++)
                  {       
                     $Battle::MonsterHandel[%b]=$Battle::MonsterHandel[%b+1];
                  }
                  %i--;
              }
           }
      }
      
      for(%i=0;%i<$Victory::LIVINGMEMBERS;%i++)
      {       
         //echo("Name: "@$Battle::PlayerHandel[%i].Name@"_"@%i@"  HP: "@$Battle::PlayerHandel[%i].CurrentHP);         
           if($Battle::PlayerHandel[%i].isDead==false)
           {
              %PLAYERSDEAD=0;
              if($Battle::PlayerHandel[%i].CurrentHP<=0)
              {
                 $Victory::LIVINGMEMBERS--;
                 $Battle::PlayerHandel[%i].AIState=$AISTATES::DIE;
                 
                  for(%b=%i;%b<$Victory::LIVINGMEMBERS;%b++)
                  {       
                     $Battle::PlayerHandel[%b]=$Battle::PlayerHandel[%b+1];
                  }
                  %i--;
              }
              BattleGui::UpDateP1Gui();
           }
      }           
      if( %PLAYERSDEAD==1)
      {
          quit();            
          return;
      }
      if( %MONSTERSDEAD==1)
      {
          BattleGui::Victory(); 
          return;
      }
}
function getNumberOfLivingEnemies(){
      return  $Victory::LIVINGENEMIES;
}
function getNumberOfLivingPlayers(){
      return  $Victory::LIVINGMEMBERS;
}
function getTargetEnemy(%pos){
      return $Battle::MonsterHandel[%pos];
}
function getTargetPlayer(%pos){
      return $Battle::PlayerHandel[%pos];
}

function BattleGui::UpDateP1Gui()
{
         P1HPTXT.setText($PlayerObject::Player[0].CurrentHP);
         P1MPTXT.setText($PlayerObject::Player[0].CurrentMP);
               
               
         %tempStaticHeight = getWord(P1HP.Extent,1);
         %temppercent= ((($PlayerObject::Player[0].CurrentHP)/$PlayerObject::Player[0].MaxHP)*$Battle::HPOrgin);
             
         if(%temppercent<=0)
         {
            $Battle::PlayerHandel[0].AIState=$AISTATES::DIE;
            %temppercent=0;
         }
         if(%temppercent>$Battle::HPOrgin)
         {
            %temppercent=$Battle::HPOrgin;
         }
         P1HP.Extent=%temppercent @ " " @ %tempStaticHeight;
         
         %tempStaticHeight = getWord(P1MP.Extent,1);
         %temppercent= (($PlayerObject::Player[0].CurrentHP/$PlayerObject::Player[0].MaxMP)*$Battle::MPOrgin);
         if(%temppercent<0)
         {
            %temppercent=0;
         }
         if(%temppercent>$Battle::MPOrgin)
         {
            %temppercent=$Battle::MPOrgin;
         }
         P1MP.Extent=%temppercent @ " " @ %tempStaticHeight;
}


function DropFromQue(%this)
{
	for(%i=0 ; %i<$Que::NumOPlayers ; %i++)
	{
		$Que::Player[%i]=$Que::Player[%i+1];
	}
	$Que::NumOPlayers--;
   BattleTick();
}
function AddToQue(%obj)
{
	$Que::Player[$Que::NumOPlayers]=%obj;
	$Que::NumOPlayers++;
   BattleTick();
}

function AttackQueAdd(%obj)
{
   $Battle::AttackQue[$Battle::AQueCounter]=%obj;
	$Battle::AQueCounter++;	
}

function AttackQueTick()
{
   if($Battle::AQueCounter==0) return;
   
   $Battle::AttackQue[0].HaultAction=false;
   if($Battle::AttackQue[0].isDead==true||$Battle::AttackQue[0].AIState==$AISTATES::COOLDOWN||$Battle::AttackQue[0].AIState==$AISTATES::ESCAPE||$Battle::AttackQue[0].AIState==$AISTATES::DIE||$Battle::AttackQue[0].AIState==$AISTATES::IDLE)
   {
      for(%i=0 ; %i<$Battle::AQueCounter ; %i++)
      {
         $Battle::AttackQue[%i]=$Battle::AttackQue[%i+1];
      }
      $Battle::AQueCounter--;
   }
}