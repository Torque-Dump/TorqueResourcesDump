

function VictoryGui::onWake(%this)
{
   // Turn off any shell sounds...
   // alxStop( ... );
   $enableDirectInput = "1";
   activateDirectInput();
   if($Victory::StartCalculation==0)
   {
      $Battle::StartBattle=0;  
      $Victory::StartCalculation=1;
      %this.initalize();
   }
   // Activate the game's action map
   moveMap.push();
}

function VictoryGui::onSleep(%this)
{
   // Pop the keymap
   moveMap.pop();
}

function VictoryGui::initalize(%this)
{
   %this.schedule(100, "DisplayVictory");
}

function VictoryGui::DisplayVictory(%this)
{
   VICTORYICON.Visible=1;
   
   %this.schedule(3000, "DisplayEXPMenu");
}


function VictoryGui::DisplayEXPMenu(%this)
{
   VICTORYICON.Visible=0;
   VS_EXPMenu.Visible=1;
   for(%i = 0; %i<$Victory::LIVINGMEMBERS;%i++)
   {
      if($Battle::PlayerHandel[%i].CurrentHP<=0)
      {
         $Victory::EXPGAIN[%i]=0;
      }
      else
      {
         $Victory::EXPGAIN[%i]=(($Victory::EXPPOOL/$Victory::LIVINGMEMBERS));
         echo(($Victory::EXPPOOL/$Victory::LIVINGMEMBERS)@" "@$Victory::EXPGAIN[%i]);
      }
   }
   switch($Victory::LIVINGMEMBERS)
   {
         case 1:
         $Victory::CountDownChecker++;
            %this.P1CountDown();
         
         case 2:
            $Victory::CountDownChecker++;
            %this.ToggleP1(1);
            %this.P1CountDown();
            $Victory::CountDownChecker++;
            %this.ToggleP2(1);
            %this.P2CountDown();
         
         case 3:
         
         case 4:
         
         case 5:
         
         case 6:
         
         case 7:
         
         case 8:
         
         case 9:
         
               
      
   }
   %this.CheckDone();
}

function VictoryGui::P1CountDown(%this)
{
   PNAME1.setText($Battle::PlayerHandel[0].Name);
   TNL1.setText($Battle::PlayerHandel[0].ExpTNL);
   VS_EXP1.setText($Victory::EXPGAIN[0]);
   $Battle::PlayerHandel[0].ExpTNL--;
   $Victory::EXPGAIN[0]-=1;
   if($Battle::PlayerHandel[0].ExpTNL==0)
   {
      LVL1.Visible=1;
      $Battle::PlayerHandel[0].LevelUp();
   }
   
   if($Victory::EXPGAIN[0]>0)
   {
      %this.schedule(100, "P1CountDown");
      return;
   }
   $Victory::CountDownChecker--;
}

function VictoryGui::P2CountDown(%this)
{
   PNAME2.setText($Battle::PlayerHandel[1].Name);
   TNL2.setText($Battle::PlayerHandel[1].ExpTNL);
   VS_EXP2.setText($Victory::EXPGAIN[1]);
   $Battle::PlayerHandel[1].ExpTNL--;
   $Victory::EXPGAIN[1]-=1;
   if($Battle::PlayerHandel[1].ExpTNL==0)
   {
      LVL2.Visible=1;
      $Battle::PlayerHandel[1].LevelUp();
   }
   
   if($Victory::EXPGAIN[1]>0)
   {
      %this.schedule(100, "P2CountDown");
      return;
   }
   $Victory::CountDownChecker--;
}

function VictoryGui::ToggleP1(%ENA)
{
   PNAME1.Visible=%ENA;
   TNL1.Visible=%ENA;
   VS_EXP1.Visible=%ENA; 
   
}

function VictoryGui::ToggleP2(%ENA)
{
   PNAME2.Visible=%ENA;
   TNL2.Visible=%ENA;
   VS_EXP2.Visible=%ENA; 
   
}
function VictoryGui::CheckDone(%this)
{
   
   if($Victory::CountDownChecker==0)
   {
         %this.ResetMonstersLife();
         VS_EXPMenu.Visible=0;
         $Victory::EXPPOOL=0;
         %this.ToggleP1(0);
         %this.ToggleP2(0);
         BattleCleanup.delete();
         $Victory::StartCalculation=0;
         /*$Battle::GlobalClient.setCameraObject($Battle::GlobalClient.moveCamera);*/
         changeToPackage($KEY::RPGMode);
         Canvas.setContent(PlayGui); 
      
   }
   else
   {  
      %this.schedule(2000, "CheckDone");   
   }
}

function VictoryGui::ResetMonstersLife()
{
   
}

