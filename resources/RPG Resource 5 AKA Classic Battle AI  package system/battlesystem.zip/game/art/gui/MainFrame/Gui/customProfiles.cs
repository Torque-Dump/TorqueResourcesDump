//-----------------------------------------------------------------------------
// Torque Game Engine Advanced
// Copyright (c) 2002 GarageGames.Com
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Game specific profiles are located here
//-----------------------------------------------------------------------------
/*
singleton GuiControlProfile (GuiTitleProfile)
{
   opaque = false;
   fontType = "Arial Bold";
   fontSize = 32;
   fontColor = "255 255 255";
   fontColorHL = "255 255 255";
   justify = "right";
};

singleton GuiControlProfile (GuiPopUpTextProfile)
{
   fontType = "Arial";
   fontSize = 14;
   fontColor = "255 255 255";
   fontColorHL = "255 255 255";
   fontColorLink = "255 96 96";
   fontColorLinkHL = "0 0 255";
};
*/

//Custom


if(!isObject(WhiteTextLeft)) new GuiControlProfile(WhiteTextLeft)
{
   fontType = "Arial Bold";
   fontSize = 20;
   fontColor = "255 255 255";
   justify = "left";
};

if(!isObject(BlackTextLeft))new GuiControlProfile(BlackTextLeft)
{
   fontType = "Arial Bold";
   fontSize = 25;
   fontColor = "0 0 0";
   justify = "left";
};

if(!isObject(BlackTextCenter))new GuiControlProfile(BlackTextCenter)
{
   fontType = "Arial Bold";
   fontSize = 30;
   fontColor = "0 0 0";
   justify = "center";
};

if(!isObject(BlackTextRight))new GuiControlProfile(BlackTextRight)
{
   fontType = "Arial Bold";
   fontSize = 30;
   fontColor = "0 0 0";
   justify = "right";
};

if(!isObject(MapTextProfile))new GuiControlProfile(MapTextProfile)
{
   opaque = false;
   fontType = "Arial Bold";
   fontSize = 20;
   fontColor = "237 201 0";
   fontColorHL = "237 201 0";
   justify = "center";
   //canKeyFocus = true;
};



if(!isObject(StoreLightTextRight))new GuiControlProfile(StoreLightTextRight)
{
   fontType = "Arial Bold";
   fontSize = 30;
   fontColor = "253 254 191";
   justify = "right";
};

if(!isObject(StoreLightTextCenter))new GuiControlProfile(StoreLightTextCenter)
{
   fontType = "Arial Bold";
   fontSize = 30;
   fontColor = "253 254 191";
   justify = "center";
};

if(!isObject(StoreLightTextLeft))new GuiControlProfile(StoreLightTextLeft)
{
   fontType = "Arial Bold";
   fontSize = 25;
   fontColor = "253 254 191";
   justify = "left";
};
if(!isObject(StoreItemTextLeft))new GuiControlProfile(StoreItemTextLeft)
{
   fontType = "Arial Bold";
   fontSize = 25;
   fontColor = "0 0 0";
   justify = "left";
};