package KeyMapActionMenu
{

function buttonleft(%val)
{

   if(%val)
   {
      $Battle::MenuPos--;
      
      if($Battle::MenuPos<0)
      {
         $Battle::MenuPos=6;      
      }
      ActionMenuText.SetText($Battle::Menu[$Battle::MenuPos]);
   }
}

function buttonright(%val)
{
   
   if(%val)
   {
      $Battle::MenuPos++;
      
      if($Battle::MenuPos>=7)
      {
         $Battle::MenuPos=0;      
      }
      
      ActionMenuText.SetText($Battle::Menu[$Battle::MenuPos]);
   }
}

function buttonup(%val)
{

}

function buttondown(%val)
{

}

function buttonL(%val)
{


}
function buttonR(%val)
{


}

function buttonA(%val)
{


}

function buttonB(%val)
{

}

function buttonC(%val)
{

   if(%val)
   {
      switch$($Battle::Menu[$Battle::MenuPos])
      {
            case "Attack":
               BattleGui::Attack();
            case "Arcana":
            /*
            for(%i=0 ; %i<$Pla::Sys[$Battle::MenuCharacter].NumOMagic; %i++)
            {
               if($Pla::Sys[$Battle::MenuCharacter].Magic[%i].Learned==1)
               {
                  BattleGui::Arcana();                  
               }
            }*/
            case "Kouyou":
            /*
            for(%i=0 ; %i<$Pla::Sys[$Battle::MenuCharacter].NumOMoves; %i++)
            {
               if($Pla::Sys[$Battle::MenuCharacter].Moves[%i].Learned==1)
               {
                  BattleGui::Kouyou();
               }
            }
              */ 
            case "Combo":
            
            case "Item":
               BattleGui::Items();
            case "Defend":
               BattleGui::Defend();
            case "Escape":
               BattleGui::RunAway();   
      }
   }
}

function buttonD(%val)
{

}


//options screen
function buttonStart(%val)
{

}

}; //package

