$Globals::CurrectMap="Tutorial";
$Globals::Time="";
$Globals::Money="300";
$Globals::PlayerObject=ToriDts;
$Globals::GameConnection="";
$Server::NextSpawnLocation="TutorialEntrance";
$Interaction::ItemStore=false;
$Interaction::ArmorStore=false;
$Interaction::WeaponStore=false;
$Interaction::NPC=false;
$Interaction::TreasureChest=false;
$Interaction::GuildStartQuest=false;
$Interaction::GuildEndQuest=false;
$Interaction::GuildArtifacts=false;
$Interaction::SlipstreamStore=false;
$Interaction::BattleArena=false;
$BGMusicHandel::NowPlaying="";


