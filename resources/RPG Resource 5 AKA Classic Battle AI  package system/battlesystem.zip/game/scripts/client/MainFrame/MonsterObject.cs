$MonsterObject::Monster="";
$MonsterObject::MonsterCount=0;
$MONSTER_REQUEST=1;
new ScriptObject(Monsters){
            
};
function InitializeMonsters(%PartyID){
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   %monsterArray=0;
   %monsterCount=0;
   %query = "Select Monster1ID,Monster2ID,Monster3ID,Monster4ID,Monster5ID,Monster6ID,Monster7ID FROM MonsterParty where MonsterPartyID="@%PartyID@";";
   %result = sqlite.query(%query, 0);
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      %i=0;
         %MonsterID = sqlite.getColumn(%result, "Monster1ID");
         if(%MonsterID){
            %monsterArray[%monsterCount]=%MonsterID;
            %monsterCount++;
         }
         %MonsterID = sqlite.getColumn(%result, "Monster2ID");
         if(%MonsterID){
            %monsterArray[%monsterCount]=%MonsterID;
            %monsterCount++;
         }
         %MonsterID = sqlite.getColumn(%result, "Monster3ID");
         if(%MonsterID){
            %monsterArray[%monsterCount]=%MonsterID;
            %monsterCount++;
         }
         %MonsterID = sqlite.getColumn(%result, "Monster4ID");
         if(%MonsterID){
            %monsterArray[%monsterCount]=%MonsterID;
            %monsterCount++;
         }
         %MonsterID = sqlite.getColumn(%result, "Monster5ID");
         if(%MonsterID){
            %monsterArray[%monsterCount]=%MonsterID;
            %monsterCount++;
         }
         %MonsterID = sqlite.getColumn(%result, "Monster6ID");
         if(%MonsterID){
            %monsterArray[%monsterCount]=%MonsterID;
            %monsterCount++;
         }
         %MonsterID = sqlite.getColumn(%result, "Monster7ID");
         if(%MonsterID){
            %monsterArray[%monsterCount]=%MonsterID;
            %monsterCount++;
         }
   }

   for(%i=0;%i<%monsterCount; %i++){
           $MonsterObject::Monster[%i] = new ScriptObject(){
               class=Monsters;
               MonsterID=%monsterArray[%i];
               Name="";
               Level="";
               ItemDropID="";
               Money="";
               Exp="";
               CriticalRate="";
               DropRate="";
               DataBlock="";

               AttackLetterGrade="";
               AttackGradeMod="";
               DefenseLetterGrade="";
               DefenseGradeMod="";
               MagicAttackLetterGrade="";
               MagicAttackGradeMod="";
               MagicDefenseLetterGrade="";
               MagicDefenseGradeMod="";
               VitalityLetterGrade="";
               VitalityGradeMod="";
               MagicLetterGrade="";
               MagicGradeMod="";
               EvasionLetterGrade="";
               EvasionGradeMod="";
               AccuracyLetterGrade="";
               AccuracyGradeMod="";
               
               CurrentHP="";
               CurrentMP="";
               CurrentKP="";
               
               MaxHP="";
               MaxMP="";
               MaxKP="";
               
               
               Attack="";
               Defense="";
               MagicAttack="";
               MagicDefense="";
               Vitality="";
               Magic="";
               Evasion="";
               Accuracy="";
               
               IsPoisoned=false;
               IsBlind=false;
               IsParalysed=false;
               IsConfused=false;
               IsSleep=false;
               IsSilenced=false;
               IsBlind=false;
               
               
               
               
            Avatar="";
            WaitTimmer=0;
            innerState=0; 
            isDefending=0;
            WaitMod="";//used for status ailments
            AIEnabled=true;
            AIState=$AISTATES::COOLDOWN;
            isBeingTargeted=0;
            AITrait=$AITRAIT::ATTACK_RANDOM;//used for AI Battle
            target="";
            scheduleHandel="";
            ThinkSpeed=500;//can not be 0, in milliseconds
            AttackAnimationTime=0;
            DestinationX=0;//Do not modify
            DestinationY=0;//Do not modify
            Origin=0;//Do not modify
            OriginX=0;//Do not modify
            OriginY=0;//Do not modify
            RunSpeed=1;//Do what you want cant go higher than 1
            AIManualAction=0;
            AIStatePrev=0;
            isAnimationDone=0;
            HaultAction=0;
            LastDis=0;
            
            CastTimmer=0;
            Animations_Standard_Time="";
            Animations_Standard_Name="";
            selectedSpecial=0;
            Animations_Speacials_Time="";
            Animations_Speacials_Name="";
            selectedMagic=0;
            Animations_Magics_Time="";
            Animations_Magics_Name="";
            
            };      
   }
   $MonsterObject::MonsterCount=%monsterCount;
   sqlite.closeDatabase();
   sqlite.delete();
   
   PopulateMonsters();
}

function PopulateMonsters(){
   for(%i=0;%i<$MonsterObject::MonsterCount;%i++){
      $MonsterObject::Monster[%i].LoadMonsterInfo();
      $MonsterObject::Monster[%i].LoadGrades();
      $MonsterObject::Monster[%i].SetupStats();
   }
}
function Monsters::LoadMonsterInfo(%this){
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   %query = "select Name, Level, ItemDropID, Money, Exp, CriticalRate, DropRate, DataBlock from Monsters where MonsterID="@%this.MonsterID@";";
   %result = sqlite.query(%query, 0);
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      %this.Name = sqlite.getColumn(%result, 1);
      %this.Level = sqlite.getColumn(%result, 2);
      %this.ItemDropID = sqlite.getColumn(%result, 3);
      %this.Money = sqlite.getColumn(%result, 4);
      %this.Exp = sqlite.getColumn(%result, 5);
      %this.CriticalRate = sqlite.getColumn(%result, 6);
      %this.DropRate = sqlite.getColumn(%result, 7);
      %this.DataBLock = sqlite.getColumn(%result, 8);
   }
   sqlite.clearResult(%result);
   sqlite.closeDatabase();
   sqlite.delete();
}

function Monsters::LoadGrades(%this){
   %sqlite = new SQLiteObject(sqlite);
   if (%sqlite == 0)
   {
      echo("ERROR: Failed to create SQLiteObject. sqliteTest aborted.");
      return;
   }
   // open database
   if (sqlite.openDatabase("Database.db") == 0)
   {
      echo("ERROR: Failed to open database: " @ %dbname);
      echo("       Ensure that the disk is not full or write protected.  sqliteTest aborted.");
      sqlite.delete();
      return;
   }
   %query = "select Grades.GradeLetter, Grades.GradeMod from MonsterGrades join Grades on MonsterGrades.GradeID=Grades.GradeID join GradeTypes on GradeTypes.GradeTypeID=MonsterGrades.GradeTypeID where MonsterGrades.MonsterID="@%this.MonsterID@";";
   %result = sqlite.query(%query, 0);
   if (%result == 0)
   {
      echo("ERROR: Failed to SELECT from users table.");
   }else{
      %this.AttackLetterGrade = sqlite.getColumn(%result, "GradeLetter");
      %this.AttackGradeMod = sqlite.getColumn(%result, "GradeMod");
      sqlite.nextRow(%result);
      %this.DefenseLetterGrade = sqlite.getColumn(%result, "GradeLetter");
      %this.DefenseGradeMod = sqlite.getColumn(%result, "GradeMod");
      sqlite.nextRow(%result);
      %this.MagicAttackLetterGrade = sqlite.getColumn(%result, "GradeLetter");
      %this.MagicAttackGradeMod = sqlite.getColumn(%result, "GradeMod");
      sqlite.nextRow(%result);
      %this.MagicDefenseLetterGrade = sqlite.getColumn(%result, "GradeLetter");
      %this.MagicDefenseGradeMod = sqlite.getColumn(%result, "GradeMod");
      sqlite.nextRow(%result);
      %this.VitalityLetterGrade = sqlite.getColumn(%result, "GradeLetter");
      %this.VitalityGradeMod = sqlite.getColumn(%result, "GradeMod");
      sqlite.nextRow(%result);
      %this.MagicLetterGrade = sqlite.getColumn(%result, "GradeLetter");
      %this.MagicGradeMod = sqlite.getColumn(%result, "GradeMod");
      sqlite.nextRow(%result);
      %this.EvasionLetterGrade = sqlite.getColumn(%result, "GradeLetter");
      %this.EvasionGradeMod = sqlite.getColumn(%result, "GradeMod");
      sqlite.nextRow(%result);
      %this.AccuracyLetterGrade = sqlite.getColumn(%result, "GradeLetter");
      %this.AccuracyGradeMod= sqlite.getColumn(%result, "GradeMod");
   }
   sqlite.clearResult(%result);
   sqlite.closeDatabase();
   sqlite.delete();
}
 
function Monsters::SetupStats(%this){
   
            %this.Attack=mFloor((((%this.AttackGradeMod)*(%this.Level))/1000)*999);
            %this.Defense=mFloor((((%this.DefenseGradeMod)*(%this.Level))/1000)*999);
            %this.MagicAttack=mFloor((((%this.MagicAttackGradeMod)*(%this.Level))/1000)*999);
            %this.MagicDefense=mFloor((((%this.MagicDefenseGradeMod)*(%this.Level))/1000)*999);
            %this.Vitality=mFloor((((%this.VitalityGradeMod)*(%this.Level))/1000)*999);
            %this.Magic=mFloor((((%this.MagicGradeMod)*(%this.Level))/1000)*999);
            %this.Evasion=mFloor((((%this.EvasionGradeMod)*(%this.Level))/1000)*999);
            %this.Accuracy=mFloor((((%this.AccuracyGradeMod)*(%this.Level))/1000)*999);
                            
            %this.CurrentHP=%this.Vitality*12;
            %this.CurrentMP=%this.Magic*12;
            %this.CurrentKP=%this.Level*12;
            
            %this.MaxHP=%this.Vitality*12;
            %this.MaxMP=%this.Magic*12;
            %this.MaxKP=%this.Level*12;            
}


function Monsters::StartThinking(%this, %obj){
   %obj.AIState=$AISTATES::COOLDOWN;
   %obj.AITrait=$AITRAIT::ATTACK_RANDOM;
   %obj.ThinkSpeed=500;
   %obj.scheduleHandel=%obj.schedule(%obj.ThinkSpeed, "MobAIStateMachine", %obj);
}

function Monsters::MobAIStateMachine(%this, %obj){

 switch(%obj.AIState){
    case $AISTATES::COOLDOWN : 
      //WAIT FOR WAIT TIME AND REACT TO BATTLE AKA DEFEND ACTION TIME
         switch(%obj.innerState){
            case 0 : 
               %obj.WaitTimmer = (1-(%obj.Evasion/(%obj.Level*20)))*10000;
               %obj.innerState=1;
               
            case 1 : 
               %obj.WaitTimmer-=%obj.ThinkSpeed;
               if(%obj.WaitTimmer<=0){
                  %obj.isDefending=false;
                  %obj.AIState=$AISTATES::WAITING_ACTION;
                  %obj.innerState=0;
               }
               if(%obj.isBeingTargeted){
                  %obj.AIStatePrev=$AISTATES::COOLDOWN;
                  %obj.AIState=$AISTATES::DEFEND;
               }
         }
       
    case $AISTATES::WAITING_ACTION : 
      //ENROLL INTO MANUAL MODE IF SET TO MANUAL OR DECIDE NEXT ACTION BASED ON AI TRAIT
      switch(%obj.innerState){
         case 0 :       
         
         if(%obj.AIEnabled){
            switch(%obj.AITrait){
               case $AITRAIT::ATTACK_RANDOM :
                  %obj.target=getTargetPlayer(getRandom(1,getNumberOfLivingPlayers())-1);
                  %obj.innerState=0;
                  %obj.AIState=$AISTATES::ATTACK;
                  
               case $AITRAIT::ATTACK_WEAK :
                  %obj.target=getTargetPlayer(getRandom(1,getNumberOfLivingPlayers())-1);
                  %obj.innerState=0;
                  %obj.AIState=$AISTATES::ATTACK;
                  
               case $AITRAIT::DEFEND_RECOVER :
                  %obj.target=getTargetPlayer(getRandom(1,getNumberOfLivingPlayers())-1);
                  %obj.innerState=0;
                  %obj.AIState=$AISTATES::ATTACK;
                  
               case $AITRAIT::ATTACK_RECOVER :
                  %obj.target=getTargetPlayer(getRandom(1,getNumberOfLivingPlayers())-1);
                  %obj.innerState=0;
                  %obj.AIState=$AISTATES::ATTACK;
                  
               case $AITRAIT::PROTECT_MAGES :
                  %obj.target=getTargetPlayer(getRandom(1,getNumberOfLivingPlayers())-1);
                  %obj.innerState=0;
                  %obj.AIState=$AISTATES::ATTACK;
                  
               case $AITRAIT::POWER_SPELLS_RANDOM :
                  %obj.target=getTargetPlayer(getRandom(1,getNumberOfLivingPlayers())-1);
                  %obj.innerState=0;
                  %obj.AIState=$AISTATES::ATTACK;
                  
               case $AITRAIT::POWER_SPELLS_WEAK :
                  %obj.target=getTargetPlayer(getRandom(1,getNumberOfLivingPlayers())-1);
                  %obj.innerState=0;
                  %obj.AIState=$AISTATES::ATTACK;
                  
               case $AITRAIT::CONSERITIVE_SPELLS_RANDOM :
                  %obj.target=getTargetPlayer(getRandom(1,getNumberOfLivingPlayers())-1);
                  %obj.innerState=0;
                  %obj.AIState=$AISTATES::ATTACK;
                  
               case $AITRAIT::CONSERITIVE_SPELLS_WEAK :
                  %obj.target=getTargetPlayer(getRandom(1,getNumberOfLivingPlayers())-1);
                  %obj.innerState=0;
                  %obj.AIState=$AISTATES::ATTACK;
                  
               case $AITRAIT::BALANCED :
                  %obj.target=getTargetPlayer(getRandom(1,getNumberOfLivingPlayers())-1);
                  %obj.innerState=0;
                  %obj.AIState=$AISTATES::ATTACK;
                  
               case $AITRAIT::DEFENSIVE :
                  %obj.target=getTargetPlayer(getRandom(1,getNumberOfLivingPlayers())-1);
                  %obj.innerState=0;
                  %obj.AIState=$AISTATES::ATTACK;
            }
            %obj.HaultAction=1;
            AttackQueAdd(%obj);
         }            
      }
       
    case $AISTATES::ATTACK : 
      if(%obj.HaultAction){
         %obj.scheduleHandel=%obj.schedule(%obj.ThinkSpeed, "MobAIStateMachine", %obj);
         return;
      }
      switch(%obj.innerState){
         case 0 :
            %obj.Avatar.setMoveDestination(%obj.target.Avatar.getPosition(),true);
            %obj.innerState=1;
              
         case 1:
         
            %obj.Avatar.setMoveDestination(%obj.target.Avatar.getPosition(),true);
            %distance = VectorDist( %obj.target.Avatar.getTransform(),%obj.Avatar.getTransform() );
            
            if(%distance<4){
               cancel(%obj.scheduleHandel);
               
               %obj.Avatar.setActionThread(%obj.AttackAnimation, 
               false,//hold = false,  
               false//fsp = false,   
               );
               %obj.innerState=2;
               %obj.isAnimationDone=0;
            }
            
         case 2 :
            if(true/*%obj.isAnimationDone*/){
               %obj.Target.CurrentHP-=attackDammage(%obj,%obj.Target);
               %obj.innerState=0;
               %obj.AIState=$AISTATES::RETURN_TO_ORGIN;      
            }
            
      }
    
      //ADVANCE TOWARD TARGET WHEN TARGER IN RANGE ATTACK THEN SWITCH TO RETURN TO ORGIN
      
       
    case $AISTATES::ARCANA : 
      //START SPELL CASTING ANIMATION WAIT TILL TIME FINISHED THEN PLAY CAST SPELL ANIMATION AND INVOKE THE PARTICAL CREATION WAIT TILL FINISHED REMOVE PARTICAL THEN RETURN TO ORGIN

      if(%obj.HaultAction){
         %obj.scheduleHandel=%obj.schedule(%obj.ThinkSpeed, "MobAIStateMachine", %obj);
         return;
      }
      switch(%obj.innerState){      
         case 0 :
               %obj.CastTimmer = ((1-(%obj.Magic/(%obj.Level*20)))*(%obj.Animations_Magics_Time[%obj.selectedMagic]));
               %obj.innerState=1;
              
         case 1 :
            %obj.CastTimmer-=%obj.ThinkSpeed/1000;
             if(%obj.CastTimmer<=0){
               %obj.innerState=2;
               %obj.isAnimationDone=0;
               %obj.Avatar.setActionThread(%obj.Animations_Magics_Name[%obj.selectedMagic], 
               false,//hold = false,  
               false//fsp = false,   
               );
            }
            
         case 2 :
            if(%obj.isAnimationDone){
               %obj.innerState=0;
               %obj.AIState=$AISTATES::RETURN_TO_ORGIN;      
            }
            
      }      
       
    case $AISTATES::KOUYOU : 
      //START SPEICAL PREP ANIMATION WAIT TILL TIME FINISHED THEN PLAY SPECIAL ANIMATION AND INVOKE THE PARTICAL CREATION WAIT TILL FINISHED REMOVE PARTICAL THEN RETURN TO ORGIN IF NEEDED
      if(%obj.HaultAction){
         %obj.scheduleHandel=%obj.schedule(%obj.ThinkSpeed, "MobAIStateMachine", %obj);
         return;
      }
      switch(%obj.innerState){
         case 0 :
               %obj.CastTimmer = %obj.Animations_Speacials_Time[%obj.selectedSpecial];
               %obj.innerState=1;
              
         case 1:
            %obj.CastTimmer-=%obj.ThinkSpeed/1000;
             if(%obj.CastTimmer<=0){
               %obj.innerState=2;
               %obj.isAnimationDone=0;
               %obj.Avatar.setActionThread(%obj.Animations_Speacials_Name[%obj.selectedSpecial], 
               false,//hold = false,  
               false//fsp = false,   
               );
            }
            
         case 2 :
            if(%obj.isAnimationDone){
               %obj.innerState=0;
               %obj.AIState=$AISTATES::RETURN_TO_ORGIN;      
            }
      }      
       
    case $AISTATES::ITEM : 
      //TURN TO THE USER IF NOT YOUR SELF PLAY ITEM USE ANIMATION AND INVOKE THE PARTICAL ANIMATION THEN RETURN TO FORWARD POSITION
      if(%obj.HaultAction){
         %obj.scheduleHandel=%obj.schedule(%obj.ThinkSpeed, "MobAIStateMachine", %obj);
         return;
      }
      switch(%obj.innerState){
         case 0 :
               %obj.CastTimmer = %obj.Animations_Standard_Time[$ANIMATIONS::ITEM_USE];
               %obj.innerState=1;
               
         case 1:
            %obj.CastTimmer-=%obj.ThinkSpeed/1000;
             if(%obj.CastTimmer<=0){
               %obj.innerState=2;
               %obj.isAnimationDone=0;
               %obj.Avatar.setActionThread(%obj.Animations_Standard_Name[$ANIMATIONS::ITEM_USE], 
               false,//hold = false,  
               false//fsp = false,   
               );
            }
            
         case 2 :
            if(%obj.isAnimationDone){
               %obj.innerState=0;
               %obj.AIState=$AISTATES::RETURN_TO_ORGIN;      
            }
            
      }      
       
    case $AISTATES::DEFEND : 
      //DEFEND FOR A TURN OR DEFEND DURING REACTION TIME BLOCKING
         if(%obj.HaultAction){
            %obj.scheduleHandel=%obj.schedule(%obj.ThinkSpeed, "MobAIStateMachine", %obj);
            return;
         }
         %obj.isDefending=true;
         %obj.Avatar.setActionThread(%obj.Animations_Standard_Name[$ANIMATIONS::DEFEND], 
               false,//hold = false,  
               false//fsp = false,   
         );
         if(%obj.AIStatePrev==-1){
               %obj.AIState=$AISTATES::RETURN_TO_ORGIN;
         }else{
               %obj.AIState=%obj.AIStatePrev;
               %obj.AIStatePrev=-1;
         }
       
    case $AISTATES::ESCAPE : 
      //PLAY RUNNING ANIMATION START TIMMER THEN CHECK ESCAPE FREQUENCY
         if(%obj.HaultAction){
            %obj.scheduleHandel=%obj.schedule(%obj.ThinkSpeed, "MobAIStateMachine", %obj);
            return;
         }
      switch(%obj.innerState){
         case 0 :
               %obj.CastTimmer = %obj.Animations_Standard_Time[$ANIMATIONS::ESCAPE];
               %obj.Avatar.setActionThread(%obj.Animations_Standard_Name[$ANIMATIONS::ESCAPE], 
               false,//hold = false,  
               false//fsp = false,   
               );
               %obj.innerState=1;
              
         case 1:
            %obj.CastTimmer-=%obj.ThinkSpeed/1000;
             if(%obj.CastTimmer<=0){
               %obj.innerState=2;
               %obj.isAnimationDone=0;
               %obj.Avatar.setActionThread(%obj.Animations_Standard_Name[$ANIMATIONS::RUN], 
               false,//hold = false,  
               false//fsp = false,   
               );
            }
            
         case 2 :
            if(%obj.isAnimationDone){
               %obj.innerState=0;
               %obj.AIState=$AISTATES::SHUTDOWN;      
               END_BATTLE();
            }
            
      }     
       
    case $AISTATES::RETURN_TO_ORGIN : 
      //RETURN TO ORGIN THEN FACE FORWARD AND ENTER COOL DOWN BASED ON LAST ACTION
      
      switch(%obj.innerState){
         case 0 :
               %obj.Avatar.setMoveDestination(%obj.Avatar.orgin,true);
               %obj.innerState=1;
              
         case 1:
         
            %distance = VectorDist( %obj.Avatar.orgin,%obj.Avatar.getTransform() );
            
            if(%distance<4){
               %obj.Avatar.stop();
               %xfrm = %obj.Avatar.getTransform();
               %lx = getword(%xfrm,0);
               %ly = getword(%xfrm,1);
               %lz = getword(%xfrm,2);
               %rz = 3.14159265359;
               %obj.Avatar.setTransform(%lx SPC %ly SPC %lz SPC 0 SPC 0 SPC 1 SPC %rz);
               %obj.innerState=2;
               %obj.isAnimationDone=0;
            }
            
         case 2 :
               %obj.innerState=0;
               %obj.AIState=$AISTATES::COOLDOWN;      
            
      }
       
       
    case $AISTATES::DIE : 
      //EAT IT! THEN ENTER IDLE
      switch(%obj.innerState){
         case 0:
               %obj.innerState=1;
               %obj.isAnimationDone=0;
               %obj.Avatar.setActionThread("death1"/*%obj.Animations_Standard_Name[$ANIMATIONS::DIE]*/, 
               true,//hold = false,  
               false//fsp = false,   
               );
            
         case 1 :
            if(true/*%obj.isAnimationDone*/){
               %obj.isDead=1;
               %obj.innerState=0;
               %obj.AIState=$AISTATES::IDLE;      
            }
      }      
       
    case $AISTATES::REVIVE : 
      //PLAY REVIVE ANIMATION
      switch(%obj.innerState){
         case 0:
               %obj.innerState=1;
               %obj.isAnimationDone=0;
               %obj.Avatar.setActionThread(%obj.Animations_Standard_Name[$ANIMATIONS::DIE], 
               false,//hold = false,  
               false//fsp = false,   
               );
            
         case 1 :
            if(%obj.isAnimationDone){
               %obj.innerState=0;
               %obj.AIState=$AISTATES::RETURN_TO_ORGIN;      
            }
            
      }      
       
    case $AISTATES::IDLE : 
      //DO NOTHING
       
    case $AISTATES::TAKE_DAMMAGE :
      //TAKE DAMMAGE THEN RETURN TO LAST KNOWN EVENT      
      switch(%obj.innerState){
         case 0:
               %obj.innerState=1;
               %obj.isAnimationDone=0;
               %obj.Avatar.setActionThread(%obj.Animations_Standard_Name[$ANIMATIONS::TAKE_DAMMAGE], 
               false,//hold = false,  
               false//fsp = false,   
               );
            
         case 1 :
            if(%obj.isAnimationDone){
               %obj.innerState=0;
               %obj.AIState=$AISTATES::RETURN_TO_ORGIN;      
            }
            
      }      
      
    case $AISTATES::VICTORY :
      //TAKE DAMMAGE THEN RETURN TO LAST KNOWN EVENT      
      switch(%obj.innerState){
         case 0:
               %obj.innerState=1;
               %obj.isAnimationDone=0;
               %obj.Avatar.setActionThread(%obj.Animations_Standard_Name[$ANIMATIONS::VICTORY_STANCE], 
               false,//hold = false,  
               false//fsp = false,   
               );
            
         case 1 :
            
      }      
      
    case $AISTATES::LEVEL :
      //TAKE DAMMAGE THEN RETURN TO LAST KNOWN EVENT      
      switch(%obj.innerState){
         case 0:
               %obj.innerState=1;
               %obj.isAnimationDone=0;
               %obj.Avatar.setActionThread(%obj.Animations_Standard_Name[$ANIMATIONS::LEVEL_UP], 
               false,//hold = false,  
               false//fsp = false,   
               );
            
         case 1 :
            
      }      
      
    case $AISTATES::SHUTDOWN :
      //TAKE DAMMAGE THEN RETURN TO LAST KNOWN EVENT      
      
      return;
      
 }
 %obj.scheduleHandel=%obj.schedule(%obj.ThinkSpeed, "MobAIStateMachine", %obj);
}
