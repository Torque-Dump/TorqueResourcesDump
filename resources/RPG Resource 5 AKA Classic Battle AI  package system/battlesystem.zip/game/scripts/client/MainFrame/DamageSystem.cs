

function attackDammage(%PID, %MID)
{   
   %misper=(100-(%PID.Accuracy/%MID.Evasion)*100);
   %hit = getRandom(0, 100);
   
   if(%misper>60){
      %misper=60;
   }
   if(%misper<0){
      %misper=0;
   }
   if(%hit>%misper)
   {
         %dammage = (%PID.Attack+%PID.Accuracy)*((%PID.Attack/%MID.Defense));
         return 0xFFFFFF&%dammage;
   }
   else
   {
         return 0;
   }
   
}

function arcanaDammage(%PID, %MID, %MagID)
{
         %dammage = (%PID.MagicAttack*%PID.Level*%PID.Magic)*((%PID.MagicAttack/%MID.MagicDefense));
         return 0xFFFFFF&%dammage;
}

function kouyouDammage(%PID, %MID, %KouID)
{
         %attack = (((%PID.Moves*%PID.Attack)*(%PID.Level/10))/10)*2;
         %attackrange= %attack*(1+(%PID.Accuracy/%PID.Attack));
         %calatk= getRandom(%attack, %attackrange);
         %dammage = (%calatk)*((%PID.Attack/%MID.Defense));
         return 0xFFFFFF&%dammage;
}



function itemHP(%PID, %ItemID)
{
         %hp=0xFFFFFF&(%PID.CurrentHP*%ItemID.HP*(%ItemID.Percent)/100);
         return %hp;
}



function itemMP(%PID, %ItemID)
{
         %mp=0xFFFFFF&(%PID.CurrentMP*%ItemID.MP*(%ItemID.Percent)/100);
         return %mp;
}



function itemKP(%PID, %ItemID)
{
         %kp=0xFFFFFF&(%PID.CurrentKP*%ItemID.KP*(%ItemID.Percent)/100);
         return %kp;
}