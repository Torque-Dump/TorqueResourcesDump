// mqv.cpp - written and placed in the public domain by Wei Dai

#include "pch.h"
#include "mqv.h"

NAMESPACE_BEGIN(CryptoPP)

void TestInstantiations_MQV()
{
	MQV mqv;
}

NAMESPACE_END
