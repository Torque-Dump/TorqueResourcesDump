//// Battlelord Authentication
// Main file
// By Signal360 & Phantom139
//
// Started writing: 1st May 2010
// Final Implementation: 10th August 2010

//REDO 1: Implemented a Token Based Authentication System (Was deemed unaccomplishable)
//REDO 2: Implemented a Certificate System (Had vulnerabilities, and was thus removed)
//REDO 3: Implemented a AES (or did we? AES.... nightmare.... no.)
//REDO 4: More certificates, with new additions of private sector
//REDO 5: a new certificate deisgn system, using a public/private sector
//REDO 6: X509 Certificate System with AES Encrypted D Sector * FINAL IMPLEMENTATION *

exec("./connection.cs");
PGDConnection();
exec("./extras.cs");
exec("./registration.cs");
exec("./login.cs");


// Stored D: sha1(decrypted D):encrypted d exponent
// D Key: sha1(password @ sha1(decrypted D))

//functions
function performClickLogin() {
   $Auth::LoginClickMode = "login";
}
function performClickRetrieve() {
   $Auth::LoginClickMode = "retrieve";
   findAuthServer(1);
}
