// Battlelord Authentication
// Login Invocation, Certificate Access
// Written by Phantom139
// Started writing 24th May 2010

function MainMenuGui::OnWake(%this) {
   LogInRadio.performClick();

   //if(isFile("game/client/accounts/prefs.cs")) {
   //   exec("game/client/accounts/prefs.cs");
   //}

   //if($PrefClientLogin::RememberingLogin) {
   //   UsernameEntry.setText($PrefClientLogin::Username);
   //   PasswordEntry.setText($PrefClientLogin::Password);

   //   RememberButton.performClick();
   //}
}

function getAccountList() {
   if(!isFile("game/client/accounts/public.acc")) {
      error("AUTH 001: Missing public.acc file");
      return;
   }
   if(!isFile("game/client/accounts/private.acc")) {
      error("AUTH 002: Missing private.acc file");
      return;
   }
   //
   //Parse each line into an account certificate variable:
   %fileO = new (FileObject)();
   //
   %fileO.openForRead("game/client/accounts/public.acc");
   while(!%fileO.isEof()) {
      %line = %fileO.readLine();
      %username = getField(%line, 0);
      $Auth::Certificate[strlwr(%username), "Public"] = %line;
   }
   %fileO.close();
   //
   %fileO.openForRead("game/client/accounts/private.acc");
   while(!%fileO.isEof()) {
      %lineA = %fileO.readLine();
      %username = getField(%lineA, 0);
      $Auth::Certificate[strlwr(%username), "Private"] = %lineA;
   }
   %fileO.close();

}

function getPublicCertificate(%name) {
   getAccountList();
   if(isSet($Auth::Certificate[strlwr(%name), "Public"])) {
      return $Auth::Certificate[strlwr(%name), "Public"];
   }
   else {
      return "NOT_FOUND";
   }
}

function getPrivateCertificate(%name) {
   getAccountList();
   if(isSet($Auth::Certificate[strlwr(%name), "Private"])) {
      return $Auth::Certificate[strlwr(%name), "Private"];
   }
   else {
      return "NOT_FOUND";
   }
}

//
function performLogin() {
   %sel = $Auth::LoginClickMode;
   if(%sel $= "login") {
      logIn();
   }
   else {
      %connect = PGDConnection();
      %connect.recoverAccount($Authentication::Username, $Authentication::Password);
   }
}

function logIn() {
   // Pull the initial list
   getAccountList();
   //
   %username = $Authentication::Username;
   %password = $Authentication::Password;
   //
   //Attempt to pull the certificates
   %public = getPublicCertificate(%username);
   %private = getPrivateCertificate(%username);
   if(%public $= "NOT_FOUND" || %private $= "NOT_FOUND") {
      MessageBoxOk("Error", "Account not found locally, please retrieve it.");
      return;
   }
   //split the fields we need
   %e = getField(%public, 3);
   %n = getField(%public, 4);
   %d = getField(%private, 1);
   %sig = getField(%public, 5);
   //
   //attempt the login
   %decHash = getSubStr(%d, 0, strstr(%d, ":"));
   %encD = getSubStr(%d, strLen(%decHash) + 1, strLen(%d));
   //
   //Invoke the account decryption here
   %attempt = DecryptAccount(%encD, %decHash, %password);
   if(%attempt !$= "INVALID_PASSWORD") {
      echo("LOGIN SUCCESSFUL");

      //if(RememberButton.getValue() == true) {
      //   $PrefClientLogin::RememberingLogin = true;

      //   $PrefClientLogin::Username = %username;
      //   $PrefClientLogin::Password = %password;
      //}
      //else {
      //   $PrefClientLogin::RememberingLogin = false;

      //   $PrefClientLogin::Username = "";
      //   $PrefClientLogin::Password = "";
      //}
      //export("$PrefClientLogin::*", "game/client/accounts/prefs.cs", false);

      //we hold onto this data for connection to servers
      //This is the old method of doing this, and is not secure
      //I have moved these to C++ in a private data structure where scripts
      //cannot touch it, however, it is still accessable via serverConnection

      //And this is the new way of doing it, storing it in the C++ Data structure
      StoreSuccessfulLogin(%e, %n, %attempt, %sig);   //E, N, D(decrypted)
      // Little script kiddies who call this function directly won't get far.
      //even if they decide to bypass login, once they try to join a server
      //or play in single player, RSA_verify will stop them dead

      //now store our needed fields for gameplay connection
      $ConnStore::username = %username;
      $ConnStore::email = getField(%public, 2);
      $ConnStore::guid = getField(%public, 1);
      $ConnStore::sig = %sig;

      //
      if(!isSet($pref::Player::Name) || $pref::Player::Name $= "Visitor") {
         $pref::Player::Name = $ConnStore::username;
      }

      Auth_LoginDone();
   }
   else {
      MessageBoxOK("Error", "Invalid Username/Password Combo");
   }
}

//Called after a successful login
function Auth_LoginDone() {
   //Gather data into $PublicCert, if we have made it this far, this test SHOULD
   //succeed, in the case it fails, push a error box
   %certificate = getPublicCertificate($Authentication::Username);
   //
   if(%certificate $= "NOT_FOUND") {
      MessageBoxOk("Login Error", "Username field modified during login process. \n If this is a mistake, please contact Phantom139");
      return;
   }
   $PublicCert = %certificate; //keep it stored here for usage in servers
   //
   Canvas.popDialog(MainMenuGui);
   Canvas.pushDialog(MainMenuALGui);
}
