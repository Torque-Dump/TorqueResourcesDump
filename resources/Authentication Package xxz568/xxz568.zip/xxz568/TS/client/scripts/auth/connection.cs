// Battlelord Authentication
// Authentication server communication
// Written by Signal360 and Phantom139
// Started writing 22nd April 2010

//Servers, you can have as many as you want (or have for that manner)
$PGD::Server[1] = ""; //Example: www.google.com -> DO NOT PUT HTTP:// => Insta Crash if you do.
$PGD::Server[2] = "";
$PGD::Server[3] = "";
//Functions (This is handled by the PHP Script)
$PGD::Server::CheckName = 1;
$PGD::Server::Registrar = 2;
$PGD::Server::CertDownload = 3;
$PGD::Server::VerifyServer = 4;
//
//$PGD::List::List = 2;        //This is for my PHP listing server, and has no point to you,
                               //move along please :)


//TCP Object and Functions
function PGDConnection() {
   //Phantom139 (8-11-10): Mutliple connection instances at once is bad, let's prevent
   //that by implementing a connected variable
   if (!isObject(PGDConnection)) {
      new TCPObject("PGDConnection");
   }
   
   return PGDConnection;
}

function PGDConnection::PerformConnect(%this, %host) {
   if($PGD::Server $= "NO_SERVERS") {
      MessageBoxOk("Error", "No Avaliable Servers \n Please Try Again Later");
      hideRegistrationWindow();
      return;
   }
   if($PGDConnection::Connected) {
      error("ERROR: Call to Perform Connect while connection is already made, terminated");
      return "NO_CONNECT";
   }
   %this.connect(%host @ ":80");
   %this.schedule(5000, "disconnect");
}
function PGDConnection::onConnected(%this) {
   $PGDConnection::Connected = true;
   %this.doingSomething = true;
   %this.send(%this.request);
   %this.response = "";
}
function PGDConnection::onConnectFailed( %this ) {
   $PGDConnection::Connected = false;
   %this.response = "CERROR_CONNECTFAILED";
   CloseMessagePopup();
   MessageBoxOK("Connection Error", "Unable to connect to a server \nPlease try again later.");
}
function PGDConnection::onDNSFailed( %this ) {
   $PGDConnection::Connected = false;
   %this.response = "CERROR_DNSFAIL";
   CloseMessagePopup();
   MessageBoxOK("DNS Error", "Your DNS server was unable to resolve a host name \nPlease try again later.");
}
function PGDConnection::onLine(%this, %line) {
   //all of PGD's responses start with the $ line
   if($debugMode) {
      echo(%line);
   }
   if(strstr(%line, "$") != -1) {
      //strip PGD
      %line = strReplace(%line, "$", "");
      %line = strReplace(%line, "PGD", "");
      if(%this.doSingleLineEval) {
         %this.call(%this.onFinish, %line);
      }
      else {
         %this.response = %this.response NL %line;
      }
   }
}

function PGDConnection::onDisconnect(%this) {
   $PGDConnection::Connected = false;
   %this.doingSomething = false;
   if(strstr(%this.response, "CERROR") != -1) {
      CloseMessagePopup();
      messageBoxOk("Connection Error", "Your client failed to connect. \n Error Code:"@%this.response@"");
      return;
   }
   %this.call(%this.onFinish, %this.response);
}

//*****************************************************************************
//Authentication Server Checking, and Verification Processes
//*****************************************************************************
function findAuthServer(%i) {
   if($Auth::PerformLookup) {
      return; //prevent a dual lookup crash
   }
   $Auth::PerformLookup = 1;
   if(isSet($Auth::Address)) {
      return;
   }
   if($PGD::Server !$= "") {
      echo("Halted next lookup on auth.");
      return;
   }
   if(!isSet($PGD::Server[%i])) {
      $PGD::Server = "NO_SERVERS";
      $Auth::Address = "NO_SERVERS";
      return;
   }
   //push a hold message
   schedule(100, 0, "MessagePopup", "AUTH LOOKUP", "Attempting to connect to an auth server, please stanby.");
   //
   %PGD = PGDConnection();
   %location = "/auth/yourprojectname/";
   %reqHead = $PGD::Server::VerifyServer;
   %host = $PGD::Server[%i];
   %seperator = getRandomSeperator(16);
   %header = makeHeader("POST", %location, %host, "Battlelord Client", "Content-Type: multipart/form-data; boundary="@%seperator@"\r\n");

   %dispo = makeDisposition( %seperator, authMode, %reqHead, 1);

   %header = %header @ "Content-Length: " @ strLen(%dispo) @ "\r\n\r\n";

   %PGD.request = %header @ %dispo;
   
   %PGD.server = $PGD::Server[%i];

   %PGD.onFinish = "verifyAuthServer";
   %check = %PGD.PerformConnect(%host);
   if(%check $= "NO_CONNECT") {
      MessageBoxOk("Connection Error", "PGDConnection is currently connected to another point \n Please ensure the current PGDConnection object is disconnected");
      return;
   }
   //Schedule the next check, verify will cancel this if it finds the server
   $Auth::NextLookup = schedule(15000, 0, "findAuthServer", %i++);
}

function PGDConnection::verifyAuthServer(%this, %response) {
   //First, check to see if a response was returned, if it wasn't that means the
   //server was not found, so we will let the next server look it up.
   $Auth::PerformLookup = 0;
   CloseMessagePopup();
   if(isSet(trim(%response))) {
      //we found a server, let's verify it.
      $Auth::Address = %response;
      //IP Address /t Hash
      %ip = getField(%response, 1);
      %Check = getField(%response, 2);
      //
      %pgdIP = sha1(%ip);
      //
      if(%pgdIP !$= %Check) {
         //Wrong!
         $Auth::Address = "";
      }
      else {
         //Matches, kill the next lookup and proceed.
         cancel($Auth::NextLookup);
         //MessageBoxOk("Verified", "Connected to Server: "@$PGD::Server@"");
         $PGD::Server = %this.server;
         $Auth::Address = %ip;
      }
   }
}





























//Server Connection Scripts
function clientCmdrequestClientCert() {
   //echo("Server Wants my cert");
//   $clientClg = "";
//   $serverClg = "";
   //RSA_Verify, then gather E/N/Sig, and transmit it to the server
   //echo("begin RSA verify");
   %FullDetails = $ConnStore::guid@$ConnStore::username;
   GatherAccountDetails(%FullDetails, $ClientKey_E, $ClientKey_N, $ClientKey_S);  //Full Details: whirlpool($guid@$name@)
   //This is the perfect place to use RSA_Verify because without using this function, the
   //client attempting a connection is dead here because it cannot provide accountDetails
   //to the server, thus instantly failing all following tests, not to mention that battlelord
   //is not equipped with "mod" support, thus this cannot be overrided.
   //------
   //the old method I used would have mirrored the tribesNext system.
   //here it would have generated a 64 bit chlg and sent it to the server
   //server would have sent it's own encrypted chlg to test the key with.
   
   //however, it dawned on me that there is pretty much no point in doing so
   //when the server can just call it's own use of RSA verify on your key to confirm
   //the results, thus that is how it will be done from here

   //so, first thing first, send the account details variable in 128 byte pieces
   %maxDetails = %FullDetails @ $AuthenticationDetails;
   $AuthenticationDetails = ""; //clear this field now to save more memory
   for(%i = 0; %i < strlen(%maxDetails); %i+= 128) {
      commandToServer('TransmitAccountDetails', getSubStr(%maxDetails, %i, 128));
   }
   //echo("Sending Signature -> "@ $ConnStore::sig);
   //Inform the server we are done sending by sending our signature for verification
   for(%i = 0; %i < strlen($ConnStore::sig); %i+= 64) {
      commandToServer('TransmitAccountSignature', getSubStr($ConnStore::sig, %i, 64));
   }
   commandToServer('CertificateSent');
   $AuthenticationSignature = "";
   //Wait 2 seconds for verify on the serverside, then ping the server with my auth info
   schedule(2000, 0, "CommandToServer", 'pingAuthInfo', $ConnStore::username TAB $ConnStore::guid TAB $ConnStore::email, $pref::Player::Name);
   //Server connection events proceed from here
}
