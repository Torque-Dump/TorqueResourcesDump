// Battlelord Authentication
// Client Registration
// written by Signal360/Phantom139

// Started writing 1st May 2010

function showRegistrationWindow()
{
   if ($loggedin)
      return;
   findAuthServer(1);
   $Registration::windowOpen = true;
   canvas.pushDialog(AccountCreationWindow);
}

function hideRegistrationWindow()
{
   Canvas.popDialog(AccountCreationWindow);
   Canvas.pushDialog(MainMenuGui);
   $Registration::windowOpen = false;
}

function AccountCreationWindow::onWake(%this)
{
   if (!$Registration::wasRegistering)
   {
       username.setValue("");
       password.setValue("");
       email.setValue("");
       repeatPassword.setValue("");
       accountKey.setValue("");
       accountKey1.setValue("");
       accountKey2.setValue("");
       accountKey3.setValue("");
       accountKey4.setValue("");
       $Registration::FieldsDone = 0;
       $Registration::Username = "";
       $Registration::PasswordRepeated = "";
       $Registration::Email = "";
       $Registration::accountKey = "";
       $Registration::Password = "";
       $Registration::NameErr = "";
   }
   registrationCheckLoop();
}
function verifyRegistration()
{
   %user = $Registration::Username;
   %pass = $Registration::Password;
   %passRepeated = $Registration::PasswordRepeated;
   %emailEntry = $Registration::Email;
   %keyEntry = stripChars($Registration::accountKey, " ");
   
   if (%pass !$= %passRepeated)
      %str = %str NL "Passwords do not match";
   if (!(strLen(%user) >= 4))
      %str = %str NL "Username must be over 4 characters long.";
   if (!(strLen(%pass) >= 8))
      %str = %str NL "Password must be over 8 characters long.";
   if (!(strLen(%keyEntry) == 25))
      %str = %str NL "Account Key must be completed.";
   if (strStr(%emailEntry, "@") == -1 || strStr(%emailEntry, ".") == -1 )
      %str = %str NL "You must enter a valid email.";
   if (isset(%str))
      MessageBoxOK("Invalid Fields", "Please address the problems below:" NL %str);
   else
      MessageBoxYesNo( "Register?", "Register account under" SPC %user @ "?", "BeginRegistrationProcess();", "" );
}

function registrationCheckLoop(%current_username)
{
   %pass = !(strLen(trim($Registration::Password)) > 8);
   %passRepeated = (trim($Registration::PasswordRepeated) !$= $Registration::Password) || ($Registration::Password $= "");
   %emailEntry = StrStr(trim($Registration::Email), "@") == -1 || StrStr(trim($Registration::Email), ".") == -1;
   %keyEntry1 = strLen(accountKey.getValue())  != 5;
   %keyEntry2 = strLen(accountKey1.getValue()) != 5;
   %keyEntry3 = strLen(accountKey2.getValue()) != 5;
   %keyEntry4 = strLen(accountKey3.getValue()) != 5;
   %keyEntry5 = strLen(accountKey4.getValue()) != 5;
   %keyEntry = %keyEntry1 + %keyEntry2 + %keyEntry3 + %keyEntry4 + %keyEntry5;
   if (%pass)
   {
      if (passwordCheck.bitmap !$= "tools/gui/images/iconCancel.png")
      {
         passwordCheck.ToolTip = "Password must be over 8 characters long.";
         passwordCheck.setBitmap("tools/gui/images/iconCancel.png");
      }
   }
   else
   {
      if (passwordCheck.bitmap !$= "tools/gui/images/iconAccept.png")
      {
         passwordCheck.ToolTip = "OK";
         passwordCheck.setBitmap("tools/gui/images/iconAccept.png");
      }
   }
   if (%passRepeated)
   {
      if (PasswordRepCheck.bitmap !$= "tools/gui/images/iconCancel.png")
      {
         PasswordRepCheck.ToolTip = "The passwords do not match";
         PasswordRepCheck.setBitmap("tools/gui/images/iconCancel.png");
      }
   }
   else
   {
      if (PasswordRepCheck.bitmap !$= "tools/gui/images/iconAccept.png")
      {
         PasswordRepCheck.ToolTip = "Passwords match";
         PasswordRepCheck.setBitmap("tools/gui/images/iconAccept.png");
      }
   }
   if (%emailEntry)
   {
      if (emailCheck.bitmap !$= "tools/gui/images/iconCancel.png")
      {
         emailCheck.ToolTip = "Invalid e-mail.";
         emailCheck.setBitmap("tools/gui/images/iconCancel.png");
      }
   }
   else
   {
      if (emailCheck.bitmap !$= "tools/gui/images/iconAccept.png")
      {
         emailCheck.ToolTip = "Valid e-mail";
         emailCheck.setBitmap("tools/gui/images/iconAccept.png");
      }
   }
   $Registration::accountKey = accountKey.getValue()  @
                               accountKey1.getValue() @
                               accountKey2.getValue() @
                               accountKey3.getValue() @
                               accountKey4.getValue();
   if (strLen($Registration::accountKey) == 25)
   {
      if (keyCheckImg.bitmap !$= "tools/gui/images/iconAccept.png")
      {
         keyCheckImg.ToolTip = "OK";
         keyCheckImg.setBitmap("tools/gui/images/iconAccept.png");
      }
   }
   else
   {
      if (keyCheckImg.bitmap !$= "tools/gui/images/iconCancel.png")
      {
         keyCheckImg.ToolTip = "This field is not complete";
         keyCheckImg.setBitmap("tools/gui/images/iconCancel.png");
      }
   }
   %emptyFields = %user + %pass + %passRepeated + %emailEntry + %keyEntry;
   if ( %emptyFields == 0 )
   {
      register.setEnabled(1);
      $Registration::FieldsDone = true;
   }
   else
   {
      register.setEnabled(0);
      $Registration::FieldsDone = false;
   }
   if ($Registration::windowOpen)
      schedule(750, 0, registrationCheckLoop, %user);
}

function beginRegistrationProcess()
{
   messagePopup("Generating key..", "Generating your key...");
   generateRSA2048();
   closeMessagePopup();
   
   messagePopup( "Please Wait", "Checking your requested username...");
   %connection = PGDConnection();
   %connection.checkName( $Registration::Username );
   
   schedule(2500, 0, "finishAccRegister");
}

function finishAccRegister()
{
   if(isSet($Registration::NameErr))
      return;
   CloseMessagePopup();
   messagePopup( "Please Wait", "Registering account...");
   %newConnect = PGDConnection();
   %newConnect.registerWithAuthServer( $Registration::Username, $Registration::Password, $Registration::Email, $Registration::AccountKey );
}

function PGDConnection::checkName( %this, %username )
{
   %location = "/auth/yourprojectname/";
   %reqHead = $PGD::Server::CheckName;
   %host = $PGD::Server;
   %seperator = getRandomSeperator(16);
   %header = makeHeader("POST", %location, %host, "Battlelord Client", "Content-Type: multipart/form-data; boundary="@%seperator@"\r\n");

   %dispo = makeDisposition( %seperator, authMode, %reqHead);
   %dispo = %dispo @ makeDisposition( %seperator, name, %username, 1 );

   %header = %header @ "Content-Length:" SPC strLen(%dispo) @ "\r\n\r\n";

   %this.request = %header @ %dispo;
   
   %this.onFinish = "checkNameDone";
   %check = %this.PerformConnect(%host);
   if(%check $= "NO_CONNECT") {
      MessageBoxOk("Connection Error", "PGDConnection is currently connected to another point \n Please ensure the current PGDConnection object is disconnected");
      return;
   }
}

function PGDConnection::checkNameDone(%this, %response)
{
   closeMessagePopup();
   %response = stripchars(%response, "$\n");
   switch$(%response)
   {
       case "NERR_TAKEN":
          MessageBoxOk("ERROR", "Your requested username has been taken");
       case "NERR_INVLDCHRS":
          MessageBoxOk("ERROR", "Your requested username contains invalid characters");
       case "NERR_TOOSMALL":
          MessageBoxOk("ERROR", "Your requested username is too short");
       case "NERR_TOOLONG":
          MessageBoxOk("ERROR", "Your requested username is too long");
       case "NERR_EMPTY":
          MessageBoxOk("ERROR", "You did not enter a username");
       default:
          MessagePopup( "Please Wait", "Establishing connection to registration server");
          return;
   }
   $Registration::NameErr = %status;
}

//MessageBoxOK("Error", "Sorry, but an error occured. try registering later. (error: " @ %response @ "_NAME)");

function PGDConnection::registerWithAuthServer(%this, %username, %password, %email, %key) {
   %location = "/auth/yourprojectname/";
   %reqHead = $PGD::Server::Registrar;
   %host = $PGD::Server;
   %seperator = getRandomSeperator(16);
   %header = makeHeader("POST", %location, %host, "Battlelord Client", "Content-Type: multipart/form-data; boundary="@%seperator@"\r\n");
   //alright, looks like we've settled with this data, grab out RSA Key
   %public_e = $Account::RSAKey::E;
   %public_n = $Account::RSAKey::N;
   //set up our PGD hash password
   %hashpass = sha1(%username @ %password @ "specialvaluehere"); //what the auth will store
   $Account::Stor_Dec_Hash = sha1($Account::RSAKey::D);
   %aes_key = %password @ $Account::Stor_Dec_Hash; //key is sha1'd when the process begins
   %encrypted = encryptAccountKey($Account::RSAKey::D, %aes_key);
   $Account::RSAKey::D = %encrypted;
   
   //all data recieved, proceed
   %dispo = %dispo @ makeDisposition( %seperator, authMode, %reqHead);
   %dispo = %dispo @ makeDisposition( %seperator, name, %username );
   %dispo = %dispo @ makeDisposition( %seperator, email, %email );
   %dispo = %dispo @ makeDisposition( %seperator, key, sha1(%key) );     //10/19/10- Added a crypto layer to the key interface
   %dispo = %dispo @ makeDisposition( %seperator, privateKey, %encrypted );
   %dispo = %dispo @ makeDisposition( %seperator, publicKey, %public_n );
   %dispo = %dispo @ makeDisposition( %seperator, publicExponent, %public_e );
   %dispo = %dispo @ makeDisposition( %seperator, privDecHash, $Account::Stor_Dec_Hash );
   %dispo = %dispo @ makeDisposition( %seperator, accData, %hashpass, 1 );

   %header = %header @ "Content-Length:" SPC strLen(%dispo) @ "\r\n\r\n";

   %this.request = %header @ %dispo;
   %this.doSingleLineEval = 1;
   
   if ($debuggingAuth)
      echo(%this.request);
   
   %this.onFinish = "checkRegistrationDone";
   %check = %this.PerformConnect(%host);
   if(%check $= "NO_CONNECT") {
      MessageBoxOk("Connection Error", "PGDConnection is currently connected to another point \n Please ensure the current PGDConnection object is disconnected");
      return;
   }
}

function PGDConnection::checkRegistrationDone(%this, %response) {
   closeMessagePopup();
   if ($debuggingAuth)
      echo("checkRegistrationDone says: " @ %response);
   %response = stripchars(%response, "$\n");
   switch$(firstWord(%response)) {
       case "NERR_TAMPER":
          MessageBoxOK("Error", "You have attempted to change your username while registering.");
       case "NO_EMAIL":
          MessageBoxOK("Error", "Your email field is missing.");
       case "BAD_EMAIL":
          MessageBoxOK("Error", "Your email contains invalid characters, or is invalid.");
       case "NO_KEY":
          MessageBoxOK("Error", "Your account key field is empty.");
       case "INVALID_KEY":
          MessageBoxOK("Error", "Your account key field contains invalid characters.");
       case "INTERNAL_ERROR":
          MessageBoxOK("Error", "The server encountered an internal error, please try again later.");
       case "EMAIL_NOT_BOUND":
          MessageBoxOK("Error", "This account key can not be used with your email address.");
       case "SIGN_FAILURE":
          MessageBoxOK("Error", "The server has failed to generate a signature, please contact the game developers ASAP.");
       case "SIGN_ERROR":
          MessageBoxOK("Error", "The server has failed to sign your account certificate.");
       case "CERT":
          %certline = strreplace(%response, "CERT ", "");
          $userField = getField(%certline, 0);
          $guidField = getField(%certline, 1);
          $emailField = getField(%certline, 2);
       case "CERT2":
          %certline = strreplace(%response, "CERT2 ", "");
          $e = getField(%certline, 0);
          $n = getField(%certline, 1);
          $sig = getField(%certline, 2);
       case "CERT3":
          %certline = strreplace(%response, "CERT3 ", "");
          WritePublicCertificate($userField TAB $guidField TAB $emailField TAB $e TAB $n TAB $sig);
          WritePrivateCertificate($userField, $Account::Stor_Dec_Hash, $Account::RSAKey::D);
          $Account::RSAKey::D = ""; // kill the private exponent field now that it's stored
          MessageBoxOK("Success", "Account creation successful, you may now log in.");
   }
}

function PGDConnection::recoverAccount(%this, %username, %password) {
   %public = getPublicCertificate(%username);
   %private = getPrivateCertificate(%username);
   if(%public !$= "NOT_FOUND" && %private !$= "NOT_FOUND") {
      MessageBoxOk("Error", "This account is already stored locally");
      return;
   }
   %location = "/auth/yourprojectname/";
   %reqHead = $PGD::Server::CertDownload;
   %host = $PGD::Server;
   %seperator = getRandomSeperator(16);
   %header = makeHeader("POST", %location, %host, "Battlelord Client", "Content-Type: multipart/form-data; boundary="@%seperator@"\r\n");
   %hashpass = sha1(%username @ %password @ "specialvaluehere"); //what the auth will store
   %UTC = getUTC();
   %time = getSubStr(%UTC, 0, strLen(%UTC) - 3);
   %enc = sha1(%time);
   %result = %enc @ %hashpass;
   //ready to move!
   %dispo = makeDisposition( %seperator, request, $Authentication::Username );
   %dispo = %dispo @ makeDisposition( %seperator, authMode, %reqHead);
   %dispo = %dispo @ makeDisposition( %seperator, hashsend, %result, 1 );

   %header = %header @ "Content-Length:" SPC strLen(%dispo) @ "\r\n\r\n";

   %this.request = %header @ %dispo;
   %this.doSingleLineEval = 1;

   %this.onFinish = "checkRecoverDone";
   %check = %this.PerformConnect(%host);
   if(%check $= "NO_CONNECT") {
      MessageBoxOk("Connection Error", "PGDConnection is currently connected to another point \n Please ensure the current PGDConnection object is disconnected");
      return;
   }
}

function PGDConnection::checkRecoverDone(%this, %response) {
   // remove anything that http would add to the response.
   %response = stripchars(%response, "$\n");
   echo(%response);
   switch$(firstWord(%response)) {
       case "INCORRECT_PASS":
          MessageBoxOK("Error", "You have entered an invalid password for this account.");
       case "NO_SUCH_ACCOUNT":
          MessageBoxOK("Error", "No such account exists on this account server.");
       case "RECVR":
          //ok, recovery is a go
          %certline = strReplace(%response, "RECVR ", "");
          %certline = strReplace(%certline, "[NL]", "\n");
          //Now it is split like so:
          $username = getWord(%certline, 0); //username
          $guid     = getWord(%certline, 1); //guid
          $email    = getWord(%certline, 2); //email
          $e        = getWord(%certline, 3); //e
       case "RECVR2":
          %certline = strReplace(%response, "RECVR2 ", "");
          %certline = strReplace(%certline, "[NL]", "\n");
          $n        = getWord(%certline, 0); //n
          $sig      = getWord(%certline, 1); //sig
          $dhash    = getWord(%certline, 2); //decoded hash
          $d        = getWord(%certline, 3); //d
          //
          %public = $username TAB $guid TAB $email TAB $e TAB $n TAB $sig;
          WritePublicCertificate(%public);
          WritePrivateCertificate($username, $dhash, $d);
          MessageBoxOK("Success", "Your account certificate has been recieved. \n You may now log in");
   }
}

function WritePublicCertificate(%certline)
{
   %userField = getField(%certline, 0);
   %guidField = getField(%certline, 1);
   %emailField = getField(%certline, 2);
   %e = getField(%certline, 3);
   %n = getField(%certline, 4);
   %sig = getField(%certline, 5);
   //
   %fileO = new (FileObject)();
   %fileO.openForAppend("game/client/accounts/public.acc");
   %fileO.writeLine(%userField TAB %guidField TAB %emailField TAB %e TAB %n TAB %sig);
   %fileO.close();
   %fileO.delete();
}

function WritePrivateCertificate(%username, %hash_dec, %private_encrypted_d)
{
   %fileO = new (FileObject)();
   %fileO.openForAppend("game/client/accounts/private.acc");
   %fileO.writeLine(%username TAB %hash_dec @ ":" @ %private_encrypted_d);
   %fileO.close();
   %fileO.delete();
}
