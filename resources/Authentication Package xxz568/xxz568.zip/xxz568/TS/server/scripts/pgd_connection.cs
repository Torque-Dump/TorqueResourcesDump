// Battlelord Armor Divisions
// - Server <-> PGD Communication and Support functions
// -- Written by Signal360 (KeyboardCat)

function isSet(%s)
{
   return (%s !$= "");
}

function getRandomSeperator(%length)
{
   %alphanumeric = "abcdefghijklmnopqrstuvwxyz0123456789";
   for (%i = 0; %i < %length; %i++)
   {
       %index = getRandom(strLen(%alphanumeric));
       %letter= getSubStr(%alphanumeric, %index, 1);
       %UpperC= getRandom(0, 1);
       if (%UpperC)
          %letter = strUpr(%letter);
       else
          %letter = strLwr(%letter);
       %seq = %seq @ %letter;
   }
   return %seq;
}
function makeDisposition(%seperator, %name, %content, %isEnd)
{
   if (%isEnd)
      %dispo = "--" @ %seperator @ "\r\nContent-Disposition: form-data; name=\""@%name@"\"\r\n\r\n"@%content@"\r\n--" @ %seperator @ "--";
   else
      %dispo = "--" @ %seperator @ "\r\nContent-Disposition: form-data; name=\""@%name@"\"\r\n\r\n"@%content@"\r\n";
   return %dispo;
}

function makeHeader(%cmd, %get, %host, %userAgent, %extra)
{
   %header = %cmd SPC %get SPC "HTTP/1.1\r\n" @
                    "Host: "@%host@"\r\n" @
                    "User-Agent: "@%userAgent@"\r\nConnection: close\r\n" @
                    %extra;
   return %header;
}

function PGDConnection()
{
   if (!isObject(PGDConnection))
      new TCPObject("PGDConnection");

   return PGDConnection;
}
PGDConnection();
function PGDConnection::PerformConnect(%this, %host)
{
   %this.connect(%host @ ":80");
   %this.schedule(5000, "disconnect");
}

function PGDConnection::onConnected(%this)
{
   //echo("connected");
   %this.send(%this.request);
   %this.response = "";
}
function PGDConnection::onConnectFailed( %this )
{
   //echo("connection failed");
   %this.response = "SERROR_CONNECTFAILED";
}
function PGDConnection::onDNSFailed( %this )
{
   //echo("dns failed");
   %this.response = "SERROR_DNSFAIL";
}
function PGDConnection::onLine(%this, %line) {
   if(strstr(%line, "$") != -1) {
      //strip PGD
      %line = strReplace(%line, "$", "");
      %this.response = %this.response NL %line;
   }
}

function PGDConnection::onDisconnect(%this) {
   if(isSet(%this.onFinish))
      %this.call(%this.onFinish, %this.response);
}
