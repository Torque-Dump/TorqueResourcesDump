<?php
   function getUTC() {
      return time();
   }
   
   function collapseEscape($str) {
      $exploded = explode($str);
      $out = "";
      for ($i = 0; $i < strlen($str); $i++)
         $out += "\\x" . bin2hex($exploded[$i]);
	
      return $out;
   }
   
   function expandEscape($str) {
      $out = "";
      for ($i = 0; $i < strlen($str); $i++)
         $out += "\\x" . bin2hex($str[$i]);
	
      return $out;
   }   
   
   function hex2bin($data) {
      $len = strlen($data);
      for($i=0;$i<$len;$i+=2) {
         $newdata .= pack("C",hexdec(substr($data,$i,2)));
      }
      return $newdata;
   }

function CA_private() {
   $privateKey = "Paste Private Key Here";
      return $privateKey;
   }  
function CA_public() { 
   $publicKey = "Paste Public Key Here";
      return $publicKey;
   } 
?>
