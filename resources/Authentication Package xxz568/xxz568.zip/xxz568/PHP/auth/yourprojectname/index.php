<?php
   //requires
   require("pgdFunctions.php");
   require("checkName.php");
   require("createGuid.php"); 
   
   include("../../../php/Crypt/RSA.php");  // CHANGE TO YOUR phpseclib RSA.php file
   
   //-- end requires
   $mode = $_POST["authMode"];
   if(!isSet($mode)) {
      die("   
      Going Somewhere? 
      <p> 
      You appear to be trying to access a part of our site that is off limits.
      <p>
      Do hacker redirection here :) -Phantom139.
      ");
   }
   $con = mysql_connect("localhost","DB_USERNAME_HERE", "DB_PASSWORD_HERE") or die("$"."INTERNAL_ERROR\n");
   mysql_select_db("YOUR_ACCOUNT_DATABASE", $con);
   //begin the processes here
   switch($mode) {
      case 1:
         //1: Check name
         $nameToTest = $_POST["name"];
         $cond = checkName($nameToTest);
         if($cond == 0) {
            die("$"."PGD"."$"."NAME_OK");
         }
         else if($cond == 1) {
            die("$"."PGD"."$"."NERR_EMPTY");
         }
         else if($cond == 2) {
            die("$"."PGD"."$"."NERR_TOOSMALL");
         }
         else if($cond == 3) {
            die("$"."PGD"."$"."NERR_TOOLONG");
         }   
         else if($cond == 4) {
            die("$"."PGD"."$"."NERR_INVLDCHRS");
         }  
         else if($cond == 5) {
            die("$"."PGD"."$"."NERR_TAKEN");
         }                          
      case 2:
         //2: Verify Data, Check Key, and Sign Certificate
         //Stage 1: Data verification
         $name = $_POST["name"];
         $cond = checkName($name);
         if($cond != 0) {
            //naughty naughty, no changing fields while the account is being generated!
            die("$"."PGD"."$"."NERR_TAMPER");
         }         
   	 $email = $_POST["email"];
   	 if(!isSet($_POST["email"])) {
            die("$"."PGD"."$"."NO_EMAIL");
         }
         if( strStr($email, "@") == -1 || strStr($email, ".") == -1 ) {
            die("$"."PGD"."$"."BAD_EMAIL");
         }
         $key = $_POST["key"];
         if(!isSet($_POST["key"])) {
            die("$"."PGD"."$"."NO_KEY");
         }
         if(!preg_match("/^[a-zA-Z0-9]+?$/", $key)) {
            die("$"."PGD"."$"."INVALID_KEY");
         }        
         //Stage 2: Key Check (Server Stores PGDHash(Key))
   	 $result2 = mysql_query("SELECT * FROM YOUR_ACCOUNTKEYS_TABLE") or die("$"."INTERNAL_ERROR");
   	 while($row2 = mysql_fetch_array($result2)) {   
            if(strCmp($row2["AccKey"], $key) == 0)  {
               $PurchCode[$key] = $row2["PurchaseCode"];
               $PurchEmail[$key] = $row2["Email"];
            }
         }
         if (strcmp(strtolower($PurchEmail[$key]), strtolower($email)) != 0) {
            mysql_close($con); 
            die("$"."PGD"."$"."EMAIL_NOT_BOUND");
         }
         //ok, all the data looks good, now lets go!
         //Stage 3: Certificate Signing / database adding
         //fields we now have: username ($name), password($hashpass), email($email)
         //key ($key)
         $email = strtolower($email);
         $guid = CreateBLADGUID();                                                                                
         $private = $_POST["privateKey"]; //client encrypts before sending 
         $priv_dec_hash = $_POST["privDecHash"];
         $public = $_POST["publicKey"];
         $exp = $_POST["publicExponent"];
         $accountData = $_POST["accData"]; //sha1(username @ password @ special_key)
         //
         //         
         $FullAccountData = hash('whirlpool', ($guid.$name.$exp.$public)); //what we need
         $rsa = new Crypt_RSA();  
	 $rsa->loadKey(CA_private());

	 $rsa->setSignatureMode(CRYPT_RSA_SIGNATURE_PKCS1);
	 $signature = $rsa->sign($FullAccountData);         
         //openssl_sign($FullAccountData, $signature, CA_private());
         //$ok = openssl_verify($FullAccountData, $signature, CA_public());
         $rsa->loadKey(CA_public());
         $ok = $rsa->verify($FullAccountData, $signature);
         if($ok == 1) {
            $sigFinal = bin2hex($signature);       
            //successful account creation
            //update the database adding the new user's data
         
            $sql="INSERT INTO YOUR_ACCOUNTS_TABLE (guid, E, N, D, D_DEC_HASH, signature, username, email, hashpass)
            VALUES ('$guid', '$exp', '$public', '$private', '$priv_dec_hash', '$sigFinal', '$name', '$email', '$accountData')";
            $result = "DELETE FROM YOUR_ACCOUNTKEYS_TABLE WHERE AccKey='$key' AND Email='$email'";
      
            mysql_query($sql,$con) or die("$".'INTERNAL_ERROR\n');
            mysql_query($result, $con) or die("$".'INTERNAL_ERROR\n');           
            echo "$"."PGD"."$"."CERT ". $name ."\t". $guid ."\t". $email ."\n";
            echo "$"."PGD"."$"."CERT2 ". $exp ."\t". $public ."\t". $sigFinal ."\n"; // complete their public certificate
            echo "$"."PGD"."$"."CERT3 "; //order the client to construct their certificate.         
         }
         else {
            die("$"."PGD"."$"."SIGN_ERROR ".$ok."");
         }
      case 3:
         //3: Account Re-Download (Certificate Lookup)
         $sentHash = $_POST["hashsend"]; //correct hash = sha1(base64(salt)) @ sha1(username @ password @ special_key) <- //what the DB stores
         $utc = time();
         $utc = "$utc";
         $salt = substr($utc, 0, -3);  
         $saltHash = hash('sha1', $salt);

         $result = mysql_query("SELECT * FROM YOUR_ACCOUNTS_TABLE", $con) or die("$"."INTERNAL_ERROR\n");

         while($row = mysql_fetch_array($result))  {
            if(strCmp(strtolower($row["username"]), strtolower($_POST["request"])) == 0) {       
               //ok, this is the account we are looking for
               $storedPassword = $row["hashpass"];
               //tag the UTC to it for a salt against replay attacks
               $check = $saltHash . $storedPassword;
               if(strCmp($sentHash, $check) == 0) {
                  echo "$"."PGD"."$"."RECVR ". $row["username"] ."[NL]". $row["guid"] ."[NL]". $row["email"] ."[NL]". $row["E"] ."\n"; 
                  echo "$"."PGD"."$"."RECVR2 ". $row["N"] ."[NL]". $row["signature"] ."[NL]". $row["D_DEC_HASH"] ."[NL]". $row["D"] ."[NL]";
               }
               else {
                  die("$"."PGD"."$"."INCORRECT_PASS");
               }
            }
         } 
         die("$"."PGD"."$"."NO_SUCH_ACCOUNT");
      case 4:
         //4: Verify Server
         $ip = $_SERVER['SERVER_ADDR'];
         die("$"."PGD". $ip ."\t". hash('sha1', $ip));
   }
?>
