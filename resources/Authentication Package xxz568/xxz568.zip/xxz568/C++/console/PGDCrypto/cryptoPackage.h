/**
cryptoPackage.cpp
Header file for cryptoPP function calls

Phantom Games Development Authentication Package xxz568
Package Version: 1.1, Compiled Feb. 12, 2011
Created By: Robert Clayton Fritzen (Phantom139)
Copyright 2011, Phantom Games Development

Libraries Used In Development: CryptoPP

This library is a slightly modified version of the xxz568 package, suited for public usage of 
GarageGames members for their Torque Game Engine Projects. This library is open only to these members
and may not in any way be used in any other game engine without the concent of Phantom139.

Credit to the security and cryptography functions go to Wei Dai, who created the CryptoPP library, 
Phantom Games Development does not take any credit for these functions, or the provided function examples
used from the CryptoPP Library, all rights and provided licence agreements to those are reserved 
by the CryptoPP Group and their respective authors.

Unauthorized usage of this system is strictly prohibited, and may be met with legal measures. See below for
unauthorized usage:

* Due to high level securtiy protocols (AES, RSA), This system cannot be used in countries to which the 
  United States Of America has embargoed goods to.
* Credit to this system must go to Phantom Games Development
* Credit to the Cryptography functions must go to Wei Dai and the Crypto++ Dev. Group
* Package xxz568 is only allotted for usage in projects of GarageGames based engines, and may not be used
  in any other game engine without concent of Phantom139

**/

// Crypto++ Library
#ifdef _DEBUG
#  pragma comment ( lib, "cryptlibd" )
#else
#  pragma comment ( lib, "cryptlib" )
#endif
//Include CryptoPP headers
#include <modes.h>
#include <base64.h>
#include <aes.h>
#include <filters.h>
#include <rsa.h>
#include <sha.h>
#include <hex.h>
#include <whrlpool.h>
#include <osrng.h>
//End
#include <time.h>
#include <iostream>
#include <strstream>

using namespace CryptoPP;
using namespace std;

#ifndef xxz568_H
#define xxz568_H

class xxz568 {
   public:  
   //--------------------------
   //xxz568 RSA functions
      InvertibleRSAFunction rsaGenerate(int bytes);
	  InvertibleRSAFunction rsaLoad(std::string e, std::string n, std::string d);
	  int rsaSign(InvertibleRSAFunction rsa, std::string toSign, std::string &output);
	  bool rsaVerify(InvertibleRSAFunction rsa, std::string message, std::string signature); //NON CA VERIFY
	  const char * caPublic();
	  bool caVerify(std::string message, std::string signature);
   //--------------------------
   //xxz568 Hashing functions
	  std::string sha1(std::string text);
	  std::string whirlpool(std::string text);
   //--------------------------
   //xxz568 Encryption Functions
	  int AESEncrypt(std::string key, std::string input, std::string &output);
      int AESDecrypt(std::string key, std::string input, std::string &output);
	  int HexEncode(std::string input, std::string &output);
	  int HexDecode(std::string input, std::string &output);
	  int Base64Encode(std::string input, std::string &out);
	  int Base64Decode(std::string input, std::string &out);
	  //RSA Enc/Dec w/ Parameters
	  //NOTE: I may add these at some point as an additional crypto layer to use with
	  //loadKey, but for the time being, these are not implemented, just use rsaSign/rsaVerify
	  //std::string RSAEncrypt(InvertibleRSAFunction rsa, std::string message);
	  //std::string RSADecrypt(InvertibleRSAFunction rsa, std::string message);
   //--------------------------
   //xxz568 Misc Functions
	  std::string IntegerToString(const Integer refs);
      unsigned int getUTC();
	  byte * generateRandLen();
	  char * charsubstr(char *x, int n, int n2);
	  void Base64ToInteger(const char *base64String, Integer &xmlint);
   //--------------------------
   private:

   protected:
};

#endif