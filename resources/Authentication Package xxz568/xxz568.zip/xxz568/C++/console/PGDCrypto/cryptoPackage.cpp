/**
cryptoPackage.cpp
source cryptoPP function calls

Phantom Games Development Authentication Package xxz568
Package Version: 1.1, Compiled Feb. 12, 2011
Created By: Robert Clayton Fritzen (Phantom139)
Copyright 2011, Phantom Games Development

Libraries Used In Development: CryptoPP

This library is a slightly modified version of the xxz568 package, suited for public usage of 
GarageGames members for their Torque Game Engine Projects. This library is open only to these members
and may not in any way be used in any other game engine without the concent of Phantom139.

Credit to the security and cryptography functions go to Wei Dai, who created the CryptoPP library, 
Phantom Games Development does not take any credit for these functions, or the provided function examples
used from the CryptoPP Library, all rights and provided licence agreements to those are reserved 
by the CryptoPP Group and their respective authors.

Unauthorized usage of this system is strictly prohibited, and may be met with legal measures. See below for
unauthorized usage:

* Due to high level securtiy protocols (AES, RSA), This system cannot be used in countries to which the 
  United States Of America has embargoed goods to.
* Credit to this system must go to Phantom Games Development
* Credit to the Cryptography functions must go to Wei Dai and the Crypto++ Dev. Group
* Package xxz568 is only allotted for usage in projects of GarageGames based engines, and may not be used
  in any other game engine without concent of Phantom139

**/

#include <fstream>
#include "cryptoPackage.h"

InvertibleRSAFunction xxz568::rsaGenerate(int bytes) {
   AutoSeededRandomPool rng;
   InvertibleRSAFunction parameters;

   while(parameters.Validate(rng, 3) == false) {
      parameters.GenerateRandomWithKeySize(rng, bytes);
      //parameters.SetPublicExponent(65537);
      RSA::PrivateKey privateKey(parameters);
      RSA::PublicKey publicKey(parameters);
   }

   //bool test = parameters.Validate(rng, 3);
   //cout << "Valid: " << test << endl;

   return parameters;
}

InvertibleRSAFunction xxz568::rsaLoad(std::string e, std::string n, std::string d) {
   InvertibleRSAFunction parameters;
   parameters.Initialize((const Integer)n.c_str(), (const Integer)e.c_str(), (const Integer)d.c_str());
   return parameters;
}

int xxz568::rsaSign(InvertibleRSAFunction rsa, string message, string &output) {
   AutoSeededRandomPool rng;
   RSA::PrivateKey privateKey(rsa);
   std::string holder;

   RSASSA_PKCS1v15_SHA_Signer signer(privateKey);

   StringSource(message, true, 
       new SignerFilter(rng, signer,
           new StringSink(holder)
      ) // SignerFilter
   ); // StringSource

   HexEncode(holder, output);

   return 1;
}

bool xxz568::rsaVerify(InvertibleRSAFunction rsa, std::string message, std::string textSig) {
   
   RSA::PublicKey publicKey(rsa);
   std::string holder;

   try {
      RSASSA_PKCS1v15_SHA_Verifier verifier(publicKey);

      HexDecode(textSig, holder);

      StringSource(message+holder, true,
          new SignatureVerificationFilter(
              verifier, NULL,
              SignatureVerificationFilter::THROW_EXCEPTION
         ) // SignatureVerificationFilter
      ); // StringSource
   }
   catch(std::exception e) {
      return false;
   }

   return true;
}

/**
NOTE NOTE NOTE NOTE NOTE

In order for this library to function properly, you must have an implemented "Certificate Authority".
Phantom Games Development provides a php link for creation of RSA-512 based CA's. In order to use this
library, please paste the given Public Key Hex from the PHP page into the below return statement.
*/
const char * xxz568::caPublic() {
   return "INSERT PUBLIC KEY HEX FROM PHP HERE";
}

std::string xxz568::sha1(std::string text) {
   CryptoPP::SHA1 hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

std::string xxz568::whirlpool(std::string text) {
   CryptoPP::Whirlpool hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

int xxz568::AESEncrypt(std::string key, std::string input, std::string &output) {
   byte keyB[32], ivB[AES::BLOCKSIZE];
   std::string hashKey = sha1(key).substr(0, 32);
   memcpy(keyB, hashKey.c_str(), 32); 
   //
   memcpy(ivB, generateRandLen(), 16);
   //
   std::string hold, final, hexVec, decVec;
   HexEncode((const char *)ivB, hexVec);
   output = hexVec.substr(0, 32);
   //convert output back to binary for usage as the initVector
   HexDecode(output, decVec);
   //store dec Vec in the iv slot
   memcpy(ivB, decVec.c_str(), 16);
   StringSink* sink = new StringSink(hold);
   CBC_Mode<AES>::Encryption aes(keyB, sizeof(keyB), ivB);
   StreamTransformationFilter* aes_enc = new StreamTransformationFilter(aes, sink);
   StringSource cipher(input, true, aes_enc);
   //convert to a hash
   HexEncode(hold, final);
   output += final;
   //
   return 1;
}

int xxz568::AESDecrypt(std::string key, std::string input, std::string &output) {
   std::string bin, store2, init, test;
   HexDecode(input, bin);
   try{
      byte keyB[32], iv[AES::BLOCKSIZE];
      std::string hashKey = sha1(key).substr(0, 32);
      memcpy(keyB, hashKey.c_str(), 32); 
	  //obtain IV
	  init.assign(bin.substr(0, 16));
	  memcpy(iv, init.c_str(), 16);
	  HexEncode(init, test);
	  store2.assign(bin.substr(16, bin.length()));
	  //
      StringSink* sink = new StringSink(output);
      CBC_Mode<AES>::Decryption aes(keyB, sizeof(keyB), iv);
      StreamTransformationFilter* aes_enc = new StreamTransformationFilter(aes, sink);
      StringSource cipher(store2, true, aes_enc);
   }
   catch(CryptoPP::Exception e) {
      cout << e.GetWhat() << endl;
   }
   return 1;
}

int xxz568::HexEncode(std::string input, std::string &output) {
   CryptoPP::StringSource foo(input, true,
	  new CryptoPP::HexEncoder(
         new CryptoPP::StringSink(output), false));
   return 1;
}

int xxz568::HexDecode(std::string input, std::string &output) {
   CryptoPP::StringSource foo(input, true,
	  new CryptoPP::HexDecoder(
         new CryptoPP::StringSink(output)));
   return 1;
}

unsigned int xxz568::getUTC() {
   unsigned int uiTime = static_cast<unsigned int>( time( NULL ) );
   return uiTime;
}

int xxz568::Base64Encode(std::string input, std::string &output) {
   StringSink* sink = new StringSink(output);
   Base64Encoder* base64_enc = new Base64Encoder(sink);
   StringSource source(input, true, base64_enc);
   return 1;
}

int xxz568::Base64Decode(std::string input, std::string &output) {
   StringSink* sink = new StringSink(output);
   Base64Decoder* base64_dec = new Base64Decoder(sink);
   StringSource source(input, true, base64_dec);
   return 1;
}

byte * xxz568::generateRandLen() {
   AutoSeededRandomPool rng;
   byte randLen[16];
   rng.GenerateBlock(randLen, 16);
   //
   return randLen;
}

char * xxz568::charsubstr(char *x, int n, int n2){
   char *p = new char[n2+1]; //This allocates the memory to hold the sub-string.
   //the rest is essentially the same
   for(int i=0; i<=n2; i++) {
      *(p+i) = *(x+i+n); //here x instead of p on the rhs.
   }
   *(p+n2) = '\0';
   return p;
}

std::string xxz568::IntegerToString(const Integer refs) {
   std::ostrstream oss;
   oss << refs;
   oss << std::hex << refs; // use this for hex output
   std::string s(oss.str());
   s = s.substr(0, s.find_first_of("."));
   return s;// output is now in s
}

void xxz568::Base64ToInteger(const char *base64String, Integer &xmlint) {
   StringSource mod_s( base64String, true, new Base64Decoder);
   unsigned long mrs = mod_s.MaxRetrievable();
   char* mod_sstr = new char[mrs];
   mod_s.Get( (unsigned char*)mod_sstr, mrs );
   xmlint = Integer((byte*)mod_sstr, strlen(mod_sstr));
   delete[] mod_sstr;
}

bool xxz568::caVerify(std::string message, std::string signature) {
   std::string dec, fin;
   fin.assign(caPublic());
   fin.append("h");
   Integer rsaPub(fin.c_str()), rsaexp("65537");
   
   std::string holder;

   try {
      RSASSA_PKCS1v15_SHA_Verifier verifier;
      verifier.AccessKey().Initialize(rsaPub, rsaexp);

      HexDecode(signature, holder);

      StringSource(message+holder, true,
          new SignatureVerificationFilter(
              verifier, NULL,
              SignatureVerificationFilter::THROW_EXCEPTION
         ) // SignatureVerificationFilter
      ); // StringSource
   }
   catch(CryptoPP::Exception e) {
     cout << e.GetWhat() << endl;
     cout << e.GetErrorType() << endl;
      return false;
   }

   return true;
}