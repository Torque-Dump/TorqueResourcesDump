Hello fellow GG users, the time has come for you to implement what I have come to know as the most
advanced and powerful method of user authentication out there.

Please don't be afraid of my "scary" notices on the cryptoPackage.cpp/.h files, I only put those there as per say
common implementation of my packages, seriously, feel free to make any changes to those files as you see fit, I 
only ask that you share your fixes with the community to help keep this system nice and secure.

This system, I have dubbed as the xxz568 package, and it's basis is that of RSA Encryption, and the x509 
certificate scheme. This package contains some very high level encryption standards, something that your users
will indeed come to trust with your projects. So, let's get this thing installed.


* ADVANTAGES OF x509 SCHEME:
** No need for a 24/7 account server, players who possess a signed account can simply log in and go.
** Accounts protected by very strong RSA-1024 keys, and AES-256-CBC cipher.
** Quick and secure verification of accounts.
** If your account server goes down at any time, players who already have their certificate can still play

* DISADVANTAGES OF x509 SCHEME:
** a pain in my ass to code xD, but hey, I did the hard part for you :)
** Signed accounts are "always" legal to play on, IE: if you ban someone from your account server, unless
if you add a check for these bans, they can still play.
** Multiple Logins, you can have more than one player on an account at the same time if they both possess
the correct certificate, you'll need to add your own server side check to prevent this.


* REQUIREMENTS:
** A web server, with capable PHP and MySQL functioning to serve as your account server.
** phpseclib library, installed on the web server
** knowledge on editing C++/TS/PHP to change my code where I instruct it to be changed.
** Crypto++ 5.6.1, installed and ready to use with Torque

BE AWARE: you should go through every file I include in this resource, becauase a good deal of it is like:
yourprojectname, specialvaluehere, YOUR_TABLE, ect.. you should be able to pick out what you need to change.

* Compiled and Tested on TGEA 1.8.1

First off, make sure you've installed Crypto++ into Torque, you can see my resource on it here:
http://www.garagegames.com/community/resources/view/20818

Secondly, plug in the given C++ code to your Torque project, I have included the directory scheme for TGEA 1.8.1
T3D users, you may need to adapt the structure just a little bit, and change the header includes, but other than
that, it's not that big of a deal.

Third, open gameConnection.cpp, and implement the following code (adjust headers as necessary) at the bottom 
of the file:

//PGD Auth System Implementation
//GameConnection Handle
#include "Console/PGDCrypto/cryptoPackage.h"
ConsoleMethod(GameConnection, verifyClientSignature, void, 4, 4, "verifys the client signature on the server-side") {
   bool result = object->verifyClientSig(argv[2], argv[3]);
   if(result == true) {
   
   }
   else {
	  Con::printf("Client Disconnected, invalid account signature.");
      object->setDisconnectReason("The server has denied your account certificate");
      object->deleteObject();
   }
}

bool GameConnection::verifyClientSig(const char * signature, const char * details) {
   //local PGD namespace
   xxz568 localPGD;
   //
   std::string toWhrl = details;
   std::string toWhrl_final = toWhrl;
   toWhrl_final = localPGD.whirlpool(toWhrl);
   std::string hexSig;
   hexSig.assign(std::string(signature));
   //
   bool result = localPGD.caVerify(toWhrl_final, hexSig);
   return result;
}

Fourth! add the included torque script files to your project, yes, I know it's a lot of files, but beleive me
all necessary for now.

Fifth, go to the following web page to create your Certificate Authority Key:
http://www.phantomdev.net/certAuthorityCreate.php

And then on your "web Server", add the PHP files included, change the public/private RSA keys in
function CA_public()/CA_private() to match the ones on that web page. Make all necessary changes to the PHP
code to point to their correct databases/tables.

In the C++ code in cryptoPackage.cpp, change the CA_Public note to match the HEX key

Lastly, modify your connection.cs script to point to your web server, and enjoy!
Please post any bugs on GG, or at my website:
www.phantomdev.net

Good luck!