//-----------------------------------------------------------------------------
// Torque 3D
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "platform/platform.h"
#include "sceneGraph/sceneObject.h"

#include "platform/profiler.h"
#include "console/consoleTypes.h"
#include "console/engineAPI.h"
#include "console/simPersistID.h"
#include "sim/netConnection.h"
#include "core/stream/bitStream.h"
#include "sceneGraph/sceneGraph.h"
#include "sceneGraph/sceneTracker.h"
#include "collision/extrudedPolyList.h"
#include "collision/earlyOutPolyList.h"
#include "collision/optimizedPolyList.h"
#include "collision/polyhedron.h"
#include "gfx/bitmap/gBitmap.h"
#include "math/util/frustum.h"
#include "math/mathIO.h"
#include "math/mTransform.h"
#include "T3D/gameBase/gameProcess.h"

IMPLEMENT_CONOBJECT(SceneObject);

ConsoleDocClass( SceneObject,
   "@brief A 3D object.\n\n"
   "SceneObject exists as a foundation for 3D objects in Torque. It provides the "
   "basic functionality for:"
   "<ul><li>A scene graph (in the Zones and Portals sections), allowing efficient "
   "and robust rendering of the game scene.</li>"
   "<li>Various helper functions, including functions to get bounding information "
   "and momentum/velocity.</li>"
   "<li>Collision detection, as well as ray casting.</li>"
   "<li>Lighting. SceneObjects can register lights both at lightmap generation "
   "time, and dynamic lights at runtime (for special effects, such as from flame "
   "or a projectile, or from an explosion).</li>"
   "<li>Manipulating scene objects, for instance varying scale.</li></ul>\n"
   "@ingroup gameObjects\n"
);

const U32 Container::csmNumBins = 16;
const F32 Container::csmBinSize = 64;
const F32 Container::csmTotalBinSize = Container::csmBinSize * Container::csmNumBins;
U32       Container::smCurrSeqKey = 1;
const U32 Container::csmRefPoolBlockSize = 4096;

Signal<void(SceneObject*)> SceneObject::smSceneObjectAdd;
Signal<void(SceneObject*)> SceneObject::smSceneObjectRemove;

// Statics used by buildPolyList methods
AbstractPolyList* sPolyList;
SphereF sBoundingSphere;
Box3F sBoundingBox;

// Statics used by collide methods
ExtrudedPolyList sExtrudedPolyList;
Polyhedron sBoxPolyhedron;

//--------------------------------------------------------------------------
//-------------------------------------- Console callbacks
//

DefineEngineMethod( SceneObject, getTransform, TransformF, (),,
   "Get the object's transform.\n"
   "@return the current transform of the object\n" )
{
   return object->getTransform();
}

DefineEngineMethod( SceneObject, getPosition, Point3F, (),,
   "Get the object's world position.\n"
   "@return the current world position of the object\n" )
{
   return object->getTransform().getPosition();
}

DefineEngineMethod( SceneObject, getEulerRotation, Point3F, (),,
   "Get Euler rotation of object.\n"
   "@return the orientation of the object in the form of rotations around the "
   "X, Y and Z axes in degrees.\n" )
{
   Point3F euler = object->getTransform().toEuler();
   
   // Convert to degrees.
   euler.x = mRadToDeg( euler.x );
   euler.y = mRadToDeg( euler.y );
   euler.z = mRadToDeg( euler.z );
   
   return euler;
}

DefineEngineMethod( SceneObject, getForwardVector, VectorF, (),,
   "Get the direction this object is facing.\n"
   "@return a vector indicating the direction this object is facing.\n"
   "@note This is the object's y axis." )
{
   return object->getTransform().getForwardVector();
}

DefineEngineMethod( SceneObject, getRightVector, VectorF, (),,
   "Get the right vector of the object.\n"
   "@return a vector indicating the right direction of this object."
   "@note This is the object's x axis." )
{
   return object->getTransform().getRightVector();
}

DefineEngineMethod( SceneObject, getUpVector, VectorF, (),,
   "Get the up vector of the object.\n"
   "@return a vector indicating the up direction of this object."
   "@note This is the object's z axis." )
{
   return object->getTransform().getUpVector();
}

DefineEngineMethod( SceneObject, setTransform, void, ( TransformF txfm ),,
   "Set the object's transform (orientation and position)."
   "@param txfm object transform to set" )
{
// PATHSHAPE
   object->PerformUpdatesForChildren(txfm.getMatrix());
// PATHSHAPE END
   if ( !txfm.hasRotation() )
      object->setPosition( txfm.getPosition() );
   else
      object->setTransform( txfm.getMatrix() );
}

DefineEngineMethod( SceneObject, getScale, Point3F, (),,
   "Get the object's scale.\n"
   "@return object scale as a Point3F" )
{
   return object->getScale();
}

DefineEngineMethod( SceneObject, setScale, void, ( Point3F scale ),,
   "Set the object's scale.\n"
   "@param scale object scale to set\n" )
{
   object->setScale( scale );
}

DefineEngineMethod( SceneObject, getWorldBox, Box3F, (),,
   "Get the object's world bounding box.\n"
   "@return six fields, two Point3Fs, containing the min and max points of the "
   "worldbox." )
{
   return object->getWorldBox();
}

DefineEngineMethod( SceneObject, getWorldBoxCenter, Point3F, (),,
   "Get the center of the object's world bounding box.\n"
   "@return the center of the world bounding box for this object." )
{
   Point3F center;
   object->getWorldBox().getCenter( &center );
   return center;
}

DefineEngineMethod( SceneObject, getObjectBox, Box3F, (),,
   "Get the object's bounding box (relative to the object's origin).\n"
   "@return six fields, two Point3Fs, containing the min and max points of the "
   "objectbox." )
{
   return object->getObjBox();
}

DefineEngineMethod( SceneObject, isGlobalBounds, bool, (),,
   "Check if this object has a global bounds set.\n"
   "If global bounds are set to be true, then the object is assumed to have an "
   "infinitely large bounding box for collision and rendering purposes.\n"
   "@return true if the object has a global bounds." )
{
   return object->isGlobalBounds();
}

ConsoleFunctionGroupBegin( Containers,  "Functions for ray casting and spatial queries.\n\n"
                                        "@note These only work server-side.");

DefineEngineFunction( containerBoxEmpty, bool,
   ( U32 mask, Point3F center, F32 xRadius, F32 yRadius, F32 zRadius ), ( -1, -1 ),
   "See if any objects of given types are present in box of given extent.\n\n"
   "@note Extent parameter is last since only one radius is often needed. If "
   "one radius is provided, the yRadius and zRadius are assumed to be the same.\n"
   "@param  mask   Indicates the type of objects we are checking against.\n"
   "@param  center Center of box.\n"
   "@param  xRadius Search radius in the x-axis. See note above.\n"
   "@param  yRadius Search radius in the y-axis. See note above.\n"
   "@param  zRadius Search radius in the z-axis. See note above.\n"
   "@return true if the box is empty, false if any object is found.\n"
   "@ingroup gameObjects")
{
   Point3F extent( xRadius, yRadius, zRadius );
   extent.y = extent.y >= 0 ? extent.y : extent.x;
   extent.z = extent.z >= 0 ? extent.z : extent.x;

   Box3F    B(center - extent, center + extent, true);

   EarlyOutPolyList polyList;
   polyList.mPlaneList.clear();
   polyList.mNormal.set(0,0,0);
   polyList.mPlaneList.setSize(6);
   polyList.mPlaneList[0].set(B.minExtents, VectorF(-1,0,0));
   polyList.mPlaneList[1].set(B.maxExtents, VectorF(0,1,0));
   polyList.mPlaneList[2].set(B.maxExtents, VectorF(1,0,0));
   polyList.mPlaneList[3].set(B.minExtents, VectorF(0,-1,0));
   polyList.mPlaneList[4].set(B.minExtents, VectorF(0,0,-1));
   polyList.mPlaneList[5].set(B.maxExtents, VectorF(0,0,1));

   return ! gServerContainer.buildPolyList(PLC_Collision, B, mask, &polyList);
}

DefineEngineFunction( initContainerRadiusSearch, void, ( Point3F pos, F32 radius, U32 mask ),,
   "Start a search for items within radius of pos, filtering by mask.\n"
   "@param pos Center position for the search\n"
   "@param radius Search radius\n"
   "@param mask Bitmask of object types to include in the search\n"
   "@see containerSearchNext\n" 
   "@ingroup gameObjects")
{
   gServerContainer.initRadiusSearch( pos, radius, mask );
}

DefineEngineFunction( initContainerTypeSearch, void, ( U32 mask ),,
   "Start a search for all items of the types specified by the bitset mask."
   "@param mask Bitmask of object types to include in the search\n"
   "@see containerSearchNext\n" 
   "@ingroup gameObjects")
{
   gServerContainer.initTypeSearch( mask );
}

DefineEngineFunction( containerSearchNext, SceneObject*, (),,
   "Get next item from a search started with initContainerRadiusSearch() or "
   "initContainerTypeSearch()."
   "@return the next object found in the search, or null if no more\n"
   "@tsexample\n"
   "// print the names of all nearby ShapeBase derived objects\n"
   "%position = %obj.getPosition;\n"
   "%radius = 20;\n"
   "%mask = $TypeMasks::ShapeBaseObjectType;\n"
   "initContainerRadiusSearch( %position, %radius, %mask );\n"
   "while ( (%targetObject = containerSearchNext()) != 0 )\n"
   "{\n"
   "   echo( \"Found: \" @ %targetObject.getName() );\n"
   "}\n"
   "@endtsexample\n"
   "@ingroup gameObjects")
{
   return gServerContainer.containerSearchNextObject();
}

DefineEngineFunction( containerSearchCurrDist, F32, (),,
   "Get distance of the center of the current item from the center of the "
   "current initContainerRadiusSearch."
   "@return distance from the center of the current object to the center of "
   "the search\n"
   "@see containerSearchNext\n"
   "@ingroup gameObjects")
{
   return gServerContainer.containerSearchCurrDist();
}

DefineEngineFunction( containerSearchCurrRadiusDist, F32, (),,
   "Get the distance of the closest point of the current item from the center "
   "of the current initContainerRadiusSearch."
   "@return distance from the closest point of the current object to the "
   "center of the search\n"
   "@see containerSearchNext\n" 
   "@ingroup gameObjects")
{
   return gServerContainer.containerSearchCurrRadiusDist();
}

//TODO: make RayInfo an API type
DefineEngineFunction( containerRayCast, const char*,
   ( Point3F start, Point3F end, U32 mask, SceneObject *pExempt ), ( NULL ),
   "Cast a ray from start to end, checking for collision against items matching mask.\n\n"
   "If exempt is specified, then it is temporarily excluded from collision checks (For "
   "instance, you might want to exclude the player if said player was firing a weapon.)\n"
   "@returns A string containing either null, if nothing was struck, or these fields:\n"
   "<ul><li>The ID of the object that was struck.</li>"
   "<li>The x, y, z position that it was struck.</li>"
   "<li>The x, y, z of the normal of the face that was struck.</li></ul>" 
   "@ingroup gameObjects")
{
   if (pExempt)
      pExempt->disableCollision();

   RayInfo rinfo;
   S32 ret = 0;
   if (gServerContainer.castRay(start, end, mask, &rinfo) == true)
      ret = rinfo.object->getId();

   if (pExempt)
      pExempt->enableCollision();

   // add the hit position and normal?
   char *returnBuffer = Con::getReturnBuffer(256);
   if(ret)
   {
      dSprintf(returnBuffer, 256, "%d %g %g %g %g %g %g",
               ret, rinfo.point.x, rinfo.point.y, rinfo.point.z,
               rinfo.normal.x, rinfo.normal.y, rinfo.normal.z);
   }
   else
   {
      returnBuffer[0] = '0';
      returnBuffer[1] = '\0';
   }

   return(returnBuffer);
}

ConsoleFunctionGroupEnd( Containers );

// Utility method for bin insertion
void getBinRange(const F32 min,
                 const F32 max,
                 U32&      minBin,
                 U32&      maxBin)
{
   AssertFatal(max >= min, "Error, bad range! in getBinRange");

   if ((max - min) >= (Container::csmTotalBinSize - Container::csmBinSize))
   {
      F32 minCoord = mFmod(min, Container::csmTotalBinSize);
      if (minCoord < 0.0f) 
      {
         minCoord += Container::csmTotalBinSize;

         // This is truly lame, but it can happen.  There must be a better way to
         //  deal with this.
         if (minCoord == Container::csmTotalBinSize)
            minCoord = Container::csmTotalBinSize - 0.01;
      }

      AssertFatal(minCoord >= 0.0 && minCoord < Container::csmTotalBinSize, "Bad minCoord");

      minBin = U32(minCoord / Container::csmBinSize);
      AssertFatal(minBin < Container::csmNumBins, avar("Error, bad clipping! (%g, %d)", minCoord, minBin));

      maxBin = minBin + (Container::csmNumBins - 1);
      return;
   }
   else 
   {

      F32 minCoord = mFmod(min, Container::csmTotalBinSize);
      
      if (minCoord < 0.0f) 
      {
         minCoord += Container::csmTotalBinSize;

         // This is truly lame, but it can happen.  There must be a better way to
         //  deal with this.
         if (minCoord == Container::csmTotalBinSize)
            minCoord = Container::csmTotalBinSize - 0.01;
      }
      AssertFatal(minCoord >= 0.0 && minCoord < Container::csmTotalBinSize, "Bad minCoord");

      F32 maxCoord = mFmod(max, Container::csmTotalBinSize);
      if (maxCoord < 0.0f) {
         maxCoord += Container::csmTotalBinSize;

         // This is truly lame, but it can happen.  There must be a better way to
         //  deal with this.
         if (maxCoord == Container::csmTotalBinSize)
            maxCoord = Container::csmTotalBinSize - 0.01;
      }
      AssertFatal(maxCoord >= 0.0 && maxCoord < Container::csmTotalBinSize, "Bad maxCoord");

      minBin = U32(minCoord / Container::csmBinSize);
      maxBin = U32(maxCoord / Container::csmBinSize);
      AssertFatal(minBin < Container::csmNumBins, avar("Error, bad clipping(min)! (%g, %d)", maxCoord, minBin));
      AssertFatal(minBin < Container::csmNumBins, avar("Error, bad clipping(max)! (%g, %d)", maxCoord, maxBin));

      // MSVC6 seems to be generating some bad floating point code around
      // here when full optimizations are on.  The min != max test should
      // not be needed, but it clears up the VC issue.
      if (min != max && minCoord > maxCoord)
         maxBin += Container::csmNumBins;

      AssertFatal(maxBin >= minBin, "Error, min should always be less than max!");
   }
}


//--------------------------------------------------------------------------
//-------------------------------------- SceneObject implementation
//
SceneObject::SceneObject()
{
   mContainer = 0;
   mTypeMask = DefaultObjectType;
   mCollisionCount = 0;
   mGlobalBounds = false;

   mObjScale.set(1,1,1);
   mObjToWorld.identity();
   mWorldToObj.identity();

   mObjBox      = Box3F(Point3F(0, 0, 0), Point3F(0, 0, 0));
   mWorldBox    = Box3F(Point3F(0, 0, 0), Point3F(0, 0, 0));
   mWorldSphere = SphereF(Point3F(0, 0, 0), 0);

   mRenderObjToWorld.identity();
   mRenderWorldToObj.identity();
   mRenderWorldBox = Box3F(Point3F(0, 0, 0), Point3F(0, 0, 0));
   mRenderWorldSphere = SphereF(Point3F(0, 0, 0), 0);

   mContainerSeqKey = 0;

   mBinRefHead  = NULL;

   mSceneManager     = NULL;
   mZoneRangeStart   = 0xFFFFFFFF;

   mNumCurrZones = 0;
   mZoneRefHead = NULL;

   mTraversalState = Done;
   mLastState    = NULL;
   mLastStateKey = 0;

   mBinMinX = 0xFFFFFFFF;
   mBinMaxX = 0xFFFFFFFF;
   mBinMinY = 0xFFFFFFFF;
   mBinMaxY = 0xFFFFFFFF;
   mLightPlugin = NULL;

   mMount.object = NULL;
   mMount.link = NULL;
   mMount.list = NULL;
   mMount.node = -1;
   mMount.xfm = MatrixF::Identity;
   mMountPID = NULL;
   
   mSceneObjectLinks = NULL;
   
   mObjectFlags.set( RenderEnabledFlag | SelectionEnabledFlag );
// PATHSHAPE
   // init the scenegraph relationships to indicate no parent, no children, and no siblings
   mGraph.parent = NULL; 
   mGraph.nextSibling = NULL;
   mGraph.firstChild = NULL;
   mGraph.objToParent.identity();
// PATHSHAPE END
}

SceneObject::~SceneObject()
{
   AssertFatal(mZoneRangeStart == 0xFFFFFFFF && mSceneManager == NULL,
               "Error, SceneObject not properly removed from sceneGraph");
   AssertFatal(mZoneRefHead == NULL && mBinRefHead == NULL,
               "Error, still linked in reference lists!");
   AssertFatal( !mSceneObjectLinks,
               "SceneObject::~SceneObject() - object is still linked to SceneTrackers" );

   unlink();   
}

//----------------------------------------------------------------------------
const char* SceneObject::scriptThis()
{
   return Con::getIntArg(getId());
}


//--------------------------------------------------------------------------
void SceneObject::buildConvex(const Box3F&, Convex*)
{
   return;
}

bool SceneObject::buildPolyList(PolyListContext, AbstractPolyList*, const Box3F&, const SphereF&)
{
   return false;
}

bool SceneObject::castRay(const Point3F&, const Point3F&, RayInfo*)
{
   return false;
}

bool SceneObject::castRayRendered(const Point3F &start, const Point3F &end, RayInfo *info)
{
   // By default, all ray checking against the rendered mesh will be passed
   // on to the collision mesh.  This saves having to define both methods
   // for simple objects.
   return castRay(start, end, info);
}

bool SceneObject::collideBox(const Point3F &start, const Point3F &end, RayInfo *info)
{
   const F32 * pStart = (const F32*)start;
   const F32 * pEnd = (const F32*)end;
   const F32 * pMin = (const F32*)mObjBox.minExtents;
   const F32 * pMax = (const F32*)mObjBox.maxExtents;

   F32 maxStartTime = -1;
   F32 minEndTime = 1;
   F32 startTime;
   F32 endTime;

   // used for getting normal
   U32 hitIndex = 0xFFFFFFFF;
   U32 side;

   // walk the axis
   for(U32 i = 0; i < 3; i++)
   {
      //
      if(pStart[i] < pEnd[i])
      {
         if(pEnd[i] < pMin[i] || pStart[i] > pMax[i])
            return(false);

         F32 dist = pEnd[i] - pStart[i];

         startTime = (pStart[i] < pMin[i]) ? (pMin[i] - pStart[i]) / dist : -1;
         endTime = (pEnd[i] > pMax[i]) ? (pMax[i] - pStart[i]) / dist : 1;
         side = 1;
      }
      else
      {
         if(pStart[i] < pMin[i] || pEnd[i] > pMax[i])
            return(false);

         F32 dist = pStart[i] - pEnd[i];
         startTime = (pStart[i] > pMax[i]) ? (pStart[i] - pMax[i]) / dist : -1;
         endTime = (pEnd[i] < pMin[i]) ? (pStart[i] - pMin[i]) / dist : 1;
         side = 0;
      }

      //
      if(startTime > maxStartTime)
      {
         maxStartTime = startTime;
         hitIndex = i * 2 + side;
      }
      if(endTime < minEndTime)
         minEndTime = endTime;
      if(minEndTime < maxStartTime)
         return(false);
   }

   // fail if inside
   if(maxStartTime < 0.f)
      return(false);

   //
   static Point3F boxNormals[] = {
      Point3F( 1, 0, 0),
      Point3F(-1, 0, 0),
      Point3F( 0, 1, 0),
      Point3F( 0,-1, 0),
      Point3F( 0, 0, 1),
      Point3F( 0, 0,-1),
   };

   //
   AssertFatal(hitIndex != 0xFFFFFFFF, "SceneObject::collideBox");
   info->t = maxStartTime;
   info->object = this;
   mObjToWorld.mulV(boxNormals[hitIndex], &info->normal);
   info->material = 0;
   return(true);
}

void SceneObject::disableCollision()
{
   mCollisionCount++;
   AssertFatal(mCollisionCount < 50, "SceneObject::disableCollision called 50 times on the same object. Is this inside a circular loop?" );
}

bool SceneObject::isDisplacable() const
{
   return false;
}

Point3F SceneObject::getMomentum() const
{
   return Point3F(0, 0, 0);
}

void SceneObject::setMomentum(const Point3F&)
{
}


F32 SceneObject::getMass() const
{
   return 1.0;
}


bool SceneObject::displaceObject(const Point3F&)
{
   return false;
}


void SceneObject::enableCollision()
{
   if (mCollisionCount)
      --mCollisionCount;
}

bool SceneObject::onAdd()
{
   if ( !Parent::onAdd() )
      return false;
      
   mWorldToObj = mObjToWorld;
   mWorldToObj.affineInverse();
   resetWorldBox();

   setRenderTransform(mObjToWorld);
   
   resolveMountPID();  

   smSceneObjectAdd.trigger(this);

   return true;
}

void SceneObject::addToScene()
{
   if(isClientObject())
   {
      if (!mContainer)
         gClientContainer.addObject(this);
      if (!mSceneManager)
         gClientSceneGraph->addObjectToScene(this);
   }
   else
   {
      if (!mContainer)
         gServerContainer.addObject(this);
      if (!mSceneManager)
         gServerSceneGraph->addObjectToScene(this);
   }
}

void SceneObject::onRemove()
{
   smSceneObjectRemove.trigger(this);

   unmount();
   plUnlink();

   Parent::onRemove();
// PATHSHAPE
   if ( getParent() != NULL)   attachToParent( NULL);
// PATHSHAPE END
}

void SceneObject::onDeleteNotify( SimObject *obj )
{      
   // We are comparing memory addresses so even if obj really is not a 
   // ProcessObject this cast shouldn't break anything.
   if ( obj == mAfterObject )
      mAfterObject = NULL;

   if ( obj == mMount.object )
      unmount();

   Parent::onDeleteNotify( obj );   
}

void SceneObject::inspectPostApply()
{
   if(isServerObject()) {
      setMaskBits( MountedMask );
   }

   Parent::inspectPostApply();
}

void SceneObject::removeFromScene()
{
   if (mSceneManager != NULL)
      mSceneManager->removeObjectFromScene(this);
   if (getContainer())
      getContainer()->removeObject(this);
}

void SceneObject::setTransform(const MatrixF& mat)
{
   // This test is a bit expensive so turn it off in release.   
#ifdef TORQUE_DEBUG
   //AssertFatal( mat.isAffine(), "SceneObject::setTransform() - Bad transform (non affine)!" );
#endif

   PROFILE_START(SceneObjectSetTransform);
// PATHSHAPE
   PerformUpdatesForChildren(mat);
// PATHSHAPE END
   mObjToWorld = mWorldToObj = mat;
   mWorldToObj.affineInverse();

   resetWorldBox();

   if (mSceneManager != NULL && mNumCurrZones != 0) 
   {
      mSceneManager->zoneRemove(this);
      mSceneManager->zoneInsert(this);
      if (getContainer())
         getContainer()->checkBins(this);
   }

   setRenderTransform(mat);
   PROFILE_END();
}

void SceneObject::setScale( const VectorF &scale )
{
	AssertFatal( !mIsNaN( scale ), "SceneObject::setScale() - The scale is NaN!" );

   // Avoid unnessasary scaling operations.
   if ( mObjScale.equal( scale ) )
      return;

   mObjScale = scale;
   setTransform(MatrixF(mObjToWorld));

   // Make sure that any subclasses of me get a chance to react to the
   // scale being changed.
   onScaleChanged();

   setMaskBits( ScaleMask );
}

void SceneObject::resetWorldBox()
{
   AssertFatal(mObjBox.isValidBox(), "SceneObject::resetWorldBox - Bad object box!");

   mWorldBox = mObjBox;
   mWorldBox.minExtents.convolve(mObjScale);
   mWorldBox.maxExtents.convolve(mObjScale);
   mObjToWorld.mul(mWorldBox);

   AssertFatal(mWorldBox.isValidBox(), "SceneObject::resetWorldBox - Bad world box!");

   // Create mWorldSphere from mWorldBox
   mWorldBox.getCenter(&mWorldSphere.center);
   mWorldSphere.radius = (mWorldBox.maxExtents - mWorldSphere.center).len();

   // Update links.
   
   for( SceneObjectLink* link = mSceneObjectLinks; link != NULL; 
        link = link->getNextLink() )
      link->update();
}

void SceneObject::resetObjectBox()
{
   AssertFatal( mWorldBox.isValidBox(), "SceneObject::resetObjectBox - Bad world box!" );

   mObjBox = mWorldBox;
   mWorldToObj.mul( mObjBox );

   Point3F objScale( mObjScale );
   objScale.setMax( Point3F( (F32)POINT_EPSILON, (F32)POINT_EPSILON, (F32)POINT_EPSILON ) );
   mObjBox.minExtents.convolveInverse( objScale );
   mObjBox.maxExtents.convolveInverse( objScale );

   AssertFatal( mObjBox.isValidBox(), "SceneObject::resetObjectBox - Bad object box!" );

   // Update the mWorldSphere from mWorldBox
   mWorldBox.getCenter( &mWorldSphere.center );
   mWorldSphere.radius = ( mWorldBox.maxExtents - mWorldSphere.center ).len();

   // Update scene managers.
   
   for( SceneObjectLink* link = mSceneObjectLinks; link != NULL; 
        link = link->getNextLink() )
      link->update();
}

void SceneObject::setRenderTransform(const MatrixF& mat)
{
   PROFILE_START(SceneObj_setRenderTransform);
   mRenderObjToWorld = mRenderWorldToObj = mat;
   mRenderWorldToObj.affineInverse();

   AssertFatal(mObjBox.isValidBox(), "Bad object box!");
   resetRenderWorldBox();
   PROFILE_END();
}


void SceneObject::resetRenderWorldBox()
{
   AssertFatal(mObjBox.isValidBox(), "Bad object box!");
   mRenderWorldBox = mObjBox;
   mRenderWorldBox.minExtents.convolve(mObjScale);
   mRenderWorldBox.maxExtents.convolve(mObjScale);
   mRenderObjToWorld.mul(mRenderWorldBox);
// #if defined(__linux__) || defined(__OpenBSD__)
//    if( !mRenderWorldBox.isValidBox() ) {
//       // reset
//       mRenderWorldBox.minExtents.set( 0.0f, 0.0f, 0.0f );
//       mRenderWorldBox.maxExtents.set( 0.0f, 0.0f, 0.0f );
//    }
// #else
   AssertFatal(mRenderWorldBox.isValidBox(), "Bad world box!");
//#endif

   // Create mRenderWorldSphere from mRenderWorldBox
   mRenderWorldBox.getCenter(&mRenderWorldSphere.center);
   mRenderWorldSphere.radius = (mRenderWorldBox.maxExtents - mRenderWorldSphere.center).len();
}


void SceneObject::initPersistFields()
{
   addGroup( "Transform" );

      addProtectedField( "position", TypeMatrixPosition, Offset( mObjToWorld, SceneObject ), &setFieldPosition, &defaultProtectedGetFn, "Object world position." );
      addProtectedField( "rotation", TypeMatrixRotation, Offset( mObjToWorld, SceneObject ), &setFieldRotation, &defaultProtectedGetFn, "Object world orientation." );
      addProtectedField( "scale", TypePoint3F, Offset( mObjScale, SceneObject ), &setFieldScale, &defaultProtectedGetFn, "Object world scale." );

   endGroup( "Transform" );

   addGroup( "Misc" );

      addProtectedField( "isRenderEnabled", TypeBool, Offset( mObjectFlags, SceneObject ),
         &_setRenderEnabled, &_getRenderEnabled,
         "Disables rendering on this instance.\n"
         "@see isRenderable\n" );

      addProtectedField( "isSelectionEnabled", TypeBool, Offset( mObjectFlags, SceneObject ),
         &_setSelectionEnabled, &_getSelectionEnabled,
         "Disables editor selection of this instance.\n"
         "@see isSelectable\n" );

   endGroup( "Misc" );

   addGroup( "Mounting" );

      addField( "mountPID", TypePID, Offset( mMountPID, SceneObject ), "PersistentID of object we are mounted to." );
      addField( "mountNode", TypeS32, Offset( mMount.node, SceneObject ), "Node we are mounted to." );
      addField( "mountPos", TypeMatrixPosition, Offset( mMount.xfm, SceneObject ), "Position we are mounted at ( object space of our mount object )." );
      addField( "mountRot", TypeMatrixRotation, Offset( mMount.xfm, SceneObject ), "Rotation we are mounted at ( object space of our mount object )." );

   endGroup( "Mounting" );

   Parent::initPersistFields();
}

bool SceneObject::setFieldPosition( void *object, const char *index, const char *data )
{
   SceneObject* so = static_cast<SceneObject*>( object );
   if ( so )
   {
      MatrixF txfm( so->getTransform() );
      Con::setData( TypeMatrixPosition, &txfm, 0, 1, &data );
      so->setTransform( txfm );
   }
   return false;
}

bool SceneObject::setFieldRotation( void *object, const char *index, const char *data )
{
   SceneObject* so = static_cast<SceneObject*>( object );
   if ( so )
   {
      MatrixF txfm( so->getTransform() );
      Con::setData( TypeMatrixRotation, &txfm, 0, 1, &data );
      so->setTransform( txfm );
   }
   return false;
}

bool SceneObject::setFieldScale( void *object, const char *index, const char *data )
{
   SceneObject* so = static_cast<SceneObject*>( object );
   if ( so )
   {
      Point3F scale;
      Con::setData( TypePoint3F, &scale, 0, 1, &data );
      so->setScale( scale );
   }
   return false;
}

bool SceneObject::writeField( StringTableEntry fieldName, const char* value )
{
   if( !Parent::writeField( fieldName, value ) )
      return false;
      
   static StringTableEntry sIsRenderEnabled = StringTable->insert( "isRenderEnabled" );
   static StringTableEntry sIsSelectionEnabled = StringTable->insert( "isSelectionEnabled" );
   static StringTableEntry sMountNode = StringTable->insert( "mountNode" );
   static StringTableEntry sMountPos = StringTable->insert( "mountPos" );
   static StringTableEntry sMountRot = StringTable->insert( "mountRot" );
   
   // Don't write flag fields if they are at their default values.
   
   if( fieldName == sIsRenderEnabled && dAtob( value ) )
      return false;
   else if( fieldName == sIsSelectionEnabled && dAtob( value ) )
      return false;
   else if ( mMountPID == NULL && ( fieldName == sMountNode || 
                                    fieldName == sMountPos || 
                                    fieldName == sMountRot ) )
   {
      return false;
   }

      
   return true;
}

bool SceneObject::onSceneAdd(SceneGraph* pGraph)
{
   mSceneManager = pGraph;
   mSceneManager->zoneInsert(this);
   return true;
}

void SceneObject::onSceneRemove()
{
   mSceneManager->zoneRemove(this);
   mSceneManager = NULL;
}

void SceneObject::onScaleChanged()
{
    // Override this function where you need to specially handle something
    // when the size of your object has been changed.
}

bool SceneObject::prepRenderImage(SceneState*, const U32, const U32, const bool)
{
   return false;
}

bool SceneObject::scopeObject(const Point3F&        /*rootPosition*/,
                              const F32             /*rootDistance*/,
                              bool*                 /*zoneScopeState*/)
{
   AssertFatal(false, "Error, this should never be called on a bare (non-zonemanaging) object.  All zone managers must override this function");
   return false;
}


//--------------------------------------------------------------------------
// Render-enabled flag.

bool SceneObject::isRenderEnabled() const
{
   AbstractClassRep *classRep = getClassRep();
   return ( mObjectFlags.test( RenderEnabledFlag ) && classRep->isRenderEnabled() );
}

void SceneObject::setRenderEnabled( bool value )
{
   if( value )
      mObjectFlags.set( RenderEnabledFlag );
   else
      mObjectFlags.clear( RenderEnabledFlag );
      
   setMaskBits( FlagMask );
}

const char* SceneObject::_getRenderEnabled( void* object, const char* data )
{
   SceneObject* obj = reinterpret_cast< SceneObject* >( object );
   if( obj->mObjectFlags.test( RenderEnabledFlag ) )
      return "true";
   else
      return "false";
}

bool SceneObject::_setRenderEnabled( void *object, const char *index, const char *data )
{
   SceneObject* obj = reinterpret_cast< SceneObject* >( object );
   obj->setRenderEnabled( dAtob( data ) );
   return false;
}

//--------------------------------------------------------------------------
// Selection-enabled flag.

bool SceneObject::isSelectionEnabled() const
{
   AbstractClassRep *classRep = getClassRep();
   return ( mObjectFlags.test( SelectionEnabledFlag ) && classRep->isSelectionEnabled() );
}

void SceneObject::setSelectionEnabled( bool value )
{
   if( value )
      mObjectFlags.set( SelectionEnabledFlag );
   else
      mObjectFlags.clear( SelectionEnabledFlag );
      
   // Not synchronized on network so don't set dirty bit.
}

const char* SceneObject::_getSelectionEnabled( void* object, const char* data )
{
   SceneObject* obj = reinterpret_cast< SceneObject* >( object );
   if( obj->mObjectFlags.test( SelectionEnabledFlag ) )
      return "true";
   else
      return "false";
}

bool SceneObject::_setSelectionEnabled( void *object, const char *index, const char *data )
{
   SceneObject* obj = reinterpret_cast< SceneObject* >( object );
   obj->setSelectionEnabled( dAtob( data ) );
   return false;
}

//--------------------------------------------------------------------------

U32 SceneObject::packUpdate( NetConnection* conn, U32 mask, BitStream* stream )
{
   U32 retMask = Parent::packUpdate( conn, mask, stream );

   if ( stream->writeFlag( mask & FlagMask ) )
      stream->writeRangedU32( (U32)mObjectFlags, 0, getObjectFlagMax() );

   if ( mask & MountedMask ) 
   {                  
      if ( mMount.object ) 
      {
         S32 gIndex = conn->getGhostIndex( mMount.object );

         if ( stream->writeFlag( gIndex != -1 ) ) 
         {
            stream->writeFlag( true );
            stream->writeInt( gIndex, NetConnection::GhostIdBitSize );
            if ( stream->writeFlag( mMount.node != -1 ) )
               stream->writeInt( mMount.node, NumMountPointBits );
            mathWrite( *stream, mMount.xfm );
         }
         else
            // Will have to try again later
            retMask |= MountedMask;
      }
      else
         // Unmount if this isn't the initial packet
         if ( stream->writeFlag( !(mask & InitialUpdateMask) ) )
            stream->writeFlag( false );
   }
   else
      stream->writeFlag( false );
   
   return retMask;
}

void SceneObject::unpackUpdate( NetConnection* conn, BitStream* stream )
{
   Parent::unpackUpdate( conn, stream );
   
   // FlagMask
   if ( stream->readFlag() )      
      mObjectFlags = stream->readRangedU32( 0, getObjectFlagMax() );

   // MountedMask
   if ( stream->readFlag() ) 
   {
      if ( stream->readFlag() ) 
      {
         S32 gIndex = stream->readInt( NetConnection::GhostIdBitSize );
         SceneObject* obj = dynamic_cast<SceneObject*>( conn->resolveGhost( gIndex ) );
         S32 node = -1;
         if ( stream->readFlag() ) // node != -1
            node = stream->readInt( NumMountPointBits );
         MatrixF xfm;
         mathRead( *stream, &xfm );
         if ( !obj )
         {
            conn->setLastError( "Invalid packet from server." );
            return;
         }
         obj->mountObject( this, node, xfm );
      }
      else
         unmount();
   }
}

//--------------------------------------------------------------------------

//--------------------------------------------------------------------------
// A quick note about these three functions.  They should only be called
//  on zoneManagers, but since we don't want to force every non-zoneManager
//  to implement them, they assert out instead of being pure virtual.
//
bool SceneObject::getOverlappingZones(SceneObject*, U32*, U32* numZones)
{
   AssertISV(false, "Pure virtual (essentially) function called.  Should never execute this");
   *numZones = 0;
   return false;
}

U32 SceneObject::getPointZone(const Point3F&)
{
   AssertISV(false, "Error, (essentially) pure virtual function called.  Any object this is called on should override this function");
   return 0;
}

void SceneObject::transformModelview(const U32, const MatrixF&, MatrixF*)
{
   AssertISV(false, "Error, (essentially) pure virtual function called.  Any object this is called on should override this function");
}

void SceneObject::transformPosition(const U32, Point3F&)
{
   AssertISV(false, "Error, (essentially) pure virtual function called.  Any object this is called on should override this function");
}

bool SceneObject::computeNewFrustum(const U32, const Frustum&, const F64, const F64,
                                    const RectI&, F64*, RectI&, const bool)
{
   AssertISV(false, "Error, (essentially) pure virtual function called.  Any object this is called on should override this function");
   return false;
}

void SceneObject::openPortal(const U32   /*portalIndex*/,
                             SceneState* /*pCurrState*/,
                             SceneState* /*pParentState*/)
{
   AssertISV(false, "Error, (essentially) pure virtual function called.  Any object this is called on should override this function");
}

void SceneObject::closePortal(const U32   /*portalIndex*/,
                              SceneState* /*pCurrState*/,
                              SceneState* /*pParentState*/)
{
   AssertISV(false, "Error, (essentially) pure virtual function called.  Any object this is called on should override this function");
}

void SceneObject::getWSPortalPlane(const U32 /*portalIndex*/, PlaneF*)
{
   AssertISV(false, "Error, (essentially) pure virtual function called.  Any object this is called on should override this function");
}


//----------------------------------------------------------------------------
//-------------------------------------- Container implementation
//
Container::Link::Link()
{
   next = prev = this;
}

void Container::Link::unlink()
{
   next->prev = prev;
   prev->next = next;
   next = prev = this;
}

void Container::Link::linkAfter(Container::Link* ptr)
{
   next = ptr->next;
   next->prev = this;
   prev = ptr;
   prev->next = this;
}

//----------------------------------------------------------------------------

Container gServerContainer;
Container gClientContainer;

Container::Container()
{
   mEnd.next = mEnd.prev = &mStart;
   mStart.next = mStart.prev = &mEnd;

   if (!sBoxPolyhedron.edgeList.size()) 
   {
      Box3F box;
      box.minExtents.set(-1,-1,-1);
      box.maxExtents.set(+1,+1,+1);
      MatrixF imat(1);
      sBoxPolyhedron.buildBox(imat,box);
   }

   mBinArray = new SceneObjectRef[csmNumBins * csmNumBins];
   for (U32 i = 0; i < csmNumBins; i++) 
   {
      U32 base = i * csmNumBins;
      for (U32 j = 0; j < csmNumBins; j++) 
      {
         mBinArray[base + j].object    = NULL;
         mBinArray[base + j].nextInBin = NULL;
         mBinArray[base + j].prevInBin = NULL;
         mBinArray[base + j].nextInObj = NULL;
      }
   }
   mOverflowBin.object    = NULL;
   mOverflowBin.nextInBin = NULL;
   mOverflowBin.prevInBin = NULL;
   mOverflowBin.nextInObj = NULL;

   VECTOR_SET_ASSOCIATION(mRefPoolBlocks);
   VECTOR_SET_ASSOCIATION(mSearchList);

   mFreeRefPool = NULL;
   addRefPoolBlock();

   cleanupSearchVectors();
}

Container::~Container()
{
   delete[] mBinArray;

   for (U32 i = 0; i < mRefPoolBlocks.size(); i++)
   {
      SceneObjectRef* pool = mRefPoolBlocks[i];
      for (U32 j = 0; j < csmRefPoolBlockSize; j++)
      {
         // Depressingly, this can give weird results if its pointing at bad memory...
         if(pool[j].object != NULL)
            Con::warnf("Error, a %s (%x) isn't properly out of the bins!", pool[j].object->getClassName(), pool[j].object);

         // If you're getting this it means that an object created didn't
         // remove itself from its container before we destroyed the
         // container. Typically you get this behavior from particle
         // emitters, as they try to hang around until all their particles
         // die. In general it's benign, though if you get it for things
         // that aren't particle emitters it can be a bad sign!
      }

      delete [] pool;
   }
   mFreeRefPool = NULL;

   cleanupSearchVectors();
}

bool Container::addObject(SceneObject* obj)
{
   AssertFatal(obj->mContainer == NULL, "Adding already added object.");
   obj->mContainer = this;
   obj->linkAfter(&mStart);

   insertIntoBins(obj);

   // Also insert water and physical zone types into the special vector.
   if ( obj->getTypeMask() & ( WaterObjectType | PhysicalZoneObjectType ) )
      mWaterAndZones.push_back(obj);

   return true;
}

bool Container::removeObject(SceneObject* obj)
{
   AssertFatal(obj->mContainer == this, "Trying to remove from wrong container.");
   removeFromBins(obj);

   // Remove water and physical zone types from the special vector.
   if ( obj->getTypeMask() & ( WaterObjectType | PhysicalZoneObjectType ) )
   {
      Vector<SceneObject*>::iterator iter = find( mWaterAndZones.begin(), mWaterAndZones.end(), obj );
      if ( iter != mWaterAndZones.end() )
         mWaterAndZones.erase_fast(iter);
   }

   obj->mContainer = 0;
   obj->unlink();
   return true;
}

void Container::addRefPoolBlock()
{
   mRefPoolBlocks.push_back(new SceneObjectRef[csmRefPoolBlockSize]);
   for (U32 i = 0; i < csmRefPoolBlockSize-1; i++)
   {
      mRefPoolBlocks.last()[i].object    = NULL;
      mRefPoolBlocks.last()[i].prevInBin = NULL;
      mRefPoolBlocks.last()[i].nextInBin = NULL;
      mRefPoolBlocks.last()[i].nextInObj = &(mRefPoolBlocks.last()[i+1]);
   }
   mRefPoolBlocks.last()[csmRefPoolBlockSize-1].object    = NULL;
   mRefPoolBlocks.last()[csmRefPoolBlockSize-1].prevInBin = NULL;
   mRefPoolBlocks.last()[csmRefPoolBlockSize-1].nextInBin = NULL;
   mRefPoolBlocks.last()[csmRefPoolBlockSize-1].nextInObj = mFreeRefPool;

   mFreeRefPool = &(mRefPoolBlocks.last()[0]);
}


void Container::insertIntoBins(SceneObject* obj)
{
   AssertFatal(obj != NULL, "No object?");
   AssertFatal(obj->mBinRefHead == NULL, "Error, already have a bin chain!");

   // The first thing we do is find which bins are covered in x and y...
   const Box3F* pWBox = &obj->getWorldBox();

   U32 minX, maxX, minY, maxY;
   getBinRange(pWBox->minExtents.x, pWBox->maxExtents.x, minX, maxX);
   getBinRange(pWBox->minExtents.y, pWBox->maxExtents.y, minY, maxY);

   // Store the current regions for later queries
   obj->mBinMinX = minX;
   obj->mBinMaxX = maxX;
   obj->mBinMinY = minY;
   obj->mBinMaxY = maxY;

   // For huge objects, dump them into the overflow bin.  Otherwise, everything
   //  goes into the grid...
   if ((maxX - minX + 1) < csmNumBins || (maxY - minY + 1) < csmNumBins && !obj->isGlobalBounds())
   {
      SceneObjectRef** pCurrInsert = &obj->mBinRefHead;

      for (U32 i = minY; i <= maxY; i++)
      {
         U32 insertY = i % csmNumBins;
         U32 base    = insertY * csmNumBins;
         for (U32 j = minX; j <= maxX; j++)
         {
            U32 insertX = j % csmNumBins;

            SceneObjectRef* ref = allocateObjectRef();

            ref->object    = obj;
            ref->nextInBin = mBinArray[base + insertX].nextInBin;
            ref->prevInBin = &mBinArray[base + insertX];
            ref->nextInObj = NULL;

            if (mBinArray[base + insertX].nextInBin)
               mBinArray[base + insertX].nextInBin->prevInBin = ref;
            mBinArray[base + insertX].nextInBin = ref;

            *pCurrInsert = ref;
            pCurrInsert  = &ref->nextInObj;
         }
      }
   }
   else
   {
      SceneObjectRef* ref = allocateObjectRef();

      ref->object    = obj;
      ref->nextInBin = mOverflowBin.nextInBin;
      ref->prevInBin = &mOverflowBin;
      ref->nextInObj = NULL;

      if (mOverflowBin.nextInBin)
         mOverflowBin.nextInBin->prevInBin = ref;
      mOverflowBin.nextInBin = ref;

      obj->mBinRefHead = ref;
   }
}

void Container::insertIntoBins(SceneObject* obj,
                               U32 minX, U32 maxX,
                               U32 minY, U32 maxY)
{
   PROFILE_START(InsertBins);
   AssertFatal(obj != NULL, "No object?");

   AssertFatal(obj->mBinRefHead == NULL, "Error, already have a bin chain!");
   // Store the current regions for later queries
   obj->mBinMinX = minX;
   obj->mBinMaxX = maxX;
   obj->mBinMinY = minY;
   obj->mBinMaxY = maxY;

   // For huge objects, dump them into the overflow bin.  Otherwise, everything
   //  goes into the grid...
   //
   if ((maxX - minX + 1) < csmNumBins || (maxY - minY + 1) < csmNumBins && !obj->isGlobalBounds())
   {
      SceneObjectRef** pCurrInsert = &obj->mBinRefHead;

      for (U32 i = minY; i <= maxY; i++)
      {
         U32 insertY = i % csmNumBins;
         U32 base    = insertY * csmNumBins;
         for (U32 j = minX; j <= maxX; j++)
         {
            U32 insertX = j % csmNumBins;

            SceneObjectRef* ref = allocateObjectRef();

            ref->object    = obj;
            ref->nextInBin = mBinArray[base + insertX].nextInBin;
            ref->prevInBin = &mBinArray[base + insertX];
            ref->nextInObj = NULL;

            if (mBinArray[base + insertX].nextInBin)
               mBinArray[base + insertX].nextInBin->prevInBin = ref;
            mBinArray[base + insertX].nextInBin = ref;

            *pCurrInsert = ref;
            pCurrInsert  = &ref->nextInObj;
         }
      }
   }
   else
   {
      SceneObjectRef* ref = allocateObjectRef();

      ref->object    = obj;
      ref->nextInBin = mOverflowBin.nextInBin;
      ref->prevInBin = &mOverflowBin;
      ref->nextInObj = NULL;

      if (mOverflowBin.nextInBin)
         mOverflowBin.nextInBin->prevInBin = ref;
      mOverflowBin.nextInBin = ref;
      obj->mBinRefHead = ref;
   }
   PROFILE_END();
}

void Container::removeFromBins(SceneObject* obj)
{
   PROFILE_START(RemoveFromBins);
   AssertFatal(obj != NULL, "No object?");

   SceneObjectRef* chain = obj->mBinRefHead;
   obj->mBinRefHead = NULL;

   while (chain)
   {
      SceneObjectRef* trash = chain;
      chain = chain->nextInObj;

      AssertFatal(trash->prevInBin != NULL, "Error, must have a previous entry in the bin!");
      if (trash->nextInBin)
         trash->nextInBin->prevInBin = trash->prevInBin;
      trash->prevInBin->nextInBin = trash->nextInBin;

      freeObjectRef(trash);
   }
   PROFILE_END();
}


void Container::checkBins(SceneObject* obj)
{
   AssertFatal(obj != NULL, "No object?");

   PROFILE_START(CheckBins);
   if (obj->mBinRefHead == NULL)
   {
      insertIntoBins(obj);
      PROFILE_END();
      return;
   }

   // Otherwise, the object is already in the bins.  Let's see if it has strayed out of
   //  the bins that it's currently in...
   const Box3F* pWBox = &obj->getWorldBox();

   U32 minX, maxX, minY, maxY;
   getBinRange(pWBox->minExtents.x, pWBox->maxExtents.x, minX, maxX);
   getBinRange(pWBox->minExtents.y, pWBox->maxExtents.y, minY, maxY);

   if (obj->mBinMinX != minX || obj->mBinMaxX != maxX ||
       obj->mBinMinY != minY || obj->mBinMaxY != maxY)
   {
      // We have to rebin the object
      removeFromBins(obj);
      insertIntoBins(obj, minX, maxX, minY, maxY);
   }
   PROFILE_END();
}


void Container::findObjects(const Box3F& box, U32 mask, FindCallback callback, void *key)
{
   PROFILE_SCOPE(ContainerFindObjects_Box);

   // If we're searching for just water, just physical zones, or
   // just water and physical zones then use the optimized path.
   if ( mask == WaterObjectType || 
        mask == PhysicalZoneObjectType ||
        mask == (WaterObjectType|PhysicalZoneObjectType) )
   {
      _findWaterAndZoneObjects( box, mask, callback, key );
      return;
   }

   U32 minX, maxX, minY, maxY;
   getBinRange(box.minExtents.x, box.maxExtents.x, minX, maxX);
   getBinRange(box.minExtents.y, box.maxExtents.y, minY, maxY);
   smCurrSeqKey++;
   for (U32 i = minY; i <= maxY; i++)
   {
      U32 insertY = i % csmNumBins;
      U32 base    = insertY * csmNumBins;
      for (U32 j = minX; j <= maxX; j++)
      {
         U32 insertX = j % csmNumBins;

         SceneObjectRef* chain = mBinArray[base + insertX].nextInBin;
         while (chain)
         {
            if (chain->object->getContainerSeqKey() != smCurrSeqKey)
            {
               chain->object->setContainerSeqKey(smCurrSeqKey);

               if ((chain->object->getTypeMask() & mask) != 0 &&
                   chain->object->isCollisionEnabled())
               {
                  if (chain->object->getWorldBox().isOverlapped(box) || chain->object->isGlobalBounds())
                  {
                     (*callback)(chain->object,key);
                  }
               }
            }
            chain = chain->nextInBin;
         }
      }
   }
   SceneObjectRef* chain = mOverflowBin.nextInBin;
   while (chain)
   {
      if (chain->object->getContainerSeqKey() != smCurrSeqKey)
      {
         chain->object->setContainerSeqKey(smCurrSeqKey);

         if ((chain->object->getTypeMask() & mask) != 0 &&
             chain->object->isCollisionEnabled())
         {
            if (chain->object->getWorldBox().isOverlapped(box) || chain->object->isGlobalBounds())
            {
               (*callback)(chain->object,key);
            }
         }
      }
      chain = chain->nextInBin;
   }
}

void Container::findObjects( const Frustum &frustum, U32 mask, FindCallback callback, void *key )
{
   PROFILE_SCOPE(ContainerFindObjects_Frustum);

   Box3F searchBox = frustum.getBounds();

   if (  mask == WaterObjectType || 
         mask == PhysicalZoneObjectType ||
         mask == (WaterObjectType|PhysicalZoneObjectType) )
   {
      _findWaterAndZoneObjects( searchBox, mask, callback, key );
      return;
   }   

   U32 minX, maxX, minY, maxY;
   getBinRange(searchBox.minExtents.x, searchBox.maxExtents.x, minX, maxX);
   getBinRange(searchBox.minExtents.y, searchBox.maxExtents.y, minY, maxY);
   smCurrSeqKey++;

   for (U32 i = minY; i <= maxY; i++)
   {
      U32 insertY = i % csmNumBins;
      U32 base    = insertY * csmNumBins;
      for (U32 j = minX; j <= maxX; j++)
      {
         U32 insertX = j % csmNumBins;

         SceneObjectRef* chain = mBinArray[base + insertX].nextInBin;
         while (chain)
         {
            SceneObject *object = chain->object;

            if (object->getContainerSeqKey() != smCurrSeqKey)
            {
               object->setContainerSeqKey(smCurrSeqKey);

               if ((object->getTypeMask() & mask) != 0 &&
                  object->isCollisionEnabled())
               {
                  const Box3F &worldBox = object->getWorldBox();
                  if ( object->isGlobalBounds() || worldBox.isOverlapped(searchBox) )
                  {
                     if ( frustum.intersects( worldBox ) )
                        (*callback)(chain->object,key);
                  }
               }
            }
            chain = chain->nextInBin;
         }
      }
   }

   SceneObjectRef* chain = mOverflowBin.nextInBin;
   while (chain)
   {
      SceneObject *object = chain->object;

      if (object->getContainerSeqKey() != smCurrSeqKey)
      {
         object->setContainerSeqKey(smCurrSeqKey);

         if ((object->getTypeMask() & mask) != 0 &&
            object->isCollisionEnabled())
         {
            const Box3F &worldBox = object->getWorldBox();

            if ( object->isGlobalBounds() || worldBox.isOverlapped(searchBox) )
            {
               if ( frustum.intersects( worldBox ) )
                  (*callback)(object,key);
            }
         }
      }
      chain = chain->nextInBin;
   }
}

void Container::polyhedronFindObjects(const Polyhedron& polyhedron, U32 mask, FindCallback callback, void *key)
{
   PROFILE_SCOPE(ContainerFindObjects_polyhedron);

   U32 i;
   Box3F box;
   box.minExtents.set(1e9, 1e9, 1e9);
   box.maxExtents.set(-1e9, -1e9, -1e9);
   for (i = 0; i < polyhedron.pointList.size(); i++)
   {
      box.minExtents.setMin(polyhedron.pointList[i]);
      box.maxExtents.setMax(polyhedron.pointList[i]);
   }

   if (  mask == WaterObjectType || 
         mask == PhysicalZoneObjectType ||
         mask == (WaterObjectType|PhysicalZoneObjectType) )
   {
      _findWaterAndZoneObjects( box, mask, callback, key );
      return;
   }

   U32 minX, maxX, minY, maxY;
   getBinRange(box.minExtents.x, box.maxExtents.x, minX, maxX);
   getBinRange(box.minExtents.y, box.maxExtents.y, minY, maxY);
   smCurrSeqKey++;
   for (i = minY; i <= maxY; i++)
   {
      U32 insertY = i % csmNumBins;
      U32 base    = insertY * csmNumBins;
      for (U32 j = minX; j <= maxX; j++)
      {
         U32 insertX = j % csmNumBins;

         SceneObjectRef* chain = mBinArray[base + insertX].nextInBin;
         while (chain)
         {
            if (chain->object->getContainerSeqKey() != smCurrSeqKey)
            {
               chain->object->setContainerSeqKey(smCurrSeqKey);

               if ((chain->object->getTypeMask() & mask) != 0 &&
                   chain->object->isCollisionEnabled())
               {
                  if (chain->object->getWorldBox().isOverlapped(box) || chain->object->isGlobalBounds())
                  {
                     (*callback)(chain->object,key);
                  }
               }
            }
            chain = chain->nextInBin;
         }
      }
   }
   SceneObjectRef* chain = mOverflowBin.nextInBin;
   while (chain)
   {
      if (chain->object->getContainerSeqKey() != smCurrSeqKey)
      {
         chain->object->setContainerSeqKey(smCurrSeqKey);

         if ((chain->object->getTypeMask() & mask) != 0 &&
             chain->object->isCollisionEnabled())
         {
            if (chain->object->getWorldBox().isOverlapped(box) || chain->object->isGlobalBounds())
            {
               (*callback)(chain->object,key);
            }
         }
      }
      chain = chain->nextInBin;
   }
}

void Container::findObjectList( const Box3F& searchBox, U32 mask, Vector<SceneObject*> *outFound )
{
   PROFILE_SCOPE( Container_FindObjectList_Box );

   // TODO: Optimize for water and zones?

   U32 minX, maxX, minY, maxY;
   getBinRange(searchBox.minExtents.x, searchBox.maxExtents.x, minX, maxX);
   getBinRange(searchBox.minExtents.y, searchBox.maxExtents.y, minY, maxY);
   smCurrSeqKey++;

   for (U32 i = minY; i <= maxY; i++)
   {
      U32 insertY = i % csmNumBins;
      U32 base    = insertY * csmNumBins;
      for (U32 j = minX; j <= maxX; j++)
      {
         U32 insertX = j % csmNumBins;

         SceneObjectRef* chain = mBinArray[base + insertX].nextInBin;
         while (chain)
         {
            SceneObject *object = chain->object;

            if (object->getContainerSeqKey() != smCurrSeqKey)
            {
               object->setContainerSeqKey(smCurrSeqKey);

               if ((object->getTypeMask() & mask) != 0 &&
                  object->isCollisionEnabled())
               {
                  const Box3F &worldBox = object->getWorldBox();
                  if ( object->isGlobalBounds() || worldBox.isOverlapped( searchBox ) )
                  {
                     outFound->push_back( object );
                  }
               }
            }
            chain = chain->nextInBin;
         }
      }
   }

   SceneObjectRef* chain = mOverflowBin.nextInBin;
   while (chain)
   {
      SceneObject *object = chain->object;

      if (object->getContainerSeqKey() != smCurrSeqKey)
      {
         object->setContainerSeqKey(smCurrSeqKey);

         if ((object->getTypeMask() & mask) != 0 &&
            object->isCollisionEnabled())
         {
            const Box3F &worldBox = object->getWorldBox();

            if ( object->isGlobalBounds() || worldBox.isOverlapped( searchBox ) )
            {
               outFound->push_back( object );
            }
         }
      }
      chain = chain->nextInBin;
   }
}

void Container::findObjectList( const Frustum &frustum, U32 mask, Vector<SceneObject*> *outFound )
{
   PROFILE_SCOPE( Container_FindObjectList_Frustum );

   // Do a box find first.
   findObjectList( frustum.getBounds(), mask, outFound );

   // Now do the frustum testing.
   for ( U32 i=0; i < outFound->size(); )
   {
      const Box3F &worldBox = (*outFound)[i]->getWorldBox();
      if ( !frustum.intersects( worldBox ) )
         outFound->erase_fast( i );
      else
         i++;
   }
}

void Container::_findWaterAndZoneObjects( U32 mask, FindCallback callback, void *key )
{
   PROFILE_SCOPE( Container_FindWaterAndZoneObjects );

   Vector<SceneObject*>::iterator iter = mWaterAndZones.begin();
   for ( ; iter != mWaterAndZones.end(); iter++ )
   {
      if ( (*iter)->getTypeMask() & mask )
         callback( *iter, key );
   }   
}

void Container::_findWaterAndZoneObjects( const Box3F &box, U32 mask, FindCallback callback, void *key )
{
   PROFILE_SCOPE( Container_FindWaterAndZoneObjects_Box );

   Vector<SceneObject*>::iterator iter = mWaterAndZones.begin();

   for ( ; iter != mWaterAndZones.end(); iter++ )
   {
      SceneObject *pObj = *iter;
      
      if ( pObj->getTypeMask() & mask &&
           ( pObj->isGlobalBounds() || pObj->getWorldBox().isOverlapped(box) ) )
      {
         callback( pObj, key );
      }
   }  
}

//----------------------------------------------------------------------------

bool Container::castRay(const Point3F &start, const Point3F &end, U32 mask, RayInfo* info)
{
   AssertFatal( info->userData == NULL, "Container::castRay - RayInfo->userData cannot be used here!" );

   PROFILE_START(ContainerCastRay);
   bool result = castRayBase(CollisionGeometry, start, end, mask, info);
   PROFILE_END();
   return result;
}

bool Container::castRayRendered(const Point3F &start, const Point3F &end, U32 mask, RayInfo* info)
{
   AssertFatal( info->userData == NULL, "Container::castRayRendered - RayInfo->userData cannot be used here!" );

   PROFILE_START(ContainerCastRayRendered);
   bool result = castRayBase(RenderedGeometry, start, end, mask, info);
   PROFILE_END();
   return result;
}

//----------------------------------------------------------------------------
// DMMNOTE: There are still some optimizations to be done here.  In particular:
//           - After checking the overflow bin, we can potentially shorten the line
//             that we rasterize against the grid if there is a collision with say,
//             the terrain.
//           - The optimal grid size isn't necessarily what we have set here. possibly
//             a resolution of 16 meters would give better results
//           - The line rasterizer is pretty lame.  Unfortunately we can't use a
//             simple bres. here, since we need to check every grid element that the line
//             passes through, which bres does _not_ do for us.  Possibly there's a
//             rasterizer for anti-aliased lines that will serve better than what
//             we have below.
//
bool Container::castRayBase(U32 type, const Point3F &start, const Point3F &end, U32 mask, RayInfo * info)
{
   F32 currentT = 2.0;
   smCurrSeqKey++;

   SceneObjectRef* chain = mOverflowBin.nextInBin;
   while (chain)
   {
      SceneObject* ptr = chain->object;
      if (ptr->getContainerSeqKey() != smCurrSeqKey)
      {
         ptr->setContainerSeqKey(smCurrSeqKey);

         // In the overflow bin, the world box is always going to intersect the line,
         //  so we can omit that test...
         if ((ptr->getTypeMask() & mask) != 0 &&
             ptr->isCollisionEnabled() == true)
         {
            Point3F xformedStart, xformedEnd;
            ptr->mWorldToObj.mulP(start, &xformedStart);
            ptr->mWorldToObj.mulP(end,   &xformedEnd);
            xformedStart.convolveInverse(ptr->mObjScale);
            xformedEnd.convolveInverse(ptr->mObjScale);

            RayInfo ri;
            bool result = false;
            if (type == CollisionGeometry)
               result = ptr->castRay(xformedStart, xformedEnd, &ri);
            else if (type == RenderedGeometry)
               result = ptr->castRayRendered(xformedStart, xformedEnd, &ri);
            if (result)
            {
               if(ri.t < currentT)
               {
                  *info = ri;
                  info->point.interpolate(start, end, info->t);
                  currentT = ri.t;
               }
            }
         }
      }
      chain = chain->nextInBin;
   }

   // These are just for rasterizing the line against the grid.  We want the x coord
   //  of the start to be <= the x coord of the end
   Point3F normalStart, normalEnd;
   if (start.x <= end.x)
   {
      normalStart = start;
      normalEnd   = end;
   }
   else
   {
      normalStart = end;
      normalEnd   = start;
   }

   // Ok, let's scan the grids.  The simplest way to do this will be to scan across in
   //  x, finding the y range for each affected bin...
   U32 minX, maxX;
   U32 minY, maxY;
//if (normalStart.x == normalEnd.x)
//   Con::printf("X start = %g, end = %g", normalStart.x, normalEnd.x);

   getBinRange(normalStart.x, normalEnd.x, minX, maxX);
   getBinRange(getMin(normalStart.y, normalEnd.y),
               getMax(normalStart.y, normalEnd.y), minY, maxY);

//if (normalStart.x == normalEnd.x && minX != maxX)
//   Con::printf("X min = %d, max = %d", minX, maxX);
//if (normalStart.y == normalEnd.y && minY != maxY)
//   Con::printf("Y min = %d, max = %d", minY, maxY);

   // We'll optimize the case that the line is contained in one bin row or column, which
   //  will be quite a few lines.  No sense doing more work than we have to...
   //
   if ((mFabs(normalStart.x - normalEnd.x) < csmTotalBinSize && minX == maxX) ||
       (mFabs(normalStart.y - normalEnd.y) < csmTotalBinSize && minY == maxY))
   {
      U32 count;
      U32 incX, incY;
      if (minX == maxX)
      {
         count = maxY - minY + 1;
         incX  = 0;
         incY  = 1;
      }
      else
      {
         count = maxX - minX + 1;
         incX  = 1;
         incY  = 0;
      }

      U32 x = minX;
      U32 y = minY;
      for (U32 i = 0; i < count; i++)
      {
         U32 checkX = x % csmNumBins;
         U32 checkY = y % csmNumBins;

         SceneObjectRef* chain = mBinArray[(checkY * csmNumBins) + checkX].nextInBin;
         while (chain)
         {
            SceneObject* ptr = chain->object;
            if (ptr->getContainerSeqKey() != smCurrSeqKey)
            {
               ptr->setContainerSeqKey(smCurrSeqKey);

               if ((ptr->getTypeMask() & mask) != 0      &&
                   ptr->isCollisionEnabled() == true)
               {
                  if (ptr->getWorldBox().collideLine(start, end) || chain->object->isGlobalBounds())
                  {
                     Point3F xformedStart, xformedEnd;
                     ptr->mWorldToObj.mulP(start, &xformedStart);
                     ptr->mWorldToObj.mulP(end,   &xformedEnd);
                     xformedStart.convolveInverse(ptr->mObjScale);
                     xformedEnd.convolveInverse(ptr->mObjScale);

                     RayInfo ri;
                     bool result = false;
                     if (type == CollisionGeometry)
                        result = ptr->castRay(xformedStart, xformedEnd, &ri);
                     else if (type == RenderedGeometry)
                        result = ptr->castRayRendered(xformedStart, xformedEnd, &ri);
                     if (result)
                     {
                        if(ri.t < currentT)
                        {
                           *info = ri;
                           info->point.interpolate(start, end, info->t);
                           currentT = ri.t;
						         info->distance = (start - end).len();
                        }
                     }
                  }
               }
            }
            chain = chain->nextInBin;
         }

         x += incX;
         y += incY;
      }
   }
   else
   {
      // Oh well, let's earn our keep.  We know that after the above conditional, we're
      //  going to cross at least one boundary, so that simplifies our job...

      F32 currStartX = normalStart.x;

      AssertFatal(currStartX != normalEnd.x, "This is going to cause problems in Container::castRay");
      while (currStartX != normalEnd.x)
      {
         F32 currEndX   = getMin(currStartX + csmTotalBinSize, normalEnd.x);

         F32 currStartT = (currStartX - normalStart.x) / (normalEnd.x - normalStart.x);
         F32 currEndT   = (currEndX   - normalStart.x) / (normalEnd.x - normalStart.x);

         F32 y1 = normalStart.y + (normalEnd.y - normalStart.y) * currStartT;
         F32 y2 = normalStart.y + (normalEnd.y - normalStart.y) * currEndT;

         U32 subMinX, subMaxX;
         getBinRange(currStartX, currEndX, subMinX, subMaxX);

         F32 subStartX = currStartX;
         F32 subEndX   = currStartX;

         if (currStartX < 0.0f)
            subEndX -= mFmod(subEndX, csmBinSize);
         else
            subEndX += (csmBinSize - mFmod(subEndX, csmBinSize));

         for (U32 currXBin = subMinX; currXBin <= subMaxX; currXBin++)
         {
            U32 checkX = currXBin % csmNumBins;

            F32 subStartT = (subStartX - currStartX) / (currEndX - currStartX);
            F32 subEndT   = getMin(F32((subEndX   - currStartX) / (currEndX - currStartX)), 1.f);

            F32 subY1 = y1 + (y2 - y1) * subStartT;
            F32 subY2 = y1 + (y2 - y1) * subEndT;

            U32 newMinY, newMaxY;
            getBinRange(getMin(subY1, subY2), getMax(subY1, subY2), newMinY, newMaxY);

            for (U32 i = newMinY; i <= newMaxY; i++)
            {
               U32 checkY = i % csmNumBins;

               SceneObjectRef* chain = mBinArray[(checkY * csmNumBins) + checkX].nextInBin;
               while (chain)
               {
                  SceneObject* ptr = chain->object;
                  if (ptr->getContainerSeqKey() != smCurrSeqKey)
                  {
                     ptr->setContainerSeqKey(smCurrSeqKey);

                     if ((ptr->getTypeMask() & mask) != 0      &&
                         ptr->isCollisionEnabled() == true)
                     {
                        if (ptr->getWorldBox().collideLine(start, end))
                        {
                           Point3F xformedStart, xformedEnd;
                           ptr->mWorldToObj.mulP(start, &xformedStart);
                           ptr->mWorldToObj.mulP(end,   &xformedEnd);
                           xformedStart.convolveInverse(ptr->mObjScale);
                           xformedEnd.convolveInverse(ptr->mObjScale);

                           RayInfo ri;
                           ri.generateTexCoord  = info->generateTexCoord;
                           bool result = false;
                           if (type == CollisionGeometry)
                              result = ptr->castRay(xformedStart, xformedEnd, &ri);
                           else if (type == RenderedGeometry)
                              result = ptr->castRayRendered(xformedStart, xformedEnd, &ri);
                           if (result)
                           {
                              if(ri.t < currentT)
                              {
                                 *info = ri;
                                 info->point.interpolate(start, end, info->t);
                                 currentT = ri.t;
								         info->distance = (start - end).len();
                              }
                           }
                        }
                     }
                  }
                  chain = chain->nextInBin;
               }
            }

            subStartX = subEndX;
            subEndX   = getMin(subEndX + csmBinSize, currEndX);
         }

         currStartX = currEndX;
      }
   }

   // Bump the normal into worldspace if appropriate.
   if(currentT != 2)
   {
      PlaneF fakePlane;
      fakePlane.x = info->normal.x;
      fakePlane.y = info->normal.y;
      fakePlane.z = info->normal.z;
      fakePlane.d = 0;

      PlaneF result;
      mTransformPlane(info->object->getTransform(), info->object->getScale(), fakePlane, &result);
      info->normal = result;

      return true;
   }
   else
   {
      // Do nothing and exit...
      return false;
   }
}

// collide with the objects projected object box
bool Container::collideBox(const Point3F &start, const Point3F &end, U32 mask, RayInfo * info)
{
   AssertFatal( info->userData == NULL, "Container::collideBox - RayInfo->userData cannot be used here!" );

   F32 currentT = 2;
   for (Link* itr = mStart.next; itr != &mEnd; itr = itr->next)
   {
      SceneObject* ptr = static_cast<SceneObject*>(itr);
      if (ptr->getTypeMask() & mask && !ptr->mCollisionCount)
      {
         Point3F xformedStart, xformedEnd;
         ptr->mWorldToObj.mulP(start, &xformedStart);
         ptr->mWorldToObj.mulP(end,   &xformedEnd);
         xformedStart.convolveInverse(ptr->mObjScale);
         xformedEnd.convolveInverse(ptr->mObjScale);

         RayInfo ri;
         if(ptr->collideBox(xformedStart, xformedEnd, &ri))
         {
            if(ri.t < currentT)
            {
               *info = ri;
               info->point.interpolate(start, end, info->t);
               currentT = ri.t;
            }
         }
      }
   }
   return currentT != 2;
}

bool SceneObject::containsPoint( const Point3F& point )
{
   return mWorldBox.isContained( point );
}

//----------------------------------------------------------------------------

static void buildCallback(SceneObject* object,void *key)
{
   Container::CallbackInfo* info = reinterpret_cast<Container::CallbackInfo*>(key);
   object->buildPolyList(info->context,info->polyList,info->boundingBox,info->boundingSphere);
}

bool Container::buildPolyList(PolyListContext context, const Box3F &box, U32 mask, AbstractPolyList *polyList)
{
   CallbackInfo info;
   info.context = context;
   info.boundingBox = box;
   info.polyList = polyList;

   // Build bounding sphere
   info.boundingSphere.center = (info.boundingBox.minExtents + info.boundingBox.maxExtents) * 0.5;
   VectorF bv = box.maxExtents - info.boundingSphere.center;
   info.boundingSphere.radius = bv.len();

   sPolyList = polyList;
   findObjects(box,mask,buildCallback,&info);
   return !polyList->isEmpty();
}

void Container::cleanupSearchVectors()
{
   for (U32 i = 0; i < mSearchList.size(); i++)
      delete mSearchList[i];
   mSearchList.clear();
   mCurrSearchPos = -1;
}


static Point3F sgSortReferencePoint;
int QSORT_CALLBACK cmpSearchPointers(const void* inP1, const void* inP2)
{
   SimObjectPtr<SceneObject>** p1 = (SimObjectPtr<SceneObject>**)inP1;
   SimObjectPtr<SceneObject>** p2 = (SimObjectPtr<SceneObject>**)inP2;

   Point3F temp;
   F32 d1, d2;

   if (bool(**p1))
   {
      (**p1)->getWorldBox().getCenter(&temp);
      d1 = (temp - sgSortReferencePoint).len();
   }
   else
   {
      d1 = 0;
   }
   if (bool(**p2))
   {
      (**p2)->getWorldBox().getCenter(&temp);
      d2 = (temp - sgSortReferencePoint).len();
   }
   else
   {
      d2 = 0;
   }

   if (d1 > d2)
      return 1;
   else if (d1 < d2)
      return -1;
   else
      return 0;
}

void Container::initRadiusSearch(const Point3F& searchPoint,
                                 const F32      searchRadius,
                                 const U32      searchMask)
{
   AssertFatal(this == &gServerContainer, "Abort.  Searches only allowed on server container");
   cleanupSearchVectors();

   mSearchReferencePoint = searchPoint;

   Box3F queryBox(searchPoint, searchPoint);
   queryBox.minExtents -= Point3F(searchRadius, searchRadius, searchRadius);
   queryBox.maxExtents += Point3F(searchRadius, searchRadius, searchRadius);

   SimpleQueryList queryList;
   findObjects(queryBox, searchMask, SimpleQueryList::insertionCallback, &queryList);

   F32 radiusSquared = searchRadius * searchRadius;

   const F32* pPoint = &searchPoint.x;
   for (U32 i = 0; i < queryList.mList.size(); i++)
   {
      const F32* bMins;
      const F32* bMaxs;
      bMins = &queryList.mList[i]->getWorldBox().minExtents.x;
      bMaxs = &queryList.mList[i]->getWorldBox().maxExtents.x;
      F32 sum = 0;
      for (U32 j = 0; j < 3; j++)
      {
         if (pPoint[j] < bMins[j])
            sum += (pPoint[j] - bMins[j])*(pPoint[j] - bMins[j]);
         else if (pPoint[j] > bMaxs[j])
            sum += (pPoint[j] - bMaxs[j])*(pPoint[j] - bMaxs[j]);
      }
      if (sum < radiusSquared || queryList.mList[i]->isGlobalBounds())
      {
         mSearchList.push_back(new SimObjectPtr<SceneObject>);
         *(mSearchList.last()) = queryList.mList[i];
      }
   }
   if (mSearchList.size() != 0)
   {
      sgSortReferencePoint = mSearchReferencePoint;
      dQsort(mSearchList.address(), mSearchList.size(),
             sizeof(SimObjectPtr<SceneObject>*), cmpSearchPointers);
   }
}

void Container::initTypeSearch(const U32      searchMask)
{
   AssertFatal(this == &gServerContainer, "Abort.  Searches only allowed on server container");
   cleanupSearchVectors();

   SimpleQueryList queryList;
   findObjects(searchMask, SimpleQueryList::insertionCallback, &queryList);

   for (U32 i = 0; i < queryList.mList.size(); i++)
   {
         mSearchList.push_back(new SimObjectPtr<SceneObject>);
         *(mSearchList.last()) = queryList.mList[i];
   }
   if (mSearchList.size() != 0)
   {
      sgSortReferencePoint = mSearchReferencePoint;
      dQsort(mSearchList.address(), mSearchList.size(),
             sizeof(SimObjectPtr<SceneObject>*), cmpSearchPointers);
   }
}

SceneObject* Container::containerSearchNextObject()
{
   AssertFatal(this == &gServerContainer, "Abort.  Searches only allowed on server container");

   if (mCurrSearchPos >= mSearchList.size())
      return NULL;

   mCurrSearchPos++;
   while (mCurrSearchPos < mSearchList.size() && bool(*mSearchList[mCurrSearchPos]) == false)
      mCurrSearchPos++;

   if (mCurrSearchPos == mSearchList.size())
      return NULL;

   return (*mSearchList[mCurrSearchPos]);
}

U32 Container::containerSearchNext()
{
   SceneObject* object = containerSearchNextObject();
   if( !object )
      return 0;
   return object->getId();
}


F32 Container::containerSearchCurrDist()
{
   AssertFatal(this == &gServerContainer, "Abort.  Searches only allowed on server container");
   AssertFatal(mCurrSearchPos != -1, "Error, must call containerSearchNext before containerSearchCurrDist");

   if (mCurrSearchPos == -1 || mCurrSearchPos >= mSearchList.size() ||
       bool(*mSearchList[mCurrSearchPos]) == false)
      return 0.0;

   Point3F pos;
   (*mSearchList[mCurrSearchPos])->getWorldBox().getCenter(&pos);
   return (pos - mSearchReferencePoint).len();
}

F32 Container::containerSearchCurrRadiusDist()
{
   AssertFatal(this == &gServerContainer, "Abort.  Searches only allowed on server container");
   AssertFatal(mCurrSearchPos != -1, "Error, must call containerSearchNext before containerSearchCurrDist");

   if (mCurrSearchPos == -1 || mCurrSearchPos >= mSearchList.size() ||
       bool(*mSearchList[mCurrSearchPos]) == false)
      return 0.0;

   Point3F pos;
   (*mSearchList[mCurrSearchPos])->getWorldBox().getCenter(&pos);

   F32 dist = (pos - mSearchReferencePoint).len();

   F32 min = (*mSearchList[mCurrSearchPos])->getWorldBox().len_x();
   if ((*mSearchList[mCurrSearchPos])->getWorldBox().len_y() < min)
      min = (*mSearchList[mCurrSearchPos])->getWorldBox().len_y();
   if ((*mSearchList[mCurrSearchPos])->getWorldBox().len_z() < min)
      min = (*mSearchList[mCurrSearchPos])->getWorldBox().len_z();

   dist -= min;
   if (dist < 0)
      dist = 0;

   return dist;
}

void SimpleQueryList::insertionCallback(SceneObject* obj, void *key)
{
   SimpleQueryList* pList = (SimpleQueryList*)key;
   pList->insertObject(obj);
}

Point3F SceneObject::getPosition() const
{
   Point3F pos;
   mObjToWorld.getColumn(3, &pos);
   return pos;
}

Point3F SceneObject::getRenderPosition() const
{
   Point3F pos;
   mRenderObjToWorld.getColumn(3, &pos);
   return pos;
}

void SceneObject::setPosition(const Point3F &pos)
{
	AssertFatal( !mIsNaN( pos ), "SceneObject::setPosition() - The position is NaN!" );

   MatrixF xform = mObjToWorld;
   xform.setColumn(3, pos);
   setTransform(xform);
}

F32 SceneObject::distanceTo(const Point3F &pnt) const
{
   return mWorldBox.getDistanceToPoint( pnt );   
}

//-------------------------------------------------------------------------

void SceneObject::processAfter( ProcessObject *obj )
{
   AssertFatal( dynamic_cast<SceneObject*>( obj ), "SceneObject::processAfter - Got non-SceneObject!" );

   mAfterObject = (SceneObject*)obj;
   if ( mAfterObject->mAfterObject == this )
      mAfterObject->mAfterObject = NULL;

   getProcessList()->markDirty();
}

void SceneObject::clearProcessAfter()
{
   mAfterObject = NULL;
}

void SceneObject::setProcessTick( bool t )
{
   if ( t == mProcessTick )
      return;

   if ( mProcessTick )
   {
      plUnlink();
      mProcessTick = false;
   }
   else
   {
      // Just to be sure...
      plUnlink();

      getProcessList()->addObject( this );

      mProcessTick = true;  
   }   
}

ProcessList* SceneObject::getProcessList() const
{
   if ( isClientObject() )      
      return ClientProcessList::get();
   else
      return ServerProcessList::get();
}

//-------------------------------------------------------------------------

bool SceneObject::isMounted()
{
   resolveMountPID();   

   return mMount.object != NULL;
}

S32 SceneObject::getMountedObjectCount()
{
   S32 count = 0;
   for (SceneObject* itr = mMount.list; itr; itr = itr->mMount.link)
      count++;
   return count;
}

SceneObject* SceneObject::getMountedObject(S32 idx)
{
   if (idx >= 0) {
      S32 count = 0;
      for (SceneObject* itr = mMount.list; itr; itr = itr->mMount.link)
         if (count++ == idx)
            return itr;
   }
   return NULL;
}

S32 SceneObject::getMountedObjectNode(S32 idx)
{
   if (idx >= 0) {
      S32 count = 0;
      for (SceneObject* itr = mMount.list; itr; itr = itr->mMount.link)
         if (count++ == idx)
            return itr->mMount.node;
   }
   return -1;
}

SceneObject* SceneObject::getMountNodeObject(S32 node)
{
   for (SceneObject* itr = mMount.list; itr; itr = itr->mMount.link)
      if (itr->mMount.node == node)
         return itr;
   return NULL;
}

void SceneObject::resolveMountPID()
{
   if ( mMountPID && !mMount.object )
   {
      SceneObject *obj = dynamic_cast< SceneObject* >( mMountPID->getObject() );
      if ( obj )      
         obj->mountObject( this, mMount.node, mMount.xfm );      
   }
}

void SceneObject::mountObject( SceneObject *obj, S32 node, const MatrixF &xfm )
{
   if ( obj->mMount.object == this )
   {
      // Already mounted to this
      // So update our node and xfm which may have changed.
      obj->mMount.node = node;
      obj->mMount.xfm = xfm;
   }
   else
   {
      if ( obj->mMount.object )
         obj->unmount();

      obj->mMount.object = this;
      obj->mMount.node = node;
      obj->mMount.link = mMount.list;
      obj->mMount.xfm = xfm;
      mMount.list = obj;

      // Assign PIDs to both objects
      if ( isServerObject() )
      {
         obj->getOrCreatePersistentId();
         obj->mMountPID = getOrCreatePersistentId();
         obj->mMountPID->incRefCount();
      }

      obj->onMount( this, node );
   }
}


void SceneObject::unmountObject( SceneObject *obj )
{   
   if ( obj->mMount.object == this ) 
   {
      // Find and unlink the object
      for ( SceneObject **ptr = &mMount.list; *ptr; ptr = &(*ptr)->mMount.link )
      {
         if ( *ptr == obj )
         {
            *ptr = obj->mMount.link;
            break;
         }
      }
      
      obj->mMount.object = NULL;
      obj->mMount.link = NULL;         
      
      if( obj->mMountPID != NULL ) // Only on server.
      {
         obj->mMountPID->decRefCount();
         obj->mMountPID = NULL;
      }

      obj->onUnmount( this, obj->mMount.node );
   }
}

void SceneObject::unmount()
{
   if (mMount.object)
      mMount.object->unmountObject(this);
}

void SceneObject::onMount( SceneObject *obj, S32 node )
{   
   deleteNotify( obj );

   if ( !isGhost() ) 
   {      
      setMaskBits( MountedMask );      
      //onMount_callback( node );
   }
}

void SceneObject::onUnmount( SceneObject *obj, S32 node )
{
   clearNotify(obj);

   if ( !isGhost() ) 
   {           
      setMaskBits( MountedMask );      
      //onUnmount_callback( node );
   }
}

void SceneObject::getMountTransform( S32 index, const MatrixF &xfm, MatrixF *outMat )
{
   MatrixF mountTransform( xfm );
   const Point3F &scale = getScale();
   Point3F position = mountTransform.getPosition();
   position.convolve( scale );
   mountTransform.setPosition( position );

   outMat->mul( mObjToWorld, mountTransform );
}

void SceneObject::getRenderMountTransform( F32 delta, S32 index, const MatrixF &xfm, MatrixF *outMat )
{
   MatrixF mountTransform( xfm );
   const Point3F &scale = getScale();
   Point3F position = mountTransform.getPosition();
   position.convolve( scale );
   mountTransform.setPosition( position );

   outMat->mul( mRenderObjToWorld, mountTransform );
}

//-------------------------------------------------------------------------

DefineEngineMethod( SceneObject, mountObject, bool,
   ( SceneObject* objB, S32 slot, TransformF txfm ), ( MatrixF::Identity ),
   "Mount objB to this object at the desired slot with optional transform.\n"
   "@param objB  Object to mount onto us\n"
   "@param slot  Mount slot ID\n"
   "@param txfm (optional) mount offset transform\n"
   "@return true if successful, false if failed (objB is not valid)" )
{
   if ( objB )
   {
      object->mountObject( objB, slot, txfm.getMatrix() );
      return true;
   }
   return false;
}

DefineEngineMethod( SceneObject, unmountObject, bool, ( SceneObject* target ),,
   "Unmount an object from ourselves.\n"
   "@param target object to unmount\n"
   "@return true if successful, false if failed\n" )
{
   if ( target )
   {
      object->unmountObject(target);
      return true;
   }
   return false;
}

DefineEngineMethod( SceneObject, unmount, void, (),,
   "Unmount from the currently mounted object if any." )
{
   object->unmount();
}

DefineEngineMethod( SceneObject, isMounted, bool, (),,
   "Check if we are mounted to another object.\n"
   "@return true if mounted to another object, false if not mounted." )
{
   return object->isMounted();
}

DefineEngineMethod( SceneObject, getObjectMount, S32, (),,
   "Get the object we are mounted to.\n"
   "@return the SceneObject ID of the object we're mounted to, or 0 if not mounted." )
{
   return object->isMounted()? object->getObjectMount()->getId(): 0;
}

DefineEngineMethod( SceneObject, getMountedObjectCount, S32, (),,
   "Get the number of objects mounted to us.\n"
   "@return the number of mounted objects." )
{
   return object->getMountedObjectCount();
}

DefineEngineMethod( SceneObject, getMountedObject, S32, ( S32 slot ),,
   "Get the object mounted at a particular slot.\n"
   "@param slot mount slot index to query\n"
   "@return ID of the object mounted in the slot, or 0 if no object." )
{
   SceneObject* mobj = object->getMountedObject( slot );
   return mobj? mobj->getId(): 0;
}

DefineEngineMethod( SceneObject, getMountedObjectNode, S32, ( S32 slot ),,
   "Get the mount node index of the object mounted at a particular slot.\n"
   "@param slot mount slot index to query\n"
   "@return index of the mount node used by the object mounted in this slot." )
{
   return object->getMountedObjectNode( slot );
}

DefineEngineMethod( SceneObject, getMountNodeObject, S32, ( S32 node ),,
   "Get the object mounted at a particular node.\n"
   "@param node mount node to query\n"
   "@return ID of the first object mounted at the node, or 0 if none found." )
{
   SceneObject* mobj = object->getMountNodeObject( node );
   return mobj? mobj->getId(): 0;
}

// PATHSHAPE
// Move RenderTransform by set amount
// no longer used

void SceneObject::moveRender(const Point3F &delta) 
{
   Point3F pos;

   const MatrixF& tmat = getRenderTransform();
   tmat.getColumn(3,&pos);
   AngAxisF aa(tmat);
   pos += delta;

   MatrixF mat;
   aa.setMatrix(&mat);
   mat.setColumn(3,pos);
   setRenderTransform(mat);
}

void SceneObject::PerformUpdatesForChildren(MatrixF mat){
	    UpdateXformChange(mat);
		for (U32 i=0; i < getNumChildren(); i++) {
			SceneObject *o = getChild(i);
			o->updateChildTransform(); //update the position of the child object
		}
}





// This function will move the players based on how much it's
// parent have moved
void SceneObject::updateChildTransform(){
	if (getParent() != NULL){
		MatrixF one;
		MatrixF two;
		MatrixF three;
		MatrixF four;
		MatrixF mat;
		one= getTransform();
		two = getParent()->getTransform();
		one.affineInverse();
		four.mul(two,one);
		mat.mul(getParent()->mLastXform,getTransform());
		setTransform(mat);
	}
}

// This function will move the rendered image based on how much it's
// parent have moved since the processtick.
// For some reason the player object must be updated via it's GetRenderTransform seen below,
// Other objects seem to require getTransform() only
void SceneObject::updateRenderChangesByParent(){
   if (getParent() != NULL){
		MatrixF renderXform = getParent()->getRenderTransform();
		MatrixF xform = getParent()->getTransform();
		xform.affineInverse();

		MatrixF offset;
		offset.mul(renderXform, xform);

   	    MatrixF mat;
		
		//add the "offset" caused by the parents change, and add it to it's own
		// This is needed by objects that update their own render transform thru interpolate tick
		// Mostly for stationary objects.

		if (getClassName() == "Player")
			mat.mul(offset,getRenderTransform());  
		else										
			mat.mul(offset,getTransform());	 
			setRenderTransform(mat);
	}
}





//Ramen - Move Transform by set amount
//written by  Anthony Lovell
void SceneObject::move(F32 x, F32 y, F32 z) 
{
    Point3F delta;
    delta.x = x;
    delta.y = y;
    delta.z = z;
    move(delta);
}
// move by a specified delta in root coordinate space
void SceneObject::move(const Point3F &delta) 
{
   Point3F pos;

   const MatrixF& tmat = getTransform();
   tmat.getColumn(3,&pos);
   AngAxisF aa(tmat);
 
   pos += delta;

   MatrixF mat;
   aa.setMatrix(&mat);
   mat.setColumn(3,pos);
   setTransform(mat);
}



//written by  Anthony Lovell ----------------------------------------------------------
U32
SceneObject::getNumChildren() const
{   
    U32 num = 0;
    for (SceneObject *cur = mGraph.firstChild; cur; cur = cur->mGraph.nextSibling)
        num++;
    return num;
}
//written by  Anthony Lovell ----------------------------------------------------------
SceneObject *
SceneObject::getChild(U32 index) const
{       
    SceneObject *cur = mGraph.firstChild;
    for (U32 i = 0; 
        cur && i < index; 
        i++)
        cur = cur->mGraph.nextSibling;
    return cur;
}




void SceneObject::UpdateXformChange(const MatrixF &mat){
// This function gets the difference between the Transform and current Render transform
// Used for Interpolation matching with the child objects who rely on this data.

	MatrixF oldxform = getTransform();

	oldxform.affineInverse();
	mLastXform.mul(mat,oldxform);

}


//----------------------------------------------------------
bool
SceneObject::attachChildAt(SceneObject *subObject, MatrixF atThisOffset, S32 node)
{   
    AssertFatal(subObject, "attaching a null subObject");
    AssertFatal(!isChildOf(subObject), "cyclic attachChild()");
    bool b = subObject->attachToParent(this, &atThisOffset, node);    
    if (!b) 
        return false;
    
    return true;
}

//----------------------------------------------------------
bool
SceneObject::attachChildAt(SceneObject *subObject, Point3F atThisPosition)
{   
    AssertFatal(subObject, "attaching a null subObject");
    AssertFatal(!isChildOf(subObject), "cyclic attachChild()");
    bool b = subObject->attachToParent(this);
    if (!b) 
        return false;
        
    subObject->mGraph.objToParent.setColumn(3, atThisPosition);
//    calcTransformFromLocalTransform();

    return true;
}

//----------------------------------------------------------
bool
SceneObject::attachChild(SceneObject *child)
{   
	AssertFatal(child, "attaching a null subObject");
    AssertFatal(!isChildOf(child), "cyclic attachChild()");
	
    return  child->attachToParent(this);        
}


//----------------------------------------------------------
/// returns a count of children plus their children, recursively
U32
SceneObject::getNumProgeny() const
{   
    U32 num = 0;
    for (SceneObject *cur = mGraph.firstChild; cur; cur = cur->mGraph.nextSibling) {
        num += 1 + cur->getNumProgeny();
    }
    return num;
}

ConsoleMethod(SceneObject, getNumChildren, S32, 2, 2, "returns number of direct child objects")
{
    return object->getNumChildren();
}

ConsoleMethod(SceneObject, getNumProgeny, S32, 2, 2, "returns number of recursively-nested child objects")
{
    return object->getNumProgeny();
}

ConsoleMethod(SceneObject, getChild, S32, 3, 3, "getChild(int index) -- returns child SceneObject at given index")
{
    SceneObject *s = object->getChild(dAtoi(argv[2]));
    return s ? s->getId() : 0;
}

ConsoleMethod(SceneObject, attachChildAt, bool, 5, 5, "(SceneObject subObject, MatrixF offset)"
              "Mount object to this one with the specified offset expressed in our coordinate space.")
{   
    SceneObject * t;   
    MatrixF m;   
	S32 node=0;
	if(Sim::findObject(argv[2], t))   {      
        // Parse into m...      
        Point3F pos;      
        const MatrixF tmat(1);      
        tmat.getColumn(3,&pos);      
        AngAxisF aa(tmat);      
        dSscanf(argv[3],"%f %f %f %f %f %f %f",            
            &pos.x,&pos.y,&pos.z,&aa.axis.x,&aa.axis.y,&aa.axis.z,&aa.angle);      
        MatrixF mat;      
        aa.setMatrix(&mat);      
        mat.setColumn(3,pos);      
        dSscanf(argv[3],"%d",&node);      

        return object->attachChildAt(t, mat,node);   
    } else {      
        Con::errorf("Couldn't addObject()!");   
        return false;
    }
}

ConsoleMethod(SceneObject, attachToParent, bool, 3, 3, "attachToParent(SceneObject)"
              "specify a null or non-null parent")
{   
    SceneObject * t;   
    
    if(Sim::findObject(argv[2], t))   {              
        return object->attachToParent(t);   
    } else {      
        if (!dStrcmp("0", argv[2]))
            return object->attachToParent(NULL);
        else {
            Con::errorf("Couldn't setParent()!");   
            return false;
        }
    }
}

ConsoleMethod(SceneObject, getParent, S32, 2, 2, "returns ID of parent SceneObject")
{
    SceneObject *p = object->getParent();
    return p ? p->getId() : -1;
}

ConsoleMethod(SceneObject, attachChild, bool, 3, 3, "(SceneObject subObject)"
              "attach an object to this one, preserving its present transform.")
{   
    SceneObject * t;   
    MatrixF m;   
    if(Sim::findObject(argv[2], t))   {              
        return object->attachChild(t);   
    } else {      
        Con::errorf("Couldn't addObject()!");   
        return false;
    }
}

bool
SceneObject::isChildOf(SceneObject *so)
{    
    SceneObject *p = mGraph.parent;
    if (p) {
        if (p == so) 
            return true;
        else
            return p->isChildOf(so);
    } else
        return false;
}



bool 
SceneObject::attachToParent(SceneObject *newParent, MatrixF *atThisOffset/* = NULL */, S32 node )
{   
	SceneObject *oldParent = mGraph.parent;

    if (oldParent == newParent)
        return true;

    // cycles in the scene hierarchy are forbidden!
    // that is:  a SceneObject cannot be a child of its progeny
    if (newParent && newParent->isChildOf(this))
        return false;
      
    mGraph.parent = newParent;

    if (oldParent) {

        clearNotify(oldParent); 

        // remove this SceneObject from the list of children of oldParent
        SceneObject *cur = oldParent->mGraph.firstChild;
        if (cur == this) { // if we are the first child, this is easy
            oldParent->mGraph.firstChild = mGraph.nextSibling;
        } else {
            while (cur->mGraph.nextSibling != this) {
                cur = cur->mGraph.nextSibling;
                // ASSERT cur != NULL;
            }
            cur->mGraph.nextSibling = mGraph.nextSibling;
        }
        oldParent->onLostChild(this);
    }
     
    if (newParent) {

        deleteNotify(newParent); // if we are deleted, inform our parent

        // add this SceneObject to the list of children of oldParent
        mGraph.nextSibling = newParent->mGraph.firstChild;
        newParent->mGraph.firstChild = this;
        mGraph.parent = newParent;
        
        newParent->onNewChild(this);

        if (atThisOffset)
            mGraph.objToParent = *atThisOffset;
    } else {
        mGraph.parent = NULL;
        mGraph.nextSibling = NULL;
        mGraph.objToParent = mObjToWorld;
    }

    onLostParent(oldParent);
    onNewParent(newParent);

    setMaskBits( ParentObjectMask );
    return true;
}

ConsoleMethod(SceneObject, detachChild, bool, 3, 3, "SceneObject subObject")
{   
    SceneObject * t;       
    if(Sim::findObject(argv[2], t))   {     
        return t->attachToParent(NULL);
    } else 
        return false;    
}

// subclasses can do something with these if they care to
void SceneObject::onNewParent(SceneObject *newParent) {}  
void SceneObject::onLostParent(SceneObject *oldParent){}    
void SceneObject::onNewChild(SceneObject *newKid){}   
void SceneObject::onLostChild(SceneObject *lostKid){}
