It is a setup for the Full Template project.

1. Copy pathshape.cs into the serverside scripts.

2. Open scriptExec.cs and exec the file :
exec("./pathshape.cs");

3. Open gameCore.cs,go at the end of :
function GameConnection::onClientEnterGame(%this)
{
Game.onClientEnterGame(%this);
// this is a fix to prevent the preload bitstream crashing on exit
doPathShape();
}

4. Now go to the client side scripts and change a bit the prefs :
$pref::Net::PacketRateToClient = "32";
$pref::Net::PacketRateToServer = "32";
$pref::Net::PacketSize = "450";

5. Open your mission file,located in levels/Empty Terrain.mis
Add here a path with three markers:
�
new Path(mPath) {
isLooping = "1";
canSaveDynamicFields = "1";
enabled = "1";
new Marker(a) {
seqNum = "1";
type = "Normal";
msToNext = "1000";
smoothingType = "Spline";
position = "-223.848 -54.2793 185.747";
rotation = "1 0 0 0";
scale = "1 1 1";
isRenderEnabled = "true";
canSaveDynamicFields = "1";
enabled = "1";
};
new Marker(b) {
seqNum = "2";
type = "Normal";
msToNext = "1000";
smoothingType = "Spline";
position = "-213.962 -54.285 185.869";
rotation = "1 0 0 0";
scale = "1 1 1";
isRenderEnabled = "true";
canSaveDynamicFields = "1";
enabled = "1";
};
new Marker(c) {
seqNum = "3";
type = "Normal";
msToNext = "1000";
smoothingType = "Spline";
position = "-223.962 -54.285 187.266";
rotation = "1 0 0 0";
scale = "1 1 1";
isRenderEnabled = "true";
canSaveDynamicFields = "1";
enabled = "1";
};
};
};
//--- OBJECT WRITE END ---
