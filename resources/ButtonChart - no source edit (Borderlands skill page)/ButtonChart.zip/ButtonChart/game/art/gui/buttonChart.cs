//---------------------------------------------------------
//---------------------------------------------------------
// Button Chart Resource - no source edit
// Copyright (C) Jonathan Noyola
//---------------------------------------------------------
//---------------------------------------------------------


//---------------------------------------------------------
//---------------------------------------------------------
// Included Functions:
// createButtonChart(%gui, %buttonChartData, %name)
// ButtonChart::refreshButton(%this, %button, %justEnabled)
// ButtonChart::selectButton(%this, %button)
//---------------------------------------------------------
//---------------------------------------------------------


function createButtonChart(%gui, %buttonChartData, %name)
{      
   %buttonChart = new GuiControl(%name) {
      class = ButtonChart;
      extent = %gui.extent;
      HorizSizing = "relative";
      VertSizing = "relative";
      buttonChartData = %buttonChartData;
   };
   
   %rows = getRecordCount(%buttonChartData.buttons);
   %columns = getWordCount(getRecord(%buttonChartData.buttons, 0));
   for (%i = 0; %i < %columns; %i++)
   {
      for (%j = 0; %j < %rows; %j++)
      {
         %data = getWord(getRecord(%buttonChartData.buttons, %j), %i);
         if (%buttonChartData.advancement $= "all" || %j == 0)
         {
            %profile = %buttonChartData.enabledProfile;
            echo(%buttonChartData.enabledProfile);
            %enabled = "1";
         }
         else
         {
            %profile = %buttonChartData.disabledProfile;
            %enabled = "0";
         }
         %width = getWord(%buttonChartData.buttonSize, 0);
         %height = getWord(%buttonChartData.buttonSize, 1);
         %x = getWord(%buttonChartData.startPos, 0) + ((%i + 1) * %buttonChartData.spacing) + (%i * getWord(%buttonChartData.buttonSize, 0));
         %y = getWord(%buttonChartData.startPos, 1) + ((%j + 1) * %buttonChartData.spacing) + (%j * getWord(%buttonChartData.buttonSize, 1));
         
         %button = new GuiButtonCtrl() {
            Profile = %profile;
            HorizSizing = "relative";
            VertSizing = "relative";
            Position = %x SPC %y;
            Extent = %width SPC %height;
            buttonCommand = %data.command;
            tooltipprofile = "GuiToolTipProfile";
            hovertime = "500";
            tooltip = %data.tooltip;
            defaultTooltip = %data.tooltip;
            text = %data.text;
            defaultText = %data.text;
            val = %data.val;
            maxVal = %data.maxVal;
            row = %j;
            column = %i;
            Enabled = %enabled;
         };
         %button.Command = %buttonChart @ ".selectButton(" @ %button @ ");";
         
         %text = "";
         if (%buttonChartData.displayVal > 0)
         {
            %text = %data.val;
            if (%buttonChartData.displayMaxVal)
               %text = %text @ "/" @ %data.maxVal;
         }
         switch (%buttonChartData.displayVal)
         {
            case 1: %button.text = %button.text TAB %text;
            case 2: %button.tooltip = %button.tooltip NL %text;
         }
         %buttonChart.add(%button);
         eval("%buttonChart.button" @ %j @ "_" @ %i @ " = %button;");
      }
   }
   %gui.add(%buttonChart);
}
function ButtonChart::refreshButton(%this, %button, %justEnabled)
{
   %data = %this.buttonChartData;
   if (%justEnabled)
   {
      %profile = %this.buttonChartData.enabledProfile;
      %button.setProfile(%profile);
   }
   else
   {
      %text = "";
      if (%this.buttonChartData.displayVal > 0)
      {
         %text = %button.val;
         if (%this.buttonChartData.displayMaxVal)
            %text = %text @ "/" @ %button.maxVal;
      }
      switch (%this.buttonChartData.displayVal)
      {
         case 1: %button.text = %button.defaultText TAB %text;
         case 2: %button.tooltip = %button.defaultTooltip NL %text;
      }
   }
}
function ButtonChart::selectButton(%this, %button)
{
   if(!%button.enabled || %button.val >= %button.maxVal)
      return;
   eval("%points = " @ %this.buttonChartData.points @ ";");
   if (%points <= 0)
      return;
   %button.val++;
   %this.refreshButton(%button, false);
   %points--;
   eval(%this.buttonChartData.points @ " = %points;");
   switch$ (%this.buttonChartData.advancement)
   {
      case "column":
         if (%button.row < getRecordCount(%this.buttonChartData.buttons) - 1)
         {
            %totalPoints = 0;
            for (%i = 0; %i <= %button.row; %i++)
            {
               eval("%totalPoints += %this.button" @ %i @ "_" @ %button.column @ ".val;");
            }
            if (%totalPoints >= (%button.row + 1) * %this.buttonChartData.advancementVal)
            {
               eval("%nextButton = %this.button" @ (%button.row + 1) @ "_" @ %button.column @ ";");
               %nextButton.enabled = "1";
               %this.refreshButton(%nextButton, true);
            }
         }
      
      case "row":
         if (%button.row < getRecordCount(%this.buttonChartData.buttons) - 1)
         {
            %totalPoints = 0;
            for (%i = 0; %i <= %button.row; %i++)
            {
               for (%j = 0; %j <= getWordCount(getRecord(%this.buttonChartData.buttons, 0)); %j++)
               {
                  eval("%totalPoints += %this.button" @ %i @ "_" @ %j @ ".val;");
               }
            }
            if (%totalPoints >= (%button.row + 1) * %this.buttonChartData.advancementVal)
            {
               for (%j = 0; %j < getWordCount(getRecord(%this.buttonChartData.buttons, 0)); %j++)
               {
                  eval("%nextButton = %this.button" @ (%button.row + 1) @ "_" @ %j @ ";");
                  %nextButton.enabled = "1";
                  %this.refreshButton(%nextButton, true);
               }
            }
         }
      
      case "all":
   }
   call(%button.buttonCommand);
}