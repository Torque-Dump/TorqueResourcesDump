//---------------------------------------------------------
//---------------------------------------------------------
// Sample ButtonChart Data
//---------------------------------------------------------
//---------------------------------------------------------

new ScriptObject(buttonA)
{
   text = "A";
   tooltip = "Button A";
   command = "";
   val = 0;
   maxVal = 5;
};
new ScriptObject(buttonB)
{
   text = "B";
   tooltip = "Button B";
   command = "";
   val = 0;
   maxVal = 5;
};
new ScriptObject(buttonC)
{
   text = "C";
   tooltip = "Button C";
   command = "";
   val = 0;
   maxVal = 5;
};
new ScriptObject(buttonD)
{
   text = "D";
   tooltip = "Button D";
   command = "";
   val = 0;
   maxVal = 5;
};
new ScriptObject(buttonE)
{
   text = "E";
   tooltip = "Button E";
   command = "";
   val = 0;
   maxVal = 5;
};
new ScriptObject(buttonF)
{
   text = "F";
   tooltip = "Button F";
   command = "";
   val = 0;
   maxVal = 5;
};
new ScriptObject(buttonG)
{
   text = "G";
   tooltip = "Button G";
   command = "";
   val = 0;
   maxVal = 5;
};
new ScriptObject(buttonH)
{
   text = "H";
   tooltip = "Button H";
   command = "";
   val = 0;
   maxVal = 5;
};
new ScriptObject(buttonI)
{
   text = "I";
   tooltip = "Button I";
   command = "";
   val = 0;
   maxVal = 5;
};
new ScriptObject(buttonJ)
{
   text = "J";
   tooltip = "Button J";
   command = "";
   val = 0;
   maxVal = 5;
};
new ScriptObject(buttonK)
{
   text = "K";
   tooltip = "Button K";
   command = "";
   val = 0;
   maxVal = 5;
};
new ScriptObject(buttonL)
{
   text = "Button L";
   tooltip = "Button L";
   command = "";
   val = 0;
   maxVal = 5;
};
new ScriptObject(ButtonChart1Data)
{
   start = "20 20"; // Spacing is added to the start position
   buttonSize = "100 100";
   spacing = 10; // Space in between buttons
   buttons = "buttonA buttonB buttonC"
          NL "buttonD buttonE buttonF"
          NL "buttonG buttonH buttonI"
          NL "buttonJ buttonK buttonL";
   enabledProfile = "GuiMenuButtonProfile";
   disabledProfile = "GuiButtonProfile";
   
   displayVal = 1; // 0 = no display; 1 = display on button; 2 = display in tooltip
   displayMaxVal = true; // displayed after val if true
   
   //------------------------------------------------------------
   //column: when the sum of all the buttons' val in one column
   //   reaches advancementVal, the next button in the column may
   //   be selected
   //row: when the sum of all the buttons' val reaches
   //   advancementVal, buttons in the next row may be selected
   //all: all buttons may be selected
   advancement = "column";
   advancementVal = 3;
   //------------------------------------------------------------
   
   points = "$buttonChartPoints"; // How many times buttons can be selected
};
