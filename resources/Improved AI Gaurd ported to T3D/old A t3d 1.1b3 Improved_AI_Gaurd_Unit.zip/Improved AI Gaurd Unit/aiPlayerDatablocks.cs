// aiPlayerDatablocks.cs
// breaks out the datablocks for aiguard.cs to make them easier to edit.
// also manages the trigger controller

//////////////////////////////////////
//
// TRIGGER CONTROLLER
// This code handles the placing and behavior of aiSoldierTriggers
/////////////////////////////////////////

datablock TriggerData(guardTrigger)
{
   tickPeriodMS = 100;
};

function guardTrigger::onEnterTrigger(%this, %trigger, %obj)
{
  echo(%trigger @ " has been triggered!");
  // we've been triggered.  Now check to see if the player triggered the trigger
  // we don't want other enemies to keep spawing more enemies!
  %tgtid = AIPlayer::GetClosestPlayer(%trigger);
         //echo("nearest human is " @ %tgtid);
  // check to see if the player triggered this.  
  if (%tgtid == %obj)
  {
      // if triggerMany is set, then we shouldn't do anything.  (or do something different.)
      // if you want a trigger to always spawn an enemy, set the trigger's triggerMany value to "true"
      // default behavior is to trigger once.
     if (!%trigger.triggerMany && !%trigger.doneOnce)
     {

         // set the spawnGroup variable to pass on to the spawn function
         %spawnGroup = %trigger.spawnGroup;

         // let the game know we've already been triggered once.
         %trigger.doneOnce = true;

         // spawn the group        
         AIPlayer::spawnByGroup(%spawnGroup);

     }
     else
     {
        // we've been triggered before.  Don't do anything
        // If you wanted to do something different, this is where you would put it.
     }
  }
}

////////////////////////////////////////
//This is the default datablock for the Guard.
//I changed the stock datablock name from those used in AIPLAYER.CS
//I did this to allow me to create different classes of bots with their own
//thinking and reaction routines for each class.
///////////////////////////////////
//
//You can specifiy as many datablocks as you have characters.
//The first variable after PlayerData must be a unique name. The second variable (after the semicolon) 
//must be a valid body type.

datablock PlayerData(DemoPlayer : DefaultPlayerData)
{
   maxDamage = 100;

   maxForwardSpeed = 14;
   maxBackwardSpeed = 13;
   maxSideSpeed = 13;

   //The art used by this datablock
   shapeFile = "art/shapes/actors/gideon/gideon.dts";
};

