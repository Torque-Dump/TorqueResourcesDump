Don't forget to add the c++ files to the project.

