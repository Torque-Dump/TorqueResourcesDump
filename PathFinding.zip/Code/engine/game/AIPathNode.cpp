#include "./aipathnode.h"
#include "./aipathgroup.h"

extern bool gEditingMission;

IMPLEMENT_CO_DATABLOCK_V1(AIPathNodeData);

IMPLEMENT_CO_NETOBJECT_V1(AIPathNode);

AIPathNode::AIPathNode(void): MissionMarker()
{
}

AIPathNode::~AIPathNode(void)
{
}

bool AIPathNode::onAdd()
{
   if(!Parent::onAdd() || !mDataBlock)
      return(false);

    return(true);
}

void AIPathNode::onRemove()
{
   Parent::onRemove();
}

bool AIPathNode::onNewDataBlock(GameBaseData * dptr)
{
   mDataBlock = dynamic_cast<AIPathNodeData*>(dptr);
   if(!mDataBlock || !Parent::onNewDataBlock(dptr))
      return(false);
   scriptOnNewDataBlock();
   return(true);
}



