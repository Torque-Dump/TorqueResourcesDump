//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// AIPlayer callbacks
// The AIPlayer class implements the following callbacks:
//
//    PlayerData::onStuck(%this,%obj)
//    PlayerData::onUnStuck(%this,%obj)
//    PlayerData::onStop(%this,%obj)
//    PlayerData::onMove(%this,%obj)
//    PlayerData::onReachDestination(%this,%obj)
//    PlayerData::onTargetEnterLOS(%this,%obj)
//    PlayerData::onTargetExitLOS(%this,%obj)
//    PlayerData::onAdd(%this,%obj)
//
// Since the AIPlayer doesn't implement it's own datablock, these callbacks
// all take place in the PlayerData namespace.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Demo Pathed AIPlayer.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//Modified by Gabriel Notman March 2008 adding new path finding
//-----------------------------------------------------------------------------
datablock PlayerData(DemoPlayer : PlayerBody)
{
   shootingDelay = 2000;
};

function DemoPlayer::onReachDestination(%this,%obj)
{
   //G.Notman Begin
   if (isObject(AiPaths))
   {
      if (%obj.CurNode == %obj.EndNode)
         %this.onEndOfPath(%obj,%obj.path);
      else
         %obj.moveToNextNode();
         
      return;
   }
   //G.Notman End
   // Moves to the next node on the path.
   // Override for all player. Normally we'd override this for only
   // a specific player datablock or class of players.
   if (%obj.path !$= "") {
      if (%obj.currentNode == %obj.targetNode)
         %this.onEndOfPath(%obj,%obj.path);
      else
         %obj.moveToNextNode();
   }
}

function DemoPlayer::onEndOfPath(%this,%obj,%path)
{
   //G.Notman Begin
   if (isObject(AiPaths))
   {
      %this.schedule(1000,"SetOnPath");
      return;
   }
   //G.Notman End
   
   %obj.nextTask();
}

function DemoPlayer::onEndSequence(%this,%obj,%slot)
{
   echo("Sequence Done!");
   %obj.stopThread(%slot);
   %obj.nextTask();
}


//G.Notman Begin
function DemoPlayer::onRemove(%this, %obj)
{
   if (isObject(%obj.patharray))
      %obj.patharray.delete();
   Parent::onRemove(%this, %obj);
}

function DemoPlayer::onStuck(%this,%obj)
{
   messageAll("",'Kork got stuck, finding new path');
 
   if (isObject(AiPaths))
      %obj.SetOnPath();
}
//G.Notman End

//-----------------------------------------------------------------------------
// AIPlayer static functions
//-----------------------------------------------------------------------------
function AIPlayer::spawn(%name,%spawnPoint)
{
   // Create the demo player object
   %player = new AiPlayer() {
      dataBlock = DemoPlayer;
      path = "";
      
      //G.Notman Begin
      CurNode=0;
      EndNode=0;
      //G.Notman End
   };
   MissionCleanup.add(%player);
   %player.setShapeName(%name);
   %player.setTransform(%spawnPoint);
   
   //G.Notman Begin
   %player.patharray=new array();
   //G.Notman End
   
   return %player;
}

function AIPlayer::spawnOnPath(%name,%path)
{
   //G.Notman Begin
   if (isObject(AiPaths))
   {
      %node = AiPaths.getObject(getRandom(0, AiPaths.getCount()-1));
      %player = AIPlayer::spawn(%name,%node.getTransform());
      return %player;
   }
   //G.Notman End
   
   // Spawn a player and place him on the first node of the path
   if (!isObject(%path))
      return 0;
   %node = %path.getObject(0);
   %player = AIPlayer::spawn(%name,%node.getTransform());
   return %player;
}


//-----------------------------------------------------------------------------
// AIPlayer methods 
//-----------------------------------------------------------------------------
//G.Notman Begin
function AIPlayer::SetOnPath(%this)
{
   %tgt=AiPaths.getObject(getRandom(0, AiPaths.getCount()-1));
   
   if (%tgt == -1)
      return;
   
   messageAll("",'Kork is looking to move to node: %1', %tgt.getID());
   
	//This empties the bots current path
	%this.patharray.empty();
	
   %path=AiPaths.findpath(%this.getposition(), %tgt.getposition(), $AiPaths::Method, $AiPaths::Random);
   
	if(%path == -1)
   {
      echo(%this.getposition());
      echo(%tgt.getposition());
	 	%this.patharray.add(%this.getposition(),0);
	 	
	 	%this.endNode=0;
	   %this.curNode=0;
	   %this.moveToNode(%this.curNode);
	   
	 	return;
   }
   
	%count=getWordCount(%path);
	for (%i=0; %i<%count; %i++)
	{
	   %this.patharray.add(getWord(%path, %i).getposition(), %i);
	}
	%this.patharray.add(%tgt.getposition(), %count);
	
	%this.endNode=%count;
	%this.curNode=0;
	%this.moveToNode(%this.curNode);
}
//G.Notman End


function AIPlayer::followPath(%this,%path,%node)
{
   //G.Notman Begin
   if (isObject(AiPaths))
   {
      %this.stopThread(0);
      %this.SetOnPath();
      return;
   }
   //G.Notman End
   
   // Start the player following a path
   %this.stopThread(0);
   if (!isObject(%path)) {
      %this.path = "";
      return;
   }
   if (%node > %path.getCount() - 1)
      %this.targetNode = %path.getCount() - 1;
   else
      %this.targetNode = %node;
   if (%this.path $= %path)
      %this.moveToNode(%this.currentNode);
   else {
      %this.path = %path;
      %this.moveToNode(0);
   }
}

function AIPlayer::moveToNextNode(%this)
{
   //G.Notman Begin
   if (isObject(AiPaths))
   {
      %this.moveToNode(%this.CurNode + 1);
      return;
   }
   //G.Notman End
   
   if (%this.targetNode < 0 || %this.currentNode < %this.targetNode) {
      if (%this.currentNode < %this.path.getCount() - 1)
         %this.moveToNode(%this.currentNode + 1);
      else
         %this.moveToNode(0);
   }
   else
      if (%this.currentNode == 0)
         %this.moveToNode(%this.path.getCount() - 1);
      else
         %this.moveToNode(%this.currentNode - 1);
}

function AIPlayer::moveToNode(%this,%index)
{
   //G.Notman Begin
   if (isObject(AiPaths))
   {
      %this.CurNode=%index;
      %pos = %this.patharray.getkey(%this.CurNode);
      %this.SetMoveDestination(%pos, false);
      return;
   }
   //G.Notman End
   
   // Move to the given path node index
   %this.currentNode = %index;
   %node = %this.path.getObject(%index);
   %this.setMoveDestination(%node.getTransform(), %index == %this.targetNode);
}


//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------

function AIPlayer::pushTask(%this,%method)
{
   if (%this.taskIndex $= "") {
      %this.taskIndex = 0;
      %this.taskCurrent = -1;
   }
   %this.task[%this.taskIndex] = %method; 
   %this.taskIndex++;
   if (%this.taskCurrent == -1)
      %this.executeTask(%this.taskIndex - 1);
}

function AIPlayer::clearTasks(%this)
{
   %this.taskIndex = 0;
   %this.taskCurrent = -1;
}

function AIPlayer::nextTask(%this)
{
   if (%this.taskCurrent != -1)
      if (%this.taskCurrent < %this.taskIndex - 1)
         %this.executeTask(%this.taskCurrent++);
      else
         %this.taskCurrent = -1;
}

function AIPlayer::executeTask(%this,%index)
{
   %this.taskCurrent = %index;
   eval(%this.getId() @ "." @ %this.task[%index] @ ";");
}


//-----------------------------------------------------------------------------

function AIPlayer::singleShot(%this)
{
   // The shooting delay is used to pulse the trigger
   %this.setImageTrigger(0,true);
   %this.setImageTrigger(0,false);
   %this.trigger = %this.schedule(%this.shootingDelay,singleShot);
}


//-----------------------------------------------------------------------------

function AIPlayer::wait(%this,%time)
{
   %this.schedule(%time * 1000,"nextTask");
}

function AIPlayer::done(%this,%time)
{
   %this.schedule(0,"delete");
}

function AIPlayer::fire(%this,%bool)
{
   if (%bool) {
      cancel(%this.trigger);
      %this.singleShot();
   }
   else
      cancel(%this.trigger);
   %this.nextTask();
}

function AIPlayer::aimAt(%this,%object)
{
   echo("Aim: " @ %object);
   %this.setAimObject(%object);
   %this.nextTask();
}

function AIPlayer::animate(%this,%seq)
{
   //%this.stopThread(0);
   //%this.playThread(0,%seq);
   %this.setActionThread(%seq);
}


//-----------------------------------------------------------------------------

function AIManager::think(%this)
{
   // We could hook into the player's onDestroyed state instead of
   // having to "think", but thinking allows us to consider other
   // things...
   if (!isObject(%this.player))
      %this.player = %this.spawn();
      
   //G.Notman Begin
   %pos=%this.player.getPosition();
   if ((%pos == %this.player.oldPos) && (%this.player.getMoveDestination() !$= "0 0 0"))
      %this.player.getDatablock().onStuck(%this.player);
      
   %this.player.oldPos=%pos;
   //G.Notman End
   %this.schedule(500,think);
}

function AIManager::spawn(%this)
{
   %player = AIPlayer::spawnOnPath("Kork","MissionGroup/Paths/Path1");
   
   if (isObject(%player))
   {
      %player.followPath("MissionGroup/Paths/Path1",-1);

      %player.mountImage(CrossbowImage,0);
      %player.setInventory(CrossbowAmmo,1000);
      return %player;
   }
   else
      return 0;
}






