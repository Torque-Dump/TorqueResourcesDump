$AiPaths::AdjDist=40;
$AiPaths::AdjType="HEURISTIC";
$AiPaths::Method=dijkstra;
$AiPaths::Random = 10;

//Key bind
MoveMap.bindCmd(keyboard, "x", "commandToServer(\'DropNode\');", "");


function LoadPaths()
{
   if (isObject(AiPaths))
   {
      AiPaths.loadAdjs("./" @ $Server::MissionFile @ ".dat");
      AiPaths.RenderAll(true);
   }
}


//Create a new node function
function ServerCmdDropNode(%client)
{
   %position=VectorAdd(%client.player.position, "0 0 1");
   %node = new AIPathNode() 
   {
      dataBlock = PathNode;
      position = %position;
   };
   
   if (!isObject(AiPaths))
   {
      new AiPathGroup(AiPaths) {};
      AiPaths.renderAll(true);
      
      MissionGroup.add(AiPaths);
   }
   
   AiPaths.addObjectSafe(%node, $AiPaths::AdjType, $AiPaths::AdjDist);
}

function SavePaths()
{
  if (isObject(AiPaths))
      AiPaths.saveAdjs("./" @ $Server::MissionFile @ ".dat");
}