datablock AIPathNodeData(PathNode)
{
   Scale = "2 2 2";
   shapeFile = "~/data/shapes/markers/octahedron.dts";
   category="AI";
};

function AIPathNodeData::create(%block)
{
   %obj = new AIPathNode() {
      dataBlock = %block;
   };
   return(%obj);
}