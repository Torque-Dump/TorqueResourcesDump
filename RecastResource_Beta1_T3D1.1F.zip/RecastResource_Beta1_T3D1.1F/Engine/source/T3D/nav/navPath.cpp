//
// T3D 1.1 NavPath class for use with NavMesh, based on the Recast/Detour library.
// Daniel Buckmaster, 2011
//

#include "tRecast.h"
#include "navPath.h"

#include "console/consoleTypes.h"
#include "console/engineAPI.h"

#include "core/stream/bitStream.h"
#include "math/mathIO.h"

#include "scene/sceneRenderState.h"
#include "gfx/gfxDrawUtil.h"
#include "renderInstance/renderPassManager.h"
#include "gfx/primBuilder.h"

extern bool gEditingMission;

namespace Nav {

   /* ------------------------------------------------------------
       ----------------------- NavPath ------------------------- */

   IMPLEMENT_CO_NETOBJECT_V1(NavPath);

   NavPath::NavPath() :
      mFrom(0.0f, 0.0f, 0.0f),
      mTo(0.0f, 0.0f, 0.0f)
   {
      mTypeMask |= MarkerObjectType;

      mMesh = NULL;
      mWaypoints = NULL;

      mFrom.set(0, 0, 0);
      mFromSet = false;
      mTo.set(0, 0, 0);
      mToSet = false;

      mCurIndex = -1;
      mIsLooping = false;
      mAutoUpdate = false;

      mAlwaysRender = false;
      mXray = false;

      mQuery = dtAllocNavMeshQuery();
   }

   NavPath::~NavPath()
   {
      dtFreeNavMeshQuery(mQuery);
      mQuery = NULL;
   }

   bool NavPath::setProtectedMesh(void *obj, const char *index, const char *data)
   {
      NavMesh *mesh = NULL;
      NavPath *object = static_cast<NavPath*>(obj);

      if(Sim::findObject(data, mesh))
         object->mMesh = mesh;

      return false;
   }

   bool NavPath::setProtectedWaypoints(void *obj, const char *index, const char *data)
   {
      SimPath::Path *points = NULL;
      NavPath *object = static_cast<NavPath*>(obj);

      if(Sim::findObject(data, points))
      {
         object->mWaypoints = points;
         object->mIsLooping = points->isLooping();
      }
      else
         object->mWaypoints = NULL;

      return false;
   }

   bool NavPath::setProtectedAutoUpdate(void *obj, const char *index, const char *data)
   {
      NavPath *object = static_cast<NavPath*>(obj);

      if(object->mMesh)
      {
         EventManager *em = object->mMesh->getEventManager();
         if(dAtob(data))
         {
            em->subscribe(object, "NavMeshLoad");
            em->subscribe(object, "NavMeshBuild");
            em->subscribe(object, "NavMeshObstacleAdded");
            em->subscribe(object, "NavMeshObstacleRemoved");
         }
         else
            em->removeAll(object);
      }

      return true;
   }

   bool NavPath::setProtectedFrom(void *obj, const char *index, const char *data)
   {
      NavPath *object = static_cast<NavPath*>(obj);

      if(dStrcmp(data, ""))
      {
         object->mFromSet = true;
         return true;
      }
      else
      {
         object->mFromSet = false;
         return false;
      }
   }

   bool NavPath::setProtectedTo(void *obj, const char *index, const char *data)
   {
      NavPath *object = static_cast<NavPath*>(obj);

      if(dStrcmp(data, ""))
      {
         object->mToSet = true;
         return true;
      }
      else
      {
         object->mToSet = false;
         return false;
      }
   }

   const char *NavPath::getProtectedFrom(void *obj, const char *data)
   {
      NavPath *object = static_cast<NavPath*>(obj);

      if(object->mFromSet)
         return data;
      else
         return StringTable->insert("");
   }

   const char *NavPath::getProtectedTo(void *obj, const char *data)
   {
      NavPath *object = static_cast<NavPath*>(obj);

      if(object->mToSet)
         return data;
      else
         return StringTable->insert("");
   }

   void NavPath::initPersistFields()
   {
      Parent::initPersistFields();

      addGroup("NavPath");

      addProtectedField("from", TypePoint3F, Offset(mFrom, NavPath),
         &setProtectedFrom, &getProtectedFrom,
         "World location this path starts at.");
      addProtectedField("to", TypePoint3F, Offset(mTo, NavPath),
         &setProtectedTo, &getProtectedTo,
         "World location this path should end at.");

      addProtectedField("mesh", TYPEID<NavMesh>(), Offset(mMesh, NavPath),
         &setProtectedMesh, &defaultProtectedGetFn,
         "NavMesh object this path travels within.");
      addProtectedField("waypoints", TYPEID<SimPath::Path>(), Offset(mWaypoints, NavPath),
         &setProtectedWaypoints, &defaultProtectedGetFn,
         "Path containing waypoints for this NavPath to visit.");

      addField("isLooping", TypeBool, Offset(mIsLooping, NavPath),
         "Does this path loop?");
      addProtectedField("autoUpdate", TypeBool, Offset(mAutoUpdate, NavPath),
         &setProtectedAutoUpdate, &defaultProtectedGetFn,
         "If set, this path will automatically replan when its navigation mesh changes.");

      endGroup("NavPath");

      addGroup("NavPath Render");

      addField("alwaysRender", TypeBool, Offset(mAlwaysRender, NavPath),
         "Render this NavPath even when not selected.");
      addField("xray", TypeBool, Offset(mXray, NavPath),
         "Render this NavPath through other objects.");

      endGroup("NavPath Render");
   }

   bool NavPath::onAdd()
   {
      if(!Parent::onAdd())
         return false;

      if(gEditingMission)
         mNetFlags.set(Ghostable);

      resize();

      if(isServerObject())
         plan();

      addToScene();

      return true;
   }

   void NavPath::onRemove()
   {
      Parent::onRemove();

      removeFromScene();
   }

   bool NavPath::init()
   {
      if(!mMesh || !mMesh->getNavMesh())
         return false;

      if(!(mFromSet && mToSet) && !mWaypoints)
         return false;

      if(dtStatusFailed(mQuery->init(mMesh->getNavMesh(), MaxPathLen)))
         return false;

      return true;
   }

   void NavPath::resize()
   {
      if(!mPoints.size())
      {
         mObjBox.set(Point3F(-0.5f, -0.5f, -0.5f),
                     Point3F( 0.5f,  0.5f,  0.5f));
         resetWorldBox();
         setTransform(MatrixF(true));
         return;
      }

      Point3F max(mPoints[0]), min(mPoints[0]), pos(0.0f);
      for(U32 i = 1; i < mPoints.size(); i++)
      {
         Point3F p = mPoints[i];
         max.x = getMax(max.x, p.x);
         max.y = getMax(max.y, p.y);
         max.z = getMax(max.z, p.z);
         min.x = getMin(min.x, p.x);
         min.y = getMin(min.y, p.y);
         min.z = getMin(min.z, p.z);
         pos += p;
      }
      pos /= mPoints.size();
      min -= Point3F(0.5f, 0.5f, 0.5f);
      max += Point3F(0.5f, 0.5f, 0.5f);

      mObjBox.set(min - pos, max - pos);
      MatrixF mat = Parent::getTransform();
      mat.setPosition(pos);
      Parent::setTransform(mat);
   }

   bool NavPath::plan()
   {
      mPoints.clear();

      if(isServerObject())
         setMaskBits(PathMask);

      if(!init())
         return false;

      bool success = true;

      if(mWaypoints && mWaypoints->size())
      {
         Vector<Point3F> locations;
         if(mFromSet)
            locations.push_front(mFrom);
         for(U32 i = 0; i < mWaypoints->size(); i++)
         {
            SceneObject *s = dynamic_cast<SceneObject*>(mWaypoints->at(i));
            if(s) locations.push_back(s->getPosition());
         }
         if(mToSet)
            locations.push_back(mTo);
         U32 s = locations.size();
         U32 l = mIsLooping? s + 1 : s;
         for(U32 i = 1; i < l; i++)
         {
            if(!addPoints(locations[i-1], locations[i%s], &mPoints))
            {
               success = false;
               break;
            }
         }
      }
      else
      {
         success = addPoints(mFrom, mTo, &mPoints);
         if(success && mIsLooping)
            success = addPoints(mTo, mFrom, &mPoints);
      }

      resize();

      return success;
   }

   bool NavPath::addPoints(Point3F pfrom, Point3F pto, Vector<Point3F> *points)
   {
      F32 from[] = {pfrom.x, pfrom.z, -pfrom.y};
      F32 to[] =   {pto.x,   pto.z,   -pto.y};
      F32 extents[] = {1.0f, 1.0f, 1.0f};
      F32 start[3], end[3];
      dtPolyRef startRef, endRef;
      dtQueryFilter filter;
      dtStatus s;
      dtPolyRef path[MaxPathLen];
      S32 pathLen;

      s = mQuery->findNearestPoly(from, extents, &filter, &startRef, start);
      if(dtStatusFailed(s))
         return false;

      s = mQuery->findNearestPoly(to, extents, &filter, &endRef, end);
      if(dtStatusFailed(s))
         return false;

      s = mQuery->findPath(startRef, endRef, start, end, &filter, path, &pathLen, MaxPathLen);
      if(dtStatusFailed(s))
         return false;

      // Convert the tile reference list into a list of points.
      if(pathLen)
      {
         // In case of partial path, make sure the end point is clamped to the last polygon.
         float epos[3] = {to[0], to[1], to[2]};
         if(path[pathLen-1] != endRef)
            mQuery->closestPointOnPoly(path[pathLen-1], to, epos);

         F32 straightPath[MaxPathLen * 3];
         S32 straightPathLen;
         dtPolyRef straightPathPolys[MaxPathLen];
         U8 straightPathFlags[MaxPathLen];

         mQuery->findStraightPath(from, to, path, pathLen,
            straightPath, straightPathFlags,
            straightPathPolys, &straightPathLen, MaxPathLen);

         U32 s = points->size();
         points->increment(straightPathLen);
         for(U32 i = 0; i < straightPathLen; i++)
         {
            F32 *f = straightPath + i * 3;
            (*points)[s + i] = RCtoDTS(f);
         }

         return true;
      }

      return false;
   }

   Point3F NavPath::getNode(S32 idx)
   {
      return Point3F(0,0,0);
   }

   S32 NavPath::getCount()
   {
      return mPoints.size();
   }

   S32 NavPath::getObject(S32 idx)
   {
      if(idx < mPoints.size())
         mCurIndex = idx;
      return getId();
   }

   Point3F NavPath::getPosition() const
   {
      if(mCurIndex < 0)
         return Parent::getPosition();
      return mPoints[mCurIndex];
   }

   const MatrixF& NavPath::getTransform() const
   {
      if(mCurIndex < 0)
         return Parent::getTransform();
      MatrixF mat(true);
      mat.setPosition(mPoints[mCurIndex]);
      return mat;
   }

   void NavPath::onEditorEnable()
   {
      mNetFlags.set(Ghostable);
   }

   void NavPath::onEditorDisable()
   {
      mNetFlags.clear(Ghostable);
   }

   void NavPath::inspectPostApply()
   {
      plan();
   }

   void NavPath::onDeleteNotify(SimObject *obj)
   {
      if(obj == (SimObject*)mMesh)
      {
         mMesh = NULL;
         plan();
      }
   }

   void NavPath::prepRenderImage(SceneRenderState *state)
   {
      ObjectRenderInst *ri = state->getRenderPass()->allocInst<ObjectRenderInst>();
      ri->renderDelegate.bind(this, &NavPath::renderSimple);
      ri->type = RenderPassManager::RIT_Editor;      
      ri->translucentSort = true;
      ri->defaultKey = 1;
      state->getRenderPass()->addInst(ri);
   }

   void NavPath::renderSimple(ObjectRenderInst *ri, SceneRenderState *state, BaseMatInstance *overrideMat)
   {
      if(overrideMat)
         return;

      if(state->isReflectPass() || !(isSelected() || mAlwaysRender))
         return;

      GFXDrawUtil *drawer = GFX->getDrawUtil();
      GFXStateBlockDesc desc;
      desc.setZReadWrite(true, false);
      desc.setBlend(true);
      desc.setCullMode(GFXCullNone);

      if(isSelected())
      {
         drawer->drawCube(desc, getWorldBox(), ColorI(136, 255, 228, 5));
         desc.setFillModeWireframe();
         drawer->drawCube(desc, getWorldBox(), ColorI::BLACK);
      }

      if(!mPoints.size())
         return;

      desc.setZReadWrite(!mXray, false);

      ColorI pathColour(255, 0, 255);

      if(!mIsLooping)
      {
         desc.setFillModeSolid();
         if(mFromSet) drawer->drawCube(desc, Point3F(0.2f, 0.2f, 0.2f), mPoints.first(), pathColour);
         if(mToSet)   drawer->drawCube(desc, Point3F(0.2f, 0.2f, 0.2f), mPoints.last(), pathColour);
      }

      GFXStateBlockRef sb = GFX->createStateBlock(desc);
      GFX->setStateBlock(sb);

      PrimBuild::color3i(pathColour.red, pathColour.green, pathColour.blue);

      PrimBuild::begin(GFXLineStrip, mPoints.size());
      for (U32 i = 0; i < mPoints.size(); i++)
         PrimBuild::vertex3fv(mPoints[i]);
      PrimBuild::end();
   }

   U32 NavPath::packUpdate(NetConnection *conn, U32 mask, BitStream *stream)
   {
      U32 retMask = Parent::packUpdate(conn, mask, stream);

      stream->writeFlag(mIsLooping);
      stream->writeFlag(mAlwaysRender);
      stream->writeFlag(mXray);

      if(stream->writeFlag(mFromSet))
         mathWrite(*stream, mFrom);
      if(stream->writeFlag(mToSet))
         mathWrite(*stream, mTo);

      if(stream->writeFlag(mask & PathMask))
      {
         stream->writeInt(mPoints.size(), 32);
         for(U32 i = 0; i < mPoints.size(); i++)
            mathWrite(*stream, mPoints[i]);
      }

      return retMask;
   }

   void NavPath::unpackUpdate(NetConnection *conn, BitStream *stream)
   {
      Parent::unpackUpdate(conn, stream);

      mIsLooping = stream->readFlag();
      mAlwaysRender = stream->readFlag();
      mXray = stream->readFlag();

      if(mFromSet = stream->readFlag())
         mathRead(*stream, &mFrom);
      if(mToSet = stream->readFlag())
         mathRead(*stream, &mTo);

      if(stream->readFlag())
      {
         mPoints.clear();
         mPoints.setSize(stream->readInt(32));
         for(U32 i = 0; i < mPoints.size(); i++)
         {
            Point3F p;
            mathRead(*stream, &p);
            mPoints[i] = p;
         }
         resize();
      }
   }

   DefineEngineMethod(NavPath, plan, bool, (),,
      "@brief Find a path using the already-specified path properties.")
   {
      return object->plan();
   }

   DefineEngineMethod(NavPath, getObject, S32, (S32 idx),,
      "@brief Set the node index of this path to idx and return this object's id.")
   {
      return object->getObject(idx);
   }

   DefineEngineMethod(NavPath, getCount, S32, (),,
      "@brief Return the number of nodes in this path.")
   {
      return object->getCount();
   }

   DefineEngineMethod(NavPath, onNavMeshBuild, void, (const char *data),,
      "@brief Callback when this path's NavMesh is rebuilt.")
   {
      object->plan();
   }

   DefineEngineMethod(NavPath, onNavMeshLoad, void, (const char *data),,
      "@brief Callback when this path's NavMesh is loaded from a file.")
   {
      object->plan();
   }

};