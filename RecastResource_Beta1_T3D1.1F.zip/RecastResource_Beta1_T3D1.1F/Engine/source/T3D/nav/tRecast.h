//
// Header for Recast integration with Torque 3D 1.1 Final.
// Daniel Buckmaster, 2011
// With huge thanks to:
//    Lethal Concept http://www.lethalconcept.com/
//    Mikko Mononen http://code.google.com/p/recastnavigation/
//

#ifndef _T_RECAST_H_
#define _T_RECAST_H_

#include "math/mPoint3.h"

/// @namespace Nav
/// Groups common functions and classes relating to AI navigation. Specifically,
/// the integration of Recast/Detour with Torque.
namespace Nav {
   static Point3F DTStoRC(F32 x, F32 y, F32 z) {return Point3F(x, z, -y);};
   static Point3F DTStoRC(Point3F point)       {return Point3F(point.x, point.z, -point.y);};
   static Point3F RCtoDTS(F32* xyz)            {return Point3F(xyz[0], -xyz[2], xyz[1]);};
   static Point3F RCtoDTS(F32 x, F32 y, F32 z) {return Point3F(x, -z, y);};
   static Point3F RCtoDTS(Point3F point)       {return Point3F(point.x, -point.z, point.y);};
};

#endif
