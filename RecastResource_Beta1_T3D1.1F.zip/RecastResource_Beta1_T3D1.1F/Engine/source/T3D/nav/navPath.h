//
// T3D 1.1 NavPath class for use with NavMesh, based on the Recast/Detour library.
// Daniel Buckmaster, 2011
//

#ifndef _NAVPATH_H_
#define _NAVPATH_H_

#include "scene/sceneObject.h"
#include "scene/simPath.h"
#include "navMesh.h"
#include "recast/DetourNavMeshQuery.h"

namespace Nav {
   static const U32 MaxPathLen = 1024;
   class NavPath: public SceneObject {
      typedef SceneObject Parent;
   public:
      /// @name NavPath
      /// Functions for planning and accessing the path.
      /// @{

      NavMesh *mMesh;
      SimPath::Path *mWaypoints;

      Point3F mFrom;
      bool mFromSet;
      Point3F mTo;
      bool mToSet;

      bool mIsLooping;
      bool mAutoUpdate;

      bool mAlwaysRender;
      bool mXray;

      /// Plan the path.
      bool plan();

      /// Return world-space position of a path node.
      Point3F getNode(S32 idx);

      /// @}

      /// @name Path interface
      /// These functions are provided to make NavPath behave
      /// similarly to the existing Path class, despite NavPath
      /// not being a SimSet.
      /// @{

      /// Return the number of nodes in this path.
      S32 getCount();

      /// Return our own ID number, and set internal logic to report our
      /// position as being the sub-position represented by idx.
      /// @param[in] idx Path point.
      /// @return Our own id.
      S32 getObject(S32 idx);

      /// @}

      /// @name SceneObject
      /// @{

      static void initPersistFields();

      bool onAdd();
      void onRemove();

      void onEditorEnable();
      void onEditorDisable();
      void inspectPostApply();

      void onDeleteNotify(SimObject *object);

      U32 packUpdate(NetConnection *conn, U32 mask, BitStream *stream);
      void unpackUpdate(NetConnection *conn, BitStream *stream);

      void prepRenderImage(SceneRenderState *state);
      void renderSimple(ObjectRenderInst *ri, SceneRenderState *state, BaseMatInstance *overrideMat);

      /// Returns the position of the currently-selected point along our path.
      Point3F getPosition() const;

      /// Gets the transform of the currently-selected point on the path.
      const MatrixF& getTransform() const;

      DECLARE_CONOBJECT(NavPath);

      /// @}

      NavPath();
      ~NavPath();

   protected:
      enum masks {
         PathMask     = Parent::NextFreeMask << 0,
         NextFreeMask = Parent::NextFreeMask << 1
      };

   private:
      /// Create appropriate data structures and stuff.
      bool init();

      /// Add points of the path between the two specified points.
      bool addPoints(Point3F from, Point3F to, Vector<Point3F> *points);

      dtNavMeshQuery *mQuery;
      S32 mCurIndex;
      Vector<Point3F> mPoints;

      /// Resets our world transform and bounds to fit our point list.
      void resize();

      /// Function used to set mMesh object from console.
      static bool setProtectedMesh(void *obj, const char *index, const char *data);

      /// Function used to set mWaypoints from console.
      static bool setProtectedWaypoints(void *obj, const char *index, const char *data);

      /// Function used to protect auto-update flag.
      static bool setProtectedAutoUpdate(void *obj, const char *index, const char *data);

      /// @name Protected from and to vectors
      /// @{
      static bool setProtectedFrom(void *obj, const char *index, const char *data);
      static bool setProtectedTo(void *obj, const char *index, const char *data);
      static const char *getProtectedFrom(void *obj, const char *data);
      static const char *getProtectedTo(void *obj, const char *data);
      /// @}
   };
};

#endif
