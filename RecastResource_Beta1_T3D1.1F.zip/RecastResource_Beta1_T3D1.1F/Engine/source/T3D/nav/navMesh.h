//
// T3D 1.1 NavMesh class and supporting methods.
// Daniel Buckmaster, 2011
// With huge thanks to:
//    Lethal Concept http://www.lethalconcept.com/
//    Mikko Mononen http://code.google.com/p/recastnavigation/
//

#ifndef _NAVMESH_H_
#define _NAVMESH_H_

#include "scene/sceneObject.h"
#include "collision/concretePolyList.h"
#include "util/messaging/eventManager.h"
#include "navMeshLoader.h"
#include "recast/Recast.h"
#include "recast/DetourNavMesh.h"
#include "tRecast.h"

namespace Nav {
   static void RCtoPolyList(NavModelData *data, AbstractPolyList *list);

   static const int NAVMESHSET_MAGIC = 'M'<<24 | 'S'<<16 | 'E'<<8 | 'T'; //'MSET';
   static const int NAVMESHSET_VERSION = 1;

   struct NavMeshSetHeader
   {
      int magic;
      int version;
      int numTiles;
      dtNavMeshParams params;
   };

   struct NavMeshTileHeader
   {
      dtTileRef tileRef;
      int dataSize;
   };

   /// @class NavMesh
   /// Represents a set of bounds within which a Recast navigation mesh is generated.
   /// @see NavMeshPolyList
   /// @see Trigger
   class NavMesh : public SceneObject {
      typedef SceneObject Parent;
      friend class NavPath;

   public:
      /// @name NavMesh
      /// @{

      /// Initiates the navmesh build process, which includes notifying the
      /// clients and posting an event.
      bool build();

      /// Generates a navigation mesh for the collection of objects in this
      /// mesh. Returns true if successful.
      bool generateMesh();

      /// Save the navmesh to a file.
      bool save();

      /// Load a saved navmesh from a file.
      bool load();

      /// Data file to store this nav mesh in. (From engine executable dir.)
      StringTableEntry mFileName;

      /// Cell width and height.
      F32 mCellSize, mCellHeight;
      /// @name Actor data
      /// @{
      F32 mWalkableHeight,
         mWalkableClimb,
         mWalkableRadius,
         mWalkableSlope;
      /// @}
      /// @name Generation data
      /// @{
      U32 mBorderSize;
      F32 mDetailSampleDist, mDetailSampleMaxError;
      U32 mMaxEdgeLen;
      F32 mMaxSimplificationError;
      static const U32 mMaxVertsPerPoly;
      U32 mMinRegionArea;
      U32 mMergeRegionArea;
      U32 mTileSize;
      /// @}

      /// Save imtermediate navmesh creation data?
      bool mSaveIntermediates;

      /// Get the EventManager for this NavMesh.
      EventManager *getEventManager() { return mEventManager; }

      /// @}

      /// @name SimObject
      /// @{

      virtual void onEditorEnable();
      virtual void onEditorDisable();

      void write(Stream &stream, U32 tabStop, U32 flags);

      /// @}

      /// @name SceneObject
      /// @{

      static void initPersistFields();

      bool onAdd();
      void onRemove();

      enum flags {
         BuildFlag    = Parent::NextFreeMask << 0,
         LoadFlag     = Parent::NextFreeMask << 1,
         NextFreeMask = Parent::NextFreeMask << 2,
      };

      U32 packUpdate(NetConnection *conn, U32 mask, BitStream *stream);
      void unpackUpdate(NetConnection *conn, BitStream *stream);

      /// @}

      /// @name Rendering
      /// @{

      /// Render the Recast navmesh.
      bool mRenderNavmesh;
      /// Render the polygons we sent to Recast as input.
      bool mRenderInputGeom;
      /// Render region contours.
      bool mRenderContours;

      void prepRenderImage(SceneRenderState *state);
      void render(ObjectRenderInst *ri, SceneRenderState *state, BaseMatInstance *overrideMat);

      /// @}

      NavMesh();
      ~NavMesh();
      DECLARE_CONOBJECT(NavMesh);

   protected:

      dtNavMesh const* getNavMesh() { return nm; }

   private:
      /// Stores the input geometry. */
      ConcretePolyList mInPolys;

      /// @name Intermediate data
      /// @{

      rcHeightfield        *hf;
      rcCompactHeightfield *chf;
      rcContourSet         *cs;
      rcPolyMesh           *pm;
      rcPolyMeshDetail     *pmd;
      dtNavMesh            *nm;

      /// Free all stored working data.
      void freeIntermediates();

      /// @}

      /// Dummy var used for build button.
      bool mBuild;
      /// Called when the 'build' box is checked in the editor.
      static bool editorBuildFlag(void *obj, const char *index, const char *data);

      /// Used to perform non-standard validation. detailSampleDist can be 0, or >= 0.9.
      static bool setProtectedDetailSampleDist(void *obj, const char *index, const char *data);

      /// Use this object to manage update events.
      EventManager *mEventManager;
   };
};

#endif
