//weaponCore.cs
//Phantom139

$BlankPath = "game/data/weaponHud/Empty.png";

//handles all weapon ops

function serverCmdSwitchWeapons(%client) { switchWeapons(%client.player); }

function switchWeapons(%player) {
   if(!isObject(%player) || %player.getState() $= "dead") {
      //pressing the switch gun key while dead? I think not!
      return;
   }
   if(%player.weaponLock) {
      return;
   }
   //
   if(%player.WPS $= "Primary") {
      if(isSet(%player.secondaryWeapon)) {
         %player.mountImage(%player.secondaryWeapon, 0);
         %player.WPS = "Secondary";
      }
   }
   else {
      if(isSet(%player.primaryWeapon)) {
         %player.mountImage(%player.primaryWeapon, 0);
         %player.WPS = "Primary";
      }
   }
}

function actionKeyToPickup(%player, %item) {
   if(!isObject(%player) || %player.getState() $= "dead") {
      return;
   }
   
   //must reload before picking stuff up
   if(%player.weaponLock) {
      return;
   }
   
   if(!isObject(%item)) {
      return;
   }
   // do I already have one of these?
   if(%player.primaryWeapon $= %item.getDatablock().image) {
      return;
   }
   if(%player.seconaryWeapon $= %item.getDatablock().image) {
      return;
   }
   //
   if(!isSet(%player.WPS)) {
      %player.WPS = "Primary";
   }
   //
   %slot = %player.WPS;
   if(%slot $= "Primary") {
      %num = 1;
   }
   else {
      %num = 2;
   }
   //"pick" up the new weapon
   weaponPickup(%player, %item.getDatablock().image, %num, %item.activeAmmo, %item.storedAmmo);
   %item.delete();
}

function weaponPickup(%player, %block, %slotNum, %activeAmmo, %reserveAmmo) {
   if(!isObject(%player) || %player.getState() $= "dead") {
      //pressing the switch gun key while dead? I think not!
      return;
   }
   //
   if(isSet(%activeAmmo) && !%block.usesEnergy) {
      %ammoSet = %block.ammo;
      %player.setInventory(%ammoSet, %activeAmmo);
   }
   
   if(isSet(%reserveAmmo) && !%block.usesEnergy) {
      %player.addGunAmmo(%block, %reserveAmmo);
   }
   else {
      %player.addGunAmmo(%block, 0); //read 0
   }
   //

   //no weapons yet?
   if(!isSet(%player.primaryWeapon) && !isSet(%player.secondaryWeapon)) {
      //set it as a primary, regardless of slot request
      %player.primaryWeapon = %block;
      %player.WPS = "Primary";
      //update
      commandToClient(%player.client, 'UpdateWeapons', %player.primaryWeapon.WH_imageFile, $BlankPath);
      commandToClient(%player.client, 'SetWeapNames', %player.primaryWeapon.WeaponName, "NO WEAPON");
      if(%player.primaryWeapon.usesEnergy) {
         commandToClient(%player.client, 'UpdateAmmo_Primary', "ENERGY");
      }
      else {
         commandToClient(%player.client, 'UpdateAmmo_Primary', %player.getInventory(%player.primaryWeapon.ammo)@"/"@%player.getReserveAmmo(%player.primaryWeapon));
      }
      commandToClient(%player.client, 'UpdateAmmo_Secondary', "");
   }
   //No Secondary yet?
   else if(!isSet(%player.secondaryWeapon)) {
      %player.secondaryWeapon = %block;
      commandToClient(%player.client, 'UpdateWeapons', %player.primaryWeapon.WH_imageFile, %player.secondaryWeapon.WH_imageFile);
      //primary:
      if(%player.primaryWeapon.usesEnergy) {
         commandToClient(%player.client, 'UpdateAmmo_Primary', "ENERGY");
      }
      else {
         commandToClient(%player.client, 'UpdateAmmo_Primary', %player.getInventory(%player.primaryWeapon.ammo)@"/"@%player.getReserveAmmo(%player.primaryWeapon));
      }
      //secondary:
      if(%player.secondaryWeapon.usesEnergy) {
         commandToClient(%player.client, 'UpdateAmmo_Secondary', "ENERGY");
      }
      else {
         commandToClient(%player.client, 'UpdateAmmo_Secondary', %player.getInventory(%player.secondaryWeapon.ammo)@"/"@%player.getReserveAmmo(%player.secondaryWeapon));
      }
      //end
      commandToClient(%player.client, 'SetWeapNames', %player.primaryWeapon.WeaponName, %player.secondaryWeapon.WeaponName);
   }
   else {
      switch(%slotNum) {
         case 1:
            if(isSet(%player.primaryWeapon)) {
               //throw the weapon
               %player.doWeaponRemoval();
            }
            //set New weapon to the new DB
            %player.primaryWeapon = %block;
         case 2:
            if(isSet(%player.secondaryWeapon)) {
               //throw the weapon
               %player.doWeaponRemoval();
            }
            //set New weapon to the new DB
            %player.secondaryWeapon = %block;
      }
      commandToClient(%player.client, 'UpdateWeapons', %player.primaryWeapon.WH_imageFile, %player.secondaryWeapon.WH_imageFile);
      //primary:
      if(%player.primaryWeapon.usesEnergy) {
         commandToClient(%player.client, 'UpdateAmmo_Primary', "ENERGY");
      }
      else {
         commandToClient(%player.client, 'UpdateAmmo_Primary', %player.getInventory(%player.primaryWeapon.ammo)@"/"@%player.getReserveAmmo(%player.primaryWeapon));
      }
      //secondary:
      if(%player.secondaryWeapon.usesEnergy) {
         commandToClient(%player.client, 'UpdateAmmo_Secondary', "ENERGY");
      }
      else {
         commandToClient(%player.client, 'UpdateAmmo_Secondary', %player.getInventory(%player.secondaryWeapon.ammo)@"/"@%player.getReserveAmmo(%player.secondaryWeapon));
      }
      commandToClient(%player.client, 'SetWeapNames', %player.primaryWeapon.WeaponName, %player.secondaryWeapon.WeaponName);
   }
   //mount new gun
   %player.mountImage(%block, 0);
   %player.testReload();
}

//Weapon Reloads, Reserves
function Player::addGunAmmo(%this, %image, %newAmmo) {
   %this.inv[%image.reserveName] = %newAmmo;     //only add to the reserves :P
   if(%image $= %this.primaryWeapon) {
      commandToClient(%this.client, 'UpdateAmmo_Primary', %this.getInventory(%this.primaryWeapon.ammo)@"/"@%this.getReserveAmmo(%image));
   }
   if(%image $= %this.secondaryWeapon) {
      commandToClient(%this.client, 'UpdateAmmo_Secondary', %this.getInventory(%this.secondaryWeapon.ammo)@"/"@%this.getReserveAmmo(%image));
   }
}

function Player::getReserveAmmo(%this, %image) {
   return %this.inv[%image.reserveName];
}

function Player::getMaxReserve(%this, %image) {
   return %image.maxAmmo;
}

function Player::doWeaponRemoval(%this) {
   //get ammo held by the player + reserves
   %weapon = %this.getMountedImage($WeaponSlot);
   %ammoHeld = %this.getInventory(%weapon.ammo);
   //
   %reserves = %this.getReserveAmmo(%weapon);
   //make the item
   %item = new Item() {
      datablock = %weapon.item;
      position = %this.getPosition();
   };
   MissionCleanup.add(%item);
   
   //
   if(%this.isAI) {
      //generate two random values
      %item.activeAmmo = getRandom(1, %weapon.clipSize);
      %this.storedAmmo = getRandom(1, %weapon.maxAmmo);
   }
   else {
      %item.activeAmmo = %ammoHeld;
      %item.storedAmmo = %reserves;
   }
}

function Player::testReload(%this) {
   //we need to check what is currently used.
   if(%this.weaponLock) {
      return;
   }
   %weapon = %this.getMountedImage($WeaponSlot);
   if(%weapon.usesEnergy) {   //energy weapon = no reload
      return;
   }
   //is the active ammo 0?
   if(%this.getInventory(%weapon.ammo) <= 0) {
      //do I have ammo to reload with?
      if(%this.getReserveAmmo(%weapon) > 0) {
         %this.doReload();
      }
   }
}

function Player::doReload(%this) {
   %weapon = %this.getMountedImage($WeaponSlot);
   //set the player to locked mode (cannot use weapons)
   %this.weaponLock = true;
   //To-Do: Perform Reload Animation Now
   
   //
   %this.schedule(%weapon.reloadTime, finishReload);
}

function Player::finishReload(%this) {
   %weapon = %this.getMountedImage($WeaponSlot);
   %c_size = %weapon.clipSize;
   %resr = %this.getReserveAmmo(%weapon);
   //check reserve size here.
   if(%resr > %c_size) {
      %deduct = %c_size;
   }
   else {
      %deduct = %resr;
   }
   //
   %this.addGunAmmo(%weapon, %resr-%deduct);
   %this.setInventory(%image.ammo, %resr-%deduct);
   //unlock the weapons
   %this.weaponLock = false;
}
