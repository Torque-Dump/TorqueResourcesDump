//ActionLoop.cs
//Phantom139

//Handles operations of in game world
$ActionList = $TypeMasks::ItemObjectType | $TypeMasks::VehicleObjectType | $TypeMasks::InteriorObjectType;

function PlayerActionLoop(%object) {
   if(!isObject(%object) || %object.getState() $= "dead") {
      return;
   }
   // AI? We have our own action loop, so we don't use this
   if(%object.isAI) {
      return;
   }
   //
   %sP = %object.getPosition();
   InitContainerRadiusSearch(%sP, 25, $ActionList);
   while ((%targetObject = containerSearchNext()) != 0) {
      //echo(%targetObject);
      if(!isSet(%targetObject.interiorFile)) {
         if(!isSet(%targetObject.actionRadius)) {
            if(isSet(%targetObject.getDatablock().actionRadius)) {
               %targetObject.actionRadius = %targetObject.getDatablock().actionRadius;
            }
         }
         if(!isSet(%targetObject.actionType)) {
            if(isSet(%targetObject.getDatablock().actionType)) {
               %targetObject.actionType = %targetObject.getDatablock().actionType;
            }
         }
      }
      
      if(isSet(%targetObject.actionRadius)) {
         %tP = %targetObject.getPosition();
         if(vectorDist(%sP, %tP) <= %targetObject.actionRadius) {
            checkPlayerAction(%object, %targetObject);
            %object.actionLoop = schedule(350, 0, "PlayerActionLoop", %object);
            return;
         }
      }
   }
   //
   %object.actionLoop = schedule(350, 0, "PlayerActionLoop", %object);
}

function checkPlayerAction(%player, %potentialObject) {
   if(!isObject(%player) || %player.getState() $= "dead") {
      return;
   }
   if(!isObject(%potentialObject)) {
      return; //gone
   }
   if(%player.isMounted()) {
      return; //no actions for a mounted player.
   }
   // interiors
   //echo(%potentialObject.getDatablock());
   if(isSet(%potentialObject.interiorFile)) {
      %player.actionObject = %potentialObject;
      %AM = strReplace(%potentialObject.actionMessage, "%usn", %potentialObject.actionEffect);
   }
   // vehicles

   else if(%potentialObject.getDatablock().category $= "Vehicle") {
      %player.actionObject = %potentialObject;
      %AM = strReplace(%potentialObject.getDatablock().actionMessage, "%vnm", %potentialObject.getDatablock().vehicleName);
   }
   // weapons
   else if(%potentialObject.getDatablock().className $= "Weapon") {
      //am I already holding one?
      if(%player.weaponLock) {
         return;
      }
      if((strcmp(%player.primaryWeapon, %potentialObject.getDatablock().image) == 0) ||
         (strcmp(%player.secondaryWeapon, %potentialObject.getDatablock().image) == 0)) {
         return;
      }
      //
      %player.actionObject = %potentialObject;
      %AM = strReplace(%potentialObject.getDatablock().actionMessage, "%pun", %potentialObject.getDatablock().pickUpName);
   }
   //
   commandToClient(%player.client, 'potentialAction', %potentialObject.actionType, %AM);
   //
}

//handles the action of the player
function serverCmdActionKey(%client) { pressActionKey(%client.player); }

function pressActionKey(%player) {
   if(!isObject(%player) || %player.getState() $= "dead") {
      return;
   }
   %potential = %player.actionObject;
   if(!isObject(%potential)) {
      return; //gone
   }
   //
   if(!isSet(%potential.actionRadius)) {
      if(isSet(%potential.getDatablock().actionRadius)) {
         %potential.actionRadius = %potential.getDatablock().actionRadius;
      }
   }
   if(!isSet(%potential.actionType)) {
      if(isSet(%potential.getDatablock().actionType)) {
         %potential.actionType = %potential.getDatablock().actionType;
      }
   }
   //
   if(vectorDist(%player.getPosition(), %potential.getPosition()) > %potential.actionRadius) {
      return;
   }
   //

   %aType = %potential.actionType;
   //echo("Action Key on: "@%potential@": "@%aType@"");
   switch$(%aType) {
      case "Weapon":
         actionKeyToPickup(%player, %potential);
      case "Switch":
         actionKeyToSwitch(%player, %potential);
      case "Vehicle":
         actionKeyToVehicle(%player, %potential);
   }
}

function actionKeyToSwitch(%player, %object) {
   if(!isObject(%player) || %player.getState() $= "dead") {
      return;
   }
   if(!isObject(%object)) {
      return;
   }
   //use it!
   eval(%object.actionFunction);
   //
}

//
function actionKeyToVehicle(%player, %object) {
   if(!isObject(%player) || %player.getState() $= "dead") {
      return;
   }
   if(!isObject(%object)) {
      return;
   }
   //am I already piloting this?
   if(%player.isMounted()) {
      return;
   }
   //check for an open seat on the vehicle.
   %seat = findEmptySeat(%object, %object.getDatablock());
   %object.mountObject(%player, %seat);
}
//
