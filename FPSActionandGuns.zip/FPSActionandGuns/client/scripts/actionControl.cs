function actionPush(%message, %time) {
   cancel($ActionDrop);
   if(!isSet($ActionDrop)) {
      Canvas.pushDialog(actionGUI);
   }

   ActionText.setText( "<just:center><color:00CD00>" @ %message );

   $ActionDrop = Canvas.schedule(%time*1100, popDialog, actionGUI);
}

function actionGUI::onWake(%this) {

}

function actionGUI::onSleep(%this) {
   $ActionDrop = "";
}

function clientCMDpotentialAction(%actionType, %message) {
   // find action Key
   %actionKey = getField(moveMap.getBinding("keyboardActionKey"), 1);
   %messageF = strReplace(%message, "%k", %actionKey);
   //
   actionPush(%messageF, 1);
}
