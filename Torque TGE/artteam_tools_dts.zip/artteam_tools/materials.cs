
new Material(mcolors_tools)
{
   baseTex[0] = "colors_tools";
   emissive[0] = true;
   glow[0] = true;
};
