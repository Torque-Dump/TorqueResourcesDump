datablock StaticShapeData(arrow_redwhite)
{
   class = "animateme";
   category = "artteam_tools";
   shapeFile = "~/data/shapes/artteam_tools/arrow_redwhite.dts"; 
};

datablock StaticShapeData(arrow_orangeblue : arrow_redwhite )
{
   shapeFile = "~/data/shapes/artteam_tools/arrow_orangeblue.dts"; 
};

datablock StaticShapeData(arrow_greenpurple : arrow_redwhite )
{
   shapeFile = "~/data/shapes/artteam_tools/arrow_greenpurple.dts"; 
};

datablock StaticShapeData(arrow_bluepink : arrow_redwhite )
{
   shapeFile = "~/data/shapes/artteam_tools/arrow_bluepink.dts"; 
};

datablock StaticShapeData(arrow_blackwhite : arrow_redwhite )
{
   shapeFile = "~/data/shapes/artteam_tools/arrow_blackwhite.dts"; 
};

datablock StaticShapeData(arrow__yellow : arrow_redwhite )
{
   shapeFile = "~/data/shapes/artteam_tools/arrow__yellow.dts"; 
};

datablock StaticShapeData(arrow__white : arrow_redwhite )
{
   shapeFile = "~/data/shapes/artteam_tools/arrow__white.dts"; 
};

datablock StaticShapeData(arrow__red : arrow_redwhite )
{
   shapeFile = "~/data/shapes/artteam_tools/arrow__red.dts"; 
};

datablock StaticShapeData(arrow__purple : arrow_redwhite )
{
   shapeFile = "~/data/shapes/artteam_tools/arrow__purple.dts"; 
};

datablock StaticShapeData(arrow__orange : arrow_redwhite )
{
   shapeFile = "~/data/shapes/artteam_tools/arrow__orange.dts"; 
};

datablock StaticShapeData(arrow__lblue : arrow_redwhite )
{
   shapeFile = "~/data/shapes/artteam_tools/arrow__lblue.dts"; 
};

datablock StaticShapeData(arrow__green : arrow_redwhite )
{
   shapeFile = "~/data/shapes/artteam_tools/arrow__green.dts"; 
};

datablock StaticShapeData(arrow__blue : arrow_redwhite )
{
   shapeFile = "~/data/shapes/artteam_tools/arrow__blue.dts"; 
};


function animateme::onAdd(%this,%obj)
{   
      %obj.playThread(0,"ambient");
}  