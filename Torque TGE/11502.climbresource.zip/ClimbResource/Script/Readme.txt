Copy ClimableObjects.cs to starter.fps\server\scripts 

and 

exec("./ClimbableObjects.cs"); in game.cs or overwrite your unmodified game.cs with mine.