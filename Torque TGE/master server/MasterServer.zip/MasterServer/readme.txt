This master server is a resource written by:

Thomas "Man of Ice" Lund 

, and preseted to the GarageGames community under resource:

http://www.garagegames.com/index.php?sec=mg&mod=resource&page=view&qid=5962

It is perfectly serviceable, but if you intend to provide a master server service on a regular basis, I strongly suggest investigating other more secure and robust soltions.

Note: This notice should not be read as disparging this excellent resource in any way.