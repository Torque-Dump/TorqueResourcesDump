//-----------------------------------------------------------------------------
// V12 Engine
// 
// Copyright (c) 2001 GarageGames.Com
// Portions Copyright (c) 2001 by Sierra Online, Inc.
//-----------------------------------------------------------------------------

#ifndef _HUDBITMAPCTRL_H_
#define _HUDBITMAPCTRL_H_

#include "hud/hudObject.h"
#include "console/consoleTypes.h"
#include "hud/hudGLEx.h"


/**
 * This HUD control is used to display bitmaps on the HUD
 */
class HudBitmapCtrl : public HudObject {
   private:
      typedef HudObject   Parent;

   protected:

      TextureHandle     mBitmapHandle;
      
   public:
      
      HudBitmapCtrl();
      
      void setBitmap( const char *bitmap );
      
      void inspectPostApply();
      
      void onPreRender();
      void onRender( Point2I offset, const RectI & updateRect, GuiControl * firstResponder );
      
      bool onWake();
      void onSleep();
      
      StringTableEntry     mBitmap;
      bool                 mAutoResize;
      bool                 mAutoCenter;
      bool                 mFlipVert;
      bool                 mFlipHorz;   
      
      static void initPersistFields();
      
      DECLARE_CONOBJECT( HudBitmapCtrl );
};

#endif

// hudBitmapCtrl.h