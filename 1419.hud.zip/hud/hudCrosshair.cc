//-----------------------------------------------------------------------------
// V12 Engine
// 
// Copyright (c) 2001 GarageGames.Com
// Portions Copyright (c) 2001 by Sierra Online, Inc.
//-----------------------------------------------------------------------------

#include "gui/guiCanvas.h"
#include "hud/hudBitmapCtrl.h"
#include "game/gameConnection.h"
#include "game/camera.h"

/**
 * This is simply a HudBitmapCtrl that displays the crosshair
 * in the center of the screen
 */
class HudCrosshairCtrl : public HudBitmapCtrl {
   private:
      typedef HudBitmapCtrl Parent;
      
   public:   
      HudCrosshairCtrl();

      void onRender( Point2I, const RectI &, GuiControl * );

      DECLARE_CONOBJECT( HudCrosshairCtrl );
};

IMPLEMENT_CONOBJECT( HudCrosshairCtrl );

/**
 * Constructor
 */ 
HudCrosshairCtrl::HudCrosshairCtrl() {
   mAutoResize = true;
   mAutoCenter = true;
}

/**
 * Method called to render the HUD object
 *
 * @param offset Basically the corner to begin drawing at
 * @param updateRect The rectangle that this object updates
 * @param firstResponder ?
 */
void HudCrosshairCtrl::onRender( Point2I offset, const RectI &updateRect, GuiControl *firstResponder ) {
   if( !bool( mBitmapHandle ) )
      return;

   // Sanity check for parent control
   GuiControl * parent = getParent();
   if( !parent )
      return;
   
   // Sanity check for game connection
   GameConnection *con = GameConnection::getServerConnection();
   if(!con)
      return;

   // Check for first person
   if( !con->isFirstPerson() )
      return;

   // Check if we are controling another object
   if( dynamic_cast<Camera*>( con->getControlObject() ) )
      return;
      
   Parent::onRender( offset, updateRect, firstResponder );
}

// hudCrosshair.cc