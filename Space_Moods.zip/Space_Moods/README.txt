The Pack:
Space_Moods.zip

The Size:
7Meg

Hey All,

Was playing around with a new Ambient Sounds pack I'm working on 
(see http://www.garagegames.com/products/89/ for what I'm talking about). 
The new pack will be a lot more spacey then the first Ambient Sounds pack 
I did for GG here a few years ago. I used Reason 3 then, I use Reason 4 
for some of my work now but mainly use Live 7 with a new thing I found out 
about a few years ago, a VST plug-in. They are amazing works. 

You can do anything with sound now, so I'm working hard on my new pack that uses Reason 4,
Live 7 w/ VSTs of all kinds for sound kits and FL Studio when I can.
I plan on getting their new Poizone 2.1 and Morphine for my plug-in kits to help 
make even more deep sounds and packs.

I have released the new mini-pack for free as donation ware.
If you like it and use it and make money from it in your game or project
then you need to donate to my efforts. If you do not like donation ware,
then please don't download. Pretty simple actually.
I am trying to make a living off my music making talents and its a hard go
but I'm not one to give up. I am giving this a shot since its easier to get my stuff 
out to the markets and more people see/hears it. I'm used to the pay to play thing but
since I have some 8 Ambient Sounds Packs out thus far (1 here and the other 7 
in redesign to be released in one mega DVD collection coming this Summer, 2008;
More on that later...), I figured it would be smart to release this to those who would use it 
and get some use from it.

I have so many projects on the table right now I can't keep up with everything.
So here is my efforts so far on the new pack. I plan on releasing this pack through
another company (or maybe again through GG?) later this year to do the marketing on it for me,
then I'll begin v1.0 of the new Magic Sweeper and T-Space VST kits I'm working on for Live.
I plan to also have those released by years end if all goes to plan. So please watch for my other
projects coming soon... Oh and for those of you who have been following my game... TORQUE TITANS,
its complete on the staff who is helping me make the game.
We're using the TGEA for the project and again I'll release more on that as it comes in...

 Enjoy and take care all...

Will Zettler
dlstorminc@yahoo.com
Waskom, Tx
