//-----------------------------------------------------------------------------
// Screen Space Image Optimization
// Copyright (C) 2011 Saitta Alfio - Collateral Studios
// http://www.garagegames.com/community/resources/view/21049
//-----------------------------------------------------------------------------

$ImageOptFX::Desaturation = 0.39;
$ImageOptFX::Toned = 0.098;
$ImageOptFX::LightColor = "0.992157 0.996078 0.87451";
$ImageOptFX::DarkColor =  "0.2 0.2 0.2";
$ImageOptFX::Gamma = 0.60;
$ImageOptFX::ScaleR = 0.0;
$ImageOptFX::ScaleG = 0.0;
$ImageOptFX::ScaleB = 0.1;
$ImageOptFX::Sharpen = 0.5;

singleton ShaderData( ImageOptShader )
{
   DXVertexShaderFile 	= "shaders/common/postFx/postFxV.hlsl";
   DXPixelShaderFile 	= "shaders/common/postFx/ImageOpt.hlsl";

   pixVersion = 2.0;   
};

singleton PostEffect( ImageOptFX )
{
   isEnabled = true;
   allowReflectPass = false;
   
   renderTime = "PFXAfterDiffuse";
   renderPriority = 0.1;
      
   shader = ImageOptShader;
   stateBlock = ImageOptStateBlock;
   
   texture[0] = "$backBuffer";    
};

singleton GFXStateBlockData( ImageOptStateBlock : PFX_DefaultStateBlock )
{
   samplersDefined = true;
   samplerStates[0] = SamplerClampLinear; 
};

function ImageOptFX::preProcess( %this )
{   
   %this.targetScale = $ImageOptFX::resolutionScale SPC $ImageOptFX::resolutionScale;
}

function ImageOptFX::setShaderConsts( %this )
{
   %this.setShaderConst( "$Desaturation", $ImageOptFX::Desaturation );
   %this.setShaderConst( "$Toned", $ImageOptFX::Toned );
   %this.setShaderConst( "$LightColor", $ImageOptFX::LightColor );
   %this.setShaderConst( "$DarkColor", $ImageOptFX::DarkColor );
   
   %this.setShaderConst( "$Gamma", $ImageOptFX::Gamma );

   %this.setShaderConst( "$ScaleR", $ImageOptFX::ScaleR );
   %this.setShaderConst( "$ScaleG", $ImageOptFX::ScaleG );
   %this.setShaderConst( "$ScaleB", $ImageOptFX::ScaleB );

   %this.setShaderConst( "$Sharpen", $ImageOptFX::Sharpen );
}