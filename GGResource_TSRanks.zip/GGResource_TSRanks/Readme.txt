Hello Fellow GG Users!

This is my resource on implementing a simple rank/progression system.

Please pardon the massive amount of comments, and other Tribes 2 Related stuff in here, I pretty much used
the code I had already made for Tribes 2 for this system (who wouldn't use their working code :) )

* All files belong in the server folder, you will need to implement your own form of client GUIS to show 
client rank info

****************************************************************************************
The code entry point for the load process is this function:
LoadUniversalRank(%client);

It will not correctly function until part 2 is implemented, so hold on for that one.
****************************************************************************************
All Global Vars of Importance are In: WebSupport.cs
****************************************************************************************


Anyways, I do need to point out a few things with this specific resource.

* It requires a network key to have the data correctly save to the server (Part 2)

* Script Objects Are Used:
** Why use a Script Object?
** Script objects are very powerful tools in my mind, not to mention the greatest weapon that these beautiful
objects have: %script.save(%file);. Yes, they may be insecure alone, but with some crypto over it, it should be 
fine.

* What's with all the 'PGD' stuff?
** PGD is the acronym for my game dev. group: Phantom Games Development, but I mostly used it in tribes 2 for
the connection service acronym: "PGD Connect", I also use it to symbolize messages sent down from the web server.

* High Number Calculations:
** As everyone is aware, torque's counting ends at 1 million, why, I don't know, but I am aware of a numbers over
a million resource out there, so you may want to implement that. My hacky method is in place, which takes any
value sent to it over 999,999, and stores a seperate var, named millionxp to increase by 1, and then to reset
the value variable to 0.

* Errors:
** I always have a feeling that I've missed something, so please point out any errors you find, if you have the
fix for it, please submit those too, a resource only works if everyone can properly use it.