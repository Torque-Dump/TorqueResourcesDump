//UniversalRanks.cs
//Coded: 1-2-10
//By: Phantom139, And alot of improvements by Signal360

//This script handles all TCP Object related code for the Universal Rank System
//It will access the server to check for a universal rank file, if it exists, it
//deletes the local file and downloads the unioversal one for use, if it does not
//exist it scans the server to see if it is a "Main" Server. If the server is "Main",
//The rank is saved to the universal server for usage in other servers.

//------------------------------------------------------------------------
//This first part of the script is the IsServerMain Handler.
//It Downloads the server key from PGD and verifies it to the key
//The Server Host Specifies.
//------------------------------------------------------------------------
$ServerType = "Satellite Server";
$PGDDebugMode = 0;
function currentEpochTime() {
   return getUTC();
}

function CreateHash(%user, %password, %name) {
   //%salt  = base64_encode(formatTimeString("dd.mm.yy-nn")); //prevent a replay attack?
   %epoch = currentEpochTime();   //now using epoch time for a better salt
   %salt = base64encode(getSubStr(%epoch, 0, strLen(%epoch)-3)); // removing last second to prevent problems
   %nonce = sha1(%user @ %name);                               // if there is a small delay, it also means
   %str = %user @ ":" @ %password;                                // the hash will be different every 10 secs.
   %hash = sha1(%nonce @ sha1(%str) @ %salt);
   return %hash;
}

function IsServerMain() {
   if($ServerType $= "Core Server")
      return 1;
   else
      return 0;
}
function GetKey(){CheckCore();}

function CheckCore() {
   if (!isObject(CoreValidation))
      %Downloader = new TCPObject(CoreValidation);
   else
      %Downloader = CoreValidation;
   %Downloader.connect($PGDServer @ ":" @ $PGDPort);
}

function CoreValidation::onConnected(%this) {
   %user     = getField($TWM2::PGDCredentials, 0);
   %password = getField($TWM2::PGDCredentials, 1);
   %name     = sha1($Host::GameName);
   %hash     = CreateHash(%user, %password, %name);

   %this.schedule(15000, "disconnect");
   %sep = getRandomSeparator(16);
   %loc = $PGDKeyHandler;
   %header1 = "POST" SPC %loc SPC "HTTP/1.1\r\n";
   %host = "Host: "@$PGDServer@"\r\n";
   %header2 = "Connection: close\r\nUser-Agent: Tribes 2\r\n";
   %contType = "Content-Type: multipart/form-data; boundary="@%sep@"\r\n";

   %userReq = "--"@%sep@"\r\nContent-Disposition: form-data; name=\"user\"\r\n\r\n"@%user;
   %hashReq = "--"@%sep@"\r\nContent-Disposition: form-data; name=\"hash\"\r\n\r\n"@%hash;
   %nameReq = "--"@%sep@"\r\nContent-Disposition: form-data; name=\"gname\"\r\n\r\n"@%name;

   %payload = %nameReq@"\r\n"@
              %hashReq@"\r\n"@
              %userReq@"\r\n"@
              "--"@%sep@"--";

   %qlen = strLen(%payload);
   %contentLeng = "Content-Length: "@%qlen@"\r\n\r\n";
   %query = %header1@
            %host@
            %header2@
            %contType@
            %contentLeng@
            %payload;
   %this.send(%query);
}

function CoreValidation::onLine(%this, %line) {
   if(strStr(%line, "pgd_debug") != -1) {
      if($PGDDebugMode == 1) {
         MessageDevs("\c5PGD DEBUG:" SPC %line);
      }
   }
   if (trim(%line) $= "yes")
      $ServerType = "Core Server";
   else if (trim(%line) $= "no")
      $ServerType = "Satellite Server";
}

function CoreValidation::onConnectFailed(%this) {
   //error("** No Connection was made.");
   $ServerType = "Satellite Server";
   schedule(5000, 0, "CheckCore");
}

function CoreValidation::onDisconnect(%this) {
   %this.schedule(1000, delete);
}

//------------------------------------------------------------------------
//This second part of the script handles the downloading of existing files
//It uses the PGDISFile from UniversalSupport.cs as well as scans for a current
//file.
//------------------------------------------------------------------------

function LoadUniversalRank(%client) {
   %client.donotupdate = 1;
   //IS FILE
   if(!PGD_IsFile("Data/"@%client.guid@"/Ranks/"@$GAMENAME@"/Saved.data")) {
      %client.donotupdate = 0;
      messageClient(%client, 'msgPGDRequired', "\c5PGD: PGD Connect confirms you do not have a universal rank.");
      messageClient(%client, 'msgPGDRequired', "\c5PGD: Play on a main server to start progressing one today!");
      messageClient(%client, 'msgPGDRequired', "\c5PGD: Loading your local rank file for the time being...");
      schedule(500, 0, "LoadClientRankfile", %client);
      return 1;
   }
   //Passed, we have a universal rank, time to loady :)
   %server = $PGDServer@":"@$PGDPort;
   if (!isObject(RankGrabber)) {
      %Downloader = new HTTPObject(RankGrabber);
   }
   else {
      %Downloader = RankGrabber;
   }
   //If the server crashes here, let everyone know why
   MessageClient(%client, 'msgAccess', "\c5PGD: Your Universal Rank file will now be downloaded.");
   echo("Client:" SPC %client.namebase SPC "needs universal rank load. It will be stored locally.");
   //Cache Create
   %file = "/public/Univ/Data/"@%client.guid@"/Ranks/"@$GAMENAME@"/Saved.data";

   //Downloader
   $Buffer[%client] = -1;
   %Downloader.client = %client;
   %Downloader.get(%server, %file);
   %Downloader.schedule(15000, "disconnect");
}

function RankGrabber::onLine(%this, %line) {

   if (!StrStr(%line, "404")) {
      messageClient(%this.client, 'MsgSuppressed', "\c5PGD: Your rank does not appear to exist, please contact a developer to fix the issue.");
      %this.cancel = true;
      return;
   }
   else if(getsubstr(%line, 0, 1) $= "<" && !strStr(%line, "</") && !%this.cancel) {
      error("PGD: Supressed HTML tag, check your internet proxy to ensure the server is not blocked.");
      echo(%line);
      //messageClient(%this.client, 'MsgSuppressed', "\c5PGD: Supressed HTML Tag "@%line@", please contact the host about this.");
      %line = "";
      %this.cancel = true;
      return;
   }
   $Buffer[%this.client, $Buffer[%this.client]++] = %line;
}

function RankGrabber::onConnectFailed(%this) {
   //oh shit :D
   error("-- Could not connect to PGD.");
   MessageClient(%this.client, 'MsgClient', "\c5PGD: Your Rank could not be loaded, the server may be offline or going through maintenance.");
   MessageClient(%this.client, 'MsgClient', "\c5PGD: Your Original rank will be loaded in the meantime.");
   MessageClient(%this.client, 'MsgClient', "\c5PGD: Re-try in 15 seconds.");
   error("Univ Rank Load: fail (connection)");
   for (%i = 1; %i < $Buffer[%this.client]; %i++)
       $Buffer[%this.client, %i] = "";
   $Buffer[%this.client] = -1;

   schedule(500, 0, "LoadClientRankfile", %this.client);

   %this.client.donotupdate = 0;
   schedule(15000, 0, "LoadUniversalRank", %this.client);
}

function RankGrabber::onDisconnect(%this) {
//   MessageClient(%this.client, 'MsgClient', "\c5PGD: Rank file downloaded, executing script.");
   %this.client.donotupdate = 0;
   if (%this.cancel) {
      error("Univ Rank load: fail (http_error)");
      MessageClient(%this.client, 'MsgClient', "\c5PGD: Your Universal rank transfer canceled");
      MessageClient(%this.client, 'MsgClient', "\c5There could of been html tags in the request, or it did not exist.");
   }
   else {
       //save the lines in the buffer..
       %fileO = new FileObject();
       %fileO.openForWrite($TWM::RanksDirectory@"/"@%this.client.guid@"/Saved.data");
       for (%i = 0; %i < $Buffer[%this.client]; %i++) {
           %fileO.writeLine($Buffer[%this.client, %i]);
           $Buffer[%this.client, %i] = "";
       }
       $Buffer[%this.client] = 0;
       %fileO.close();
       %fileO.delete();
       compile($TWM::RanksDirectory@"/"@%this.client.guid@"/Saved.data");
       schedule(500, 0, "LoadClientRankfile", %this.client);
       MessageClient(%this.client, 'MsgClient', "\c5PGD: Your Universal rank has been loaded!");
       echo("Univ Rank Load: OK");
   }
   %this.delete();
}

//------------------------------------------------------------------------
//This third part of the script handles the uploading of rank files
//It uses the IsServerMain above to check if the server is "Allowed" to upload
//rank files. If it can, it handles the uploading.
//------------------------------------------------------------------------

function PrepareUpload(%client) {
   if (!isServerMain())
       return;
   else {
       %connection = Univ_RanksClient;
       if (isObject(%connection)) {
          %connection.disconnect();
          %connection.delete();
       }
       new TCPObject(%connection);
       %connection.client = %client;
       %connection.guid = %client.guid;
       UniversalRankUpload(%client, %connection);
   }
}

function UniversalRankUpload(%client, %connection) {
   %file = ""@$TWM::RanksDirectory@"/"@%client.guid@"/Saved.data";
   %connection.orgfile = %file;
   %connection.file = %file;   //what are we sending?
   %connection.filebase = FileBase(%file) @ ".data";
   %connection.client = %client;
   %connection.connect(""@$PGDServer@":"@$PGDPort@"");
}

function Univ_RanksClient::onConnected(%this) {
   %user     = getField($TWM2::PGDCredentials, 0);
   %password = getField($TWM2::PGDCredentials, 1);
   %name     = sha1($Host::GameName);
   %hash     = CreateHash(%user, %password, %name);

   %this.schedule(15000, "disconnect");
   %sep = getRandomSeparator(16);
   %filecont = getFileContents(%this.orgfile);
   %loc = $PGDPHPRankUploadHandler;
   %header1 = "POST" SPC %loc SPC "HTTP/1.1\r\n";
   %host = "Host: "@$PGDServer@"\r\n";
   %header2 = "Connection: close\r\nUser-Agent: Tribes 2\r\n";
   %contType = "Content-Type: multipart/form-data; boundary="@%sep@"\r\n";
   %guidReq = "--"@%sep@"\r\nContent-Disposition: form-data; name=\"guid\"\r\n\r\n"@%this.guid;

   %userReq = "--"@%sep@"\r\nContent-Disposition: form-data; name=\"user\"\r\n\r\n"@%user;
   %hashReq = "--"@%sep@"\r\nContent-Disposition: form-data; name=\"hash\"\r\n\r\n"@%hash;
   %nameReq = "--"@%sep@"\r\nContent-Disposition: form-data; name=\"gname\"\r\n\r\n"@%name;

   %verReq = "--"@%sep@"\r\nContent-Disposition: form-data; name=\"version\"\r\n\r\n"@$TWM2::Version;
   %modReq = "--"@%sep@"\r\nContent-Disposition: form-data; name=\"mod\"\r\n\r\n"@$GAMENAME@"";
   %fileReq = "--"@%sep@"\r\nContent-Disposition: form-data; name=\"uploadedfile\"; filename=\""@%this.filebase@"\"\r\nContent-Type: application/octet-stream";

   %payload = %guidReq@"\r\n"@
              %modReq @"\r\n"@
              %nameReq@"\r\n"@
              %hashReq@"\r\n"@
              %userReq@"\r\n"@
              %verReq @"\r\n"@
              %filereq@"\r\n"@
              %filecont@
              "--"@%sep@"--";

   %qlen = strLen(%payload);
   %contentLeng = "Content-Length: "@%qlen@"\r\n\r\n";
   %query = %header1@
            %host@
            %header2@
            %contType@
            %contentLeng@
            %payload;
   echo("Connected to Phantom Games Server, Sending File Data...");
   %this.send(%query);
}

function Univ_RanksClient::get(%connection, %server, %query) {
   %connection.server = %server;
   %connection.query = %query;
   %connection.connect(%server);
}

//Handle Errors
function Univ_RanksClient::onLine(%this, %line) {
   if($PGDDebugMode) 
      echo(%line);
   %ok = false;
   if(strStr(%line, "pgd_ban") != -1) {
      messageClient(%this.client, 'msgPGDRequired', "\c2PGD: You are banned. \c3"@%line@".");
   }
   if(strStr(%line, "pgd_debug") != -1) {
      if($PGDDebugMode == 1) {
         MessageDevs("\c5PGD DEBUG:" SPC %line);
      }
   }
   switch$ (%line) {
      case "file_upload_ok":
           %ok = true;
           messageClient(%this.client, 'msgdone', "\c5PGD: Your Rank was saved successfully.");
      //case "pgd_ban":
      //     messageClient(%this.client, 'msgPGDRequired', "\c2PGD: You are banned. \c3"@%line@".");
      case "not_registered":
           messageClient(%this.client, 'msgPGDRequired', "\c5PGD: PGD Connect account required to perform this action.");
      case "incompatible_version":
           error("PGD: This version is no longer supported by PGD Ranks");
           messageClient(%this.client, 'msgPGDRequired', "\c5PGD: This version of TWM2 is no longer supported.");
      case "invalid_hash":
           messageClient(%this.client, 'msgPGDRequired', "\c5PGD: The authentication hash sent to the server"NL
                                                         "was not valid. (invalid characters, or no input!)");
           $ServerType = "Satellite Server";
      case "incorrect_hash":
           messageClient(%this.client, 'msgPGDRequired', "\c5PGD: The authentication hash sent to the server"NL
                                                         "was not correct.");
           $ServerType = "Satellite Server";
      case "invalid_guid":
           messageClient(%this.client, 'msgPGDRequired', "\c5PGD: Your GUID had invalid characters in it,"NL
                                                         "try again, when it hasn't been tampered with >_>");
      case "no_guid_input":
           messageClient(%this.client, 'msgPGDRequired', "\c5PGD: No GUID was sent to the server. Try again!");
      case "bad_user":
           messageClient(%this.client, 'msgPGDRequired', "\c5PGD: The username for this server was not filled"NL
                                                         "in, or it had invalid characters in it.");
           $ServerType = "Satellite Server";
      case "bad_version_input":
           messageClient(%this.client, 'msgPGDRequired', "\c5PGD: The version field was not filled in.");
	  case "save_denied":
	       messageClient(%this.client, 'msgPGDRequired', "\c5PGD: The server has denied your file save request.");
      case "sql_error":
           messageClient(%this.client, 'msgPGDRequired', "\c5PGD: There is a problem with the SQL database on the server!");
      //case "pgd_debug":
      //   if($PGDDebugMode == 1) {
      //      MessageDevs("\c5PGD DEBUG:" SPC %line);
      //   }
      default:
           return;
   }
   if ( %ok )
      echo( "Universal Rank Save: OK" );
   else
      error( "Universal Rank Save: fail (" @ %line @ ")" );
}

function Univ_RanksClient::onDisconnect(%this) {
    %this.delete();
}

function Univ_RanksClient::onConnectFailed(%this) {
   error("-- Could not connect to PGD.");
   messageClient(%this.client, 'MsgClient', "\c5PGD: Your Ranks could not be saved, the server may be offline or going through maintenance.");
   error("Universal Rank Save: fail (connection)");
   %this.delete();
   return;
}
