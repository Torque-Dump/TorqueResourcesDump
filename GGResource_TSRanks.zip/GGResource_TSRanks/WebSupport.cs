//Support Script, Allows this to work
//Updated 2.1, Signal360's Changes implemented
//Universal Ranks Implemented

$TWM::RanksDirectory = "Server/TWM/Saved";
// This is where all of the ranks will be saved
// I highly recommend leaving this alone

$TWM2::Version = 1.0;

$PGDKeyHandler = "path/to/key.php";
$PGDPHPRankUploadHandler = "path/to/upload.php";
$PGDISFileHandler = "path/to/isFile.php";

$GAMENAME = "Garage_Games_Rocks";

$PGDPort = 80; //TCP
$PGDServer = "www.somewebsite.com";

//PGD IS FILE
function PGD_IsFile(%file) {
   if($PGD::IsFile[%file] $= "" || $PGD::IsFile[%file] == -1) {
      PGD_IsFileDL(%file);
      return schedule(5000, 0, "PGD_IsFile", %file);
   }
   else {
      return $PGD::IsFile[%file];
   }
}

function PGD_IsFileDL(%file) {
   %server = ""@$PGDServer@":"@$PGDPort@"";
   %filename = ""@$PGDISFileHandler@"?File="@%file@"";
   if (!isObject(PGDISFile)) {
      %Downloader = new HTTPObject(PGDISFile){};
   }
   else {
      %Downloader = PGDISFile;
   }
   %Downloader.File = %file;
   echo("Getting");
   %Downloader.get(%server, %filename);
}

function PGDISFile::onLine(%this, %line) {
   echo(%line);
   if(strStr(%line, "Not") != -1) {
      $PGD::IsFile[%this.File] = 0;
      %this.schedule(1000, disconnect);
      %this.schedule(1500, delete);
   }
   else {
      $PGD::IsFile[%this.File] = 1;
      %this.schedule(1000, disconnect);
      %this.schedule(1500, delete);
   }
}

function PGDISFile::onConnectFailed(%this) {
   error("-- Could not connect to PGD Is File, re-attempt, 30 sec.");
   $PGD::IsFile[%this.File] = -1;
   //
   schedule(30000, 0, "PGD_IsFile", %this.File);
   %this.disconnect();
   %this.delete();
}

function PGDISFile::onDisconnect(%this) {

}

//END PGD IS FILE

function getRandomSeperator(%length) {
   %alphanumeric = "abcdefghijklmnopqrstuvwxyz0123456789";
   for (%i = 0; %i < %length; %i++) {
       %index = getRandom(strLen(%alphanumeric));
       %letter= getSubStr(%alphanumeric, %index, 1);
       %UpperC= getRandom(0, 1);
       if (%UpperC)
          %letter = strUpr(%letter);
       else
          %letter = strLwr(%letter);
       %seq = %seq @ %letter;
   }
   return %seq;
}

function GetFileLength(%file) {
   new fileobject(LengthReader);
   LengthReader.openforread(%file);
   %bool = 0;
   while(!%bool) {
      %bool = LengthReader.isEOF();
      %Msg = LengthReader.readLine();
      $message = ""@$message@"\n"@%Msg@"";
   }
   %count = strLen($message);
   $message = "";
   return %count;
}

function getFileContents(%file) {
   new fileobject(filereader);
   filereader.openforread(%file);
   %bool = 0;
   while(!%bool) {
      %bool = filereader.isEOF();
      %Msgget = filereader.readLine();
      %msg = ""@%msg@""NL""@%Msgget@"";
   }
   return %msg;
}
