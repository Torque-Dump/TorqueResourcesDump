//function LoadRanksBase() {
   //echo("Loading The Ranking System Base");
   //findTopRanks();
   //Modified 2.6, top ranks handled by PGD now
//}

function CreateClientRankFile(%client) {
   if(!isSet(%client)) {
      return;
   }
   if(%client.donotupdate) {
      echo("Stopped rank file make on "@%client@", server denies access (probably loading univ rank)");
      return;
   }
   $ModFile.openforWrite(""@$TWM::RanksDirectory@"/"@%client.guid@"/Saved.data");
   $ModFile.WriteLine("//Ranks & Settings File For GUID "@%client.guid@" / Name: "@%client.namebase@"");
   $ModFile.WriteLine("//Created On "@formattimestring("yy-mm-dd")@", Total Warfare Mod 2 "@$TWM2::Version@"");
   $ModFile.close();
   ClientContainer(%client);
   %scriptController = %client.TWM2Core;
   if(!isObject(%scriptController)) {
      //yikes, no script object controller yet, time to create it
	  %soNAME = "TWM2Client_"@%client.guid@"";
	  %client.TWM2Core = new ScriptObject(%soNAME) {};
	  %scriptController = %client.TWM2Core;  
   }
   //now apply the base settings for this new file.
   %scriptController.name = %client.namebase;
   %scriptController.xp = 0;
   %scriptController.money = 0;
   %scriptController.rank = "Private";
   %scriptController.phrase = "None Set";
   %scriptController.gameTime = 0;
   %scriptController.millionxp = 0;
   //and save the new file
   %client.container.add(%scriptController);
   //
   echo("Ranks File For "@%client.namebase@" created");
   exec(""@$TWM::RanksDirectory@"/"@%client.guid@"/Saved.data");
}

function LoadClientRankfile(%client) {
   %client.donotupdate = 0;
   echo("Attempting To Load "@%client.namebase@"'s Ranks File");
   %file = ""@$TWM::RanksDirectory@"/"@%client.guid@"/Saved.data";
   if(!isFile(%file)) {
      echo(""@%client.namebase@" does not have a save file, creating one.");
      CreateClientRankFile(%client);
      //schedule(5000,0,"UpdateRankFile", %client);
   }
   else {
      LoadClientFile(%client);
   }
   //define a new script object for the client, if it does not yet exist
   %soNAME = "Container_"@%client.guid@"/TWM2Client_"@%client.guid@"";
   %object = nameToId(%soNAME);
   if(!isObject(%object)) {
      echo("TWM2 Rank/Setting Client Controller Object is non-existant, creating");
      %client.TWM2Core = new ScriptObject("TWM2Client_"@%client.guid) {};
      %client.container.add(%client.TWM2Core);
   }
   else {
      echo("Found TWM2 Rank/Setting Client Controller for "@%client@" -> "@%object@"");
      %client.TWM2Core = %object;
   }   
   //
   PlayerTimeLoop(%client); //post load functions
}

function UpdateClientRank(%client) {
    if(!isSet(%client) || %client.guid $= "") {
       return;
    }
    if(%client.donotupdate) {
       echo("Stopped rank up check on "@%client@", server denies access (probably loading univ rank)");
       return;
    }
	%scriptController = %client.TWM2Core;
    if($XPArray[%client] <= 0) {
       return; //kill it here, no need to go into the loop
    }
    if(%scriptController.officer $= "") {
       %scriptController.officer = 0;
    }
	%file = ""@$TWM::RanksDirectory@"/"@%client.guid@"/Saved.data";
    //TO GG USERS:
    //IMPLEMENT THE NUMBERS OVER 1 MILLION RESOURCE IF YOU DON'T WANT TO USE THIS
    //HACKY METHOD HERE:
	if(!isSet(%scriptController.millionxp)) {
	   %scriptController.millionxp = 0;
	}
	if((%scriptController.xp + $XPArray[%client]) >= 1000000) {
	   %scriptController.xp = 0;
	   %scriptController.millionxp++;
	}
    %scriptController.xp += $XPArray[%client];
	//%scriptController.save(%file);
    checkForXPAwards(%client);
    $XPArray[%client] = 0;
    %j = $Rank::RankCount;
    runRankUpdateLoop(%client, %j, 1);
}

function runRankUpdateLoop(%client, %j, %continue) {
   if(!%continue) {
      return;
      //break the function run through here
   }
   if(%j <= 0) {
      return;
   }
   %name = %client.namebase;
   %scriptController = %client.TWM2Core;
   if(getCurrentEXP(%client) >= $Ranks::MinPoints[%j]){
      if(%scriptController.rank !$= $Ranks::NewRank[%j]) {
         %scriptController.rankNumber = %j;
         if($TWM2::UseRankTags) {
             DoNameChangeChecks(%client);
         }
         %scriptController.rank = $Ranks::NewRank[%j];
         if($Prestige::Name[%scriptController.officer] >= 1) {
            $Prestige::Name[%scriptController.officer] = "";
         }
         messageAll('msgclient',"\c2"@%name@" has become a "@$Prestige::Name[%scriptController.officer]@""@$Ranks::NewRank[%j]@" with a XP of "@getCurrentEXP(%client)@"!");
         //Place Promoted Sound FX here.
         //messageclient(%client, 'Msgclient', "~wfx/Bonuses/Nouns/General.wav");
         bottomPrint(%client, "Excelent work "@%name@", you have been promoted to the rank of: "@$Prestige::Name[%scriptController.officer]@""@$Ranks::NewRank[%j]@"!", 5, 2 );
         echo("Promotion: "@%name@" to Rank "@$Ranks::NewRank[%j]@", XP: "@getCurrentEXP(%client)@".");
         //UpdateRankFile(%client);
         SaveClientFile(%client);
         //
         PrepareUpload(%client);
         %j = 1;
         runRankUpdateLoop(%client, %j, 0);
      }
   }
   else {
      %j--;
      runRankUpdateLoop(%client, %j, 1);
   }
}

function getCurrentEXP(%client) {
   %scriptController = %client.TWM2Core;
   %xp = %scriptController.xp + (1000000*%scriptController.millionxp);
   return %xp;
}

//PRESTIGE RANKS
function PromoteToPrestige(%client) {
   %scriptController = %client.TWM2Core;
   %savedGameTime = %scriptController.gameTime;
   %savedPhrs = %scriptController.phrase;
   %savedMoney = %scriptController.money;
   if(%scriptController.officer $= "" || %scriptController.officer == 0) {
      %next = 1;
   }
   else {
      %next = %scriptController.officer++;
   }

   DumpStats(%client);
   
   %file = ""@$TWM::RanksDirectory@"/"@%client.guid@"/Saved.data";

   //now apply the base settings for this new file.
   %client.TWM2Core.name = %client.namebase;
   %client.TWM2Core.xp = 0;
   %client.TWM2Core.millionxp = 0;
   %client.TWM2Core.money = %savedMoney;
   %client.TWM2Core.rank = "Private";
   %client.TWM2Core.phrase = %savedPhrs;
   %client.TWM2Core.gameTime = %savedGameTime;
   %client.TWM2Core.officer = %next;
   //and save the new file
   //%scriptController.save(%file);
   SaveClientFile(%client);

   MessageAll('msgSpecial', "\c5"@%client.namebase@" has promoted to Officer level "@%next@".");
}

//STAT Cleaner:
//Phantom139: Changed in 3.4 to support the newer system
function DumpStats(%c) { 
   echo("Resetting" SPC %c.guid@"'s stats.");
   %sO = %c.TWM2Core;
   %sO.delete();
   %soNAME = "TWM2Client_"@%c.guid@"";
   %c.TWM2Core = new ScriptObject(%soNAME) {};
   %c.container.add(%c.TWM2Core);
   // this is now our cleaned object file, it will be populated shortly
}

//Direct calls to needed function, replaces
//old system.
function GainExperience(%client, %variable, %tagToGain) {
   %script = %client.TWM2Core;
   %variable = mFloor(%variable);  //Bad decimals! Bad!!
   %script.money += %variable; //money is kept no matter what

   messageClient(%client, 'msgClient', "\c5TWM2: "@%tagToGain@"\c3+"@%variable@" EXP");
   $XPArray[%client] += %variable;
   updateClientRank(%client);
}

//Directorate.cs
//Phantom139, TWM2 3.6

//Handles all client connection operations when they join

function ClientContainer(%client) {
   //
   echo("*Creating/Loading Client Container For "@%client@"/"@%client.guid@"");
   //
   %name = "Container_"@%client.guid;
   %check = nameToID(%name);
   if(isObject(%check)) {
      echo("*Container Found for "@%client@", applying");
      %client.container = %check;
   }
   else {
      %client.container = new SimSet(%name) {};
   }
}

//brand new saver, saves the client's file container, which in turn will save all other stuffs.
function SaveClientFile(%client) {
   echo("Saving "@%client.namebase@"'s File");
   %file = ""@$TWM::RanksDirectory@"/"@%client.guid@"/Saved.data";
   %client.container.save(%file);
}

function LoadClientFile(%client) {
   %file = ""@$TWM::RanksDirectory@"/"@%client.guid@"/Saved.data";
   exec(%file);
   ClientContainer(%client);
}

function PlayerTimeLoop(%client) {
   %scriptController = %client.TWM2Core;
   %scriptController.gameTime++;
   schedule(60000,0, "PlayerTimeLoop", %client);
}
