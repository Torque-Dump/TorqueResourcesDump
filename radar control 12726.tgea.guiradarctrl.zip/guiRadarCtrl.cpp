//-----------------------------------------------------------------------------
// Torque Game Engine Advanced v1.0
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "console/console.h"
#include "console/consoleTypes.h"
#include "gfx/gfxDevice.h"
#include "game/game.h"
#include "game/gameConnection.h"
#include "gfx/primBuilder.h"

#include "gui/controls/GuiRadarCtrl.h"

IMPLEMENT_CONOBJECT(GuiRadarCtrl);

GuiRadarCtrl::GuiRadarCtrl(void)
{
	// Radar Background default
	mRadarBitmapName = StringTable->insert("");

	// Blip defaults
	mBlipUpName = StringTable->insert("");
	mBlipBelowName = StringTable->insert("");
	mBlipLevelName = StringTable->insert("");
	mShowRadar = true;
	mWrap = true;
	mRadarRadiusRange = 2500.0f;

	mLevelRange = 20.0f;

	// As default show only players
	mShowShapeBase = false;
	mShowVehicles = false;
	mShowPlayers = true;

	// Compass defaults
	mCompassBitmapName = StringTable->insert("");
	mShowCompass = true;

	mCompassRotation = 0.0f;

	// <MH>
	// Map defaults
	mMapBitmapName = StringTable->insert("");
	mShowMap = true;
	// </MH>

	mHideAll = false;
}


void GuiRadarCtrl::initPersistFields()
{
   Parent::initPersistFields();

	addGroup("Radar");
   addField("RadarBitmap",		TypeFilename,		Offset(mRadarBitmapName, GuiRadarCtrl));
   addField("wrap",				TypeBool,			Offset(mWrap,       GuiRadarCtrl));
   addField("blip_above",		TypeFilename,     Offset(mBlipUpName,       GuiRadarCtrl));
	addField("blip_below",		TypeFilename,     Offset(mBlipBelowName,       GuiRadarCtrl));
	addField("blip_level",		TypeFilename,     Offset(mBlipLevelName,       GuiRadarCtrl));
	addField("RadarRange",		TypeF32,				Offset(mRadarRadiusRange,       GuiRadarCtrl));
	addField("ShowRadar",		TypeBool,			Offset(mShowRadar,       GuiRadarCtrl));
	endGroup("Radar");
   
	addGroup("Compass");
	addField("CompassBitmap",	TypeFilename,	Offset(mCompassBitmapName, GuiRadarCtrl));
	addField("ShowCompass",		TypeBool,		Offset(mShowCompass,       GuiRadarCtrl),"Show Compass)");
   endGroup("Compass");		

	// <MH>
	addGroup("Map");
	addField("MapBitmap",		TypeFilename,	Offset(mMapBitmapName, GuiRadarCtrl));
	addField("ShowMap",			TypeBool,		Offset(mShowMap,		  GuiRadarCtrl), "Show Map");
   endGroup("Map");	
	// </MH>
	
	addGroup("Misc");
	addField("RadarShowPlayers",		TypeBool,     Offset(mShowPlayers,       GuiRadarCtrl),"Show Players on Radar");
	addField("RadarShowVehicles",		TypeBool,     Offset(mShowVehicles,       GuiRadarCtrl),"Show Vehicles on Radar");
	addField("RadarShowShapeBase",	TypeBool,     Offset(mShowShapeBase,       GuiRadarCtrl),"Show All Shapebase derived objects on Radar");
	addField("LevelRange",				TypeS32,     Offset(mLevelRange,       GuiRadarCtrl),"The height difference at which the Level blip is displayed");
	addField("HideAll",					TypeBool,     Offset(mHideAll,       GuiRadarCtrl));
	addField("ShowFrame",					TypeBool,     Offset(mShowFrame,       GuiRadarCtrl));
	endGroup("Misc");
}

ConsoleMethod( GuiRadarCtrl, setValue, void, 4, 4, "(int xAxis, int yAxis)"
              "Set the offset of the bitmap.")
{
	object->setValue(dAtoi(argv[2]), dAtoi(argv[3]));
}

ConsoleMethod( GuiRadarCtrl, setRadarBitmap, void, 3, 4, "(string filename, bool resize=false)"
               "Set the bitmap displayed in the control. Note that it is limited in size, to 256x256.")
{
   char fileName[1024];
   Con::expandScriptFilename(fileName, sizeof(fileName), argv[2]);
   object->setRadarBitmap(fileName, argc > 3 ? dAtob( argv[3] ) : false );
}

ConsoleMethod( GuiRadarCtrl, setRadarRange, void, 3, 3, "")
{
	Con::printf("Object->SetRadius = %f", dAtof(argv[2]));
	object->setRadius(dAtof(argv[2]));
}

bool GuiRadarCtrl::onWake()
{
   if (! Parent::onWake())
      return false;
   
	setActive(true);
   setRadarBitmap(mRadarBitmapName);
	setRadarUpBlipBitmap(mBlipUpName);
	setRadarBelowBlipBitmap(mBlipBelowName);
	setRadarLevelBlipBitmap(mBlipLevelName);
	setRadius(mRadarRadiusRange);
	setLevelRange(mLevelRange);
	setCompassBitmap(mCompassBitmapName);
	setMapBitmap(mMapBitmapName);

   return true;
}

void GuiRadarCtrl::onSleep()
{
   mRadarTextureObject = NULL;
	mRadarDot = NULL;
	mRadarUp = NULL;
	mRadarDown = NULL;

	mCompassTextureObject = NULL;
	mMapTextureObject = NULL;

   Parent::onSleep();
}

//-------------------------------------
void GuiRadarCtrl::inspectPostApply()
{
   // if the extent is set to (0,0) in the gui editor and appy hit, this control will
   // set it's extent to be exactly the size of the bitmap (if present)
   Parent::inspectPostApply();

   if (!mWrap && (mBounds.extent.x == 0) && (mBounds.extent.y == 0) && mRadarTextureObject)
   {
      mBounds.extent.x = mRadarTextureObject->getWidth();
      mBounds.extent.y = mRadarTextureObject->getHeight();
   }

   if (!mWrap && (mBounds.extent.x == 0) && (mBounds.extent.y == 0) && mCompassTextureObject)
   {
      mBounds.extent.x = mRadarTextureObject->getWidth();
      mBounds.extent.y = mRadarTextureObject->getHeight();
   }
}

void GuiRadarCtrl::setRadarBitmap(const char *name, bool resize)
{
   mRadarBitmapName = StringTable->insert(name);
   if (*mRadarBitmapName)
	{
		mRadarTextureObject.set( mRadarBitmapName, &GFXDefaultGUIProfile );	// mBitmapName = directory + filename

      // Resize the control to fit the bitmap
      if( mRadarTextureObject && resize )
      {
         mBounds.extent.x = mRadarTextureObject->getWidth();
         mBounds.extent.y = mRadarTextureObject->getHeight();
         Point2I extent = getParent()->getExtent();
         parentResized(extent,extent);
      }
   }
   else
      mRadarTextureObject = NULL;

   setUpdate();
}

void GuiRadarCtrl::setRadarLevelBlipBitmap(const char *name)
{
   mBlipLevelName = StringTable->insert(name);
   if (*mBlipLevelName)
		mRadarDot.set( mBlipLevelName, &GFXDefaultGUIProfile );
   else
      mRadarDot = NULL;

   setUpdate();
}

void GuiRadarCtrl::setRadarUpBlipBitmap(const char *name)
{

   mBlipUpName = StringTable->insert(name);
   if (*mBlipUpName)
		mRadarUp.set( mBlipUpName, &GFXDefaultGUIProfile );
   else
      mRadarUp = NULL;

   setUpdate();

}

void GuiRadarCtrl::setRadarBelowBlipBitmap(const char *name)
{

   mBlipBelowName = StringTable->insert(name);
   if (*mBlipBelowName)
		mRadarDown.set( mBlipBelowName, &GFXDefaultGUIProfile );
   else
      mRadarDown = NULL;

   setUpdate();
}

void GuiRadarCtrl::setCompassBitmap(const char *name, bool resize)
{
   mCompassBitmapName = StringTable->insert(name);
   if (*mCompassBitmapName)
	{
		mCompassTextureObject.set( mCompassBitmapName, &GFXDefaultGUIProfile );

      // Resize the control to fit the bitmap
      if( mCompassTextureObject && resize )
      {
         mBounds.extent.x = mCompassTextureObject->getWidth();
         mBounds.extent.y = mCompassTextureObject->getHeight();
         Point2I extent = getParent()->getExtent();
         parentResized(extent,extent);
      }
   }
   else
      mCompassTextureObject = NULL;

   setUpdate();
}

// <MH>
void GuiRadarCtrl::setMapBitmap(const char *name)
{
   mMapBitmapName = StringTable->insert(name);

   if (*mMapBitmapName)
		mMapTextureObject.set( mMapBitmapName, &GFXDefaultGUIProfile );
   else
      mMapTextureObject = NULL;

   setUpdate();
}
// </MH>

void GuiRadarCtrl::setRadius(const F32 newRange)
{
	mRadarRadiusRange = newRange;
}

void GuiRadarCtrl::setLevelRange(const F32 newLevelRange)
{
	mLevelRange = newLevelRange;
}

void GuiRadarCtrl::setCompassRotation(const F32 rotation)
{
	mCompassRotation = rotation;
}

ConsoleMethod( GuiRadarCtrl, setCompassRotation, void, 3, 3, "")
{
	Con::printf("Object->SetRadius = %f", dAtof(argv[2]));
	object->setCompassRotation(dAtof(argv[2]));
}

float Vector3dToDegree(Point3F vector)
{
    float angle;
	if (vector.x == 0.0F)
    {
        if (vector.y > 0.0F)
            return 0.0F;
        else if (vector.y == 0.0F)
            return -1.0F;
        else
            return 180.0F;
    }
    if (vector.y == 0.0F)
    {
        if (vector.x < 0.0F)
            return 270.0F;
        else
            return 90.0F;
    }
    angle = atanf((vector.x) / (-vector.y)) * (180.0F / M_PI);
    if ((-vector.y) < 0.0F)
        return angle + 180.0F;
    else
    {
        if (vector.x > 0.0F)
            return angle;
        else
            return angle + 360.0F;
    }
}

// Conversion function, Degrees to vector (used after manipulating camera angle to represent angle of object on radar)
void DegreeToVector2d(float angle, float length, Point3F &vector)
{
	angle = (angle / 180.0F) * M_PI;
    vector.x = length * (sin(angle) );
	vector.y = length * (-cos(angle) );
}
void GuiRadarCtrl::onRender(Point2I offset, const RectI &updateRect)
{
	// Must have a connection
	GameConnection* conn = GameConnection::getConnectionToServer();
	if (!conn) return;
	// Must have controlled object
	ShapeBase* control = conn->getControlObject();
	if (!control) return;

	//Find distance from top-left corner to center of radar image 
	Point2F center(mBounds.extent.x / 2,mBounds.extent.y / 2); 

	//F32 HWidth = mBounds.extent.x/2.0;
	//F32 HHeight = mBounds.extent.y/2.0;
	F32 HW = mBounds.extent.x/2.0;

	//Make center the UI object's coordinate center 
	center.x += mBounds.point.x; 
	center.y += mBounds.point.y; 

	MatrixF cam;
	VectorF camDir;
	Point3F cameraRot;

   conn->getControlCameraTransform(0,&cam);	// store camera information
   cam.getColumn(3, &mMyCoords);				// get camera position
   cam.getColumn(1, &camDir);					// get camera vector
	cam.getRow(1,&cameraRot);					// get camera rotation

	// Remove Rotation around the X/Y axis
	//cameraRot.x = 0;
	//cameraRot.y = 0;
	
	cameraRot.neg();							// bug forces us to need to invert camera rotation angle

	// get angle that camera is facing
	float cameraAngle = Vector3dToDegree(cameraRot);

	// <MH>
	if (mMapTextureObject && mShowMap)
   {
      GFX->clearBitmapModulation();

 		GFXTextureObject* texture = mMapTextureObject;
		
		GFX->setBaseRenderState();

		F32 width = mBounds.extent.x * 0.5;

		MatrixF rotMatrix( EulerF( 0.0, 0.0, mDegToRad(cameraAngle)) );

		Point3F offset( offset.x + mBounds.extent.x / 2, 
							 offset.y + mBounds.extent.y / 2, 0.0);


		// The 8 will help model the scale of which the player moves across the map
		Point2F offsetTexture( mMyCoords.x / ((float)mMapTextureObject->getBitmapWidth() * 8), 
									 -mMyCoords.y / ((float)mMapTextureObject->getBitmapHeight() * 8));

		F32 uvOffset = (float)mBounds.extent.x / (float)mMapTextureObject->getBitmapWidth() / 2;

		GFXVertexBufferHandle<GFXVertexPCT> verts( GFX, 10, GFXBufferTypeVolatile );
		verts.lock();
		
		// Octagons Vertices
		verts[0].point.set( 0.0f, 0.0f, 0.0f);
		verts[1].point.set( 0.0f, width, 0.0f);
		verts[2].point.set( width * 0.7f, width * 0.7f, 0.0f);
		verts[3].point.set( width, 0.0f, 0.0f);
		verts[4].point.set( width * 0.7f, -width * 0.7f, 0.0f);
		verts[5].point.set( 0.0f, -width, 0.0f);
		verts[6].point.set( -width * 0.7f, -width * 0.7f, 0.0f);
		verts[7].point.set( -width, 0.0f, 0.0f);
		verts[8].point.set( -width * 0.7f, width * 0.7f, 0.0f);
		verts[9].point.set( 0.0f, width, 0.0f);
		
		//verts[0].color = verts[1].color = verts[2].color = verts[3].color = verts[4].color = verts[5].color = verts[6].color = verts[7].color = verts[8].color = verts[9].color = GFX->mBitmapModulation;
		
		// Octagons UV coordinates
		verts[0].texCoord.set( 0.0f, 0.0f);
		verts[1].texCoord.set( 0.0f, uvOffset);
		verts[2].texCoord.set( uvOffset * 0.7f, uvOffset * 0.7f);
		verts[3].texCoord.set( uvOffset, 0.0f);
		verts[4].texCoord.set( uvOffset * 0.7f, -uvOffset * 0.7f);
		verts[5].texCoord.set( 0.0f, -uvOffset);
		verts[6].texCoord.set( -uvOffset * 0.7f, -uvOffset * 0.7f);
		verts[7].texCoord.set( -uvOffset, 0.0f);
		verts[8].texCoord.set( -uvOffset * 0.7f, uvOffset * 0.7f);
		verts[9].texCoord.set( 0.0f, uvOffset);

		for( int i = 0; i < 10; i++ )
		{
			rotMatrix.mulP( verts[i].point );
			verts[i].point += offset;
			verts[i].texCoord += offsetTexture;
		}

		verts.unlock();

		GFX->setVertexBuffer( verts );

		GFX->setCullMode( GFXCullNone );
		GFX->setLightingEnable( false );
		GFX->setAlphaBlendEnable( true );
		GFX->setSrcBlend( GFXBlendSrcAlpha );
		GFX->setDestBlend( GFXBlendInvSrcAlpha );
		GFX->setTextureStageAddressModeU(0, GFXAddressWrap);
		GFX->setTextureStageAddressModeV(0, GFXAddressWrap);
		GFX->setTextureStageColorOp( 0, GFXTOPModulate );
		GFX->setTextureStageColorOp( 1, GFXTOPDisable );
		GFX->setTexture( 0, texture );

		GFX->drawPrimitive( GFXTriangleFan, 0, 8);

		GFX->setAlphaBlendEnable( false );
	}
	// </MH>

	if (mRadarTextureObject && mShowRadar)
   {
      GFX->clearBitmapModulation();
		if(mWrap)
		{
 			GFXTextureObject* texture = mRadarTextureObject;
			RectI srcRegion;
			RectI dstRegion;
			float xdone = ((float)mBounds.extent.x/(float)texture->mBitmapSize.x)+1;
			float ydone = ((float)mBounds.extent.y/(float)texture->mBitmapSize.y)+1;

			int xshift = startPoint.x%texture->mBitmapSize.x;
			int yshift = startPoint.y%texture->mBitmapSize.y;
			for(int y = 0; y < ydone; ++y)
				for(int x = 0; x < xdone; ++x)
				{
		 			srcRegion.set(0,0,texture->mBitmapSize.x,texture->mBitmapSize.y);
  					dstRegion.set( ((texture->mBitmapSize.x*x)+offset.x)-xshift,
								      ((texture->mBitmapSize.y*y)+offset.y)-yshift,
								      texture->mBitmapSize.x,
								      texture->mBitmapSize.y);
               GFX->drawBitmapStretchSR(texture,dstRegion, srcRegion);
				}

		}
		else
      {
         RectI rect(offset, mBounds.extent);
         GFX->drawBitmapStretch(mRadarTextureObject, rect);
      }
   }

	GFX->clearBitmapModulation();

	GFXTextureObject* LevelBlip = (GFXTextureObject*) mRadarDot;
	GFXTextureObject* HighBlip = (GFXTextureObject*) mRadarUp;
	GFXTextureObject* LowBlip = (GFXTextureObject*) mRadarDown;	

	// Go through all ghosted objects on connection (client-side)
	for (SimSetIterator itr(conn); *itr; ++itr) {
      // Make sure that the object is a shapebase object
      if ((*itr)->getType() & ShapeBaseObjectType) {
         ShapeBase* shape = static_cast<ShapeBase*>(*itr);
		 // Make sure that the object isn't the client
		 if (shape != control  && shape->getShapeName()) { 
			// Make sure the shapebase object is a player

			 if (shape->getType()) {
					
				   //ONly check when shapebase is not selecting, we are after all iterating through ShapebaseObjects
					/*if (!mShowShapeBase)
					{
						if (!mShowPlayers && shape->getType() == PlayerObjectType)
							continue;

						if (!mShowVehicles && shape->getType() == VehicleObjectType) 
							continue;
					}*/

					Point3F newCoord;
   					// Get coords of player object
					newCoord = shape->getPosition();

					// Find distance from point A (player object) to point B (client's player)
					VectorF shapeDir = newCoord - mMyCoords;

					// Test to see if player object in range (deal with squared objects in cheap way to use non-negative value)
					F32 shapeDist = shapeDir.lenSquared();
					if (shapeDist == 0 || shapeDist > (mRadarRadiusRange * mRadarRadiusRange))
						continue;

					// Convert map coordinates to screen coordinates
					newCoord.x -= mMyCoords.x;
					newCoord.y -= mMyCoords.y;
					newCoord.y = -newCoord.y;
					
					float coord_z = newCoord.z - mMyCoords.z; 

					newCoord.z = 0;

					// Adjust object's vector to represent rotation of camera
					float objectAngle = Vector3dToDegree(newCoord);
					float length = newCoord.len()*HW/mRadarRadiusRange;
					DegreeToVector2d(((360-objectAngle)+(cameraAngle) ), length, newCoord);
					
					newCoord.x = -newCoord.x;

					// Add tour calculation to the centre of the GuiControl
					newCoord.x += (center.x);
					newCoord.y += (center.y);
						
					// Draw radar blips based on height
					if(coord_z < F32(0 - mLevelRange)){
						if (LowBlip) 
						{
							GFX->drawBitmap(LowBlip, Point2I(newCoord.x,newCoord.y));
						}
					}
					else if(coord_z > mLevelRange){
						if (HighBlip) 
						{
							GFX->drawBitmap(HighBlip, Point2I(newCoord.x,newCoord.y));
						}
					}
					else{
						if (LevelBlip) 
						{
							GFX->drawBitmap(LevelBlip, Point2I(newCoord.x,newCoord.y));
						}
					}
					}
				}
			}
		}

   if (mProfile->mBorder || !mRadarTextureObject)
   {
		if (mShowFrame)
		{
			RectI rect(offset.x, offset.y, mBounds.extent.x, mBounds.extent.y);
			GFX->drawRect(rect, mProfile->mBorderColor);
		}
   }
	
	if (mCompassTextureObject && mShowCompass)
   {

		GFX->clearBitmapModulation();

		GFXTextureObject* texture = mCompassTextureObject;

		GFX->setCullMode( GFXCullNone );

		GFX->setLightingEnable( false );
		GFX->setAlphaBlendEnable( true );

		GFX->setSrcBlend( GFXBlendSrcAlpha );
		GFX->setDestBlend( GFXBlendInvSrcAlpha );
		GFX->setTextureStageColorOp( 0, GFXTOPModulate );
		GFX->setTextureStageColorOp( 1, GFXTOPDisable );

		GFX->setTexture( 0, texture );
		GFX->disableShaders();

		F32 width = mBounds.extent.x * 0.5;

		MatrixF rotMatrix( EulerF( 0.0, 0.0, mDegToRad(cameraAngle)));

		Point3F offset( offset.x + mBounds.extent.x / 2,
			offset.y + mBounds.extent.y / 2, 0.0);


		Point3F points[4];
		points[0] = Point3F(-width, -width, 0.0f);
		points[1] = Point3F(-width, width, 0.0f);
		points[2] = Point3F( width, width, 0.0f);
		points[3] = Point3F( width, -width, 0.0f);

		for(int i = 0; i < 4; i++)
		{
			rotMatrix.mulP( points[i] );
			points[i] += offset;
		}

		PrimBuild::color3f(1.0f,1.0f,1.0f);

		PrimBuild::begin(GFXTriangleFan, 4);
		PrimBuild::texCoord2f(0, 0);
		PrimBuild::vertex3fv(points[0]);
		PrimBuild::texCoord2f(0, 1);
		PrimBuild::vertex3fv(points[1]);
		PrimBuild::texCoord2f(1, 1);
		PrimBuild::vertex3fv(points[2]);
		PrimBuild::texCoord2f(1, 0);
		PrimBuild::vertex3fv(points[3]);
		PrimBuild::end();

		GFX->setAlphaBlendEnable( false );
	}

   renderChildControls(offset, updateRect);
}

void GuiRadarCtrl::setValue(S32 x, S32 y)
{
   if (mRadarTextureObject)
   {
		x += mRadarTextureObject->getWidth() / 2;
		y += mRadarTextureObject->getHeight() / 2;
  	}
  	while (x < 0)
  		x += 256;
  	startPoint.x = x % 256;

  	while (y < 0)
  		y += 256;
  	startPoint.y = y % 256;
}
