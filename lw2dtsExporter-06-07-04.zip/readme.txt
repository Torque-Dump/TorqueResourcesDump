LightWave to DTS Exporter Plug-in
Release 06-07-04

By David Wyand
TheHeadGnome@gnometech.com
www.gnometech.com

Removal of Previous Version
If you have a previous version of the exporter installed, you'll need to remove it
from Layout.  To do so, go to Layout->Plug-ins->Edit Plug-ins... and click on the
'File' button in the bottom of the screen.  Scroll down until you find the
'lw2dtsExporter.p' file.  Select it and click the 'Delete' button to the right.  Close
down Layout.  You'll also want to remove any previous version from Modeler.

Installation
To install the plug-in for use in LightWave 7.5, place the lw2dtsExporter.p in the
LightWave_3D_7.0\Plugins\Utility folder (or anywhere else you'd like).  Then in
Layout, select Layout->Plug-ins->Add Plug-ins... and select the plug-in.  You will get
a message stating '10 plug-ins have been successfully added'.  I usually recommend that you
then close down Layout to ensure that the plug-in has been written in the config file
correctly.

This version of the exporter also requires that you install in Modeler.  To accomplish
this, select Modeler->Plug-ins->Add Plug-ins... and select the plug-in.  You see a window
stating that there are five plug-ins.  Click on 'Done' and close down Modeler to ensure
that the changes are saved to the config file.

Use
The LightWave to DTS Exporter plug-in is a Master Handler plug-in.  This means that
it will be saved with the scene that it is used on.  To add the plug-in to the current
scene, select Scene->Master Plug-ins.  This will open a window from which you may select
'Add Layout or Scene Master'.  Choose TorqueDTSExporter from the list.  Then double-click
on the plug-in to open its user interface.

In this version, there are also a number of support plug-ins.  To find out more, please
see the changes.txt file included with the plug-in and the documentation archive at the
GnomeTech site.

Enjoy!
