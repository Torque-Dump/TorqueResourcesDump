function initReferenceLookup(index)
{
   referenceLookUpArray = new Array();



}