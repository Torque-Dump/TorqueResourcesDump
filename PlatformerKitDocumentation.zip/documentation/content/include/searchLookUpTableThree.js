function initSearchTableThree() 
{
}