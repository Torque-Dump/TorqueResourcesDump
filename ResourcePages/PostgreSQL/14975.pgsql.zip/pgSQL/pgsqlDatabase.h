
#ifndef _PLSQLDATABASE_H
#define _PLSQLDATABASE_H

#include "console/simBase.h"
#ifdef TORQUE_OS_WIN32
//#include <winsock2.h>
#endif
#include "core/llist.h"
#include "platform/platform.h"
#include "platform/threads/mutex.h"
#include "platform/threads/thread.h"
#include "atlas/core/threadSafeQueue.h"
#include "platform/threads/semaphore.h"
#include <libpq-fe.h>

#define QUERYLISTSIZE 64

class PGQuery
{
private:
	PGresult *r;
	U64 id;

public:
	PGQuery(PGresult *_r, U64 _id) { r = _r;  id = _id;}
	~PGQuery() { PQclear(r); }
	const char* getValue(U32 row, U32 col) { return PQgetisnull(r, row,col) ? NULL : PQgetvalue(r, row, col); }
	const char* getNamedValue (const U32 row, const char * field);
	U32 getNumFields() { return PQnfields(r); }
	U32 getNumRows() { return PQntuples(r); }
	const char* getFieldName(U32 f) { return PQfname(r, f); }
	S32 getFieldNum(const char* f) { return PQfnumber(r,f); }
	U32 getId() { return id; }
};

typedef void (*QueryCallback)(PGQuery*,const void *user);


class PGSQL
{
private:
	const char * mHost;
	const char * mPort;
	const char * mUser;
	const char * mDatabase;
	const char * mPassword;

	PGconn *db;
	bool connected;
	bool isBusy;

	bool Connect();

public:
	PGSQL();
	~PGSQL();

	PGQuery *Exec(const char *query);

	bool Connect(const char* host, const char* port, const char* db, const char* user, const char* pass);
	void Close();
	bool isConnected() {return connected;}
};


// This got a little messy...
struct PGSQLRequest
{
	// C++ callback
	PGSQLRequest(const char* _query, const void* _user, QueryCallback _cCallback)
	{
		sql = _query;
		cCallback = _cCallback;
		user = _user;
		sim = NULL;
		tsCallback = NULL;
	}

	// TS Function Callback
	PGSQLRequest(const char* _query,  const char* _tsCallback)
	{
		sql = _query;
		cCallback = NULL;
		user = NULL;
		sim = NULL;
		tsCallback = dStrdup(_tsCallback);
	}

	// TS Object + Function Callback
	PGSQLRequest(const char* _query, SimObject* _sim, const char* _tsCallback)
	{
		sql = _query;
		cCallback = NULL;
		user = NULL;
		sim = _sim;
		tsCallback = dStrdup(_tsCallback);
	}

	~PGSQLRequest()
	{
		// Allocated by BuildQuery
		delete[] sql;

		if (tsCallback)
			dFree(tsCallback);
	}

	const char *sql;
	char *tsCallback;
	QueryCallback cCallback;
	SimObject * sim;
	const void *user;
};

class PGSQLPool;

class PGSQLThread
{
	bool		mStop;
	const char * mHost;
	const char * mPort;
	const char * mUser;
	const char * mDatabase;
	const char * mPassword;
	Thread*		mThread;
	PGSQL*		db;
	PGSQLPool	*master;
	U8 id;
	typedef SimObject Parent;

public:
	PGSQLThread(const char* host, const char* port, const char* db, const char* user, const char* pass, PGSQLPool * m, U8 _id);
	~PGSQLThread();
	void Stop() {mStop = true;}

	static void processThread( void *udata );

protected:
	void processLoop();
};


// Realy hate doing this...
class PGSQLPool: public SimObject
{
	LList<PGSQLRequest*> queue;
	LList<PGSQLThread*> threads; 
	LList<PGQuery*> queries[QUERYLISTSIZE];

	Semaphore  * mReady;
	void	   * mQueueMutex;
	
	U32		   time;

	typedef SimObject Parent;
	

public:
	DECLARE_CONOBJECT (PGSQLPool);

	PGSQLPool();
	~PGSQLPool();
	static void consoleInit();
	void Initilize(int n);
	Semaphore* getReadySemaphore() {return mReady;}
	void lockQueue() {Mutex::lockMutex(mQueueMutex);}
	void unlockQueue() {Mutex::unlockMutex(mQueueMutex);}
	static void lockID() {Mutex::lockMutex(mIDMutex);}
	static void unlockID() {Mutex::unlockMutex(mIDMutex);}

	U32 getTime( ) { return time; }
	PGSQLRequest* getRequest();
	void Exec(QueryCallback callback, const void* _user, const char *fmt, ...);
	void VExec(QueryCallback callback, const void* _user, const char *fmt, va_list ap);
	void VExec(const char* callback, const char *fmt, va_list ap);
	void VExec(SimObject* sim, const char* callback, const char *fmt, va_list ap);

	U64 addQuery (PGQuery *q);
	PGQuery * getQuery (U64 id);
	PGQuery * getQueryAndUnlink (U64 id);
	void freeQuery (U64 query);
	void unlinkAll();
	static U64 queryIdIter;
	static void	* mIDMutex;
	// static members
protected:
	static PGSQLPool * dbPool;
	static char * mHost;
	static char * mPort;
	static char * mUser;
	static char * mDatabase;
	static char * mPassword;
	static S32	  mThreads;

public:
	static PGSQLPool * getPool() {return dbPool;}
	static void createPool();

	static const char* getHost() {return mHost;}
	static const char* getPort() {return mPort;}
	static const char* getUser() {return mUser;}
	static const char* getDatabase() {return mDatabase;}
	static const char* getPassword() {return mPassword;}

};

#endif
