#define _PGSQLDATABASE_CPP

#include "pgsql/pgsqlDatabase.h"
#include "console/consoleTypes.h"



static inline const char* BuildQuery(const char *fmt, va_list ap)
{
	char *buf = new char[dStrlen(fmt)*3];

	const char *topOfFmt = fmt + dStrlen(fmt);

	char *ptr	   = buf;

	for ( ; fmt < topOfFmt; fmt++) 
	{
		if (*fmt == '%' && *(fmt+1)) 
		{
			switch (*(++fmt)) 
			{
			case 'b':               /* Escaped Binary. */
				{
					U32 newlen = 0;
					const U8 *src = va_arg(ap, const U8 *);
					const U8 *newStr = PQescapeBytea( src, dStrlen((const char*)src), &newlen);

					// PQescapeBytea adds a null on the end, so
					// copy the string and add quotations while we are at it.

					*(ptr++) = '\'';
					while (*newStr) *(ptr++) = *(newStr++);
					*(ptr++) = '\'';
					PQfreemem((void*)newStr);
					break;
				}
			case 's':               /* Escaped string. */
				{
					const char *str = va_arg(ap, const char *);

					*(ptr++) = '\'';
					ptr += PQescapeString(ptr, str, dStrlen(str));
					*(ptr++) = '\'';
					break;
				}
			case 'x':               /* Unescaped string. */
				{
					const char *str = va_arg(ap, const char *);

					//*(ptr++) = '\'';
					while (*str) *(ptr++) = *(str++);
					//*(ptr++) = '\'';
					break;
				}
			case '%':               /* $$ = $ */
				{
					*(ptr++) = '%';
					break;
				}
			default:                /* Invalid taken verbatim. */
				{
					*(ptr++) = '%';
					*(ptr++) = *fmt;
				}
				break;
			}
		} 
		else
			*(ptr++) = *fmt;
	}

	*ptr = '\0';
	return buf;
}

PGSQL::PGSQL()
{
	mHost		= NULL;
	mPort		= "5432";
	mUser		= NULL;
	mPassword	= NULL;
	mDatabase	= NULL;
	db			= NULL;

	connected	= false;
}

PGSQL::~PGSQL()
{
	if (connected)
		Close();
}

bool PGSQL::Connect(const char* host, const char* port, const char* db, const char* user, const char* pass)
{
	mHost		= host;
	mPort		= port;
	mDatabase	= db;
	mUser		= user;
	mPassword	= pass;
	return Connect();
}

bool PGSQL::Connect()
{
	if (!strlen (mUser))
	{
		Con::errorf ("PGSQL: Connection failed. No username specified.");
		return false;
	}
	else if (!strlen (mDatabase))
	{
		Con::errorf ("PGSQL: Connection failed. No name specified.");
		return false;
	}
	else if (dAtoi(mPort) <= 0 || dAtoi(mPort) > 65535)
	{
		Con::errorf ("PGSQL: Connection failed. Port %i is invalid.", mPort);
		return false;
	}

	// This is the weirdest way of referencing a port i have ever seen.

	db = PQsetdbLogin(mHost, mPort, NULL, NULL, mDatabase, mUser, mPassword);

	if (PQstatus(db) == CONNECTION_BAD)
	{
		Con::errorf ("PGSQL: Connection to %s failed. %s", mDatabase, PQerrorMessage(db));
		Close();
		return false;
	}

	return connected = true;
}

void PGSQL::Close()
{
	PQfinish(db);
	connected = false;
}

PGQuery* PGSQL::Exec(const char *query)
{
	if (!connected)
		return NULL;
	
	PGresult	  *r = PQexec(db, query);
	ExecStatusType s = PQresultStatus(r);
	if (s == PGRES_TUPLES_OK || s == PGRES_COMMAND_OK)
	{
		PGSQLPool::lockID();
		PGSQLPool::queryIdIter++;
		PGQuery *q = new PGQuery(r, PGSQLPool::queryIdIter);
		PGSQLPool::unlockID();
		return q;	
	}
	else
	{
		Con::errorf ("PGSQL: Query Error: %s: %s", PQresStatus(s), PQresultErrorMessage(r));
	}

	return NULL;
}

void PGSQLThread::processThread( void *udata )
{
	PGSQLThread* pThis = (PGSQLThread *)udata;
	pThis->processLoop();
}

void PGSQLThread::processLoop()
{
	db = new PGSQL();
	db->Connect(mHost, mPort, mDatabase, mUser, mPassword);

	while(!mStop)   
	{
		if (master->getReadySemaphore()->acquire(true))
		{
			master->lockQueue();
			PGSQLRequest *r = master->getRequest();
			master->unlockQueue();
			if (r)
			{
				PGQuery * q = db->Exec(r->sql);
				if (r->cCallback)
					r->cCallback(q, r->user);

				if (r->tsCallback)
				{
					char buf[100];
					if (q)
					{
						U64 nid = master->addQuery(q);
						dSprintf(buf, sizeof(buf), "%d", nid);
					}
					else
					{
						buf[0] = NULL;
					}
					if (!r->sim)
						Con::executef(r->tsCallback, buf);
					else
						Con::executef(r->sim, r->tsCallback, buf);
				}

				delete r;
			}
		}
	}
}

PGSQLThread::PGSQLThread(const char* host, const char* port, const char* _db, const char* user, const char* pass, PGSQLPool *m, U8 _id)
{
	db = NULL;
	mHost		= host;
	mPort		= port;
	mDatabase	= _db;
	mUser		= user;
	mPassword	= pass;
	id = _id;
	mStop = false;
	master = m;
	mThread = new Thread((ThreadRunFunction)processThread, this, 1);
}

PGSQLThread::~PGSQLThread()
{
	mStop = true;
	mThread->join();
	if (db)
	{
		db->Close();
		delete db;
	}
	delete mThread;
}

IMPLEMENT_CONOBJECT (PGSQLPool);

PGSQLPool::PGSQLPool()
{
    mQueueMutex = Mutex::createMutex();
	
	mReady = new Semaphore(0);
	time		= 0;
}

void PGSQLPool::Initilize(int n)
{
	while (n--)
	{
		PGSQLThread *t = new PGSQLThread(getHost(), getPort(), getDatabase(), getUser(), getPassword(), this, n);
		threads.link(t);
	}
}

PGSQLPool::~PGSQLPool()
{
	Mutex::destroyMutex(mQueueMutex);
	delete mReady;
	while (PGSQLThread *t = *(threads.pop_first()))
	{
		delete t;
	}
}

PGSQLRequest* PGSQLPool::getRequest() 
{ 

	if (!queue.size())
		return NULL;

	PGSQLRequest* r = *(queue.pop_first());
	
	return r;
}

void PGSQLPool::Exec(QueryCallback callback, const void* user, const char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	VExec(callback, user, fmt, ap);
	va_end(ap);
}

void PGSQLPool::VExec(QueryCallback callback, const void* user, const char *fmt, va_list ap)
{
	const char *buf;
	buf = BuildQuery(fmt, ap);
	
	PGSQLRequest *q = new PGSQLRequest(buf, user, callback);
	lockQueue();
	queue.push_back(q);
	unlockQueue();
	mReady->release();
}

void PGSQLPool::VExec(const char* callback, const char *fmt, va_list ap)
{
	const char *buf;
	buf = BuildQuery(fmt, ap);
	
	PGSQLRequest *q = new PGSQLRequest(buf, callback);
	lockQueue();
	queue.push_back(q);
	unlockQueue();
	mReady->release();
}

void PGSQLPool::VExec(SimObject* sim, const char* callback, const char *fmt, va_list ap)
{
	const char *buf;
	buf = BuildQuery(fmt, ap);
	
	PGSQLRequest *q = new PGSQLRequest(buf, sim, callback);
	lockQueue();
	queue.push_back(q);
	unlockQueue();
	mReady->release();

}
U64 PGSQLPool::addQuery (PGQuery *q)
{
	U64 n = q->getId();
	queries[n % QUERYLISTSIZE].link(q);
	return n;
}

PGQuery * PGSQLPool::getQuery (U64 id)
{
	LList<PGQuery*> *l = &queries[id % QUERYLISTSIZE];
	LListNode<PGQuery*>* n = NULL;
	while ( (n = l->iterate(n)) != NULL )
	{
		PGQuery *q = *(n->Data);
		if (q->getId() == id)
		{
			return q;
		}
	}
	return NULL;
}

void PGSQLPool::unlinkAll()
{
	for (int i = 0; i<QUERYLISTSIZE; i++)
	{
		LList<PGQuery*> *l = &queries[i];
		LListNode<PGQuery*>* n = l->iterate(NULL);
		while( (n = l->iterate( n ) )!=NULL )
		{
			LListNode<PGQuery*> *kill = n;
			n = n->Prev;
			PGQuery * q= *(kill->Data);
			l->free( kill );
			delete q;
		}
	 }
}

// Static Members
char * PGSQLPool::mHost = "localhost";
char * PGSQLPool::mPort = "5432";
char * PGSQLPool::mUser = "";
char * PGSQLPool::mDatabase = "";
char * PGSQLPool::mPassword = "";
S32    PGSQLPool::mThreads = 2;
PGSQLPool * PGSQLPool::dbPool = NULL;
U64 PGSQLPool::queryIdIter = 1;
void *PGSQLPool::mIDMutex = Mutex::createMutex();

void PGSQLPool::consoleInit()
{
	Con::addVariable("$pref::Server::Database::Password", TypeString, &mPassword);
	Con::addVariable("$pref::Server::Database::Host",	  TypeString, &mHost);
	Con::addVariable("$pref::Server::Database::Port",	  TypeString, &mPort);
	Con::addVariable("$pref::Server::Database::Database", TypeString, &mDatabase);
	Con::addVariable("$pref::Server::Database::Threads",  TypeS32, &mThreads);
	Con::addVariable("$pref::Server::Database::Username", TypeString, &mUser);
}

void PGSQLPool::createPool()
{
	if (!dbPool)
	{
		dbPool = new PGSQLPool();
		dbPool->registerObject();
		dbPool->Initilize(mThreads);
    }
}


ConsoleStaticMethod (PGSQLPool, createPool, void, 1, 1, "")
{
	PGSQLPool::createPool();
}

ConsoleStaticMethod (PGSQLPool, getPool, S32, 1, 1, "")
{
	if (PGSQLPool::getPool())
	{
		S32 id = PGSQLPool::getPool()->getId();
		return id;
	}
	else
		return 0;
}

PGQuery * PGSQLPool::getQueryAndUnlink (U64 id)
{
	LList<PGQuery*> *l = &queries[id % QUERYLISTSIZE];
	LListNode<PGQuery*>* n = NULL;
	while ( (n = l->iterate(n)) != NULL )
	{
		PGQuery *q = *(n->Data);
		if (q->getId() == id)
		{
			l->free(n);
			return q;
		}
	}
	return NULL;
}

void PGSQLPool::freeQuery (U64 id)
{
	PGQuery *q = getQueryAndUnlink(id);
	delete q;
} 


ConsoleMethod (PGSQLPool, freeQuery, void, 3, 3, "PGSQL.freeResult (QueryId)")
{
	object->freeQuery (dAtoi (argv[2]));
}

ConsoleMethod (PGSQLPool, getNumRows, S32, 3, 3, "PGSQL.getNumRows (QueryId)")
{
	PGQuery *q = object->getQuery(dAtoi (argv[2]));
	if (!q) 
		return 0;

	return q->getNumRows();	
}

ConsoleMethod (PGSQLPool, getNumFields, S32, 3, 3, "PGSQL.getNumFields (QueryId)")
{
	PGQuery *q = object->getQuery(dAtoi (argv[2]));
	if (!q) 
		return 0;

	return q->getNumFields();	
}

ConsoleMethod (PGSQLPool, getFieldNum, S32, 4, 4, "PGSQL.getFieldNum (QueryId, fname)")
{
	PGQuery *q = object->getQuery(dAtoi (argv[2]));
	if (!q) 
		return 0;

	return q->getFieldNum(argv[3]);	
}

ConsoleMethod (PGSQLPool, getFieldName, const char *, 4, 4, "PGSQL.getFieldName (QueryId, field)")
{
	PGQuery *q = object->getQuery(dAtoi (argv[2]));
	if (!q) 
		return "";
	return q->getFieldName(dAtoi(argv[3]));	
}

ConsoleMethod (PGSQLPool, getValue, const char *, 5, 5, "PGSQL.getFieldName (QueryId, row, column)")
{
	PGQuery *q = object->getQuery(dAtoi (argv[2]));
	if (!q) 
		return "";

	return q->getValue(dAtoi(argv[3]), dAtoi(argv[4]));	
}
const char* PGQuery::getNamedValue (const U32 row, const char * field) 
{ 
	if (PQgetisnull(r, row,PQfnumber(r, field))) 
		return NULL;

    return PQgetvalue(r, row, PQfnumber(r, field)); 
}

ConsoleMethod (PGSQLPool, getNamedValue, const char *, 5, 5, "PGSQL.getFieldName (QueryId, row, fname)")
{
	PGQuery *q = object->getQuery(dAtoi (argv[2]));
	if (!q) 
		return "";

	return q->getNamedValue(dAtoi(argv[3]), argv[4]);	
}

ConsoleMethod (PGSQLPool, Exec, void, 3, 0, "PGSQL.Query (Query, ...)")
{
	SimObject *cbObj = dynamic_cast<SimObject *>(Sim::findObject(argv[2]));
	if( cbObj == NULL )
	{
		va_list ap = (va_list)&argv[4];
		object->VExec(argv[2], argv[3], ap);
	}
	else
	{
		va_list ap = (va_list)&argv[5];
		object->VExec(cbObj,argv[3], argv[4], ap);
	}
}


