// ============================================================
// Project      :   killer.kork
// File         :   .\server\scripts\consoleFunctions.cs
// Copyright    :   © 2005
// Author       :   
// Editor       :   TorqueDev 1.2.2053.2571
// 
// Description  :   
//              :   
//              :   
// ============================================================


//.............................................................
// Console function for returning player positions
//.............................................................

$consoleFunctions::ProjectName = "killer.kork";

function Con::spewPP()
{
  InitContainerRadiusSearch("0 0 0", 10000, $TypeMasks::PlayerObjectType);

  while( (%obj = containerSearchNext()) != 0 )
  {
   
    // ignore dead players
    if( %obj.getState() $= "Dead" )
      continue;
      
    echo( %obj @ " " @ %obj.getShapeName() @ 
          " at " @ %obj.getPosition() @ " in state " @ %obj.getState());
  }
  
  return %index;
}

function Con::fireOnce(%name)
{
  %obj = Con::resolveName(%name);
   %obj.fireOnce();
}

function Con::fireAuto(%name, %isOn)
{
  %obj = Con::resolveName(%name);
   if( %isOn )
      %obj.fireStart();
   else
      %obj.fireStop();
}

function Con::resolveName(%name)
{
  InitContainerRadiusSearch("0 0 0", 10000, $TypeMasks::PlayerObjectType);

  while( (%obj = containerSearchNext()) != 0 )
  {
    if( %name $= %obj.getShapeName() ||
        strToPlayerName(%name) $= %obj.getShapeName() )
      return %obj;
  }
  error("==> Unable to resolve name " @ %name);
  return %name;
}

function Con::setDebug(%name, %debugLvl)
{
  %obj = Con::resolveName(%name);
  %obj.algo.debugLvl = %debugLvl;
}

function Con::setHard(%name)
{
  %obj = Con::resolveName(%name);
  %obj.setRepairRate(1000);
}

function Con::hardOn(%val)
{
  if( %val $= "" )
    %val = 1000;
    
  // find all clients
  %count = ClientGroup.getCount();
  for( %index = 0; %index < %count; %index++ )
  { 
    %client = ClientGroup.getObject(%index); 
    if( isObject(%client.player) && !%client.isAIControlled() )
      %client.player.setRepairRate(%val);
  } 
}


function Con::newCode()
{ exec($consoleFunctions::ProjectName @ "/server/scripts/aiPlayer.cs"); }

function Con::reload(%name, %val)
{
  if( %val $= "" )
    %val = 50;
  %obj = Con::resolveName(%name);
  %obj.setInventory(CrossbowAmmo, %val);
}

function Con::hurt(%name, %val)
{
  if( %val $= "" )
    %val = 80;
  %obj = Con::resolveName(%name);
  %obj.setDamageLevel(%val);
}

function Con::Act(%name, %actNum)
{
  %obj = Con::resolveName(%name);
  switch(%actNum)
  {
    case 1 : %actSeq = "run";
    case 2 : %actSeq = "back";
    case 3 : %actSeq = "side";
    case 4 : %actSeq = "look";
    case 5 : %actSeq = "head";
    case 6 : %actSeq = "fall";
    case 7 : %actSeq = "land";
    case 8 : %actSeq = "jump";
    case 9  : %actSeq = "death1";
    case 10 : %actSeq = "death2";
    case 11 : %actSeq = "death3";
    case 12 : %actSeq = "death4";
    case 13 : %actSeq = "death5";
    case 14 : %actSeq = "death6";
    case 15 : %actSeq = "death7";
    case 16 : %actSeq = "death8";
    case 17 : %actSeq = "death9";
    case 18 : %actSeq = "death10";  
    case 19 : %actSeq = "death11";
    case 20 : %actSeq = "looksn";
    case 21 : %actSeq = "lookms";
    case 22 : %actSeq = "scoutroot";
    case 23 : %actSeq = "headside";
    case 24 : %actSeq = "light_recoil";
    case 25 : %actSeq = "sitting";
    case 26 : %actSeq = "celsalute";
    case 27 : %actSeq = "celwave";
    case 28 : %actSeq = "standjump";
    case 29 : %actSeq = "looknw";
    case 30 : %actSeq = "dance";
    case 31 : %actSeq = "range";
    case 32 : %actSeq = "tauntbest";
    case 33 : %actSeq = "tauntimp";
    default : error ("error, not valid Action");
  }

  %obj.stop();  // just for testing, let's make him stop in his tracks
  %obj.setActionThread(%actSeq);
  return; 
}