//-----------------------------------------------------------------------------
// AI Player
//  modified by Matthew Evans, August 2005
//-----------------------------------------------------------------------------

echo("====================================================================");
echo("=============================== AI Player ==========================");
echo("====================================================================");

exec("./aiSensObj.cs");
exec("./aiAlgo1.cs");
// exec("./aiBrain1.cs");			// execute Team Two's ai code, if different
exec("./consoleFunctions.cs");

//-----------------------------------------------------------------------------
// AIPlayer callbacks
// The AIPlayer class implements the following callbacks:
//
//    PlayerData::onStuck(%this,%obj)
//    PlayerData::onUnStuck(%this,%obj)
//    PlayerData::onStop(%this,%obj)
//    PlayerData::onMove(%this,%obj)
//    PlayerData::onReachDestination(%this,%obj)
//    PlayerData::onTargetEnterLOS(%this,%obj)
//    PlayerData::onTargetExitLOS(%this,%obj)
//    PlayerData::onAdd(%this,%obj)
//
// Since the AIPlayer doesn't implement it's own datablock, these callbacks
// all take place in the PlayerData namespace.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// AIPlayer globals
//-----------------------------------------------------------------------------

// ==== Thinking Parameters
$AIPLayer::ThinkMin = 500;          // minimum time between think cycles
$AIPLayer::ThinkVar = 100;          // variability of think cycle timing
$AIPLayer::ThinkFast = 50;          // fast thinking time

// ==== Vision Parameters
$AIPlayer::VisDistRange = 300;      // maximum visible distance
$AIPlayer::VisDistClose = 30;       // highly visible distance
$AIPlayer::VisDistScale = 50;       // vision drop-off distance scale (see getVisProb)
$AIPlayer::VisFastRange = 150;      // maximum visible distance for fast check

$AIPlayer::VisMoveVel = 1.0;        // minimum speed for enhanced visibility
$AIPlayer::VisMoveCoeff = 2.0;      // increase in visibility of moving objects
$AIPlayer::VisImpactCoeff = 3.0;    // visibility of impacts (projectile explosions)

$AIPlayer::VisAngleRange = 120;     // maximum visible angle
$AIPlayer::VisAngleClose = 60;      // highly visible angle
$AIPlayer::VisAngleScale = 30;      // vision drop-off anglular scale

$AIPlayer::VisBaseMin = 2;          // rate of vision drop-off (see getVisProb)
$AIPlayer::VisBasePow = 2;          // sensitivity to visible fraction
$AIPlayer::VisPointNum = 5;         // points used to compute visible fraction
$AIPlayer::VisPointOffset = 0.1;    // z-offset from player position for lowest point
$AIPlayer::VisPointScale = (1.0 - $AIPlayer::VisPointOffset) / ($AIPlayer::VisPointNum - 1);

$AIPlayer::VisProjectileDir = 0.5;  // visible fraction depedence on angle for projectiles 
$AIPlayer::VisObjMax = 100;         // maximum number of sensed objects

// mask of visible objects reported in visList
$AIPlayer::VisObjMask = 
  $TypeMasks::PlayerObjectType |
  $TypeMasks::ProjectileObjectType |
  $TypeMasks::ItemObjectType;

// mask of opaque objects (things that block vision)
$AIPlayer::VisOpaqueMask = 
  $TypeMasks::PlayerObjectType |      // players
  $TypeMasks::TerrainObjectType |     // dirt, but not water
  $TypeMasks::StaticTSObjectType |    // trees and whatnot
  $TypeMasks::InteriorObjectType;     // walls

// mask of visible objects reported in the fastList (subset of $AIPlayer::VisObjMask)
$AIPlayer::VisFastMask = $TypeMasks::ProjectileObjectType;

// all visible objects
$AIPlayer::VisAllMask = $AIPlayer::VisOpaqueMask | $AIPlayer::VisObjMask;

// ==== Hearing Parameters
$AIPlayer::AudVelPlayer = 1.5; 
$AIPlayer::AudDistPlayer = 15;
$AIPlayer::AudDistProjectile = 20; 
$AIPlayer::AudDistImpact = 50;
$AIPlayer::AudObjMask = 
  $TypeMasks::PlayerObjectType |
  $TypeMasks::ProjectileObjectType;
  
// ==== Misc Parameters
$AIPlayer::DebugLevel = 2;
$AIPlayer::InitAmmo = 15;
$AIPlayer::TeamCount = 4;
$AIPlayer::BigDist = 1e5;
$AIPlayer::SmallNumber = 1e-6;
$AIPlayer::ProjectileLOSDist = 3;     // hack for seeing projectiles and Impacts
$AIPlayer::SensObjMask = $AIPlayer::VisObjMask | $AIPlayer::AudObjMask;
$AIPlayer::ClearPathMask =
  $TypeMasks::StaticTSObjectType |    // trees and whatnot
  $TypeMasks::InteriorObjectType;     // walls?

//-----------------------------------------------------------------------------
// DemoPlayer datablock used by AIPlayer 
//-----------------------------------------------------------------------------

datablock PlayerData(DemoPlayer : PlayerBody)
{
  shootingDelay = 2000;  // just a place holder
};

//-----------------------------------------------------------------------------
// Call backs (relayed to AIAlgo classes)
//-----------------------------------------------------------------------------

function DemoPlayer::onStuck(%this, %obj)
{ %obj.algo.onStuck(); }

function DemoPlayer::onUnStuck(%this, %obj)
{ %obj.algo.onUnStuck(); }

function DemoPlayer::onStop(%this, %obj)
{ %obj.algo.onStop(); }

function DemoPlayer::onMove(%this, %obj)
{ %obj.algo.onMove(); }

function DemoPlayer::onReachDestination(%this, %obj)
{ %obj.algo.onReachDestination(); }

function DemoPlayer::onEndOfPath(%this, %obj, %path)
{ %obj.algo.onEndOfPath(%path); }

function DemoPlayer::onEndSequence(%this, %obj, %slot)
{ %obj.algo.onEndSequence(%slot); }

// this one is special
function AIPlayer::onDeath(%this, %obj)
{ %this.algo.onDeath(%obj); }

//-----------------------------------------------------------------------------
// AIPlayer statics 
//-----------------------------------------------------------------------------

function AIPlayer::spawn(%name, %spawnPoint, %path)
{
  // Create the demo player object
  %player = new AIPlayer() {
    dataBlock = DemoPlayer;
    shootingDelay = 2000;
    path = %path;
    algo = 0;
    team = 0;
  };
  
  MissionCleanup.add(%player);
  %player.setShapeName(%name);
  %player.setTransform(%spawnPoint);
  return %player;
}

function AIPlayer::spawnOnPath(%name,%path,%index)
{
  // Spawn a player and place him on the first node of the path
  if (!isObject(%path))
    return;
  
  // HACK: fix this so that index -1 is random,
  //   and index out of bounds is checked
  if( %index < 0 || %index >= %path.getCount() )
    %index = mFloor(getRandom(0.1, %path.getCount() - 0.1));
  
  %node = %path.getObject(%index);
  %player = AIPlayer::spawn(%name, %node.getTransform(), %path);
  return %player;
}

//-----------------------------------------------------------------------------
// Player class overrides
//-----------------------------------------------------------------------------

function AIPlayer::playDeathAnimation(%this)
{
  %this.deathIdx = mFloor(getRandom(1.1, 11.9));
  %this.setActionThread("Death" @ %this.deathIdx);
}

//-----------------------------------------------------------------------------
// initialization and thinking
//-----------------------------------------------------------------------------

function AIPlayer::init(%this, %algo, %team)
{
  %this.mountImage(CrossbowImage, 0);
  %this.setInventory(CrossbowAmmo, $AIPlayer::InitAmmo);

  // additional info
  %this.algo = %algo;
  %this.team = %team;
}

function AIPlayer::thinkFast(%this)
{
  if( %this.getDamagePercent() < 1.0 && %this.getState() !$= "Dead" )
  {
    // update fastList and think fast if there is anything there
    %fastNum = %this.updateFastList();
    if( %fastNum > 0 )
      %this.algo.thinkFast(%fastNum);
  }
}

function AIPlayer::think(%this)
{
  // dead men don't think
  if( %this.getDamagePercent() < 1.0 && %this.getState() !$= "Dead" )
  {
    // think
    %this.algo.think();

    // schedule calls to thinkFast and think
    %delay = $AIPLayer::ThinkMin + $AIPLayer::ThinkVar * getRandom();
    for( %time = $AIPLayer::ThinkFast; %time < %delay; %time += $AIPLayer::ThinkFast )
      %this.schedule(%time, thinkFast);
    %this.schedule(%delay, think);
  }
  else
  {
    messageAll('MsgClientKilled','%1 is %2!', %this.getShapeName(), %this.getState());
    
    // I'm not sure how memory clean up should be done
    //  around here, but this might be the place to do it...
    // %this.algo.delete();
  }
}

//-----------------------------------------------------------------------------
// navigation 
//-----------------------------------------------------------------------------

// Start the player following a path
function AIPlayer::followPath(%this,%path,%node)
{
  // what does this do?
  %this.stopThread(0);

  // be sure that the path is valid
  if( !isObject(%path) )
  {
    %this.path = "";
    return;
  }
  
  // set target node
  if( %node > %path.getCount() - 1 )
    %this.targetNode = %path.getCount() - 1;
  else
    %this.targetNode = %node;

  // check current node
  if( %this.currentNode $= "" )
    %this.currentNode = 0;

  // check path
  if( %this.path !$= %path )
  {
    %this.currentNode = 0;
    %this.path = %path;
  }

  // move to next node
  %this.moveToNode(%this.currentNode);
}

function AIPlayer::moveToNextNode(%this)
{
   if (%this.targetNode < 0 || %this.currentNode < %this.targetNode) {
      if (%this.currentNode < %this.path.getCount() - 1)
         %this.moveToNode(%this.currentNode + 1);
      else
         %this.moveToNode(0);
   }
   else
      if (%this.currentNode == 0)
         %this.moveToNode(%this.path.getCount() - 1);
      else
         %this.moveToNode(%this.currentNode - 1);
}

function AIPlayer::moveToNode(%this,%index)
{
   // Move to the given path node index
   %this.currentNode = %index;
   %node = %this.path.getObject(%index);
   %this.setMoveDestination(%node.getTransform(), %index == %this.targetNode);
}


//-----------------------------------------------------------------------------
// task management
//-----------------------------------------------------------------------------

function AIPlayer::pushTask(%this,%method)
{
  if (%this.taskIndex $= "") 
  {
    %this.taskIndex = 0;
    %this.taskCurrent = -1;
  }
  %this.task[%this.taskIndex] = %method; 
  %this.taskIndex++;
  if (%this.taskCurrent == -1)
    %this.executeTask(%this.taskIndex - 1);
}

function AIPlayer::clearTasks(%this)
{
  %this.taskIndex = 0;
  %this.taskCurrent = -1;
}

function AIPlayer::nextTask(%this)
{
  if (%this.taskCurrent != -1)
    if (%this.taskCurrent < %this.taskIndex - 1)
      %this.executeTask(%this.taskCurrent++);
    else
      %this.taskCurrent = -1;
}

function AIPlayer::executeTask(%this,%index)
{
  %this.taskCurrent = %index;
  eval(%this.getId() @ "." @ %this.task[%index] @ ";");
}

function AIPlayer::wait(%this, %time)
{
  %this.schedule(%time * 1000, "nextTask");
}

//-----------------------------------------------------------------------------
// sight and target detection
//-----------------------------------------------------------------------------

// true if the first thing hit on a ray to %pos is %obj
function AIPlayer::isObjLOS(%this, %obj, %pos)
{
  %posEye = %this.getEyePoint();
  %objList = containerRayCast(%posEye, %pos, $AIPlayer::VisAllMask, %this);
  %objHit = getword(%objList, 0);

  // projectiles are special (because their position is usually wrong)
  if( %obj.getType() & $TypeMasks::ProjectileObjectType )
  {
    // if nothing was hit, that's good enough
    if( %objHit == 0 )
      return true;
      
    // if the hit point is close to the projectile, that's also good enough
    %dist = VectorLen(VectorSub(%pos, getWords(%objList, 1, 3)));
    return %dist < $AIPlayer::ProjectileLOSDist;
  }
  
  // if nothing was hit, the position must be wrong, so that's good enough
  return %objHit == %obj || %objHit == 0;
}

// standard probability computation
function AIPlayer::getVisProb(%val, %visFrac, %range, %close, %scale)
{
  if( %visFrac == 0.0 )
    %prob = 0.0;
  else if( %val < %close )
    %prob = 1.0;
  else if( %val > %range )
    %prob = 0.0;
  else
  {
    %base = $AIPlayer::VisBaseMin / mPow(%visFrac, $AIPlayer::VisBasePow);
    %pval = mPow((%val - %close) / %scale, 2);
    %prob = mPow(%base, -1.0 * %pval);
  }
  return %prob;
}

// player vision determination (returns true if %obj is seen)
function AIPlayer::isObjVis(%this, %obj, %sensObj)
{
  // make sure %obj is a visible object type
  if( !(%obj.getType() & $AIPlayer::VisObjMask) )
    return false;
    
  // ==== Count Visible Points
  if( %sensObj.isProjectile() )
  {
    // for projectiles, make them less visible when coming or going
    %pos = %sensObj.pos;
    %cos = VectorDot(VectorNormalize(%sensObj.vel),
                     VectorNormalize(VectorSub(%this.getEyePoint(), %pos)));
    if( %this.isObjLOS(%obj, %pos) )
      %visFrac = 1 - $AIPlayer::VisProjectileDir * %cos;
    else
      %visFrac = 0.0;    
  }
  if( !%sensObj.isPlayer() )
  {
    // for non players, just use the object's position
    %pos = %obj.getPosition();
    if( %this.isObjLOS(%obj, %pos) )
      %visFrac = 1.0;
    else
      %visFrac = 0.0;    
  }
  else
  {
    // for players, take several points
    %posFoot = %obj.getPosition();
    %posHead = %obj.getEyePoint();
    %vecBody = VectorSub(%posHead, %posFoot);
    
    %numVis = 0;
    %pos = "0 0 0";
    for( %index = 0; %index < $AIPlayer::VisPointNum; %index++ )
    {
      %del = $AIPlayer::VisPointOffset + %index * $AIPlayer::VisPointScale;
      %posVis[%index] = VectorAdd(%posFoot, VectorScale(%vecBody, %del));
      %isVis[%index] = %this.isObjLOS(%obj, %posVis[%index]);
      
      // accumulate visual position
      if( %isVis[%index] )
      {
        %numVis++;
        %pos = VectorAdd(%pos, %posVis[%index]);
      }
    }
    
    // compute visual fraction and visual position
    %visFrac = %numVis / $AIPlayer::VisPointNum;
    if( %numVis == 0 )
      %pos = VectorAdd(%posFoot, VectorScale(%vecBody, 0.5));
    else
      %pos = VectorScale(%pos, 1 / %numVis);
  }

  // update senseObj position to visual position
  %sensObj.pos = %pos;
  
  // ==== Compute sight probability
  
  // set default visiblity coefficient
  %coeff = 1.0;
  
  // check for moving objects
  if( %sensObj.vel > $AIPlayer::VisMoveVel )
    %coeff = $AIPlayer::VisMoveCoeff;

  // check for impacts
  if( (%sensObj.type & $AISensObj::ImpactType) != 0 )
    %coeff = $AIPlayer::VisImpactCoeff;

  // distance based probability
  %dist = %this.getDistTo(%pos);
  %close = $AIPlayer::VisDistClose * %coeff;
  %scale = $AIPlayer::VisDistScale * %coeff;
  %pDist = AIPlayer::getVisProb(%dist, %visFrac, $AIPlayer::VisDistRange, %close, %scale);

  // field of view based probability
  %angle = %this.getAngleTo(%pos);
  %pView = AIPlayer::getVisProb(%angle, %visFrac, $AIPlayer::VisAngleRange, 
             $AIPlayer::VisAngleClose, $AIPlayer::VisAngleScale);
  
  // ==== Final Binary Determination
  %rand = getRandom();
  %prob = %pDist * %pView;

  //error("  " @ %sensObj.name @ "  " @ %sensObj.getTypeName() @
  //      " visFrac == " @ %visFrac @ ", prob "  @ %prob  @ ", rand "  @ %rand);
  //error("    pDist " @ %pDist @ ", pView " @ %pView @
  //      ", dist "  @ %dist  @ ", angle " @ %angle);

  // return true if seen
  return %rand < %prob;
}

// player auditory determination (returns true if %obj is heard)
function AIPlayer::isObjAud(%this, %obj, %sensObj)
{
  // make sure %obj is a audible object type
  if( !(%obj.getType() & $AIPlayer::AudObjMask) )
    return false;

  // compute distance
  %dist = %this.getDistTo(%sensObj.pos);

  // check for players
  if( %sensObj.isPlayer() && %dist < $AIPlayer::AudDistPlayer &&
      %sensObj.vel > $AIPlayer::AudPlayerVel )
    return true;

  // check for impacts
  if( %sensObj.isImpact() && %dist < $AIPlayer::AudDistImpact )
    return true;

  // check for projectiles
  if( %sensObj.isProjectile() && %dist < $AIPlayer::AudDistProjectile )
    return true;

  return false;
}

// update %this.algo.visList to reflect what is currently sensed
//   Sense objects in visList are reused, so AISensObj::copy 
//   should be used to retain sense info found in the visList.
function AIPlayer::updateVisList(%this)
{
  // search for nearby players
  InitContainerRadiusSearch(%this.getEyePoint(), $AIPlayer::VisDistRange,
                            $AIPlayer::SensObjMask);

  %index = 0;
  while( isObject(%obj = containerSearchNext()) )
  {
    // if over the max, just clear the search list
    if( %index >= $AIPlayer::VisObjMax )
      continue;
      
    // ignore self
    if( %obj == %this )
      continue;

    // we might detect this obj, so init an unused sensObj in visList
    %sensObj = %this.algo.visList[%index];    // DANGER: use algo's visList
    if( !isObject(%sensObj) )
    {
      %sensObj = AISensObj::create();
      %this.algo.visList[%index] = %sensObj;  // DANGER: use algo's visList
    }
    %sensObj.init(%obj);

    // determine if we can see or hear this player
    if( %this.isObjVis(%obj, %sensObj) )
      %sensObj.sense = 1;    // saw it
    else if( %this.isObjAud(%obj, %sensObj) )
      %sensObj.sense = 2;    // heard it
    else
      continue;             // detection failed
    
    // we detected this obj, so go to next sensObj in visList
    %index++;
  }
  
  %this.algo.visNum = %index;
  return %index;
}

// update %this.algo.fastList to reflect what is currently sensed
//   much like updateVisList, but only for projectiles 
function AIPlayer::updateFastList(%this)
{
  // search for nearby players
  InitContainerRadiusSearch(%this.getEyePoint(), $AIPlayer::VisFastRange,
                            $AIPlayer::VisFastMask);

  %index = 0;
  while( isObject(%obj = containerSearchNext()) )
  {
    // if over the max, just clear the search list
    if( %index >= $AIPlayer::VisObjMax || %obj == %this )
      continue;

    // we might detect this obj, so init an unused sensObj in fastList
    %sensObj = %this.algo.fastList[%index];    // DANGER: use algo's fastList
    if( !isObject(%sensObj) )
    {
      %sensObj = AISensObj::create();
      %this.algo.fastList[%index] = %sensObj;  // DANGER: use algo's fastList
    }
    %sensObj.init(%obj);

    // determine if we can see it
    if( %this.isObjVis(%obj, %sensObj) )
      %sensObj.sense = 1;    // saw it
    else
      continue;             // detection failed
    
    // we detected this obj, so go to next sensObj in visList
    %index++;
  }
  
  %this.algo.fastNum = %index;
  return %index;
}

//-----------------------------------------------------------------------------
// looking around
//-----------------------------------------------------------------------------

// Rotate the player by %angle (in degrees)
//  The aim point should be cleared later as necessary.
function AIPlayer::doYaw(%this, %angle)
{
  %pos = %this.getPosition();
  %eye = %this.getEyeVector();

  // rotate eye vector and add to position
  %vec = AIPlayer::vecRotateAz(%eye, %angle);
  %posAim = VectorAdd(%pos, VectorScale(%vec, 100));
  
  // set aim location
  %this.setAimLocation(%posAim);
}

// move to a destination %dist from current location
//  %angle sets the angle from the eye vector to the destination
//  %isEnd is used to slow the approach to the destination (if true)
function AIPlayer::doMove(%this, %dist, %angle, %isEnd)
{
  %pos = %this.getPosition();
  %eye = %this.getEyeVector();

  // rotate eye vector and add to position
  %vec = AIPlayer::vecRotateAz(%eye, %angle);
  %dest = VectorAdd(%pos, VectorScale(%vec, %dist));
  
  // set move destionation
  %this.setMoveDestination(%dest, %isEnd);
}

//-----------------------------------------------------------------------------
// firing
//-----------------------------------------------------------------------------

// fire one shot
function AIPlayer::fireOnce(%this, %mask, %maskDist)
{
  // dead men don't shoot
  if( %this.getState() $= "Dead" )
    return false;
    
  // if %mask is given, check for clear firing path
  if( %mask != 0 )
  {
    // check only out to %maskDist, if given and target is far enough
    %posAim = %this.getAimLocation();
    if( %posAim $= "" )
      %dist = %maskDist;
    else
    {
      %dist = %this.getDistTo(%posAim) - 1;
      if( %maskDist < %dist )
        %dist = %maskDist;
    }

    %vec = %this.getMuzzleVector(0);
    %pos = %this.getRelPos(%vec, %dist);

    // if path is not clear, return false
    if( !%this.isClearTo(%pos, %mask) )
      return false;
  }
  
  // pulse the trigger
  if( !%this.isImageFiring(0) )
    %this.setImageTrigger(0, true);
  %this.setImageTrigger(0, false);
  return true;
}

// fire one shot at %pos
function AIPlayer::fireOnceAt(%this, %pos, %delay, %mask)
{
  %this.setAimLocation(%pos);
  %this.schedule(%delay, fireOnce, %mask);
  %this.schedule(%delay + 10, clearAim);
}

// stop auto firing
function AIPlayer::fireStop(%this)
{ cancel(%this.triggerSched); }

// start auto firing
function AIPlayer::fireStart(%this)
{
  %this.fireStop();
  %this.fireAuto();
}

// internal function, for scheduling trigger impulses
function AIPlayer::fireAuto(%this)
{
  %this.fireOnce();
  if( %this.shootingDelay > 100 )
    %this.triggerSched = %this.schedule(%this.shootingDelay, fireAuto);
  else
    error("AIPlayer::fireAuto - shooting delay too short == " @ %this.shootingDelay);
}

//-----------------------------------------------------------------------------
// geometrical computations (member functions)
//-----------------------------------------------------------------------------

// Return relative position
function AIPlayer::getRelPos(%this, %vec, %dist)
{
  if( %dist $= "" )
    return VectorAdd(%this.getEyePoint(), %vec);
  return VectorAdd(%this.getEyePoint(), VectorScale(%vec, %dist));
}

// Return position vector to a position
function AIPlayer::getVectorTo(%this, %pos)
{ return VectorSub(%pos, %this.getPosition()); }

// Return distance to a position
function AIPlayer::getDistTo(%this, %pos)
{ return VectorDist(%pos, %this.getPosition()); }

// Return azimuthal angle to a position
function AIPlayer::getAzTo(%this, %pos)
{ return AIPlayer::getAz(%this.getVectorTo(%pos), %this.getEyeVector()); }

// Return elevation angle to a position
function AIPlayer::getElTo(%this, %pos)
{ return AIPlayer::getEl(%this.getVectorTo(%pos), %this.getEyeVector()); }

// return angle between eye vector and %pos
function AIPlayer::getAngleTo(%this, %pos)
{ return AIPlayer::getAngle(%this.getVectorTo(%pos), %this.getEyeVector()); }

// return impact vector
function AIPlayer::getVectorImpactTo(%this, %pos, %vel)
{ return AIPlayer::getVectorImpact(%this.getEyePoint(), %pos, %vel); }

// return impact distace, negative means not approaching
function AIPlayer::getDistImpactTo(%this, %pos, %vel)
{ return AIPlayer::getDistImpact(%this.getEyePoint(), %pos, %vel); }

// return time to intersection with impact plane
function AIPlayer::getHitTimeTo(%this, %pos, %vel)
{  
  %vec = %this.getVectorTo(%pos);
  %vecn = VectorNormalize(%vec);
  %myVel = %this.getVelocity();
  
  %closingSpeed = VectorDot(%myVel, %vecn) - VectorDot(%vel, %vecn);
  return VectorLen(%vec) / %closingSpeed;
}

// return impact distace, but to predicted position at time of impact
function AIPlayer::getHitDistTo(%this, %pos, %vel)
{  
  %time = %this.getHitTimeTo(%pos, %vel);
  %myVel = %this.getVelocity();
  %myPos = %this.getRelPos(%myVel, %time);
  %dist = AIPlayer::getDistImpact(%myPos, %pos, %vel);
  
  return %dist @ " " @ %time;
}

// check for a clear path to %dest (from muzzle point)
function AIPlayer::isClearTo(%this, %dest, %mask) 
{ return AIPlayer::isClear(%this.getMuzzlePoint(0), %dest, %mask, %this); }

//-----------------------------------------------------------------------------
// geometrical computations (statics)
//-----------------------------------------------------------------------------

// Return azimuthal angle of a vector in relation to world origin
function AIPlayer::getDirection(%vec)
{ return AIPlayer::getAz(%vec, new Vector3F(1, 0, 0)); }

// Return azimuthal angle between two vectors (in the XY plane)
function AIPlayer::getAz(%vec1, %vec2)
{
  // normalize
  %vec1n = VectorNormalize(%vec1);
  %vec2n = VectorNormalize(%vec2);

  // project onto XY plane
  %vec1p = setWord(%vec1n, 2, 0);
  %vec2p = setWord(%vec2n, 2, 0);

  // compute angle between
  %vecDot = VectorDot(%vec1p, %vec2p);
  %vecCross = VectorCross(%vec1p, %vec2p);
  %angle = mATan(getWord(%vecCross, 2), %vecDot);
  
  // convert to degrees and return
  %degangle = mRadToDeg(%angle);
  return %degangle;
}

// Return elevation angle between two vectors
function AIPlayer::getEl(%vec1, %vec2)
{
  // normalize
  %vec1n = VectorNormalize(%vec1);
  %vec2n = VectorNormalize(%vec2);

  // compute angle between
  %vecd = VectorSub(%vec1n, %vec2n);
  %angle = mASin(getWord(%vecd, 2));
  
  // convert to degrees and return
  %degangle = mRadToDeg(%angle);
  return %degangle;
}

// Return angle between two vectors
function AIPlayer::getAngle(%vec1, %vec2)
{
  %vec1n = VectorNormalize(%vec1);
  %vec2n = VectorNormalize(%vec2);

  %vdot = VectorDot(%vec1n, %vec2n);
  %angle = mACos(%vdot);

  // convert to degrees and return
  %degangle = mRadToDeg(%angle);
  return %degangle;
}

// Rotate a vector in the XY plane (i.e., around Z-axis)
// (%angle is in degrees)
function AIPlayer::vecRotateAz(%vec, %angle)
{
  %rot = MatrixCreateFromEuler("0 0 " @ mDegToRad(%angle));
  return MatrixMulVector(%rot, %vec);
}

// Return impact vector
//  this is the vector from %pos to the closest approach of an object
//  with position %objPos and velocity %objVel
function AIPlayer::getVectorImpact(%pos, %objPos, %objVel)
{
  %delta = VectorSub(%objPos, %pos);

  // if velocity is zero, return %delta
  if( VectorLen(%objVel) < $AIPlayer::SmallNumber )
    return %delta;
  
  %dirVel = VectorNormalize(%objVel);
  return VectorCross(%dirVel, VectorCross(%delta, %dirVel));
}

// Return impact distace (negative means object is not approaching)
//  much of getVectorImpact is reproduced here in order to produce sign of return value
function AIPlayer::getDistImpact(%pos, %objPos, %objVel)
{
  %delta = VectorSub(%objPos, %pos);

  // if velocity is zero, return negative distance
  if( VectorLen(%objVel) == 0.0 )
    return -1 * VectorLen(%delta);
  
  %dir = VectorNormalize(%objVel);
  %dist = VectorLen(VectorCross(%delta, %dir));
  
  // if object is not approaching, return negative distance
  if( VectorDot(%dir, %delta) >= 0 )
    return -1 * %dist;
    
  // object is approaching, return impact distance
  return %dist;
}

// check for a clear path to %dest (from muzzle point)
function AIPlayer::isClear(%pos, %dest, %mask, %exempt) 
{
  // if no mask is given, use default mask
  if( %mask == 0 )
    %mask = $AIPlayer::ClearPathMask;

  %objList = containerRayCast(%pos, %dest, %mask, %exempt);
  %objHit = getWord(%objList, 0);

  return %objHit == 0;
}
//-----------------------------------------------------------------------------
// handy statics
//-----------------------------------------------------------------------------

function AIPlayer::isTeammate(%obj, %team) 
{
  // make sure we are talking about a player
  if( !AIPlayer::isPlayer(%obj) )
    return false;
    
  // return true if %team is my team (team 0 is no team)
  return %obj.team != 0 && %obj.team == %team;
}

function AIPlayer::isMoving(%obj, %minSpeed) 
{
  // make sure we are talking about a player
  if( !AIPlayer::isPlayer(%obj) )
    return false;
  
  // use default if %minSpeed not given
  if( %minSpeed $= "" )
    %minSpeed = $AIPlayer::SmallNumber;
    
  // return true if speed is greater than %minSpeed
  return VectorLen(%obj.getVelocity()) > %minSpeed;
}

function AIPlayer::isPlayer(%obj) 
{ return isObject(%obj) && (%obj.getType() & $TypeMasks::PlayerObjectType); }

function AIPlayer::isHuman(%obj) 
{
  // check obj first
  if( !AIPlayer::isPlayer(%obj) )
    return false;
  
  // find all clients
  %count = ClientGroup.getCount();
  for( %index = 0; %index < %count; %index++ )
  { 
    %client = ClientGroup.getObject(%index); 
    if( isObject(%client.player) && %client.player == %obj )
      return !%client.isAIControlled();
  } 
  return false; 
} 

function AIPlayer::isInWater(%obj) 
{
  %pos = %obj.getPosition();
  %posUp = setWord(%pos, 2, $AIPlayer::BigDist);
  return !AIPlayer::isClear(%pos, %posUp, $TypeMasks::WaterObjectType);
}

// just to remember how it's done...
function AIPlayer::isFiring(%obj) 
{ return %obj.isImageFiring(0); }

// convert an object type mask to a string
function AIPlayer::getTypeName(%type)
{
  // make a concatenation of type strings
  %str = "";
  if( %type & $TypeMasks::TerrainObjectType )
    %str = %str @ "Terrain";
  if( %type & $TypeMasks::InteriorObjectType )
    %str = %str @ "Interior";
  if( %type & $TypeMasks::WaterObjectType )
    %str = %str @ "Water";
  if( %type & $TypeMasks::DecalManagerObjectType )
    %str = %str @ "DecalManager";
  if( %type & $TypeMasks::PlayerObjectType )
    %str = %str @ "Player";
  if( %type & $TypeMasks::ItemObjectType )
    %str = %str @ "Item";
  if( %type & $TypeMasks::ProjectileObjectType )
    %str = %str @ "Projectile";
  if( %type & $TypeMasks::ExplosionObjectType )
    %str = %str @ "Explosion";
  if( %type & $TypeMasks::DebrisObjectType )
    %str = %str @ "Debris";
  if( %type & $TypeMasks::CorpseObjectType )
    %str = %str @ "Corpse";
  if( %type & $TypeMasks::StaticTSObjectType )
    %str = %str @ "StaticTS";

  // unknown type... just use number
  if( %str $= "" )
    %str = "Type" @ %type;
    
  return %str;
}
//-----------------------------------------------------------------------------
// AI Manager
//  This class loads the AI classes, respawns the dead ones, and calls
//  the think function every 500 ms.
//-----------------------------------------------------------------------------

function AIManager::think(%this)
{
  %haveSpawned = false;
    
  // respawn dead bots (not more than one per cycle)
  for( %index = 0; %index < ($AIPlayer::TeamCount * 2) && !%haveSpawned; %index++ )
  {
    if( !isObject(%this.player[%index]) )
    {
      // Create player object
      %haveSpawned = true;
      %team = (%index % 2) + 1;
      switch( %index )
      {
        case 0:
        %plr = AIPlayer::spawnOnPath("Evil Brain","MissionGroup/Paths/Path1", 1);
        %algo = AIAlgo1::create(%plr, $AIPlayer::DebugLevel);
        %algo.isHumanFriendly = false;

        case 1:
        %plr = AIPlayer::spawnOnPath("Evil Algo","MissionGroup/Paths/Path1", 0);
        %algo = AIAlgo1::create(%plr, $AIPlayer::DebugLevel);
        %algo.isHumanFriendly = false;
        
        default:
        if( %index % 2 == 0 )
        {
          %path = "MissionGroup/Paths/Path1";
          %plr = AIPlayer::spawnOnPath("Brain" @ %index, %path, -1);
          %algo = AIAlgo1::create(%plr, $AIPlayer::DebugLevel);
			%algo.isHumanFriendly = true;
        }
        else
        {
          %path = "MissionGroup/Paths/Path1";
          %plr = AIPlayer::spawnOnPath("Algo" @ %index, %path, -1);
          %algo = AIAlgo1::create(%plr, $AIPlayer::DebugLevel);
		  %algo.isHumanFriendly = true;
        }
      }
      // wake the algo and start thinking
      %plr.init(%algo, %team);
      %algo.wake();
      %plr.schedule(100, think);
    
      // save the player info
      %this.player[%index] = %plr;

      // increment spawn count and report
      if( %this.spawnCount[%team] $= "" )
        %this.spawnCount[%team] = 0;
      %this.spawnCount[%team]++;
      messageAll('MsgClientKilled','SPAWNS: Algo %1, Brain %2', 
                 %this.spawnCount[1], %this.spawnCount[2]);
    }
  }

  // schedule another call to this function
  %this.schedule(3000, think);
}