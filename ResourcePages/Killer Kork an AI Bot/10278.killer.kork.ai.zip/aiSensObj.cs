// ============================================================
// AI Sense Object
//  by Matthew Evans, August 2005
//
//  This class is for describing objects sensed by bots.
//
//    sense = 0;           // 0 == unknown, 1 == visual, 2 = auditory
//
//    pos = 0;
//    vel = 0;
//    dir = 0;      // forward direction
//
//    type = 0;
//    id = 0;
//    dbStr = "";
//
//    team = 0;
//    name = "Unknown";
//    state = "Unknown";
//    damage = 0;
//    
//    // this shouldn't be here, but it helps for debugging
//    obj = 0;
//
//  There is something wrong in my use of it (or in the imp?),
//  which prevents .delete() from working... can you fix it?
// ============================================================

$AISensObj::TypeCount = 0;

// player types
$AISensObj::PlayerType     = (1 << $AISensObj::TypeCount++);
$AISensObj::HumanType      = (1 << $AISensObj::TypeCount++);
$AISensObj::CorpseType     = (1 << $AISensObj::TypeCount++);
$AISensObj::FiringType     = (1 << $AISensObj::TypeCount++);

// live fire types
$AISensObj::ProjectileType = (1 << $AISensObj::TypeCount++);
$AISensObj::ImpactType     = (1 << $AISensObj::TypeCount++);

// item types
$AISensObj::WeaponType     = (1 << $AISensObj::TypeCount++);
$AISensObj::HealthType     = (1 << $AISensObj::TypeCount++);
$AISensObj::AmmoType       = (1 << $AISensObj::TypeCount++);
$AISensObj::JunkType       = (1 << $AISensObj::TypeCount++);

// just for debugging
$AISensObj::Count = 0;

function AISensObj::create()
{
  %sensObj = new ScriptObject(AISensObj) {};

  //$AISensObj::Count++;
  //warn("AISensObj::Count == " @ $AISensObj::Count);
  
  MissionCleanup.add(%sensObj);
  return %sensObj;
}

// sensing for objects
function AISensObj::init(%this, %obj)
{
  // generic init
  %this.sense = 0;
  
  %this.pos = 0;
  %this.vel = 0;
  %this.dir = 0;

  %this.type = 0;
  %this.id = 0;
  //%this.dbStr = "";

  %this.team = 0;
  %this.name = "Unknown";
  %this.state = "Unknown";
  %this.damage = 0;

  %this.obj = %obj; // shouldn't need this

  // generic init
  if( !isObject(%obj) )
    return;
    
  %this.pos = %obj.getPosition();
  %this.id = %obj.getId();
  //%this.dbStr = "" @ %obj.dataBlock;
  
  // specific properties
  %type = %obj.getType();
  if( %type & $TypeMasks::PlayerObjectType )
  {
    // set type
    if( %obj.getState() $= "Dead" )
      %this.type = $AISensObj::CorpseType;
    else
      %this.type = $AISensObj::PlayerType;
    if( AIPlayer::isHuman(%obj) )
      %this.type |= $AISensObj::HumanType;
    if( AIPlayer::isFiring(%obj) )
      %this.type |= $AISensObj::FiringType;
    
    // set info
    %this.vel = %obj.getVelocity();
    %this.dir = %obj.getEyeVector();

    %this.team = %obj.team;
    %this.name = %obj.getShapeName();
    %this.state = %obj.getState();
    %this.damage = %obj.getDamagePercent();
  }
  else if( %type & $TypeMasks::ItemObjectType )
  {
    switch$( %obj.dataBlock )
    {
      case "Crossbow":     %this.type = $AISensObj::WeaponType;
      case "CrossbowAmmo": %this.type = $AISensObj::AmmoType;
      case "HealthPatch":  %this.type = $AISensObj::HealthType;
      default:             %this.type = $AISensObj::JunkType;
    }
  }
  else if( %type & $TypeMasks::ProjectileObjectType )
  {
    if( VectorLen(%obj.initialVelocity) > 0 )
      %this.type = $AISensObj::ProjectileType;
    else
      %this.type = $AISensObj::ImpactType;
    %this.vel = %obj.initialVelocity;
    %this.name = %obj.dataBlock @ %obj.getId();
  }
}

// make a copy of a sens object
function AISensObj::copy(%this, %obj)
{
  %this.sense = %obj.sense;
  
  %this.pos = %obj.pos;
  %this.vel = %obj.vel;
  %this.dir = %obj.dir;

  %this.type = %obj.type;
  %this.id = %obj.id;
  //%this.dbStr = %obj.dbStr;

  %this.team = %obj.team;
  %this.name = %obj.name;
  %this.state = %obj.state;
  %this.damage = %obj.damage;

  %this.obj = %obj.obj;
}

// type convenience
function AISensObj::getTypeName(%this)
{ return AISensObj::getTypeStr(%this.type); }

function AISensObj::getTypeStr(%type)
{
  %str = "";

  if( %type & $AISensObj::HumanType )
    %str = %str @ "Human";
  if( %type & $AISensObj::PlayerType )
    %str = %str @ "Player";
  if( %type & $AISensObj::CorpseType )
    %str = %str @ "Corpse";
  if( %type & $AISensObj::ProjectileType )
    %str = %str @ "Projectile";
  if( %type & $AISensObj::ImpactType )
    %str = %str @ "Impact";
  if( %type & $AISensObj::HealthType )
    %str = %str @ "Health";
  if( %type & $AISensObj::AmmoType )
    %str = %str @ "Ammo";
  if( %type & $AISensObj::WeaponType )
    %str = %str @ "Weapon";
  if( %type & $AISensObj::JunkType )
    %str = %str @ "Junk";

  if( %str $= "" )
    %str = "Type" @ %type;
    
  return %str;
}

// player
function AISensObj::isPlayer(%this)
{ return %this.type & $AISensObj::PlayerType; }

function AISensObj::isHuman(%this)
{ return %this.type & $AISensObj::HumanType; }

function AISensObj::isCorpse(%this)
{ return %this.type & $AISensObj::CorpseType; }

function AISensObj::isFiring(%this)
{ return %this.type & $AISensObj::FiringType; }

function AISensObj::isBot(%this)
{ return %this.isPlayer() && !%this.isHuman(); }

// live fire
function AISensObj::isProjectile(%this)
{ return %this.type & $AISensObj::ProjectileType; }

function AISensObj::isImpact(%this)
{ return %this.type & $AISensObj::ImpactType; }

function AISensObj::isLiveFire(%this)
{ return %this.type & ($AISensObj::ProjectileType | $AISensObj::ImpactType); }

// item types
function AISensObj::isWeapon(%this)
{ return %this.type & $AISensObj::WeaponType; }

function AISensObj::isHealth(%this)
{ return %this.type & $AISensObj::HealthType; }

function AISensObj::isAmmo(%this)
{ return %this.type & $AISensObj::AmmoType; }

function AISensObj::isJunk(%this)
{ return %this.type & $AISensObj::JunkType; }

function AISensObj::isItem(%this)
{ return %this.type & ($AISensObj::WeaponType | $AISensObj::HealthType |
                       $AISensObj::AmmoType   | $AISensObj::JunkType); }

