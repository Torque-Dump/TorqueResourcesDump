//-----------------------------------------------------------------------------
// AI Algorithm 1
//  by Matthew Evans, August 2005
//
// A wandering, flocking, hunter.
//
//
//-----------------------------------------------------------------------------

// ==== Wander parameters
$AIAlgo1::DistPathMax = 100;
$AIAlgo1::DistWander = 40;
$AIAlgo1::DistWanderInside = 2;
$AIAlgo1::DistDamageResp = 30;

// this is a mask of things to avoid while wandering
$AIAlgo1::RandDestMaxIter = 100;
$AIPlayer::WanderMask = 
  $TypeMasks::PlayerObjectType |      // players
  $TypeMasks::WaterObjectType |       // water
  $TypeMasks::StaticTSObjectType |    // trees and whatnot
  $TypeMasks::InteriorObjectType;     // walls?

// ==== Attack parameters
$AIAlgo1::AttackDist = 10;            // distance to attack destination
$AIAlgo1::AttackDelay = 50;           // firing delay in ms
$AIAlgo1::AttackRadius = 100;         // target circling offset
$AIAlgo1::AttackClose = 60;           // target closest, or weakest in this radius
$AIAlgo1::AttackSnipeDelay = 300;     // firing delay in ms (when sniping)
$AIAlgo1::AttackSnipeDist = 50;       // target is snipable if outside this radius
$AIAlgo1::AttackSnipeDot = -0.3;      // target is snipable if looking away

// ==== Threat parameters
$AIAlgo1::ThreatHitDist = 30;         // min projectile hit distance
$AIAlgo1::ThreatHitDistMine = 3;      // projectiles that are probably mine
$AIAlgo1::ThreatDistImpact = 30;      // impacts less than this are threats
$AIAlgo1::ThreatDistGuess = 100;      // guess at distance to enemy
$AIAlgo1::ThreatDistResp = 30;        // distance to run when threatened

// ==== Follow parameters
$AIAlgo1::FollowDist = 15;            // don't crowd the leader or we all get stuck
$AIAlgo1::FlankDist = 15;             // really used in assist

// ==== Fetch parameters
$AIAlgo1::FetchDist = 35;             // maximum distance to fetch from
$AIAlgo1::FetchTryMax = 2;            // number of times to try to fetch something
$AIAlgo1::FetchTryWait = 2;           // number of times wait before trying again (lame)

$AIAlgo1::FetchDamage = 0.5;          // damage level at which to fetch
$AIAlgo1::FetchAmmo = 8;              // ammo count at which to fetch
 
$AIAlgo1::FetchPointNum = 40;         // number of points to use in approach path finding
$AIAlgo1::FetchPointSep = 0.3;        // separation of approach points

// ==== Aiming parameters
$AIAlgo1::AimFast = 5;                // minimum speed for aiming at ground
$AIAlgo1::AimLow = 0.8;               // height for aiming at ground
$AIAlgo1::AimHigh = 2.0;              // height when ground aim is not clear

$AIAlgo1::AimProjectileSpeed = 100;   // projectile speed (for lead aiming)
$AIAlgo1::AimRotErr = 0.13;           // rotation correction (for strafe induced error)

$AIAlgo1::AimMaskDist = 20;           // clear path length required for firing
$AIAlgo1::AimMask = 
  $TypeMasks::PlayerObjectType |      // players (hopefully friendlies)
  $TypeMasks::TerrainObjectType |     // dirt, but not water
  $TypeMasks::StaticTSObjectType |    // trees and whatnot
  $TypeMasks::InteriorObjectType;     // walls

// ==== Thinking parameters
$AIAlgo1::DodgeHitDist = 4;
$AIAlgo1::DodgeHitTimeMax = 0.8;
$AIAlgo1::DodgeHitTimeMin = 0.05;
$AIAlgo1::DodgeDistResp = 10;

$AIAlgo1::StuckMinCount = 2;
$AIAlgo1::StuckMinSpeed = 2;

//-----------------------------------------------------------------------------
// Call Backs
//-----------------------------------------------------------------------------

function AIAlgo1::onReachDestination(%this)
{
  // reset the in transit flag
  %this.isInTransit = false;
}

function AIAlgo1::onDeath(%this, %obj)
{}

// all of the ones below here don't seem to work...
function AIAlgo1::onStuck(%this)
{ %this.out(3, "AIAlgo1::onStuck - " @ %this.name); }

function AIAlgo1::onUnStuck(%this)
{ %this.out(3, "AIAlgo1::onUnStuck - " @ %this.name); }

function AIAlgo1::onStop(%this)
{ %this.out(3, "AIAlgo1::onStop - " @ %this.name); }

function AIAlgo1::onMove(%this)
{ %this.out(3, "AIAlgo1::onMove - " @ %this.name); }

function AIAlgo1::onEndOfPath(%this, %path)
{ %this.out(3, "AIAlgo1::onEndOfPath - " @ %this.name); }

function AIAlgo1::onEndSequence(%this, %slot)
{ %this.out(3, "AIAlgo1::onEndSequence - " @ %this.name); }


//-----------------------------------------------------------------------------
// Create
//  This function creates an instace of AIAlgo1, initializes it,
//  and returns it for use in a AIPlayer.
//-----------------------------------------------------------------------------

function AIAlgo1::create(%player, %debugLvl)
{
  %algo = new ScriptObject(AIAlgo1) {
    // used/set by AIPlayer
    player = %player;
    debugLvl = %debugLvl;
    visList[0] = 0;
    visNum = 0;
    fastList[0] = 0;
    fastNum = 0;
    isHumanFriendly = true;

    name = "WHO AM I?";

    // algo state
    state = "SEARCH";
    //state = "DODGE";
    isInTransit = false;
    isStuck = false;
    stuckCount = 0;
    moveDest = "";

    attackObj = 0;
    followObj = 0;
    threatObj = 0;
    assistObj = 0;

    wanderDir = 0;
    searchDir = 0;
    followDir = 0;
    
    fetchDir = 0;
    fetchType = 0;
    fetchIndex = 0;
    fetchCount = 0;
    fetchList[0] = 0;
    foundHealth = 0;
    foundAmmo = 0;
    
    // last info
    lastAttackObj = AISensObj::create();
    lastFollowObj = AISensObj::create();

    // prev cycle info
    prevState = "UNKNOWN";
    prevDamage = 0;
    prevAttackObj = AISensObj::create();
    prevFollowObj = AISensObj::create();
  };
  
  // add self to cleanup and return
  MissionCleanup.add(%algo);
  return %algo;
}

function AIAlgo1::cleanUp(%this)
{
  // FIX: why doesn't this work?
  return;

  for( %index = 0; %index < %this.visNum; %index++ )
    %this.visList[%index].delete();
  for( %index = 0; %index < %this.fastNum; %index++ )
    %this.fastList[%index].delete();

  %this.lastAttackObj.delete();
  %this.lastFollowObj.delete();

  %this.prevAttackObj.delete();
  %this.prevFollowObj.delete();
}

//-----------------------------------------------------------------------------
// State Independent functions
//-----------------------------------------------------------------------------

// Wake Up
//  This function is created after the AI is spawned, but before
//  the first call to "think".
function AIAlgo1::wake(%this)
{
  %this.name = %this.player.getShapeName();
  %this.posHome = %this.player.getPosition();
}

// Ongoing Decision Maker
//   Called every 500 ms, this is the main thinking "loop".
function AIAlgo1::think(%this)
{
  // for ease of use
  %plr = %this.player;
  
  // check for stuck
  if( %this.isInTransit && !%plr.isMoving($AIAlgo1::StuckMinSpeed) )
    %this.stuckCount++;
  else
    %this.stuckCount = 0;
  %this.isStuck = %this.stuckCount > $AIAlgo1::StuckMinCount;


  // diagnostic output
  %this.out(3, "======================== " @ %this.state @
               ", damage " @ %plr.getDamagePercent());
  %this.out(3, "transit " @ %this.isInTransit @ ", stuck " @ %this.isStuck @ 
               ", speed " @ VectorLen(%plr.getVelocity()));

  // ==== Undodge (reset pre-dodge destination)
  if( %this.moveDest !$= "" )
  {
    %plr.setMoveDestination(%this.moveDest);
    %this.moveDest = "";
    if( !%this.isInTransit )
      %this.out(0, "moveDest set, but not in transit");
  }

  // === Update visList
  %visNum = %plr.updateVisList();
  
  // spew visList info
  for( %index = 0; %index < %visNum; %index++ )
  {
    %obj = %this.visList[%index];
    
    %dist = %plr.getDistTo(%obj.pos);
    %az = %plr.getAzTo(%obj.pos);
    %el = %plr.getElTo(%obj.pos);
    
    if( %obj.isPlayer() )
      %this.out(4, %index @ ": name " @ %obj.name @
           " type " @ %obj.getTypeName() @ " id " @ %obj.id @
           "\n      dist " @ %dist @ ", az " @ %az @ ", el " @ %el @
           "\n      human " @ %obj.isHuman() @ ", sense " @ %obj.sense);
    else if( %obj.isLiveFire() )
      %this.out(4, %index @ ": type " @ %obj.getTypeName() @ " id " @ %obj.id @
           " hit " @ %plr.getHitDistTo(%obj.pos, %obj.vel) @
           "\n      dist " @ %dist @ ", az " @ %az @ ", el " @ %el @
           "\n      projectile " @ %obj.isProjectile() @ ", sense " @ %obj.sense);
    else if( %obj.isItem() )
      %this.out(4, %index @ ": type " @ %obj.getTypeName() @ " id " @ %obj.id @
           "\n      dist " @ %dist @ ", az " @ %az @ ", el " @ %el @
           "\n      health " @ %obj.isHealth() @ ", sense " @ %obj.sense);
  }

  // update interesting things
  %this.updateInterestObj();
  if( %this.attackObj != 0 )
    %this.out(3, "attackObj is " @ %this.attackObj.name);
  if( %this.followObj != 0 )
    %this.out(3, "followObj is " @ %this.followObj.name);
  if( %this.threatObj != 0 )
    %this.out(3, "threatObj is " @ %this.threatObj.name);

  // ==== Switch on State
  switch$( %this.state )
  {
    case "WANDER": %this.stateWander();
    case "ATTACK": %this.stateAttack();
    case "SEARCH": %this.stateSearch();
    case "FOLLOW": %this.stateFollow();
    case "ASSIST": %this.stateAssist();
    case "RESPOND": %this.stateRespond();
    case "FETCH": %this.stateFetch();
    case "DODGE":  // brain dead state
    default:
    %this.out(0, "Unknown state in think == " @ %this.state);
    %this.state = "SEARCH";
  }
  
  // ==== Update Prevs
  %this.prevState = %this.state;
  %this.prevDamage = %plr.getDamagePercent();
  
  %this.prevAttackObj.copy(%this.attackObj);
  if( %this.attackObj.obj != 0 )
    %this.lastAttackObj.copy(%this.attackObj);

  %this.prevFollowObj.copy(%this.followObj);
  if( %this.followObj.obj != 0 )
    %this.lastFollowObj.copy(%this.followObj);

  // ==== Dodge
  %this.dodge(%this.threatObj);  
}

// Fast Response
//  called when projectiles are visible, this function should
//  be simple, and efficient
function AIAlgo1::thinkFast(%this, %fastNum)
{
  for( %index = 0; %index < %fastNum; %index++ )
    %this.dodge(%this.fastList[%index]);
}
  
// dodge (avoid incoming projectiles between think cycles)
function AIAlgo1::dodge(%this, %obj)
{
  // if %obj is a projectile, and we're not already dodging
  if( %obj != 0 && %obj.isProjectile() && %this.moveDest $= "" )
  {
    %plr = %this.player;
    %distHit = %plr.getHitDistTo(%obj.pos, %obj.vel);
    %timeHit = getWord(%distHit, 1);
    if( %distHit > 0 && %distHit < $AIAlgo1::DodgeHitDist &&
        %timeHit > $AIAlgo1::DodgeHitTimeMin && %timeHit < $AIAlgo1::DodgeHitTimeMax )
    {
      // save current move destionation
      if( %this.isInTransit )
        %this.moveDest = %plr.getMoveDestination();

      // compute dodge destionation
      %vec = %plr.getVectorImpactTo(%obj.pos, %obj.vel);
      %vecn = VectorNormalize(setWord(%vec, 2, 0));
      %dest = %plr.getRelPos(%vecn, -1 * $AIAlgo1::DodgeDistResp);
      %plr.setMoveDestination(%dest, false);
      %this.out(4, "dodge " @ %obj.name @
                   " dist " @ %distHit @ " time " @ %timeHit);
      return true;
    }
  }
  return false;
}

//-----------------------------------------------------------------------------
// State Functions
//  this needs a generic preemptive state switcher to avoid the
//  silly code that has grown at the top of each state function
//-----------------------------------------------------------------------------

// wander around in search of a target
function AIAlgo1::stateWander(%this)
{
  %plr = %this.player;
  %this.state = "WANDER";
  %this.out(5, "State is " @ %this.state);

  // check for enemies
  if( %this.attackObj != 0 && %this.haveAmmo() )
  {
    %this.stateAttack();
    return;
  }
  
  // assist friends
  if( %this.assistObj != 0 && %this.haveAmmo() )
  {
    %this.stateAssist();
    return;
  }
      
  // respond to threat or damage
  if( (%this.threatObj != 0 || %this.isUnderFire()) && %this.haveAmmo() )
  {
    %this.stateRespond();
    return;
  }

  // check for fetch time
  if( %this.isFetchTime() )
  {
    %this.stateFetch();
    return;
  }
  
  // follow friends
  if( %this.followObj != 0 && %this.haveAmmo() )
  {
    %this.stateFollow();
    return;
  }
  
  // wander more
  if( %this.isInTransit && !%this.isStuck )
  {
    switch( %this.wanderDir )
    {
      case 1:
      %plr.doYaw(80);
      %this.wanderDir++;

      case 3:
      %plr.doYaw(-80);
      %this.wanderDir++;

      case 5:
      %plr.doYaw(170);
      %this.wanderDir = 0;
      
      default:
      %plr.clearAim();
      %this.wanderDir++;
    }
  }
  else
  {
    %plr.clearAim();
    %posNode = %this.getClosestNode();
    %dist = %plr.getDistTo(%posNode);
    
    if( (%dist > $AIAlgo1::DistPathMax || %plr.isInWater()) && !%this.isStuck )
    {
      // go to node on path
      %this.goToDest(%posNode, false);
      if( %dist > $AIAlgo1::DistPathMax )
        %this.out(3, %dist @ " from path, going to node at " @ %posNode);
      else
        %this.out(2, "in water, going to node at " @ %posNode);
    }
    else
    {
      // select a random destination
      %dest = %this.getRandDest($AIAlgo1::DistWander, $AIPlayer::WanderMask);
      if( %plr.isClearTo(%dest, $AIPlayer::WanderMask) )
        %this.out(3, %dist @ " from path, new destination " @ %dest);
      else
      {
        // a clear path was not found, try a shorter distance
        %dest = %this.getRandDest($AIAlgo1::DistWanderInside, $AIPlayer::WanderMask);
        %this.out(2, "inside, new destination " @ %dest);
      }
      %this.goToDest(%dest, false);
    }
  }
}

// attack anyone nearby
function AIAlgo1::stateAttack(%this)
{
  %plr = %this.player;
  %this.state = "ATTACK";
  %this.out(5, "State is " @ %this.state);

  // === Change State
  // check for empty weapon
  if( !%this.haveAmmo() )
  {
    %this.stateWander();
    return;
  }
  
  if( %this.attackObj == 0 )
  {
    // lost target, go to last sighting
    if( %this.prevAttackObj.id == 0 )
    {
      %this.out(0, "prev attack target lost");  // this should never happen
      %this.state = "SEARCH";
    }
    else 
    {
      %obj = %this.prevAttackObj;
      if( %obj.obj.getState() $= "Dead" )
      {
        %this.out(2, "killed " @ %obj.name);
        %this.stop();
        %this.state = "WANDER";
      }
      else
      {
        %this.out(2, "going to last sighting of " @ %obj.name);
        %this.goToDest(%obj.pos, false);
        %this.state = "SEARCH";
      }
    }
    // go to state SEARCH or WANDER in next cycle
    return;
  }
  
  // ==== Attack Target
  %obj = %this.attackObj;
  
  // == decide how to move
  %dist = %plr.getDistTo(%obj.pos);
  
  // here, the dot product is used to see if the target is looking this way
  // %aimDot > 0 means looking away, < 0 means looking this direction
  %vecTo = %plr.getVectorTo(%obj.pos);
  %vecn = VectorNormalize(%vecTo);
  %aimDot = VectorDot(%vecn, %obj.dir);
  if( %dist > $AIAlgo1::AttackSnipeDist && %aimDot > $AIAlgo1::AttackSnipeDot )
    %this.stop();  // == stop moving, target is far and not looking this way
  else
  {
    // == target is close, or facing this way, so move to attack radius
    // compute destination near target  
    // but slide away from opponents aim point
    %vecc = VectorCross(%vecn, %obj.dir);
    if( getWord(%vecc, 2) > 0.0 )
      %vecz = "0 0 " @ $AIAlgo1::AttackRadius;
    else
      %vecz = "0 0 " @ -1 * $AIAlgo1::AttackRadius;
    %delta = VectorCross(%vecn, %vecz);
    %destFar = VectorAdd(%delta, %obj.pos);
    %dir = VectorNormalize(%plr.getVectorTo(%destFar));
    %dest = %plr.getRelPos(%dir, $AIAlgo1::AttackDist);

    // move toward target, while avoiding problems
    if( !%plr.isClearTo(%dest) || !AIPlayer::isClear(%dest, %obj.pos, 0, %obj.id) )
      %dest = %this.getRandDest($AIAlgo1::AttackDist);
    %this.goToDest(%dest, false);
  }

  // fire
  %posAim = %this.getAimPoint(%obj.pos, %obj.vel);
  %plr.setAimLocation(%posAim);
  if( %this.isInTransit )
    %plr.schedule($AIAlgo1::AttackDelay, fireOnce, 
                  $AIAlgo1::AimMask, $AIAlgo1::AimMaskDist);
  else
    %plr.schedule($AIAlgo1::AttackSnipeDelay, fireOnce, 
                  $AIAlgo1::AimMask, $AIAlgo1::AimMaskDist);
}

// do a quick search around the destination
function AIAlgo1::stateSearch(%this)
{
  %plr = %this.player;
  %this.state = "SEARCH";
  %this.out(5, "State is " @ %this.state);

  // check for empty weapon
  if( !%this.haveAmmo() )
  {
    %this.stateWander();
    return;
  }
  
  // check for enemies
  if( %this.attackObj != 0 )
  {
    %this.searchDir = 0;
    %this.stateAttack();
    return;
  }
  
  // assist friends
  if(  %this.assistObj != 0  )
  {
    %this.searchDir = 0;
    %this.stateAssist();
    return;
  }
      
  // respond to damage
  if( %this.isUnderFire() )
  {
    %this.searchDir = 0;
    %this.stateRespond();
    return;
  }

  // wander after a loop at the destination
  if( %this.searchDir > 4 )
  {
    %plr.clearAim();
    %this.searchDir = 0;
    %this.state = "WANDER";
    return;
  }
  
  if( %this.isInTransit && !%this.isStuck )
  {
    // look mostly forward while approaching destination
    switch( %this.searchDir )
    {
      case 0:                         // look right
      %plr.doYaw(-30);
      %this.searchDir++;

      case 1:                         // look where you're going
      %plr.clearAim();
      %this.searchDir++;

      case 2:                         // look left
      %plr.doYaw(30);
      %this.searchDir++;

      default:                        // look where you're going
      %plr.clearAim();
      %this.searchDir = 0;
    }
  }
  else
  {
    // take a quick look around
    %plr.doYaw(80);
    %this.searchDir++;
  }
}

// respond to a threat
function AIAlgo1::stateRespond(%this)
{
  %plr = %this.player;
  %obj = %this.threatObj;

  %this.state = "RESPOND";
  %this.out(5, "State is " @ %this.state);

  // check for empty weapon
  if( !%this.haveAmmo() )
  {
    %this.stateWander();
    return;
  }
  
  // check for enemies
  if( %this.attackObj != 0 )
  {
    %this.stateAttack();
    return;
  }
  
  // assist friends
  if(  %this.assistObj != 0 )
  {
    %this.stateAssist();
    return;
  }
    
  // respond to damage or nerby impact
  if( %obj != 0 && !%obj.isProjectile() )
  {
    %this.move($AIAlgo1::ThreatDistResp, -120, false);
    %this.out(2, "responding to unknown threat!");
    %this.state = "WANDER";
    return;
  }

  // initiate projectile response
  if( %obj != 0 )
  {
    %az = AIPlayer::getAz(%plr.getEyeVector(), %obj.vel);
    %delta = VectorScale(VectorNormalize(%obj.vel), -1 * $AIAlgo1::ThreatDistGuess);
    %pos = VectorAdd(%obj.pos, %delta);

    // move perpendicular to projectile velocity
    if( %az > 0 )
      %this.move($AIAlgo1::ThreatDistResp, %az - 90, false);
    else
      %this.move($AIAlgo1::ThreatDistResp, %az + 90, false);
        
    // look at source position
    %plr.setAimLocation(%pos);
    %this.out(2, "responding to projectile!");
    return;
  }
  
  // continue projectile response
  if( !%this.isInTransit || %this.isStuck )
  {
    // reached response destination, now move toward projectile source
    %this.goToDest(%plr.getAimLocation(), false);
    %this.state = "WANDER";    
  }
}

// follow a friend
function AIAlgo1::stateFollow(%this)
{
  %plr = %this.player;
  %this.state = "FOLLOW";
  %this.out(5, "State is " @ %this.state);

  // check for ammo
  if( !%this.haveAmmo() )
  {
    %this.stateWander();
    return;
  }
  
  // check for enemies
  if( %this.attackObj != 0 )
  {
    %this.stateAttack();
    return;
  }
  
  // assist friends
  if(  %this.assistObj != 0 )
  {
    %this.stateAssist();
    return;
  }
      
  // respond to damage
  if( %this.isUnderFire() )
  {
    %this.stateRespond();
    return;
  }

  // output only when follow object changes
  if( %this.followObj != 0 && %this.followObj.id != %this.lastFollowObj.id )
    %this.out(2, "following " @ %this.followObj.name);

  // ==== Move to Follow
  if( %this.followObj != 0 )
    %obj = %this.followObj;
  else if( %this.prevFollowObj.id != 0 )
    %obj = %this.prevFollowObj;
  else
  {
    // leader not seen, wander in his direction
    %this.goToDest(%this.lastFollowObj.pos);
    %this.state = "WANDER";
    return;
  }

  // approach leader
  %this.approachDest(%obj.pos, $AIAlgo1::FollowDist, false);

  // ==== Look Around
  switch( %this.followDir )
  {
    case 0:                         // look right
    %plr.doYaw(-40);
    %this.followDir++;

    case 1:                         // look where you're going
    %plr.clearAim();
    %this.followDir++;

    case 2:                         // look left
    %plr.doYaw(40);
    %this.followDir++;

    case 3:                          // look where leader was last seen
    %plr.setAimLocation(%obj.pos);
    %this.followDir++;

    default:                          // look where you're going
    %plr.clearAim();
    %this.followDir = 0;
  }
}

// assist a friend
// HACK: make this a real state
function AIAlgo1::stateAssist(%this)
{
  %plr = %this.player;
  %this.state = "ASSIST";
  %this.out(5, "State is " @ %this.state);

  // check for empty weapon
  if( !%this.haveAmmo() )
  {
    %this.stateWander();
    return;
  }
  
  // check for enemies
  if( %this.attackObj != 0 )
  {
    %this.stateAttack();
    return;
  }
  
  if( %this.assistObj != 0  )
  {
    %obj = %this.assistObj;
    
    // look where threat might be
    %pos = VectorAdd(%obj.pos, VectorScale(%obj.dir, $AIAlgo1::ThreatDistGuess));
    %plr.setAimLocation(%pos);

    // goto destination beside of friend
    %dest = %this.getPosBeside(%obj, $AIAlgo1::FlankDist);
    %this.goToDest(%dest, false);

    %this.out(2, "going to help " @ %obj.name);
  }
  %this.state = "WANDER";
}

// fetch an item
function AIAlgo1::stateFetch(%this)
{
  %plr = %this.player;
  %this.state = "FETCH";
  %this.out(5, "State is " @ %this.state);

  // just keep moving
  if( %this.isInTransit && !%this.isStuck )
    return;
  
  // decide what is needed
  if( %this.fetchDir == 0 )
  {
    %this.fetchIndex = -1;
    %distMin = $AIPlayer::BigDist;
    for( %index = 0; %index < %this.fetchCount; %index++ )
    {
      %dist = %plr.getDistTo(%this.getFetchVisPos(%index));
      if( %dist < %distMin && %this.fetchType == %this.getFetchType(%index) &&
          %this.getFetchIsGood(%index) )
        %this.fetchIndex = %index;
    }

    // reduce count (either stuck or used) and report
    if( %this.fetchIndex != -1 )
    {
      if( %this.getFetchType(%this.fetchIndex) == $AISensObj::AmmoType )
        %this.foundAmmo--;
      else
        %this.foundHealth--;
      
      // report
      %name = %this.getFetchName(%this.fetchIndex);
      %pos = %this.getFetchObjPos(%this.fetchIndex);
      %this.out(2, "going to fetch " @ %name @
                   " at " @ %pos @ ", distance is " @ %dist);
    }
  }
  else if( %this.isStuck && %this.fetchDir < 3 )
  {
    // stuck while fetching, mark this position as bad
    %this.incFetchFail(%this.fetchIndex);

    // report
    %name = %this.getFetchName(%this.fetchIndex);
    %pos = %this.getFetchObjPos(%this.fetchIndex);
    %this.out(2, "got stuck fetching " @ %name @ " at " @ %pos);

    // wander
    %this.fetchDir = 3;
    %this.state = "WANDER";
    return;
  }

  // check for error
  if( %this.fetchIndex == -1 )
  {
    %this.fetchCount = 0;
    %this.foundHealth = 0;
    %this.foundAmmo = 0;
    %this.fetchDir = 0;

    %this.out(0, "error, nothing to fetch");
    %this.state = "WANDER";
    return;
  }

  // update destination
  switch( %this.fetchDir )
  {
    case 0:                       // go to fetch position and stop
    %plr.clearAim();
    %pos = %this.getFetchVisPos(%this.fetchIndex);
    %this.goToDest(%pos, true);
    %this.fetchDir++;

    case 1:                       // go to object position and stop
    %pos = %this.getFetchObjPos(%this.fetchIndex);
    %this.goToDest(%pos, true);
    %this.fetchDir++;

    case 2:                      // go back to fetch position, but don't stop
    %pos = %this.getFetchVisPos(%this.fetchIndex);
    %this.goToDest(%pos, false);
    %this.fetchDir++;

    default:                      // return to wander(give some time for health regen)
    %this.setFetchUsed(%this.fetchIndex);  // mark this item used
    %this.fetchDir = 0;
    %this.state = "WANDER";
  }
}

//-----------------------------------------------------------------------------
// decsion support functions
//-----------------------------------------------------------------------------

// update objects of interest
function AIAlgo1::updateInterestObj(%this)
{
  %plr = %this.player;

  // prepare for scan
  %this.attackObj = 0;
  %this.followObj = 0;
  %this.threatObj = 0;
  %this.assistObj = 0;

  %distHitMin = -10 * $AIPlayer::VisDistRange;

  // ==== Scan VisList
  //  note that the visList is sorted by distance, closest first
  for( %index = 0; %index < %this.visNum; %index++ )
  {
    %obj = %this.visList[%index];
    %dist = %plr.getDistTo(%obj.pos);

    if( !isObject(%obj.obj) )
    {
      %this.out(0, "bad visList object " @ %obj);
      continue;
    }
    
    // == Players
    if( %obj.isPlayer() )
    {
      // closest/weakest attack target
      if( (%this.attackObj == 0 || 
           (%dist < $AIAlgo1::AttackClose && %this.attackObj.damage < %obj.damage)) && 
          !%plr.isTeammate(%obj.team) && !(%obj.isHuman() && %this.isHumanFriendly) )
        %this.attackObj = %obj;                 // closest not on my team

      // closest older friendly
      if( %this.followObj == 0 && %plr.isTeammate(%obj.team) && %obj.id < %plr.getId() )
        %this.followObj = %obj;

      // closest friendly in a fight
      if( %this.assistObj == 0 && %plr.isTeammate(%obj.team) && %obj.isFiring() )
        %this.assistObj = %obj;
    }

    // == Threats
    if( %obj.isLiveFire() )
    {
      // closest impact if no projectiles found
      %distHit = %plr.getHitDistTo(%obj.pos, %obj.vel);
      
      if( %obj.isImpact() && %dist < $AIAlgo1::ThreatDistImpact )
      {
        // closest impact
        if( %this.threatObj == 0 )
          %this.threatObj = %obj;
      }
      else if( %obj.isProjectile() && %dist < $AIAlgo1::ThreatHitDist )
      {
        // most threatening projectile
        if( %distHit < 0 && mAbs(%distHit) < $AIAlgo1::ThreatHitDistMine )
          %distHit = 0; // ignore this one... it is probably mine
        else if( %distHit < 0 && %distHit > %distHitMin  )
          %this.threatObj = %obj;  // projectile passed me
        else if( %distHit > 0 && (%distHit < %distHitMin || %distHitMin < 0) )
          %this.threatObj = %obj;  // incoming projectile
      }
    }

    // == Items
    if( (%obj.isAmmo() || %obj.isHealth()) && %dist < $AIAlgo1::FetchDist )
    {
      // look in the list for this item
      %inList = false;
      for( %j = 0; %j < %this.fetchCount && !%inList; %j++ )
        if( %this.getFetchId(%j) == %obj.id )
        {
          %inList = true;
          %this.out(4, "saw object index " @ %j @ " of " @ %this.fetchCount);
        }
      // add or replace in list
      %isAdded = false;
      if( !%inList && %this.setFetchObj(%j, %obj) )
      {
        %isAdded = true;  // so that the counter gets incremented
        %this.fetchCount++;
        %this.out(4, "added object index " @ %j @ " of " @ %this.fetchCount);
      }
      else if( %inList && !%this.getFetchIsGood(%j - 1) &&
               %this.getFetchTries(%j - 1) < $AIAlgo1::FetchTryMax &&
               %this.setFetchObj(%j - 1, %obj) )
      {
        %isAdded = true;  // so that the counter gets incremented
        %this.out(4, "replaced object index " @ (%j - 1) @ " of " @ %this.fetchCount);
      }
  
      // increment ammo or health counter
      if( %isAdded && %obj.isAmmo() )
      {
        %this.foundAmmo++;
        %this.out(4, "saw AMMO at " @ %obj.pos @ " now " @ %this.foundAmmo);
      }

      if( %isAdded && %obj.isHealth() )
      {
        %this.foundHealth++;
        %this.out(4, "saw HEALTH at " @ %obj.pos @ " now " @ %this.foundHealth);
      }
    }
  }
}

// aiming control
function AIAlgo1::getAimPoint(%this, %pos, %vel)
{
  %plr = %this.player;
  %dist = %plr.getDistTo(%pos);

  // vector to the target
  %vec = %plr.getVectorTo(%pos);
  %vecn = VectorNormalize(%vec);
  
  // target position at impact
  %closingSpeed = $AIAlgo1::AimProjectileSpeed - VectorDot(%vel, %vecn);
  %time = $AIAlgo1::AttackDelay / 1000 + %dist / %closingSpeed;
  %posAim = VectorAdd(%pos, VectorScale(%vel, %time));

  // aiming error correction
  %vecRot = VectorCross(%vecn, %plr.getVelocity());
  %vecErr = VectorScale(VectorCross(%vecn, %vecRot), $AIAlgo1::AimRotErr);
  %posAim = VectorAdd(%posAim, %vecErr);
  
  // aim at the ground if target is moving fast
  if( VectorLen(%vel) > $AIAlgo1::AimFast )
  {
    %zTerr = getTerrainHeight(%posAim);
    %posAim = setWord(%posAim, 2, %zTerr + $AIAlgo1::AimLow);
    
    // if low aim hits something, aim high instead
    if( !%plr.isClearTo(%posAim, $AIAlgo1::AimMask) )
      %posAim = setWord(%posAim, 2, %zTerr + $AIAlgo1::AimHigh);
  }
  return %posAim; 
}

// true if taking damage
function AIAlgo1::isUnderFire(%this)
{ return %this.player.getDamagePercent() > %this.prevDamage + 0.001; }

// true if all activity should be abandoned until item is found
function AIAlgo1::isFetchTime(%this)
{
  %plr = %this.player;
  %isNotFighting = %this.attackObj == 0 && %this.prevAttackObj.id == 0;
  %ammo = %plr.getInventory(CrossbowAmmo);
  %damage = %plr.getDamagePercent();
  
  // if we're out, there's nothing to do but get more
  if( %this.foundAmmo > 0 && %ammo == 0 )
  {
    %this.fetchType = $AISensObj::AmmoType;
    return true;
  }

  // health will have to wait until we're not in close combat
  if( %this.foundHealth > 0 && %isNotFighting && %damage > $AIAlgo1::FetchDamage )
  {
    %this.fetchType = $AISensObj::HealthType;
    return true;
  }

  // low ammo can wait until we're done fighting
  if( %this.foundAmmo > 0 && %isNotFighting && %ammo < $AIAlgo1::FetchAmmo )
  {
    %this.fetchType = $AISensObj::AmmoType;
    return true;
  }
    
  // we don't need anything now (or don't have what we need)
  return false;
}

function AIAlgo1::haveAmmo(%this)
{ return %this.player.getInventory(CrossbowAmmo) > 0; }


//-----------------------------------------------------------------------------
// navigation functions
//-----------------------------------------------------------------------------

// get closest postion beside %obj at distance %dist
function AIAlgo1::getPosBeside(%this, %obj, %dist)
{
  %plr = %this.player;

  // compute positions left and right
  %vecL = AIPlayer::vecRotateAz(%obj.dir, 90);
  %vecR = AIPlayer::vecRotateAz(%obj.dir, -90);
    
  %posL = VectorAdd(%obj.pos, VectorScale(%vecL, %dist));
  %posR = VectorAdd(%obj.pos, VectorScale(%vecR, %dist));
    
  // return closest side
  %distL = %plr.getDistTo(%posL);
  %distR = %plr.getDistTo(%posR);

  if( %distL < %distR )
    return %posL;
  return %posR;
}

// generate a random nearby position
function AIAlgo1::getRandPos(%pos, %dist)
{
  // generate a random shift
  %dx = getRandom(1, -1) * %dist;
  %dy = getRandom(1, -1) * %dist;
  %delta = %dx @ " " @ %dy @ " 0";
  %dest = VectorAdd(%pos, %delta);
      
  // set height just above the terrain
  %dz = getTerrainHeight(%dest) + 0.1;
  %dest = setWord(%dest, 2, %dz);

  return %dest;
}

// generate a random nearby destination, avoiding things in %mask
function AIAlgo1::getRandDest(%this, %dist, %mask)
{
  %pos = %this.player.getPosition();
  %dest = AIAlgo1::getRandPos(%pos, %dist);
  %isClear = %this.player.isClearTo(%dest, %mask);

  for( %index = 0; %index < $AIAlgo1::RandDestMaxIter && !%isClear; %index++ )
  {
    %dest = AIAlgo1::getRandPos(%pos, %dist);
    %isClear = %this.player.isClearTo(%dest, %mask);
  }

  return %dest;
}

// return position of closest path node
function AIAlgo1::getClosestNode(%this)
{
  %plr = %this.player;
  %path = %plr.path;
  
  %minPos = %path.getObject(0).getPosition();
  %minDist = %plr.getDistTo(%minPos);
  for( %index = 1; %index < %path.getCount(); %index++ )
  {
    %pos = %path.getObject(%index).getPosition();
    %dist = %plr.getDistTo(%pos);
    if( %dist < %minDist )
    {
      %minPos = %pos;
      %minDist = %dist;
    }
  }
  
  return %pos;
}

// try to find clear path from player to %dest
//  this method is weak, and works only at close range
function AIAlgo1::getFetchPath(%this, %dest)
{
  %plr = %this.player;
  
  %plrPos = %plr.getEyePoint();
  %vecTo = VectorNormalize(setWord(VectorSub(%dest, %plrPos), 2, 0));
  %vec = AIPlayer::vecRotateAz(%vecTo, 90);
  
  %visOff = 0;
  %visNum = 0;
  %off = $AIAlgo1::FetchPointSep * $AIAlgo1::FetchPointNum / 2;
  for( %index = 0; %index < $AIAlgo1::FetchPointNum; %index++ )
  {
    %pos = VectorAdd(%plrPos, VectorScale(%vec, %off));
    if( AIPlayer::isClear(%pos, %dest) )
    {
      %visOff += %off;
      %visNum++;
    }
    %off -= $AIAlgo1::FetchPointSep;
  }
  if( %visNum == 0 )
    return "NULL";

  return VectorAdd(%plrPos, VectorScale(%vec, %visOff / %visNum));
}

//-----------------------------------------------------------------------------
// movement functions
//-----------------------------------------------------------------------------

// go to a destination
function AIAlgo1::goToDest(%this, %dest, %isEnd)
{
  %this.isInTransit = true;
  %this.player.setMoveDestination(%dest, %isEnd);
}

// get close to a destination
function AIAlgo1::approachDest(%this, %dest, %dist, %isEnd)
{
  %vec = %this.player.getVectorTo(%dest);
  %delta = VectorScale(VectorNormalize(%vec), %dist);
  %destNew = VectorSub(%dest, %delta);
  
  %this.goToDest(%destNew, %isEnd);
}

// move to a relative position
function AIAlgo1::move(%this, %dist, %angle, %isEnd)
{
  %this.isInTransit = true;
  %this.player.doMove(%dist, %angle, %isEnd);
}

// stop moving
function AIAlgo1::stop(%this)
{
  %this.isInTransit = false;
  %this.player.stop();
}

//-----------------------------------------------------------------------------
// fetch list functions
//   born of desparation, and still growing
//-----------------------------------------------------------------------------

function AIAlgo1::getFetchStr(%objId, %objType, %objPos, %visPos, %isGood)
{ return %objId @ " " @ %objType @ " " @ %objPos @ " " @ %visPos @
         " " @ %isGood @ " 0 0"; }

function AIAlgo1::setFetchObj(%this, %index, %obj)
{
  %visPos = %this.getFetchPath(%obj.pos);
  %this.fetchList[%index] =
    AIAlgo1::getFetchStr(%obj.id, %obj.type, %obj.pos, %visPos, %visPos !$= "NULL");
  return %visPos !$= "NULL";
}

function AIAlgo1::incFetchFail(%this, %index)
{
  %tries = %this.getFetchTries(%index) + 1;
  %this.fetchList[%index] = setWord(%this.fetchList[%index], 8, false);
  %this.fetchList[%index] = setWord(%this.fetchList[%index], 9, %tries);
}

function AIAlgo1::setFetchUsed(%this, %index)
{ %this.fetchList[%index] = setWord(%this.fetchList[%index], 8, false); }

function AIAlgo1::getFetchId(%this, %index)
{ return getWord(%this.fetchList[%index], 0); }

function AIAlgo1::getFetchType(%this, %index)
{ return getWord(%this.fetchList[%index], 1); }

function AIAlgo1::getFetchObjPos(%this, %index)
{ return getWords(%this.fetchList[%index], 2, 4); }

function AIAlgo1::getFetchVisPos(%this, %index)
{ return getWords(%this.fetchList[%index], 5, 7); }

function AIAlgo1::getFetchIsGood(%this, %index)
{ return getWord(%this.fetchList[%index], 8); }

function AIAlgo1::getFetchTries(%this, %index)
{ return getWord(%this.fetchList[%index], 9); }

function AIAlgo1::getFetchName(%this, %index)
{ return AISensObj::getTypeStr(%this.getFetchType(%index)) @ %this.getFetchId(%index); }

//-----------------------------------------------------------------------------
// utility functions
//-----------------------------------------------------------------------------

// make sure we are not animating
function AIAlgo1::resetAct(%this)
{ %this.player.setActionThread("headside"); }

// start an animation
function AIAlgo1::setAct(%this, %act)
{ %this.player.setActionThread(%act); }

// for debugging output
function AIAlgo1::out(%this, %lvl, %str)
{
  if( %lvl <= 0 )
    error(%this.name @ ": " @ %str);
  else if( %lvl <= %this.debugLvl )
  {
    if( %lvl <= 2 )
      warn(%this.name @ ": " @ %str);
    else
      echo(%this.name @ ": " @ %str);
  }
}
