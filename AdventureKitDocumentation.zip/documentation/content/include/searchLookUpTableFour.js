function initSearchTableFour() 
{
}