//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

#include "platform/platform.h"
#include "T3D/vehicles/tankVehicle.h"

#include "math/mMath.h"
#include "math/mathIO.h"
#include "math/mRandom.h"
#include "console/simBase.h"
#include "console/console.h"
#include "console/consoleTypes.h"
#include "console/engineAPI.h"
#include "collision/clippedPolyList.h"
#include "collision/planeExtractor.h"
#include "core/stream/bitStream.h"
#include "core/dnet.h"
#include "T3D/gameBase/gameConnection.h"
#include "ts/tsShapeInstance.h"
#include "T3D/fx/particleEmitter.h"
#include "sfx/sfxSystem.h"
#include "sfx/sfxTrack.h"
#include "sfx/sfxSource.h"
#include "sfx/sfxTypes.h"
#include "scene/sceneManager.h"
#include "core/resourceManager.h"
#include "materials/materialDefinition.h"
#include "materials/baseMatInstance.h"
#include "lighting/lightQuery.h"


// Collision masks are used to determin what type of objects the
// wheeled vehicle will collide with.
static U32 sClientCollisionMask =
      TerrainObjectType    | InteriorObjectType       |
      PlayerObjectType     | StaticShapeObjectType    |
      VehicleObjectType    | VehicleBlockerObjectType;

// Gravity constant
static F32 sTankVehicleGravity = -20;
// Misc. sound constants
static F32 sIdleEngineVolume = 0.2f;

//----------------------------------------------------------------------------
// Vehicle Tire Data Block
//----------------------------------------------------------------------------
IMPLEMENT_CO_DATABLOCK_V1(TankVehicleTire);
ConsoleDocClass( TankVehicleTire,
   "@brief Defines the properties of a TankVehicle tire.\n\n"
   "Tires act as springs and generate lateral and longitudinal forces to move "
   "the vehicle. These distortion/spring forces are what convert wheel angular "
   "velocity into forces that act on the rigid body.\n"
   "@ingroup Vehicles\n"
);
TankVehicleTire::TankVehicleTire()
{
   shape = 0;
   shapeName = "";
   staticFriction = 1;
   kineticFriction = 0.5f;
   restitution = 1;
   radius = 0.6f;
   lateralForce = 10;
   lateralDamping = 1;
   lateralRelaxation = 1;
   longitudinalForce = 10;
   longitudinalDamping = 1;
   longitudinalRelaxation = 1;
   mass = 1.f;
}
bool TankVehicleTire::preload(bool server, String &errorStr)
{
   if (shapeName && shapeName[0]) 
   {
      shape = ResourceManager::get().load(shapeName);
      if (!bool(shape)) 
      {
         errorStr = String::ToString("TankVehicleTire: Couldn't load shape \"%s\"",shapeName);
         return false;
      }
      radius = shape->bounds.len_z() / 2;
   }
   return true;
}
void TankVehicleTire::initPersistFields()
{
   addField( "shapeFile",					TypeFilename,Offset(shapeName,			TankVehicleTire));
   addField( "mass",							TypeF32, Offset(mass,						TankVehicleTire));
   addField( "radius",						TypeF32, Offset(radius,						TankVehicleTire));
   addField( "staticFriction",			TypeF32, Offset(staticFriction,			TankVehicleTire));
   addField( "kineticFriction",			TypeF32, Offset(kineticFriction,			TankVehicleTire));
   addField( "restitution",				TypeF32, Offset(restitution,				TankVehicleTire));
   addField( "lateralForce",				TypeF32, Offset(lateralForce,				TankVehicleTire));
   addField( "lateralDamping",			TypeF32, Offset(lateralDamping,			TankVehicleTire));
   addField( "lateralRelaxation",		TypeF32, Offset(lateralRelaxation,		TankVehicleTire));
   addField( "longitudinalForce",		TypeF32, Offset(longitudinalForce,		TankVehicleTire));
   addField( "longitudinalDamping",		TypeF32, Offset(longitudinalDamping,	TankVehicleTire));
   addField( "longitudinalRelaxation", TypeF32, Offset(longitudinalRelaxation,TankVehicleTire));

   Parent::initPersistFields();
}
void TankVehicleTire::packData(BitStream* stream)
{
   Parent::packData(stream);

   stream->writeString(shapeName);
   stream->write(mass);
   stream->write(staticFriction);
   stream->write(kineticFriction);
   stream->write(restitution);
   stream->write(radius);
   stream->write(lateralForce);
   stream->write(lateralDamping);
   stream->write(lateralRelaxation);
   stream->write(longitudinalForce);
   stream->write(longitudinalDamping);
   stream->write(longitudinalRelaxation);
}
void TankVehicleTire::unpackData(BitStream* stream)
{
   Parent::unpackData(stream);

   shapeName = stream->readSTString();
   stream->read(&mass);
   stream->read(&staticFriction);
   stream->read(&kineticFriction);
   stream->read(&restitution);
   stream->read(&radius);
   stream->read(&lateralForce);
   stream->read(&lateralDamping);
   stream->read(&lateralRelaxation);
   stream->read(&longitudinalForce);
   stream->read(&longitudinalDamping);
   stream->read(&longitudinalRelaxation);
}
//----------------------------------------------------------------------------
// Vehicle Spring Data Block
//----------------------------------------------------------------------------
IMPLEMENT_CO_DATABLOCK_V1(TankVehicleSpring);
ConsoleDocClass( TankVehicleSpring,
   "@brief Defines the properties of a TankVehicle spring.\n\n"
   "@ingroup Vehicles\n"
);
TankVehicleSpring::TankVehicleSpring()
{
   length = 1;
   force = 10;
   damping = 1;
   antiSway = 1;
}
void TankVehicleSpring::initPersistFields()
{
   addField( "length", TypeF32, Offset(length, TankVehicleSpring));
   addField( "force", TypeF32, Offset(force, TankVehicleSpring));
   addField( "damping", TypeF32, Offset(damping, TankVehicleSpring));
   addField( "antiSwayForce", TypeF32, Offset(antiSway, TankVehicleSpring));

   Parent::initPersistFields();
}
void TankVehicleSpring::packData(BitStream* stream)
{
   Parent::packData(stream);

   stream->write(length);
   stream->write(force);
   stream->write(damping);
   stream->write(antiSway);
}
void TankVehicleSpring::unpackData(BitStream* stream)
{
   Parent::unpackData(stream);

   stream->read(&length);
   stream->read(&force);
   stream->read(&damping);
   stream->read(&antiSway);
}
//----------------------------------------------------------------------------
// Wheeled Vehicle Data Block
//----------------------------------------------------------------------------
IMPLEMENT_CO_DATABLOCK_V1(TankVehicleData);
ConsoleDocClass( TankVehicleData,
   "@brief Defines the properties of a TankVehicle.\n\n"
   "The model used for the TankVehicle has a number of requirements:\n"
   "@ingroup Vehicles\n"
);
TankVehicleData::TankVehicleData()
{
   tireEmitter				= 0;
   maxWheelSpeed			= 40;
   engineTorque			= 1;
   engineBrake				= 1;
   brakeTorque				= 1;
   tankWheelCount			= 0;
	mInnerWheelsPerSide	= 0;

   mTurretNode				= -1;
   mWeaponNode				= -1;
   mMuzzleNode				= -1;
   mSuspensionNode		= -1;

	//Tank Suspension System
   mPrimaryRecoil			= 10.0f;
   mSuspensionRange		= 0.1f;
   mSpringRangeX			= 0.06f;
   mSpringRangeY			= 0.06f;
   mSpringRangeZ			= 0.0f;
   mSpringVelScale		= 1.0f;
   mSpringLooseness		= 0.999f;

   for (S32 i = 0; i < MaxTankSounds; i++)
      tankSound[i] = 0;
}
//----------------------------------------------------------------------------
/** Load the vehicle shape
   Loads and extracts information from the vehicle shape.

   Wheel Nodes
      hub#           Wheel hub
		spring#			Matching spring to deform Tread
*/
//----------------------------------------------------------------------------
bool TankVehicleData::preload(bool server, String &errorStr)
{
   if (!Parent::preload(server, errorStr))
      return false;

   TSShapeInstance* si = new TSShapeInstance(mShape, false);
   // Resolve objects transmitted from server
   if (!server) {
      for (S32 i = 0; i < MaxTankSounds; i++)
         if( !sfxResolve( &tankSound[ i ], errorStr ) )
            return false;

      if (tireEmitter)
         Sim::findObject(SimObjectId(tireEmitter),tireEmitter);
   }
   // Extract wheel information from the shape
   TankWheel* wp = tankWheel;
   char buff[10];
   for (S32 i = 0; i < MaxTankWheels; i++) 
	{
		wp->treadNode = -1;
      // The wheel must have a hub node to operate at all.
      dSprintf(buff,sizeof(buff),"hub%d",i);
      wp->springNode = mShape->findNode(buff);
      if (wp->springNode != -1) 
		{
         si->mNodeTransforms[wp->springNode].getColumn(3, &wp->pos);

         dSprintf(buff,sizeof(buff),"spring%d",i);
			wp->treadNode = mShape->findNode(buff);
         mirrorWheel(wp);
         wp++;
      }
   }
   tankWheelCount = wp - tankWheel;

   // get nodes from shape
   mTurretNode     = mShape->findNode("codeTurret");
   mWeaponNode     = mShape->findNode("codeWeapon");
   mMuzzleNode     = mShape->findNode("mount3");
   mSuspensionNode = mShape->findNode("codeSuspension");

   // Extract collision planes from shape collision detail level
   if (collisionDetails[0] != -1) 
	{
      MatrixF imat(1);
      SphereF sphere;
      sphere.center = mShape->center;
      sphere.radius = mShape->radius;
      PlaneExtractorPolyList polyList;
      polyList.mPlaneList = &rigidBody.mPlaneList;
      polyList.setTransform(&imat, Point3F(1,1,1));
      si->buildPolyList(&polyList,collisionDetails[0]);
   }

   delete si;
   return true;
}
//----------------------------------------------------------------------------
/** Find a matching lateral wheel
   Looks for a matching wheeling mirrored along the Y axis, within some
   tolerance (current 0.5m), if one is found, the two wheels are lined up.
*/
//----------------------------------------------------------------------------
bool TankVehicleData::mirrorWheel(TankWheel* we)
{
   we->opposite = -1;
   for (TankWheel* wp = tankWheel; wp != we; wp++)
      if (mFabs(wp->pos.y - we->pos.y) < 0.5) 
      {
         we->pos.x = -wp->pos.x;
         we->pos.y = wp->pos.y;
         we->pos.z = wp->pos.z;
         we->opposite = wp - tankWheel;
         wp->opposite = we - tankWheel;
         return true;
      }
   return false;
}
//----------------------------------------------------------------------------
void TankVehicleData::initPersistFields()
{
   addField("engineSoundA",		TYPEID< SFXTrack >(), Offset(tankSound[EngineSoundA],		TankVehicleData));
   addField("engineSoundB",		TYPEID< SFXTrack >(), Offset(tankSound[EngineSoundB],		TankVehicleData));
   addField("WheelImpactSound",	TYPEID< SFXTrack >(), Offset(tankSound[WheelImpactSound],TankVehicleData));

   addField( "numInnerWheelsPerSide", TypeS32, Offset(mInnerWheelsPerSide,						TankVehicleData));

   addField("tireEmitter",			TYPEID< ParticleEmitterData >(), Offset(tireEmitter,		TankVehicleData));
   addField("maxWheelSpeed",		TypeF32, Offset(maxWheelSpeed,		TankVehicleData));
   addField("engineTorque",		TypeF32, Offset(engineTorque,			TankVehicleData));
   addField("engineBrake",			TypeF32, Offset(engineBrake,			TankVehicleData));
   addField("brakeTorque",			TypeF32, Offset(brakeTorque,			TankVehicleData));

//Tank Turret and Suspension system
   addField("primaryRecoil",		TypeF32, Offset(mPrimaryRecoil,		TankVehicleData));
   addField("suspensionRange",	TypeF32, Offset(mSuspensionRange,	TankVehicleData));
   addField("springRangeX",		TypeF32, Offset(mSpringRangeX,		TankVehicleData));
   addField("springRangeY",		TypeF32, Offset(mSpringRangeY,		TankVehicleData));
   addField("springRangeZ",		TypeF32, Offset(mSpringRangeZ,		TankVehicleData));
   addField("springVelScale",		TypeF32, Offset(mSpringVelScale,		TankVehicleData));
   addField("springLooseness",	TypeF32, Offset(mSpringLooseness,	TankVehicleData));
//Tank Turret and Suspension system

   Parent::initPersistFields();
}
//----------------------------------------------------------------------------
void TankVehicleData::packData(BitStream* stream)
{
   Parent::packData(stream);

   if (stream->writeFlag(tireEmitter))
      stream->writeRangedU32(packed? SimObjectId(tireEmitter):
         tireEmitter->getId(),DataBlockObjectIdFirst,DataBlockObjectIdLast);

   for (S32 i = 0; i < MaxTankSounds; i++)
      sfxWrite( stream, tankSound[ i ] );

   stream->write(maxWheelSpeed);
   stream->write(engineTorque);
   stream->write(engineBrake);
   stream->write(brakeTorque);
   stream->write(mInnerWheelsPerSide);

   stream->write(mPrimaryRecoil);
   stream->write(mSuspensionRange);
   stream->write(mSpringRangeX);
   stream->write(mSpringRangeY);
   stream->write(mSpringRangeZ);
   stream->write(mSpringVelScale);
   stream->write(mSpringLooseness);
}
void TankVehicleData::unpackData(BitStream* stream)
{
   Parent::unpackData(stream);

   tireEmitter = stream->readFlag()?
      (ParticleEmitterData*) stream->readRangedU32(DataBlockObjectIdFirst,
         DataBlockObjectIdLast): 0;

   for (S32 i = 0; i < MaxTankSounds; i++)
      sfxRead( stream, &tankSound[ i ] );

   stream->read(&maxWheelSpeed);
   stream->read(&engineTorque);
   stream->read(&engineBrake);
   stream->read(&brakeTorque);
   stream->read(&mInnerWheelsPerSide);
	//Turret/Suspension system
   stream->read(&mPrimaryRecoil);
   stream->read(&mSuspensionRange);
   stream->read(&mSpringRangeX);
   stream->read(&mSpringRangeY);
   stream->read(&mSpringRangeZ);
   stream->read(&mSpringVelScale);
   stream->read(&mSpringLooseness);
}
//----------------------------------------------------------------------------
// Tank Vehicle Class
//----------------------------------------------------------------------------
IMPLEMENT_CO_NETOBJECT_V1(TankVehicle);
ConsoleDocClass( TankVehicle,
   "@brief A wheeled vehicle.\n"
   "@ingroup Vehicles\n"
);
TankVehicle::TankVehicle()
{
   mDataBlock = 0;
   mBraking = false;
   mEngineSoundA = NULL;
   mEngineSoundB = NULL;

   for (S32 i = 0; i < TankVehicleData::MaxTankWheels; i++) 
	{
      mTankWheel[i].Dy = mTankWheel[i].Dx = 0;
      mTankWheel[i].tire = 0;
      mTankWheel[i].spring = 0;
      mTankWheel[i].shapeInstance = 0;
      mTankWheel[i].steering = 0;
      mTankWheel[i].powered = false;
      mTankWheel[i].slipping = false;
   }
}
TankVehicle::~TankVehicle()
{
}
void TankVehicle::initPersistFields()
{
   Parent::initPersistFields();
}
//----------------------------------------------------------------------------
bool TankVehicle::onAdd()
{
   if(!Parent::onAdd())
      return false;

   addToScene();
   if (isServerObject())
      scriptOnAdd();
   return true;
}
void TankVehicle::onRemove()
{
   // Delete the wheel resources
   if (mDataBlock != NULL)  {
      TankWheel* wend = &mTankWheel[mDataBlock->tankWheelCount];
      for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++) {
         if (!wheel->emitter.isNull())
            wheel->emitter->deleteWhenEmpty();
         delete wheel->shapeInstance;
      }
   }

   // Stop the sounds
   SFX_DELETE( mEngineSoundA );
   SFX_DELETE( mEngineSoundB );

   //
   scriptOnRemove();
   removeFromScene();
   Parent::onRemove();
}
//----------------------------------------------------------------------------
bool TankVehicle::onNewDataBlock(GameBaseData* dptr, bool reload)
{
   // Delete any existing wheel resources if we're switching
   // datablocks.
   if (mDataBlock) 
   {
      TankWheel* wend = &mTankWheel[mDataBlock->tankWheelCount];
      for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++) 
      {
         if (!wheel->emitter.isNull()) 
         {
            wheel->emitter->deleteWhenEmpty();
            wheel->emitter = 0;
         }
         delete wheel->shapeInstance;
         wheel->shapeInstance = 0;
      }
   }

   // Load up the new datablock
   mDataBlock = dynamic_cast<TankVehicleData*>(dptr);
   if (!mDataBlock || !Parent::onNewDataBlock(dptr,reload))
      return false;

   // Set inertial tensor, default for the vehicle is sphere
   if (mDataBlock->massBox.x > 0 && mDataBlock->massBox.y > 0 && mDataBlock->massBox.z > 0)
      mRigid.setObjectInertia(mDataBlock->massBox);
   else
      mRigid.setObjectInertia(mObjBox.maxExtents - mObjBox.minExtents);

   // Initialize the wheels...
   for (S32 i = 0; i < mDataBlock->tankWheelCount; i++) 
   {
      TankWheel* wheel = &mTankWheel[i];
      wheel->data = &mDataBlock->tankWheel[i];
      wheel->tire = 0;
      wheel->spring = 0;

      wheel->surface.contact = false;
      wheel->surface.object  = NULL;
      wheel->avel = 0;
      wheel->apos = 0;
      wheel->extension = 1;
      wheel->slip = 0;

      wheel->emitter = 0;
      // Each wheel get's it's own particle emitter
      if( mDataBlock->tireEmitter && isGhost() )
      {
         wheel->emitter = new ParticleEmitter;
         wheel->emitter->onNewDataBlock( mDataBlock->tireEmitter, false );
         wheel->emitter->registerObject();
      }

		//Mask off the manually controlled springs
		if( isGhost() && wheel->data->treadNode != -1 )
         mShapeInstance->setNodeAnimationState(wheel->data->treadNode, TSShapeInstance::MaskNodeHandsOff);
   }

   // mark callback nodes (for turret/weapon control)
	if(mDataBlock->mTurretNode != -1)
		mShapeInstance->setNodeAnimationState(mDataBlock->mTurretNode,TSShapeInstance::MaskNodeHandsOff);
	if(mDataBlock->mWeaponNode != -1)
		mShapeInstance->setNodeAnimationState(mDataBlock->mWeaponNode,TSShapeInstance::MaskNodeHandsOff);

	if (isGhost()) 
   {
      mShapeInstance->setNodeAnimationState(mDataBlock->mSuspensionNode,TSShapeInstance::MaskNodeHandsOff);

      // Create the sounds ahead of time.  This reduces runtime
      // costs and makes the system easier to understand.
      SFX_DELETE( mEngineSoundA );
      SFX_DELETE( mEngineSoundB );

      if ( mDataBlock->tankSound[TankVehicleData::EngineSoundA] )
         mEngineSoundA = SFX->createSource( mDataBlock->tankSound[TankVehicleData::EngineSoundA], &getTransform() );

      if ( mDataBlock->tankSound[TankVehicleData::EngineSoundB] )
         mEngineSoundB = SFX->createSource( mDataBlock->tankSound[TankVehicleData::EngineSoundB], &getTransform() );
   }

   scriptOnNewDataBlock();
   return true;
}
//----------------------------------------------------------------------------
S32 TankVehicle::getWheelCount()
{
   // Return # of hubs defined on the car body
   return mDataBlock? mDataBlock->tankWheelCount: 0;
}
void TankVehicle::setWheelSteering(S32 wheel,F32 steering)
{
   AssertFatal(wheel >= 0 && wheel < TankVehicleData::MaxTankWheels,"Wheel index out of bounds");
   mTankWheel[wheel].steering = mClampF(steering,-1,1);
   setMaskBits(TankWheelMask);
}
void TankVehicle::setWheelPowered(S32 wheel,bool powered)
{
   AssertFatal(wheel >= 0 && wheel < TankVehicleData::MaxTankWheels,"Wheel index out of bounds");
   mTankWheel[wheel].powered = powered;
   setMaskBits(TankWheelMask);
}
void TankVehicle::setWheelTire(S32 wheel,TankVehicleTire* tire)
{
   AssertFatal(wheel >= 0 && wheel < TankVehicleData::MaxTankWheels,"Wheel index out of bounds");
   mTankWheel[wheel].tire = tire;
   setMaskBits(TankWheelMask);
}
void TankVehicle::setWheelSpring(S32 wheel,TankVehicleSpring* spring)
{
   AssertFatal(wheel >= 0 && wheel < TankVehicleData::MaxTankWheels,"Wheel index out of bounds");
   mTankWheel[wheel].spring = spring;
   setMaskBits(TankWheelMask);
}
//----------------------------------------------------------------------------
void TankVehicle::getWheelInstAndTransform( U32 index, TSShapeInstance** inst, MatrixF* xfrm ) const
{
   AssertFatal( index < TankVehicleData::MaxTankWheels,
      "TankVehicle::getWheelInstAndTransform() - Bad wheel index!" );

   const TankWheel* wheel = &mTankWheel[index];
   *inst = wheel->shapeInstance;
   
   if ( !xfrm || !wheel->shapeInstance )
      return;

   MatrixF world = getRenderTransform();
   world.scale( mObjScale );

   // Steering & spring extension
   MatrixF hub(EulerF(0,0,mSteeringLR * wheel->steering));
   Point3F pos = wheel->data->pos;
   pos.z -= wheel->spring->length * wheel->extension;
   hub.setColumn(3,pos);
   world.mul(hub);

   // Wheel rotation
   MatrixF rot(EulerF(wheel->apos * M_2PI,0,0));
   world.mul(rot);

   // Rotation the tire to face the right direction
   // (could pre-calculate this)
   MatrixF wrot(EulerF(0,0,(wheel->data->pos.x > 0)? M_PI/2: -M_PI/2));
   world.mul(wrot);

   *xfrm = world;
}
//----------------------------------------------------------------------------
void TankVehicle::processTick(const Move* move)
{
   Parent::processTick(move);

	//Turret/Suspension System -->
	updateAnimation();

	if( isGhost() )
      updateTankSuspension();
	//Turret/Suspension System <--
}
//-----------------------------------------------------------
// Function name:  TankVehicle::interpolateTick
// Summary:        Interpolate between prev tick location and next.
//                 This lets the mDelta state system do its thing
//						 Then updates animation using the mCamera var
//						 This is a client-side only method.
//-----------------------------------------------------------
void TankVehicle::interpolateTick(F32 dt)
{
   Parent::interpolateTick(dt);

	updateAnimation();
}
//-----------------------------------------------------------
void TankVehicle::updateMove(const Move* move)
{
   Parent::updateMove(move);

   // Brake on trigger
   mBraking = move->trigger[2];
}
//----------------------------------------------------------------------------
void TankVehicle::advanceTime(F32 dt)
{
   PROFILE_SCOPE( TankVehicle_AdvanceTime );

   Parent::advanceTime(dt);

   // Stick the wheels to the ground.  This is purely so they look
   // good while the vehicle is being interpolated.
   extendWheels();

   // Update wheel angular position and slip, this is a client visual
   // feature only, it has no affect on the physics.
   F32 slipTotal = 0;
   F32 torqueTotal = 0;

   TankWheel* wend = &mTankWheel[mDataBlock->tankWheelCount];
   for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++)
	{
      if (wheel->tire && wheel->spring) 
		{
         // Update angular position
         wheel->apos += (wheel->avel * dt) / M_2PI;
         wheel->apos -= mFloor(wheel->apos);
         if (wheel->apos < 0)
            wheel->apos = 1 - wheel->apos;

         // Keep track of largest slip
         slipTotal += wheel->slip;
         torqueTotal += wheel->torqueScale;
      }
	}

   // Update the sounds based on wheel slip and torque output
	updateEngineSound(sIdleEngineVolume + (1 - sIdleEngineVolume) * (1 - (torqueTotal / mDataBlock->tankWheelCount)));
	updateWheelThreads();
   updateWheelParticles(dt);
}
//------------------------------------------
// Function name:	TankVehicle::updateTankSuspension
// Summary:       Update Tank Springs
//						I like this setup, 
//						but needs to be setup
//------------------------------------------
void TankVehicle::updateTankSuspension()
{
	return;

/*
   Point3F x,y,z;
   getTransform().getColumn(0,&x);
   getTransform().getColumn(1,&y);
   getTransform().getColumn(2,&z);

   Point3F adjustForce1(0,0,0);
   if (mContact)
   {
      // if on the ground, apply force based on acceleration
      Point3F dv = smStartVelocity - mVelocity; 
      adjustForce1.x -= mDot(x,dv);
      adjustForce1.y -= mDot(y,dv);
      F32 redist = mRandF(0.0f,1.0f);
      adjustForce1.x -= redist * mDot(z,dv);
      adjustForce1.y -= (1.0f-redist) * mDot(z,dv);
      adjustForce1 *= mDataBlock->springVelScale;

      // if on the ground, set the center position of spring
      // based on the angle of the tank
      F32 scale = -1.4f; // magic scale...
      mTankSpringCenter.x = scale * x.z * mDataBlock->springRangeX;
      mTankSpringCenter.x = mClampF(mTankSpringCenter.x,-mDataBlock->springRangeX,mDataBlock->springRangeX);
      mTankSpringCenter.y = scale * y.z * mDataBlock->springRangeY;
      mTankSpringCenter.y = mClampF(mTankSpringCenter.y,-mDataBlock->springRangeY,mDataBlock->springRangeY);
      mTankSpringCenter.z = 0.0f;
   }

   // spring back to center position
   Point3F adjustForce2 = mTankSpringPos - mTankSpringCenter;
   //adjustForce2 *= mDataBlock->springCorrectScale1;
   // No harm hard-coding this
   adjustForce2 *= 0.5f;

   mTankSpringVel -= adjustForce1;
   mTankSpringVel -= adjustForce2;

   F32 springScale = mContact ? mDataBlock->springLooseness : 0.9f;
   mTankSpringPos *= springScale;
   mTankSpringPos += (1.0f-mDataBlock->springLooseness) * mTankSpringCenter;
   mTankSpringPos += mTankSpringVel * TickSec;

   F32 clamped = mClampF(mTankSpringPos.x,-mDataBlock->springRangeX,mDataBlock->springRangeX);
   if (clamped!=mTankSpringPos.x)
      mTankSpringVel.x = 0.0f;
   mTankSpringPos.x = clamped;

   clamped = mClampF(mTankSpringPos.y,-mDataBlock->springRangeY,mDataBlock->springRangeY);
   if (clamped!=mTankSpringPos.y)
      mTankSpringVel.y = 0.0f;
   mTankSpringPos.y = clamped;

   clamped = mClampF(mTankSpringPos.z,-mDataBlock->springRangeZ,mDataBlock->springRangeZ);
   if (clamped!=mTankSpringPos.z)
      mTankSpringVel.z = 0.0f;
   mTankSpringPos.z = clamped;

*/
}
//----------------------------------------------
void TankVehicle::updateAnimation(bool muzzleOnly)
{
	S32 node;
	MatrixF * mat;
	Point3F defaultPos;
	Point3F tCameraRot = getCameraRotation();

   // set Turret...
   node = mDataBlock->mTurretNode;
   mat = &mShapeInstance->mNodeTransforms[node];
   defaultPos = mDataBlock->mShape->defaultTranslations[node];
   mat->set(EulerF(0,0,tCameraRot.z));
   mat->setColumn(3,defaultPos);

	// set Barrel...
   node = mDataBlock->mWeaponNode;
   mat = &mShapeInstance->mNodeTransforms[node];
   defaultPos = mDataBlock->mShape->defaultTranslations[node];
   mat->set(EulerF(tCameraRot.x,0,0));
   mat->setColumn(3,defaultPos);

   if( isGhost() )
   {
      if( muzzleOnly )
      {
         // tank suspension...
         node = mDataBlock->mSuspensionNode;
         mat = &mShapeInstance->mNodeTransforms[node];
         defaultPos = mDataBlock->mShape->defaultTranslations[node];
         mat->identity();
         mat->setColumn(3,defaultPos);
      }
      else
      {
         // wheel suspension...
			for (S32 i = 0; i < mDataBlock->tankWheelCount; i++) 
			{
				if( mTankWheel[i].data->treadNode != -1 )
				{
					node = mTankWheel[i].data->treadNode;
					mat = &mShapeInstance->mNodeTransforms[node];
					defaultPos = mDataBlock->mShape->defaultTranslations[node];
					defaultPos.z -= mTankWheel[i].spring->length * mTankWheel[i].extension;
					mat->identity();
					mat->setColumn(3,defaultPos);
				}
         }

			// tank suspension...
/*         node = mDataBlock->mSuspensionNode;
         mat = &mShapeInstance->mNodeTransforms[node];
         defaultPos = mDataBlock->mShape->defaultTranslations[node];
         defaultPos.z -= mTankSpringPos.z;

         Point3F z = mTankSpringPos;
         z.z=1.0f;
         z.normalize();
         Point3F x,y;
         mCross(Point3F(0,1,0),z,&x);
         x.normalize();
         mCross(z,x,&y);

         mat->setColumn(0,x);
         mat->setColumn(1,y);
         mat->setColumn(2,z);
         mat->setColumn(3,defaultPos);
*/
      }
   }
   mShapeInstance->setDirty(TSShapeInstance::TransformDirty);
   mShapeInstance->animate();
}
//-----------------------------------------------------------
// Function name:  TankVehicle::onImageRecoil
// Summary:        Callback when weapon fires...from ShapeBase
//-----------------------------------------------------------
void TankVehicle::onImageRecoil(U32 imageSlot, ShapeBaseImageData::StateData::RecoilState)
{
   F32 kickPower = mDataBlock->mPrimaryRecoil;
   F32 angle = mCameraRot.x;
   //mTankSpringVel.x -= kickPower * mSin(angle);
   //mTankSpringVel.y -= kickPower * mCos(angle);
}
//-----------------------------------------------------------
/** Update the rigid body forces on the vehicle
   This method calculates the forces acting on the body, including gravity,
   suspension & tire forces.
*/
//-----------------------------------------------------------
void TankVehicle::updateForces(F32 dt)
{
   PROFILE_SCOPE( TankVehicle_UpdateForces );

   extendWheels();

   F32 aMomentum = mMass / mDataBlock->tankWheelCount;

   // Get the current matrix and extact vectors
   MatrixF currMatrix;
   mRigid.getTransform(&currMatrix);

   Point3F bx,by,bz;
   currMatrix.getColumn(0,&bx);
   currMatrix.getColumn(1,&by);
   currMatrix.getColumn(2,&bz);

   // Steering angles from current steering wheel position
   F32 quadraticSteering = 0.0f;	//-(mSteeringLR * mFabs(mSteeringLR));
   F32 cosSteering,sinSteering;
   mSinCos(quadraticSteering, sinSteering, cosSteering);

	//	Mythic Take over Steering Correctly...
	S8 mSteerControl = 0;
	if( mSteeringLR != 0.0f )
		mSteerControl = ( mSteeringLR > 0.0f ) ? 1 : -1;

   // Calculate Engine and brake torque values used later by in
   // wheel calculations.
	// Attempt to Manage Steering by Reducing Wheel Speed
	//	Simple adjustment of Speed for the moment
	//	Left == mSteeringLR == -1 / Right == mSteeringLR == 1
	//
   F32 engineTorqueLeft,engineTorqueRight,brakeVelLeft,brakeVelRight,engineTorque,brakeVel;
   if (mBraking) 
   {
		//If braking turn off steering
      brakeVel = (mDataBlock->brakeTorque / aMomentum) * dt;
      engineTorque = engineTorqueLeft = engineTorqueRight = 0;
		brakeVelLeft  = (mSteerControl == -1) ? (brakeVel * -0.25) : brakeVel;
		brakeVelRight = (mSteerControl == 1)  ? (brakeVel * -0.25) : brakeVel;
   }
   else 
   {
      if (mThrottle) 
      {
         engineTorque = mDataBlock->engineTorque * mThrottle;
			brakeVelLeft = brakeVelRight = brakeVel = 0;
			engineTorqueLeft  = (mSteerControl == -1) ? (engineTorque * -0.25) : engineTorque;
			engineTorqueRight = (mSteerControl == 1)  ? (engineTorque * -0.25) : engineTorque;
		}
      else 
      {
         // Engine brake.
         brakeVel = (mDataBlock->engineBrake / aMomentum) * dt;
			engineTorque = engineTorqueLeft = engineTorqueRight = 0;
			brakeVelLeft  = (mSteerControl == -1) ? (brakeVel * -0.25) : brakeVel;
			brakeVelRight = (mSteerControl == 1)  ? (brakeVel * -0.25) : brakeVel;
      }
   }

   // Integrate forces, we'll do this ourselves here instead of
   // relying on the rigid class which does it during movement.
   TankWheel* wend = &mTankWheel[mDataBlock->tankWheelCount];
   mRigid.force.set(0, 0, 0);
   mRigid.torque.set(0, 0, 0);

   // Calculate vertical load for friction.  Divide up the spring
   // forces across all the wheels that are in contact with
   // the ground.
   U32 contactCount = 0;
   F32 verticalLoad = 0;
   for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++) 
   {
      if (wheel->tire && wheel->spring && wheel->surface.contact) 
      {
         verticalLoad += wheel->spring->force * (1 - wheel->extension);
         contactCount++;
      }
   }
   if (contactCount)
      verticalLoad /= contactCount;

   // Sum up spring and wheel torque forces
   for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++)  
   {
      if (!wheel->tire || !wheel->spring)
         continue;

      F32 Fy = 0;
      if (wheel->surface.contact) 
      {
         // First, let's compute the wheel's position, and worldspace velocity
         Point3F pos, r, localVel;
         currMatrix.mulP(wheel->data->pos, &pos);
         mRigid.getOriginVector(pos,&r);
         mRigid.getVelocity(r, &localVel);

         // Spring force & damping
         F32 spring  = wheel->spring->force * (1 - wheel->extension);
         if (wheel->extension == 0) //spring fully compressed
         {
            F32 n = -mDot(localVel,Point3F(0,0,1));
            if (n >= 0)
            {
               F32 d = mRigid.getZeroImpulse(r,Point3F(0,0,1));
               F32 j = n * (1 + mRigid.restitution) * d;
               mRigid.force += Point3F(0,0,1) * j;
            }
         }

         F32 damping = wheel->spring->damping * -(mDot(bz, localVel) / wheel->spring->length);
         if (damping < 0)
            damping = 0;

         F32 antiSway = 0;
         if (wheel->data->opposite != -1)
         {
            TankWheel* oppositeWheel = &mTankWheel[wheel->data->opposite];
            if (oppositeWheel->surface.contact)
               antiSway = ((oppositeWheel->extension - wheel->extension) *
                  wheel->spring->antiSway);
            if (antiSway < 0)
               antiSway = 0;
         }

         // Spring forces act straight up and are applied at the spring's root position.
         Point3F t, forceVector = bz * (spring + damping + antiSway);
         mCross(r, forceVector, &t);
         mRigid.torque += t;
         mRigid.force += forceVector;

         // Tire direction vectors perpendicular to surface normal
         Point3F wheelXVec = bx * cosSteering;
         wheelXVec += by * sinSteering * wheel->steering;
         Point3F tireX, tireY;
         mCross(wheel->surface.normal, wheelXVec, &tireY);
         tireY.normalize();
         mCross(tireY, wheel->surface.normal, &tireX);
         tireX.normalize();

         // Velocity of tire at the surface contact
         Point3F wheelContact, wheelVelocity;
         mRigid.getOriginVector(wheel->surface.pos,&wheelContact);
         mRigid.getVelocity(wheelContact, &wheelVelocity);

         F32 xVelocity = mDot(tireX, wheelVelocity);
         F32 yVelocity = mDot(tireY, wheelVelocity);

         // Longitudinal tire deformation force
         F32 ddy = (wheel->avel * wheel->tire->radius - yVelocity) -
            wheel->tire->longitudinalRelaxation *
            mFabs(wheel->avel) * wheel->Dy;
         wheel->Dy += ddy * dt;
         Fy = (wheel->tire->longitudinalForce * wheel->Dy +
            wheel->tire->longitudinalDamping * ddy);

         // Lateral tire deformation force
         F32 ddx = xVelocity - wheel->tire->lateralRelaxation *
            mFabs(wheel->avel) * wheel->Dx;
         wheel->Dx += ddx * dt;
         F32 Fx = -(wheel->tire->lateralForce * wheel->Dx +
            wheel->tire->lateralDamping * ddx);

         // Vertical load on the tire
         verticalLoad = spring + damping + antiSway;
         if (verticalLoad < 0)
            verticalLoad = 0;

         // Adjust tire forces based on friction
         F32 surfaceFriction = 1;
         F32 mu = surfaceFriction * (wheel->slipping ? wheel->tire->kineticFriction : wheel->tire->staticFriction);
         F32 Fn = verticalLoad * mu; Fn *= Fn;
         F32 Fw = Fx * Fx + Fy * Fy;
         if (Fw > Fn) 
         {
            F32 K = mSqrt(Fn / Fw);
            Fy *= K;
            Fx *= K;
            wheel->Dy *= K;
            wheel->Dx *= K;
            wheel->slip = 1 - K;
            wheel->slipping = true;
         }
         else 
         {
            wheel->slipping = false;
            wheel->slip = 0;
         }

         forceVector = (tireX * Fx) + (tireY * Fy);
         pos -= bz * (wheel->spring->length * wheel->extension);
         mRigid.getOriginVector(pos,&r);
         mCross(r, forceVector, &t);
         mRigid.torque += t;
         mRigid.force += forceVector;
      }
      else 
      {
         wheel->torqueScale  = 0;
         wheel->slip = 0;
         wheel->Dy += (-wheel->tire->longitudinalRelaxation *
                       mFabs(wheel->avel) * wheel->Dy) * dt;
         wheel->Dx += (-wheel->tire->lateralRelaxation *
                       mFabs(wheel->avel) * wheel->Dx) * dt;
      }

      if (wheel->powered) 
      {
         F32 maxAvel = mDataBlock->maxWheelSpeed / wheel->tire->radius;
         wheel->torqueScale = (mFabs(wheel->avel) > maxAvel) ? 0 :
            1 - (mFabs(wheel->avel) / maxAvel);
      }
      else
         wheel->torqueScale = 0;

		//Mythic DEBUG
		// Change to Torque / Brakeing to do Left Right turns
		//	Instead of Tire Deformations :)
		if( mSteerControl == 0 )
			wheel->avel += (((wheel->torqueScale * engineTorque) - Fy * wheel->tire->radius) / aMomentum) * dt;
		else	//Turn Baby
		{
			//Track Speed Modifications
			F32 tempTorque = engineTorqueLeft;
			U8 endRight = mDataBlock->mInnerWheelsPerSide + 4;
			for(int i=4; i<mDataBlock->tankWheelCount; i++)
			{
				if(wheel == &mTankWheel[i])
				{
					tempTorque = (i<endRight) ? engineTorqueRight : engineTorqueLeft;
					wheel->avel += (((wheel->torqueScale * tempTorque) - Fy * wheel->tire->radius) / aMomentum) * dt;
				}
			}
		}
      // Adjust the wheel's angular velocity based on brake torque.
      // This is done after avel update to make sure we come to a
      // complete stop.
		if (brakeVel > mFabs(wheel->avel))
			wheel->avel = 0;
		else
		{
			if( mSteerControl == 0 )
			{
				if (wheel->avel > 0)
					wheel->avel -= brakeVel;
				else
					wheel->avel += brakeVel;
			}
			else	//Turn Baby
			{
				//Track Speed Modifications
				F32 tempBrake = brakeVelLeft;
				U8 endRight = mDataBlock->mInnerWheelsPerSide + 4;
				for(int i=4; i<mDataBlock->tankWheelCount; i++)
				{
					if(wheel == &mTankWheel[i])
					{
						tempBrake = (i<endRight) ? brakeVelRight : brakeVelLeft;
						if (wheel->avel > 0)
							wheel->avel -= tempBrake;
						else
							wheel->avel += tempBrake;
					}
				}
			}
		}
   }

   // Container drag & buoyancy
   mRigid.force  += Point3F(0, 0, -mBuoyancy * sTankVehicleGravity * mRigid.mass);
   mRigid.force  -= mRigid.linVelocity * mDrag;
   mRigid.torque -= mRigid.angMomentum * mDrag;

   if (mRigid.atRest && (mRigid.force.len() || mRigid.torque.len()))
      mRigid.atRest = false;

   // Gravity
   mRigid.force += Point3F(0, 0, sTankVehicleGravity * mRigid.mass);

   // Integrate and update velocity
   mRigid.linMomentum += mRigid.force * dt;
   mRigid.angMomentum += mRigid.torque * dt;
   mRigid.updateVelocity();

   mRigid.force.set(0, 0, 0);
   mRigid.torque.set(0, 0, 0);
   if (mRigid.atRest)
      mRigid.setAtRest();
}
//----------------------------------------------------------------------------
/** Extend the wheels
   The wheels are extended until they contact a surface. The extension
   is instantaneous.  The wheels are extended before force calculations and
   also on during client side interpolation (so that the wheels are glued
   to the ground).
*/
void TankVehicle::extendWheels(bool clientHack)
{
   PROFILE_SCOPE( TankVehicle_ExtendWheels );

   disableCollision();

   MatrixF currMatrix;
   
   if(clientHack)
      currMatrix = getRenderTransform();
   else
      mRigid.getTransform(&currMatrix);

   // Does a single ray cast down for now... this will have to be
   // changed to something a little more complicated to avoid getting
   // stuck in cracks.
   TankWheel* wend = &mTankWheel[mDataBlock->tankWheelCount];
   for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++) 
   {
      if (wheel->tire && wheel->spring) 
      {
         wheel->extension = 1;

         // The ray is cast from the spring mount point to the tip of
         // the tire.  If there is a collision the spring extension is
         // adjust to remove the tire radius.
         Point3F sp,vec;
         currMatrix.mulP(wheel->data->pos,&sp);
			currMatrix.mulV(VectorF(0,0,-wheel->spring->length),&vec);
			F32 ts = wheel->tire->radius / wheel->spring->length;
         Point3F ep = sp + (vec * (1 + ts));
         ts = ts / (1+ts);
         RayInfo rInfo;
         if (mContainer->castRay(sp, ep, sClientCollisionMask & ~PlayerObjectType, &rInfo)) 
         {
            wheel->surface.contact  = true;
            wheel->extension = (rInfo.t < ts)? 0: (rInfo.t - ts) / (1 - ts);
            wheel->surface.normal   = rInfo.normal;
            wheel->surface.pos      = rInfo.point;
            wheel->surface.material = rInfo.material;
            wheel->surface.object   = rInfo.object;
         }
			else
			{
				wheel->surface.contact = false;
				wheel->slipping = true;
			}
      }
   }
   enableCollision();
}
//----------------------------------------------------------------------------
/** Update wheel steering and suspension threads.
   These animations are purely cosmetic and this method is only invoked
   on the client.
*/
//----------------------------------------------------------------------------
void TankVehicle::updateWheelThreads()
{
	return;
/*
	TankWheel* wend = &mTankWheel[mDataBlock->tankWheelCount];
   for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++) 
   {
      if (wheel->tire && wheel->spring && wheel->springThread) 
      {
         // Scale the spring animation time to match the current
         // position of the wheel.  We'll also check to make sure
         // the animation is long enough, if it isn't, just stick
         // it at the end.
         F32 pos = wheel->extension * wheel->spring->length;
         if (pos > wheel->data->springLength)
            pos = 1;
         else
            pos /= wheel->data->springLength;
         mShapeInstance->setPos(wheel->springThread,pos);
      }
   }
*/
}
//----------------------------------------------------------------------------
/** Update wheel particles effects
   These animations are purely cosmetic and this method is only invoked
   on the client.  Particles are emitted as long as the moving.
*/
//----------------------------------------------------------------------------
void TankVehicle::updateWheelParticles(F32 dt)
{
   // OMG l33t hax
   extendWheels(true);
   
   Point3F vel = Parent::getVelocity();
   F32 speed = vel.len();

   // Don't bother if we're not moving.
   if (speed > 1.0f)  
   {
      Point3F axis = vel;
      axis.normalize();

      TankWheel* wend = &mTankWheel[mDataBlock->tankWheelCount];
      for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++) 
      {
         if (wheel->tire && wheel->spring && !wheel->emitter.isNull() &&
               wheel->surface.contact && wheel->surface.object && wheel->powered)
         {
				if( mRandom.randF() <= 0.6f )	//A little bit less dust here
				{
	            Material* material = ( wheel->surface.material ? dynamic_cast< Material* >( wheel->surface.material->getMaterial() ) : 0 );
		         if( material)//&& material->mShowDust )
			      {
				      ColorF colorList[ ParticleData::PDC_NUM_KEYS ];
					   for( U32 x = 0; x < getMin( Material::NUM_EFFECT_COLOR_STAGES, ParticleData::PDC_NUM_KEYS ); ++ x )
						   colorList[ x ] = material->mEffectColor[ x ];
	               for( U32 x = Material::NUM_EFFECT_COLOR_STAGES; x < ParticleData::PDC_NUM_KEYS; ++ x )
		               colorList[ x ].set( 1.0, 1.0, 1.0, 0.0 );
						wheel->emitter->setColors( colorList );
	               wheel->emitter->emitParticles( wheel->surface.pos, true, axis, vel, (U32)(3));
		         }
				}
         }
      }
   }
}
//----------------------------------------------------------------------------
/** Update engine sound
   This method is only invoked by clients.
*/
//----------------------------------------------------------------------------
void TankVehicle::updateEngineSound(F32 level)
{
   if ( !mEngineSoundA || !mEngineSoundB )
      return;

	if( isEngineOn() )
	{
		if ( !mEngineSoundA->isPlaying() )
			mEngineSoundA->play();
		if ( !mEngineSoundB->isPlaying() )
			mEngineSoundB->play();

		mEngineSoundA->setTransform( getTransform() );
		mEngineSoundA->setVelocity( getVelocity() );
		//mEngineSoundA->setVolume( level );

		mEngineSoundB->setTransform( getTransform() );
		mEngineSoundB->setVelocity( getVelocity() );
		//mEngineSoundB->setVolume( level );

		// Adjust pitch
		F32 pitch = ((level-sIdleEngineVolume) * 1.3f);
		if (pitch < 0.4f)  
			pitch = 0.4f;

		mEngineSoundA->setPitch( pitch );
		mEngineSoundB->setPitch( pitch );
	}
	else
	{
		mEngineSoundA->stop();
		mEngineSoundB->stop();
	}
}
//----------------------------------------------------------------------------
U32 TankVehicle::getCollisionMask()
{
   return sClientCollisionMask;
}
//----------------------------------------------------------------------------
/** Build a collision polylist
   The polylist is filled with polygons representing the collision volume
   and the wheels.
*/
//----------------------------------------------------------------------------
bool TankVehicle::buildPolyList(PolyListContext context, AbstractPolyList* polyList, const Box3F& box, const SphereF& sphere)
{
   PROFILE_SCOPE( TankVehicle_BuildPolyList );

   // Parent will take care of body collision.
   Parent::buildPolyList(context, polyList,box,sphere);

   // Add wheels as boxes.
   TankWheel* wend = &mTankWheel[mDataBlock->tankWheelCount];
   for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++) 
	{
      if (wheel->tire && wheel->spring) 
		{
         Box3F wbox;
         F32 radius = wheel->tire->radius;
         wbox.minExtents.x = -(wbox.maxExtents.x = radius / 2);
			wbox.minExtents.y = -(wbox.maxExtents.y = radius);
         wbox.minExtents.z = -(wbox.maxExtents.z = radius);
         MatrixF mat = mObjToWorld;

         Point3F sp,vec;
         mObjToWorld.mulP(wheel->data->pos,&sp);
         mObjToWorld.mulV(VectorF(0,0,-wheel->spring->length),&vec);
         Point3F ep = sp + (vec * wheel->extension);
         mat.setColumn(3,ep);
         polyList->setTransform(&mat,Point3F(1,1,1));
         polyList->addBox(wbox);
      }
   }
   return !polyList->isEmpty();
}
void TankVehicle::prepBatchRender(SceneRenderState* state, S32 mountedImageIndex)
{
   Parent::prepBatchRender( state, mountedImageIndex );

   if ( mountedImageIndex != -1 )
      return;

   // Set up our render state *here*, 
   // before the push world matrix, so 
   // that wheel rendering will be correct.
   TSRenderState rdata;
   rdata.setSceneState( state );

   // We might have some forward lit materials
   // so pass down a query to gather lights.
   LightQuery query;
   query.init( getWorldSphere() );
   rdata.setLightQuery( &query );

   // Shape transform
   GFX->pushWorldMatrix();

   MatrixF mat = getRenderTransform();
   mat.scale( mObjScale );
   GFX->setWorldMatrix( mat );

   TankWheel* wend = &mTankWheel[mDataBlock->tankWheelCount];
   for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++) 
   {
      if (wheel->shapeInstance) 
      {
         GFX->pushWorldMatrix();

         // Steering & spring extension
         MatrixF hub(EulerF(0,0,mSteeringLR * wheel->steering));
         Point3F pos = wheel->data->pos;
         pos.z -= wheel->spring->length * wheel->extension;
         hub.setColumn(3,pos);

         GFX->multWorld(hub);

         // Wheel rotation
         MatrixF rot(EulerF(wheel->apos * M_2PI,0,0));
         GFX->multWorld(rot);

         // Rotation the tire to face the right direction
         // (could pre-calculate this)
         MatrixF wrot(EulerF(0,0,(wheel->data->pos.x > 0)? M_PI/2: -M_PI/2));
         GFX->multWorld(wrot);

         // Render!
         wheel->shapeInstance->animate();
         wheel->shapeInstance->render( rdata );

         if (mCloakLevel != 0.0f)
            wheel->shapeInstance->setAlphaAlways(1.0f - mCloakLevel);
         else
            wheel->shapeInstance->setAlphaAlways(1.0f);

         GFX->popWorldMatrix();
      }
   }
   GFX->popWorldMatrix();
}
//----------------------------------------------------------------------------
void TankVehicle::writePacketData(GameConnection *connection, BitStream *stream)
{
   Parent::writePacketData(connection, stream);
   stream->writeFlag(mBraking);

   TankWheel* wend = &mTankWheel[mDataBlock->tankWheelCount];
   for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++) 
   {
      stream->write(wheel->avel);
      stream->write(wheel->Dy);
      stream->write(wheel->Dx);
      stream->writeFlag(wheel->slipping);
   }
}
void TankVehicle::readPacketData(GameConnection *connection, BitStream *stream)
{
   Parent::readPacketData(connection, stream);
   mBraking = stream->readFlag();

   TankWheel* wend = &mTankWheel[mDataBlock->tankWheelCount];
   for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++) 
   {
      stream->read(&wheel->avel);
      stream->read(&wheel->Dy);
      stream->read(&wheel->Dx);
      wheel->slipping = stream->readFlag();
   }
   // Rigid state is transmitted by the parent...
   setPosition(mRigid.linPosition,mRigid.angPosition);
   mDelta.pos = mRigid.linPosition;
   mDelta.rot[1] = mRigid.angPosition;
}
//----------------------------------------------------------------------------
U32 TankVehicle::packUpdate(NetConnection *con, U32 mask, BitStream *stream)
{
   U32 retMask = Parent::packUpdate(con, mask, stream);

   // Update wheel datablock information
   if (stream->writeFlag(mask & TankWheelMask)) 
   {
      TankWheel* wend = &mTankWheel[mDataBlock->tankWheelCount];
      for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++) 
      {
         if (stream->writeFlag(wheel->tire && wheel->spring)) 
         {
            stream->writeRangedU32(wheel->tire->getId(),
               DataBlockObjectIdFirst,DataBlockObjectIdLast);
            stream->writeRangedU32(wheel->spring->getId(),
               DataBlockObjectIdFirst,DataBlockObjectIdLast);
            stream->writeFlag(wheel->powered);
            stream->write(wheel->steering);
         }
      }
   }

   // The rest of the data is part of the control object packet update.
   // If we're controlled by this client, we don't need to send it.
   if (stream->writeFlag(getControllingClient() == con && !(mask & InitialUpdateMask)))
      return retMask;

   stream->writeFlag(mBraking);

   if (stream->writeFlag(mask & PositionMask)) 
   {
      TankWheel* wend = &mTankWheel[mDataBlock->tankWheelCount];
      for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++) 
      {
         stream->write(wheel->avel);
         stream->write(wheel->Dy);
         stream->write(wheel->Dx);
      }
   }

   return retMask;
}
void TankVehicle::unpackUpdate(NetConnection *con, BitStream *stream)
{
   Parent::unpackUpdate(con,stream);

   // Update wheel datablock information
   if (stream->readFlag()) 
   {
      TankWheel* wend = &mTankWheel[mDataBlock->tankWheelCount];
      for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++) 
      {
         if (stream->readFlag()) 
         {
            SimObjectId tid = stream->readRangedU32(DataBlockObjectIdFirst,DataBlockObjectIdLast);
            SimObjectId sid = stream->readRangedU32(DataBlockObjectIdFirst,DataBlockObjectIdLast);
            if (!Sim::findObject(tid,wheel->tire) || !Sim::findObject(sid,wheel->spring)) 
            {
               con->setLastError("Invalid packet TankVehicle::unpackUpdate()");
               return;
            }
            wheel->powered = stream->readFlag();
            stream->read(&wheel->steering);

            // Create an instance of the tire for rendering
            delete wheel->shapeInstance;
            wheel->shapeInstance = (wheel->tire->shape == NULL) ? 0:
               new TSShapeInstance(wheel->tire->shape);
         }
      }
   }

   // After this is data that we only need if we're not the
   // controlling client.
   if (stream->readFlag())
      return;

   mBraking = stream->readFlag();

   if (stream->readFlag()) 
   {
      TankWheel* wend = &mTankWheel[mDataBlock->tankWheelCount];
      for (TankWheel* wheel = mTankWheel; wheel < wend; wheel++) 
      {
         stream->read(&wheel->avel);
         stream->read(&wheel->Dy);
         stream->read(&wheel->Dx);
      }
   }
}
//----------------------------------------------------------------------------
// Console Methods
//----------------------------------------------------------------------------
DefineEngineMethod( TankVehicle, setWheelSteering, bool, ( S32 wheel, F32 steering ),,
   "Set how much the wheel is affected by steering.\n"
   "The steering factor controls how much the wheel is rotated by the vehicle "
   "steering. For example, most cars would have their front wheels set to 1.0, "
   "and their rear wheels set to 0 since only the front wheels should turn.\n\n"
   "Negative values will turn the wheel in the opposite direction to the steering "
   "angle.\n"
   "@param wheel index of the wheel to set\n"
   "@param steering steering factor from -1 (full inverse) to 1 (full)\n"
   "@return true if successful, false if failed\n\n" )
{
   if ( wheel >= 0 && wheel < object->getWheelCount() ) {
      object->setWheelSteering( wheel, steering );
      return true;
   }
   else
      Con::warnf("setWheelSteering: wheel index %d out of bounds, vehicle has %d hubs",
         wheel, object->getWheelCount());
   return false;
}
DefineEngineMethod( TankVehicle, setWheelPowered, bool, ( S32 wheel, bool powered ),,
   "Set whether the wheel is powered (has torque applied from the engine).\n"
   "A rear wheel drive car for example would set the front wheels to false, "
   "and the rear wheels to true.\n"
   "@param wheel index of the wheel to set\n"
   "@param powered flag indicating whether to power the wheel or not\n"
   "@return true if successful, false if failed\n\n" )
{
   if ( wheel >= 0 && wheel < object->getWheelCount() ) {
      object->setWheelPowered( wheel, powered );
      return true;
   }
   else
      Con::warnf("setWheelPowered: wheel index %d out of bounds, vehicle has %d hubs",
         wheel, object->getWheelCount());
   return false;
}
DefineEngineMethod( TankVehicle, setWheelTire, bool, ( S32 wheel, TankVehicleTire* tire ),,
   "Set the TankVehicleTire datablock for this wheel.\n"
   "@param wheel index of the wheel to set\n"
   "@param tire TankVehicleTire datablock\n"
   "@return true if successful, false if failed\n\n"
   "@tsexample\n"
   "%obj.setWheelTire( 0, FrontTire );\n"
   "@endtsexample\n" )
{
   if (wheel >= 0 && wheel < object->getWheelCount()) {
      object->setWheelTire(wheel,tire);
      return true;
   }
   else {
      Con::warnf("setWheelTire: invalid tire datablock or wheel index, vehicle has %d hubs",
         object->getWheelCount());
      return false;
   }
}
DefineEngineMethod( TankVehicle, setWheelSpring, bool, ( S32 wheel, TankVehicleSpring* spring ),,
   "Set the TankVehicleSpring datablock for this wheel.\n"
   "@param wheel index of the wheel to set\n"
   "@param spring TankVehicleSpring datablock\n"
   "@return true if successful, false if failed\n\n"
   "@tsexample\n"
   "%obj.setWheelSpring( 0, FrontSpring );\n"
   "@endtsexample\n" )
{
   if (spring && wheel >= 0 && wheel < object->getWheelCount()) {
      object->setWheelSpring(wheel,spring);
      return true;
   }
   else {
      Con::warnf("setWheelSpring: invalid spring datablock or wheel index, vehicle has %d hubs",
         object->getWheelCount());
      return false;
   }
}
DefineEngineMethod( TankVehicle, getWheelCount, S32, (),,
   "Get the number of wheels on this vehicle.\n"
   "@return the number of wheels (equal to the number of hub nodes defined in the model)\n\n" )
{
   return object->getWheelCount();
}
