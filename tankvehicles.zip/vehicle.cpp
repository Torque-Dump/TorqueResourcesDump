//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

#include "platform/platform.h"
#include "T3D/vehicles/vehicle.h"

#include "math/mMath.h"
#include "console/simBase.h"
#include "console/console.h"
#include "console/consoleTypes.h"
#include "console/engineAPI.h"
#include "collision/clippedPolyList.h"
#include "collision/planeExtractor.h"
#include "core/stream/bitStream.h"
#include "core/dnet.h"
#include "T3D/gameBase/gameConnection.h"
#include "T3D/fx/cameraFXMgr.h"
#include "ts/tsShapeInstance.h"
#include "T3D/fx/particleEmitter.h"
#include "sfx/sfxSystem.h"
#include "sfx/sfxProfile.h"
#include "sfx/sfxSource.h"
#include "math/mathIO.h"
#include "scene/sceneRenderState.h"
#include "T3D/trigger.h"
#include "T3D/item.h"
#include "gfx/primBuilder.h"
#include "gfx/gfxDrawUtil.h"
#include "materials/materialDefinition.h"

namespace {

static U32 sWorkingQueryBoxStaleThreshold = 10;    // The maximum number of ticks that go by before
                                                   // the mWorkingQueryBox is considered stale and
                                                   // needs updating.  Set to -1 to disable.

static F32 sWorkingQueryBoxSizeMultiplier = 2.0f;  // How much larger should the mWorkingQueryBox be
                                                   // made when updating the working collision list.
                                                   // The larger this number the less often the working list
                                                   // will be updated due to motion, but any non-static shape
                                                   // that moves into the query box will not be noticed.

const U32 sMoveRetryCount = 3;

// Client prediction
const S32 sMaxWarpTicks = 3;           // Max warp duration in ticks
const S32 sMaxPredictionTicks = 30;    // Number of ticks to predict
const F32 sVehicleGravity = -20;

// Physics and collision constants
static F32 sRestTol = 0.5;             // % of gravity energy to be at rest
static int sRestCount = 10;            // Consecutive ticks before comming to rest

} // namespace {}

// Trigger objects that are not normally collided with.
static U32 sTriggerMask = ItemObjectType     |
                          TriggerObjectType  |
                          CorpseObjectType;

IMPLEMENT_CONOBJECT(VehicleData);
ConsoleDocClass( VehicleData,
   "@brief Base properties shared by all Vehicles (FlyingVehicle, HoverVehicle, "
   "WheeledVehicle.\n\n"
   "This datablock defines properties shared by all Vehicle types, but should "
   "not be instantiated directly. Instead, set the desired properties in the "
   "FlyingVehicleData, HoverVehicleData or WheeledVehicleData datablock.\n"
   "@ingroup Vehicles\n"
);
IMPLEMENT_CALLBACK( VehicleData, onEnterLiquid, void, ( Vehicle* obj, F32 coverage, const char* type ), ( obj, coverage, type ),
   "Called when the vehicle enters liquid.\n"
   "@param obj the Vehicle object\n"
   "@param coverage percentage of the vehicle's bounding box covered by the liquid\n"
   "@param type type of liquid the vehicle has entered\n" );
IMPLEMENT_CALLBACK( VehicleData, onLeaveLiquid, void, ( Vehicle* obj, const char* type ), ( obj, type ),
   "Called when the vehicle leaves liquid.\n"
   "@param obj the Vehicle object\n"
   "@param type type of liquid the vehicle has left\n" );
//----------------------------------------------------------------------------
VehicleData::VehicleData()
{
   shadowEnable = true;
   shadowSize = 256;
   shadowProjectionDistance = 14.0f;

	body.friction = 0;
   body.restitution = 1;

   minImpactSpeed = 25;
   softImpactSpeed = 25;
   hardImpactSpeed = 50;
   minRollSpeed = 0;
   maxSteeringAngle = M_PI_F/4.0f; // 45 deg.

   cameraRoll = true;
   cameraLag = 0;
   cameraDecay = 0;
   cameraOffset = 0;

   minDrag = 0;
   maxDrag = 0;
   integration = 1;
   collisionTol = 0.1f;
   contactTol = 0.1f;
   massCenter.set(0,0,0);
   massBox.set(0,0,0);

   drag = 0.7f;
   density = 4;

   jetForce = 500;
   jetEnergyDrain =  0.8f;
   minJetEnergy = 1;

   for (S32 i = 0; i < Body::MaxSounds; i++)
      body.sound[i] = 0;

   for (S32 i = 0; i < MaxWaterSounds; i++)
     waterSound[i] = 0;

   dustEmitter = NULL;
   dustID = 0;
   triggerDustHeight = 3.0;
   dustHeight = 1.0;

   dMemset( damageEmitterList, 0, sizeof( damageEmitterList ) );
   dMemset( damageEmitterOffset, 0, sizeof( damageEmitterOffset ) );
   dMemset( damageEmitterIDList, 0, sizeof( damageEmitterIDList ) );
   dMemset( damageLevelTolerance, 0, sizeof( damageLevelTolerance ) );
   dMemset( splashEmitterList, 0, sizeof( splashEmitterList ) );
   dMemset( splashEmitterIDList, 0, sizeof( splashEmitterIDList ) );

   numDmgEmitterAreas = 0;

   splashFreqMod = 300.0;
   splashVelEpsilon = 0.50;
   exitSplashSoundVel = 2.0;
   softSplashSoundVel = 1.0;
   medSplashSoundVel = 2.0;
   hardSplashSoundVel = 3.0;

   dMemset(waterSound, 0, sizeof(waterSound));

   collDamageThresholdVel = 20;
   collDamageMultiplier   = 0.05f;

//Mythic Debug Added -->
	freeCamPitch		= false;
	minCamPitchAngle	= -1.0f;
	maxCamPitchAngle	= 1.4f;	
	freeCamYaw			= false;
	minCamYawAngle		= -3.0f;		
	maxCamYawAngle		= 3.0f;

	///	These values Affect how quickly the Weapon can be turned
	///	Default Speed of turns/rotate/elevate
	///	No change to speed by Default
	///	Increase this value in DataBlock to slow it down 	
	mMaxTurnSpeed		= 1.0f;	
	mMaxPitchSpeed		= 1.0f;
	mMaxYawSpeed		= 1.0f;

	///	New Mounted Weapons System
	///	mNumMountPoints		== How many Personnel Seats
	///	mNumWeaponPoints		==	How many Weapon Spots
	///	mMountTrigger[x]		== Trigger[x] Assigned to weapon slot (x) x == trigger
	///	This System Revolves Around Slot [0] Being the Driver
	///	All Personnel Seats are the First Slots
	///	All other Slots have to be AFTER personnel
	///	With this Setup You can assign One Trigger to several weapons
	///	And so (2) mounted MiniGuns can fire Simultaneously
	///
	mPilotNode = 0;
	mNumMountPoints	= 0;
	mNumWeaponPoints	= 0;
	for( S32 i = 0; i<ShapeBase::MaxMountedImages; i++)
		mMountTrigger[i] = -1;
//Mythic Debug Added <--
}
//----------------------------------------------------------------------------
bool VehicleData::preload(bool server, String &errorStr)
{
   if (!Parent::preload(server, errorStr))
      return false;

   // Vehicle objects must define a collision detail
   if (!collisionDetails.size() || collisionDetails[0] == -1)
   {
      Con::errorf("VehicleData::preload failed: Vehicle models must define a collision-1 detail");
      return false;
   }

   // Resolve objects transmitted from server
   if (!server) 
	{
      for (S32 i = 0; i < Body::MaxSounds; i++)
         if (body.sound[i])
            Sim::findObject(SimObjectId(body.sound[i]),body.sound[i]);

		for (S32 i = 0; i < MaxWaterSounds; i++)
         if (waterSound[i])
            Sim::findObject(SimObjectId(waterSound[i]),waterSound[i]);
	}

   if( !dustEmitter && dustID != 0 )
   {
      if( !Sim::findObject( dustID, dustEmitter ) )
      {
         Con::errorf( ConsoleLogEntry::General, "VehicleData::preload Invalid packet, bad datablockId(dustEmitter): 0x%x", dustID );
      }
   }

   U32 i;
   for( i=0; i<VC_NUM_DAMAGE_EMITTERS; i++ )
   {
      if( !damageEmitterList[i] && damageEmitterIDList[i] != 0 )
      {
         if( !Sim::findObject( damageEmitterIDList[i], damageEmitterList[i] ) )
         {
            Con::errorf( ConsoleLogEntry::General, "VehicleData::preload Invalid packet, bad datablockId(damageEmitter): 0x%x", damageEmitterIDList[i] );
         }
      }
   }

   for( i=0; i<VC_NUM_SPLASH_EMITTERS; i++ )
   {
      if( !splashEmitterList[i] && splashEmitterIDList[i] != 0 )
      {
         if( !Sim::findObject( splashEmitterIDList[i], splashEmitterList[i] ) )
         {
            Con::errorf( ConsoleLogEntry::General, "VehicleData::preload Invalid packet, bad datablockId(splashEmitter): 0x%x", splashEmitterIDList[i] );
         }
      }
   }

   return true;
}
//----------------------------------------------------------------------------
void VehicleData::packData(BitStream* stream)
{
   S32 i;
   Parent::packData(stream);

   stream->write(body.restitution);
   stream->write(body.friction);
   for (i = 0; i < Body::MaxSounds; i++)
      if (stream->writeFlag(body.sound[i]))
         stream->writeRangedU32(packed? SimObjectId(body.sound[i]):
                                body.sound[i]->getId(),DataBlockObjectIdFirst,
                                DataBlockObjectIdLast);

//Mythic Debug Added -->
	stream->write(freeCamPitch);
	stream->write(minCamPitchAngle);
	stream->write(maxCamPitchAngle);
	stream->write(freeCamYaw);
	stream->write(minCamYawAngle);
	stream->write(maxCamYawAngle);
	stream->write(mMaxTurnSpeed);
	stream->write(mMaxPitchSpeed);
	stream->write(mMaxYawSpeed);
	stream->write(mPilotNode);
	stream->write(mNumMountPoints);

	if( mNumWeaponPoints > ShapeBase::MaxMountedImages )
		mNumWeaponPoints = ShapeBase::MaxMountedImages;
	stream->write(mNumWeaponPoints);

	for( S32 i=0; i<ShapeBase::MaxMountedImages; i++)
		stream->write(mMountTrigger[i]);
//Mythic Debug Added <--

   stream->write(minImpactSpeed);
   stream->write(softImpactSpeed);
   stream->write(hardImpactSpeed);
   stream->write(minRollSpeed);
   stream->write(maxSteeringAngle);

   stream->write(maxDrag);
   stream->write(minDrag);
   stream->write(integration);
   stream->write(collisionTol);
   stream->write(contactTol);
   mathWrite(*stream,massCenter);
   mathWrite(*stream,massBox);

   stream->write(jetForce);
   stream->write(jetEnergyDrain);
   stream->write(minJetEnergy);

   stream->writeFlag(cameraRoll);
   stream->write(cameraLag);
   stream->write(cameraDecay);
   stream->write(cameraOffset);

   stream->write( triggerDustHeight );
   stream->write( dustHeight );

   stream->write( numDmgEmitterAreas );

   stream->write(exitSplashSoundVel);
   stream->write(softSplashSoundVel);
   stream->write(medSplashSoundVel);
   stream->write(hardSplashSoundVel);

   // write the water sound profiles
   for(i = 0; i < MaxWaterSounds; i++)
      if(stream->writeFlag(waterSound[i]))
         stream->writeRangedU32(waterSound[i]->getId(), DataBlockObjectIdFirst,  DataBlockObjectIdLast);

   if (stream->writeFlag( dustEmitter ))
   {
      stream->writeRangedU32( dustEmitter->getId(), DataBlockObjectIdFirst,  DataBlockObjectIdLast );
   }

   for (i = 0; i < VC_NUM_DAMAGE_EMITTERS; i++)
   {
      if( stream->writeFlag( damageEmitterList[i] != NULL ) )
      {
         stream->writeRangedU32( damageEmitterList[i]->getId(), DataBlockObjectIdFirst,  DataBlockObjectIdLast );
      }
   }

   for (i = 0; i < VC_NUM_SPLASH_EMITTERS; i++)
   {
      if( stream->writeFlag( splashEmitterList[i] != NULL ) )
      {
         stream->writeRangedU32( splashEmitterList[i]->getId(), DataBlockObjectIdFirst,  DataBlockObjectIdLast );
      }
   }

   for (int j = 0;  j < VC_NUM_DAMAGE_EMITTER_AREAS; j++)
   {
      stream->write( damageEmitterOffset[j].x );
      stream->write( damageEmitterOffset[j].y );
      stream->write( damageEmitterOffset[j].z );
   }

   for (int k = 0; k < VC_NUM_DAMAGE_LEVELS; k++)
   {
      stream->write( damageLevelTolerance[k] );
   }

   stream->write(splashFreqMod);
   stream->write(splashVelEpsilon);

   stream->write(collDamageThresholdVel);
   stream->write(collDamageMultiplier);
}

void VehicleData::unpackData(BitStream* stream)
{
   Parent::unpackData(stream);

   stream->read(&body.restitution);
   stream->read(&body.friction);
   S32 i;
   for (i = 0; i < Body::MaxSounds; i++) {
      body.sound[i] = NULL;
      if (stream->readFlag())
         body.sound[i] = (SFXProfile*)stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);
   }

//Mythic Debug Added -->
	stream->read(&freeCamPitch);
	stream->read(&minCamPitchAngle);
	stream->read(&maxCamPitchAngle);
	stream->read(&freeCamYaw);
	stream->read(&minCamYawAngle);
	stream->read(&maxCamYawAngle);
	stream->read(&mMaxTurnSpeed);
	stream->read(&mMaxPitchSpeed);
	stream->read(&mMaxYawSpeed);
	stream->read(&mPilotNode);
	stream->read(&mNumMountPoints);
	stream->read(&mNumWeaponPoints);
	for(S32 i=0; i<ShapeBase::MaxMountedImages; i++)
		stream->read(&mMountTrigger[i]);
//Mythic Debug Added -->

   stream->read(&minImpactSpeed);
   stream->read(&softImpactSpeed);
   stream->read(&hardImpactSpeed);
   stream->read(&minRollSpeed);
   stream->read(&maxSteeringAngle);

   stream->read(&maxDrag);
   stream->read(&minDrag);
   stream->read(&integration);
   stream->read(&collisionTol);
   stream->read(&contactTol);
   mathRead(*stream,&massCenter);
   mathRead(*stream,&massBox);

   stream->read(&jetForce);
   stream->read(&jetEnergyDrain);
   stream->read(&minJetEnergy);

   cameraRoll = stream->readFlag();
   stream->read(&cameraLag);
   stream->read(&cameraDecay);
   stream->read(&cameraOffset);

   stream->read( &triggerDustHeight );
   stream->read( &dustHeight );

   stream->read( &numDmgEmitterAreas );

   stream->read(&exitSplashSoundVel);
   stream->read(&softSplashSoundVel);
   stream->read(&medSplashSoundVel);
   stream->read(&hardSplashSoundVel);

   // write the water sound profiles
   for(i = 0; i < MaxWaterSounds; i++)
      if(stream->readFlag())
      {
         U32 id = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);
         waterSound[i] = dynamic_cast<SFXProfile*>( Sim::findObject(id) );
      }

   if( stream->readFlag() )
   {
      dustID = (S32) stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);
   }

   for (i = 0; i < VC_NUM_DAMAGE_EMITTERS; i++)
   {
      if( stream->readFlag() )
      {
         damageEmitterIDList[i] = stream->readRangedU32( DataBlockObjectIdFirst, DataBlockObjectIdLast );
      }
   }

   for (i = 0; i < VC_NUM_SPLASH_EMITTERS; i++)
   {
      if( stream->readFlag() )
      {
         splashEmitterIDList[i] = stream->readRangedU32( DataBlockObjectIdFirst, DataBlockObjectIdLast );
      }
   }

   for( int j=0; j<VC_NUM_DAMAGE_EMITTER_AREAS; j++ )
   {
      stream->read( &damageEmitterOffset[j].x );
      stream->read( &damageEmitterOffset[j].y );
      stream->read( &damageEmitterOffset[j].z );
   }

   for( int k=0; k<VC_NUM_DAMAGE_LEVELS; k++ )
   {
      stream->read( &damageLevelTolerance[k] );
   }

   stream->read(&splashFreqMod);
   stream->read(&splashVelEpsilon);

   stream->read(&collDamageThresholdVel);
   stream->read(&collDamageMultiplier);
}
//----------------------------------------------------------------------------
void VehicleData::initPersistFields()
{
   addField( "jetForce", TypeF32, Offset(jetForce, VehicleData),
      "Additional force applied to the vehicle when it is jetting.\n"
      "For WheeledVehicles, the force is applied in the forward direction. For "
      "FlyingVehicles, the force is applied in the thrust direction." );
   addField( "jetEnergyDrain", TypeF32, Offset(jetEnergyDrain, VehicleData),
      "Energy amount to drain for each tick the vehicle is jetting.\nOnce the "
      "vehicle's energy level reaches 0, it will no longer be able to jet." );
   addField( "minJetEnergy", TypeF32, Offset(minJetEnergy, VehicleData),
      "Minimum vehicle energy level to begin jetting." );

   addField( "massCenter", TypePoint3F, Offset(massCenter, VehicleData),
      "Defines the vehicle's center of mass (offset from the origin of the model)." );
   addField( "massBox", TypePoint3F, Offset(massBox, VehicleData),
      "Define the box used to estimate the vehicle's moment of inertia.\n"
      "Currently only used by WheeledVehicle, other vehicle types use a "
      "unit sphere to compute inertia." );
   addField( "bodyRestitution", TypeF32, Offset(body.restitution, VehicleData),
      "Collision 'bounciness'.\nNormally in the range 0 (not bouncy at all) to "
      "1 (100% bounciness)." );
   addField( "bodyFriction", TypeF32, Offset(body.friction, VehicleData),
      "Collision friction coefficient.\nHow well this object will slide against "
      "objects it collides with." );
   addField( "softImpactSound", TYPEID< SFXProfile >(), Offset(body.sound[Body::SoftImpactSound], VehicleData),
      "Sound to play on a 'soft' impact.\nThis sound is played if the impact "
      "speed is < hardImpactSpeed and >= softImpactSpeed.\n@see softImpactSpeed" );
   addField( "hardImpactSound", TYPEID< SFXProfile >(), Offset(body.sound[Body::HardImpactSound], VehicleData),
      "Sound to play on a 'hard' impact.\nThis sound is played if the impact "
      "speed >= hardImpactSpeed.\n@see hardImpactSpeed" );

   addField( "minImpactSpeed", TypeF32, Offset(minImpactSpeed, VehicleData),
      "Minimum collision speed for the onImpact callback to be invoked." );
   addField( "softImpactSpeed", TypeF32, Offset(softImpactSpeed, VehicleData),
      "Minimum collision speed for the softImpactSound to be played." );
   addField( "hardImpactSpeed", TypeF32, Offset(hardImpactSpeed, VehicleData),
      "Minimum collision speed for the hardImpactSound to be played." );
   addField( "minRollSpeed", TypeF32, Offset(minRollSpeed, VehicleData),
      "Unused" );
   addField( "maxSteeringAngle", TypeF32, Offset(maxSteeringAngle, VehicleData),
      "Maximum yaw (horizontal) and pitch (vertical) steering angle in radians." );

   addField( "maxDrag", TypeF32, Offset(maxDrag, VehicleData),
      "Maximum drag coefficient.\nCurrently unused." );
   addField( "minDrag", TypeF32, Offset(minDrag, VehicleData),
      "Minimum drag coefficient.\nCurrently only used by FlyingVehicle." );
   addField( "integration", TypeS32, Offset(integration, VehicleData),
      "Number of integration steps per tick.\nIncrease this to improve simulation "
      "stability (also increases simulation processing time)." );
   addField( "collisionTol", TypeF32, Offset(collisionTol, VehicleData),
      "Minimum distance between objects for them to be considered as colliding." );
   addField( "contactTol", TypeF32, Offset(contactTol, VehicleData),
      "Maximum relative velocity between objects for collisions to be resolved "
      "as contacts.\nVelocities greater than this are handled as collisions." );

   addField( "cameraRoll", TypeBool, Offset(cameraRoll, VehicleData),
      "If true, the camera will roll with the vehicle. If false, the camera will "
      "always have the positive Z axis as up." );
   addField( "cameraLag", TypeF32, Offset(cameraLag, VehicleData),
      "How much the camera lags behind the vehicle depending on vehicle speed.\n "
      "Increasing this value will make the camera fall further behind the vehicle "
      "as it accelerates away.\n\n@see cameraDecay." );
   addField("cameraDecay",  TypeF32, Offset(cameraDecay, VehicleData),
      "How quickly the camera moves back towards the vehicle when stopped.\n\n"
      "@see cameraLag." );
   addField("cameraOffset", TypeF32, Offset(cameraOffset, VehicleData),
      "Vertical (Z axis) height of the camera above the vehicle." );

   addField( "dustEmitter", TYPEID< ParticleEmitterData >(), Offset(dustEmitter, VehicleData),
      "Dust particle emitter.\n\n@see triggerDustHeight\n\n@see dustHeight");
   addField( "triggerDustHeight", TypeF32, Offset(triggerDustHeight, VehicleData),
      "Maximum height above surface to emit dust particles.\nIf the vehicle is "
      "less than triggerDustHeight above a static surface with a material that "
      "has 'showDust' set to true, the vehicle will emit particles from the "
      "dustEmitter." );
   addField( "dustHeight", TypeF32, Offset(dustHeight, VehicleData),
      "Height above ground at which to emit particles from the dustEmitter." );

   addField( "damageEmitter", TYPEID< ParticleEmitterData >(), Offset(damageEmitterList, VehicleData), VC_NUM_DAMAGE_EMITTERS,
      "Array of particle emitters used to generate damage (dust, smoke etc) "
      "effects.\n\n@see damageEmitterOffset" );
   addField( "damageEmitterOffset", TypePoint3F, Offset(damageEmitterOffset, VehicleData), VC_NUM_DAMAGE_EMITTER_AREAS,
      "\"x y z\" offsets used to emit particles for each of the active damageEmitters.\n\n"
      "@tsexample\n"
      "// damage levels\n"
      "damageLevelTolerance[0] = 0.5;\n"
      "damageEmitter[0] = SmokeEmitter;\n"
      "// emit offsets (used for all active damage level emitters\n"
      "damageEmitterOffset[0] = \"0.5 3 1\";\n"
      "damageEmitterOffset[1] = \"-0.5 3 1\";\n"
      "numDmgEmitterAreas = 2;\n"
      "@endtsexample\n" );
   addField( "damageLevelTolerance", TypeF32, Offset(damageLevelTolerance, VehicleData), VC_NUM_DAMAGE_LEVELS,
      "Damage level (as a percentage of maxDamage) above which to begin "
      "emitting particles from the associated damageEmitter.\n\n"
      "@see damageEmitterOffset" );
   addField( "numDmgEmitterAreas", TypeF32, Offset(numDmgEmitterAreas, VehicleData),
      "Number of damageEmitterOffset values to use for each damageEmitter.\n\n"
      "@see damageEmitterOffset" );

   addField( "splashEmitter", TYPEID< ParticleEmitterData >(), Offset(splashEmitterList, VehicleData), VC_NUM_SPLASH_EMITTERS,
      "Array of particle emitters used to generate splash effects." );
   addField( "splashFreqMod",  TypeF32, Offset(splashFreqMod, VehicleData),
      "Number of splash particles to generate based on vehicle speed.\nThis value "
      "is multiplied by the current speed to determine how many particles to "
      "generate each frame." );
   addField( "splashVelEpsilon", TypeF32, Offset(splashVelEpsilon, VehicleData),
      "Minimum speed when moving through water to generate splash particles." );

   addField( "exitSplashSoundVelocity", TypeF32, Offset(exitSplashSoundVel, VehicleData),
      "Minimum velocity when leaving the water for the exitingWater sound to play." );
   addField( "softSplashSoundVelocity", TypeF32, Offset(softSplashSoundVel, VehicleData),
      "Minimum velocity when entering the water for the imapactWaterEasy sound "
      "to play.\n\n@see impactWaterEasy" );
   addField( "mediumSplashSoundVelocity", TypeF32, Offset(medSplashSoundVel, VehicleData),
      "Minimum velocity when entering the water for the imapactWaterMedium sound "
      "to play.\n\n@see impactWaterMedium" );
   addField( "hardSplashSoundVelocity", TypeF32, Offset(hardSplashSoundVel, VehicleData),
      "Minimum velocity when entering the water for the imapactWaterHard sound "
      "to play.\n\n@see impactWaterHard" );
   addField( "exitingWater", TYPEID< SFXProfile >(), Offset(waterSound[ExitWater], VehicleData),
      "Sound to play when exiting the water." );
   addField( "impactWaterEasy", TYPEID< SFXProfile >(), Offset(waterSound[ImpactSoft], VehicleData),
      "Sound to play when entering the water with speed >= softSplashSoundVelocity "
      "and < mediumSplashSoundVelocity." );
   addField( "impactWaterMedium", TYPEID< SFXProfile >(), Offset(waterSound[ImpactMedium], VehicleData),
      "Sound to play when entering the water with speed >= mediumSplashSoundVelocity "
      "and < hardSplashSoundVelocity." );
   addField( "impactWaterHard", TYPEID< SFXProfile >(), Offset(waterSound[ImpactHard], VehicleData),
      "Sound to play when entering the water with speed >= hardSplashSoundVelocity." );
   addField( "waterWakeSound", TYPEID< SFXProfile >(), Offset(waterSound[Wake], VehicleData),
      "Looping sound to play while moving through the water." );

   addField( "collDamageThresholdVel", TypeF32, Offset(collDamageThresholdVel, VehicleData),
      "Minimum collision velocity to cause damage to this vehicle.\nCurrently unused." );
   addField( "collDamageMultiplier", TypeF32, Offset(collDamageMultiplier, VehicleData),
      "Damage to this vehicle after a collision (multiplied by collision "
      "velocity).\nCurrently unused." );

//Mythic Debug Added -->
	addGroup("CameraControl");
		addField("freeCamPitch",		TypeBool,	Offset(freeCamPitch,			VehicleData));
		addField("minCamPitchAngle",	TypeF32,		Offset(minCamPitchAngle,	VehicleData));
		addField("maxCamPitchAngle",	TypeF32,		Offset(maxCamPitchAngle,	VehicleData));
		addField("freeCamYaw",			TypeBool,	Offset(freeCamYaw,			VehicleData));
		addField("minCamYawAngle",		TypeF32,		Offset(minCamYawAngle,		VehicleData));
		addField("maxCamYawAngle",		TypeF32,		Offset(maxCamYawAngle,		VehicleData));
		addField("maxTurnSpeed",		TypeF32,		Offset(mMaxTurnSpeed,		VehicleData));
		addField("maxPitchSpeed",		TypeF32,		Offset(mMaxPitchSpeed,		VehicleData));
		addField("maxYawSpeed",			TypeF32,		Offset(mMaxYawSpeed,			VehicleData));
	endGroup("CameraControl");

	addGroup("WeaponSystems");	//PilotNode added for Flexibility
		addField("pilotNode",		TypeS32,		Offset(mPilotNode,		VehicleData),
					"Driver Seat [Driver Node/Slot == 0 - Default]." );
		addField("numMountPoints",		TypeS32,		Offset(mNumMountPoints,		VehicleData),
					"Driver + Passengers , How many seats?" );
		addField("numWeaponPoints",	TypeS32,		Offset(mNumWeaponPoints,	VehicleData),
					"How many weapons mountpoints? [MAX 4]" );
		addField( "mountTrigger",		TypeS32,		Offset(mMountTrigger,		VehicleData), ShapeBase::MaxMountedImages,
					"Assign Trigger to MountPoint." );
	endGroup("WeaponSystems");
//Mythic Debug Added <--

   Parent::initPersistFields();
}
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
IMPLEMENT_CONOBJECT(Vehicle);
ConsoleDocClass( Vehicle,
   "@brief Base functionality shared by all Vehicles (FlyingVehicle, HoverVehicle, "
   "WheeledVehicle.\n\n"
   "This object implements functionality shared by all Vehicle types, but should "
   "not be instantiated directly. Create a FlyingVehicle, HoverVehicle, or "
   "WheeledVehicle instead.\n"
   "@note The model used for any Vehicle must include a collision mesh at detail "
   "size -1.\n"
   "@ingroup Vehicles\n"
);
Vehicle::Vehicle()
{
   mDataBlock = 0;
   mTypeMask |= VehicleObjectType | DynamicShapeObjectType;

   mDelta.pos = Point3F(0,0,0);
   mDelta.posVec = Point3F(0,0,0);
   mDelta.warpTicks = mDelta.warpCount = 0;
   mDelta.dt = 1;
   mDelta.move = NullMove;
   mPredictionCount = 0;
   mDelta.cameraOffset.set(0,0,0);
   mDelta.cameraVec.set(0,0,0);
   mDelta.cameraRot.set(0,0,0);
   mDelta.cameraRotVec.set(0,0,0);

   mRigid.linPosition.set(0, 0, 0);
   mRigid.linVelocity.set(0, 0, 0);
   mRigid.angPosition.identity();
   mRigid.angVelocity.set(0, 0, 0);
   mRigid.linMomentum.set(0, 0, 0);
   mRigid.angMomentum.set(0, 0, 0);
   mContacts.clear();

   mSteering.set(0,0);
	mSteeringLR = 0.0f;

   mThrottle = 0;
   mJetting = false;

   mCameraOffset.set(0,0,0);

//Mythic Debug Added -->
	mCameraRot = mDelta.cameraRot;
	mEngineOn = false;
//Mythic Debug Added <--

   dMemset( mDustEmitterList, 0, sizeof( mDustEmitterList ) );
   dMemset( mDamageEmitterList, 0, sizeof( mDamageEmitterList ) );
   dMemset( mSplashEmitterList, 0, sizeof( mSplashEmitterList ) );

   mDisableMove = false;
   restCount = 0;

   inLiquid = false;
   mWakeSound = NULL;

   mWorkingQueryBox.minExtents.set(-1e9f, -1e9f, -1e9f);
   mWorkingQueryBox.maxExtents.set(-1e9f, -1e9f, -1e9f);
   mWorkingQueryBoxCountDown = sWorkingQueryBoxStaleThreshold;
}
//-------------------------------------------------------------------
U32 Vehicle::getCollisionMask()
{
   AssertFatal(false, "Vehicle::getCollisionMask is pure virtual!");
   return 0;
}
Point3F Vehicle::getVelocity() const
{
   return mRigid.linVelocity;
}
//----------------------------------------------------------------------------
bool Vehicle::onAdd()
{
   if (!Parent::onAdd())
      return false;

   mWorkingQueryBox.minExtents.set(-1e9f, -1e9f, -1e9f);
   mWorkingQueryBox.maxExtents.set(-1e9f, -1e9f, -1e9f);

   // When loading from a mission script, the base SceneObject's transform
   // will have been set and needs to be transfered to the rigid body.
   mRigid.setTransform(mObjToWorld);

   // Initialize interpolation vars.
   mDelta.rot[1] = mDelta.rot[0] = mRigid.angPosition;
   mDelta.pos = mRigid.linPosition;
   mDelta.posVec = Point3F(0,0,0);

   // Create Emitters on the client
   if( isClientObject() )
   {
      if( mDataBlock->dustEmitter )
      {
         for( int i=0; i<VehicleData::VC_NUM_DUST_EMITTERS; i++ )
         {
            mDustEmitterList[i] = new ParticleEmitter;
            mDustEmitterList[i]->onNewDataBlock( mDataBlock->dustEmitter, false );
            if( !mDustEmitterList[i]->registerObject() )
            {
               Con::warnf( ConsoleLogEntry::General, "Could not register dust emitter for class: %s", mDataBlock->getName() );
               delete mDustEmitterList[i];
               mDustEmitterList[i] = NULL;
            }
         }
      }

      U32 j;
      for( j=0; j<VehicleData::VC_NUM_DAMAGE_EMITTERS; j++ )
      {
         if( mDataBlock->damageEmitterList[j] )
         {
            mDamageEmitterList[j] = new ParticleEmitter;
            mDamageEmitterList[j]->onNewDataBlock( mDataBlock->damageEmitterList[j], false );
            if( !mDamageEmitterList[j]->registerObject() )
            {
               Con::warnf( ConsoleLogEntry::General, "Could not register damage emitter for class: %s", mDataBlock->getName() );
               delete mDamageEmitterList[j];
               mDamageEmitterList[j] = NULL;
            }

         }
      }

      for( j=0; j<VehicleData::VC_NUM_SPLASH_EMITTERS; j++ )
      {
         if( mDataBlock->splashEmitterList[j] )
         {
            mSplashEmitterList[j] = new ParticleEmitter;
            mSplashEmitterList[j]->onNewDataBlock( mDataBlock->splashEmitterList[j], false );
            if( !mSplashEmitterList[j]->registerObject() )
            {
               Con::warnf( ConsoleLogEntry::General, "Could not register splash emitter for class: %s", mDataBlock->getName() );
               delete mSplashEmitterList[j];
               mSplashEmitterList[j] = NULL;
            }

         }
      }
   }

   // Create a new convex.
   AssertFatal(mDataBlock->collisionDetails[0] != -1, "Error, a vehicle must have a collision-1 detail!");
   mConvex.mObject    = this;
   mConvex.pShapeBase = this;
   mConvex.hullId     = 0;
   mConvex.box        = mObjBox;
   mConvex.box.minExtents.convolve(mObjScale);
   mConvex.box.maxExtents.convolve(mObjScale);
   mConvex.findNodeTransform();

   return true;
}
//-------------------------------------------------------------------
void Vehicle::onRemove()
{
	SFX_DELETE( mWakeSound );

   U32 i=0;
   for( i=0; i<VehicleData::VC_NUM_DUST_EMITTERS; i++ )
   {
      if( mDustEmitterList[i] )
      {
         mDustEmitterList[i]->deleteWhenEmpty();
         mDustEmitterList[i] = NULL;
      }
   }

   for( i=0; i<VehicleData::VC_NUM_DAMAGE_EMITTERS; i++ )
   {
      if( mDamageEmitterList[i] )
      {
         mDamageEmitterList[i]->deleteWhenEmpty();
         mDamageEmitterList[i] = NULL;
      }
   }

   for( i=0; i<VehicleData::VC_NUM_SPLASH_EMITTERS; i++ )
   {
      if( mSplashEmitterList[i] )
      {
         mSplashEmitterList[i]->deleteWhenEmpty();
         mSplashEmitterList[i] = NULL;
      }
   }

   mWorkingQueryBox.minExtents.set(-1e9f, -1e9f, -1e9f);
   mWorkingQueryBox.maxExtents.set(-1e9f, -1e9f, -1e9f);

   Parent::onRemove();
}
//----------------------------------------------------------------------------
void Vehicle::processTick(const Move* move)
{
   PROFILE_SCOPE( Vehicle_ProcessTick );

   Parent::processTick(move);

   // Warp to catch up to server
   if (mDelta.warpCount < mDelta.warpTicks)
   {
      mDelta.warpCount++;

      // Set new pos.
      mObjToWorld.getColumn(3,&mDelta.pos);
      mDelta.pos += mDelta.warpOffset;
      mDelta.rot[0] = mDelta.rot[1];
      mDelta.rot[1].interpolate(mDelta.warpRot[0],mDelta.warpRot[1],F32(mDelta.warpCount)/mDelta.warpTicks);
      setPosition(mDelta.pos,mDelta.rot[1]);

      // Pos backstepping
      mDelta.posVec.x = -mDelta.warpOffset.x;
      mDelta.posVec.y = -mDelta.warpOffset.y;
      mDelta.posVec.z = -mDelta.warpOffset.z;
   }
   else 
   {
      if (!move) 
      {
         if (isGhost()) 
         {
            // If we haven't run out of prediction time,
            // predict using the last known move.
            if (mPredictionCount-- <= 0)
               return;
            move = &mDelta.move;
         }
         else
            move = &NullMove;
      }

      // Process input move
      updateMove(move);

      // Save current rigid state interpolation
      mDelta.posVec = mRigid.linPosition;
      mDelta.rot[0] = mRigid.angPosition;

      // Update the physics based on the integration rate
      S32 count = mDataBlock->integration;
      --mWorkingQueryBoxCountDown;
      updateWorkingCollisionSet(getCollisionMask());
      for (U32 i = 0; i < count; i++)
         updatePos(TickSec / count);

      // Wrap up interpolation info
      mDelta.pos     = mRigid.linPosition;
      mDelta.posVec -= mRigid.linPosition;
      mDelta.rot[1]  = mRigid.angPosition;

      // Update container database
      setPosition(mRigid.linPosition, mRigid.angPosition);
      setMaskBits(PositionMask);
      updateContainer();
   }
}
//------------------------------------------------------------------------
void Vehicle::interpolateTick(F32 dt)
{
   PROFILE_SCOPE( Vehicle_InterpolateTick );

   Parent::interpolateTick(dt);

   if(dt == 0.0f)
	{
      setRenderPosition(mDelta.pos, mDelta.rot[1]);
		mCameraRot = mDelta.cameraRot;  //Mythic DEBUG <--
	}
   else
   {
		mCameraRot = mDelta.cameraRot + mDelta.cameraRotVec * dt;	//Mythic DEBUG <--

      QuatF rot;
      rot.interpolate(mDelta.rot[1], mDelta.rot[0], dt);
      Point3F pos = mDelta.pos + mDelta.posVec * dt;
      setRenderPosition(pos,rot);
   }
   mDelta.dt = dt;
}
//------------------------------------------------------------------------
void Vehicle::advanceTime(F32 dt)
{
   PROFILE_SCOPE( Vehicle_AdvanceTime );

   Parent::advanceTime(dt);

   updateLiftoffDust( dt );
   updateDamageSmoke( dt );
   updateFroth(dt);

   // Update 3rd person camera offset.  Camera update is done
   // here as it's a client side only animation.
   mCameraOffset -=
      (mCameraOffset * mDataBlock->cameraDecay +
      mRigid.linVelocity * mDataBlock->cameraLag) * dt;
}
//----------------------------------------------------------------------------
bool Vehicle::onNewDataBlock(GameBaseData* dptr,bool reload)
{
   mDataBlock = dynamic_cast<VehicleData*>(dptr);
   if (!mDataBlock || !Parent::onNewDataBlock(dptr, reload))
      return false;

   // Update Rigid Info
   mRigid.mass = mDataBlock->mass;
   mRigid.oneOverMass = 1 / mRigid.mass;
   mRigid.friction = mDataBlock->body.friction;
   mRigid.restitution = mDataBlock->body.restitution;
   mRigid.setCenterOfMass(mDataBlock->massCenter);

   // Ignores massBox, just set sphere for now. Derived objects
   // can set what they want.
   mRigid.setObjectInertia();

   if (isGhost()) 
   {
      // Create the sound ahead of time.  This reduces runtime
      // costs and makes the system easier to understand.
      SFX_DELETE( mWakeSound );

      if ( mDataBlock->waterSound[VehicleData::Wake] )
         mWakeSound = SFX->createSource( mDataBlock->waterSound[VehicleData::Wake], &getTransform() );
   }

   return true;
}
//----------------------------------------------------------------------------
void Vehicle::getCameraParameters(F32 *min,F32* max,Point3F* off,MatrixF* rot)
{
   *min = mDataBlock->cameraMinDist;
   *max = mDataBlock->cameraMaxDist;

   off->set(0,0,mDataBlock->cameraOffset);
   rot->identity();
}
//----------------------------------------------------------------------------
void Vehicle::getCameraTransform(F32* pos,MatrixF* mat)
{
   // Returns camera to world space transform
   // Handles first person / third person camera position
   if (isServerObject() && mShapeInstance)
      mShapeInstance->animateNodeSubtrees(true);

   if (*pos == 0) {
      getRenderEyeTransform(mat);
      return;
   }

   // Get the shape's camera parameters.
   F32 min,max;
   MatrixF rot;
   Point3F offset;
   getCameraParameters(&min,&max,&offset,&rot);

   // Start with the current eye position
   MatrixF eye;
   getRenderEyeTransform(&eye);

   // Build a transform that points along the eye axis
   // but where the Z axis is always up.
   if (mDataBlock->cameraRoll)
      mat->mul(eye,rot);
   else 
   {
      MatrixF cam(1);
      VectorF x,y,z(0,0,1);
      eye.getColumn(1, &y);
      mCross(y, z, &x);
      x.normalize();
      mCross(x, y, &z);
      z.normalize();
      cam.setColumn(0,x);
      cam.setColumn(1,y);
      cam.setColumn(2,z);
      mat->mul(cam,rot);
   }

   // Camera is positioned straight back along the eye's -Y axis.
   // A ray is cast to make sure the camera doesn't go through
   // anything solid.
   VectorF vp,vec;
   vp.x = vp.z = 0;
   vp.y = -(max - min) * *pos;
   eye.mulV(vp,&vec);

   // Use the camera node as the starting position if it exists.
   Point3F osp,sp;
   if (mDataBlock->cameraNode != -1) 
   {
      mShapeInstance->mNodeTransforms[mDataBlock->cameraNode].getColumn(3,&osp);
      getRenderTransform().mulP(osp,&sp);
   }
   else
      eye.getColumn(3,&sp);

   // Make sure we don't hit ourself...
   disableCollision();
   if (isMounted())
      getObjectMount()->disableCollision();

   // Cast the ray into the container database to see if we're going
   // to hit anything.
   RayInfo collision;
   Point3F ep = sp + vec + offset + mCameraOffset;
   if (mContainer->castRay(sp, ep,
         ~(WaterObjectType | GameBaseObjectType | DefaultObjectType | sTriggerMask),
         &collision) == true) {

      // Shift the collision point back a little to try and
      // avoid clipping against the front camera plane.
      F32 t = collision.t - (-mDot(vec, collision.normal) / vec.len()) * 0.1;
      if (t > 0.0f)
         ep = sp + offset + mCameraOffset + (vec * t);
      else
         eye.getColumn(3,&ep);
   }
   mat->setColumn(3,ep);

   // Re-enable our collision.
   if (isMounted())
      getObjectMount()->enableCollision();
   enableCollision();

   // Apply Camera FX.
   mat->mul( gCamFXMgr.getTrans() );
}
//----------------------------------------------------------------------------
void Vehicle::getVelocity(const Point3F& r, Point3F* v)
{
   mRigid.getVelocity(r, v);
}
void Vehicle::applyImpulse(const Point3F &pos, const Point3F &impulse)
{
   Point3F r;
   mRigid.getOriginVector(pos,&r);
   mRigid.applyImpulse(r, impulse);
}
//----------------------------------------------------------------------------
void Vehicle::updateMove(const Move* move)
{
   PROFILE_SCOPE( Vehicle_UpdateMove );

   mDelta.move = *move;

   // Mythic DEBUG -->
	//	New Weapon System
   if (mDamageState == Enabled) 
	{
		//
		//	Drivers / Passenger			 -- mNumMountPoints
		//	Number of possible weapons  -- mNumWeaponPoints
		// Trigger to Mount Assignment -- mMountTrigger[x]
		//	Defaults to [-1] to Skip it
		// Thus we can assign ANY of the [19] Triggers to Any Mount point
		//	Have to be carefull here...
		//	Anything can be mounted, so we should do a check that it is a Weapon
		//
		//	If Weapon is mounted Activate Trigger Sequence YEAH!!
		// Very Simple system, if ImageSlot[ x ]
		//	Image Mounted is Sent trigger[ mMountTrigger[x] ]
		// We also ONLY activate on a WeaponImage, So mounted Item
		//	MUST be a WeaponImage Class Type! 
		// Reduce Calls / Reduce CPU cycles / Speed up Game
		//
		// Do we have any Weapons??
		if( mDataBlock->mNumWeaponPoints > 0)
		{
			//for( S32 trigAssign=0; trigAssign<MaxTriggerKeys; trigAssign++)
			for( S32 trigAssign=0; trigAssign < mDataBlock->mNumWeaponPoints; trigAssign++)
			{
				S32 mTrigWeap = mDataBlock->mMountTrigger[trigAssign];
				//Have to deal with the HardCoded Limit of [4] Mounted Images MAX
				//Will look into wether or not we need more later
				if( mTrigWeap >= 0 && mTrigWeap < MaxTriggerKeys)
				{
					ShapeBaseImageData* tempWeapon = getMountedImage( trigAssign );
					if ( tempWeapon != NULL )
						setImageTriggerState( trigAssign, move->trigger[mTrigWeap] );
				}
			}
		}
	}
   // Mythic DEBUG <--

   // Throttle
   if(!mDisableMove)
      mThrottle = move->y;

   // Steering Mythic DEBUG -->
   if (move != &NullMove) 
	{
		//	DataBlock Control of the Turn/Rotate/Elevate speed limiters
		//	So Vehicles can behave differently
		// Have to reset mSteeringLR as move->x is only : -1 / 0 / 1
		//

		//	[ <- | -> ] steering system [keys A-S ] -->
		if( move->x != 0.0f )
		{
			F32 lr = (move->x * M_PI_F/mDataBlock->mMaxTurnSpeed); //move->x is the A/D keys!
			mSteeringLR = mClampF(mSteeringLR + lr,-mDataBlock->maxSteeringAngle, mDataBlock->maxSteeringAngle);
		}
		else
			mSteeringLR = 0.0f;
		//	[ <- | -> ] steering system [keys A-S ] <--

		//	Flying/HoverCraft steering -->
		F32 y = move->yaw;
		mSteering.x = mClampF(mSteering.x + y,-mDataBlock->maxSteeringAngle,
 							  mDataBlock->maxSteeringAngle);
      F32 p = move->pitch;
      mSteering.y = mClampF(mSteering.y + p,-mDataBlock->maxSteeringAngle,
                            mDataBlock->maxSteeringAngle);
		//	Flying/HoverCraft steering <--

		//	Camera/Vehicle Rotation/Elevation -->
		//	Pitch [Up-Down]
		mDelta.cameraRotVec = mCameraRot;
		p = (p * M_PI_F/mDataBlock->mMaxPitchSpeed);
		if (p > M_PI_F)
			p -= M_2PI_F;
		if (mDataBlock->freeCamPitch)
			mCameraRot.x = mClampF(mCameraRot.x + p, -M_PI_F, M_PI_F);
		else
			mCameraRot.x = mClampF(mCameraRot.x + p, mDataBlock->minCamPitchAngle, mDataBlock->maxCamPitchAngle); //constrain to datablock values
		//	Yaw [Left-Right]  
		y = (y * M_PI_F/mDataBlock->mMaxYawSpeed);
		if (y > M_PI_F)
			y -= M_2PI_F;
		if (mDataBlock->freeCamYaw)
			mCameraRot.z = mClampF(mCameraRot.z + y, -M_PI_F, M_PI_F);
		else
			mCameraRot.z = mClampF(mCameraRot.z + y, mDataBlock->minCamYawAngle, mDataBlock->maxCamYawAngle); //constrain to datablock values
		mDelta.cameraRot = mCameraRot;
		mDelta.cameraRotVec -= mCameraRot;   
		//	Camera/Vehicle Rotation/Elevation <--
	}
   // Steering Mythic DEBUG <--
   else 
	{
      mSteering.x = 0;
      mSteering.y = 0;
		mSteeringLR = 0.0f;
   }

   // Jetting flag
   if (move->trigger[3]) {
      if (!mJetting && getEnergyLevel() >= mDataBlock->minJetEnergy)
         mJetting = true;
      if (mJetting) {
         F32 newEnergy = getEnergyLevel() - mDataBlock->jetEnergyDrain;
         if (newEnergy < 0) {
            newEnergy = 0;
            mJetting = false;
         }
         setEnergyLevel(newEnergy);
      }
   }
   else
      mJetting = false;
}
//----------------------------------------------------------------------------
void Vehicle::setPosition(const Point3F& pos,const QuatF& rot)
{
   MatrixF mat;
   rot.setMatrix(&mat);
   mat.setColumn(3,pos);
   Parent::setTransform(mat);
}
void Vehicle::setRenderPosition(const Point3F& pos, const QuatF& rot)
{
   MatrixF mat;
   rot.setMatrix(&mat);
   mat.setColumn(3,pos);
   Parent::setRenderTransform(mat);
}
void Vehicle::setTransform(const MatrixF& newMat)
{
   mRigid.setTransform(newMat);
   Parent::setTransform(newMat);
   mRigid.atRest = false;
   mContacts.clear();
}
//-----------------------------------------------------------------------------
void Vehicle::disableCollision()
{
   Parent::disableCollision();
   for (SceneObject* ptr = getMountList(); ptr; ptr = ptr->getMountLink())
      ptr->disableCollision();
}
void Vehicle::enableCollision()
{
   Parent::enableCollision();
   for (SceneObject* ptr = getMountList(); ptr; ptr = ptr->getMountLink())
      ptr->enableCollision();
}
//----------------------------------------------------------------------------
/** Update the physics
*/
void Vehicle::updatePos(F32 dt)
{
   PROFILE_SCOPE( Vehicle_UpdatePos );

   Point3F origVelocity = mRigid.linVelocity;

   // Update internal forces acting on the body.
   mRigid.clearForces();
   updateForces(dt);

   // Update collision information based on our current pos.
   bool collided = false;
   if (!mRigid.atRest) {
      collided = updateCollision(dt);

      // Now that all the forces have been processed, lets
      // see if we're at rest.  Basically, if the kinetic energy of
      // the vehicles is less than some percentage of the energy added
      // by gravity for a short period, we're considered at rest.
      // This should really be part of the rigid class...
      if (mCollisionList.getCount()) 
      {
         F32 k = mRigid.getKineticEnergy();
         F32 G = sVehicleGravity * dt;
         F32 Kg = 0.5 * mRigid.mass * G * G;
         if (k < sRestTol * Kg && ++restCount > sRestCount)
            mRigid.setAtRest();
      }
      else
         restCount = 0;
   }

   // Integrate forward
   if (!mRigid.atRest)
      mRigid.integrate(dt);

   // Deal with client and server scripting, sounds, etc.
   if (isServerObject()) {

      // Check triggers and other objects that we normally don't
      // collide with.  This function must be called before notifyCollision
      // as it will queue collision.
      checkTriggers();

      // Invoke the onCollision notify callback for all the objects
      // we've just hit.
      notifyCollision();

      // Server side impact script callback
      if (collided) 
		{
         VectorF collVec = mRigid.linVelocity - origVelocity;
			F32 collSpeed = collVec.len();
         if (collSpeed > mDataBlock->minImpactSpeed)
            onImpact(collVec);
      }

      // Water script callbacks
      if (!inLiquid && mWaterCoverage != 0.0f) {
         mDataBlock->onEnterLiquid_callback( this, mWaterCoverage, mLiquidType.c_str() );
         inLiquid = true;
      }
      else if (inLiquid && mWaterCoverage == 0.0f) {
         mDataBlock->onLeaveLiquid_callback( this, mLiquidType.c_str() );
         inLiquid = false;
      }

   }
   else {

      // Play impact sounds on the client.
      if (collided) {
         F32 collSpeed = (mRigid.linVelocity - origVelocity).len();
         S32 impactSound = -1;
         if (collSpeed >= mDataBlock->hardImpactSpeed)
            impactSound = VehicleData::Body::HardImpactSound;
         else
            if (collSpeed >= mDataBlock->softImpactSpeed)
               impactSound = VehicleData::Body::SoftImpactSound;

         if (impactSound != -1 && mDataBlock->body.sound[impactSound] != NULL)
            SFX->playOnce( mDataBlock->body.sound[impactSound], &getTransform() );
      }

      // Water volume sounds
      F32 vSpeed = getVelocity().len();
      if (!inLiquid && mWaterCoverage >= 0.8f) {
         if (vSpeed >= mDataBlock->hardSplashSoundVel)
            SFX->playOnce( mDataBlock->waterSound[VehicleData::ImpactHard], &getTransform() );
         else
            if (vSpeed >= mDataBlock->medSplashSoundVel)
               SFX->playOnce( mDataBlock->waterSound[VehicleData::ImpactMedium], &getTransform() );
         else
            if (vSpeed >= mDataBlock->softSplashSoundVel)
               SFX->playOnce( mDataBlock->waterSound[VehicleData::ImpactSoft], &getTransform() );
         inLiquid = true;
      }
      else
         if(inLiquid && mWaterCoverage < 0.8f) {
            if (vSpeed >= mDataBlock->exitSplashSoundVel)
               SFX->playOnce( mDataBlock->waterSound[VehicleData::ExitWater], &getTransform() );
         inLiquid = false;
      }
   }
}
//----------------------------------------------------------------------------
void Vehicle::updateForces(F32 /*dt*/)
{
   // Nothing here.
}
//-----------------------------------------------------------------------------
/** Update collision information
   Update the convex state and check for collisions. If the object is in
   collision, impact and contact forces are generated.
*/
bool Vehicle::updateCollision(F32 dt)
{
   PROFILE_SCOPE( Vehicle_UpdateCollision );

   // Update collision information
   MatrixF mat,cmat;
   mConvex.transform = &mat;
   mRigid.getTransform(&mat);
   cmat = mConvex.getTransform();

   mCollisionList.clear();
   CollisionState *state = mConvex.findClosestState(cmat, getScale(), mDataBlock->collisionTol);
   if (state && state->dist <= mDataBlock->collisionTol) 
   {
      //resolveDisplacement(ns,state,dt);
      mConvex.getCollisionInfo(cmat, getScale(), &mCollisionList, mDataBlock->collisionTol);
   }

   // Resolve collisions
   bool collided = resolveCollision(mRigid,mCollisionList);
   resolveContacts(mRigid,mCollisionList,dt);
   return collided;
}
//----------------------------------------------------------------------------
/** Resolve collision impacts
   Handle collision impacts, as opposed to contacts. Impulses are calculated based
   on standard collision resolution formulas.
*/
// Add collisions vs. Vehicles & Players
bool Vehicle::resolveCollision(Rigid& ns,CollisionList& cList)
{
   PROFILE_SCOPE( Vehicle_ResolveCollision );

	// Apply impulses to resolve collision
   bool collided = false;
   bool colliding = false;
   bool tmpColliding = false;
   S32 counter = 0;
   do
   {
      colliding = false;
      for (S32 i = 0; i < cList.getCount(); i++) 
      {
         Collision& c = cList[i];
         if (c.object->getId() == getId()) //Self Collision
            continue;

			if (c.distance < mDataBlock->collisionTol) 
         {
            // Skip the normal stuff for vehicles
            if (c.object->getTypeMask() & VehicleObjectType)
            {
               Vehicle *tmpShape = (Vehicle*)c.object;
               tmpColliding = ns.resolveCollision(cList[i].point, cList[i].normal,
                  &tmpShape->mRigid);//, c.distance);
               if (tmpColliding)
                  collided = colliding = true;

               // Keep track of objects we collide with
               if (!isGhost()) 
               {
                  Point3F v,r;
                  ns.getOriginVector(c.point,&r);
                  ns.getVelocity(r,&v);
                  queueCollision(tmpShape,v - tmpShape->getVelocity());
               }
            }
            else if (c.object->getTypeMask() & PlayerObjectType)
            {
               if (c.distance >= 0.0f)
               {
                  ShapeBase *tmpShape = (ShapeBase*)c.object;
                  Point3F tmpImpulse(0.0f, 0.0f, 0.0f);
                  Rigid tmpRigid;
                  tmpRigid.mass = ((ShapeBaseData*)tmpShape->getDataBlock())->mass;
                  tmpRigid.oneOverMass = 1.0f / tmpRigid.mass;
                  tmpRigid.centerOfMass = tmpShape->getBoxCenter() - tmpShape->getPosition();
                  tmpRigid.worldCenterOfMass = tmpShape->getBoxCenter();
                  tmpRigid.setTransform(tmpShape->getTransform());
                  tmpRigid.linVelocity = tmpShape->getVelocity();
                  tmpRigid.linMomentum = tmpShape->getMomentum();
                  tmpRigid.restitution = 0.5;
                  tmpRigid.linPosition = tmpShape->getPosition();
                  tmpRigid.setObjectInertia();
                  
                  tmpColliding = ns.resolveCollision(cList[i].point, cList[i].normal,
                     &tmpRigid, tmpImpulse);//, c.distance);
                  tmpShape->applyImpulse(tmpRigid.linPosition, tmpImpulse);
                  if (tmpColliding)
                     collided = colliding = true;
                  
                  //Con::printf("It's a %lf %lf %lf mass %lf Pos %lf %lf %lf", tmpImpulse.x, tmpImpulse.y, tmpImpulse.z, tmpRigid.mass, tmpShape->getBoxCenter().x, tmpShape->getBoxCenter().y, tmpShape->getBoxCenter().z);
               }
            }
            else
            {
               // Velocity into surface
               Point3F v,r;
               ns.getOriginVector(c.point,&r);
               ns.getVelocity(r,&v);
               F32 vn = mDot(v,c.normal);

               // Only interested in velocities greater than sContactTol,
               // velocities less than that will be dealt with as contacts
               // "constraints".
               if (vn < -mDataBlock->contactTol) 
               {
                  // Apply impulses to the rigid body to keep it from
                  // penetrating the surface.
                  ns.resolveCollision(cList[i].point,
                     cList[i].normal);
                  collided = colliding = true;

                  // Keep track of objects we collide with
                  if (!isGhost() && c.object->getTypeMask() & ShapeBaseObjectType) 
                  {
                     ShapeBase* col = static_cast<ShapeBase*>(c.object);
                     queueCollision(col,v - col->getVelocity());
                  }
               }
            }
         }
      }
      counter++;
   } while (colliding && counter < 10);
   //if (counter > 1)
      //Con::printf("--------solved collision in %d loops", counter);

   return collided;
}
//----------------------------------------------------------------------------
/** Resolve contact forces
   Resolve contact forces using the "penalty" method. Forces are generated based
   on the depth of penetration and the moment of inertia at the point of contact.
*/
bool Vehicle::resolveContacts(Rigid& ns,CollisionList& cList,F32 dt)
{
   PROFILE_SCOPE( Vehicle_ResolveContacts );

   // Use spring forces to manage contact constraints.
   bool collided = false;
   Point3F t,p(0,0,0),l(0,0,0);
   for (S32 i = 0; i < cList.getCount(); i++) 
   {
      const Collision& c = cList[i];
      if (c.distance < mDataBlock->collisionTol) 
      {

         // Velocity into the surface
         Point3F v,r;
         ns.getOriginVector(c.point,&r);
         ns.getVelocity(r,&v);
         F32 vn = mDot(v,c.normal);

         // Only interested in velocities less than mDataBlock->contactTol,
         // velocities greater than that are dealt with as collisions.
         if (mFabs(vn) < mDataBlock->contactTol) 
         {
            collided = true;

            // Penetration force. This is actually a spring which
            // will seperate the body from the collision surface.
            F32 zi = 2 * mFabs(mRigid.getZeroImpulse(r,c.normal));
            F32 s = (mDataBlock->collisionTol - c.distance) * zi - ((vn / mDataBlock->contactTol) * zi);
            Point3F f = c.normal * s;

            // Friction impulse, calculated as a function of the
            // amount of force it would take to stop the motion
            // perpendicular to the normal.
            Point3F uv = v - (c.normal * vn);
            F32 ul = uv.len();
            if (s > 0 && ul) 
            {
               uv /= -ul;
               F32 u = ul * ns.getZeroImpulse(r,uv);
               s *= mRigid.friction;
               if (u > s)
                  u = s;
               f += uv * u;
            }

            // Accumulate forces
            p += f;
            mCross(r,f,&t);
            l += t;
         }
      }
   }

   // Contact constraint forces act over time...
   ns.linMomentum += p * dt;
   ns.angMomentum += l * dt;
   ns.updateVelocity();
   return true;
}
//----------------------------------------------------------------------------
bool Vehicle::resolveDisplacement(Rigid& ns,CollisionState *state, F32 dt)
{
   PROFILE_SCOPE( Vehicle_ResolveDisplacement );

   SceneObject* obj = (state->a->getObject() == this)?
       state->b->getObject(): state->a->getObject();

   if (obj->isDisplacable() && ((obj->getTypeMask() & ShapeBaseObjectType) != 0))
   {
      // Try to displace the object by the amount we're trying to move
      Point3F objNewMom = ns.linVelocity * obj->getMass() * 1.1f;
      Point3F objOldMom = obj->getMomentum();
      Point3F objNewVel = objNewMom / obj->getMass();

      Point3F myCenter;
      Point3F theirCenter;
      getWorldBox().getCenter(&myCenter);
      obj->getWorldBox().getCenter(&theirCenter);
      if (mDot(myCenter - theirCenter, objNewMom) >= 0.0f || objNewVel.len() < 0.01)
      {
         objNewMom = (theirCenter - myCenter);
         objNewMom.normalize();
         objNewMom *= 1.0f * obj->getMass();
         objNewVel = objNewMom / obj->getMass();
      }

      obj->setMomentum(objNewMom);
      if (obj->displaceObject(objNewVel * 1.1f * dt) == true)
      {
         // Queue collision and change in velocity
         VectorF dv = (objOldMom - objNewMom) / obj->getMass();
         queueCollision(static_cast<ShapeBase*>(obj), dv);
         return true;
      }
   }

   return false;
}
//----------------------------------------------------------------------------
void Vehicle::updateWorkingCollisionSet(const U32 mask)
{
   PROFILE_SCOPE( Vehicle_UpdateWorkingCollisionSet );

   // First, we need to adjust our velocity for possible acceleration.  It is assumed
   // that we will never accelerate more than 20 m/s for gravity, plus 30 m/s for
   // jetting, and an equivalent 10 m/s for vehicle accel.  We also assume that our
   // working list is updated on a Tick basis, which means we only expand our box by
   // the possible movement in that tick, plus some extra for caching purposes
   Box3F convexBox = mConvex.getBoundingBox(getTransform(), getScale());
   F32 len = (mRigid.linVelocity.len() + 50) * TickSec;
   F32 l = (len * 1.1) + 0.1;  // fudge factor
   convexBox.minExtents -= Point3F(l, l, l);
   convexBox.maxExtents += Point3F(l, l, l);

   // Check to see if it is actually necessary to construct the new working list,
   // or if we can use the cached version from the last query.  We use the x
   // component of the min member of the mWorkingQueryBox, which is lame, but
   // it works ok.
   bool updateSet = false;

   // Check containment
   if ((sWorkingQueryBoxStaleThreshold == -1 || mWorkingQueryBoxCountDown > 0) && mWorkingQueryBox.minExtents.x != -1e9f)
   {
      if (mWorkingQueryBox.isContained(convexBox) == false)
         // Needed region is outside the cached region.  Update it.
         updateSet = true;
   }
   else
   {
      // Must update
      updateSet = true;
   }

   // Actually perform the query, if necessary
   if (updateSet == true)
   {
      mWorkingQueryBoxCountDown = sWorkingQueryBoxStaleThreshold;

      const Point3F  lPoint( sWorkingQueryBoxSizeMultiplier * l );
      mWorkingQueryBox = convexBox;
      mWorkingQueryBox.minExtents -= lPoint;
      mWorkingQueryBox.maxExtents += lPoint;

      disableCollision();
      mConvex.updateWorkingList(mWorkingQueryBox, mask);
      enableCollision();
   }
}
//----------------------------------------------------------------------------
/** Check collisions with trigger and items
   Perform a container search using the current bounding box
   of the main body, wheels are not included.  This method should
   only be called on the server.
*/
void Vehicle::checkTriggers()
{
   Box3F bbox = mConvex.getBoundingBox(getTransform(), getScale());
   gServerContainer.findObjects(bbox,sTriggerMask,findCallback,this);
}
/** The callback used in by the checkTriggers() method.
   The checkTriggers method uses a container search which will
   invoke this callback on each obj that matches.
*/
void Vehicle::findCallback(SceneObject* obj,void *key)
{
   Vehicle* vehicle = reinterpret_cast<Vehicle*>(key);
   U32 objectMask = obj->getTypeMask();

   // Check: triggers, corpses and items, basically the same things
   // that the player class checks for
   if (objectMask & TriggerObjectType) {
      Trigger* pTrigger = static_cast<Trigger*>(obj);
      pTrigger->potentialEnterObject(vehicle);
   }
   else if (objectMask & CorpseObjectType) {
      ShapeBase* col = static_cast<ShapeBase*>(obj);
      vehicle->queueCollision(col,vehicle->getVelocity() - col->getVelocity());
   }
   else if (objectMask & ItemObjectType) {
      Item* item = static_cast<Item*>(obj);
      if (vehicle != item->getCollisionObject())
         vehicle->queueCollision(item,vehicle->getVelocity() - item->getVelocity());
   }
}
//----------------------------------------------------------------------------
void Vehicle::writePacketData(GameConnection *connection, BitStream *stream)
{
   Parent::writePacketData(connection, stream);
   mathWrite(*stream, mSteering);

   mathWrite(*stream, mRigid.linPosition);
   mathWrite(*stream, mRigid.angPosition);
   mathWrite(*stream, mRigid.linMomentum);
   mathWrite(*stream, mRigid.angMomentum);
   stream->writeFlag(mRigid.atRest);
   stream->writeFlag(mContacts.getCount() == 0);

   stream->writeFlag(mDisableMove);
   stream->setCompressionPoint(mRigid.linPosition);

	//Mythic DEBUG -->
	stream->write(mSteeringLR);  
	stream->write(mCameraRot.x);  
	stream->write(mCameraRot.z);
	//Mythic DEBUG <--
}
//-------------------------------
void Vehicle::readPacketData(GameConnection *connection, BitStream *stream)
{
   Parent::readPacketData(connection, stream);
   mathRead(*stream, &mSteering);

   mathRead(*stream, &mRigid.linPosition);
   mathRead(*stream, &mRigid.angPosition);
   mathRead(*stream, &mRigid.linMomentum);
   mathRead(*stream, &mRigid.angMomentum);
   mRigid.atRest = stream->readFlag();
   if (stream->readFlag())
      mContacts.clear();
   mRigid.updateInertialTensor();
   mRigid.updateVelocity();
   mRigid.updateCenterOfMass();

   mDisableMove = stream->readFlag();
   stream->setCompressionPoint(mRigid.linPosition);

	//Mythic DEBUG -->
	stream->read(&mSteeringLR);  
	stream->read(&mCameraRot.x);  
	stream->read(&mCameraRot.z);  
	mDelta.cameraRot = mCameraRot; 
	//Mythic DEBUG <--
}
//----------------------------------------------------------------------------
U32 Vehicle::packUpdate(NetConnection *con, U32 mask, BitStream *stream)
{
   U32 retMask = Parent::packUpdate(con, mask, stream);

   stream->writeFlag(mJetting);
	stream->writeFlag(mEngineOn);

   // The rest of the data is part of the control object packet update.
   // If we're controlled by this client, we don't need to send it.
   if (stream->writeFlag(getControllingClient() == con && !(mask & InitialUpdateMask)))
      return retMask;

   F32 lrMove = (	mSteeringLR + mDataBlock->maxSteeringAngle) / (2 * mDataBlock->maxSteeringAngle);
	F32 yaw = (mSteering.x + mDataBlock->maxSteeringAngle) / (2 * mDataBlock->maxSteeringAngle);
   F32 pitch = (mSteering.y + mDataBlock->maxSteeringAngle) / (2 * mDataBlock->maxSteeringAngle);
   stream->writeFloat(lrMove,9);
   stream->writeFloat(yaw,9);
   stream->writeFloat(pitch,9);
   mDelta.move.pack(stream);

   if (stream->writeFlag(mask & PositionMask))
   {
		//Mythic DEBUG -->
		stream->writeSignedFloat(mCameraRot.x/ 3.0, 6);
		stream->writeSignedFloat(mCameraRot.z/ 3.0, 6);
		//Mythic DEBUG <--

      stream->writeCompressedPoint(mRigid.linPosition);
      mathWrite(*stream, mRigid.angPosition);
      mathWrite(*stream, mRigid.linMomentum);
      mathWrite(*stream, mRigid.angMomentum);
      stream->writeFlag(mRigid.atRest);
   }
   stream->writeFloat(mClampF(getEnergyValue(), 0.f, 1.f), 8);
   return retMask;
}
//-----------------------------------
void Vehicle::unpackUpdate(NetConnection *con, BitStream *stream)
{
   Parent::unpackUpdate(con,stream);

   mJetting = stream->readFlag();
	mEngineOn = stream->readFlag();

   if (stream->readFlag())
      return;

   F32 lrMove = stream->readFloat(9);
   F32 yaw = stream->readFloat(9);
   F32 pitch = stream->readFloat(9);
   mSteeringLR = (2 * lrMove * mDataBlock->maxSteeringAngle) - mDataBlock->maxSteeringAngle;
   mSteering.x = (2 * yaw * mDataBlock->maxSteeringAngle) - mDataBlock->maxSteeringAngle;
   mSteering.y = (2 * pitch * mDataBlock->maxSteeringAngle) - mDataBlock->maxSteeringAngle;
   mDelta.move.unpack(stream);

   if (stream->readFlag()) 
   {
		//Mythic DEBUG -->
		mCameraRot.x = stream->readSignedFloat(6) * 3.0;
		mCameraRot.z = stream->readSignedFloat(6) * 3.0;
		//Mythic DEBUG <--

      mPredictionCount = sMaxPredictionTicks;
      F32 speed = mRigid.linVelocity.len();
      mDelta.warpRot[0] = mRigid.angPosition;

      // Read in new position and momentum values
      stream->readCompressedPoint(&mRigid.linPosition);
      mathRead(*stream, &mRigid.angPosition);
      mathRead(*stream, &mRigid.linMomentum);
      mathRead(*stream, &mRigid.angMomentum);
      mRigid.atRest = stream->readFlag();
      mRigid.updateVelocity();

      if (isProperlyAdded()) 
      {
         // Determine number of ticks to warp based on the average
         // of the client and server velocities.
         Point3F cp = mDelta.pos + mDelta.posVec * mDelta.dt;
         mDelta.warpOffset = mRigid.linPosition - cp;

         // Calc the distance covered in one tick as the average of
         // the old speed and the new speed from the server.
         F32 dt,as = (speed + mRigid.linVelocity.len()) * 0.5 * TickSec;

         // Cal how many ticks it will take to cover the warp offset.
         // If it's less than what's left in the current tick, we'll just
         // warp in the remaining time.
         if (!as || (dt = mDelta.warpOffset.len() / as) > sMaxWarpTicks)
            dt = mDelta.dt + sMaxWarpTicks;
         else
            dt = (dt <= mDelta.dt)? mDelta.dt : mCeil(dt - mDelta.dt) + mDelta.dt;

         // Adjust current frame interpolation
         if (mDelta.dt) {
            mDelta.pos = cp + (mDelta.warpOffset * (mDelta.dt / dt));
            mDelta.posVec = (cp - mDelta.pos) / mDelta.dt;
            QuatF cr;
            cr.interpolate(mDelta.rot[1],mDelta.rot[0],mDelta.dt);
            mDelta.rot[1].interpolate(cr,mRigid.angPosition,mDelta.dt / dt);
            mDelta.rot[0].extrapolate(mDelta.rot[1],cr,mDelta.dt);
         }

         // Calculated multi-tick warp
         mDelta.warpCount = 0;
         mDelta.warpTicks = (S32)(mFloor(dt));
         if (mDelta.warpTicks) 
         {
            mDelta.warpOffset = mRigid.linPosition - mDelta.pos;
            mDelta.warpOffset /= (F32)mDelta.warpTicks;
            mDelta.warpRot[0] = mDelta.rot[1];
            mDelta.warpRot[1] = mRigid.angPosition;
         }
      }
      else 
      {
         // Set the vehicle to the server position
         mDelta.dt  = 0;
         mDelta.pos = mRigid.linPosition;
         mDelta.posVec.set(0,0,0);
         mDelta.rot[1] = mDelta.rot[0] = mRigid.angPosition;
         mDelta.warpCount = mDelta.warpTicks = 0;
         setPosition(mRigid.linPosition, mRigid.angPosition);
      }
      mRigid.updateCenterOfMass();
   }

   setEnergyLevel(stream->readFloat(8) * mDataBlock->maxEnergy);
}
//----------------------------------------------------------------------------
//	Mythic Debug Additional Functionality added to Basic Vehicles
//----------------------------------------------------------------------------
void Vehicle::getRenderEyeTransform(MatrixF* mat)
{
   // Eye transform in world space.  We only use the eye position
   // from the Shape and supply our own rotation.
   MatrixF pmat,xmat,zmat;
	xmat.set(EulerF(mCameraRot.x, 0.0f, 0.0f));
	zmat.set(EulerF(0.0f, 0.0f, mCameraRot.z));
   pmat.mul(zmat,xmat);

   F32 *dp = pmat;
   F32* sp;
   if (mDataBlock->eyeNode != -1)
   {
      sp = mShapeInstance->mNodeTransforms[mDataBlock->eyeNode];
   }
   else
   {
      Point3F center;
      mObjBox.getCenter(&center);
      MatrixF eyeMat(true);
      eyeMat.setPosition(center);

      sp = eyeMat;
   }

   const Point3F& scale = getScale();
   dp[3] = sp[3] * scale.x;
   dp[7] = sp[7] * scale.y;
   dp[11] = sp[11] * scale.z;
   mat->mul(getRenderTransform(), pmat);
}
//----------------------------------------------------------------------------


//----------------------------------------------------------------------------
//	Mythic DEBUG Additional Console Methods
//----------------------------------------------------------------------------
DefineEngineMethod( Vehicle, setEngineOn, void, (bool state), ( false ),
   "Turns Engine Sounds on/off.\n" )
{
   object->setEngineOn( state );
}
//----------------------------------------------------------------------------
void Vehicle::consoleInit()
{
   Con::addVariable("$vehicle::workingQueryBoxStaleThreshold",TypeS32,&sWorkingQueryBoxStaleThreshold, 
      "@brief The maximum number of ticks that go by before the mWorkingQueryBox is considered stale and needs updating.\n\n"
      "Other factors can cause the collision working query box to become invalidated, such as the vehicle moving far "
      "enough outside of this cached box.  The smaller this number, the more times the working list of triangles that are "
      "considered for collision is refreshed.  This has the greatest impact with colliding with high triangle count meshes.\n\n"
      "@note Set to -1 to disable any time-based forced check.\n\n"
	   "@ingroup GameObjects\n");

   Con::addVariable("$vehicle::workingQueryBoxSizeMultiplier",TypeF32,&sWorkingQueryBoxSizeMultiplier, 
      "@brief How much larger should the mWorkingQueryBox be made when updating the working collision list.\n\n"
      "The larger this number the less often the working list will be updated due to motion, but any non-static shape that "
      "moves into the query box will not be noticed.\n\n"
	   "@ingroup GameObjects\n");
}
void Vehicle::initPersistFields()
{
   addField( "disableMove", TypeBool, Offset(mDisableMove, Vehicle),
      "When this flag is set, the vehicle will ignore throttle changes." );

   Parent::initPersistFields();
}
//----------------------------------------------------------------------------
void Vehicle::mountObject(SceneObject *obj, S32 node, const MatrixF &xfm )
{
   Parent::mountObject( obj, node, xfm );

   // Clear objects off the working list that are from objects mounted to us.
   //  (This applies mostly to players...)
   for ( CollisionWorkingList* itr = mConvex.getWorkingList().wLink.mNext; 
         itr != &mConvex.getWorkingList(); 
         itr = itr->wLink.mNext) 
   {
      if (itr->mConvex->getObject() == obj) 
      {
         CollisionWorkingList* cl = itr;
         itr = itr->wLink.mPrev;
         cl->free();
      }
   }
}
//----------------------------------------------------------------------------
void Vehicle::updateLiftoffDust( F32 dt )
{
   Point3F offset( 0.0, 0.0, mDataBlock->dustHeight );
   emitDust( mDustEmitterList[ 0 ], mDataBlock->triggerDustHeight, offset,
             ( U32 )( dt * 1000 ) );
}
//----------------------------------------------------------------------------
void Vehicle::updateDamageSmoke( F32 dt )
{

   for( S32 j=VehicleData::VC_NUM_DAMAGE_LEVELS-1; j>=0; j-- )
   {
      F32 damagePercent = mDamage / mDataBlock->maxDamage;
      if( damagePercent >= mDataBlock->damageLevelTolerance[j] )
      {
         for( int i=0; i<mDataBlock->numDmgEmitterAreas; i++ )
         {
            MatrixF trans = getTransform();
            Point3F offset = mDataBlock->damageEmitterOffset[i];
            trans.mulP( offset );
            Point3F emitterPoint = offset;

            if( pointInWater(offset ) )
            {
               U32 emitterOffset = VehicleData::VC_BUBBLE_EMITTER;
               if( mDamageEmitterList[emitterOffset] )
               {
                  mDamageEmitterList[emitterOffset]->emitParticles( emitterPoint, emitterPoint, Point3F( 0.0, 0.0, 1.0 ), getVelocity(), (U32)( dt * 1000 ) );
               }
            }
            else
            {
               if( mDamageEmitterList[j] )
               {
                  mDamageEmitterList[j]->emitParticles( emitterPoint, emitterPoint, Point3F( 0.0, 0.0, 1.0 ), getVelocity(), (U32)(dt * 1000));
               }
            }
         }
         break;
      }
   }

}
//--------------------------------------------------------------------------
void Vehicle::updateFroth( F32 dt )
{
   // update bubbles
   Point3F moveDir = getVelocity();

   Point3F contactPoint;
   if( !collidingWithWater( contactPoint ) )
   {
      if ( mWakeSound )
         mWakeSound->stop();
      return;
   }

   F32 speed = moveDir.len();
   if( speed < mDataBlock->splashVelEpsilon ) speed = 0.0;

   U32 emitRate = (U32)(speed * mDataBlock->splashFreqMod * dt);

   U32 i;

   if ( mWakeSound )
   {
      if ( !mWakeSound->isPlaying() )
         mWakeSound->play();

      mWakeSound->setTransform( getTransform() );
      mWakeSound->setVelocity( getVelocity() );
   }

   for( i=0; i<VehicleData::VC_NUM_SPLASH_EMITTERS; i++ )
   {
      if( mSplashEmitterList[i] )
      {
         mSplashEmitterList[i]->emitParticles( contactPoint, contactPoint, Point3F( 0.0, 0.0, 1.0 ),
                                               moveDir, emitRate );
      }
   }

}
//--------------------------------------------------------------------------
// Returns true if vehicle is intersecting a water surface (roughly)
//--------------------------------------------------------------------------
bool Vehicle::collidingWithWater( Point3F &waterHeight )
{
   Point3F curPos = getPosition();

   F32 height = mFabs( mObjBox.maxExtents.z - mObjBox.minExtents.z );

   RayInfo rInfo;
   if( gClientContainer.castRay( curPos + Point3F(0.0, 0.0, height), curPos, WaterObjectType, &rInfo) )
   {
      waterHeight = rInfo.point;
      return true;
   }

   return false;
}
//----------------------------------------------------------------------------
void Vehicle::setEnergyLevel(F32 energy)
{
   Parent::setEnergyLevel(energy);
   setMaskBits(EnergyMask);
}
//----------------------------------------------------------------------------
void Vehicle::prepBatchRender( SceneRenderState *state, S32 mountedImageIndex )
{
   Parent::prepBatchRender( state, mountedImageIndex );

   if ( !gShowBoundingBox )
      return;

   if ( mountedImageIndex != -1 )
   {
      ObjectRenderInst *ri = state->getRenderPass()->allocInst<ObjectRenderInst>();
      ri->renderDelegate.bind( this, &Vehicle::_renderMuzzleVector );
      ri->objectIndex = mountedImageIndex;
      ri->type = RenderPassManager::RIT_Editor;
      state->getRenderPass()->addInst( ri );
      return;
   }

   ObjectRenderInst *ri = state->getRenderPass()->allocInst<ObjectRenderInst>();
   ri->renderDelegate.bind( this, &Vehicle::_renderMassAndContacts );
   ri->type = RenderPassManager::RIT_Editor;
   state->getRenderPass()->addInst( ri );
}
//----------------------------------------------------------------------------
void Vehicle::_renderMassAndContacts( ObjectRenderInst *ri, SceneRenderState *state, BaseMatInstance *overrideMat )
{
   GFXStateBlockDesc desc;
   desc.setBlend(false, GFXBlendSrcAlpha, GFXBlendInvSrcAlpha);
   desc.setZReadWrite(false,true);
   desc.fillMode = GFXFillWireframe;

   // Render the mass center.   
   GFX->getDrawUtil()->drawCube(desc, Point3F(0.1f,0.1f,0.1f),mDataBlock->massCenter, ColorI(255, 255, 255), &mRenderObjToWorld);

   // Now render all the contact points.
   for (int i = 0; i < mCollisionList.getCount(); i++)
   {
      const Collision& collision = mCollisionList[i];
      GFX->getDrawUtil()->drawCube(desc, Point3F(0.05f,0.05f,0.05f),collision.point, ColorI(0, 0, 255));
   }

   // Finally render the normals as one big batch.
   PrimBuild::begin(GFXLineList, mCollisionList.getCount() * 2);
   for (int i = 0; i < mCollisionList.getCount(); i++)
   {
      const Collision& collision = mCollisionList[i];
      PrimBuild::color3f(1, 1, 1);
      PrimBuild::vertex3fv(collision.point);
      PrimBuild::vertex3fv(collision.point + collision.normal * 0.05f);
   }
   PrimBuild::end();

   // Build and render the collision polylist which is returned
   // in the server's world space.
   ClippedPolyList polyList;
   polyList.mPlaneList.setSize(6);
   polyList.mPlaneList[0].set(getWorldBox().minExtents,VectorF(-1,0,0));
   polyList.mPlaneList[1].set(getWorldBox().minExtents,VectorF(0,-1,0));
   polyList.mPlaneList[2].set(getWorldBox().minExtents,VectorF(0,0,-1));
   polyList.mPlaneList[3].set(getWorldBox().maxExtents,VectorF(1,0,0));
   polyList.mPlaneList[4].set(getWorldBox().maxExtents,VectorF(0,1,0));
   polyList.mPlaneList[5].set(getWorldBox().maxExtents,VectorF(0,0,1));
   Box3F dummyBox;
   SphereF dummySphere;
   buildPolyList(PLC_Collision, &polyList, dummyBox, dummySphere);
   //polyList.render();
}
//----------------------------------------------------------------------------
void Vehicle::_renderMuzzleVector( ObjectRenderInst *ri, SceneRenderState *state, BaseMatInstance *overrideMat )
{
   const U32 index = ri->objectIndex;

   AssertFatal( index > 0 && index < MaxMountedImages, "Vehicle::_renderMuzzleVector() - Bad object index!" );
   AssertFatal( mMountedImageList[index].dataBlock, "Vehicle::_renderMuzzleVector() - Bad object index!" );

	Point3F muzzlePoint, muzzleVector, endpoint;
	getMuzzlePoint(index, &muzzlePoint);
	getMuzzleVector(index, &muzzleVector);
	endpoint = muzzlePoint + muzzleVector * 250;

   if (mSolidSB.isNull())
   {
      GFXStateBlockDesc desc;
      desc.setBlend(false, GFXBlendSrcAlpha, GFXBlendInvSrcAlpha);
      desc.setZReadWrite(false);
      mSolidSB = GFX->createStateBlock(desc);
   }

   GFX->setStateBlock(mSolidSB);

   PrimBuild::begin(GFXLineList, 2);

   PrimBuild::color4f(0, 1, 0, 1);
   PrimBuild::vertex3fv(muzzlePoint);
	PrimBuild::vertex3fv(endpoint);

   PrimBuild::end();
}
//----------------------------------------------------------------------------
