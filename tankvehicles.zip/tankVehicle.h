//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

#ifndef _TANKVEHICLE_H_
#define _TANKVEHICLE_H_

#ifndef _VEHICLE_H_
#include "T3D/vehicles/vehicle.h"
#endif

#ifndef _CLIPPEDPOLYLIST_H_
#include "collision/clippedPolyList.h"
#endif

class ParticleEmitter;
class ParticleEmitterData;

//----------------------------------------------------------------------------
struct TankVehicleTire: public SimDataBlock 
{
   typedef SimDataBlock Parent;

   //
   StringTableEntry shapeName;// Max shape to render

   // Physical properties
   F32 mass;                  // Mass of the whole wheel
   F32 kineticFriction;       // Tire friction coefficient
   F32 staticFriction;        // Tire friction coefficient
   F32 restitution;           // Currently not used

   // Tires act as springs and generate lateral and longitudinal
   // forces to move the vehicle. These distortion/spring forces
   // are what convert wheel angular velocity into forces that
   // act on the rigid body.
   F32 lateralForce;          // Spring force
   F32 lateralDamping;        // Damping force
   F32 lateralRelaxation;     // The tire will relax if left alone
   F32 longitudinalForce;
   F32 longitudinalDamping;
   F32 longitudinalRelaxation;
   // Shape information initialized in the preload
   Resource<TSShape> shape;   // The loaded shape
   F32 radius;                // Tire radius
   //
   TankVehicleTire();
   DECLARE_CONOBJECT(TankVehicleTire);
   static void initPersistFields();
   bool preload(bool, String &errorStr);
   virtual void packData(BitStream* stream);
   virtual void unpackData(BitStream* stream);
};
//----------------------------------------------------------------------------
struct TankVehicleSpring: public SimDataBlock 
{
   typedef SimDataBlock Parent;

   F32 length;                // Travel distance from root hub position
   F32 force;                 // Spring force
   F32 damping;               // Damping force
   F32 antiSway;              // Opposite wheel anti-sway
   //
   TankVehicleSpring();
   DECLARE_CONOBJECT(TankVehicleSpring);
   static void initPersistFields();
   virtual void packData(BitStream* stream);
   virtual void unpackData(BitStream* stream);
};
//----------------------------------------------------------------------------
struct TankVehicleData: public VehicleData 
{
   typedef VehicleData Parent;

   enum Constants 
   {
      MaxTankWheels = 20,
      MaxWheelBits = 3
   };

   enum { 
      hMaxDestructSequences = 4, 
      // NOTE: dependency here and tankShape.cc where TankShapeData::preload() defines array leftSideNames[] etc...
      hMaxInnerWheelsPerSide = 9,
      hMaxInnerWheels=hMaxInnerWheelsPerSide*2,
      hMaxWheels=hMaxInnerWheels+4
	};

   F32 maxStepHeight;

   enum TankSounds 
   {
      EngineSoundA,
      EngineSoundB,
      WheelImpactSound,
      MaxTankSounds,
   };
   SFXTrack* tankSound[MaxTankSounds];

	ParticleEmitterData* tireEmitter;

	S32 mInnerWheelsPerSide;
   F32 maxWheelSpeed;            // Engine torque is scale based on wheel speed
   F32 engineTorque;             // Engine force controlled through throttle
   F32 engineBrake;              // Break force applied when throttle is 0
   F32 brakeTorque;              // Force used when brakeing

	//	Turret Controls
   S32 mTurretNode;					// Rotation Node
   S32 mWeaponNode;					//	Elevation Node
   S32 mMuzzleNode;					//	Firing Node
   S32 mSuspensionNode;				//	Recoil Node
	//	Suspension System
   F32 mSuspensionRange;   // proportion of wheel size for wheel to move up/down
   F32 mSpringRangeX;
   F32 mSpringRangeY;
   F32 mSpringRangeZ;
   F32 mSpringVelScale;
   F32 mSpringLooseness;
   // Recoil System
   F32 mPrimaryRecoil;		//	Only Recoil on the Primary Gun

   // Initialized onAdd
   struct TankWheel 
   {
      S32 opposite;              // Opposite wheel on Y axis (or -1 for none)
      Point3F pos;               // Root pos of spring
      S32 springNode;            // Wheel spring/hub node
      S32 springSequence;        // Suspension animation
      F32 springLength;          // Suspension animation length
		S32 treadNode;						
   } tankWheel[MaxTankWheels];
   U32 tankWheelCount;
   ClippedPolyList rigidBody;    // Extracted from shape

   //
   TankVehicleData();
   DECLARE_CONOBJECT(TankVehicleData);
   static void initPersistFields();
   bool preload(bool, String &errorStr);
   bool mirrorWheel(TankWheel* we);
   virtual void packData(BitStream* stream);
   virtual void unpackData(BitStream* stream);
};
//----------------------------------------------------------------------------
class TankVehicle: public Vehicle
{
   typedef Vehicle Parent;

   enum MaskBits 
   {
      TankWheelMask  = Parent::NextFreeMask << 0,
      NextFreeMask	= Parent::NextFreeMask << 1
   };

	TankVehicleData* mDataBlock;

	//Better Random Generator
	MRandom mRandom;

   SFXSource* mEngineSoundA;
   SFXSource* mEngineSoundB;

   struct TankWheel 
   {
      TankVehicleTire *tire;
      TankVehicleSpring *spring;
      TankVehicleData::TankWheel* data;

      F32 extension;          // Spring extension (0-1)
      F32 avel;               // Angular velocity
      F32 apos;               // Anuglar position (client side only)
      F32 Dy,Dx;              // Current tire deformation

      struct Surface 
      {
         bool contact;        // Wheel is touching a surface
         Point3F normal;      // Surface normal
         BaseMatInstance* material; // Surface material
         Point3F pos;         // Point of contact
         SceneObject* object; // Object in contact with
      } surface;

      TSShapeInstance* shapeInstance;

      F32 steering;           // Wheel steering scale
      bool powered;           // Powered by engine
      bool slipping;          // Traction on last tick
      F32 torqueScale;        // Max torque % applied to wheel (0-1)
      F32 slip;               // Amount of wheel slip (0-1)
      SimObjectPtr<ParticleEmitter> emitter;
   };
   TankWheel mTankWheel[TankVehicleData::MaxTankWheels];

public:
   bool mBraking;
   //
   bool onNewDataBlock( GameBaseData *dptr, bool reload );
   void processTick(const Move *move);
	void interpolateTick(F32 dt);
	void updateMove(const Move *move);
   void updateForces(F32 dt);

	void updateAnimation(bool muzzleOnly = false);
	void updateTankSuspension();

	void onImageRecoil(U32 imageSlot, ShapeBaseImageData::StateData::RecoilState);

	void extendWheels(bool clientHack = false);
	void prepBatchRender( SceneRenderState *state, S32 mountedImageIndex);

   // Client sounds & particles
   void updateWheelThreads();
   void updateWheelParticles(F32 dt);
   void updateEngineSound(F32 level);

   virtual U32 getCollisionMask();

   DECLARE_CONOBJECT(TankVehicle);
   static void initPersistFields();

   TankVehicle();
   ~TankVehicle();

   bool onAdd();
   void onRemove();
   void advanceTime(F32 dt);
   bool buildPolyList(PolyListContext context, AbstractPolyList* polyList, const Box3F &box, const SphereF &sphere);

   S32 getWheelCount();
   TankWheel *getWheel(U32 index) {return &mTankWheel[index];}
   void setWheelSteering(S32 wheel,F32 steering);
   void setWheelPowered(S32 wheel,bool powered);
   void setWheelTire(S32 wheel,TankVehicleTire*);
   void setWheelSpring(S32 wheel,TankVehicleSpring*);

   void getWheelInstAndTransform( U32 wheel, TSShapeInstance** inst, MatrixF* xfrm ) const;

   void writePacketData(GameConnection * conn, BitStream *stream);
   void readPacketData(GameConnection * conn, BitStream *stream);
   U32  packUpdate(NetConnection * conn, U32 mask, BitStream *stream);
   void unpackUpdate(NetConnection * conn, BitStream *stream);
};

#endif
