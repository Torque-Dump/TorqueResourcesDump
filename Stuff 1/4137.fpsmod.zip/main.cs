
function initFPSMod() {
	exec("~/ui/fpsmod.gui");
	echo("Test");
}

GlobalActionMap.bindCmd(keyboard, "alt F12", "", "showFPS();");

//-----------------------------------------------------------------------------
package FPSMod {

function showFPS(){

	if(!$showFPS::toggle)
	{
		$showFPS::toggle = 1;
		Canvas.getContent().add(FPSHud);
		FPSshow();
	}
	else {
		$showFPS::toggle = 0;
		Canvas.getContent().remove(FPSHud);
	}
}

function FPSshow()
{
	if(!$showfps)
	{
		$showfps = 1;
		$fps::avg = $fps::real;
		$fps::low = $fps::real;
		$fps::high = $fps::real;
	}

	if($showFPS::toggle){
		$fps::avg = ($fps::avg + $fps::real) / 2;
		if ($fps::real > $fps::high)
			$fps::high = $fps::real;	
		if ($fps::real < $fps::low)
			$fps::low = $fps::real;			
		
		fpscurr.setText("FPS: " SPC $fps::real);
		fpslow.setText("Low: " SPC $fps::low);
		fpshigh.setText("High:" SPC $fps::high);
		fpsavg.setText("Aver:" SPC $fps::avg);
   	
   	schedule(1000, 0, "FPSshow");
	}
	else {
			$showfps = 0;
	}
}	

function onStart()
{
   Parent::onStart();
   echo("\n--------- Initializing MOD: Frames Per Second Mod ---------");
   initFPSMod();
}

function playGui::onWake(%this)
{
	parent::onWake(%this);
	showFPS();
}


}; // Common package
activatePackage(FPSMod);