datablock TSShapeConstructor(DragonDts)
{
   baseShape = "./dragon.dts";
   sequence0 = "./dragon_root.dsq root";
   sequence1 = "./dragon_forward.dsq forward";
   sequence2 = "./dragon_fly.dsq fly";
   sequence3 = "./dragon_attack.dsq attack";
   sequence4 = "./dragon_death.dsq death";
};
