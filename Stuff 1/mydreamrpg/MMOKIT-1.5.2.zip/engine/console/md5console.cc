#include "platform/platform.h"
#include "console/console.h"
#include "console/consoleInternal.h"
#include "console/ast.h"
#include "core/resManager.h"
#include "core/fileStream.h"
#include "console/compiler.h"
#include "platform/event.h"
#include "platform/gameInterface.h"
#include "md5.h"
#include "md5file.h"

static const char Base16Values[] = "0123456789ABCDEF";

// This is the same format as is used for the WWW authentication.
ConsoleFunction(getStringMD5, const char*, 2, 2, "getStringMD5(string)")
{
   // This function isn't threadsafe.
   // (just so we have that out of the way).
   //
   // The return buffer would need to be from TLS for it to be
   // threadsafe.  For now, since the console stuff all runs on
   // a single thread it doesn't matter.
   
   MD5_CTX context;
   U8 digest[16];
   
   static U8 digestB16[128];
   
   // Should never make it here
   if ((argc < 2) || (argc > 3))
      {
         return NULL;
      }
   
   U32 len = dStrlen (argv[1]);

   MD5Init (context);
   MD5Update (context, (U8 *) argv[1], len);
   MD5Final (digest, context);
   
   for (U32 Index = 0; Index < 16; Index++)
   {
      U32 Byte1 = Index * 2;
      U32 Byte2 = Byte1 + 1;
      
      U8  Value1 = (digest[Index] & 0xF0) >> 4;
      U8  Value2 = digest[Index] & 0x0F;
      
      digestB16[Byte1] = Base16Values[Value1];
      digestB16[Byte2] = Base16Values[Value2];
   }
  
   digestB16[32] = 0;
   
   return((const char *) digestB16);
}


ConsoleFunction(getFileMD5, const char*, 2, 2, "getFileMD5(file)")
{
	const char * fileMD5;
	fileMD5 = MD5File( argv[1] ); 
	//Con::printf("MD5 Checksum for file %s = <%s>", argv[1], csMD5);
	return((const char *) fileMD5);
}

