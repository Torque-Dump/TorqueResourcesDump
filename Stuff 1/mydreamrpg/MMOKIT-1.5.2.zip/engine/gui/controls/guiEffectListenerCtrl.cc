//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "console/consoleTypes.h"
#include "console/console.h"
#include "console/consoleInternal.h"
#include "platform/event.h"
#include "dgl/gBitmap.h"
#include "dgl/dgl.h"
#include "sim/actionMap.h"
#include "gui/core/guiCanvas.h"
#include "gui/controls/guiEffectListenerCtrl.h"
#include "gui/core/guiDefaultControlRender.h"
#include "gui/editor/guiEditCtrl.h"

//DreamRPG Effects
#include "game/shapeBase.h"
#include "game/gameConnection.h"


//------------------------------------------------------------------------------

IMPLEMENT_CONOBJECT(GuiEffectListenerCtrl);


GuiEffectListenerCtrl::GuiEffectListenerCtrl()
{
   //DreamRPG Effects
   mEffectContainer = false;
   mPlayerBound = false;
   mBoundPlayer = 0;
   mNumEffects = 0;
}


void GuiEffectListenerCtrl::initPersistFields()
{
   Parent::initPersistFields();
   
   //DreamRPG Effects
   addField("PlayerBound",      TypeBool,         Offset(mPlayerBound, GuiEffectListenerCtrl));
   addField( "Boundplayer",			TypeSimObjectPtr, Offset( mBoundPlayer, GuiEffectListenerCtrl ) );
   addField("EffectContainer",   TypeBool,       Offset(mEffectContainer, GuiEffectListenerCtrl));

}

void GuiEffectListenerCtrl::onRender(Point2I offset, const RectI &updateRect)
{
   //DreamRPG
   listenEffects();

   renderChildControls(offset, updateRect);
}


//DreamRPG Effects

ConsoleMethod( GuiEffectListenerCtrl, setEffectContainer, void, 3, 3, "(bool effectcontainer)")
{
   object->setEffectContainer(dAtob(argv[2]));
}

ConsoleMethod( GuiEffectListenerCtrl, setPlayerBound, void, 3, 3, "(bool PlayerBound)")
{
   object->setPlayerBound(dAtob(argv[2]));
}

ConsoleMethod( GuiEffectListenerCtrl, getBoundPlayer, S32, 2, 2, "")
{
	if (object->mBoundPlayer)
      return object->mBoundPlayer->getId();
   return 0;
}


void GuiEffectListenerCtrl::setEffectContainer(bool isEffectContainer){
	mEffectContainer = isEffectContainer;
}
void GuiEffectListenerCtrl::setPlayerBound(bool isPlayerBound){
	mPlayerBound = isPlayerBound;
}


//DreamRPG Effects
void GuiEffectListenerCtrl::listenEffects(){
// Must have a connection and control object
	//if(!mEffectContainer)
		//return;

	GameConnection* conn = GameConnection::getConnectionToServer();
	if (!conn)
		return;
	
	ShapeBase* control = conn->getControlObject();
	if (!control)
		return;


	if(!mBoundPlayer && !mPlayerBound)
	{
		if(mNumEffects > 0){
			mNumEffects = 0;
			Con::executef(this, 2, "onNumEffectsChanged",Con::getIntArg(mNumEffects));
		}
		return;
	}

	ShapeBase* shape = NULL;

	if(mPlayerBound){
		shape = control;
	} else {
		shape = mBoundPlayer;
	}


	if (shape){
			S32 prevEffects = mNumEffects;
			S32 currentEffects = shape->effects.size();
			if (currentEffects != prevEffects){
				mNumEffects = currentEffects;
				Con::executef(this, 2, "onNumEffectsChanged",Con::getIntArg(currentEffects));
			}
	}
}