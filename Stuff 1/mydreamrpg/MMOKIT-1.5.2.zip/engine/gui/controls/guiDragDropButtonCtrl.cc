//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
// written by Jarred Schnelle, updated by Stefan "Beffy" Moises
//-----------------------------------------------------------------------------

#include "console/console.h"
#include "console/consoleTypes.h"
#include "dgl/dgl.h"
#include "platform/platformAudio.h"  
#include "gui/core/guiCanvas.h"           
#include "gui/controls/guiDragDropButtonCtrl.h"

GuiDragDropButtonCtrl::GuiDragDropButtonCtrl()
{
   mBitmapName = StringTable->insert("");
   mHoverBitmapName = StringTable->insert("");
   mDownBitmapName = StringTable->insert("");
   startPoint.set(0, 0);
   mWrap = false;
   mIsButtonMoving = false;
   mCanMove = true;
   mCopySource = true;
   mIsReceiver = true;
   mSnapsBack = true;
   mResetSourceOnDrop = false;
   mPerformActionOnUp = true;
   mDropBorderSearchColor.set(255,0,0);
   mDropBorderColor.set(0,0,0);
   mDropBorder = false;
   mDropBorderType = StringTable->insert("defaultDrop");
   mDropBorderSearch = StringTable->insert("defaultDrop");
   mDropBorderDisplayed = false;
   mSwitchImages = true;

   //DreamRPG Text
   mButtonText = StringTable->insert("");
   mButtonTextID = StringTable->insert("");
}


void GuiDragDropButtonCtrl::initPersistFields()
{
   Parent::initPersistFields();
   addField("Bitmap", TypeFilename, Offset(mBitmapName, GuiDragDropButtonCtrl));
   addField("HoverBitmap", TypeFilename, Offset(mHoverBitmapName, GuiDragDropButtonCtrl));
   addField("DownBitmap", TypeFilename, Offset(mDownBitmapName, GuiDragDropButtonCtrl));
   addField("canMove",   TypeBool,     Offset(mCanMove, GuiDragDropButtonCtrl));
   addField("isReceiver", TypeBool, Offset(mIsReceiver, GuiDragDropButtonCtrl));
   addField("snapsBack", TypeBool, Offset(mSnapsBack, GuiDragDropButtonCtrl));
   addField("copySource", TypeBool, Offset(mCopySource, GuiDragDropButtonCtrl));
   addField("switchImages", TypeBool, Offset(mSwitchImages, GuiDragDropButtonCtrl));
   addField("resetSourceOnDrop", TypeBool, Offset(mResetSourceOnDrop, GuiDragDropButtonCtrl));
   addField("dropBorder", TypeBool, Offset(mDropBorder, GuiDragDropButtonCtrl));
   addField("dropBorderSearchColor", TypeColorI, Offset(mDropBorderSearchColor, GuiDragDropButtonCtrl));
   addField("dropBorderType", TypeString, Offset(mDropBorderType, GuiDragDropButtonCtrl));
   addField("dropBorderSearch", TypeString, Offset(mDropBorderSearch, GuiDragDropButtonCtrl));
   addField("performActionOnUp", TypeBool, Offset(mPerformActionOnUp, GuiDragDropButtonCtrl));
   //DreamRPG lets render some text
   addField("text", TypeCaseString, Offset(mButtonText, GuiDragDropButtonCtrl));
   addField("textID", TypeString, Offset(mButtonTextID, GuiDragDropButtonCtrl));
}

// ----------------------------------------------------------
// Console functions
// ----------------------------------------------------------

ConsoleMethod( GuiDragDropButtonCtrl, setValue, void, 4, 4, "(int a, int b)"
              "Set the value of the dragdrop control.")
{
   object->setValue(dAtoi(argv[2]), dAtoi(argv[3]));
}

ConsoleMethod( GuiDragDropButtonCtrl, setBitmap, void, 3, 3, "(string name)"
              "Set the bitmap of the dragdrop control.")
{
   object->setBitmapName(argv[2]);
}
ConsoleMethod( GuiDragDropButtonCtrl, setHoverBitmap, void, 3, 3, "(string name)"
              "Set the hover bitmap of the dragdrop control.")
{
   object->setHoverBitmapName(argv[2]);
}
ConsoleMethod( GuiDragDropButtonCtrl, setDownBitmap, void, 3, 3, "(string name)"
              "Set the down bitmap of the dragdrop control.")
{
   object->setDownBitmapName(argv[2]);
}
ConsoleMethod( GuiDragDropButtonCtrl, setCanMove, void, 3, 3, "(bool canMove)"
              "Set the dragdrop control moveable.")
{
   object->setCanMove(dAtob(argv[2]));
}
ConsoleMethod( GuiDragDropButtonCtrl, setIsReceiver, void, 3, 3, "(bool isReceiver)"
              "Set the dragdrop control as receiver.")
{
   object->setIsReceiver(dAtob(argv[2]));
}
ConsoleMethod( GuiDragDropButtonCtrl, setSnapsBack, void, 3, 3, "(bool snapsBack)"
              "Set the dragdrop control to snap back.")
{
   object->setSnapsBack(dAtob(argv[2]));
}
ConsoleMethod( GuiDragDropButtonCtrl, setDropBorder, void, 3, 3, "(bool dropBorder)"
              "Set the dragdrop control to drop the border.")
{
	object->setDropBorder(dAtob(argv[2]));
}

ConsoleMethod( GuiDragDropButtonCtrl, setDropBorderSearchColor, void, 6, 6, "(bool dropBorder)"
              "Set the border search color of the dragdrop control.")
{
   if(argv[5])
      object->setDropBorderSearchColor(dAtoi(argv[2]), dAtoi(argv[3]), dAtoi(argv[4]), dAtoi(argv[5]));
   else
      object->setDropBorderSearchColor(dAtoi(argv[2]), dAtoi(argv[3]), dAtoi(argv[4]));
}
ConsoleMethod( GuiDragDropButtonCtrl, setDropBorderType, void, 3, 3, "(string type)"
              "Set the drop border type of the dragdrop control.")
{
   object->setDropBorderType(argv[2]);
}
ConsoleMethod( GuiDragDropButtonCtrl, setDropBorderSearch, void, 3, 3, "(string search)"
              "Set the drop border search of the dragdrop control.")
{
   object->setDropBorderSearch(argv[2]);
}
ConsoleMethod( GuiDragDropButtonCtrl, getBitmap, const char*, 2, 2, ""
              "Get the bitmap of the dragdrop control.")
{
   const char* temp = object->getNormalName();
   return temp;
}
ConsoleMethod( GuiDragDropButtonCtrl, getHoverBitmap, const char*, 2, 2, ""
              "Get the hover bitmap of the dragdrop control.")
{
   const char* temp = object->getHoverName();
   return temp;
}
ConsoleMethod( GuiDragDropButtonCtrl, getDownBitmap, const char*, 2, 2, ""
              "Get the down bitmap of the dragdrop control.")
{
   const char* temp = object->getDownName();
   return temp;
}
ConsoleMethod( GuiDragDropButtonCtrl, getCanMove, const char*, 2, 2, ""
              "Get the move capability of the dragdrop control.")
{
   bool temp = object->getCanMove();

   char* returnBuffer = Con::getReturnBuffer(256);
   dSprintf(returnBuffer,256,"%b", temp);
   return returnBuffer;
}
ConsoleMethod( GuiDragDropButtonCtrl, getSnapsBack, const char*, 2, 2, ""
              "Get the snap back capability of the dragdrop control.")
{
   bool temp = object->getSnapsBack();

   char* returnBuffer = Con::getReturnBuffer(256);
   dSprintf(returnBuffer,256,"%b", temp);
   return returnBuffer;
}
ConsoleMethod( GuiDragDropButtonCtrl, getIsReceiver, const char*, 2, 2, ""
              "Get the receiver capability of the dragdrop control.")
{
   bool temp = object->getIsReceiver();

   char* returnBuffer = Con::getReturnBuffer(256);
   dSprintf(returnBuffer,256,"%b", temp);
   return returnBuffer;
}
ConsoleMethod( GuiDragDropButtonCtrl, getCopySource, const char*, 2, 2, ""
              "Get the copy source capability of the dragdrop control.")
{
   bool temp = object->getCopySource();

   char* returnBuffer = Con::getReturnBuffer(256);
   dSprintf(returnBuffer,256,"%b", temp);
   return returnBuffer;
}
ConsoleMethod( GuiDragDropButtonCtrl, getDropBorder, const char*, 2, 2, ""
              "Get the drop border capability of the dragdrop control.")
{
   bool temp = object->getDropBorder();

   char* returnBuffer = Con::getReturnBuffer(256);
   dSprintf(returnBuffer,256,"%b", temp);
   return returnBuffer;
}
ConsoleMethod( GuiDragDropButtonCtrl, getDropBorderType, const char*, 2, 2, ""
              "Get the drop border type of the dragdrop control.")
{
   bool temp = object->getDropBorderType();

   char* returnBuffer = Con::getReturnBuffer(256);
   dSprintf(returnBuffer,256,"%b", temp);
   return returnBuffer;
}
ConsoleMethod( GuiDragDropButtonCtrl, getDropBorderSearch, const char*, 2, 2, ""
              "Get the drop border search of the dragdrop control.")
{
   bool temp = object->getDropBorderSearch();

   char* returnBuffer = Con::getReturnBuffer(256);
   dSprintf(returnBuffer,256,"%b", temp);
   return returnBuffer;
}
ConsoleMethod( GuiDragDropButtonCtrl, getDropBorderSearchColor, const char*, 2, 2, ""
              "Get the drop border search color of the dragdrop control.")
{
   ColorI temp = object->getDropBorderSearchColor();

   char* returnBuffer = Con::getReturnBuffer(256);
   dSprintf(returnBuffer,256,"%d %d %d %d", temp.red, temp.green, temp.blue, temp.alpha);
   return returnBuffer;
}



//CanMove Member Function - Setter
void GuiDragDropButtonCtrl::setCanMove(bool temp)
{
   mCanMove = temp;
}

//IsReceiver Member Function - Setter
void GuiDragDropButtonCtrl::setIsReceiver(bool temp)
{
   mIsReceiver = temp;
}

//SnapsBack Member Function - Setter
void GuiDragDropButtonCtrl::setSnapsBack(bool temp)
{
   mSnapsBack = temp;
}

//DropBorder Member Function - Setter
void GuiDragDropButtonCtrl::setDropBorder(bool temp)
{
   mDropBorder = temp;
}

//DropBorderSearchColor Member Function - Setter
void GuiDragDropButtonCtrl::setDropBorderSearchColor(int r, int g, int b)
{
   mDropBorderSearchColor.set(r, g, b);
}

void GuiDragDropButtonCtrl::setDropBorderSearchColor(int r, int g, int b, int a)
{
   mDropBorderSearchColor.set(r, g, b, a);
}

//DropBorderType Member Function - Setter
void GuiDragDropButtonCtrl::setDropBorderType(const char* temp)
{
   mDropBorderType = StringTable->insert(temp);
}


//DropBorderSearch Member Function - Setter
void GuiDragDropButtonCtrl::setDropBorderSearch(const char* temp)
{
   mDropBorderSearch = StringTable->insert(temp);
}


void GuiDragDropButtonCtrl::consoleInit()
{
}

bool GuiDragDropButtonCtrl::onWake()
{
   if (! Parent::onWake())
      return false;
   setActive(true);
   setBitmapName(mBitmapName);
   setHoverBitmapName(mHoverBitmapName);
   setDownBitmapName(mDownBitmapName);
   setText(mButtonText);
   return true;
}

void GuiDragDropButtonCtrl::onSleep()
{
   mTextureHandle = NULL;
   mHoverTextureHandle = NULL;
   mDownTextureHandle = NULL;
   mNormalTextureHandle = NULL;
   Parent::onSleep();
}

void GuiDragDropButtonCtrl::setBitmapName(const char *name)
{
   mBitmapName = StringTable->insert(name);
   if (*mBitmapName)
      mTextureHandle = TextureHandle(mBitmapName, BitmapTexture, true);
   else
      mTextureHandle = NULL;

   mNormalTextureHandle = mTextureHandle; //Store the normal(default) texture for our up/down/enter/leave events
   setUpdate();
}

void GuiDragDropButtonCtrl::setHoverBitmapName(const char *name)
{
   mHoverBitmapName = StringTable->insert(name);
   if (*mHoverBitmapName)
      mHoverTextureHandle = TextureHandle(mHoverBitmapName, BitmapTexture, true);
   else
      mHoverTextureHandle = NULL;
   setUpdate();
}   

void GuiDragDropButtonCtrl::setDownBitmapName(const char *name)
{
   mDownBitmapName = StringTable->insert(name);
   if (*mDownBitmapName)
      mDownTextureHandle = TextureHandle(mDownBitmapName, BitmapTexture, true);
   else
      mDownTextureHandle = NULL;
   setUpdate();
} 

void GuiDragDropButtonCtrl::setBitmapHandle(const TextureHandle &handle)
{
   mTextureHandle = handle;
   mNormalTextureHandle = mTextureHandle;
}   

void GuiDragDropButtonCtrl::setHoverBitmapHandle(const TextureHandle &handle)
{
   mHoverTextureHandle = handle;   
}

void GuiDragDropButtonCtrl::setDownBitmapHandle(const TextureHandle &handle)
{
   mDownTextureHandle = handle;   
}


void GuiDragDropButtonCtrl::setTextureHandle(const TextureHandle &handle)
{
   mTextureHandle = handle;
}

void GuiDragDropButtonCtrl::onRender(Point2I offset, const RectI &updateRect)
{
   if (mTextureHandle)
   {
      dglClearBitmapModulation();
      if(mWrap)
      {
         TextureObject* texture = (TextureObject *) mTextureHandle;
         RectI srcRegion;
         RectI dstRegion;
         float xdone = ((float)mBounds.extent.x/(float)texture->bitmapWidth)+1;
         float ydone = ((float)mBounds.extent.y/(float)texture->bitmapHeight)+1;

         int xshift = startPoint.x%texture->bitmapWidth;
         int yshift = startPoint.y%texture->bitmapHeight;
         for(int y = 0; y < ydone; ++y)
            for(int x = 0; x < xdone; ++x)
            {
               srcRegion.set(0,0,texture->bitmapWidth,texture->bitmapHeight);
               dstRegion.set( ((texture->bitmapWidth*x)+offset.x)-xshift,
                  ((texture->bitmapHeight*y)+offset.y)-yshift,
                  texture->bitmapWidth,	
                  texture->bitmapHeight);
               dglDrawBitmapStretchSR(texture,dstRegion, srcRegion, false);
            }
      }
      else
      {
         RectI rect(offset, mBounds.extent);
         dglDrawBitmapStretch(mTextureHandle, rect);
      }
   }

   //If the button is being dragged, and we're supposed to display borders around the targets
   if (mIsButtonMoving && mDropBorder)
   {
      //Con::errorf("Trying to draw them borders...");     
      drawDropBorder(mDropBorderSearch, mDropBorderSearchColor);
   }

   //if we're supposed to be displaying a colored border because we're a target, draw it
   //another sibling class sets our border bool and our border color
   //The extra If/Else statement for button moving is because I dont want to draw a border around
   //the button that is actually moving.  You may remove this if you'd like.
   if (!mIsButtonMoving)
   {
      if (mDropBorderDisplayed)
      {
         RectI rect(offset.x, offset.y, mBounds.extent.x, mBounds.extent.y);
         dglDrawRect(rect, mDropBorderColor);
      }
      else if (mProfile->mBorder || !mTextureHandle)
      {
         RectI rect(offset.x, offset.y, mBounds.extent.x, mBounds.extent.y);
         dglDrawRect(rect, mProfile->mBorderColor);
      }
      else {}
   }
   else
   {
      if (mProfile->mBorder || !mTextureHandle)
      {
         RectI rect(offset.x, offset.y, mBounds.extent.x, mBounds.extent.y);
         dglDrawRect(rect, mProfile->mBorderColor);
      }
   }
   
   //Dream RPG render a little text
   if(mButtonText){
	  Point2I textPos = offset;
      // Make sure we take the profile's textOffset into account.
      textPos += mProfile->mTextOffset;
      dglSetBitmapModulation( mProfile->mFontColor );
      renderJustifiedText(textPos, mBounds.extent, mButtonText);
   }

   renderChildControls(offset, updateRect);

}

void GuiDragDropButtonCtrl::setValue(S32 x, S32 y)
{
   if (mTextureHandle)
   {
      TextureObject* texture = (TextureObject *) mTextureHandle;
      x+=texture->bitmapWidth/2;
      y+=texture->bitmapHeight/2;
  	}
   while (x < 0)
      x += 256;
   startPoint.x = x % 256;

   while (y < 0)
      y += 256;
   startPoint.y = y % 256;
}


void GuiDragDropButtonCtrl::onMouseEnter(const GuiEvent &event)
{
   Parent::onMouseEnter(event);

   if ( mActive && mProfile->mSoundButtonOver )
   {
      //F32 pan = (F32(event.mousePoint.x)/F32(Canvas->mBounds.extent.x)*2.0f-1.0f)*0.8f;
      AUDIOHANDLE handle = alxCreateSource(mProfile->mSoundButtonOver);
      alxPlay(handle);
   }

   //Dont change textures if we're dragging the icons around
   if(!mIsButtonMoving && mHoverTextureHandle)  
   {
      //Only change textures if the Hover texture exists
      mTextureHandle = mHoverTextureHandle;    
      setUpdate();    
   }    
   //Dont change textures here either
   else if(!mIsButtonMoving)                    
   {
      //There is no hover, so we make the hover the NormalTexture
      mHoverTextureHandle = mNormalTextureHandle;  
      mTextureHandle = mHoverTextureHandle;
      setUpdate();
   }
   else{}

}

void GuiDragDropButtonCtrl::onMouseLeave(const GuiEvent &event)
{
   Parent::onMouseLeave(event);

   //Make sure we switch to the NormalTexture when we've left & make sure we're not moving
   if(!mIsButtonMoving && mTextureHandle != mNormalTextureHandle)
   {
      mTextureHandle = mNormalTextureHandle;
      setUpdate();
   }

}

void GuiDragDropButtonCtrl::onMouseDown(const GuiEvent & event)
{
   Parent::onMouseDown(event);

   //If there's nothing in this control, dont bother doing anything except notify the script
   if(!mNormalTextureHandle){
	   Con::executef(this, 1, "onMouseDown");
	   return;
   }

   mOrigBounds = mBounds;
   mMouseDownPosition = event.mousePoint;
   mMouseDownPositionOffset = event.mousePoint;
   Point2I grabbedPos = globalToLocalCoord(event.mousePoint);
   mMouseDownPositionOffset.x -= grabbedPos.x;
   mMouseDownPositionOffset.y -= grabbedPos.y;

   if(mDownTextureHandle)
   {
      mTextureHandle = mDownTextureHandle;
      setUpdate();
   }
   else  // There's no down, lets see if there is a hover, if there's no hover we'll use the normal
   {
      if(mHoverTextureHandle)
         mDownTextureHandle = mHoverTextureHandle;
      else
         mDownTextureHandle = mNormalTextureHandle;

      mTextureHandle = mDownTextureHandle;
      setUpdate();
   }

   Point2I localPoint = globalToLocalCoord(event.mousePoint);

   //Let's check to see if we clicked inside the button
   if(localPoint.x < 0 || localPoint.x > mBounds.extent.x || localPoint.y < 0 || localPoint.y > mBounds.extent.y || !mCanMove)
      mIsButtonMoving = false;	

   else
   {
      mIsButtonMoving = true;

      //Ok, now we need to find out if we're good where we're at, or if we need to move the icon up the GUI
      //tree so we can actually move it around the screen.

      //We're interested in what comes two levels below GuiCanvas, because that's the highest level of the tree,
      //where we can still see the GUI elements

      GuiControl* thirdParent = NULL;
      GuiControl* previousParent = NULL;
      GuiControl* currentParent = this->getParent();

      GuiCanvas* root = this->getRoot();

      //Get the position in relation to it's immediate parent
      mChangedGroupPosition = this->getPosition();

      //Now we cycle through the parents, updating our position in relation to them.
      //We will also take this opportunity to find out what lives 2 steps below the GuiCanvas
      //The group that this parent lives in, is the top group which we can move things around visibly.

      while(currentParent && currentParent->getClassName() != root->getClassName())
      {        
         //we have a parent that isnt GuiCanvas, let's find it's position, and add it to our
         //ChangedGroupPosition.  This ChangedGroupPosition will be equal to the original Drag/Drop
         //GUI element's global position.
         mChangedGroupPosition += currentParent->getPosition();

         thirdParent = previousParent;
         previousParent = currentParent;
         //Grab the new parent, and loop
         currentParent = currentParent->getParent();
      }

      //if thirdParent changed, then we've moved up at least 2 layers, and we need to use this layer as our
      //parent.  This means that "currentParent == GuiCanvas", and "previousParent == GameTSCtrl"
      //the previousParent could really be anything, but it's not what we want

      //if the thirdParent didnt change(read, thirdPraent == NULL), then we only moved up one layer,
      //and we need to use the parent stored in previousParent.  This means that currentParent == GuiCanvas

      if(thirdParent)
      {
         //START MOVE GUI LAYERS
         //Store the current group that this button belongs to, so we can switch back when we're done
         mCurrentGroup = this->getGroup();
         //Find the group, One level below GameTSCtrl
         mTopLevelGroup = thirdParent->getGroup();
         //remove the DragDrop button from it's current group
         mCurrentGroup->removeObject(this);
         //and add it to the TopLevelGroup
         mTopLevelGroup->addObject(this);
         mChangedGroup = true;
         //END MOVE GUI LAYERS
         //START CANVAS UPDATE
         resize(mChangedGroupPosition, mOrigBounds.extent);
         //END CANVAS UPDATE
      }
      else
         mChangedGroup = false;

      mouseLock(); //Lock the mouse after we've done all our changes
   }

}

void GuiDragDropButtonCtrl::onMouseUp(const GuiEvent & event)
{
   bool executedFunction = false;
   //DreamRPG this will prevent the mouseup from doing anything unless its moving, which we DONT want to do
   if(!mIsButtonMoving)
	   return ;
   Parent::onMouseUp(event);
   mIsButtonMoving = false;
   mouseUnlock();

   //Shut off the rendering boxes around the targets if it draws them
   if(mDropBorder)
      undoDrawDropBorder(mDropBorderSearch);

   //Should always be within the bounds when mouse goes up, so we're still hovering, unless we snap
   //but we'll handle snap down below
   mTextureHandle = mHoverTextureHandle;

   //Let's check if the button can even move before we see if it can drop
   //This should simplify the button to be simply a ButtonCtrl element if that's all we want
   //No need to check for drop recievers if the thing cant move!
   if(mCanMove)
   {
      //checkDropPosition(whereverLetGoOfMouseButton)		
      if(checkDropPosition(event.mousePoint))
      {
         if(!mCopySource) 
         {
            //Delete the object if we've dropped it. And DONT want to copy the source button.
            //This will MOVE the contents into another button, and delete the current button.
            this->deleteObject();
            return;
         }
         if(mResetSourceOnDrop && !mSwitchImages)
            resetContents();

         //Give the console a way to find out what we actually dropped
         //I use this to save off the images for my command bar, since it has many layers which may
         //have different images in any given slot.  This could be done in the script, but this just
         //saves me the headache of putting $SomeVar = thisThingsName, every time I want to use it.

         Con::setVariable("$DroppedCtrl", this->getName());
         //Execute the console function for dropped items
         Con::executef(this, 1, "onDropped");
		 Con::errorf("Dropped the control");
         //We dont want to do both an onDropped() and an onAction() in the console
         executedFunction = true; 
      }
      else
      {
         const char* varCtrl = NULL;
         Con::setVariable("$DroppedCtrl", varCtrl);
         Con::setVariable("$DroppedUponCtrl", varCtrl);
		 //Con::executef(this, 1, "onDropped");
		 //Con::errorf("Dropped the control over nothing");
         //We dont want to do both an onDropped() and an onAction() in the console
         //executedFunction = true; 
      }

      //If it's supposed to snap back, snap it back
      if(mSnapsBack)
      {
         GuiControl *parent = getParent();
         GuiCanvas *root = getRoot();
         bool update = false;
         if (! root) return;
         if (parent)
            update = true;
         if (update)
         {
            Point2I pos = parent->localToGlobalCoord(mBounds.point);
            root->addUpdateRegion(pos, mBounds.extent);
            resize(mOrigBounds.point, mOrigBounds.extent);
         }
         mTextureHandle = mNormalTextureHandle;
      }
      else
      {
         GuiControl *parent = getParent();
         GuiCanvas *root = getRoot();
         bool update = false;
         if (! root) return;
         if (parent)
            update = true;
         if (update)
         {
            Point2I pos = parent->localToGlobalCoord(mBounds.point);
            root->addUpdateRegion(pos, mBounds.extent);
            resize(event.mousePoint, mOrigBounds.extent);
         }
         mTextureHandle = mNormalTextureHandle;
      }



      //Correct the changes we've made to the groups
      //NOTE:: If you dont want the thing to snap back, and it has changed groups in the tree
      //then it stays on the top level of the GuiTree, because you may run into problems with the
      //button not displaying if you dont snap back, and move it outside the extents of the Gui
      //it came from.  This is just a work around, as I personally dont plan to use multi-tree, non-snapping
      //buttons.  In the future, checks for extent versus group could be made, to see if you're even allowed to
      //not snap back.  As in, if the icon lands outside your local extent, ignore the GUIs demands to not snap back
      //and do it anyways.
      if(mChangedGroup && mSnapsBack)
      {
         mTopLevelGroup->removeObject(this);
         mCurrentGroup->addObject(this);
      }

   } //Close bracket for mCanMove if check
   setUpdate();

   //if we didnt do an onDrop() console function, go ahead and call the onAction() function
   //Also, the GUI creator can specify if he wants the button to perform any actions on mouse up,
   //In creation of a skill/power listing, with these buttons, you may not want the spells to be
   //castable from the menu.  This solves that by taking away the onAction method.
   if(!executedFunction && mPerformActionOnUp){
      S32 doubleClick = (event.mouseClickCount > 1)?1:0;
	  //Con::errorf("Performing Action");
      onAction();
   }
}

void GuiDragDropButtonCtrl::onMouseDragged(const GuiEvent &event)
{

   //Dont do anything if we cant move
   if(!mCanMove)
      return;

    //If there's nothing in this control, dont bother doing anything!
   if(!mNormalTextureHandle){
	   return;
   }

   GuiControl *parent = getParent();
   GuiCanvas *root = getRoot();
   if (!root)
      return;


   Point2I deltaMousePosition = event.mousePoint - mMouseDownPosition;
   Point2I newPosition = mBounds.point; //Defined in case we drag the mouse and dont move the button, oops
   Point2I newExtent = mBounds.extent;

   bool update = false;
   //if we didnt change groups, use the regular position
   if (mIsButtonMoving && parent && !mChangedGroup)
   {
      newPosition.x = getMax(0, getMin(parent->mBounds.extent.x - mBounds.extent.x, mMouseDownPositionOffset.x + deltaMousePosition.x));
      newPosition.y = getMax(0, getMin(parent->mBounds.extent.y - mBounds.extent.y, mMouseDownPositionOffset.y + deltaMousePosition.y));
      update = true;
   }
   //if we did change groups, we need to use our newly found position
   else if(mIsButtonMoving && parent && mChangedGroup)
   {   
      newPosition.x = getMax(0, getMin(parent->mBounds.extent.x - mBounds.extent.x, mMouseDownPositionOffset.x + deltaMousePosition.x));
      newPosition.y = getMax(0, getMin(parent->mBounds.extent.y - mBounds.extent.y, mMouseDownPositionOffset.y + deltaMousePosition.y));
      update = true;
   }

   if (update)
   {
      Point2I pos = parent->localToGlobalCoord(mBounds.point);
      root->addUpdateRegion(pos, mBounds.extent);
      resize(newPosition, newExtent);
   }
}


void GuiDragDropButtonCtrl::onRightMouseDown(const GuiEvent &event)
{
   Parent::onRightMouseDown(event);

}

void GuiDragDropButtonCtrl::onRightMouseUp(const GuiEvent &event)
{
   Parent::onRightMouseUp(event);
   
   char buf[16];
   dSprintf(buf, sizeof(buf), "%d", getId());
   Con::setVariable("$ThisControl", buf);
   Con::executef(this, 1, "onRightMouseClick");
}


//Expects the Position of the MouseUpEvent from guiDragDropButtonCtrl
bool GuiDragDropButtonCtrl::checkDropPosition(Point2I MouseUpPosition)
{
   //Check for Active Elements
   SimObject* DDObj = NULL;
   GuiControl* DDCtrl = NULL;
   GuiControl* Parent = NULL;
   Point2I ArrayPosition;  //Coordinates of the object in the array
   Point2I ArrayExtent;    //Extent of the object so we can check to see if the Mouse Up event is within this extent.
   Point2I TempExtent;     //We will subtract the ArrayPosition from the MouseUpPosition, and create this new extent	
   for(U32 i=0; i<mDragDropArraySize; i++)
   {
      //Check the Array for non zero values, which means we have a Drag/Drop ID number	
      if(GuiControl::DragDropArray[i] != 0 && GuiControl::DragDropArray[i] != this->getId())
      {
         //Get the SimObject pointer that belongs to the ID number
         DDObj = Sim::findObject(GuiControl::DragDropArray[i]);
         //Turn it into a GuiControl so we can work with position
         DDCtrl = dynamic_cast<GuiControl *>(DDObj);
         //Find out if this GuiControl is awake on the screen
         if(DDCtrl->isAwake())
         {
            //It's awake, let's find out where it is, in relation to the top level GameGui
            //This makes the assumption that your top level GUI is GameTSCtrl(it should be)
            //This will cycle through the parents, and add the parents relative position to
            //the children's relative positions.

            ArrayPosition = DDCtrl->getPosition();
            Parent = DDCtrl->getParent();  //Find the parent control
            if(Parent)					
            {
               while(Parent && Parent->getClassName() != "GameTSCtrl")
               {
                  ArrayPosition += Parent->getPosition();
                  Parent = Parent->getParent();
               }
            }

            //We will subtract the 2 positions, to form a new rectangle.  If this rectangle is fully contained
            //within the extent of the ArrayObject, then we've clicked inside the ArrayObject
            TempExtent = MouseUpPosition - ArrayPosition;
            //Get the ArrayExtent so we can compare the two rectangles
            ArrayExtent = DDCtrl->getExtent();
            //Check to see if it's within
            if(TempExtent.x >= 0 && TempExtent.x <= ArrayExtent.x && TempExtent.y >= 0 && TempExtent.y <= ArrayExtent.y)
            {
               //We've dropped our button within another DDGui Element, time to
               //assign new values to the receiver, if it is one.

               //Create a pointer to our DDBCtrl that was stored within the Array
               GuiDragDropButtonCtrl* DDBCtrl = dynamic_cast<GuiDragDropButtonCtrl *>(DDObj);

               //Start the assignment process of: 3 Texture Names, 4 Texture Handles, Command & Variable
               //My intentions are to leave a lot up to the GUI designer.  If they want the receiving end to have
               //completly different actions(such as transmit/receive capabilities), they should implement these
               //on creation of the GUI.  This is not the place to alter GUI design.
              if(DDBCtrl->mIsReceiver && this->getDropBorderSearch() == DDBCtrl->getDropBorderType() && DDCtrl->getParent()->isVisible())
               {
                  if(mSwitchImages)
                  {
                     //Grab our texture handles for what we're dropping onto incase there's something there
                     const TextureHandle tempHandle = DDBCtrl->getNormalHandle();  
                     const char* tempBitmap   = DDBCtrl->getNormalName();
                     const char* tempHover    = DDBCtrl->getHoverName();
                     const char* tempDown     = DDBCtrl->getDownName();

                     DDBCtrl->setTextureHandle(this->getNormalHandle());
                     //No need to set the other Handles, the following 3 lines do that				  
                     DDBCtrl->setBitmapName(this->getNormalName());
                     DDBCtrl->setHoverBitmapName(this->getHoverName());
                     DDBCtrl->setDownBitmapName(this->getDownName());

                     this->setTextureHandle(tempHandle);
                     this->setBitmapName(tempBitmap);
                     this->setHoverBitmapName(tempHover);
                     this->setDownBitmapName(tempDown);
                  }
                  else
                  {
                     //Put our new texture handles in that spot
                     DDBCtrl->setTextureHandle(this->getNormalHandle());
                     //No need to set the other Handles, the following 3 lines do that				  
                     DDBCtrl->setBitmapName(this->getNormalName());
                     DDBCtrl->setHoverBitmapName(this->getHoverName());
                     DDBCtrl->setDownBitmapName(this->getDownName());
                  }

                  //Set a variable in the script so the script will know what receieved the new textures.
                  //This is VERY necessary since we will be handling ALL functions via script.
                  //The idea is as follows:
                  //We drag and drop a button(the function doing the dropping will call an onDrop function),
                  //if this button falls upon something ($DroppedUponControl).  In the script we could trigger
                  //$DroppedUponControl.onDroppedUpon()

                  Con::setVariable("$DroppedUponCtrl", DDObj->getName());

                  //Old style function execution if you dont like how I made it all script	(2 lines)
                  //DDBCtrl->setConsoleCommand(this->getConsoleCommand());
                  //DDBCtrl->setConsoleVariable(this->getConsoleVariable());

                  DDBCtrl->setUpdate();
                  return true; // We've succeeded in placing the button
               }
               //If it's not a receiver then we just move on to the next one, since we may be dropping on something
               //that is right below it.  This gives a tad bit more flexibility to the person making the GUI
            }
         }
      }
   }
   return false;  // If we're here, we never placed our button
}

void GuiDragDropButtonCtrl::drawDropBorder(const char* searchString, ColorI searchColor)
{
   SimObject* DDObj = NULL;
   GuiControl* DDCtrl = NULL;
   GuiDragDropButtonCtrl* DDBCtrl = NULL;

   for(U32 i=0; i<mDragDropArraySize; i++)
   {
      if(GuiControl::DragDropArray[i] != 0)  //if we have an ID number
      {
         //Get the SimObject pointer that belongs to the ID number
         DDObj = Sim::findObject(GuiControl::DragDropArray[i]);
         //Turn it into a GuiControl so we can work with position
         DDCtrl = dynamic_cast<GuiControl *>(DDObj);
         //Find out if this GuiControl is awake on the screen
         if(DDCtrl->isAwake())
         {
            DDBCtrl = dynamic_cast<GuiDragDropButtonCtrl *>(DDObj);
            //Find out what type of DragDropButton it is, and see if it's what we're looking for
            //If it's what we want, then let's draw the border around it
            if(searchString == DDBCtrl->getDropBorderType())
            {
               DDBCtrl->setDropBorderDisplayed(true);
               DDBCtrl->setDropBorderColor(searchColor);
            }
         }
      }
   }
}

//Identical to the one above, but it simply sets the Displayed to false
void GuiDragDropButtonCtrl::undoDrawDropBorder(const char* searchString)
{
   SimObject* DDObj = NULL;
   GuiControl* DDCtrl = NULL;
   GuiDragDropButtonCtrl* DDBCtrl = NULL;

   for(U32 i=0; i<mDragDropArraySize; i++)
   {
      if(GuiControl::DragDropArray[i] != 0)  //if we have an ID number
      {
         //Get the SimObject pointer that belongs to the ID number
         DDObj = Sim::findObject(GuiControl::DragDropArray[i]);
         //Turn it into a GuiControl so we can work with position
         DDCtrl = dynamic_cast<GuiControl *>(DDObj);
         //Find out if this GuiControl is awake on the screen
         if(DDCtrl->isAwake())
         {
            DDBCtrl = dynamic_cast<GuiDragDropButtonCtrl *>(DDObj);
            //Find out what type of DragDropButton it is, and see if it's what we're looking for
            //If it's what we want, then let's draw the border around it
            if(searchString == DDBCtrl->getDropBorderType())
            {
               DDBCtrl->setDropBorderDisplayed(false);
            }
         }
      }
   }
}

void GuiDragDropButtonCtrl::setDropBorderDisplayed(bool display)
{
   mDropBorderDisplayed = display;
}

void GuiDragDropButtonCtrl::setDropBorderColor(ColorI color)
{
   mDropBorderColor = color;
}

//Reset the Contents to the original state.
//This means, we're saving whatever bools they have, but we're clearing the images, and the command/var
void GuiDragDropButtonCtrl::resetContents()
{
   setBitmapName("");
   setBitmapHandle(NULL);
   setHoverBitmapName("");
   setHoverBitmapHandle(NULL);
   setDownBitmapName("");
   setDownBitmapHandle(NULL);
   setTextureHandle(NULL);
   setConsoleCommand("");
   setConsoleVariable("");
   setUpdate();
}


//We're not going to handle any function calling in code, let's leave that up to the script
void GuiDragDropButtonCtrl::onAction()
{
   char buf[16];
   dSprintf(buf, sizeof(buf), "%d", getId());
   Con::setVariable("$ThisControl", buf);

   //Con::setVariable("$DropCtrlName", getName());
   Con::executef(this, 1, "onAction");	   
}






//DreamRPG Methods for getting/setting text

void GuiDragDropButtonCtrl::setText(const char *text)
{
   mButtonText = StringTable->insert(text);
}

void GuiDragDropButtonCtrl::setTextID(const char *id)
{
	S32 n = Con::getIntVariable(id, -1);
	if(n != -1)
	{
		mButtonTextID = StringTable->insert(id);
		setTextID(n);
	}
}
void GuiDragDropButtonCtrl::setTextID(S32 id)
{
	const UTF8 *str = getGUIString(id);
	if(str)
		setText((const char*)str);
	//mButtonTextID = id;
}
const char *GuiDragDropButtonCtrl::getText()
{
   return mButtonText;
}


ConsoleMethod( GuiDragDropButtonCtrl, setText, void, 3, 3, "(string text) - sets the text of the button to the string." )
{
   argc;
   object->setText( argv[2] );
}

ConsoleMethod( GuiDragDropButtonCtrl, setTextID, void, 3, 3, "(string id) - sets the text of the button to the localized string." )
{
	argc;
	object->setTextID(argv[2]);
}
ConsoleMethod( GuiDragDropButtonCtrl, getText, const char *, 2, 2, "() - returns the text of the button." )
{
   argc; argv;
   return object->getText( );
}
