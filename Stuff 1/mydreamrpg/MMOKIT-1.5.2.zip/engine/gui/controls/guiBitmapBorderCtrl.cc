//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (c) 2002 GarageGames.Com
//-----------------------------------------------------------------------------

#include "gui/core/guiControl.h"
#include "gui/core/guiCanvas.h"
#include "dgl/dgl.h"

/// Renders a skinned border.
class GuiBitmapBorderCtrl : public GuiControl
{
   typedef GuiControl Parent;

   enum {
      BorderTopLeft,
      BorderTopRight,
      BorderTop,
      BorderLeft,
      BorderRight,
      BorderBottomLeft,
      BorderBottom,
      BorderBottomRight,
      NumBitmaps
   };
	RectI *mBitmapBounds;  ///< bmp is [3*n], bmpHL is [3*n + 1], bmpNA is [3*n + 2]
   TextureHandle mTextureHandle;

   // The original position of the GUI before moving, scaling, etc. 
   RectI mOrigBounds;
   // Are we currently moving the GUI element.
   bool mMouseMovingWin;
   // Position of the mouse when we pressed the button.
   Point2I mMouseDownPosition;

public:
   bool onWake();
   void onSleep();

   void onMouseDown(const GuiEvent &event);
   void onMouseDragged(const GuiEvent &event);
   void onMouseUp(const GuiEvent &event);
   void onMouseEnter(const GuiEvent &);
   void onMouseLeave(const GuiEvent &);

   void onRender(Point2I offset, const RectI &updateRect);
   DECLARE_CONOBJECT(GuiBitmapBorderCtrl);
};

IMPLEMENT_CONOBJECT(GuiBitmapBorderCtrl);

bool GuiBitmapBorderCtrl::onWake()
{
   if (! Parent::onWake())
      return false;

   //get the texture for the close, minimize, and maximize buttons
   mTextureHandle = mProfile->mTextureHandle;
   bool result = mProfile->constructBitmapArray() >= NumBitmaps;
   AssertFatal(result, "Failed to create the bitmap array");
   if(!result)
      return false;

   mBitmapBounds = mProfile->mBitmapArrayRects.address();
   return true;
}

void GuiBitmapBorderCtrl::onSleep()
{
   mTextureHandle = NULL;
   Parent::onSleep();
}

// Cursor Control
void GuiBitmapBorderCtrl::onMouseEnter(const GuiEvent &event)
{
   // get the canvas, this is "the" gui..
   GuiCanvas *canvas = getRoot();  
   if(!canvas)
      return;

   // get the position of the pouse pointer..
   Point2I localPoint = globalToLocalCoord(event.mousePoint);
   // get the position of the GUI element.
   S32 guiHeight = mBitmapBounds[BorderLeft].extent.y;
   S32 guiWidth = mBitmapBounds[BorderTop].extent.x / 4;
   // define the cursor
   GuiCursor *curs = NULL;
   // check to see if the mouse is within the limits of the gui width and height.
   if (localPoint.y <= guiHeight && localPoint.x <= guiWidth) {
      // If we find the "MoveCursor" datablock, go ahead and assign the new cursor.
      if(Sim::findObject("MoveCursor", curs))
         canvas->setCursor(curs);
   }
   else
   {
      // We have moved out of the gui limits set above, revert back to the default Cursor.    
      if(Sim::findObject("DefaultCursor", curs))
         canvas->setCursor(curs);
   }
}

void GuiBitmapBorderCtrl::onMouseLeave(const GuiEvent &event)
{
   // Back to the default cursor if out of the "move" bounds.
   GuiCanvas *canvas = getRoot();
   if(!canvas)
      return;

   GuiCursor *curs = NULL;
   if(Sim::findObject("DefaultCursor", curs))
      canvas->setCursor(curs);
}

// MOVE!!!
void GuiBitmapBorderCtrl::onMouseDown(const GuiEvent &event)
{
   setUpdate();     
   
   mOrigBounds = mBounds;	 	  
   mMouseDownPosition = event.mousePoint;
   Point2I localPoint = globalToLocalCoord(event.mousePoint);
   mMouseMovingWin = false;
   //if we clicked within the title bar
   S32 guiHeight = mBitmapBounds[BorderLeft].extent.y;
   S32 guiWidth = mBitmapBounds[BorderTop].extent.x / 4;
   if (localPoint.y <= guiHeight && localPoint.x <= guiWidth)   
      mMouseMovingWin = true;

   if (mMouseMovingWin)
   {
      mouseLock(); 
   }
   else
   {
      GuiControl *ctrl = findHitControl(localPoint);
      if (ctrl && ctrl != this)
      {
         ctrl->onMouseDown(event);
      }
   }
}

void GuiBitmapBorderCtrl::onMouseDragged(const GuiEvent &event)
{
   GuiControl *parent = getParent();
   GuiCanvas *root = getRoot();
   if (! root) return;
   
   Point2I deltaMousePosition = event.mousePoint - mMouseDownPosition;
   
   Point2I newPosition = mBounds.point;
   Point2I newExtent = mBounds.extent;
   bool update = false;
   if (mMouseMovingWin && parent)
   {
      newPosition.x = getMax(0, getMin(parent->mBounds.extent.x - mBounds.extent.x, mOrigBounds.point.x + deltaMousePosition.x));
      newPosition.y = getMax(0, getMin(parent->mBounds.extent.y - mBounds.extent.y, mOrigBounds.point.y + deltaMousePosition.y));
      update = true;
   }

   if (update)
   {
      Point2I pos = parent->localToGlobalCoord(mBounds.point);
      root->addUpdateRegion(pos, mBounds.extent);
      resize(newPosition, newExtent);
   }
}

void GuiBitmapBorderCtrl::onMouseUp(const GuiEvent &event)
{
   event;
   mouseUnlock();
   
   mMouseMovingWin = false;   
}

void GuiBitmapBorderCtrl::onRender(Point2I offset, const RectI &updateRect)
{
   renderChildControls( offset, updateRect );
   dglSetClipRect(updateRect);

   //draw the outline
   RectI winRect;
   winRect.point = offset;
   winRect.extent = mBounds.extent;

	winRect.point.x += mBitmapBounds[BorderLeft].extent.x;
	winRect.point.y += mBitmapBounds[BorderTop].extent.y;

   winRect.extent.x -= mBitmapBounds[BorderLeft].extent.x + mBitmapBounds[BorderRight].extent.x;
   winRect.extent.y -= mBitmapBounds[BorderTop].extent.y + mBitmapBounds[BorderBottom].extent.y;

   if(mProfile->mOpaque)
      dglDrawRectFill(winRect, mProfile->mFillColor);

   dglClearBitmapModulation();
   dglDrawBitmapSR(mTextureHandle, offset, mBitmapBounds[BorderTopLeft]);
   dglDrawBitmapSR(mTextureHandle, Point2I(offset.x + mBounds.extent.x - mBitmapBounds[BorderTopRight].extent.x, offset.y),
                   mBitmapBounds[BorderTopRight]);

   RectI destRect;
   destRect.point.x = offset.x + mBitmapBounds[BorderTopLeft].extent.x;
   destRect.point.y = offset.y;
   destRect.extent.x = mBounds.extent.x - mBitmapBounds[BorderTopLeft].extent.x - mBitmapBounds[BorderTopRight].extent.x;
	destRect.extent.y = mBitmapBounds[BorderTop].extent.y;
   RectI stretchRect = mBitmapBounds[BorderTop];
   stretchRect.inset(1,0);
   dglDrawBitmapStretchSR(mTextureHandle, destRect, stretchRect);

   destRect.point.x = offset.x;
   destRect.point.y = offset.y + mBitmapBounds[BorderTopLeft].extent.y;
   destRect.extent.x = mBitmapBounds[BorderLeft].extent.x;
   destRect.extent.y = mBounds.extent.y - mBitmapBounds[BorderTopLeft].extent.y - mBitmapBounds[BorderBottomLeft].extent.y;
   stretchRect = mBitmapBounds[BorderLeft];
   stretchRect.inset(0,1);
   dglDrawBitmapStretchSR(mTextureHandle, destRect, stretchRect);

   destRect.point.x = offset.x + mBounds.extent.x - mBitmapBounds[BorderRight].extent.x;
   destRect.extent.x = mBitmapBounds[BorderRight].extent.x;
   destRect.point.y = offset.y + mBitmapBounds[BorderTopRight].extent.y;
   destRect.extent.y = mBounds.extent.y - mBitmapBounds[BorderTopRight].extent.y - mBitmapBounds[BorderBottomRight].extent.y;

	stretchRect = mBitmapBounds[BorderRight];
   stretchRect.inset(0,1);
   dglDrawBitmapStretchSR(mTextureHandle, destRect, stretchRect);

   dglDrawBitmapSR(mTextureHandle, offset + Point2I(0, mBounds.extent.y - mBitmapBounds[BorderBottomLeft].extent.y), mBitmapBounds[BorderBottomLeft]);
   dglDrawBitmapSR(mTextureHandle, offset + mBounds.extent - mBitmapBounds[BorderBottomRight].extent, mBitmapBounds[BorderBottomRight]);

   destRect.point.x = offset.x + mBitmapBounds[BorderBottomLeft].extent.x;
   destRect.extent.x = mBounds.extent.x - mBitmapBounds[BorderBottomLeft].extent.x - mBitmapBounds[BorderBottomRight].extent.x;

   destRect.point.y = offset.y + mBounds.extent.y - mBitmapBounds[BorderBottom].extent.y;
   destRect.extent.y = mBitmapBounds[BorderBottom].extent.y;
   stretchRect = mBitmapBounds[BorderBottom];
   stretchRect.inset(1,0);

   dglDrawBitmapStretchSR(mTextureHandle, destRect, stretchRect);
}
