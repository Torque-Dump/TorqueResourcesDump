//-----------------------------------------------------------------------------
// guiMapOverviewCtrl.cc
// Made by Thomas Larsen (StoneGroup)
//  
//-----------------------------------------------------------------------------
//
// Torque Engine
//
// Portions Copyright (c) 2001 by Sierra Online, Inc.
//
//-----------------------------------------------------------------------------

#include "console/console.h"
#include "console/consoleTypes.h"
#include "dgl/dgl.h"
#include "game/game.h"
#include "gui/controls/guiMapOverviewCtrl.h"
#include "game/missionArea.h"
#include "game/gameConnection.h"


IMPLEMENT_CONOBJECT(GuiMapOverviewCtrl);

GuiMapOverviewCtrl::GuiMapOverviewCtrl(void)
{
	mArea.set(0,0,0,0);

	mBounds.set(0, 0, 256, 256);

	mMyControlVisible = true;
	mPlayersVisible = true;
	mVehiclesVisible = true;
	
	mMyControlColor.set(1.00F,0.00F,0.00F,1.00F); // Red;
	mPlayersColor.set(0.00F,0.00F,1.00F,1.00F); // Blue
	mVehiclesColor.set(0.00F,1.00F,0.00F,1.00F); //Green

	mPointSize = 10.0;

	mMapAlpha = 1.0;
}

void GuiMapOverviewCtrl::initPersistFields()
{
	Parent::initPersistFields();

	addField("MyControlVisible", TypeBool, Offset(mMyControlVisible, GuiMapOverviewCtrl));
	addField("MyControlColor", TypeColorF, Offset(mMyControlColor, GuiMapOverviewCtrl));
	
	addField("PlayersVisible", TypeBool, Offset(mPlayersVisible, GuiMapOverviewCtrl));
	addField("PlayersColor", TypeColorF, Offset(mPlayersColor, GuiMapOverviewCtrl));
	
	addField("VehiclesVisible", TypeBool, Offset(mVehiclesVisible, GuiMapOverviewCtrl));
	addField("VehiclesColor", TypeColorF, Offset(mVehiclesColor, GuiMapOverviewCtrl));
	
	addField("MapAlpha", TypeF32, Offset(mMapAlpha, GuiMapOverviewCtrl));

	addField("PointSize", TypeF32, Offset(mPointSize, GuiMapOverviewCtrl));
}


void GuiMapOverviewCtrl::onRender(Point2I offset, const RectI &updateRect) 
{ 	
    // Must have a connection
    GameConnection* conn = GameConnection::getConnectionToServer();
    if (!conn) return;
    
	// Must have controlled object
    ShapeBase* control = conn->getControlObject();
    if (!control) return;
	
	const RectI &mArea = MissionArea::smMissionArea;

   	//Find distance from top-left corner to center of map image 
	Point2F center(mBounds.extent.x / 2,mBounds.extent.y / 2); 
	
	//Make center the UI object's coordinate center 
	center.x += mBounds.point.x; 
	center.y += mBounds.point.y; 

	F32 HWidth = mBounds.extent.x/2.0;
	F32 HHeight = mBounds.extent.y/2.0;

	glPushMatrix();
	glTranslatef(center.x, center.y, 0);  //  Center of Map Control
	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glColor4f(1.0, 1.0, 1.0, mMapAlpha);  //  Background transparency control

	
	// Draw Map
	if (mTextureHandle) {
		TextureObject* texture = (TextureObject *) mTextureHandle; 
		glBindTexture(GL_TEXTURE_2D, texture->texGLName);		
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);

		glBegin(GL_QUADS);
			glTexCoord2f(0, 0);  glVertex2f(-HWidth, -HHeight);
			glTexCoord2f(1, 0);  glVertex2f( HWidth, -HHeight);
			glTexCoord2f(1, 1);  glVertex2f( HWidth,  HHeight);
			glTexCoord2f(0, 1);  glVertex2f(-HWidth,  HHeight);
		glEnd();					
	
		glDisable(GL_TEXTURE_2D);
	
		glPushAttrib(GL_POINT_BIT);
		glEnable(GL_POINT_SMOOTH);

		glPointSize(mPointSize);		
		glBegin(GL_POINTS);


		Point3F MyControlCoord;
		bool RenderMyControl = false;

		// Go through all Ghosted Sim objects to find Vehicles and paint them first.		
		if (mMyControlVisible | mVehiclesVisible) {
            for (SimSetIterator itr(conn); *itr; ++itr) {
                // Make sure the shapebase object is a Vehicle object.			
				if ((*itr)->getType() & VehicleObjectType) {
                    ShapeBase* shape = static_cast<ShapeBase*>(*itr);
	
					// Get coords of object
					Point3F newCoord;   			    
					newCoord = shape->getPosition();

					bool InMissionArea = !( (newCoord.x < mArea.point.x) || (newCoord.x > mArea.point.x + mArea.extent.x) || 
						                    (newCoord.y < mArea.point.y) || (newCoord.y > mArea.point.y + mArea.extent.y) );

					if (InMissionArea) {
                        int x = (((newCoord.x - mArea.point.x) / mArea.extent.x) * mBounds.extent.x) -(mBounds.extent.x / 2);
				  		int y = mBounds.extent.y - (((newCoord.y - mArea.point.y) / mArea.extent.y) * mBounds.extent.y) -(mBounds.extent.y / 2);
		
						// If this is the controlling object then save position for it now.
						if (shape == control) {
							if (mMyControlVisible) {
								RenderMyControl = true;
								MyControlCoord.x = x; MyControlCoord.y = y;									
							}
						}
						
						if (mVehiclesVisible) {
							glColor4f(mVehiclesColor.red,mVehiclesColor.green,mVehiclesColor.blue,mVehiclesColor.alpha);
							glVertex2f(x,y);
						}
						
					}
				}
			}
		}

		glEnd();
		
		glPointSize(mPointSize - 2);						
		glBegin(GL_POINTS);

		// Go through all Ghosted Sim objects to find Players and paint them next.		
		if (mMyControlVisible | mPlayersVisible) {
			for (SimSetIterator itr(conn); *itr; ++itr) {
                // Make sure the shapebase object is a Player object.			
				if ((*itr)->getType() & PlayerObjectType) {
                    ShapeBase* shape = static_cast<ShapeBase*>(*itr);
	
					// Get coords of object
					Point3F newCoord;   			    
					newCoord = shape->getPosition();

					bool InMissionArea = !( (newCoord.x < mArea.point.x) || (newCoord.x > mArea.point.x + mArea.extent.x) || 
						                    (newCoord.y < mArea.point.y) || (newCoord.y > mArea.point.y + mArea.extent.y) );

					if (InMissionArea) {
                        int x = (((newCoord.x - mArea.point.x) / mArea.extent.x) * mBounds.extent.x) -(mBounds.extent.x / 2);
				  		int y = mBounds.extent.y - (((newCoord.y - mArea.point.y) / mArea.extent.y) * mBounds.extent.y) -(mBounds.extent.y / 2);

						// If this is the controlling object then save position for it now.
						if (shape == control) {
							if (mMyControlVisible) {
								RenderMyControl = true;
								MyControlCoord.x = x; MyControlCoord.y = y;									
							}
						}
						
						if (mPlayersVisible) {
							glColor4f(mPlayersColor.red,mPlayersColor.green,mPlayersColor.blue,mPlayersColor.alpha);
							glVertex2f(x,y);						
						}
					}
				}
			}
		}

		// Render MyControl as the last point.
		if (RenderMyControl) {            		
			// Get flashing Alpha level.
		    float FlashLevel = float(Platform::getRealMilliseconds() % 1000) / 1000;

			glColor4f(mMyControlColor.red, mMyControlColor.green, mMyControlColor.blue,FlashLevel);
			glVertex2f(MyControlCoord.x,MyControlCoord.y);
		}
		
		glEnd();
		glDisable(GL_BLEND);	
		
		glPopAttrib();		
	}  

	glPopMatrix();  //  Undo glTranslate

	renderChildControls(offset, updateRect); 
	
} 


