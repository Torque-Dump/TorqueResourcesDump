//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _GUIBITMAPSTORAGECTRL_H_
#define _GUIBITMAPSTORAGECTRL_H_

#ifndef _GUICONTROL_H_
#include "gui/core/guiControl.h"
#endif
#ifndef _GTEXMANAGER_H_
#include "dgl/gTexManager.h"
#endif

/// Renders a bitmap.
class GuiBitmapStorageCtrl : public GuiControl
{
private:
   typedef GuiControl Parent;

protected:
   StringTableEntry mBitmapName;
   U32 mBitmapIndex;
   U32 mNumBitmaps;
   TextureHandle mTextureHandle;
   Point2I startPoint;
   bool mWrap;
   RectI *mBitmapBounds;  //bmp is [3*n], bmpHL is [3*n + 1], bmpNA is [3*n + 2]

public:
   //creation methods
   DECLARE_CONOBJECT(GuiBitmapStorageCtrl);
   GuiBitmapStorageCtrl();
   static void initPersistFields();

   //Parental methods
   bool onWake();
   void onSleep();
   void inspectPostApply();

   virtual void setBitmap(const char *name,bool resize = false);
   virtual void setBitmap(const TextureHandle &handle,bool resize = false);
   //virtual void setBitmap(U32 index,bool resize = false);
   

   S32 getWidth() const       { return(mTextureHandle.getWidth()); }
   S32 getHeight() const      { return(mTextureHandle.getHeight()); }

   void onRender(Point2I offset, const RectI &updateRect);
   void setValue(S32 x, S32 y);
};

#endif
