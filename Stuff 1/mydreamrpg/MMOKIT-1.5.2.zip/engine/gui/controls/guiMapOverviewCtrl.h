//-----------------------------------------------------------------------------
// guiMapOverviewCtrl.cc
// Made by Thomas Larsen (Stonegroup)
//  
//-----------------------------------------------------------------------------
//
// Torque Engine
//
// Portions Copyright (c) 2001 by Sierra Online, Inc.
//
//-----------------------------------------------------------------------------

#ifndef _GuiMapOverviewCtrl_H_
#define _GuiMapOverviewCtrl_H_

#ifndef _GUIBITMAPCTRL_H_
#include "gui/controls/guiBitmapCtrl.h"
#endif

#ifndef _SCENEOBJECT_H_
#include "sim/sceneObject.h"
#endif

#ifndef _PLATFORMGL_H_

#include "platform/platformAssert.h"
#if defined(TORQUE_OS_MAC)
#include "platformMacCarb/platformGL.h"
#elif defined(TORQUE_OS_WIN32)
#include "platformWin32/platformGL.h"
#elif defined(TORQUE_OS_LINUX) || defined(TORQUE_OS_OPENBSD) || defined(TORQUE_OS_FREEBSD)
#include "platformX86UNIX/platformGL.h"
#endif

#endif

class GuiMapOverviewCtrl : public GuiBitmapCtrl
{
private:
	typedef GuiBitmapCtrl Parent;
	
	Point3F mMyCoords;

	RectI mArea;

	bool mMyControlVisible;
	bool mPlayersVisible;
	bool mVehiclesVisible;
	
	ColorF   mMyControlColor;
	ColorF   mPlayersColor;
	ColorF   mVehiclesColor;

	F32 mPointSize;

	F32 mMapAlpha;	
   
public:
	//creation methods
	DECLARE_CONOBJECT(GuiMapOverviewCtrl);
	GuiMapOverviewCtrl();
	static void initPersistFields();

	//Parental methods    
	void onRender(Point2I offset, const RectI &updateRect);		
};

#endif //_GuiMapOverviewCtrl_H_