
#include "console/consoleTypes.h"
#include "gui/controls/guiHotSpot.h"

IMPLEMENT_CONOBJECT(guiHotSpot);

guiHotSpot::guiHotSpot()
{
}

void guiHotSpot::onMouseDown(const GuiEvent &event)
{
	Parent::onMouseDown(event);
	Con::executef(this, 1, "onMouseDown");
}

void guiHotSpot::onSleep()
{
	Parent::onSleep();
}



//~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~//