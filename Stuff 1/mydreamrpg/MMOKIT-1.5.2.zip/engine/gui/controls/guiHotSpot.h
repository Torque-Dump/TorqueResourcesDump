
#ifndef _GUI_HOTSPOT_H_
#define _GUI_HOTSPOT_H_

#include "gui/core/guiTSControl.h"

class guiHotSpot : public GuiTSCtrl
{
private:
	typedef GuiTSCtrl Parent;

public:   
	/*C*/         guiHotSpot();

	virtual void  onMouseDown(const GuiEvent &event);
	virtual void  onSleep();

	DECLARE_CONOBJECT(guiHotSpot);
};

//~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~//~~~~~~~~~~~~~~~~~~~~~//

#endif //_GUI_HOTSPOT_H_
