//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
// This control Copyright (C) Dream Games, Inc.
// By Dave Young
//-----------------------------------------------------------------------------

#include "dgl/dgl.h"
#include "gui/core/guiControl.h"
#include "console/consoleTypes.h"
#include "game/gameConnection.h"
#include "game/shapeBase.h"

//-----------------------------------------------------------------------------
/// A basic listener control.
/// This control only works if a server connection exists and
/// it's control object is a PlayerObjectType, or the control is pointed at a shapebase. If
/// any of these requirements is false, the control is not rendered.
class GuiEffectListenerCtrl : public GuiControl
{
   typedef GuiControl Parent;

   bool	    mPlayerBound;
   bool    mEffectContainer;
   S32     mNumEffects;

public:
   GuiEffectListenerCtrl();

   void onRender( Point2I, const RectI &);
   static void initPersistFields();
   	//DreamRPG Effects
	bool isEffectContainer() { return mEffectContainer; } ///<Returns true if this control is an effect container/listener
	bool isPlayerBound() { return mPlayerBound; } ///<Returns true if this control listens to the control object
	void listenEffects();
	void setEffectContainer(bool isEffectContainer);
	void setPlayerBound(bool isPlayerBound);
	
	ShapeBase* mBoundPlayer;
	
   DECLARE_CONOBJECT( GuiEffectListenerCtrl );
};