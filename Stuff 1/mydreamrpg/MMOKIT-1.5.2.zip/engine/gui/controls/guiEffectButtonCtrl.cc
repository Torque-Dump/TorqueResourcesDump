//-----------------------------------------------------------------------------
// Torque Game Engine
//
// Copyright (c) 2001 GarageGames.Com
//-----------------------------------------------------------------------------
// guiEffectButton by Dave Young - Dream Games, Inc.
// developed for the MMOKIT based on BUIBITMAPBUTTON


//-------------------------------------
//
// Effect Button Control
// Set 'bitmap' console field to base name of bitmaps to use.  This control will
// append '_n' for normal
// append '_h' for hilighted
// append '_d' for depressed
//
// if bitmap cannot be found it will use the default bitmap to render.
//
// if the extent is set to (0,0) in the gui editor and appy hit, this control will
// set it's extent to be exactly the size of the normal bitmap (if present)
//


#include "console/console.h"
#include "dgl/dgl.h"
#include "console/consoleTypes.h"
#include "platform/platformAudio.h"
#include "gui/core/guiCanvas.h"
#include "gui/core/guiDefaultControlRender.h"
#include "gui/controls/guiEffectButtonCtrl.h"
#include "sceneGraph/sceneGraph.h"
#include "game/shapeBase.h"
#include "game/gameConnection.h"
#include "gui/core/guiControl.h"
#include "gui/core/guiTSControl.h"


IMPLEMENT_CONOBJECT(GuiEffectButtonCtrl);

//-------------------------------------
GuiEffectButtonCtrl::GuiEffectButtonCtrl()
{
   mBitmapName = StringTable->insert("");
   mBounds.extent.set(140, 30);
   mPlayerBound = true;
   mEffectIndex = -1;
   mPlayer = 0;
   mFirstRun = false;
}


//-------------------------------------
void GuiEffectButtonCtrl::initPersistFields()
{
   Parent::initPersistFields();
   addField("bitmap", TypeFilename, Offset(mBitmapName, GuiEffectButtonCtrl));
   addField("playerbound", TypeBool, Offset(mPlayerBound, GuiEffectButtonCtrl));
   addField( "player",   TypeSimObjectPtr, Offset( mPlayer, GuiEffectButtonCtrl ) );
   addField("rendertimer", TypeBool, Offset(mRenderTimer, GuiEffectButtonCtrl));
   addField("effectindex", TypeF32, Offset(mEffectIndex, GuiEffectButtonCtrl));
}


//-------------------------------------
bool GuiEffectButtonCtrl::onWake()
{
   if (! Parent::onWake())
      return false;
   setActive(true);
   setBitmap(mBitmapName);
   mEffectIndex = -1;
   mRenderTimer = false;
   return true;
}


//-------------------------------------
void GuiEffectButtonCtrl::onSleep()
{
   mEffectIndex = -1;
   mTextureNormal = NULL;
   mTextureHilight = NULL;
   mTextureDepressed = NULL;
   Parent::onSleep();
}


//-------------------------------------

ConsoleMethod( GuiEffectButtonCtrl, setBitmap, void, 3, 3, "(filepath name)")
{
   object->setBitmap(argv[2]);
}

ConsoleMethod( GuiEffectButtonCtrl, setEffectIndex, void, 3, 3, "(integer effectindex)")
{
   object->setEffectIndex(dAtoi(argv[2]));
}

ConsoleMethod( GuiEffectButtonCtrl, setPlayerBound, void, 3, 3, "(boolean playerbound)")
{
   object->setPlayerBound(dAtob(argv[2]));
}

ConsoleMethod( GuiEffectButtonCtrl, setRenderTimer, void, 3, 3, "(boolean rendertimer)")
{
   object->setRenderTimer(dAtob(argv[2]));
}

//-------------------------------------
void GuiEffectButtonCtrl::inspectPostApply()
{
   // if the extent is set to (0,0) in the gui editor and appy hit, this control will
   // set it's extent to be exactly the size of the normal bitmap (if present)
   Parent::inspectPostApply();

   if ((mBounds.extent.x == 0) && (mBounds.extent.y == 0) && mTextureNormal)
   {
      TextureObject *texture = (TextureObject *) mTextureNormal;
      mBounds.extent.x = texture->bitmapWidth;
      mBounds.extent.y = texture->bitmapHeight;
   }
}


//-------------------------------------
void GuiEffectButtonCtrl::setBitmap(const char *name)
{
   mBitmapName = StringTable->insert(name);
   if(!isAwake())
      return;

   if (*mBitmapName)
   {
      char buffer[1024];
      char *p;
      dStrcpy(buffer, name);
      p = buffer + dStrlen(buffer);

      mTextureNormal = TextureHandle(buffer, BitmapTexture, true);
      if (!mTextureNormal)
      {
      dStrcpy(p, "_n");
      mTextureNormal = TextureHandle(buffer, BitmapTexture, true);
      }
      dStrcpy(p, "_h");
      mTextureHilight = TextureHandle(buffer, BitmapTexture, true);
      if (!mTextureHilight)
         mTextureHilight = mTextureNormal;
      dStrcpy(p, "_d");
      mTextureDepressed = TextureHandle(buffer, BitmapTexture, true);
      if (!mTextureDepressed)
         mTextureDepressed = mTextureHilight;
      dStrcpy(p, "_i");
      mTextureInactive = TextureHandle(buffer, BitmapTexture, true);
      if (!mTextureInactive)
         mTextureInactive = mTextureNormal;
   }
   else
   {
      mTextureNormal = NULL;
      mTextureHilight = NULL;
      mTextureDepressed = NULL;
      mTextureInactive = NULL;
   }
   setUpdate();
}


//-------------------------------------
void GuiEffectButtonCtrl::setEffectIndex(U32 effectIndex)
{
   if(!isAwake())
      return;

   mEffectIndex = effectIndex;
   mFirstRun = false;

}
//-------------------------------------
void GuiEffectButtonCtrl::setPlayerBound(bool playerbound)
{
   if(!isAwake())
      return;

   mPlayerBound = playerbound;
   mFirstRun = false;

}


//-------------------------------------
void GuiEffectButtonCtrl::setRenderTimer(bool renderTimer)
{
   if(!isAwake())
      return;

   mRenderTimer = renderTimer;
   mFirstRun = false;

}

//-------------------------------------
void GuiEffectButtonCtrl::onRender(Point2I offset, const RectI& updateRect)
{

	//////Get the effect text to put into the tooltip////////////
	if(mEffectIndex==-1)
	   return;

	// Must have a connection and control object
	GameConnection* conn = GameConnection::getConnectionToServer();
	if (!conn)
		return;
	
	ShapeBase* control = conn->getControlObject();
	if (!control)
		return;

	if(!mPlayer && !mPlayerBound)
		return;
	ShapeBase* shape = NULL;

	if(mPlayerBound){
		shape = control;
	} else {
		shape = mPlayer;
	}

	char listbuff[128];
	listbuff[0] = 0;
	if (shape){
		if(mEffectIndex < shape->effects.size()){
			if(shape->effects.size() > 0){
				dStrcat(listbuff, (shape->effects[mEffectIndex]->effectName));
				mTooltip = shape->effects[mEffectIndex]->effectName;
				if(!mFirstRun){
					Con::executef(this, 3, "onEffectIndexChanged",shape->effects[mEffectIndex]->effectName);
					mFirstRun = true;
				}
			}
		}
	} else {
		return;
	}

   enum {
      NORMAL,
      HILIGHT,
      DEPRESSED,
      INACTIVE
   } state = NORMAL;

   if (mActive)
   {
      if (mMouseOver) state = HILIGHT;
      if (mDepressed || mStateOn) state = DEPRESSED;
   }
   else
      state = INACTIVE;

   switch (state)
   {
      case NORMAL:      renderButton(mTextureNormal, offset, updateRect); break;
      case HILIGHT:     renderButton(mTextureHilight ? mTextureHilight : mTextureNormal, offset, updateRect); break;
      case DEPRESSED:   renderButton(mTextureDepressed, offset, updateRect); break;
      case INACTIVE:    renderButton(mTextureInactive ? mTextureInactive : mTextureNormal, offset, updateRect); break;
   }
}





//------------------------------------------------------------------------------

void GuiEffectButtonCtrl::renderButton(TextureHandle &texture, Point2I &offset, const RectI& updateRect)
{
   if (texture)
   {
      RectI rect(offset, mBounds.extent);
      dglClearBitmapModulation();
      dglDrawBitmapStretch(texture, rect);

	   Point2I textPos = offset;
	   if(mDepressed)
		   textPos += Point2I(1,1);

	   // Make sure we take the profile's textOffset into account.
	   textPos += mProfile->mTextOffset;

	   dglSetBitmapModulation( mProfile->mFontColor );
	   renderJustifiedText(textPos, mBounds.extent, mButtonText);

      renderChildControls( offset, updateRect);
   }
   else
      Parent::onRender(offset, updateRect);
}

//------------------------------------------------------------------------------
IMPLEMENT_CONOBJECT(GuiEffectButtonTextCtrl);

void GuiEffectButtonTextCtrl::onRender(Point2I offset, const RectI& updateRect)
{

   enum {
      NORMAL,
      HILIGHT,
      DEPRESSED,
      INACTIVE
   } state = NORMAL;

   if (mActive)
   {
      if (mMouseOver) state = HILIGHT;
      if (mDepressed || mStateOn) state = DEPRESSED;
   }
   else
      state = INACTIVE;

   ColorI fontColor = mProfile->mFontColor;

   TextureHandle texture;

   switch (state)
   {
      case NORMAL:
         texture = mTextureNormal;
         fontColor = mProfile->mFontColor;
         break;
      case HILIGHT:
         texture = mTextureHilight;
         fontColor = mProfile->mFontColorHL;
         break;
      case DEPRESSED:
         texture = mTextureDepressed;
         fontColor = mProfile->mFontColorSEL;
         break;
      case INACTIVE:
         texture = mTextureInactive;
         fontColor = mProfile->mFontColorNA;
         if(!texture)
            texture = mTextureNormal;
         break;
   }
   if (texture)
   {

	//////Get the effect text////////////
	if(mEffectIndex==-1)
	   return;

	// Must have a connection and control object
	GameConnection* conn = GameConnection::getConnectionToServer();
	if (!conn)
		return;
	
	ShapeBase* control = conn->getControlObject();
	if (!control)
		return;

	if(!mPlayer && !mPlayerBound)
		return;
	ShapeBase* shape = NULL;

	if(mPlayerBound){
		shape = control;
	} else {
		shape = mPlayer;
	}

	char listbuff[128];
	listbuff[0] = 0;
	if (shape){
			if(mEffectIndex < shape->effects.size()){
				if(shape->effects.size() > 0){
				    dStrcat(listbuff, (shape->effects[mEffectIndex]->effectName));
					if(mRenderTimer && (!shape->effects[mEffectIndex]->continuous)){
						dStrcat(listbuff," ");
						//Con::errorf("Rendering Timer on %i",mEffectIndex);

					  char listbuff1[64];
					  F32 tTime = shape->effects[mEffectIndex]->timeLeft;
					  F32 secs = tTime / 1000.00;
					  U32 mins = secs / 60;
					  U32 secsfrommins = mins * 60;
					  U32 hours = mins / 60;
					  U32 minsfromhours = hours * 60;
					  mins = mins - minsfromhours;
					  U32 secsleft = secs - secsfrommins;

					  char* returnBuffer = Con::getReturnBuffer(32);

					  if(hours > 0){
						dSprintf(returnBuffer, 32, "%i", hours );
						dStrcat(listbuff1, returnBuffer);
						dStrcat(listbuff1, ":");
						if(mins < 1)
							dStrcat(listbuff1, "00:");
						if(secsleft < 1)
							dStrcat(listbuff1, "00");
					  }
					  if(mins > 0){
						dSprintf(returnBuffer, 32, "%i", mins );
						if (mins < 10)
							dStrcat(listbuff1, "0");
						dStrcat(listbuff1, returnBuffer);
						dStrcat(listbuff1, ":");
						if(secsleft < 1)
							dStrcat(listbuff1, "00");
					  }
					  if(secsleft > 0){
						dSprintf(returnBuffer, 32, "%i", secsleft );
						if (secsleft < 10)
							dStrcat(listbuff1, "0");
						dStrcat(listbuff1, returnBuffer);
						dStrcat(listbuff1, " ");
					  }
			  			dStrcat(listbuff,listbuff1);
					}
				}
		}
		this->setText(listbuff);
		mTooltip = this->getText();
		if(!mFirstRun){
			Con::executef(this, 3, "onEffectIndexChanged",shape->effects[mEffectIndex]->effectName);
			mFirstRun = true;
		}
	} else {
		return;
	}

	   /////////////////////////////////////


      RectI rect(offset, mBounds.extent);
      dglClearBitmapModulation();
      dglDrawBitmapStretch(texture, rect);

      Point2I textPos = offset;
      if(mDepressed)
         textPos += Point2I(1,1);

      // Make sure we take the profile's textOffset into account.
      textPos += mProfile->mTextOffset;

      dglSetBitmapModulation( fontColor );
      renderJustifiedText(textPos, mBounds.extent, listbuff);

      renderChildControls( offset, updateRect);
   }
   else
      Parent::onRender(offset, updateRect);
}

