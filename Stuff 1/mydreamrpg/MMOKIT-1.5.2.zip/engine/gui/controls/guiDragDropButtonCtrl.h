//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
// written by Jarred Schnelle, updated by Stefan "Beffy" Moises
//-----------------------------------------------------------------------------

#ifndef _GUIDRAGDROPBUTTONCTRL_H_
#define _GUIDRAGDROPBUTTONCTRL_H_

#ifndef _GUICONTROL_H_
#include "gui/core/guiControl.h"
#endif
#ifndef _GTEXMANAGER_H_
#include "dgl/gTexManager.h"
#endif

#ifndef _GUIMOUSEEVENTCTRL_H_
#include "gui/utility/guiMouseEventCtrl.h"
#endif



class GuiDragDropButtonCtrl : public GuiMouseEventCtrl
{
private:
	typedef GuiMouseEventCtrl Parent;
   bool mCanMove;          //Can the button your mouse clicks on move at all?
	bool mSnapsBack;        //Does the dragged icon snap back to where it was?
	bool mIsButtonMoving;   //Is the icon(source or copy) moving?
	bool mIsReceiver;       //Is this slot a receiver, as in, can it be written over? 
	bool mCopySource;       //Does this button create copies of itself to be placed, and remain where it is?
	bool mResetSourceOnDrop; //Do we want to clear out the source icon after we've droped it?
	bool mPerformActionOnUp;    //Do we want to perform an action on mouse up? Might not if it's for a power/skill menu
	bool mSwitchImages;     //Do we want it to switch the images between dropper / dropee ?
	SimGroup* mCurrentGroup;
	SimGroup* mTopLevelGroup;
	bool mChangedGroup;
	Point2I mMouseDownPosition;
	Point2I mMouseDownPositionOffset;
	Point2I mChangedGroupPosition;
	RectI mOrigBounds;
    
	//Used for displaying border around specific types of drag/drop icons
	ColorI mDropBorderSearchColor;
	ColorI mDropBorderColor; //Set by siblings
	bool mDropBorder;
	const char* mDropBorderType;
	const char* mDropBorderSearch;
	bool mDropBorderDisplayed; //Set by siblings


protected:
   StringTableEntry mBitmapName;
   StringTableEntry mHoverBitmapName;
   StringTableEntry mDownBitmapName;
   TextureHandle mTextureHandle;
   TextureHandle mNormalTextureHandle;
   TextureHandle mHoverTextureHandle;
   TextureHandle mDownTextureHandle;
   Point2I startPoint;
   bool mWrap;

   //Dream RPG Text on the DragDrop
   StringTableEntry mButtonText;
   StringTableEntry mButtonTextID;
   
public:
   //creation methods
   DECLARE_CONOBJECT(GuiDragDropButtonCtrl);
   GuiDragDropButtonCtrl();
   static void initPersistFields();
   static void consoleInit();

   //Parental methods
   bool onWake();
   void onSleep();

   void setBitmapName(const char *name);
   void setBitmapHandle(const TextureHandle &handle);

   void setHoverBitmapName(const char *name);
   void setHoverBitmapHandle(const TextureHandle &handle);
 
   void setDownBitmapName(const char *name);
   void setDownBitmapHandle(const TextureHandle &handle);

   //This is the actual graphic that is shown on the screen
   void setTextureHandle(const TextureHandle &handle);
      
   //Getter functions for assignment on MouseUp drop
   const TextureHandle getNormalHandle() {return mNormalTextureHandle;}
   const TextureHandle getHoverHandle() {return mHoverTextureHandle;}
   const TextureHandle getDownHandle() {return mDownTextureHandle;}
   const char *getNormalName() {return mBitmapName;}
   const char *getHoverName() {return mHoverBitmapName;}
   const char *getDownName() {return mDownBitmapName;}
   bool checkDropPosition(Point2I MouseUpPosition);

   S32 getWidth() const       { return(mTextureHandle.getWidth()); }
   S32 getHeight() const      { return(mTextureHandle.getHeight()); }

   void onRender(Point2I offset, const RectI &updateRect);
   void setValue(S32 x, S32 y);

   void resetContents();
   void onMouseEnter(const GuiEvent &);
   void onMouseLeave(const GuiEvent &);
   void onMouseDown(const GuiEvent &);
   void onMouseUp(const GuiEvent &);
   void onMouseDragged(const GuiEvent &);
   void onRightMouseDown(const GuiEvent &);
   void onRightMouseUp(const GuiEvent &);

   //Method to draw the dropable borders on drag
   void drawDropBorder(const char*, ColorI);
   void undoDrawDropBorder(const char*);
   void setDropBorderDisplayed(bool);
   void setDropBorderColor(ColorI);

   //Console setter functions
   void setCanMove(bool temp);
   void setIsReceiver(bool temp);
   void setSnapsBack(bool temp);
   void setDropBorder(bool temp);
   void setDropBorderSearchColor(int r, int g, int b);
   void setDropBorderSearchColor(int r, int g, int b, int a);
   void setDropBorderType(const char* temp);
   void setDropBorderSearch(const char* temp);
   
   //Public Getter Methods for Console Commands
   const bool getCanMove() {return mCanMove;}
   const bool getSnapsBack() {return mSnapsBack;}
   const bool getIsReceiver() {return mIsReceiver;}
   const bool getCopySource() {return mCopySource;}
   const bool getDropBorder() {return mDropBorder;}
   const char* getDropBorderType() {return mDropBorderType;}
   const char* getDropBorderSearch() {return mDropBorderSearch;}
   const ColorI getDropBorderSearchColor() {return mDropBorderSearchColor;}

   //Set our own onAction function, so that we may pass variables to the console
   //Doing this so we dont adversly affect the other GuiControls :)
   void onAction();

   //DreamRPG our text methods
   void setText(const char *text);
   void setTextID(S32 id);
   void setTextID(const char *id);
   const char *getText();
      
};

extern U32 DragDropArray[GuiControl::mDragDropArraySize];

#endif
