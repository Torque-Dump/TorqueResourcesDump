//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// guiEffectButton by Dave Young - Dream Games, Inc.
// developed for the MMOKIT based on BUIBITMAPBUTTON

#ifndef _GUIEFFECTBUTTON_H_
#define _GUIEFFECTBUTTON_H_

#ifndef _GUIBUTTONCTRL_H_
#include "gui/controls/guiButtonCtrl.h"
#endif
#ifndef _GTEXMANAGER_H_
#include "dgl/gTexManager.h"
#endif


#include "game/shapeBase.h"


///-------------------------------------
/// Effect Bitmap Button Contrl
/// Set 'bitmap' console field to base name of bitmaps to use.  This control will
/// append '_n' for normal
/// append '_h' for hilighted
/// append '_d' for depressed
///
/// if bitmap cannot be found it will use the default bitmap to render.
///
/// if the extent is set to (0,0) in the gui editor and apply hit, this control will
/// set it's extent to be exactly the size of the normal bitmap (if present)
///
class GuiEffectButtonCtrl : public GuiButtonCtrl
{
private:
   typedef GuiButtonCtrl Parent;

protected:
   StringTableEntry mBitmapName;
   TextureHandle mTextureNormal;
   TextureHandle mTextureHilight;
   TextureHandle mTextureDepressed;
   TextureHandle mTextureInactive;
   U32 mEffectIndex;
   bool mRenderSelf;
   bool mRenderTimer;
   ShapeBase* mPlayer;
   bool	    mPlayerBound;
   bool mFirstRun;

   void renderButton(TextureHandle &texture, Point2I &offset, const RectI& updateRect);
   void drawEffect(Point2I effectOffset, ShapeBase *shape, S32 levelDif, F32 opacity);

public:
   DECLARE_CONOBJECT(GuiEffectButtonCtrl);
   GuiEffectButtonCtrl();

   static void initPersistFields();

   //Parent methods
   bool onWake();
   void onSleep();
   void inspectPostApply();

   void setBitmap(const char *name);
   void setEffectIndex(U32 effectIndex);
   void setPlayerBound(bool playerbound);
   void setRenderTimer(bool renderTimer);

   void onRender(Point2I offset, const RectI &updateRect);
};

class GuiEffectButtonTextCtrl : public GuiEffectButtonCtrl
{
   typedef GuiEffectButtonCtrl Parent;
public:
   DECLARE_CONOBJECT(GuiEffectButtonTextCtrl);
   void onRender(Point2I offset, const RectI &updateRect);
};

#endif //_GUI_EFFECT_BUTTON_CTRL_H
