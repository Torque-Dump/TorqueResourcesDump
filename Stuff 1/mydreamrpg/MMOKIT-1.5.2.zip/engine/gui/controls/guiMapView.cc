// -------------------------
//     GuiMapView.cc
// Written by Peter Simard
// -------------------------

#include "guiMapView.h"
#include "console/console.h"
#include "console/consoleTypes.h"
#include "dgl/dgl.h"
#include "game/gameConnection.h"
#include "game/ShapeBase.h"
#include "core/fileObject.h"

IMPLEMENT_CONOBJECT(GuiMapView);
IMPLEMENT_CONOBJECT(PointOfInterest);

// Conversion function, (used to find the angle of the camera and angle of the object from the client)
float Vector3dToDegree(Point3F vector)
{
    float angle;
	if (vector.x == 0.0F)
    {
        if (vector.y > 0.0F)
            return 0.0F;
        else if (vector.y == 0.0F)
            return -1.0F;
        else
            return 180.0F;
    }
    if (vector.y == 0.0F)
    {
        if (vector.x < 0.0F)
            return 270.0F;
        else
            return 90.0F;
    }
    angle = atanf((vector.x) / (-vector.y)) * (180.0F / M_PI);
    if ((-vector.y) < 0.0F)
        return angle + 180.0F;
    else
    {
        if (vector.x > 0.0F)
            return angle;
        else
            return angle + 360.0F;
    }
}


// Conversion function, Degrees to vector (used after manipulating camera angle to represent angle of object on radar)
void DegreeToVector2d(float angle, float length, Point3F &vector)
{
	angle = (angle / 180.0F) * M_PI;
    vector.x = length * (sin(angle) );
	vector.y = length * (-cos(angle) );
}


PointOfInterest::PointOfInterest()
{
	isActive = false;
	temporary = false;
	bitmap = NULL;
	hoverBitmap  = NULL;
	extent.set(0, 0);
	position.set(0, 0);
	title = StringTable->insert("");
	description = StringTable->insert("");
}

void PointOfInterest::initPersistFields()
{
   Parent::initPersistFields();
   addGroup("misc");		 
	addField("position", TypePoint2I, Offset(position, PointOfInterest));  
	addField("title", TypeString, Offset(title, PointOfInterest));  
	addField("description", TypeString, Offset(description, PointOfInterest));  
   endGroup("misc");
}

GuiMapView::GuiMapView()
{
	mArrowBitmap = NULL;
	mArrowBitmapName = StringTable->insert("");
	mArrowOffset.set(100, 100);
	mTopLeftPos.set(0, 0);
	mBottomRightPos.set(0, 0);
	mPoiTitleFont = GFont::create("Arial Bold", 14, Con::getVariable("$GUI::fontCacheDirectory"));
}

void GuiMapView::initPersistFields()
{
   Parent::initPersistFields();
   addGroup("MapView");		
     addField("arrowBitmap", TypeFilename, Offset(mArrowBitmapName, GuiMapView));  
     addField("topLeftPos", TypePoint2I, Offset(mTopLeftPos, GuiMapView));  // The point in the mission that corresponds to top left corner of your map image
     addField("bottomRightPos", TypePoint2I, Offset(mBottomRightPos, GuiMapView));  // The point in the mission that corresponds to bottom right corner of your map image
   endGroup("MapView");		
}

ConsoleMethod( GuiMapView, addPointOfInterest, S32, 6, 7, "(bitmap, title, desc, offset)")
{
	Point2F offset;
	dSscanf(argv[5], "%f %f", &offset.x, &offset.y);
	
	return object->addPointOfInterest(argv[2], argv[3], argv[4], offset, argv[6], false)->getId();
}

ConsoleMethod( GuiMapView, addTempPointOfInterest, S32, 6, 7, "(bitmap, title, desc, offset)")
{
	Point2F offset;
	dSscanf(argv[5], "%f %f", &offset.x, &offset.y);
	
	return object->addPointOfInterest(argv[2], argv[3], argv[4], offset, argv[6], true)->getId();
}


ConsoleMethod( GuiMapView, getPointOfInterest, const char*, 3, 3, "()")
{
	PointOfInterest* poi = object->getPointOfInterest(dAtoi(argv[2]));
	if(!poi)
		return "0";
	char* poiStr = Con::getReturnBuffer(32);
	dSprintf(poiStr, sizeof(poiStr), "%i", poi->getId());
	return poiStr;
}

ConsoleMethod( GuiMapView, pointsOfInterestCount, S32, 2, 2, "()")
{
	return object->mPointsOfInterest.size();
}

PointOfInterest* GuiMapView::getPointOfInterest(U32 id)
{
	if(id < 0 || id > mPointsOfInterest.size()) 
		return NULL;

	return mPointsOfInterest[id];
}

ConsoleMethod( GuiMapView, empty, void, 2, 2, "()")
{
	object->clearPointsOfInterest();
}

ConsoleMethod( GuiMapView, savePointsOfInterest, void, 3, 3, "()")
{
	object->savePointsOfInterest(argv[2]);
}

// Clear the POI list
void GuiMapView::clearPointsOfInterest()
{
  	for(int x = 0; x < mPointsOfInterest.size(); x++)
	{
		delete mPointsOfInterest[x];
	}

	mPointsOfInterest.clear();
}

// Write the current non-temporary POIs to a file
void GuiMapView::savePointsOfInterest(const char* poiFileName)
{
   FileObject file;
   if ( !file.openForWrite( poiFileName ) )
   {
	   Con::warnf("unable to open file for write: %s", poiFileName);
      return;
   }

  	for(int x = 0; x < mPointsOfInterest.size(); x++)
	{
		PointOfInterest* poi = mPointsOfInterest[x];
		if(poi->temporary) // Do not save the temp POIs
			continue;
		char poiLine[1024];
		dSprintf(poiLine, sizeof(poiLine), "mapView.addPointOfInterest(\"%s\", \"%s\", \"%s\", \"%f %f\", \"%s\");", poi->bitmap.getName(), poi->title, poi->description, poi->position.x, poi->position.y, poi->hoverBitmap.getName()); 
		file.writeLine( (const U8*) poiLine);
	}

   file.close();
}

// Add a point of interest to the map
// Bitmap, Title, Description, Position, Hover Bitmap, Is Temporary
PointOfInterest* GuiMapView::addPointOfInterest(const char* bitmapName, const char* title, const char* description, Point2F position, const char* hoverBitmapName, bool temp)
{
	PointOfInterest* poi = new PointOfInterest();
	if(!poi->registerObject())
		return 0;

	poi->title = StringTable->insert(title);
	poi->description = StringTable->insert(description);
	poi->position = position;
	poi->temporary = temp;
	poi->bitmap = TextureHandle(bitmapName, BitmapKeepTexture, true);
	if(poi->bitmap)
	{
		poi->extent = Point2I(poi->bitmap.getWidth(), poi->bitmap.getWidth());
	}
	poi->hoverBitmap = TextureHandle(hoverBitmapName, BitmapKeepTexture, true);
	mPointsOfInterest.push_back(poi);

	return poi;
}

// Delete a POI from the list
void GuiMapView::removePoi(PointOfInterest* delPoi)
{
	if(!delPoi)
		return;

  	for(int x = 0; x < mPointsOfInterest.size(); x++)
	{
		PointOfInterest* poi = mPointsOfInterest[x];
		if(poi == delPoi)
		{
			mPointsOfInterest.erase(x);
			delete poi;
			return;
		}
	}
}

// Render all the POI bitmaps
void GuiMapView::renderPointsOfInterest(Point2I mapOffset)
{
	F32 mapWidth  = mBottomRightPos.x - mTopLeftPos.x; // Width of the mission
	F32 mapHeight = mTopLeftPos.y - mBottomRightPos.y; // Height of the mission
	PointOfInterest* activePoi = NULL; // The POI that youe mouse is hovered over

  	for(int x = 0; x < mPointsOfInterest.size(); x++)
	{
		PointOfInterest* poi = mPointsOfInterest[x];
		if(poi->bitmap)
		{
			// Calculate the GUI poisition of the POI bitmap using the mission coord
			F32 xOffset = (F32)(poi->position.x - mTopLeftPos.x) / mapWidth;
			F32 yOffset = (F32)(mTopLeftPos.y - poi->position.y) / mapHeight;
			xOffset *= mBounds.extent.x;
			yOffset *= mBounds.extent.y;
			xOffset -= (poi->extent.x / 2);
			yOffset -= (poi->extent.y / 2);
			Point2I poiOffset(xOffset, yOffset);
			poiOffset += mapOffset;

			RectI rect(poiOffset, poi->extent);
			if(poi->isActive && poi->hoverBitmap) {
				dglDrawBitmapStretch(poi->hoverBitmap, rect); // Draw hoverbitmap
			}
			else {
				dglDrawBitmapStretch(poi->bitmap, rect); // Draw regular bitmap
			}
			
			if(poi->isActive && (*poi->title))
			{
				activePoi = poi; // Save the active POI here, so we dont need to loop through the vector again
			}
		}
	}
	
	// Render the hoverover
	if(activePoi)
	{
		// Determine the hoverover position
		F32 xOffset = (F32)(activePoi->position.x - mTopLeftPos.x) / mapWidth;
		F32 yOffset = (F32)(mTopLeftPos.y - activePoi->position.y) / mapHeight;
		xOffset *= mBounds.extent.x;
		yOffset *= mBounds.extent.y;
		xOffset -= (activePoi->extent.x / 2);
		yOffset -= (activePoi->extent.y / 2);
		Point2I hoverCenter(xOffset, yOffset);
		hoverCenter += mapOffset;

		U32 titleWidth = mPoiTitleFont->getStrWidth(activePoi->title);
		U32 descWidth = 0;
		if(*activePoi->description)
		{
			descWidth = mPoiTitleFont->getStrWidth(activePoi->description);
		}
		
		Point2I hoverOffset((hoverCenter.x - ( (titleWidth > descWidth ? titleWidth : descWidth) / 2) - 2) , (*activePoi->description ? hoverCenter.y - 35 : hoverCenter.y - 25) );
		Point2I hoverExtent((titleWidth > descWidth ? titleWidth : descWidth) + 6, (*activePoi->description ? 27 : 17));

		if((hoverOffset.y - mapOffset.y) < 0)
			hoverOffset.y  = hoverCenter.y + 10;
		if((hoverOffset.y + hoverExtent.y) > getExtent().y + mapOffset.y)
			hoverOffset.y  = getExtent().y + mapOffset.y - hoverExtent.y  - 4;

		if((hoverOffset.x - mapOffset.x)< 0)
			hoverOffset.x = mapOffset.x + 4;
		if((hoverOffset.x + hoverExtent.x) > getExtent().x + mapOffset.x)
			hoverOffset.x  = getExtent().x + mapOffset.x - hoverExtent.x  - 4;

		RectI hoverRect(hoverOffset, hoverExtent);
		ColorI titleColor(230, 230, 80, 255);
		ColorI descColor(185, 185, 185, 255);
		ColorI fillColor(0, 0, 0, 155);
		ColorI borderColor(0, 0, 0, 255);
		dglDrawRectFill(hoverRect, fillColor);	
		dglDrawRect(hoverRect, fillColor);

		dglSetBitmapModulation(titleColor);
		dglDrawText(mPoiTitleFont, Point2I(hoverOffset.x + (hoverExtent.x / 2) - (titleWidth/2) + 1, hoverOffset.y + 1), activePoi->title);
		if(*activePoi->description)
		{
			dglSetBitmapModulation(descColor);
			dglDrawText(mPoiTitleFont, Point2I(hoverOffset.x + (hoverExtent.x / 2) - (descWidth/2) + 1, hoverOffset.y + 12), activePoi->description);
		}
		dglClearBitmapModulation();
	}
}

// When the mouse moves, see if you mouseover a POI
PointOfInterest* GuiMapView::findHitPoi(Point2I point)
{
	point = globalToLocalCoord(point);
	F32 mapWidth  = mBottomRightPos.x - mTopLeftPos.x;
	F32 mapHeight = mTopLeftPos.y - mBottomRightPos.y;
	for(int x = 0; x < mPointsOfInterest.size(); x++)
	{
		PointOfInterest* poi = mPointsOfInterest[x];

		F32 xOffset = (F32)(poi->position.x - mTopLeftPos.x) / mapWidth;
		F32 yOffset = (F32)(mTopLeftPos.y - poi->position.y) / mapHeight;
		xOffset *= mBounds.extent.x;
		yOffset *= mBounds.extent.y;
		xOffset -= (poi->extent.x / 2);
		yOffset -= (poi->extent.y / 2);
		Point2I poiOffset(xOffset, yOffset);

		if(point.x > (poiOffset.x) && point.y > (poiOffset.y) && point.x < (poi->extent.x  + (poiOffset.x)) && point.y < (poi->extent.y + (poiOffset.y)))
		{
			return poi;
		}
	}
	return NULL;
}

void GuiMapView::onMouseLeave(const GuiEvent& evt)
{
	for(int x = 0; x < mPointsOfInterest.size(); x++)
	{
		PointOfInterest* poi = mPointsOfInterest[x];
		poi->isActive = false;
	}
}

void GuiMapView::onMouseMove(const GuiEvent& evt)
{
	for(int x = 0; x < mPointsOfInterest.size(); x++)
	{
		PointOfInterest* poi = mPointsOfInterest[x];
		poi->isActive = false;
	}

	PointOfInterest* poi = findHitPoi(evt.mousePoint);
	if(!poi)
		return;

	poi->isActive = true;
}

void GuiMapView::setArrowBitmap()
{
	if(*mArrowBitmapName)
	{
		mArrowBitmap = TextureHandle(mArrowBitmapName, BitmapKeepTexture, true);
	}
}

bool GuiMapView::onWake()
{
	Parent::onWake();
	setArrowBitmap();

	return true;
}

// GUI bitmap render code. Will render the map, arrow, and POIs
void GuiMapView::onRender(Point2I offset, const RectI &updateRect)
{
	 // BASE BITMAP RENDER CODE
	dglClearBitmapModulation();
	if (mTextureHandle)
	{
		if(mWrap)
		{
 			TextureObject* texture = (TextureObject *) mTextureHandle;
			RectI srcRegion;
			RectI dstRegion;
			float xdone = ((float)mBounds.extent.x/(float)texture->bitmapWidth)+1;
			float ydone = ((float)mBounds.extent.y/(float)texture->bitmapHeight)+1;

			int xshift = startPoint.x%texture->bitmapWidth;
			int yshift = startPoint.y%texture->bitmapHeight;
			for(int y = 0; y < ydone; ++y)
				for(int x = 0; x < xdone; ++x)
				{
		 			srcRegion.set(0,0,texture->bitmapWidth,texture->bitmapHeight);
  					dstRegion.set( ((texture->bitmapWidth*x)+offset.x)-xshift,
								      ((texture->bitmapHeight*y)+offset.y)-yshift,
								      texture->bitmapWidth,	
								      texture->bitmapHeight);
   					dglDrawBitmapStretchSR(texture,dstRegion, srcRegion, false);
				}
		}
		else
		{
         RectI rect(offset, mBounds.extent);
	      dglDrawBitmapStretch(mTextureHandle, rect);
		}
   }

   if (mProfile->mBorder || !mTextureHandle)
   {
      RectI rect(offset.x, offset.y, mBounds.extent.x, mBounds.extent.y);
      dglDrawRect(rect, mProfile->mBorderColor);
   }

    // --------------
    // MAP RENDER CODE
    // --------------

	renderPointsOfInterest(offset);
	
	if(mArrowBitmap)
	{
		mArrowOffset = calcArrowOffset();
		Point2I arrowOffset = mArrowOffset;
		arrowOffset.x += offset.x - (mArrowBitmap.getWidth() / 2);
		arrowOffset.y += offset.y - (mArrowBitmap.getHeight() / 2);
		RectI arrowBounds(arrowOffset.x, arrowOffset.y, mArrowBitmap.getWidth(), mArrowBitmap.getHeight());
		RectI arrowSourceBounds(0, 0, mArrowBitmap.getWidth(), mArrowBitmap.getHeight());

		GameConnection* conn = GameConnection::getConnectionToServer();
		if(!conn) {
			return;
		}

		ShapeBase* control = conn->getControlObject();

		if(!control) {
			return;
		}
		
		Point3F cameraRot;
		MatrixF cam = control->getTransform(); // get camera transform
		cam.getRow(1,&cameraRot); // get camera rotation
		float cameraAngle = Vector3dToDegree(cameraRot); // Convert into Degrees

		dglDrawBitmapRotated(mArrowBitmap, arrowBounds, arrowSourceBounds, 0, -cameraAngle); // Draw the rotated angle
	}

   renderChildControls(offset, updateRect);
}

// Determine the position of the arrow
Point2I GuiMapView::calcArrowOffset()
{
	Point2I offset(mBounds.extent / 2); // Default to the center

    GameConnection* conn = GameConnection::getConnectionToServer();
	if(!conn) {
		return offset;
	}

	ShapeBase* control = conn->getControlObject();
	if(!control) {
		return offset;
	}

	Point3F pos = control->getPosition();
	if(pos.x < mTopLeftPos.x || pos.x > mBottomRightPos.x || pos.y < mBottomRightPos.y || pos.y > mTopLeftPos.y)
	{
		return offset; // Return the center if your outside of the map
	}
	
	U32 width  = mBottomRightPos.x - mTopLeftPos.x;
	U32 height = mTopLeftPos.y - mBottomRightPos.y;

	F32 xOffset = (pos.x - mTopLeftPos.x) / width;
	F32 yOffset = (mTopLeftPos.y - pos.y) / height;
	xOffset *= mBounds.extent.x;
	yOffset *= mBounds.extent.y;
	offset.set(xOffset, yOffset);

	return offset;
}