////////////////////////////
//     GuiMapView.h
// Written by Peter Simard
////////////////////////////

/// Map view control

#ifndef _MAPVIEW_H_
#define _MAPVIEW_H_

#include "guiBitmapCtrl.h"

// Point of Interest class
class PointOfInterest : public SimObject
{
   typedef SimObject Parent;

public:
    DECLARE_CONOBJECT(PointOfInterest);
    Point2I		    extent;
	Point2F		    position;
	TextureHandle	bitmap;
	TextureHandle	hoverBitmap;
	bool			isActive;
	bool			temporary;

	StringTableEntry title;
	StringTableEntry description;
	PointOfInterest();
   
   static void initPersistFields();
};

// The main MapView GUI
class GuiMapView : public GuiBitmapCtrl
{
private:
   typedef GuiBitmapCtrl Parent;

   TextureHandle			mArrowBitmap;
   StringTableEntry			mArrowBitmapName;
   Point2I					mArrowOffset;
   Point2I					mTopLeftPos; // The point in the mission that corresponds to top left corner of your map image
   Point2I					mBottomRightPos; // The point in the mission that corresponds to bottom right corner of your map image
   Resource<GFont>			mPoiTitleFont;


public:
   DECLARE_CONOBJECT(GuiMapView);
   GuiMapView();
   bool onWake();
   void onRender(Point2I offset, const RectI &updateRect);
   Vector<PointOfInterest*>  mPointsOfInterest;
   void				savePointsOfInterest(const char* fileName);
   void				clearPointsOfInterest();
   PointOfInterest* getPointOfInterest(U32 id);
   void				onMouseLeave(const GuiEvent& evt);
   void				onMouseMove(const GuiEvent& evt);
   PointOfInterest* GuiMapView::findHitPoi(Point2I point);
   Point2I			calcArrowOffset();
   void				setArrowBitmap();
   void				renderPointsOfInterest(Point2I mapOffset);
   PointOfInterest*				addPointOfInterest(const char* bitmapName, const char* title, const char* description, Point2F offset, const char* hoverBitmapName, bool temp);
   void				removePoi(PointOfInterest* delPoi);
   
   static void initPersistFields();
};

#endif