//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _MEMSTREAM_H_
#define _MEMSTREAM_H_

//Includes
#ifndef _STREAM_H_
#include "core/stream.h"
#endif

class MemStream : public Stream {
   typedef Stream Parent;

  protected:
  U32 cm_bufferSize;
   void*  m_pBufferBase;

   U32 m_instCaps;
   U32 m_currentPosition;

  public:
  MemStream(){};	
   MemStream(const U32  in_bufferSize,
             void*      io_pBuffer,
             const bool in_allowRead  = true,
             const bool in_allowWrite = true);
   ~MemStream();

   // Mandatory overrides from Stream
  protected:
   bool _read(const U32 in_numBytes,  void* out_pBuffer);
   bool _write(const U32 in_numBytes, const void* in_pBuffer);
  public:
   bool hasCapability(const Capability) const;
   U32  getPosition() const;
   bool setPosition(const U32 in_newPosition);

   // Mandatory overrides from Stream
  public:
   U32  getStreamSize();
};

class DynMemStream : public MemStream {
	typedef MemStream Parent;
	
	protected:
		U32 m_blockSize;	///< Chunk size for new allocations
		U32 m_writSize;	///< Bytes we have written
	
	public:
		DynMemStream(const U32  in_blockSize, 
			
				const bool in_allowRead  = true, 
				const bool in_allowWrite = true);
		~DynMemStream();

		U32 getStreamSize() {return m_writSize;}
		U8 *getData() {return (U8*)m_pBufferBase;}
	protected:
		bool _write(const U32 in_numBytes, const void* in_pBuffer);
};


#endif //_MEMSTREAM_H_
