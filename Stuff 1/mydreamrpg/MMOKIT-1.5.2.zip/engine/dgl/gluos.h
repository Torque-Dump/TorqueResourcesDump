/*
** gluos.h - operating system dependencies for GLU
**
** $Header: /cvsroot/mesa3d/Mesa/si-glu/include/gluos.h,v 1.4 2002/10/04 15:58:33 kschultz Exp $
**

/* 
  License Applicability. Except to the extent portions of this file are made 
  subject to an alternative license as permitted in the SGI Free Software 
  License B, Version 1.1 (the "License"), the contents of this file are subject
  only to the provisions of the License. You may not use this file except in 
  compliance with the License. You may obtain a copy of the License at Silicon 
  Graphics, Inc., attn: Legal Services, 1600 Amphitheatre Parkway, Mountain 
  View, CA 94043-1351, or at:
  
  http://oss.sgi.com/projects/FreeB

  Note that, as provided in the License, the Software is distributed on an 
  "AS IS" basis, with ALL EXPRESS AND IMPLIED WARRANTIES AND CONDITIONS 
  DISCLAIMED, INCLUDING, WITHOUT LIMITATION, ANY IMPLIED WARRANTIES AND 
  CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR
  PURPOSE, AND NON-INFRINGEMENT.

  Original Code. The Original Code is: OpenGL Sample Implementation v1.3 
  (8/7/2000), developed by Silicon Graphics, Inc. The Original Code is 
  Copyright (c) Silicon Graphics, Inc. Copyright in any portions created by 
  third parties is as indicated elsewhere herein. All Rights Reserved.
*/

#ifdef __VMS
#ifdef __cplusplus 
#pragma message disable nocordel
#pragma message disable codeunreachable
#pragma message disable codcauunr
#endif
#endif

#ifdef _WIN32
#include <stdlib.h>         /* For _MAX_PATH definition */
#include <stdio.h>
#include <malloc.h>

#define WIN32_LEAN_AND_MEAN
#define NOGDI
#define NOIME
#define NOMINMAX

#define _WIN32_WINNT 0x0400
#ifndef STRICT
  #define STRICT 1
#endif

#include <windows.h>

/* Disable warnings */
#pragma warning(disable : 4101)
#pragma warning(disable : 4244)
#pragma warning(disable : 4761)

#if defined(_MSC_VER) && _MSC_VER >= 1200
#pragma comment(linker, "/OPT:NOWIN98")
#endif

#else

/* Disable Microsoft-specific keywords */
#define GLAPIENTRY
#define WINGDIAPI

#endif
