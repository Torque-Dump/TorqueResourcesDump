// glu.h: selected GLU source ported to Torque by James "Corvidae" Williams, 2/21/2003

/* 
  License Applicability. Except to the extent portions of this file are made 
  subject to an alternative license as permitted in the SGI Free Software 
  License B, Version 1.1 (the "License"), the contents of this file are subject
  only to the provisions of the License. You may not use this file except in 
  compliance with the License. You may obtain a copy of the License at Silicon 
  Graphics, Inc., attn: Legal Services, 1600 Amphitheatre Parkway, Mountain 
  View, CA 94043-1351, or at:
  
  http://oss.sgi.com/projects/FreeB

  Note that, as provided in the License, the Software is distributed on an 
  "AS IS" basis, with ALL EXPRESS AND IMPLIED WARRANTIES AND CONDITIONS 
  DISCLAIMED, INCLUDING, WITHOUT LIMITATION, ANY IMPLIED WARRANTIES AND 
  CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR
  PURPOSE, AND NON-INFRINGEMENT.

  Original Code. The Original Code is: OpenGL Sample Implementation v1.3 
  (8/7/2000), developed by Silicon Graphics, Inc. The Original Code is 
  Copyright (c) Silicon Graphics, Inc. Copyright in any portions created by 
  third parties is as indicated elsewhere herein. All Rights Reserved.
*/

//Includes
#ifndef _PLATFORM_H_
#include "platform/platform.h"
#endif

#ifndef _GLU_H
#define _GLU_H
#include <stdlib.h>         /* For _MAX_PATH definition */
#include <stdio.h>
#if defined(TORQUE_OS_MAC)
#include <malloc/malloc.h>
#include "gluos.h"
#else
#include <malloc.h>
#endif
#include "math.h"
#include "dgl.h"


#define COS cos
#define SIN sin
#define SQRT sqrt

#define CACHE_SIZE	240

#ifndef PI 
#define PI            3.14159265358979323846
#endif

struct GLUquadric {
    GLint 	normals;
    GLboolean	textureCoords;
    GLint	orientation;
    GLint	drawStyle;
    void (GLAPIENTRY *errorCallback)( GLint );
};
typedef struct GLUquadric GLUquadricObj;


/****           Generic constants               ****/

/* Version */
#define GLU_VERSION_1_1                 1
#define GLU_VERSION_1_2                 1

/* Errors: (return value 0 = no error) */
#define GLU_INVALID_ENUM        100900
#define GLU_INVALID_VALUE       100901
#define GLU_OUT_OF_MEMORY       100902
#define GLU_INCOMPATIBLE_GL_VERSION     100903

/* StringName */
#define GLU_VERSION             100800
#define GLU_EXTENSIONS          100801

/* Boolean */
#define GLU_TRUE                GL_TRUE
#define GLU_FALSE               GL_FALSE

/****           Quadric constants               ****/

/* QuadricNormal */
#define GLU_SMOOTH              100000
#define GLU_FLAT                100001
#define GLU_NONE                100002

/* QuadricDrawStyle */
#define GLU_POINT               100010
#define GLU_LINE                100011
#define GLU_FILL                100012
#define GLU_SILHOUETTE          100013

/* QuadricOrientation */
#define GLU_OUTSIDE             100020
#define GLU_INSIDE              100021

/* Callback types: */
/*      GLU_ERROR               100103 */



GLUquadric * GLAPIENTRY gluNewQuadric(void);
void GLAPIENTRY gluDeleteQuadric(GLUquadric *state);
static void gluQuadricError(GLUquadric *qobj, GLenum which);
//void GLAPIENTRY gluQuadricCallback(GLUquadric *qobj, GLenum which, _GLUfuncptr fn);
void GLAPIENTRY gluQuadricNormals(GLUquadric *qobj, GLenum normals);
void GLAPIENTRY gluQuadricTexture(GLUquadric *qobj, GLboolean textureCoords);
void GLAPIENTRY gluQuadricOrientation(GLUquadric *qobj, GLenum orientation);
void GLAPIENTRY gluQuadricDrawStyle(GLUquadric *qobj, GLenum drawStyle);
void GLAPIENTRY gluDisk(GLUquadric *qobj, GLdouble innerRadius, GLdouble outerRadius, GLint slices, GLint loops);
void GLAPIENTRY gluPartialDisk(GLUquadric *qobj, GLdouble innerRadius, GLdouble outerRadius, GLint slices, GLint loops, GLdouble startAngle, GLdouble sweepAngle);
void GLAPIENTRY gluSphere(GLUquadric *qobj, GLdouble radius, GLint slices, GLint stacks);
#endif
