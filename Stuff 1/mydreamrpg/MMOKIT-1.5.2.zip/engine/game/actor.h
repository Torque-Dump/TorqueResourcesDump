//-----------------------------------------------------------------------------
// derived from Actor.h which bore this copyright notice
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _ACTOR_H_
#define _ACTOR_H_

// an Actor is a game avatar which combines into a single C++ class the combined functionality
// of TGE's Player and Actor.  That is to say, this is an in-game entity whose behavior
// can be directed by a game client connection (a GameConnection?) or by AI scripts (over an AIConnection?)

#ifndef _PLAYER_H_
#include "game/player.h"
#endif


class Actor : public Player {

	typedef Player Parent;

public:
	enum MoveState {
		ModeStop,
		ModeMove,
		ModeStuck,
	};


private:
		MoveState mMoveState;
		F32 mMoveSpeed;
		F32 mMoveTolerance;                 // Distance from destination before we stop
		Point3F mMoveDestination;           // Destination for movement
		Point3F mLastLocation;              // For stuck check
		bool mMoveSlowdown;                 // Slowdown as we near the destination
		SimObjectPtr<GameBase> mMoveObject;// Object to move to
		SimObjectPtr<GameBase> mAimObject; // Object to point at, overrides location
		bool mAimLocationSet;               // Has an aim location been set?
		Point3F mAimLocation;               // Point to look at
		bool mTargetInLOS;                  // Is target object visible?
		
		Point3F mAimOffset;

      // Utility Methods
      void throwCallback( const char *name );

public:
		DECLARE_CONOBJECT( Actor );

		Actor();
      ~Actor();

		virtual bool getAIMove( Move *move );

		// Targeting and aiming sets/gets
		void setAimObject( GameBase *targetObject );
      		void setAimObject( GameBase *targetObject, Point3F offset );
		GameBase* getAimObject() const  { return mAimObject; }

		//DreamRPG AI help
		void setMoveObject( GameBase *targetObject );
		GameBase* getMoveObject() const  { return mMoveObject; }

		void setAimLocation( const Point3F &location );
		Point3F getAimLocation() const { return mAimLocation; }
		void clearAim();

		// Movement sets/gets
		void setMoveSpeed( const F32 speed );
		F32 getMoveSpeed() const { return mMoveSpeed; }
		void setMoveTolerance( const F32 tolerance );
		F32 getMoveTolerance() const { return mMoveTolerance; }
		void setMoveDestination( const Point3F &location, bool slowdown );
		Point3F getMoveDestination() const { return mMoveDestination; }
		void stopMove();

		// TONE added these to AIPlayer's code
		bool isAIControlled();		// is this Actor under AI control?
		bool isPlayerControlled();  // is a player controlling this Actor (by a game client)
};

#endif
