
//-----------------------------------------------------------------------------
// With the Fleet
// Copyright (C) Anthony Lovell
//-----------------------------------------------------------------------------

#ifndef _ACTORCONNECTION_H_
#define _ACTORCONNECTION_H_

#ifndef _GAMECONNECTION_H_
#include "game/gameConnection.h"
#endif
#ifndef _MOVEMANAGE_H_
#include "game/moveManager.h"
#endif

//-----------------------------------------------------------------------------

// this class is meant to combine the functionality of the original TGE GameConnection
// and the AIConnection

class ActorConnection : public GameConnection 
{
   typedef GameConnection Parent;

private:   
	// this is the single Move that can be set and acted upon when the connection is 
	// AI controlled (the behavior supported by the old AIConnection)
   Move mAIMove;   

public:
	// this permits the AI/non-AI nature of the NetConnection to be changed, unlike 
	// in the old GameConnection (mAIControlled = false) and AIConnection (mAIControlled = true) days
	void setAIControlled(bool b) { mAIControlled = b; };

	void setAIMove(Move* m);
	const Move& getAIMove();
	void  getMoveList(Move**,U32* numMoves); // borrowed from

   static ActorConnection *getConnectionToServer() { return dynamic_cast<ActorConnection*>((NetConnection *) mServerConnection); }
   static ActorConnection *getLocalClientConnection() { return dynamic_cast<ActorConnection*>((NetConnection *) mLocalClientConnection); }

   ActorConnection();
   DECLARE_CONOBJECT( ActorConnection );
};


#endif
