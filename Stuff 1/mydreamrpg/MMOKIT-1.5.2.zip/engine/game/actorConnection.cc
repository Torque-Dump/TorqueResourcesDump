//-----------------------------------------------------------------------------
// adapted from AIConnection.cc, which bore this copyright notice
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "actorConnection.h"

IMPLEMENT_CONOBJECT( ActorConnection );


//-----------------------------------------------------------------------------

ActorConnection::ActorConnection() {   
   mAIMove = NullMove;
}




void ActorConnection::setAIMove(Move* m)
{
   mAIMove = *m;
}

const Move& ActorConnection::getAIMove()
{
   return mAIMove;
}   




/// Retrieve the pending moves
/**
 * The GameConnection base class queues moves for delivery to the
 * control object.  This function is normally used to retrieve the
 * queued moves received from the client.  An AI actor does not
 * have a connected client and simply generates moves on-the-fly
 * base on its current state.
 */
void ActorConnection::getMoveList( Move **lngMove, U32 *numMoves )
{
	if (mAIControlled) {
		*numMoves = 1;
		*lngMove = &mAIMove;
	} else
		GameConnection::getMoveList(lngMove, numMoves);
}



//-----------------------------------------------------------------------------
// Console functions & methods
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------


static inline F32 moveClamp(F32 v)
{
   // Support function to convert/clamp the input into a move rotation
   // which only allows 0 -> M_2PI.
   F32 a = mClampF(v,-M_PI,M_PI);
   return (a < 0)? a + M_2PI: a;
}


//-----------------------------------------------------------------------------
/// Construct and connect an actor connection object, placing it in AI mode at the outset
ConsoleFunction(makeAIConnection, S32 , 2, 20, "(...)"
                "Make a new ActorConnection, and pass arguments to the onConnect script callback.")
{
   // Create the connection
   ActorConnection *aConnection = new ActorConnection();
   aConnection->registerObject();
   aConnection->setAIControlled(true);
   
   // Add the connection to the client group
   SimGroup *g = Sim::getClientGroup();
   g->addObject(aConnection);

   // Prep the arguments for the console exec...
   // Make sure and leav args[1] empty.
   const char* args[21];
   args[0] = "onConnect";
   for (S32 i = 1; i < argc; i++)
      args[i + 1] = argv[i];

   // Execute the connect console function, this is the same 
   // onConnect function invoked for normal client connections
   Con::execute(aConnection, argc + 1, args);
   return aConnection->getId();
}


//-----------------------------------------------------------------------------
ConsoleMethod(ActorConnection,setAIMove,void,4, 4,"(string field, float value)"
              "Set a field on the current move.\n\n"
              "@param   field One of {'x','y','z','yaw','pitch','roll'}\n"
              "@param   value Value to set field to.")
{
   Move move = object->getAIMove();

   // Ok, a little slow for now, but this is just an example..
   if (!dStricmp(argv[2],"x"))
      move.x = mClampF(dAtof(argv[3]),-1,1);
      else
   if (!dStricmp(argv[2],"y"))
      move.y = mClampF(dAtof(argv[3]),-1,1);
      else
   if (!dStricmp(argv[2],"z"))
      move.z = mClampF(dAtof(argv[3]),-1,1);
      else
   if (!dStricmp(argv[2],"yaw"))
      move.yaw = moveClamp(dAtof(argv[3]));
      else
   if (!dStricmp(argv[2],"pitch"))
      move.pitch = moveClamp(dAtof(argv[3]));
      else
   if (!dStricmp(argv[2],"roll"))
      move.roll = moveClamp(dAtof(argv[3]));

   //
   object->setAIMove(&move);
}

ConsoleMethod(ActorConnection,getAIMove,F32,3, 3,"(string field)"
              "Get the given field of a move.\n\n"
              "@param field One of {'x','y','z','yaw','pitch','roll'}\n"
              "@returns The requested field on the current move (in AI mode).")
{
   const Move& move = object->getAIMove();
   if (!dStricmp(argv[2],"x"))
      return move.x;
   if (!dStricmp(argv[2],"y"))
      return move.y;
   if (!dStricmp(argv[2],"z"))
      return move.z;
   if (!dStricmp(argv[2],"yaw"))
      return move.yaw;
   if (!dStricmp(argv[2],"pitch"))
      return move.pitch;
   if (!dStricmp(argv[2],"roll"))
      return move.roll;
   return 0;
}


ConsoleMethod(ActorConnection,setFreeLook,void,3, 3,"(bool isFreeLook)"
              "Enable/disable freelook on the current move (in AI mode).")
{
   Move move = object->getAIMove();
   move.freeLook = dAtob(argv[2]);
   object->setAIMove(&move);
}

ConsoleMethod(ActorConnection,getFreeLook,bool,2, 2,"getFreeLook()"
              "Is freelook on for the current move (in AI mode)?")
{
   return object->getAIMove().freeLook;
}

// TONE added this so a given connection can be asked whether it is 
// behaving as the old AIConnections did, or as the old GameConnections did
ConsoleMethod(ActorConnection,isInAIMode,bool,2, 2,"isInAIMode()"
              "is this connection in AI mode?")
{
	return object->isAIControlled();
}

// TONE added this so a given connection can be asked whether it is 
// behaving as the old AIConnections did, or as the old GameConnections did
ConsoleMethod(ActorConnection,setAIMode,void ,3, 3,"setAIMode(bool)"
              "")
{
	bool b = dAtob(argv[2]);    
	object->setAIControlled(b);
}




//-----------------------------------------------------------------------------

ConsoleMethod(ActorConnection,setTrigger,void,4, 4,"(int trigger, bool set)"
              "Set a trigger.")
{
   S32 idx = dAtoi(argv[2]);
   if (idx >= 0 && idx < MaxTriggerKeys)  {
      Move move = object->getAIMove();
      move.trigger[idx] = dAtob(argv[3]);
      object->setAIMove(&move);
   }
}

ConsoleMethod(ActorConnection,getTrigger,bool,4, 4,"(int trigger)"
              "Is the given trigger set?")
{
   S32 idx = dAtoi(argv[2]);
   if (idx >= 0 && idx < MaxTriggerKeys)
      return object->getAIMove().trigger[idx];
   return false;
}


// TONE -- I am not completely sure about this
// I tried to make this behave as GameConnection did when !mAIControlled 
// and as AIConnection did otherwise
//-----------------------------------------------------------------------------
ConsoleMethod(ActorConnection,getAddress,const char*,2, 2,"")
{
   // Override the NetConnection method to return to indicate
   // this is a local connection.
	if (object->isAIControlled()) {
		// this was the behavior of AIConnection
	  return "ai:local";
	} else {
	   // this code copied from NetConnection's version of this 
		// (GameConnection did not have its own logic)
	   argc; argv;
	if(object->isLocalConnection())
		return "local";
	char *buffer = Con::getReturnBuffer(256);
	Net::addressToString(object->getNetAddress(), buffer);
	return buffer;
   }
}


// this is newly added for ActorConnection
ConsoleFunction(getConnectionToServer, S32, 1, 1, "returns ActorConnection to server (if we are a client)")
{
   ActorConnection *ac = ActorConnection::getConnectionToServer();
   if (ac) {
      return ac->getId();
   }
   else {
      return 0;
   }
}

