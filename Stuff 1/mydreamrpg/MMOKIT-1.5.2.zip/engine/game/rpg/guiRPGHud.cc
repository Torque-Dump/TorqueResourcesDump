//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "dgl/dgl.h"
#include "dgl/gNewFont.h"
#include "gui/core/guiControl.h"
#include "gui/core/guiTSControl.h"
#include "console/consoleTypes.h"
#include "sceneGraph/sceneGraph.h"
#include "game/shapeBase.h"
#include "game/gameConnection.h"
#include "dgl/glu.h"
//----------------------------------------------------------------------------
/// Displays name & damage above shape objects.
///
/// This control displays the name and damage value of all named
/// ShapeBase objects on the client.  The name and damage of objects
/// within the control's display area are overlayed above the object.
///
/// This GUI control must be a child of a TSControl, and a server connection
/// and control object must be present.
///
/// This is a stand-alone control and relies only on the standard base GuiControl.
class GuiRPGHud : public GuiControl 
{
   typedef GuiControl Parent;

   // field data
   ColorF   mFillColor;
   ColorF   mFrameColor;
   ColorF   mTextColor;

   F32      mVerticalOffset;
   F32      mDistanceFade;
    // Visible distance info & name fading
   F32      mVisDistance;
   bool     mShowFrame;
   bool     mShowFill;
   bool	mShowDamage;
   ColorF   mDamageFillColor;
   ColorF   mDamageFrameColor;
   ColorF   mLevelDifColorSimple;
   ColorF   mLevelDifColorEasy;
   ColorF   mLevelDifColorNormal;
   ColorF   mLevelDifColorHard;
   ColorF   mLevelDifColorTough;
   Point2I  mDamageRectSize;
   Point2I  mDamageOffset;
   Point2I mObjectSize;

protected:
   void drawName(Point2I offset, ShapeBase *shape, S32 levelDif, F32 opacity);
   void drawDamage(Point2I offset, F32 damage, F32 opacity);

public:
   GuiRPGHud();

   // GuiControl
   virtual void onRender(Point2I offset, const RectI &updateRect);

      // object selection additions
   virtual void onMouseDown(const GuiEvent &evt);
	
   static void initPersistFields();
   DECLARE_CONOBJECT( GuiRPGHud );
};


//-----------------------------------------------------------------------------

IMPLEMENT_CONOBJECT(GuiRPGHud);

/// Default distance for object's information to be displayed.
static const F32 cDefaultVisibleDistance = 500.0f;

GuiRPGHud::GuiRPGHud()
{
   mFillColor.set( 0.25, 0.25, 0.25, 0.25 );
   mFrameColor.set( 0, 1, 0, 1 );
   mTextColor.set( 0, 1, 0, 1 );
   mLevelDifColorSimple.set(0.5, 0.5, 0.5);
   mLevelDifColorEasy.set(0, 1, 0);
   mLevelDifColorNormal.set(0, 0, 1);
   mLevelDifColorHard.set(1, 1, 0);
   mLevelDifColorTough.set(1, 0, 0);
   mShowFrame = mShowFill = true;
   mShowDamage = true;
   mVerticalOffset = 0.5;
   mDistanceFade = 0.1;
   mVisDistance = gClientSceneGraph->getVisibleDistance();
   mDamageFillColor.set( 0, 1, 0, 1 );
   mDamageFrameColor.set( 1, 0.6, 0, 1 );
   mDamageRectSize.set(50, 4);
   mObjectSize.set(4, 50);
   mDamageOffset.set(0,32);	
}

void GuiRPGHud::initPersistFields()
{
   Parent::initPersistFields();
   addGroup("Colors");
   addField( "fillColor",  TypeColorF, Offset( mFillColor, GuiRPGHud ) );
   addField( "frameColor", TypeColorF, Offset( mFrameColor, GuiRPGHud ) );
   addField( "textColor",  TypeColorF, Offset( mTextColor, GuiRPGHud ) );
   endGroup("Colors");

   addGroup("Misc");
   addField( "showFill",   TypeBool, Offset( mShowFill, GuiRPGHud ) );
   addField( "showFrame",  TypeBool, Offset( mShowFrame, GuiRPGHud ) );
   addField( "verticalOffset", TypeF32, Offset( mVerticalOffset, GuiRPGHud ) );
   addField( "distanceFade", TypeF32, Offset( mDistanceFade, GuiRPGHud ) );
   addField( "visibleDistance", TypeF32, Offset( mVisDistance, GuiRPGHud ) );
   addField( "LevelDifColorSimple", TypeColorF, Offset( mLevelDifColorSimple, GuiRPGHud) );
   addField( "LevelDifColorEasy", TypeColorF, Offset( mLevelDifColorEasy, GuiRPGHud) );
   addField( "LevelDifColorNormal", TypeColorF, Offset( mLevelDifColorNormal, GuiRPGHud) );
   addField( "LevelDifColorTough", TypeColorF, Offset( mLevelDifColorTough, GuiRPGHud) );
   addField( "LevelDifColorHard", TypeColorF, Offset( mLevelDifColorHard, GuiRPGHud) );
   endGroup("Misc");

   addGroup("Damage");
   addField( "showDamage",   TypeBool, Offset( mShowDamage, GuiRPGHud ) );		
   addField( "damageFillColor", TypeColorF, Offset( mDamageFillColor, GuiRPGHud) );
   addField( "damageFrameColor", TypeColorF, Offset( mDamageFrameColor, GuiRPGHud) );
   addField( "damageRect", TypePoint2I, Offset( mDamageRectSize, GuiRPGHud) );
   addField( "damageOffset", TypePoint2I, Offset( mDamageOffset, GuiRPGHud) );
   endGroup("Damage");		
}

//--------------------------------------------------------------------------
// object selection additions
//--------------------------------------------------------------------------
void GuiRPGHud::onMouseDown(const GuiEvent &evt)
{
   // Let's let the parent execute its event handling (if any)
   GuiTSCtrl *parent = dynamic_cast<GuiTSCtrl*>(getParent());

   if (parent)
      parent->onMouseDown(evt);
}


//----------------------------------------------------------------------------
/// Core rendering method for this control.
///
/// This method scans through all the current client ShapeBase objects.
/// If one is named, it displays the name and damage information for it.
///
/// Information is offset from the center of the object's bounding box,
/// unless the object is a PlayerObjectType, in which case the eye point
/// is used.
///
/// @param   updateRect   Extents of control.
void GuiRPGHud::onRender( Point2I, const RectI &updateRect){

	// Background fill first
	if (mShowFill)
		dglDrawRectFill(updateRect, mFillColor);
	
	// Must be in a TS Control
	GuiTSCtrl *parent = dynamic_cast<GuiTSCtrl*>(getParent());
	if (!parent) return;
	
	// Must have a connection and control object
	GameConnection* conn = GameConnection::getConnectionToServer();
	if (!conn)
		return;
	
	ShapeBase* control = conn->getControlObject();
	if (!control)
		return;
	
	// Get control camera info
	MatrixF cam;
	Point3F camPos;
	VectorF camDir;
	conn->getControlCameraTransform(0,&cam);
	cam.getColumn(3, &camPos);
	cam.getColumn(1, &camDir);
	
	F32 camFov;
	conn->getControlCameraFov(&camFov);
	//camFov = mDegToRad(camFov) / 2;
	F32 cosCamFov = mCos(camFov);
	
	// Visible distance info & name fading
	//F32 visDistance = gClientSceneGraph->getVisibleDistance();
	//F32 visDistanceSqr = visDistance / 2;
	F32 fadeDistance = mVisDistance * mDistanceFade;
	
	// Collision info. We're going to be running LOS tests and we
	// don't want to collide with the control object.
	static U32 losMask = TerrainObjectType | InteriorObjectType | ShapeBaseObjectType;
	control->disableCollision();
	
	//Get the  selectedID
	//chaning from ShapeBase to SceneObject
//	ShapeBase* selectedObj = NULL;
	SceneObject* selectedObj = NULL;


	if (conn)
		selectedObj = conn->getSelectedObject();
	
	S32 selectedId = -1;
	
	if (selectedObj != NULL)
		selectedId = selectedObj->getId();
	
	// All ghosted objects are added to the server connection group,
	// so we can find all the shape base objects by iterating through
	// our current connection.
	for (SimSetIterator itr(conn); *itr; ++itr){
		if ((*itr)->getType() & ShapeBaseObjectType){
			ShapeBase* shape = static_cast<ShapeBase*>(*itr);
			if (shape != control && shape->getShapeName()){
		
				// Target pos to test, if it's a player run the LOS to his eye
				// point, otherwise we'll grab the generic box center.
				Point3F shapePos;
				if (shape->getType() & PlayerObjectType){
					MatrixF eye;
				
					// Use the render eye transform, otherwise we'll see jittering
					shape->getRenderEyeTransform(&eye);
					eye.getColumn(3, &shapePos);
				}else{
					// Use the render transform instead of the box center
					// otherwise it'll jitter.
					MatrixF srtMat = shape->getRenderTransform();
					srtMat.getColumn(3, &shapePos);
				}
			
				VectorF shapeDir = shapePos - camPos;
				F32 dot = mDot(shapeDir, camDir);
				if (dot < 0)
					continue;
				// Test to see if it's in range
				F32 shapeDist = shapeDir.lenSquared();
				if (shapeDist == 0 || shapeDist > mVisDistance)
					continue;
				shapeDist = mSqrt(shapeDist);
			
				// Test to see if it's within our viewcone, this test doesn't
				// actually match the viewport very well, should consider
				// projection and box test.
				dot /= shapeDist;
				if (dot < cosCamFov)
					continue;
			
				// Test to see if it's behind something, and we want to
				// ignore anything it's mounted on when we run the LOS.
				RayInfo info;
				shape->disableCollision();
				ShapeBase *mount = shape->getObjectMount();
			
				if (mount)
					mount->disableCollision();

				bool los = !gClientContainer.castRay(camPos, shapePos,losMask, &info);
				shape->enableCollision();
				
				if (mount)
					mount->enableCollision();
			
				if (!los)
					continue;
				
				// Project the shape pos into screen space and calculate
				// the distance opacity used to fade the labels into the
				// distance.
				Point3F projPnt;
				shapePos.z += mVerticalOffset;
				if (!parent->project(shapePos, &projPnt))
				continue;
				F32 opacity = (shapeDist < fadeDistance)? 1.0:
				1.0 - (shapeDist - fadeDistance) / (mVisDistance - fadeDistance);

				//Calculate Level Difference
				U32 shapeLevel = shape->getLevel();
				U32 myLevel = control->getLevel();
				S32 levelDif = shapeLevel - myLevel;
				
				// Render the shape's name
				drawName(Point2I((S32)projPnt.x, (S32)projPnt.y),shape, levelDif, opacity);
				if(selectedId == shape->getId() && mShowDamage)
					drawDamage(Point2I((S32)projPnt.x, (S32)projPnt.y),shape->getDamageValue(), opacity);
				
			}
		}
	}
	
	// Restore control object collision
	control->enableCollision();
	
	// Border is drawn last
	if (mShowFrame)
	dglDrawRect(updateRect, mFrameColor);
}


//----------------------------------------------------------------------------
/// Render object names.
///
/// Helper function for GuiRPGHud::onRender
///
/// @param   offset  Screen coordinates to render name label. (Text is centered
///                  horizontally about this location, with bottom of text at
///                  specified y position.)
/// @param   shape    pointer to shape for the stuff we are about to render
/// @param   opacity Opacity of name (a fraction).
void GuiRPGHud::drawName(Point2I nameOffset, ShapeBase *shape, S32 levelDif, F32 opacity)
{
   const char* name = shape->getShapeName();
   const char* guild = shape->getGuildName();
   
   Point2I guildOffset =  nameOffset;
   // Center the name and guild
   nameOffset.x -= mProfile->mFont->getStrWidth((const UTF8 *)name) / 2;
   guildOffset.x -= mProfile->mFont->getStrWidth((const UTF8 *)guild) / 2;
   
   //guildOffset.y = nameOffset.y;
   nameOffset.y -= mProfile->mFont->getHeight();
   
   
   //Con::printf("Shape Name is %s",name);
   //Con::printf("Level dif is %d", levelDif);
   
	if(levelDif < 0){
//		mTextColor.set( 0.5, 0.5, 0.5, 0.5 ); //Simple = Grey
		mTextColor = mLevelDifColorSimple; //Simple = Grey
		//Con::printf("simple");
	}else if(levelDif >= 10){
//		mTextColor.set( 1, 0, 0, 1 ); //Hard=red
		mTextColor = mLevelDifColorHard; //Hard=red
		//Con::printf("hard");
	}else{
		switch (levelDif){ 
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:{
				//mTextColor.set( 0, 1, 0, 1 ); //Easy = Green
			    mTextColor = mLevelDifColorEasy; //Easy = Green
				//Con::printf("easy");
			break;
				   }

			case 5:
			case 6:
			case 7:{
				//mTextColor.set( 0, 0, 1, 1 ); //Normal=Blue
				mTextColor = mLevelDifColorNormal; //Normal=Blue
				//Con::printf("normal");
				   
			break;
				   }
			case 8:
			case 9:{
				//mTextColor.set( 1, 1, 0, 1 ); //tough=yellow
				mTextColor = mLevelDifColorTough; //tough=yellow
				//Con::printf("tough");
			break;
				   }
		}
	}

   // Deal with opacity and draw.
   mTextColor.alpha = opacity;
   dglSetBitmapModulation(mTextColor);
   dglDrawText(mProfile->mFont, nameOffset, name);
   dglDrawText(mProfile->mFont, guildOffset, guild);
   dglClearBitmapModulation();
   //Con::printf("levelDif is %d",levelDif);
}

void GuiRPGHud::drawDamage(Point2I offset, F32 damage, F32 opacity)
{
   mDamageFillColor.alpha = mDamageFrameColor.alpha = opacity;

   // Damage should be 0->1 (0 being no damage,or healthy), but
   // we'll just make sure here as we flip it.
   damage = mClampF(1 - damage, 0, 1);

   // Center the bar
   RectI rect(offset, mDamageRectSize);
   rect.point.x -= mDamageRectSize.x / 2;

   // Draw the border
   dglDrawRect(rect, mDamageFrameColor);

   // Draw the damage % fill
   rect.point += Point2I(1, 1);
   rect.extent -= Point2I(1, 1);
   rect.extent.x = (S32)(rect.extent.x * damage);
   if (rect.extent.x == 1)
      rect.extent.x = 2;
   if (rect.extent.x > 0)
      dglDrawRectFill(rect, mDamageFillColor);
}

