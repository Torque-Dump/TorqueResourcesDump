//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _GUIRPGTSCTRL_H_
#define _GUIRPGTSCTRL_H_

#ifndef _EDITTSCTRL_H_
#include "editor/editTSCtrl.h"
#endif
#ifndef _CONSOLETYPES_H_
#include "console/consoleTypes.h"
#endif
#ifndef _GTEXMANAGER_H_
#include "dgl/gTexManager.h"
#endif
#ifndef _TERRDATA_H_
#include "terrain/terrData.h"
#endif


class SceneObject;
class GuiRPGTSCtrl : public EditTSCtrl
{
private:
   typedef EditTSCtrl Parent;
   
   //DreamRPG used to keep track of last cursor position
   //Gui3DMouseEvent mLastEvent;
   Point2I	lastCursor;
   bool canDrag;	// Allows dragging only if MouseDown was on this object


public:
   struct CollisionInfo
   {
      SceneObject *     obj;
      Point3F           pos;
      VectorF           normal;
      Point3F           start;
   };

   SceneObject * getControlObject();
   bool collide(const Gui3DMouseEvent & event, CollisionInfo & info);

   GuiRPGTSCtrl();
   ~GuiRPGTSCtrl();

   // SimObject
   bool onWake();
   void onSleep();

   // EditTSCtrl
   void on3DMouseMove(const Gui3DMouseEvent & event);
   void on3DMouseDragged(const Gui3DMouseEvent & event);
   void on3DMouseDown(const Gui3DMouseEvent & event);
   void on3DMouseUp(const Gui3DMouseEvent & event);

   void on3DRightMouseDown(const Gui3DMouseEvent & event);
   void on3DRightMouseDragged(const Gui3DMouseEvent & event);
   void on3DRightMouseUp(const Gui3DMouseEvent & event);

 
   void updateGuiInfo();

   //
   void onRender(Point2I offset, const RectI &updateRect);
   void renderScene(const RectI & updateRect);

   static void initPersistFields();

   DECLARE_CONOBJECT(GuiRPGTSCtrl);



   private:
      ColorF   mDamageFillColor;
      ColorF   mDamageFrameColor;
      Point2I  mDamageRectSize;

      CollisionInfo              mHitInfo;
      Point3F                    mHitOffset;
      SimObjectPtr<SceneObject>  mHitObject;


   public:
 
      bool      mLockSelection;
};

#endif



