//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "dgl/dgl.h"
#include "gui/core/guiControl.h"
#include "console/consoleTypes.h"
#include "game/shapeBase.h"
#include "game/gameConnection.h"

//-----------------------------------------------------------------------------
/// A generic fill bar control.
/// This gui displays the specified value in a progress like control object.
/// The gui can be set to pulse if the value drops below a set value.
class GuiGenericBarHud : public GuiControl
{
   typedef GuiControl Parent;

   bool     mShowFrame;
   bool     mShowBackgroundFill;
   bool     mShowTargetFill;
   bool     mFlipped;
   bool     mPulseAlways;

   ColorF   mBackgroundFillColor;
   ColorF   mFrameColor;
   ColorF   mFillColor;

   S32      mPulseRate;
   F32      mPulseThreshold;

   S32      mLastRenderTime;
   F32      mFillSpeed;
   F32      mDrainSpeed;

   F32      mCurValue;
   F32      mValue;
   F32      mMinValue;
   F32      mMaxValue;
   U32		mTargetObject; //what is the id of the target object?
   U32		mRenderStat; //what stat from the object will be rendering?

public:
   GuiGenericBarHud();

   virtual const char *getScriptValue();
   virtual void setScriptValue(const char *value);

   F32 getRenderValue();  //go get the value to render
   void setTargetObject(U32 ObjectID);
   void setRenderStat(U32 StatID);

   void setMinValue(F32 value);
   F32 getMinValue();

   void setMaxValue(F32 value);
   F32 getMaxValue();

   void setFillSpeed(F32 value);
   F32 getFillSpeed();

   void setDrainSpeed(F32 value);
   F32 getDrainSpeed();

   void drainValueTo(F32 value);
   void fillValueTo(F32 value);

   void drainValue(F32 value);
   void fillValue(F32 value);

   void setPulseRate(S32 value);
   S32 getPulseRate();

   void setPulseThreshold(F32 value);
   F32 getPulseThreshold();

   void setPulseAlways(bool value);
   bool getPulseAlways();

   void setShowBackgroundFill(bool value);
   bool getShowBackgroundFill();

   void setShowTargetFill(bool value);
   bool getShowTargetFill();

   void drawFillToPercent(F32 percent, ColorF color, RectI updateRect);
   void onRender( Point2I, const RectI &);
   static void initPersistFields();
   DECLARE_CONOBJECT( GuiGenericBarHud );
};


//-----------------------------------------------------------------------------

IMPLEMENT_CONOBJECT( GuiGenericBarHud );

GuiGenericBarHud::GuiGenericBarHud()
{
   mShowFrame = mShowTargetFill = true;
   mBackgroundFillColor.set(0, 1, 0, 0.25);
   mFrameColor.set(0, 1, 0, 1);
   mFillColor.set(0, 1, 0, 1);

   mFlipped = mShowBackgroundFill = mPulseAlways = false;

   mPulseRate = 0;
   mPulseThreshold = 0.3f;

   mValue = 0.2f;
   mCurValue = 0.2f;
   mMinValue = 0.0f;
   mMaxValue = 1.0f;

   mFillSpeed = 1.0f;
   mDrainSpeed = 1.0f;

   mLastRenderTime = 0;

   mTargetObject = 0;
   mRenderStat = 0;
}

void GuiGenericBarHud::initPersistFields()
{
   Parent::initPersistFields();

   addGroup("Colors");
   addField( "backgroundFillColor", TypeColorF, Offset( mBackgroundFillColor, GuiGenericBarHud ) );
   addField( "frameColor",      TypeColorF, Offset( mFrameColor, GuiGenericBarHud ) );
   addField( "fillColor",       TypeColorF, Offset( mFillColor, GuiGenericBarHud ) );
   endGroup("Colors");

   addGroup("Pulse");
   addField( "pulseRate",       TypeS32, Offset( mPulseRate, GuiGenericBarHud ) );
   addField( "pulseThreshold",  TypeF32, Offset( mPulseThreshold, GuiGenericBarHud ) );
   addField( "pulseAlways",     TypeBool, Offset( mPulseAlways, GuiGenericBarHud ) );
   endGroup("Pulse");

   addGroup("Values");
   addField( "minValue",        TypeF32, Offset( mMinValue, GuiGenericBarHud ) );
   addField( "maxValue",        TypeF32, Offset( mMaxValue, GuiGenericBarHud ) );
   addField( "initialValue",    TypeF32, Offset( mCurValue, GuiGenericBarHud ) );
   addField( "fillSpeed",       TypeF32, Offset( mFillSpeed, GuiGenericBarHud ) );
   addField( "drainSpeed",      TypeF32, Offset( mDrainSpeed, GuiGenericBarHud ) );
   endGroup("Values");

   addGroup("Misc");
   addField( "flipped",         TypeBool, Offset( mFlipped, GuiGenericBarHud ) );
   addField( "showBackgroundFill", TypeBool, Offset( mShowBackgroundFill, GuiGenericBarHud ) );
   addField( "showTargetFill",  TypeBool, Offset( mShowTargetFill, GuiGenericBarHud ) );
   addField( "showFrame",       TypeBool, Offset( mShowFrame, GuiGenericBarHud ) );
   endGroup("Misc");
}


//-----------------------------------------------------------------------------
/**
   Gui onRender method.
   Renders a health bar with filled background and border.
*/
F32 GuiGenericBarHud::getRenderValue(){

	return 0;
}

void GuiGenericBarHud::setTargetObject(U32 ObjectID){
	mTargetObject = ObjectID;	
}

void GuiGenericBarHud::setRenderStat(U32 StatID){
	mRenderStat = StatID;
}

void GuiGenericBarHud::onRender(Point2I offset, const RectI &updateRect)
{
   
	/*// Must have a connection and player control object
   GameConnection* conn = GameConnection::getConnectionToServer();
   if (!conn)
      return;
   ShapeBase* control = conn->getControlObject();
   if (!control || !(control->getType() & PlayerObjectType))
      return;

   if(mDisplayEnergy)
   {
      mValue = control->getEnergyValue();
   }
   else
   {
      // We'll just grab the damage right off the control object.
      // Damage value 0 = no damage.
      mValue = 1 - control->getDamageValue();
   }
   */


   S32 time = Platform::getVirtualMilliseconds();
   S32 dt = time - mLastRenderTime;
   mLastRenderTime = time;

   if (mCurValue > mValue)
   {
      mCurValue -= (mMaxValue - mMinValue) * (dt * mDrainSpeed) / 1000.f;

      if (mCurValue < mValue)
         mCurValue = mValue;
   }
   else if (mCurValue < mValue)
   {
      mCurValue += (mMaxValue - mMinValue) * (dt * mFillSpeed) / 1000.f;

      if (mCurValue > mValue)
         mCurValue = mValue;
   }

   // Background first
   if (mShowBackgroundFill)
      dglDrawRectFill(updateRect, mBackgroundFillColor);
   else if (mShowTargetFill)
      drawFillToPercent((mValue - mMinValue) / (mMaxValue - mMinValue), mBackgroundFillColor, updateRect);

   F32 old_alpha = mFillColor.alpha;
   // Pulse the fill if it's below the threshold
   if (mPulseRate != 0)
   {
      if (mCurValue < mPulseThreshold || mPulseAlways == true)
      {
         F32 time = Platform::getVirtualMilliseconds();
         F32 alpha = mFmod(time,mPulseRate) / (mPulseRate / (old_alpha * 2.0));
         mFillColor.alpha = (alpha > old_alpha)? (old_alpha * 2.0) - alpha: alpha;
      }
   }

   // Render fill %
   drawFillToPercent((mCurValue - mMinValue) / (mMaxValue - mMinValue), mFillColor, updateRect);
   mFillColor.alpha = old_alpha;

   // Border last
   if (mShowFrame)
      dglDrawRect(updateRect, mFrameColor);
}

void GuiGenericBarHud::drawFillToPercent(F32 percent, ColorF color, RectI updateRect)
{
   RectI rect(updateRect);
   if(mBounds.extent.x > mBounds.extent.y)
   {
      if(mFlipped)
      {
         S32 bottomX = rect.point.x + rect.extent.x;
         rect.extent.x = (S32)(rect.extent.x * percent);
         rect.point.x = bottomX - rect.extent.x;
      }
      else
      {
         rect.extent.x = (S32)(rect.extent.x * percent);
      }
   }
   else
   {
      if(mFlipped)
      {
         rect.extent.y = (S32)(rect.extent.y * percent);
      }
      else
      {
         S32 bottomY = rect.point.y + rect.extent.y;
         rect.extent.y = (S32)(rect.extent.y * percent);
         rect.point.y = bottomY - rect.extent.y;
      }
   }

   dglDrawRectFill(rect, color);
}

void GuiGenericBarHud::setScriptValue(const char *value)
{
   mValue = mCurValue = mClampF(dAtof(value), mMinValue, mMaxValue);
}

const char *GuiGenericBarHud::getScriptValue()
{
   char * ret = Con::getReturnBuffer(64);
   dSprintf(ret, 64, "%f", mValue);
   return ret;
}

void GuiGenericBarHud::setMinValue(F32 value)
{
   if (value > mMaxValue)
      mMaxValue = value;

   mMinValue = value;
   mValue = mClampF(mValue, mMinValue, mMaxValue);
   mCurValue = mClampF(mCurValue, mMinValue, mMaxValue);
}

F32 GuiGenericBarHud::getMinValue()
{
   return mMinValue;
}

void GuiGenericBarHud::setMaxValue(F32 value)
{
   if (value < mMinValue)
      mMinValue = value;

   mMaxValue = value;
   mValue = mClampF(mValue, mMinValue, mMaxValue);
   mCurValue = mClampF(mCurValue, mMinValue, mMaxValue);
}

F32 GuiGenericBarHud::getMaxValue()
{
   return mMaxValue;
}

void GuiGenericBarHud::setFillSpeed(F32 value)
{
   mFillSpeed = value;
}

F32 GuiGenericBarHud::getFillSpeed()
{
   return mFillSpeed;
}

void GuiGenericBarHud::setDrainSpeed(F32 value)
{
   mDrainSpeed = value;
}

F32 GuiGenericBarHud::getDrainSpeed()
{
   return mDrainSpeed;
}

void GuiGenericBarHud::drainValueTo(F32 value)
{
   mValue = mClampF(value, mMinValue, mMaxValue);
}

void GuiGenericBarHud::fillValueTo(F32 value)
{
   mValue = mClampF(value, mMinValue, mMaxValue);
}

void GuiGenericBarHud::drainValue(F32 value)
{
   drainValueTo(mValue - value);
}

void GuiGenericBarHud::fillValue(F32 value)
{
   fillValueTo(mValue + value);
}

void GuiGenericBarHud::setPulseRate(S32 value)
{
   mPulseRate = value;
}

S32 GuiGenericBarHud::getPulseRate()
{
   return mPulseRate;
}

void GuiGenericBarHud::setPulseThreshold(F32 value)
{
   mPulseThreshold = value;
}

F32 GuiGenericBarHud::getPulseThreshold()
{
   return mPulseThreshold;
}

void GuiGenericBarHud::setPulseAlways(bool value)
{
   mPulseAlways = value;
}

bool GuiGenericBarHud::getPulseAlways()
{
   return mPulseAlways;
}

void GuiGenericBarHud::setShowBackgroundFill(bool value)
{
   mShowBackgroundFill = value;
}

bool GuiGenericBarHud::getShowBackgroundFill()
{
   return mShowBackgroundFill;
}

void GuiGenericBarHud::setShowTargetFill(bool value)
{
   mShowTargetFill = value;
}

bool GuiGenericBarHud::getShowTargetFill()
{
   return mShowTargetFill;
}

// Console methods for direct manipulation of bar.
ConsoleMethod(GuiGenericBarHud, setValue, void, 3, 3, "Set the value of the bar.")
{
   object->setScriptValue(argv[2]);
}

ConsoleMethod(GuiGenericBarHud, getValue, F32, 2, 2, "Get the value of the bar.")
{
   return dAtof(object->getScriptValue());
}

ConsoleMethod(GuiGenericBarHud, setMinValue, void, 3, 3, "Set the minimum value of the bar.")
{
   object->setMinValue(dAtof(argv[2]));
}

ConsoleMethod(GuiGenericBarHud, getMinValue, F32, 2, 2,"Get the minimum value of the bar.")
{
   return object->getMinValue();
}

ConsoleMethod(GuiGenericBarHud, setMaxValue, void, 3, 3, "Set the minimum value of the bar.")
{
   object->setMaxValue(dAtof(argv[2]));
}

ConsoleMethod(GuiGenericBarHud, getMaxValue, F32, 2, 2, "Get the minimum value of the bar.")
{
   return object->getMaxValue();
}

ConsoleMethod(GuiGenericBarHud, setFillSpeed, void, 3, 3, "Set the speed used to fill the bar.")
{
   object->setFillSpeed(dAtof(argv[2]));
}

ConsoleMethod(GuiGenericBarHud, getFillSpeed, F32, 2, 2, "Get the speed used to fill the bar.")
{
   return object->getFillSpeed();
}

ConsoleMethod(GuiGenericBarHud, setDrainSpeed, void, 3, 3, "Set the speed used to drain the bar.")
{
   object->setDrainSpeed(dAtof(argv[2]));
}

ConsoleMethod(GuiGenericBarHud, getDrainSpeed, F32, 2, 2,"Get the speed used to drain the bar.")
{
   return object->getDrainSpeed();
}

ConsoleMethod(GuiGenericBarHud, fillTo, void, 3, 3, "Fills the bar to the specified value.")
{
   object->fillValueTo(dAtof(argv[2]));
}

ConsoleMethod(GuiGenericBarHud, drainTo, void, 3, 3, "Drains the bar to the specified value.")
{
   object->drainValueTo(dAtof(argv[2]));
}

ConsoleMethod(GuiGenericBarHud, fill, void, 3, 3, "Fills the bar by the delta value.")
{
   object->fillValue(dAtof(argv[2]));
}

ConsoleMethod(GuiGenericBarHud, drain, void, 3, 3, "Drains the bar by the delta value.")
{
   object->drainValue(dAtof(argv[2]));
}

ConsoleMethod(GuiGenericBarHud, setPulseRate, void, 3, 3, "Set the pulse rate of the bar.")
{
   object->setPulseRate(dAtoi(argv[2]));
}

ConsoleMethod(GuiGenericBarHud, getPulseRate, S32, 2, 2, "Get the pulse rate of the bar.")
{
   return object->getPulseRate();
}

ConsoleMethod(GuiGenericBarHud, setPulseThreshold, void, 3, 3, "Set the threshold to start/stop the bar pulse.")
{
   object->setPulseThreshold(dAtof(argv[2]));
}

ConsoleMethod(GuiGenericBarHud, getPulseThreshold, F32, 2, 2, "Get the threshold to start/stop the bar pulse.")
{
   return object->getPulseThreshold();
}

ConsoleMethod(GuiGenericBarHud, setPulseAlways, void, 3, 3, "Set the bar to always pulse.")
{
   object->setPulseAlways(dAtob(argv[2]));
}

ConsoleMethod(GuiGenericBarHud, getPulseAlways, bool, 2, 2, "Get whether the bar should always pulse.")
{
   return object->getPulseAlways();
}

ConsoleMethod(GuiGenericBarHud, setShowBackgroundFill, void, 3, 3, "Set the bar to display a background fill color.")
{
   object->setShowBackgroundFill(dAtob(argv[2]));
}

ConsoleMethod(GuiGenericBarHud, getShowBackgroundFill, bool, 2, 2, "Get whether the bar should display a background fill color.")
{
   return object->getShowBackgroundFill();
}

ConsoleMethod(GuiGenericBarHud, setShowTargetFill, void, 3, 3, "Set the bar to display a target fill color.")
{
   object->setShowTargetFill(dAtob(argv[2]));
}

ConsoleMethod(GuiGenericBarHud, getShowTargetFill, bool, 2, 2, "Get whether the bar should display a target fill color.")
{
   return object->getShowTargetFill();
}
