//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "sceneGraph/sceneGraph.h"
#include "sceneGraph/sceneState.h"
#include "sim/sceneObject.h"
#include "platform/event.h"
#include "gui/core/guiCanvas.h"
#include "game/game.h"
#include "game/gameConnection.h"
#include "core/memstream.h"
#include "collision/clippedPolyList.h"
#include "game/shapeBase.h"
#include "console/consoleInternal.h"
#include "game/sphere.h"
#include "console/simBase.h"
#include "game/rpg/guiRPGTSCtrl.h"
#include "ts/tsShapeInstance.h"
#include "game/gameConnection.h"
#include "game/item.h"
IMPLEMENT_CONOBJECT(GuiRPGTSCtrl);

//-----------------------------------------------------------------------------

bool GuiRPGTSCtrl::collide(const Gui3DMouseEvent & event, CollisionInfo & info)
{
   GameConnection* conn = dynamic_cast<GameConnection*>(NetConnection::getConnectionToServer());
   if(!conn)
      return false;

   // turn off the collision with the control object
   SceneObject * controlObj = conn->getControlObject();
   if(controlObj)
      controlObj->disableCollision();

   //Get start and end points for a ray 500 seems to be a reasonable value, but it could certainly be lowered
   Point3F startPnt = event.pos;
   Point3F endPnt   = event.pos + event.vec * 500.f;

   //Lets cast a ray and see what we hit
   RayInfo ri;
   bool hit;
   hit = gClientContainer.castRay(startPnt, endPnt, -1, &ri);
   if(controlObj)//Gotta re-enable collision real quick or we could pass through objects and that would be bad
      controlObj->enableCollision();

   //Did we hit something?  Is it new?
   if(hit)
   {
	info.pos    = ri.point;
	info.obj    = ri.object;
	info.normal = ri.normal;
   }

   return(hit);
}

//------------------------------------------------------------------------------

GuiRPGTSCtrl::GuiRPGTSCtrl()
{
   mRightMousePassThru = false;
   mRenderMissionArea = false;

   mDamageFillColor.set( 0, 1, 0, 1 );
   mDamageFrameColor.set( 0, 0, 0, 1 );
   mDamageRectSize.set(50, 4);

   mHitInfo.obj = 0;
   mHitObject = mHitInfo.obj;

   mLockSelection = false;

   //DreamRPG WoW Control emulation
   canDrag = false;	// Allows dragging only if MouseDown was on this object
}

GuiRPGTSCtrl::~GuiRPGTSCtrl()
{

}

//------------------------------------------------------------------------------
bool GuiRPGTSCtrl::onWake()
{
   if (!Parent::onWake())
      return false;

   Platform::setWindowLocked(true);
   return true;
}

void GuiRPGTSCtrl::onSleep()
{
   Parent::onSleep();
   Platform::setWindowLocked(false);
}

//------------------------------------------------------------------------------
//MyDreamRPG
void GuiRPGTSCtrl::on3DMouseDragged(const Gui3DMouseEvent & event)
{
   //We use this function to movcast a ray as the mouse moves and update the cursor
   //According to object type
   mHitInfo.obj = 0;

   CollisionInfo info;
   if(collide(event, info))
   {
      if(info.obj)
      {
          mHitInfo = info;
          Con::executef(this, 2, "onMouseDraggedOverObject", info.obj->getIdString(), info.obj->getClassName());
      }
   }

   mHitObject = mHitInfo.obj;

}

//MyDreamRPG
void GuiRPGTSCtrl::on3DRightMouseDragged(const Gui3DMouseEvent & event)
{
	return;
   //We can use this function to do right mouse move if we aren't doing it all in script :)
	//Con::printf("Right Dragged");
	if(canDrag){

	   static const char *argv[2];
	   Point2I diff( event.mousePoint - lastCursor);
	
	   // Use Move Cursor if moving
	   if (!diff.isZero()) {
		   //setCursor( MoveCursor);
		
		   // If you don't want to continue tracking, use the following:
		   // mTrackObject = NULL;
	   }
	
	   // Perform script-based yaw and pitch callbacks
	   if (diff.x) {
		   //Con::printf("DiffX: %d", diff.x);
		   argv[0] = "yaw";
		   argv[1] = Con::getFloatArg( diff.x);
		   Con::execute( 2, argv);
	   }
	   if (diff.y) {
	      argv[0] = "pitch";
		  argv[1] = Con::getFloatArg( diff.y);
		  Con::execute( 2, argv);
	   }
	   // HACK - Have GuiCanvas skip next MouseMoveEvent
	   lastCursor = Canvas->getCursorPos();
	   Canvas->setCursorPos( lastCursor);
	   Canvas->ignoreNextMove = true;
	   
	}

}


void GuiRPGTSCtrl::on3DMouseMove(const Gui3DMouseEvent & event)
{
//We use this function to cast a ray as the mouse moves and update the cursor
//According to object type
   if(!canDrag){
      mHitInfo.obj = 0;

      CollisionInfo info;
      if(collide(event, info))
      {
         if(info.obj)
         {
             mHitInfo = info;
             Con::executef(this, 2, "onMouseOverObject", info.obj->getIdString(), info.obj->getClassName());
         }
      }

      mHitObject = mHitInfo.obj;
   }
}

void GuiRPGTSCtrl::on3DMouseDown(const Gui3DMouseEvent &event)
{

   //In this function we just want to see if the mouse is over anything 
   //If it is we send the object and the coordinates to script for further handling
   CollisionInfo info;
   if(collide(event, info))
      if(info.obj)
         mHitInfo = info;

   S32 doubleClick = (event.mouseClickCount > 1)?1:0;
   
   Con::executef(this,
      6,
      "onMouseDown",
      Con::getIntArg((mHitInfo.obj) ? mHitInfo.obj->getId() : 0),
      Con::getFloatArg(info.pos.x),
      Con::getFloatArg(info.pos.y),
      Con::getFloatArg(info.pos.z),
	Con::getIntArg(doubleClick));

   // Update the hitObject so we know what the mouse is over.
   mHitObject = mHitInfo.obj;

}

void GuiRPGTSCtrl::on3DRightMouseDown(const Gui3DMouseEvent &event)
{

   //In this function we just want to see if the mouse is over anything 
   //If it is we send the object and the coordinates to script for further handling
   CollisionInfo info;
   if(collide(event, info))
      if(info.obj)
         mHitInfo = info;

   S32 doubleClick = (event.mouseClickCount > 1)?1:0;
   
   Con::executef(this,
      6,
      "onRightMouseDown",
      Con::getIntArg((mHitInfo.obj) ? mHitInfo.obj->getId() : 0),
      Con::getFloatArg(info.pos.x),
      Con::getFloatArg(info.pos.y),
      Con::getFloatArg(info.pos.z),
	Con::getIntArg(doubleClick));

   // Update the hitObject so we know what the mouse is over.
   mHitObject = mHitInfo.obj;

}

void GuiRPGTSCtrl::on3DRightMouseUp(const Gui3DMouseEvent &event){
   //In this function we just want to see if the mouse is over anything 
   //If it is we send the object and the coordinates to script for further handling
   CollisionInfo info;
   if(collide(event, info))
      if(info.obj)
         mHitInfo = info;

   S32 doubleClick = (event.mouseClickCount > 1)?1:0;

	   Con::executef(this,6,
      "onRightMouseUp",
      Con::getIntArg((mHitInfo.obj) ? mHitInfo.obj->getId() : 0),
      Con::getFloatArg(info.pos.x),
      Con::getFloatArg(info.pos.y),
      Con::getFloatArg(info.pos.z),
      Con::getIntArg(doubleClick));

}

void GuiRPGTSCtrl::on3DMouseUp(const Gui3DMouseEvent &event){
   //In this function we just want to see if the mouse is over anything 
   //If it is we send the object and the coordinates to script for further handling
   CollisionInfo info;
   if(collide(event, info))
      if(info.obj)
         mHitInfo = info;

   S32 doubleClick = (event.mouseClickCount > 1)?1:0;

	   Con::executef(this,6,
      "onMouseUp",
      Con::getIntArg((mHitInfo.obj) ? mHitInfo.obj->getId() : 0),
      Con::getFloatArg(info.pos.x),
      Con::getFloatArg(info.pos.y),
      Con::getFloatArg(info.pos.z),
      Con::getIntArg(doubleClick));

}
/*
void GuiRPGTSCtrl::on3DRightMouseDown(const Gui3DMouseEvent & event)
{
   //We define interaction and selection in terms on LMB and RMB
   //In this case we want to select with left and interact with right
   //The only difference then between this function and the one above is 
   //the console function called at the end
   
   //DreamRPG used for WoW Control Emulation
   
   
  if(!canDrag){
   //lastCursor = Canvas->getCursorPos();
   //canDrag = true;

   CollisionInfo info;
   if(collide(event, info))
      if(info.obj)
         mHitInfo = info;

   Con::executef(this,
      6,
      "onRightMouseDown",
      Con::getIntArg((mHitInfo.obj) ? mHitInfo.obj->getId() : 0),
      Con::getFloatArg(info.pos.x),
      Con::getFloatArg(info.pos.y),
      Con::getFloatArg(info.pos.z));

   // Update the mouse over object.
   mHitObject = mHitInfo.obj;
  }
}

void GuiRPGTSCtrl::on3DRightMouseUp(const Gui3DMouseEvent & event){
   
   //DreamRPG Restore the cursor
   
   if(canDrag){
      //canDrag = false;
      //Canvas->setCursorPos( lastCursor);
   }

   CollisionInfo info;
   if(collide(event, info))
      if(info.obj)
         mHitInfo = info;

 	   Con::executef(this,
		6,
		"onRightMouseUp",
		Con::getIntArg((mHitInfo.obj) ? mHitInfo.obj->getId() : 0),
		Con::getFloatArg(info.pos.x),
		Con::getFloatArg(info.pos.y),
		Con::getFloatArg(info.pos.z));

}
*/
//------------------------------------------------------------------------------

void GuiRPGTSCtrl::updateGuiInfo()
{
}


void GuiRPGTSCtrl::renderScene(const RectI & updateRect)
{
   // Show damage/whiteout
   CameraQuery camQ;
   if(GameProcessCameraQuery(&camQ))
      GameRenderFilters(camQ);
}

void GuiRPGTSCtrl::onRender(Point2I offset, const RectI &updateRect)
{
   Parent::onRender(offset, updateRect);

   GameConnection* conn = dynamic_cast<GameConnection*>(NetConnection::getConnectionToServer());

   if(!conn)
      return;

   // setup GL for selection info rendering
   dglSetClipRect(updateRect);
   glDisable     (GL_CULL_FACE);
   glEnable      (GL_BLEND);
   glBlendFunc   (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
   //glLineWidth(4.f);
   glLineWidth(1.f);
   if(bool(mHitObject))
   {
      //drawDamage(mHitObject);
   }
   renderChildControls(offset, updateRect);
}


void GuiRPGTSCtrl::initPersistFields()
{
   Parent::initPersistFields();
}

