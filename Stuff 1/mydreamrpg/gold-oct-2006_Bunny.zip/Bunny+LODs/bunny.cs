datablock TSShapeConstructor(bunnyDts)
{
   baseShape = "./bunny.dts";
   sequence0 = "./bunny_root.dsq bunny_root";
   sequence1 = "./bunny_run.dsq bunny_run";
   sequence2 = "./bunny_walk.dsq bunny_walk";
   sequence3 = "./bunny_alert.dsq bunny_alert";
   sequence4 = "./bunny_death1.dsq bunny_death1";
};