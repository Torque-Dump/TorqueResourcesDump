TGE "Actor Resource"

What it does:

As of v1.4, TGE employs different classes (Player and AIPlayer) for in-game 
avatars that are controlled by connected player clients and AI, respectively.
Moreover, there are different classes for controlling connections, whether
they are being fed by an interactive game client or by AI logic (GameConnection
and AIConnection).  This approach is needlessly "bushy" and creates problems
if you want to have avatars in your game that can be handed back and forth between
connected players as if they were dance partners.

This resource unified Player and AIPlayer into a single Actor class that can be 
dynamically assigned to the control of 
a.  a player client through a connection (ala GameConnection)
b.  an AI entity expressing itself through a connection (ala AIConnection)
c.  scripted behavior employing no connection whatever (ala Kork in starter.fps)

Part of this is done by also unifying GameConnection and AIConnection into a single
ActorConnection which can function as either.

This design permits game characters to be divorced from static associations with a given
network connection, and provides an easy way to have them persist when the player
controlling them decides he'd rather log off or control a different character within
the game.  It's fairly nice!

OBSOLETES C++:  AIPlayer.cc, AIPlayer.h, AIConnection.cc, AIConnection.h 
OBSOLETES server-side scripts (in starter.fps, e.g.): player.cs, aiPlayer.cs


Author: Tony "tone" Lovell
Originally submitted:  Aug 18, 2005


2 C++ Classes in 4 files (.cc and .h files for each)
5 Torque Script files 

additionally:

2 single-line .GUI edits required (see GarageGames resource page for more info)


INSTALLATION:

For details, check the Resource page for this, but if your TGE source code is 
approx v1.4, you will be off to a good start if you unzip this file into the
TGE root folder (that is, the one that has "engine", "example" and "vc7" as
subdirectories), preserving and applying the path information in the zip.  

Alternatively, you can hand-place the files into your project tree according
to the instructions in the resource page.






