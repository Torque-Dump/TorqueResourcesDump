//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Misc. server commands available to clients
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------

// This file has been adapted from TGE's stock starter.fps demo mod version
// to employ the "Actor" resource.  Look for ACTOR comment tags to see changes
// made.  One broad change is that the identifier "player" has generally been 
// replaced by "actor" where it is used to refer to an in-game avatar

function serverCmdToggleCamera(%client)
{
	// ACTOR 
	// With Actors, there is no guarantee that a 
	// given client HAS an actor
   if (!isObject(%client.actor))
      return;

   %control = %client.getControlObject();   

   if (%control == %client.actor)
   {
      %control = %client.camera;
      %control.mode = toggleCameraFly;
   }
   else
   {
      %control = %client.actor;
      %control.mode = observerFly;
   }
   %client.setControlObject(%control);
}


function serverCmdDropPlayerAtCamera(%client)
{
   if ($Server::TestCheats || isObject(EditorGui))
   {
      %client.actor.setTransform(%client.camera.getTransform());
      %client.actor.setVelocity("0 0 0");
      %client.setControlObject(%client.actor);
   }
}

function serverCmdDropCameraAtPlayer(%client)
{
   %client.camera.setTransform(%client.actor.getEyeTransform());
   %client.camera.setVelocity("0 0 0");
   %client.setControlObject(%client.camera);
}


//-----------------------------------------------------------------------------


function serverCmdPlayCel(%client,%anim)
{
   if (isObject(%client.actor))
      %client.actor.playCelAnimation(%anim);
}

function serverCmdPlayDeath(%client)
{
   if (isObject(%client.actor))
      %client.actor.playDeathAnimation();
}


// ACTOR 
// this is new function implements how the server resolves 
// a client-side script call to "setActor(%actorID)"
function serverCmdSetActor(%client, %actor)
{

	// do not give the requesting client control of an actor who already 
	// has a controlling ActorConnection
	// other game developers might have different ideas for what to do
	// if the actor has an ActorConnection, but one that is in AI mode
   if (isObject(%actor))
   {	
        if (isObject(%actor.getConnection())) {
		// TODO: send some notification of failure to the client?
	    return;
        }

   }


	// if the requesting client already HAS an actor, disuse that one
	// he will have no connection and (at least in starter.fps) will
	// revert to scripted behavior
   if (isObject(%client.actor))
   {
        %oldGuy = %client.actor;
	%client.actor = 0;
        %oldGuy.client = 0;
   }


	// if the client is requesting an actor be assigned to it
	// grant the client control of him
   if (isObject(%actor)) 
   {
      %control = %actor;
      %control.mode = observerFly;
   } else { // else, put the client into free camera mode (e.g.: setActor(0);)
      %control = %client.camera;
      %control.mode = toggleCameraFly;
   }

   %client.actor = %actor;
   %client.setControlObject(%control);
}
