//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------


// This file is adapted from TGE's example/starter.fps/server/scripts/aiPlayer.cs file
// it replaces use of that file, and employs the Actor Resource's new capabilities
// General changes throughout are to replace use of "player" as an identifier
// when referring to an in-game avatar with "actor".  Other changes are marked
// with the comment tag "ACTOR"
// it is worth mentioning that there IS no AIActor class when using the Actor Resource
// this script file exists only to help those familiar with the old Player/AIPlayer
// dichotomy this resource aims to render obsolete

//-----------------------------------------------------------------------------
// Actor callbacks
// The Actor class implements the following callbacks:
//
//    PlayerData::onStuck(%this,%obj)
//    PlayerData::onUnStuck(%this,%obj)
//    PlayerData::onStop(%this,%obj)
//    PlayerData::onMove(%this,%obj)
//    PlayerData::onReachDestination(%this,%obj)
//    PlayerData::onTargetEnterLOS(%this,%obj)
//    PlayerData::onTargetExitLOS(%this,%obj)
//    PlayerData::onAdd(%this,%obj)
//
// Since the Actor doesn't implement it's own datablock, these callbacks
// all take place in the PlayerData namespace.
//-----------------------------------------------------------------------------


// ACTOR -- the DemoPlayer datablock found in aiPlayer.cs has been removed
// its single field has been promoted to the datablock all Actors use, which
// is outlined in actor.cs

function ActorData::onReachDestination(%this,%obj)
{
   // Moves to the next node on the path.
   // Override for all player. Normally we'd override this for only
   // a specific player datablock or class of players.
   if (%obj.path !$= "") {
      if (%obj.currentNode == %obj.targetNode)
         %this.onEndOfPath(%obj,%obj.path);
      else
         %obj.moveToNextNode();
   }
}

function ActorData::onEndOfPath(%this,%obj,%path)
{
   %obj.nextTask();
}

function ActorData::onEndSequence(%this,%obj,%slot)
{
   echo("Sequence Done!");
   %obj.stopThread(%slot);
   %obj.nextTask();
}


//-----------------------------------------------------------------------------
// Actor static functions
//-----------------------------------------------------------------------------

function Actor::spawnAt(%name,%spawnPoint)
{
   // ACTOR Create the actor object (not AIPlayer)
   %actor = new Actor() {
      dataBlock = ActorData;
      path = "";
   };
   %actor.client = 0;
   MissionCleanup.add(%actor);
   %actor.setShapeName(%name);
   %actor.setTransform(%spawnPoint);
   return %actor;
}

function Actor::spawnOnPath(%name,%path)
{
   // Spawn a new actor without a connection
   // and place him on the first node of the path
   if (!isObject(%path))
      return;
   %node = %path.getObject(0);
   %actor = Actor::spawnAt(%name,%node.getTransform());

   return %actor;
}


//-----------------------------------------------------------------------------
// Actor methods 
//-----------------------------------------------------------------------------

function Actor::followPath(%this,%path,%node)
{
   // Start the actor following a path
   %this.stopThread(0);
   if (!isObject(%path)) {
      %this.path = "";
      return;
   }
   if (%node > %path.getCount() - 1)
      %this.targetNode = %path.getCount() - 1;
   else
      %this.targetNode = %node;
   if (%this.path $= %path)
      %this.moveToNode(%this.currentNode);
   else {
      %this.path = %path;
      %this.moveToNode(0);
   }
}

function Actor::moveToNextNode(%this)
{
   if (%this.targetNode < 0 || %this.currentNode < %this.targetNode) {
      if (%this.currentNode < %this.path.getCount() - 1)
         %this.moveToNode(%this.currentNode + 1);
      else
         %this.moveToNode(0);
   }
   else
      if (%this.currentNode == 0)
         %this.moveToNode(%this.path.getCount() - 1);
      else
         %this.moveToNode(%this.currentNode - 1);
}

function Actor::moveToNode(%this,%index)
{
   // Move to the given path node index
   %this.currentNode = %index;
   %node = %this.path.getObject(%index);
   %this.setMoveDestination(%node.getTransform(), %index == %this.targetNode);
}


//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------

function Actor::pushTask(%this,%method)
{
   if (%this.taskIndex $= "") {
      %this.taskIndex = 0;
      %this.taskCurrent = -1;
   }
   %this.task[%this.taskIndex] = %method; 
   %this.taskIndex++;
   if (%this.taskCurrent == -1)
      %this.executeTask(%this.taskIndex - 1);
}

function Actor::clearTasks(%this)
{
   %this.taskIndex = 0;
   %this.taskCurrent = -1;
}

function Actor::nextTask(%this)
{
   if (%this.taskCurrent != -1)
      if (%this.taskCurrent < %this.taskIndex - 1)
         %this.executeTask(%this.taskCurrent++);
      else
         %this.taskCurrent = -1;
}

function Actor::executeTask(%this,%index)
{
   %this.taskCurrent = %index;
   eval(%this.getId() @ "." @ %this.task[%index] @ ";");
}


//-----------------------------------------------------------------------------

function Actor::singleShot(%this)
{
   // The shooting delay is used to pulse the trigger
   %this.setImageTrigger(0,true);
   %this.setImageTrigger(0,false);
   %this.trigger = %this.schedule(%this.shootingDelay,singleShot);
}


//-----------------------------------------------------------------------------

function Actor::wait(%this,%time)
{
   %this.schedule(%time * 1000,"nextTask");
}

function Actor::done(%this,%time)
{
   %this.schedule(0,"delete");
}

function Actor::fire(%this,%bool)
{
   if (%bool) {
      cancel(%this.trigger);
      %this.singleShot();
   }
   else
      cancel(%this.trigger);
   %this.nextTask();
}

function Actor::aimAt(%this,%object)
{
   echo("Aim: " @ %object);
   %this.setAimObject(%object);
   %this.nextTask();
}

function Actor::animate(%this,%seq)
{
   //%this.stopThread(0);
   //%this.playThread(0,%seq);
   %this.setActionThread(%seq);
}


//-----------------------------------------------------------------------------
// this AIManager stuff is called from the end of the server's Game::startGame() code 

function AIManager::think(%this)
{
   // We could hook into the player's onDestroyed state instead of
   // having to "think", but thinking allows us to consider other
   // things...
   if (!isObject(%this.actor))
      %this.actor = %this.spawn();
   %this.schedule(500,think);
}

function AIManager::spawn(%this)
{
   %actor = Actor::spawnOnPath("Kork","MissionGroup/Paths/Path1");
   %actor.followPath("MissionGroup/Paths/Path1",-1);

   %actor.mountImage(CrossbowImage,0);
   %actor.setInventory(CrossbowAmmo,1000);
   return %actor;
}

