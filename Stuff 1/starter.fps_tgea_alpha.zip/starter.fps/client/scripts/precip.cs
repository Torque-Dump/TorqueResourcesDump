//-----------------------------------------------------------------------------
// Torque Shader Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

new ShaderData( PrecipShader )
{
   DXVertexShaderFile   = "shaders/precipV.hlsl";
   DXPixelShaderFile    = "shaders/precipP.hlsl";
   pixVersion = 1.1;
};
