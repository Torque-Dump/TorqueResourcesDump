//-----------------------------------------------------------------------------
// Torque Shader Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

// A temporary hack until we can find a better way to initialize
// material properties.
exec( "./terrains/highplains/propertyMap.cs" );

