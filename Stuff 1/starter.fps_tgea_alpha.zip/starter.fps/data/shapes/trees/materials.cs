// WIP MATERIALS

new Material(bark_tex)
{
   baseTex[0] = "bark";
   //bumpTex[0] = "";
 };
 
new Material(knot_tex)
{
   baseTex[0] = "knot";
   //bumpTex[0] = "";
 };


new Material(foliage_tex)
{
   baseTex[0] = "foliage";
   translucent = true;
   translucentBlendOp = LerpAlpha;
   translucentZWrite = true;
   alphaRef = 20;  // anything below this number is not visible and is not written to zbuffer
};

new Material(foliage2_tex)
{
   baseTex[0] = "foliage";
   translucent = true;
   translucentBlendOp = LerpAlpha;
   translucentZWrite = true;
   alphaRef = 20;  // anything below this number is not visible and is not written to zbuffer
};