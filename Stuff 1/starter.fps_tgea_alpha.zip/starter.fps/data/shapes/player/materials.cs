// WIP MATERIALS

new Material(player_tex)
{
   baseTex[0] = "player";
   //bumpTex[0] = "";
 };
 
