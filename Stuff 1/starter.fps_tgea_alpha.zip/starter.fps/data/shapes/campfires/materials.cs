//*****************************************************************************
// Camp fire materials
//*****************************************************************************

new Material(stoneCF_tex)
{
   baseTex[0] = "stone";
   //bumpTex[0] = "";
 };
 new Material(ashCF_tex)
{
   baseTex[0] = "ash";
   //bumpTex[0] = "";
 };

