// WIP MATERIALS

new Material(healthKit_tex)
{
   baseTex[0] = "healthKit";
   //bumpTex[0] = "";
 };
 
