// WIP MATERIALS

new Material(ammo_tex)
{
   baseTex[0] = "ammo";
   //bumpTex[0] = "";
 };
 
new Material(clip_tex)
{
   baseTex[0] = "clip";
   //bumpTex[0] = "";
 };

new Material(crossbow_tex)
{
   baseTex[0] = "crossbow";
   //bumpTex[0] = "";
 };