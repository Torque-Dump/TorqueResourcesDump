// WIP MATERIALS

new Material(stoneLantern_tex)
{
   baseTex[0] = "stone";
   //bumpTex[0] = "";
 };
 
