//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

addMaterialMapping( "sand" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0" ); 
addMaterialMapping( "grass" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0" ); 
addMaterialMapping( "patchy" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0" ); 