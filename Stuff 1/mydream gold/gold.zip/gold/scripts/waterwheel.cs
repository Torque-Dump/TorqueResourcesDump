//Dream Games inc

datablock AudioProfile(waterfall)
{
filename = "~/data/sound/waterfall.wav";
description = AudioCloseLooping3d;
preload = true;
};

datablock StaticShapeData(Waterwheel)
{
   category = "Animated Shapes";
   className = DefaultRadarData;
   shapeFile = "~/data/interiors/gold/waterwheel.dts";
   maxDamage = 100; // destroyed at 100
   disabledLevel = 80; // disabled beo=yond this damage
   destroyedLevel = 100; // this is max damage
   repairRate = 0.05; // repair at 1.6 points per sec
   
      
};

  
function Waterwheel::onAdd(%this,%obj)
{
   %obj.playThread(0,"ambient");
   %obj.playAudio(0,waterfall);
}











