datablock TSShapeConstructor(DragonDts)
{
   baseShape = "./Dragon.dts";
   sequence0 = "./animations/landRoot.dsq Root";
   sequence1 = "./animations/landWalk.dsq Walk";
   sequence2 = "./animations/landRoarAttack.dsq RoarAttack";
   sequence3 = "./animations/flyingRoot.dsq flyingRoot";
   sequence4 = "./animations/flyingForward.dsq flyingForward";
};