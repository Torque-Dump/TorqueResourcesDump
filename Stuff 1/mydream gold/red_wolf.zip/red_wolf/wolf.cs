datablock TSShapeConstructor(WolfDts)
{
   baseShape = "./wolf.dts";
   sequence0 = "./wolf_root.dsq root";
   sequence1 = "./wolf_run.dsq run";
   sequence2 = "./wolf_attack.dsq attack";
   sequence3 = "./wolf_death.dsq death";
};
