Bookcase by Leighann

This model and textures may only be released as game content.