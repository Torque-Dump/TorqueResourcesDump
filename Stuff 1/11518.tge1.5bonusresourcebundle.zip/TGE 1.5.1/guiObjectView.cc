//-----------------------------------------------------------------------------
// Torque Game Engine
// 
// Copyright (c) 2004 Synapse Gaming
// Copyright (c) 2003 Black Blood Studios
// Copyright (c) 2001 GarageGames.Com
//-----------------------------------------------------------------------------
// This release by: Xavier Amado (xavier@blackbloodstudios.com)
// Credits to : Vinci_Smurf, Loonatik, Matt Webster, Frank Bignone, Xavier Amado
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// What are the changes?
//
// This updated GuiObjectView for TGE 1.5 uses it's own
// LightManager, allowing it to be used in-game without affecting
// scene lighting, and also resolves a crash that occurred
// when exiting the mission.
//
// The new GuiObjectView also supports env mapping on displayed models.
//
//
// How to install it?
//
// Just unzip the files into the 'engine/lightingSystem/' directory, add them
// to your project, then rebuild your project - and your done!
//
//
// How to use it?
//
// Same as the previous GuiObjectView resources. For example; create a
// GuiObjectView control on your game's main menu, give it the name
// MainMenuObjectView, and exec this code in the main menu's onWake event:
//
// MainMenuObjectView.setObject("name", "starter.fps/data/shapes/player/player.dts", 0, 0);
//
// Assuming "starter.fps/data/shapes/player/player.dts" is a valid path to
// the player dts file, the player should appear when the main menu is displayed.
//
// The only new script method is setEmapTexture, which accepts the path to
// the texture used for env mapping.
//
// Enjoy!
//
// -John Kabus
//-----------------------------------------------------------------------------

#include "gui/core/guiCanvas.h"
#include "guiObjectView.h"
#include "console/consoleTypes.h"


//-----------------------------------------------
// Lighting Pack code block
//-----------------------------------------------
static ColorF gOpenGLMaterialAmbientColor(0.f, 0.f, 0.f, 0.f);
static ColorF gOpenGLMaterialDiffuseColor(1.f, 1.f, 1.f, 1.f);
//-----------------------------------------------
// Lighting Pack code block
//-----------------------------------------------
		

static const F32 MaxOrbitDist = 50.0f;
static const S32 MaxAnimations = 6;

IMPLEMENT_CONOBJECT( GuiObjectView );


GuiObjectView::GuiObjectView() : GuiTSCtrl()
{
	mActive = true;

	mMouseState = None;

	// Can zoom and spin by default
	mZoom = true;
	mSpin = true;
	mLastMousePoint.set( 0, 0 );


	//-----------------------------------------------
	// Lighting Pack code block
	//-----------------------------------------------
	sgLightDirection = VectorF(-0.57735f, -0.57735f, -0.57735f);
	sgLightColor = ColorF(0.6f, 0.58f, 0.5f);
	sgAmbientColor = ColorF(0.3f, 0.3f, 0.3f);
	sgEmapAmount = 1.0f;
	//-----------------------------------------------
	// Lighting Pack code block
	//-----------------------------------------------
}

GuiObjectView::~GuiObjectView()
{
	mMeshObjects.Clear();
}


//-----------------------------------------------
// Lighting Pack code block
//-----------------------------------------------
void GuiObjectView::initPersistFields()
{
	Parent::initPersistFields();

	addField("lightDirection", TypePoint3F, Offset(sgLightDirection, GuiObjectView));
	addField("lightColor",     TypeColorF,  Offset(sgLightColor,     GuiObjectView));
	addField("ambientColor",   TypeColorF,  Offset(sgAmbientColor,   GuiObjectView));
	addField("emapAmount",     TypeF32,     Offset(sgEmapAmount,   GuiObjectView));
}


ConsoleMethod(GuiObjectView, setEmapTexture, void, 3, 3, "(texturefilename)")
{
	object->sgEmapTexture = TextureHandle(argv[2], MeshTexture);
}
//-----------------------------------------------
// Lighting Pack code block
//-----------------------------------------------
	

// Script function handling for "setMouse"
ConsoleMethod( GuiObjectView, setMouse, void, 4, 4, "ObjectView.setMouse(canZoom, canSpin)" ) {
	argc;
	GuiObjectView* view = static_cast<GuiObjectView*>( object );
	view->setMouseOptions(dAtob(argv[2]), dAtob(argv[3]));
}

// Script function handling for "setObject"
ConsoleMethod( GuiObjectView, setObject, void, 6, 6, "ObjectView.setObject(name, model, skin, lod)" )
{
	argc;
	GuiObjectView* view = static_cast<GuiObjectView*>( object );
	view->loadObject(argv[2], argv[3], argv[4], "", "", dAtoi(argv[5]));
	view->setCamera();
}

// Script function handling for "mountObject"
ConsoleMethod( GuiObjectView, mountObject, void, 8, 8, "ObjectView.mountObject(name, model, skin, parentName, nodeName, lod)" ) {
	argc;
	GuiObjectView* view = static_cast<GuiObjectView*>( object );
	view->loadObject(argv[2], argv[3], argv[4], argv[5], argv[6] ,dAtoi(argv[7]));
}

// Script function handling for "unMountObject"
ConsoleMethod( GuiObjectView, unMountObject, void, 4, 4, "ObjectView.unMountObject(name, node)" ) {
	argc;
	GuiObjectView* view = static_cast<GuiObjectView*>( object );
	view->unLoadObject(argv[2], argv[3]);
}

// Script function handling for "setEmpty"
ConsoleMethod( GuiObjectView, setEmpty, void, 2, 2, "ObjectView.setEmpty( )" ) {
	argc;
	GuiObjectView* view = static_cast<GuiObjectView*>( object );
	view->Clear();
}

// Script function handling for "loadDSQ"
ConsoleMethod( GuiObjectView, loadDSQ, void, 4, 4, "ObjectView.loadDSQ(name, dsq)" ) {
	argc;
	GuiObjectView* view = static_cast<GuiObjectView*>( object );
	view->loadDSQ(argv[2], argv[3]);
}

// Script function handling for "setSequence"
ConsoleMethod( GuiObjectView, setSequence, void, 5, 5, "ObjectView.setSequence(name, seq, time)" ) {
	argc;
	GuiObjectView* view = static_cast<GuiObjectView*>( object );
	view->setSequence(argv[2], argv[3], dAtof(argv[4]));
}

void GuiObjectView::consoleInit()
{

}

bool GuiObjectView::onWake()
{
	if ( !Parent::onWake() )
		return( false );
      
	mCameraMatrix.identity();
	mCameraRot.set( 0, 0, 3.9 );
	mCameraPos.set( 0, 1.75, 1.25 );
	mCameraMatrix.setColumn( 3, mCameraPos );
	mOrbitPos.set( 0, 0, 0 );
	mOrbitDist = 9.5f;

	return( true );
}

// Function to determine the ways the mouse can interact with the gui object
void GuiObjectView::setMouseOptions( bool zoom, bool spin  )
{
	mZoom = zoom;
	mSpin = spin;
}

// Mouse is down, lock mouse input and get the mouse pointer coordinates and set mode to spin
void GuiObjectView::onMouseDown( const GuiEvent &event )
{
	if ( !mActive || !mVisible || !mAwake || !mSpin )
		return;

	mMouseState = Rotating;

	mLastMousePoint = event.mousePoint;
	mouseLock();
}

// Mouse is up, unlock mouse input
void GuiObjectView::onMouseUp( const GuiEvent &/*event*/ )
{
	mouseUnlock();
	mMouseState = None;
}

// If mouse is dragged, adjust camera position accordingly. Makes model rotate
void GuiObjectView::onMouseDragged( const GuiEvent &event )
{
	if ( mMouseState != Rotating )
		return;

	Point2I delta = event.mousePoint - mLastMousePoint;
	mLastMousePoint = event.mousePoint;

	mCameraRot.x += ( delta.y * 0.01 );
	mCameraRot.z += ( delta.x * 0.01 );
}

// Right mouse is down, lock mouse input and get the mouse pointer coordinates and set mode to zoom
void GuiObjectView::onRightMouseDown( const GuiEvent &event )
{
	if ( !mActive || !mVisible || !mAwake || !mZoom )
		return;

	mMouseState = Zooming;

	mLastMousePoint = event.mousePoint;
	mouseLock();
}

// Right mouse is up, unlock mouse input
void GuiObjectView::onRightMouseUp( const GuiEvent &/*event*/ )
{
	mouseUnlock();
	mMouseState = None;
}

// If mouse is dragged, adjust camera position accordingly. Makes model zoom
void GuiObjectView::onRightMouseDragged( const GuiEvent &event )
{
	if ( mMouseState != Zooming )
		return;

	S32 delta = event.mousePoint.y - mLastMousePoint.y;
	mLastMousePoint = event.mousePoint;

	mOrbitDist += ( delta * 0.01 ); 
}

//-----------------------------------------------------------
void GuiObjectView::setCamera()
{
	// Make sure there is a main object in the scene
	if (mMeshObjects.mMainObject)
	{
		// Initialize camera values:
		mOrbitPos = mMeshObjects.mMainObject->getShape()->center;
		mMinOrbitDist = mMeshObjects.mMainObject->getShape()->radius;
		mOrbitDist = mMinOrbitDist + 1;
	}
}

//------------------------------------------------------------------------------
bool GuiObjectView::processCameraQuery( CameraQuery* query )
{
	// Make sure the orbit distance is within the acceptable range:
	mOrbitDist = ( mOrbitDist < mMinOrbitDist ) ? mMinOrbitDist : ( ( mOrbitDist > MaxOrbitDist ) ? MaxOrbitDist : mOrbitDist );

	// Adjust the camera so that we are still facing the model:
	Point3F vec;
	MatrixF xRot, zRot;
	xRot.set( EulerF( mCameraRot.x, 0, 0 ) );
	zRot.set( EulerF( 0, 0, mCameraRot.z ) );

	mCameraMatrix.mul( zRot, xRot );
	mCameraMatrix.getColumn( 1, &vec );
	vec *= mOrbitDist;
	mCameraPos = mOrbitPos - vec;

	query->nearPlane = 0.1;
	query->farPlane = 2100.0;
	query->fov = 3.1415 / 3.5;
	mCameraMatrix.setColumn( 3, mCameraPos );
	query->cameraMatrix = mCameraMatrix;
	return( true );
}


//------------------------------------------------------------------------------
void GuiObjectView::renderWorld( const RectI &updateRect )
{
	if (!(bool)mMeshObjects.mMainObject)
		return;
	    
	glClear( GL_DEPTH_BUFFER_BIT );
	glMatrixMode( GL_MODELVIEW );

	glEnable( GL_DEPTH_TEST );
	glDepthFunc( GL_LEQUAL );  


	//-----------------------------------------------
	// Lighting Pack code block
	//-----------------------------------------------
	glEnable(GL_LIGHTING);
	LightInfo light;
	light.mType = LightInfo::Vector;
	light.mDirection = sgLightDirection;
	light.mColor = sgLightColor;
	light.mAmbient = sgAmbientColor;

	//sgLightManager.setMaxGLLights(1);
   sgLightManager.sgUnregisterAllLights();
   sgLightManager.sgSetSpecialLight(LightManager::sgSunLightType, &light);

   SceneObject obj;
   obj.receiveSunLight = true;
   obj.receiveLMLighting = false;
   obj.overrideOptions = false;
   sgLightManager.sgSetupLights(&obj, true);
	//-----------------------------------------------
	// Lighting Pack code block
	//-----------------------------------------------


	for (S32 i=0; i<33; i++)
	{
		if (mMeshObjects.mMesh[i].mesh)
		{
			// Animate and render
			if(mMeshObjects.mMesh[i].mode == 1)
			{
				S32 time = Platform::getVirtualMilliseconds();
				S32 dt = time - mMeshObjects.mMesh[i].lastRenderTime;
				mMeshObjects.mMesh[i].lastRenderTime = time;
				F32 fdt = dt;

				mMeshObjects.mMesh[i].mesh->advanceTime( fdt/1000.f, mMeshObjects.mMesh[i].thread );
				mMeshObjects.mMesh[i].mesh->animate();
			}


			//-----------------------------------------------
			// Lighting Pack code block
			//-----------------------------------------------
			if(((TextureObject *)sgEmapTexture) != NULL)
			{
				mMeshObjects.mMesh[i].mesh->setEnvironmentMap(sgEmapTexture);
				mMeshObjects.mMesh[i].mesh->setEnvironmentMapOn(true, sgEmapAmount);
			}
			else
			{
				mMeshObjects.mMesh[i].mesh->setEnvironmentMapOn(false);
			}
			//-----------------------------------------------
			// Lighting Pack code block
			//-----------------------------------------------


			// If this is a mounted object transform to the correct position
			if (mMeshObjects.mMesh[i].parentNode != -1)
			{
				MatrixF mat;
				getObjectTransform( &mat, i ); 
				glPushMatrix();
				dglMultMatrix( &mat );
				mMeshObjects.mMesh[i].mesh->render();
				glPopMatrix();
			}
			else
			{
				mMeshObjects.mMesh[i].mesh->render();
			}
		}
	}


	//-----------------------------------------------
	// Lighting Pack code block
	//-----------------------------------------------	
	sgLightManager.sgResetLights();
	sgLightManager.sgUnregisterAllLights();
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, (const F32 *)gOpenGLMaterialAmbientColor);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, (const F32 *)gOpenGLMaterialDiffuseColor);
	glDisable(GL_LIGHTING);
	//-----------------------------------------------
	// Lighting Pack code block
	//-----------------------------------------------
	

	glDisable( GL_DEPTH_TEST );
	dglSetClipRect( updateRect );
	dglSetCanonicalState();
}

//-----------------------------------------------------------
void GuiObjectView::getObjectTransform( MatrixF *mat , S32 index)
{
	
	MatrixF subTrans = mMeshObjects.mMesh[index].mesh->mNodeTransforms[mMeshObjects.mMesh[index].node];
	Point3F subOffset = -subTrans.getPosition();

	S32 pIndex = mMeshObjects.mMesh[index].parentIndex;
	MatrixF parentTrans = mMeshObjects.mMesh[pIndex].mesh->mNodeTransforms[mMeshObjects.mMesh[index].parentNode];
	parentTrans.mulP( subOffset );
	parentTrans.setPosition( subOffset );
	*mat = parentTrans;
}

//-----------------------------------------------------------
void GuiObjectView::loadObject(const char* name, const char* shape, const char* skin, const char* parentName, const char* nodeName, S32 detail)
{ 
	bool main = (dStrcmp(nodeName,"") == 0);
	S32 index = 0;

	if (main)
	{
		// This is the main object clear out any meshs already loaded
		Clear();

		mMeshObjects.load(0, name, shape, skin, 0, -1, detail);
	}
	else
	{
		// Make sure there is a mMainObject
		if (!mMeshObjects.mMainObject)
		{
			Con::printf("Error: Main object not found");
			return;
		}

		// Check for target node
		S32 pNode;
		S32 pIndex;
		for(S32 i=0; i<33; i++)
		{
			if(dStrcmp(mMeshObjects.mMesh[i].name, parentName) == 0)
			{
				pNode = mMeshObjects.mMesh[i].mesh->getShape()->findNode(nodeName);
				pIndex = i;
				if(pNode == -1)
				{
					Con::printf("Error: Unable to find node %s", nodeName);
					return;
				}

				continue;
			}
		}

		// Check to see if something is already mounted to this object's mountPoint, or if the object name already exists.
		for (S32 i=0; i<33; i++)
		{
			if (mMeshObjects.mMesh[i].parentNode == pNode && mMeshObjects.mMesh[i].parentIndex == pIndex || dStrcmp(mMeshObjects.mMesh[i].name, name) == 0)
			{
				Con::printf("Unloading object %s at %s", mMeshObjects.mMesh[i].name, nodeName);
				mMeshObjects.unLoad(i);
			}
		}

		// This is a mounted object find an open spot for this mesh
		index = mMeshObjects.findOpen();
		if (index == -1)
		{
			Con::printf("Error: Maximum mountable objects reached. Please unMount an object");
			return;
		}

		mMeshObjects.load(index, name, shape, skin, pIndex, pNode, detail);
	}
}

//-----------------------------------------------------------
void GuiObjectView::unLoadObject(const char* name, const char* node)
{ 
	if (dStrcmp(name,"") != 0)
	{
		S32 index = mMeshObjects.findMeshByName(name);
		if (index != -1)
		{
			mMeshObjects.unLoad(index);
			Con::printf("Unloading object %s", name);
		}
		else
		{
			Con::printf("Error: Unable to find object %s", name);
		}
	}
	else if (dStrcmp(node,"") != 0)
	{
		S32 index = mMeshObjects.findMeshByNode(node);
		if (index != -1)
		{
			mMeshObjects.unLoad(index);
			Con::printf("Unloading object at %s", node);
		}
		else
		{
			Con::printf("Error: Unable to find object at %s", node);
		}
	}
}

void GuiObjectView::loadDSQ(const char* name, const char* dsq)
{
	S32 index = mMeshObjects.findMeshByName(name);
	if (index != -1)
	{
		mMeshObjects.mMesh[index].loadDSQ(dsq);
	}
	else
	{
		Con::printf("Error: Could not find object %s", name);
	}
}
//-----------------------------------------------------------
void GuiObjectView::setSequence(const char* name, const char* seq, F32 time)
{
	S32 index = mMeshObjects.findMeshByName(name);
	if (index != -1)
	{
		mMeshObjects.mMesh[index].setSequence(seq, time);
	}
	else
	{
		Con::printf("Error: Could not find object %s", name);
	}
}

//-----------------------------------------------------------
void GuiObjectView::Clear()
{ 
	mMeshObjects.Clear(); 
}


//-----------------------------------------------------------
GuiObjectView::meshObjects::meshObjects()
{
	mMainObject = NULL;
	mDetail = 0;
}

GuiObjectView::meshObjects::~meshObjects()
{
	
}

//-----------------------------------------------------------
void GuiObjectView::meshObjects::load(S32 index, const char* name, const char* shape, const char* skin, S32 pIndex, S32 pNode, S32 detail)
{
	char fileBuffer[256];
	
	// Load the shape
	dSprintf(fileBuffer, sizeof( fileBuffer ), "%s", shape);

	// Load the shape into the ResourceManager
	Resource<TSShape> hShape = ResourceManager->load(fileBuffer);
	if (!bool(hShape))
	{
		Con::printf("Error: Unable to load: %s", shape);
		return;
	}

	// Copy the shape to mMesh
	mMesh[index].mesh = new TSShapeInstance(hShape, true);
	AssertFatal(mMesh[index].mesh, "ERROR!  Failed to load object model!");

	// Load the skin
	if(dStrcmp(skin,"") != 0)
	{
		dSprintf(fileBuffer, sizeof( fileBuffer ), "%s", skin);
		TextureHandle texture = TextureHandle(fileBuffer, MeshTexture, false);
		TSMaterialList* materialList = mMesh[index].mesh->getMaterialList();
		materialList->mMaterials[0] = texture;
	}

	// If a parent Index exists store it.
	if(pIndex)
		mMesh[index].parentIndex = pIndex;

	if (pNode == -1)
	{
		// If this is the main object setup the pointer and global detail level
		mMainObject = mMesh[index].mesh;
		mDetail = detail;	
	}
	else
	{
		// If this is a mounted object set the mountPoint node and parentNode
		mMesh[index].node = mMesh[index].mesh->getShape()->findNode("mountPoint");
		mMesh[index].parentNode = pNode;
	}

	// Set the name
	dSprintf(mMesh[index].name, sizeof( mMesh[index].name ), "%s", name);

	// Set the detail level
	mMesh[index].detail = (detail != -1) ? detail : mDetail;

	// Check the detail level to make sure LOD is valid
	U32 dlNum = mMesh[index].mesh->getNumDetails();
	if(mMesh[index].detail >= dlNum)
	{
		mMesh[index].detail = dlNum - 1;
	}
	mMesh[index].mesh->setCurrentDetail(mMesh[index].detail);

	Con::printf("Loading object %s", shape);
}

//-----------------------------------------------------------
void GuiObjectView::meshObjects::unLoad(S32 index)
{
	if (mMesh[index].mesh)
	{
		dStrcpy(mMesh[index].name, "");
		mMesh[index].mode = 0;
		mMesh[index].node = -1;
		mMesh[index].parentIndex = 0;
		mMesh[index].parentNode = -1;
		mMesh[index].detail = -1;
		mMesh[index].lastRenderTime = 0;
		if (mMesh[index].thread)
		{
			mMesh[index].mesh->destroyThread(mMesh[index].thread);
			mMesh[index].thread = 0;
		}
		
		delete mMesh[index].mesh;
		mMesh[index].mesh = NULL;
	}
}

//-----------------------------------------------------------
S32 GuiObjectView::meshObjects::findOpen()
{
	for (S32 i = 0; i<33; i++)
	{
		if (!mMesh[i].mesh)
		{
			return i;
		}
	}

	return -1;
}

//-----------------------------------------------------------
S32 GuiObjectView::meshObjects::findMeshByName(const char* name)
{
	for (S32 i = 0; i<33; i++)
	{
		if (dStrcmp(mMesh[i].name, name) == 0)
		{
			return i;
		}
	}

	return -1;
}

//-----------------------------------------------------------
S32 GuiObjectView::meshObjects::findMeshByNode(const char* node)
{
	S32 pNode = mMainObject->getShape()->findNode(node);
	if (pNode != -1)
	{
		for (S32 i = 0; i<33; i++)
		{
			if (mMesh[i].parentNode == pNode)
			{
				return i;
			}
		}
	}

	return -1;
}

//-----------------------------------------------------------
void GuiObjectView::meshObjects::Clear()
{
	for (S32 i = 0; i < 33; i++)
	{
		unLoad(i);
	}
	
	mMainObject = NULL;
	mDetail = -1;

}

//-----------------------------------------------------------
GuiObjectView::meshObjects::meshs::meshs()
{
	mesh = NULL;
	mode = 0;
	node = -1;
	parentIndex = 0;
	parentNode = -1;
	detail = 0;
	lastRenderTime = 0;
	thread = 0;
}

GuiObjectView::meshObjects::meshs::~meshs()
{
	if (mesh)
	{
		delete mesh;
		mesh = NULL;
	}

	if (thread)
	{
		mesh->destroyThread(thread);
		thread = 0;
	}
}

//-----------------------------------------------------------
void GuiObjectView::meshObjects::meshs::loadDSQ(const char* dsq)
{
	Stream * f;
	char fileBuffer[256];

	dSprintf(fileBuffer, sizeof( fileBuffer ), "%s", dsq);

	f = ResourceManager->openStream(fileBuffer);
	if (f)
	{
		if (!mesh->getShape()->importSequences(f) || f->getStatus()!=Stream::Ok)
		{
			Con::errorf(ConsoleLogEntry::General,"Load sequence %s failed",dsq);
			return;
		}

		ResourceManager->closeStream(f);
		Con::printf("Loading dsq %s", dsq);
	}
	else
	{
		Con::printf("Error: Unable to open %s", dsq);
	}
}

//-----------------------------------------------------------
void GuiObjectView::meshObjects::meshs::setSequence(const char* seq, F32 time)
{
	S32 sequence = mesh->getShape()->findSequence(seq);

	if( sequence != -1 )
	{
		if (thread)
		{
			mesh->destroyThread(thread);
		}
		// If you found the sequence add the thread and set sequence and scale
		thread = mesh->addThread();
		lastRenderTime = Platform::getVirtualMilliseconds();
		mesh->setPos( thread, 0 );
		mesh->setTimeScale( thread, time );
		mesh->setSequence( thread, sequence, 0 );
		mode = 1;
		Con::printf("Loading sequence %s", seq);
	}
	else
	{
		Con::printf("Error: Could not locate sequence %s", seq);
	}
}

