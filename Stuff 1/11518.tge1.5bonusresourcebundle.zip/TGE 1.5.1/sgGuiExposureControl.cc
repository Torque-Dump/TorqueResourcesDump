//-----------------------------------------------
// Synapse Gaming - Lighting Code Pack
// Copyright � Synapse Gaming 2003
// Written by John Kabus
//
//
// What does it do?
//
// This resource adds the sgGuiExposureControl gui control to TGE 1.5.
// This control allows gamma-style per-client exposure adjustments. The
// exposure level is handled per-color component, which means it also
// performs color filtering, and can also use a mask texture to perform
// per-pixel filtering. Because it's a gui control, exposure and
// filtering can affect the entire screen or a smaller sub-region, and
// other gui controls as well as the scene.
//
//
// How to install it?
//
// Unzip the resource zip file into the TGE lighting system directory
// ('engine/lightingSystem/'), add the unzipped file 'sgGuiExposureControl.cc'
// to your Visual Studio and/or Xcode projects, and then perform a clean
// build of Torque.
//
//
// How to use it?
//
// Add the sgGuiExposureControl gui control over any screen region you want
// to adjust the exposure or filter the color of. Then set the control exposure
// level and/or mask texture to the desired effect. Selecting Filter Children
// also filters the control's children gui controls.
//
// The exposure level is adjusted per-color component, which allows color
// filtering as well as exposure changes. Each color component can range from
// 0.0 - 2.0, with 0.5 allowing the color to remain unchanged. The following
// is a chart of a few color component values and the resulting exposure:
//
// Color Component Value | Exposure
// -----------------------------------------
// 0.0                   | 0   (color removed)
// 0.25                  | 0.5 (half intensity)
// 0.5                   | 1   (unchanged)
// 1.0                   | 2   (double intensity)
// 2.0                   | 4   (quad intensity)
//
//
// The color component range of 0.0 - 1.0 was chosen to represent the exposure
// range 0.0 - 2.0 in order to play nicely with the new Torque gui editor color
// picker, which can only create colors up to 1.0, 1.0, 1.0.
//
// Each color component supports a value up to 2.0 (extending the exposure range
// up to 4.0), however this value must be hand entered into the control's exposure
// member because of the color picker's limited range. There is also an additional
// rendering overhead involved in using this extended range.
//
// The mask texture color components adjust the amount that the exposure member
// will affect the screen on a per-pixel level based on the following formula:
//
// output_intensity = input_intensity * exposure_member_exposure * mask_texture_exposure
//
// The following is a chart of a few mask texture color component values and the
// resulting exposure:
//
// Color Component Value | Exposure
// -----------------------------------------
// 0   (0.0)             | 0   (color removed)
// 63  (0.25)            | 0.25(quarter intensity)
// 127 (0.5)             | 0.5 (half intensity)
// 255 (1.0)             | 1   (unchanged)
//
//
// As an example; if the control's red *exposure* component is 1.0 (which doubles
// intensity) the screen's red color will be doubled. If the mask texture is used
// and its red color component is 0.5 (which halves intensity) the total intensity
// will remain unchanged (intensity * 2 * 0.5 = intensity * 1). If the mask texture
// red color component is 1.0 (which leaves the exposure component intensity unchanged)
// the total intensity is doubled (intensity * 2 * 1 = intensity * 2).
//
// If any of the *exposure* member color components exceed 1.0 (putting them in the
// extended range) the above formula does not entirely apply - some experimentation is
// needed in this case.
//
// Enjoy!
//
//-John Kabus
//-----------------------------------------------
#include "console/consoleTypes.h"
#include "core/bitStream.h"
#include "dgl/dgl.h"
#include "game/gameConnection.h"
#include "gui/core/guiControl.h"
#include "platform/platformVideo.h"
#include "sceneGraph/sceneGraph.h"
#include "sim/netConnection.h"

#include "lightingSystem/sgMissionLightingFilter.h"
#include "lightingSystem/sgLighting.h"
#include "lightingSystem/sgLightingModel.h"


class sgGuiExposureControl : public GuiControl
{
private:
	typedef GuiControl Parent;

protected:
	bool sgFilterChildren;
	ColorF sgExposure;
	StringTableEntry sgMaskTextureName;
	TextureHandle sgMaskTexture;

public:
	//creation methods
	DECLARE_CONOBJECT(sgGuiExposureControl);
	sgGuiExposureControl()
	{
		sgFilterChildren = false;
		sgExposure = ColorF(0.5f, 0.5f, 0.5f, 0.5f);
		sgMaskTextureName = StringTable->insert("");
		sgMaskTexture = NULL;
	}
	static void initPersistFields()
	{
		Parent::initPersistFields();
		addField("filterChildren", TypeBool, Offset(sgFilterChildren, sgGuiExposureControl));
		addField("exposure", TypeColorF, Offset(sgExposure, sgGuiExposureControl));
		addField("maskTextureName", TypeFilename, Offset(sgMaskTextureName, sgGuiExposureControl));
	}
	bool onWake()
	{
		if(!Parent::onWake())
			return false;
		if(*sgMaskTextureName)
			sgMaskTexture = TextureHandle(sgMaskTextureName, BitmapTexture);
		return true;
	}
	void onSleep()
	{
		sgMaskTexture = NULL;
		Parent::onSleep();
	}
	void sgRenderQuad(const RectI &rect)
	{
		Point2I lowerright(rect.point.x + rect.extent.x, rect.point.y + rect.extent.y);

		TextureObject *texobj = sgMaskTexture;
		if(texobj)
		{
			glEnable(GL_TEXTURE_2D);
			glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
			glBindTexture(GL_TEXTURE_2D, texobj->texGLName);
		}
		else
		{
			glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
			glDisable(GL_TEXTURE_2D);
		}

		glBegin(GL_TRIANGLE_FAN);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(rect.point.x, rect.point.y);
		glTexCoord2f(1.0f, 0.0f);
		glVertex2f(lowerright.x, rect.point.y);
		glTexCoord2f(1.0f, 1.0f);
		glVertex2f(lowerright.x, lowerright.y);
		glTexCoord2f(0.0f, 1.0f);
		glVertex2f(rect.point.x, lowerright.y);
		glEnd();

		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
		glDisable(GL_TEXTURE_2D);
	}
	void onRender(Point2I offset, const RectI &updateRect)
	{
		if(sgFilterChildren)
			renderChildControls(offset, updateRect);

		dglSetClipRect(RectI(offset, updateRect.extent));

		glEnable(GL_BLEND);
		glBlendFunc(GL_DST_COLOR, GL_SRC_COLOR);
		//glBlendFunc(GL_ONE, GL_ZERO);

		RectI rect(offset, mBounds.extent);

		glColor3fv(sgExposure);
		sgRenderQuad(rect);

		ColorF extendedexposure = sgExposure - ColorF(1.0f, 1.0f, 1.0f, 0.0f);
		extendedexposure.clamp();
		if((extendedexposure.red + extendedexposure.green + extendedexposure.blue) > 0.0f)
		{
			// second pass should appear additive in nature...
			extendedexposure *= 0.5f;
			extendedexposure += ColorF(0.5f, 0.5f, 0.5f, 1.0f);
			glColor3fv(extendedexposure);
			sgRenderQuad(rect);
		}

		glBlendFunc(GL_ONE, GL_ZERO);
		glDisable(GL_BLEND);

		if(!sgFilterChildren)
			renderChildControls(offset, updateRect);
	}
};

IMPLEMENT_CONOBJECT(sgGuiExposureControl);

