//------------------------------------------------------
// Copyright Roaming Gamer, LLC.
//------------------------------------------------------

/*
Description: Return the distance between this object and %dstObject.
*/
function t2dSceneObject::distanceBetween( %this, %dstObject )
{
}

/*
Description: Return a vector between this object and %dstObject.
*/
function t2dSceneObject::vectorTo( %this, %dstObject )
{
}


/*
Description: Return true if %distObject is in-front of this object.
To be in-front, %dstObject must be within a 180-degree field of view.
*/
function t2dSceneObject::inFrontOfMe( %this, %dstObject )
{
}

/*
Description: Return true if %distObject is behind of this object.
To be in-front, %dstObject must be outside a 180-degree field of view.
*/
function t2dSceneObject::behindMe( %this, %dstObject )
{
}