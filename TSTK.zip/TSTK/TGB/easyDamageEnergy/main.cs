///------------------------------------------------------
// Copyright Roaming Gamer, LLC.
//------------------------------------------------------

// ******************************************************
//                 SIMPLE GAME METRICS
// ******************************************************
// * Damage Points - damage.cs, repair.cs
// * Energy Points - energy.cs, recharge.cs
// * Magic Points  - magic.cs, mrecharge.cs 
// ******************************************************
exec("./damage.cs");
exec("./energy.cs");
exec("./helperMethods.cs");




