//------------------------------------------------------
// Copyright Roaming Gamer, LLC.
//------------------------------------------------------
if($TSTK::Initialized) return;

////
//   Enable Settings for loading the various script tool kits
//   and initializing the RG Event Router
////
$TSTK::LoadContributors = true;
$TSTK::LoadCommon = true;
$TSTK::LoadTGB = true;
$TSTK::LoadTGE = true;

$TSTK::InitEventRouter = true;

// TGB Specific Flags/Enables
$TSTK::Enable_ConfigDatablock_BehaviorFix = true;
$TSTK::UseTGBQuickConfig = true;
$TSTK::UseTGBEasyGameMetrics = true;

$TSTK::Description    = "Torque Script Toolkit";
$TSTK::Version        = 106;
$TSTK::LastUpdate     = "31 DEC 2009";

package TSTK_Package {
   function rgVersions()
   {
      Parent::rgVersions();
      echo( $TSTK::Description @ ":" SPC $TSTK::Version SPC "Last updated:" SPC $TSTK::LastUpdate );      
   }

   function onStart()
   {
     Parent::onStart();
      exec("./TSTK/main.cs");
      initTSTK();          
   }   
   
   function initTSTK()
   {  

      ////
      //  Load TSTK Preferences
      ////
      exec("./prefs.cs");

      if( $TSTK::LoadContributors )
      {
         exec("./contributors/DigitalFlux.cs");
      }

      if( $TSTK::LoadCommon )
      {
         exec("./common/utilities/actionmap.cs");
         exec("./common/utilities/ArrayObject.cs");
         exec("./common/utilities/Fields.cs");
         exec("./common/utilities/File.cs");
         exec("./common/utilities/GUI.cs");
         exec("./common/utilities/Math.cs");
         exec("./common/utilities/Objects.cs");
         exec("./common/utilities/Records.cs");
         exec("./common/utilities/SimSet.cs");
         exec("./common/utilities/Strings.cs");
         exec("./common/utilities/Words.cs");
      
         exec("./common/EventRouter/EventRouter.cs");
         exec("./common/EventRouter/EventBind.cs");
      }
      
      if( $TSTK::LoadTGB )
      {
         exec("./TGB/accessMethodGenerators.cs");
         exec("./TGB/behaviors.cs");
         exec("./TGB/effects.cs");
         exec("./TGB/EventManager.cs");
         exec("./TGB/ImageMaps.cs");
         exec("./TGB/levelLoading.cs" ); 
         exec("./TGB/special.cs");
         exec("./TGB/targeting.cs");
         exec("./TGB/t2dSceneObject.cs");
         exec("./TGB/WorldLimit.cs");

         if( $TSTK::UseTGBQuickConfig )
         {      
            exec("./TGB/quickConfig/main.cs");
         }

         exec("./TGB/editors/fieldTypes.ed.cs" ); 
         exec("./TGB/editors/levelEditor.ed.cs" );

         if( $TSTK::UseTGBEasyGameMetrics )
         {      
            exec("./TGB/easyDamageEnergy/main.cs" ); 
         }

      }
   
      if( $TSTK::LoadTGE )
      {
         exec("./TGE/GameBase.cs");
         exec("./TGE/Networking.cs");
         exec("./TGE/SceneObject.cs");   
      }
      
      if( $TSTK::InitEventRouter )
      {      
         initializeEventRouterSystem();
      }
      
      $TSTK::Initialized = true;
   }   
   
   
   function TSTK::doco()
   {
   }
};

activatePackage( TSTK_Package );
