$pref::JoystickDeadZone = 0.2;
