//------------------------------------------------------
// Copyright Roaming Gamer, LLC.
//------------------------------------------------------

/*
Description: Return true if %obj is in in the GameBase object hierarchy.
*/
function isGameBase( %obj ) 
{
	return ( %obj.getType() == $TypeMasks::GameBaseObjectType );
}
