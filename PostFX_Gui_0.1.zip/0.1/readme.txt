I needed control over the postFX system, so i made a temporary GUI. Hope this helps until the engine gets its own shiny new controls :) 

To install : 

First, load the GUI's in game/core/main.cs ( I load it right after the options GUI : about line 79 ).


   exec("./scripts/gui/postProcessOptionsDlg.cs");   
   exec("./art/gui/postProcessOptionsDlg.gui"); 


Second, add the menu item in game\tools\worldEditor\scripts\menus.ed.cs (about line 139)


 item[14] = "Post Process Options" TAB "" TAB "Canvas.pushDialog(postProcessOptionsDlg);";


TODO : 

Fix the ranges of the SSAO Near/Far tab (they are way off at the moment)
Look at what certain things ACTUALLY do (instead of guessing names based on variables)




