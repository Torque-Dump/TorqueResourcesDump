<?php
   $Check = $_GET["File"];
   $PathToCDir = "/path/to/current/folder/".$Check."";
   if(is_file($PathToCDir)) {
      echo 'Exists';
   }
   else {
      echo 'Does Not Exist';
   }
?>
