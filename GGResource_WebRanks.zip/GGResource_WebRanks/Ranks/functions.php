<?php
   function getUserPass($user) {
      if($user == "")
         return 0;
      $con = mysql_connect("localhost","YOURSQLUSERNAMEHERE","YOURSQLPASSWORDHERE");
      if (!$con)
         die("sql_error");
      mysql_select_db("YOURDBHERE", $con);
      $result = mysql_query("SELECT * FROM YOURTABLEHERE WHERE Username='$user'");
      if (!$result)
         die("sql_error");
      while($row1 = mysql_fetch_array($result))
         $match1 = $row1['Password'];
      if($match1)
         return $match1;
      else
         return 0;
   }

   function CompareHash($user, $nameasHash, $providedhash)
   {
      $time = time();
      $time = "$time";
      //echo "pgd_debug Epoch ".substr($time, 0, -2)."\n";
      $salt  = base64_encode(substr($time, 0, -3));
      //echo "pgd_debug Salt ".$salt."\n";
      $nonce = sha1($user.$nameasHash);
      //echo "pgd_debug nonce ".$nonce."\n";

      $pass  = getUserPass($user);

      if ($pass)
      {
         $hash = sha1($user . ":" . $pass);
         $compare = sha1($nonce . $hash . $salt);
         //echo "pgd_debug hash ".$compare."\n";
         if (strcmp($providedhash, $compare) == 0)
           return 1;
         else
           return 0;
      }
      else
        return 0;
   }

   function IsBanned($guid) {
      $con = mysql_connect("localhost","YOURSQLUSERNAMEHERE","YOURSQLPASSWORDHERE");
      if (!$con) {
         die('sql_error');
      }
      mysql_select_db("YOURSQLDBHERE", $con);
      $result = mysql_query("SELECT * FROM YOURTABLEHERE WHERE guid=$guid");
      while($row = mysql_fetch_array($result)) 
      {
         $expire = $row['Expre'];
         //in yyyymmdd
         $cur = gmdate("Ymd");
         if($expire > $cur) 
         {
            return $row['reason'];
         }
         else 
         {
            return 0;
         }
      }
   } 
   
   function ModRequiresAuth($MOD) {
      if($MOD == "GarageGames_Rocks") {
         return 1;
      }
      else if($MOD == "SomeOtherCompany") {
         return 0;
      }
   }
   
   function BadVersion($MOD, $VER) {
      if($MOD == "GarageGames_Rocks") {
         if($VER < 1) {
            return 1;
         }
         else {
            return 0;
         }
      }   
      return 0;
   }
   
   function isDev($guid) {
      if(strcmp($guid, "putYourGUIDHere") == 0) {
         return true;
      }
      else {
         return false;
      }
   }
?>
