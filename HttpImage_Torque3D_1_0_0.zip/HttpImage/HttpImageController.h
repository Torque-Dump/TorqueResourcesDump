//-----------------------------------------------------------------------------
// Torque Twitter Itegration
// Copyright (C) Violent Tulip.
//-----------------------------------------------------------------------------

#ifndef _HTTPIMAGECONTROLLER_H_
#define _HTTPIMAGECONTROLLER_H_

#ifndef _PLATFORM_PLATFORMNET_H_
#include "platform/platformNet.h"
#endif

#ifndef _GFXTEXTUREHANDLE_H_
#include "gfx/gfxTextureHandle.h"
#endif

//-----------------------------------------------------------------------------

class HttpImageController
{
public:
    
    typedef Delegate<void( GFXTexHandle& )> ResponseDelegate;

protected:

    NetSocket           mSocket;
    U8                 *mResponseBuffer;
    U32                 mResponseSize;
    ResponseDelegate    mResponseDelegate;

    String              mImageUrl;
    GFXTexHandle        mImageObject;

public:

    /// Constructor.
    HttpImageController( void );
    /// Destructor.
    ~HttpImageController( void );

    /// Load the Image.
    void LoadImage( const String &pUrl );
    /// Get the Image.
    GFXTexHandle &GetImage( void ) { return mImageObject; };

    /// Is Connected?
    bool IsConnected( void ) const;

    /// Make Connection.
    bool Connect( const String &pUrl );
    /// On Connect.
    void OnConnect( void );
    /// On Connect Fail.
    void OnConnectFail( void );

    /// Send Command.
    bool Send( const String &pString );
    /// Send Command.
    bool Send( const U8 *pBuffer, const U32 &pSize );

    /// Break Connection.
    void Disconnect( void );
    /// On Break Connection.
    void OnDisconnect( void );

    /// Parse Response.
    void ParseResponse( U8 *pBuffer, const U32 &pSize );
    /// Get Response Header.
    void ParseResponseHeader( U8 *pData, const U32 &pLength, U32 &pHeaderSize );
    /// Get Response Delegate.
    ResponseDelegate &GetResponseDelegate( void ) { return mResponseDelegate; };

public:

    /// On Update Connection.
    void OnUpdateConnection( NetSocket pSocket, U32 pState );
    /// On Receive Data.
    void OnReceiveData( NetSocket pSocket, RawData pData );
};

#endif // _HTTPIMAGECONTROLLER_H_