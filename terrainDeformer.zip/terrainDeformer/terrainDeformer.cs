$myDeformer = TerrainDeformer;

// resetSelWeights ( true ); 
// resetLife();   -- Resets the deformers life 
// enableManualUpdate(); -- Stops the deformer updating the terrain, use completeUpdates()
// disableManualUpdate(); -- The deformer automatically updates the terrain
// completeUpdates(); -- Updates the terrain after deformation (for ue with manual updates)
// updateMaterial ( index, matName ); -- Updates the material name at the specified index

// getBrushType(); 
// getBrushSize();
// getBrushPressure();
// getBrushSoftness();
// getBrushPos();
// getActionName( num );
// getNumActions();
// getCurrentAction();
// getActiveTerrain();
// getNumtextures();
// getMaterialCount();
// getmaterialIndex();
// getMaterials();
// getTerrainUnderWorldPoint( x, y, z );
// getSlopeLimitMinAngle();
// getSlopeLimitMaxAngle();

// setBrushType( "type" ); -- (Box, Ellipse)
// setBrushSize( w, h ); -- In squares
// setBrushpressure( pressure );
// setBrushSoftness ( pressure );
// setBrushPos( x, y );
// setFirstAction( "action" ); -- The first action to process (raiseHeight, lowerHeight, setHeight, setEmpty, clearEmpty, smoothHeight, paintNoise)
// setSecondAction( "action" ); -- The second action to process (raiseHeight, lowerHeight, setHeight, setEmpty, clearEmpty, smoothHeight, paintNoise)
// setThirdAction( "action" ); -- The third action to process (raiseHeight, lowerHeight, setHeight, setEmpty, clearEmpty, smoothHeight, paintNoise)
// setSlopeLimitMinAngle( Angle );
// setSlopeLimitMaxAngle( Angle ); 
// setDeformObject( "Object" ) -- The object to attatch the deformer to 
// setDefaultPaintTexture( "Texture" ) -- The texture to apply to a deformed area
// setSteepPaintTexture( "Texture" ) -- Set's the texture to use on steep terrain sides (side projection) 
// setLifeTime( int ) -- Set how many ticks the deformer lives before dying

// Note: Actions are processed 1 > 3 then updated once at the end  



// Called when the terrain is deformed
function Deformer::onActiveTerrainChange( %this, %terrainBlock, %x, %y, %z )
{
   echo("----> TERRAIN BLOCK: " @ %terrainBlock @ " HAS BEEN DEFORMED AT - X:" @ %x @ " Y:" @ %y @ " Z:" @ %z);
}

// Initializes the the Deformer 
function Deformer::Setup(){
   
   $myDeformer = new TerrainDeformer();   

   $myDeformer.setDeformObject("theObject");
   
   $myDeformer.setFirstAction("softSelect");
   
   $myDeformer.setSecondAction("lowerHeight");
   
   // $myDeformer.setThirdAction("paintNoise");
   
   $myDeformer.setDefaultPaintTexture("rock");
   
   // $myDeformer.setSteepPaintTexture("sRock");
   
   
   $myDeformer.setBrushType("ellipse");
   // $myDeformer.setBrushType("Box");
   
}

function Deformer::createAbomb(){
}

function Deformer::attatchRocketDeformer( %Object )
{
   $myDeformer.setDeformObject(%Object);
   
   $myDeformer.attachTerrain("theTerrain");
   
   $myDeformer.setBrushSize(8, 8);
   
   $myDeformer.setBrushType("ellipse");
   
   $myDeformer.setDefaultPaintTexture("rock");
   
   $myDeformer.setSteepPaintTexture("rockS");
   
   $myDeformer.setFirstAction("softSelect");
   
   $myDeformer.setSecondAction("lowerHeight");
   
   //$myDeformer.setThirdAction("paintMaterial");
}

function Deformer::attatchPowerfullRocketDeformer( %Object )
{
   $myDeformer.setDeformObject(%Object);
   
   $myDeformer.attachTerrain("theTerrain");
   
   $myDeformer.setBrushSize(16, 16);
   
   $myDeformer.setBrushType("ellipse");
   
   $myDeformer.setDefaultPaintTexture("rocktest");
   
   $myDeformer.setSteepPaintTexture("rocktest2");
   
   $myDeformer.setFirstAction("lowerHeight");
   
   $myDeformer.setSecondAction("paintMaterial");
   
   //$myDeformer.setThirdAction("paintNoise");
}

function Deformer::showGUI( %simgroup ) {
   

   Canvas.pushDialog(terrainDeformerDLG);
   //MBSetText(IODropdownText, IODropdownFrame, %message);
   
   if(isObject(%simgroup))
   {
      for(%i = 0; %i < %simgroup.getCount(); %i++)
         ddlSimObjects.add(%simgroup.getObject(%i).getName());
      
   }
   
   ddlSimObjects.sort();
   ddlSimObjects.setFirstSelected(0);
   
   ddlSimObjects.callback = %callback;
   ddlSimObjects.cancelCallback = %cancelCallback;
}