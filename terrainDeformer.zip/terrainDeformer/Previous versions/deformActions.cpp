//------------------------------------------------------------------------------
// Torque 3D
// Copyright (C) GarageGames.com, Inc.
//------------------------------------------------------------------------------
#include "platform/platform.h"
#include "T3D/TerrainDeformer/deformActions.h"
#include "gui/core/guiCanvas.h"

//------------------------------------------------------------------------------
void DeformPaintMaterialAction::process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type)
{
   S32 mat = mTerrainDeformer->getDefaultPaintMaterialIndex();
   S32 matParallax = mTerrainDeformer->getSteepPaintMaterialIndex();

   if ( !selChanged || mat < 0 )
      return;

   const bool slopeLimit = mTerrainDeformer->mSlopeMinAngle > 0.0f || mTerrainDeformer->mSlopeMaxAngle < 90.0f;

   const F32 minSlope = mSin( mDegToRad( 90.0f - mTerrainDeformer->mSlopeMinAngle ) );
   const F32 maxSlope = mSin( mDegToRad( 90.0f - mTerrainDeformer->mSlopeMaxAngle ) );

   const TerrainBlock *terrain = mTerrainDeformer->getActiveTerrain();
   const F32 squareSize = terrain->getSquareSize();

   Point2F p;
   Point3F norm;


   for( U32 i = 0; i < sel->size(); i++ )
   {
      GridInfo &inf = (*sel)[i];

      p.x = inf.mGridPoint.gridPos.x * squareSize;

      p.y = inf.mGridPoint.gridPos.y * squareSize;

      if ( !terrain->getNormal( p, &norm, true ) )
        continue;

      if ( slopeLimit )
      {
         if (  norm.z > minSlope ||
               norm.z < maxSlope )
            continue;  
      }

 
      // Painting is really simple now... set the one mat index.
	  if (norm.z < 0.40 && matParallax > -1)
	  {
		if (inf.mMaterial == matParallax)
			continue;

		inf.mMaterial = matParallax;
		inf.mMaterialChanged = true;
	  }
	  else 
	  {
		if (inf.mMaterial == mat) 
			continue; 

		inf.mMaterial = mat;
		inf.mMaterialChanged = true;
	  }

      mTerrainDeformer->setGridInfo(inf, true);
   }

   mTerrainDeformer->scheduleMaterialUpdate();
}

//------------------------------------------------------------------------------
void DeformClearMaterialsAction::process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type)
{
   if(selChanged)
   {
      for(U32 i = 0; i < sel->size(); i++)
      {
         GridInfo &inf = (*sel)[i];

         inf.mMaterialChanged = true;

         // Reset to the first texture layer.
         inf.mMaterial = 0; 
         mTerrainDeformer->setGridInfo(inf);
      }
      mTerrainDeformer->scheduleMaterialUpdate();
   }
}

//------------------------------------------------------------------------------
void DeformRaiseHeightAction::process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type)
{
   // ok the raise height action is our "dirt pour" action
   // only works on brushes...

   DeformBrush *deformBrush = dynamic_cast<DeformBrush *>(sel);

   if(!deformBrush)
      return;

   Point2I brushPos = deformBrush->getPosition();

   Point2I brushSize = deformBrush->getSize();

   GridPoint brushGridPoint = deformBrush->getGridPoint();

   Vector<GridInfo> cur; // the height at the DeformBrush position

   mTerrainDeformer->getGridInfos(brushGridPoint, cur);

   if (cur.size() == 0)
      return;

   // we get 30 process actions per second (at least)
   F32 heightAdjust = mTerrainDeformer->mAdjustHeightVal / 30;

   // nothing can get higher than the current DeformBrush pos adjusted height
   F32 maxHeight = cur[0].mHeight + heightAdjust;

   for(U32 i = 0; i < sel->size(); i++)
   {
      if((*sel)[i].mHeight < maxHeight)
      {
         (*sel)[i].mHeight += heightAdjust * (*sel)[i].mWeight;
         if((*sel)[i].mHeight > maxHeight)
			(*sel)[i].mHeight = maxHeight;
      }
      mTerrainDeformer->setGridInfo((*sel)[i]);
   }

   mTerrainDeformer->scheduleGridUpdate();   
}

//------------------------------------------------------------------------------
void DeformLowerHeightAction::process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type)
{
   // ok the lower height action is our "dirt dig" action
   // only works on brushes...
   DeformBrush *deformBrush = dynamic_cast<DeformBrush *>(sel);

   if(!deformBrush)
      return;

   Point2I brushPos = deformBrush->getPosition();
   Point2I brushSize = deformBrush->getSize();
   GridPoint brushGridPoint = deformBrush->getGridPoint();

   Vector<GridInfo> cur; // the height at the DeformBrush position
   mTerrainDeformer->getGridInfos(brushGridPoint, cur);

   if (cur.size() == 0)
      return;

   // we get 30 process actions per second (at least)
   F32 heightAdjust = -mTerrainDeformer->mAdjustHeightVal / 30;
   // nothing can get higher than the current DeformBrush pos adjusted height

   F32 maxHeight = cur[0].mHeight + heightAdjust;
   if(maxHeight < 0)
      maxHeight = 0;

   for(U32 i = 0; i < sel->size(); i++)
   {
      if((*sel)[i].mHeight > maxHeight)
      {
         (*sel)[i].mHeight += heightAdjust * (*sel)[i].mWeight;
         if((*sel)[i].mHeight < maxHeight)
            (*sel)[i].mHeight = maxHeight;
      }
      mTerrainDeformer->setGridInfo((*sel)[i]);
   }

   mTerrainDeformer->scheduleGridUpdate();   
}

//------------------------------------------------------------------------------
void DeformSetHeightAction::process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type)
{
   if(selChanged)
   {
	  if ( mTerrainDeformer->getGridHeight(deformEvent.gPos) != mTerrainDeformer->getHeight(deformEvent.wPos) )
	  {
		  for(U32 i = 0; i < sel->size(); i++)
		  {
			 (*sel)[i].mHeight = mTerrainDeformer->getHeight(deformEvent.wPos);
			 mTerrainDeformer->setGridInfo((*sel)[i]);
		  }
		  mTerrainDeformer->scheduleGridUpdate();
	  }
   }
}
//------------------------------------------------------------------------------
void DeformSetEmptyAction::process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type)
{
   if ( !selChanged )
      return;

   mTerrainDeformer->setMissionDirty();

   for ( U32 i = 0; i < sel->size(); i++ )
   {
      GridInfo &inf = (*sel)[i];

      // Skip already empty blocks.
      if ( inf.mMaterial == U8_MAX )
         continue;

      inf.mMaterialChanged = true;

      // Set the material to empty.
      inf.mMaterial = -1;
      mTerrainDeformer->setGridInfo( inf );
   }

   mTerrainDeformer->scheduleGridUpdate();
}

//------------------------------------------------------------------------------
void DeformClearEmptyAction::process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type)
{
   if ( !selChanged )
      return;

   mTerrainDeformer->setMissionDirty();

   for ( U32 i = 0; i < sel->size(); i++ )
   {
      GridInfo &inf = (*sel)[i];

      // Skip if not empty.
      if ( inf.mMaterial != U8_MAX )
         continue;

      inf.mMaterialChanged = true;

      // Set the material
      inf.mMaterial = 0;
      mTerrainDeformer->setGridInfo( inf );
   }

   mTerrainDeformer->scheduleGridUpdate();
}

//------------------------------------------------------------------------------
void DeformBrushAdjustHeightAction::process(DeformSelection * sel, const DeformEvent & deformEvent, bool, Type type)
{
   if(type == Process)
      return;

   TerrainBlock *terrBlock = mTerrainDeformer->getActiveTerrain();

   if ( !terrBlock )
      return;


	// ok, collide the ray from the deformEvent with the intersection plane:

	Point3F intersectPoint;
	Point3F start = Point3F(deformEvent.wPos.x, deformEvent.wPos.y, 0);
	Point3F end = Point3F(deformEvent.gPos.x, deformEvent.gPos.y, 0);

	F32 t = mIntersectionPlane.intersect(start, end);

	m_point3F_interpolate( start, end, t, intersectPoint);
	F32 currentZ = mDot(mTerrainUpVector, intersectPoint);

	F32 diff = currentZ - mPreviousZ;

	for(U32 i = 0; i < sel->size(); i++)
	{
	 (*sel)[i].mHeight = (*sel)[i].mStartHeight + diff * (*sel)[i].mWeight;

	 // clamp it
	 if((*sel)[i].mHeight < 0.f)
		(*sel)[i].mHeight = 0.f;
	 if((*sel)[i].mHeight > 2047.f)
		(*sel)[i].mHeight = 2047.f;

	 mTerrainDeformer->setGridInfoHeight((*sel)[i]);

	}

	mTerrainDeformer->scheduleGridUpdate();

}

//------------------------------------------------------------------------------
DeformAdjustHeightAction::DeformAdjustHeightAction(TerrainDeformer * editor) : DeformBrushAdjustHeightAction(editor) {mCursor = 0;}
//------------------------------------------------------------------------------
void DeformAdjustHeightAction::process(DeformSelection *sel, const DeformEvent & deformEvent, bool b, Type type)
{
   DeformSelection * curSel = mTerrainDeformer->getCurrentSel();
   DeformBrushAdjustHeightAction::process(curSel, deformEvent, b, type);
}
//------------------------------------------------------------------------------
void DeformFlattenHeightAction::process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type)
{
   if(!sel->size())
      return;

   if(selChanged)
   {
      F32 average = 0.f;

      // get the average height
      U32 cPrimary = 0;
      for(U32 k = 0; k < sel->size(); k++)
         if((*sel)[k].mPrimarySelect)
         {
            cPrimary++;
            average += (*sel)[k].mHeight;
         }

      average /= cPrimary;

      // set it
      for(U32 i = 0; i < sel->size(); i++)
      {
         if((*sel)[i].mPrimarySelect)
            (*sel)[i].mHeight = average;
         else
         {
            F32 h = average - (*sel)[i].mHeight;
            (*sel)[i].mHeight += (h * (*sel)[i].mWeight);
         }

         mTerrainDeformer->setGridInfo((*sel)[i]);
      }
      mTerrainDeformer->scheduleGridUpdate();
   }
}

//------------------------------------------------------------------------------
void DeformSmoothHeightAction::process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type)
{
   if(!sel->size())
      return;

   if(selChanged)
   {
      F32 avgHeight = 0.f;
      for(U32 k = 0; k < sel->size(); k++)
      {
         avgHeight += (*sel)[k].mHeight;
      }

      avgHeight /= sel->size();

      // clamp the terrain smooth factor...
      if(mTerrainDeformer->mSmoothFactor < 0.f)
         mTerrainDeformer->mSmoothFactor = 0.f;
      if(mTerrainDeformer->mSmoothFactor > 1.f)
         mTerrainDeformer->mSmoothFactor = 1.f;

      // linear
      for(U32 i = 0; i < sel->size(); i++)
      {
         (*sel)[i].mHeight += (avgHeight - (*sel)[i].mHeight) * mTerrainDeformer->mSmoothFactor * (*sel)[i].mWeight;
         mTerrainDeformer->setGridInfo((*sel)[i]);
      }
      mTerrainDeformer->scheduleGridUpdate();
   }
}

//------------------------------------------------------------------------------
void DeformPaintNoiseAction::process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type type)
{
   // If this is the ending mouse down deformEvent, then update the noise values.
   if ( type == Begin )
   {
      mNoise.setSeed( Sim::getCurrentTime() );
      mNoise.fBm( &mNoiseData, mNoiseSize, 12, 1.0f, 5.0f );
      mNoise.getMinMax( &mNoiseData, &mMinMaxNoise.x, &mMinMaxNoise.y, mNoiseSize );
    
      mScale = 1.5f / ( mMinMaxNoise.x - mMinMaxNoise.y);
   }

   if( selChanged )
   {
      for( U32 i = 0; i < sel->size(); i++ )
      {
         const Point2I &gridPos = (*sel)[i].mGridPoint.gridPos;

         const F32 noiseVal = mNoiseData[ ( gridPos.x % mNoiseSize ) + 
                                          ( ( gridPos.y % mNoiseSize ) * mNoiseSize ) ];

         (*sel)[i].mHeight += (noiseVal - mMinMaxNoise.y * mScale) * (*sel)[i].mWeight * mTerrainDeformer->mNoiseFactor;

         mTerrainDeformer->setGridInfo((*sel)[i]);
      }

      mTerrainDeformer->scheduleGridUpdate();
   }
}

//------------------------------------------------------------------------------
void DeformSoftSelectAction::process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type type)
{
   TerrainBlock *terrBlock = mTerrainDeformer->getActiveTerrain();
   if ( !terrBlock )
      return;
      
   // allow process of current selection
   DeformSelection tmpSel;
   if(sel == mTerrainDeformer->getCurrentSel())
   {
      tmpSel = *sel;
      sel = &tmpSel;
   }

   if(type == Begin || type == Process)
      mFilter.set(1, &mTerrainDeformer->mSoftSelectFilter);

   //
   if(selChanged)
   {
      F32 radius = mTerrainDeformer->mSoftSelectRadius;
      if(radius == 0.f)
         return;

      S32 squareSize = terrBlock->getSquareSize();
      U32 offset = U32(radius / F32(squareSize)) + 1;

      for(U32 i = 0; i < sel->size(); i++)
      {
         GridInfo & info = (*sel)[i];

         info.mPrimarySelect = true;
         info.mWeight = mFilter.getValue(0);

         if(!mTerrainDeformer->getCurrentSel()->add(info))
            mTerrainDeformer->getCurrentSel()->setInfo(info);

         Point2F infoPos((F32)info.mGridPoint.gridPos.x, (F32)info.mGridPoint.gridPos.y);

         //
         for(S32 x = info.mGridPoint.gridPos.x - offset; x < info.mGridPoint.gridPos.x + (offset << 1); x++)
            for(S32 y = info.mGridPoint.gridPos.y - offset; y < info.mGridPoint.gridPos.y + (offset << 1); y++)
            {
               //
               Point2F pos((F32)x, (F32)y);

               F32 dist = Point2F(pos - infoPos).len() * F32(squareSize);

               if(dist > radius)
                  continue;

               F32 weight = mFilter.getValue(dist / radius);

               //
               GridInfo gInfo;
               GridPoint gridPoint = info.mGridPoint;
               gridPoint.gridPos.set(x, y);

               if(mTerrainDeformer->getCurrentSel()->getInfo(Point2I(x, y), gInfo))
               {
                  if(gInfo.mPrimarySelect)
                     continue;

                  if(gInfo.mWeight < weight)
                  {
                     gInfo.mWeight = weight;
                     mTerrainDeformer->getCurrentSel()->setInfo(gInfo);
                  }
               }
               else
               {
                  Vector<GridInfo> gInfos;
                  mTerrainDeformer->getGridInfos(gridPoint, gInfos);

                  for (U32 z = 0; z < gInfos.size(); z++)
                  {
                     gInfos[z].mWeight = weight;
                     gInfos[z].mPrimarySelect = false;
                     mTerrainDeformer->getCurrentSel()->add(gInfos[z]);
                  }
               }
            }
      }
   }
}
//------------------------------------------------------------------------------