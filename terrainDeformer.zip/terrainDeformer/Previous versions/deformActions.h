//--------------------------------------------------------------------------------
// Torque 3D
// Copyright (C) GarageGames.com, Inc.
//--------------------------------------------------------------------------------
#ifndef _DeformActions_H_

	#define _DeformActions_H_

	#ifndef _TerrainDeformer_H_
		#include "T3D/terrainDeformer/terrainDeformer.h"
	#endif

	#ifndef _GUIFILTERCTRL_H_
		#include "gui/editor/guiFilterCtrl.h"
	#endif

	#ifndef _NOISE2D_H_
		#include "util/noise2d.h"
	#endif

	//------------------------------------------------------------------------------
	class DeformAction
	{
	   protected:
		  TerrainDeformer *         mTerrainDeformer;

	   public:

		  virtual ~DeformAction(){};
		  DeformAction(TerrainDeformer * editor) : mTerrainDeformer(editor){}

		  virtual StringTableEntry getName() = 0;

		  enum Type {
			 Begin = 0,
			 Update,
			 End,
			 Process
		  };

		  //
		  virtual void process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type type) = 0;
		  virtual bool useMouseBrush() { return(true); }
	};

	//------------------------------------------------------------------------------
	class DeformPaintMaterialAction : public DeformAction
	{
	   public:
		  DeformPaintMaterialAction(TerrainDeformer * editor) : DeformAction(editor){}
		  StringTableEntry getName(){return("paintMaterial");}

		  void process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type type);
	};

	//------------------------------------------------------------------------------
	class DeformClearMaterialsAction : public DeformAction
	{
	public:
	   DeformClearMaterialsAction(TerrainDeformer * editor) : DeformAction(editor){}
	   StringTableEntry getName(){return("clearMaterials");}

	   void process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type type);
	};

	//------------------------------------------------------------------------------
	class DeformRaiseHeightAction : public DeformAction
	{
	   public:
		  DeformRaiseHeightAction(TerrainDeformer * editor) : DeformAction(editor){}
		  StringTableEntry getName(){return("raiseHeight");}

		  void process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type type);
	};

	//------------------------------------------------------------------------------
	class DeformLowerHeightAction : public DeformAction
	{
	   public:
		  DeformLowerHeightAction(TerrainDeformer * editor) : DeformAction(editor){}
		  StringTableEntry getName(){return("lowerHeight");}

		  void process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type type);
	};

	//------------------------------------------------------------------------------
	class DeformSetHeightAction : public DeformAction
	{
	   public:
		  DeformSetHeightAction(TerrainDeformer * editor) : DeformAction(editor){}
		  StringTableEntry getName(){return("setHeight");}

		  void process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type type);
	};

	//------------------------------------------------------------------------------
	class DeformSetEmptyAction : public DeformAction
	{
	   public:
		  DeformSetEmptyAction(TerrainDeformer * editor) : DeformAction(editor){}
		  StringTableEntry getName(){return("setEmpty");}

		  void process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type type);
	};

	//------------------------------------------------------------------------------
	class DeformClearEmptyAction : public DeformAction
	{
	   public:
		  DeformClearEmptyAction(TerrainDeformer * editor) : DeformAction(editor){}
		  StringTableEntry getName(){return("clearEmpty");}

		  void process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type type);
	};

	//------------------------------------------------------------------------------
	class DeformBrushAdjustHeightAction : public DeformAction
	{
	   public:
		  DeformBrushAdjustHeightAction(TerrainDeformer * editor) : DeformAction(editor){}
		  StringTableEntry getName(){return("brushAdjustHeight");}

		  void process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type type);

	   private:
		  PlaneF mIntersectionPlane;
		  Point3F mTerrainUpVector;
		  F32 mPreviousZ;
	};

	//------------------------------------------------------------------------------
	class DeformAdjustHeightAction : public DeformBrushAdjustHeightAction
	{
	   public:
		  DeformAdjustHeightAction(TerrainDeformer * editor);
		  StringTableEntry getName(){return("adjustHeight");}

		  void process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type type);
		  bool useMouseBrush() { return(false); }

	   private:
		  //
		  Point3F                    mHitPos;
		  Point3F                    mLastPos;
		  SimObjectPtr<GuiCursor>    mCursor;
	};

	//------------------------------------------------------------------------------
	class DeformFlattenHeightAction : public DeformAction
	{
	   public:
		  DeformFlattenHeightAction(TerrainDeformer * editor) : DeformAction(editor){}
		  StringTableEntry getName(){return("flattenHeight");}

		  void process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type type);
	};

	//------------------------------------------------------------------------------
	class DeformSmoothHeightAction : public DeformAction
	{
	   public:
		  DeformSmoothHeightAction(TerrainDeformer * editor) : DeformAction(editor){}
		  StringTableEntry getName(){return("smoothHeight");}

		  void process(DeformSelection * sel, const DeformEvent & deformEvent, bool selChanged, Type type);
	};

	//------------------------------------------------------------------------------
	class DeformPaintNoiseAction : public DeformAction
	{
	   public:

		  DeformPaintNoiseAction( TerrainDeformer *editor ) 
			 :  DeformAction( editor ),
				mNoiseSize( 256 )
		  {
			 mNoise.setSeed( 5342219 );
			 mNoiseData.setSize( mNoiseSize * mNoiseSize );
			 mNoise.fBm( &mNoiseData, mNoiseSize, 12, 1.0f, 5.0f );

			 mNoise.getMinMax( &mNoiseData, &mMinMaxNoise.x, &mMinMaxNoise.y, mNoiseSize );
	       
			 mScale = 1.5f / ( mMinMaxNoise.x - mMinMaxNoise.y);
		  }
	      
		  StringTableEntry getName() { return "paintNoise"; }

		  void process( DeformSelection *sel, const DeformEvent &deformEvent, bool selChanged, Type type );

	   protected:

		  const U32 mNoiseSize;

		  Noise2D mNoise;

		  Vector<F32> mNoiseData;

		  Point2F mMinMaxNoise;

		  F32 mScale;
	};


	//------------------------------------------------------------------------------
	class DeformSoftSelectAction : public DeformAction
	{
	   public:
		  DeformSoftSelectAction(TerrainDeformer *editor) : DeformAction(editor){};
		  StringTableEntry getName(){return("softSelect");}

		  void process( DeformSelection *sel, const DeformEvent &deformEvent, bool selChanged, Type type );

		  Filter   mFilter;
	};


#endif // _DeformActions_H_
