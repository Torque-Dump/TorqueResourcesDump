#include "platform/platform.h"
#include "T3D/terrainDeformer/terrainDeformer.h"
#include "gui/core/guiCanvas.h"
#include "console/consoleTypes.h"
#include "T3D/terrainDeformer/deformActions.h"
#include "sim/netConnection.h"
#include "core/frameAllocator.h"
#include "gfx/primBuilder.h"
#include "console/simEvents.h"
#include "interior/interiorInstance.h"
#include "core/strings/stringUnit.h"
#include "terrain/terrMaterial.h"

IMPLEMENT_CONOBJECT(TerrainDeformer);

//------------------------------DEFORM SELECTION--------------------------------
DeformSelection::DeformSelection() : Vector<GridInfo>(__FILE__, __LINE__), mName(0), mHashListSize(1024)
{
   VECTOR_SET_ASSOCIATION(mHashLists);

   // Clear The Hash List
   mHashLists.setSize(mHashListSize);
   reset();
}
DeformSelection::~DeformSelection(){}
void DeformSelection::reset()
{
   for(U32 i = 0; i < mHashListSize; i++)
      mHashLists[i] = -1;
   clear();
}

void DeformSelection::insert(GridInfo info)
{
   // Get The Index Into The Hash Table
   U32 index = getHashIndex(info.mGridPoint.gridPos);

   // if there is an existing linked list, make it our next
   info.mNext = mHashLists[index];
   info.mPrev = -1;

   // if there is an existing linked list, make us it's prev
   U32 indexOfNewEntry = size();
   if(info.mNext != -1)
      (*this)[info.mNext].mPrev = indexOfNewEntry;

   // the hash table holds the heads of the linked lists. make us the head of this list
   mHashLists[index] = indexOfNewEntry;

   // copy us into the vector
   push_back(info);
}

U32  DeformSelection::getHashIndex(const Point2I & pos)
{
   Point2F pnt = Point2F((F32)pos.x, (F32)pos.y) + Point2F(1.3f,3.5f);
   return( (U32)(mFloor(mHashLists.size() * mFmod(pnt.len() * 0.618f, 1.0f))) );
}

S32  DeformSelection::lookup(const Point2I & pos)
{
   U32 index = getHashIndex(pos);

   S32 entry = mHashLists[index];

   while(entry != -1)
   {
      if((*this)[entry].mGridPoint.gridPos == pos)
         return(entry);

      entry = (*this)[entry].mNext;
   }

   return(-1);
}

bool DeformSelection::remove(const GridInfo &info)
{
   if(size() < 1)
      return false;

   U32 hashIndex = getHashIndex(info.mGridPoint.gridPos);
   S32 listHead = mHashLists[hashIndex];

   if(listHead == -1)
      return(false);

   const S32 victimEntry = lookup(info.mGridPoint.gridPos);
   if( victimEntry == -1 )
      return(false);

   const GridInfo victim = (*this)[victimEntry];
   const S32 vicPrev = victim.mPrev;
   const S32 vicNext = victim.mNext;
      
   // remove us from the linked list, if there is one.
   if(vicPrev != -1)
      (*this)[vicPrev].mNext = vicNext;
   if(vicNext != -1)
      (*this)[vicNext].mPrev = vicPrev;
   
   // if we were the head of the list, make our next the new head in the hash table.
   if(vicPrev == -1)
      mHashLists[hashIndex] = vicNext;

   // if we're not the last element in the vector, copy the last element to our position.
   if(victimEntry != size() - 1)
   {
      // copy last into victim, and re-cache next & prev
      const GridInfo lastEntry = last();
      const S32 lastPrev = lastEntry.mPrev;
      const S32 lastNext = lastEntry.mNext;
      (*this)[victimEntry] = lastEntry;
      
      // update the new element's next and prev, to reestablish it in it's linked list.
      if(lastPrev != -1)
         (*this)[lastPrev].mNext = victimEntry;
      if(lastNext != -1)
         (*this)[lastNext].mPrev = victimEntry;

      // if it was the head of it's list, update the hash table with its new position.
      if(lastPrev == -1)
      {
         const U32 lastHash = getHashIndex(lastEntry.mGridPoint.gridPos);
         AssertFatal(mHashLists[lastHash] == size() - 1, "DeformSelection hashLists corrupted during DeformSelection.remove() (oldmsg)");
         mHashLists[lastHash] = victimEntry;
      }
   }
   
   // decrement the vector, we're done here
   pop_back();

   return true;
}

bool DeformSelection::add(const GridInfo &info)
{
   S32 index = lookup(info.mGridPoint.gridPos);
   if(index != -1)
      return(false);

   insert(info);
   return(true);
}


bool DeformSelection::setInfo(GridInfo & info)
{
   S32 index = lookup(info.mGridPoint.gridPos);
   if(index == -1)
      return(false);

   S32 next = (*this)[index].mNext;
   S32 prev = (*this)[index].mPrev;

   (*this)[index] = info;
   (*this)[index].mNext = next;
   (*this)[index].mPrev = prev;

   return(true);
}

bool DeformSelection::validate()
{
   // scan all the hashes and verify that the heads they point to point back to them
   U32 hashesProcessed = 0;
   for(U32 i = 0; i < mHashLists.size(); i++)
   {
      U32 entry = mHashLists[i];
      if(entry == -1)
         continue;
      
      GridInfo info = (*this)[entry];
      U32 hashIndex = getHashIndex(info.mGridPoint.gridPos);
      
      if( entry != mHashLists[hashIndex] )
      {
         AssertFatal(false, "DeformSelection hash lists corrupted");
         return false;
      }
      hashesProcessed++;
   }

   // scan all the entries and verify that anything w/ a prev == -1 is correctly in the hash table
   U32 headsProcessed = 0;
   for(U32 i = 0; i < size(); i++)
   {
      GridInfo info = (*this)[i];
      if(info.mPrev != -1)
         continue;

      U32 hashIndex = getHashIndex(info.mGridPoint.gridPos);

      if(mHashLists[hashIndex] != i)
      {
         AssertFatal(false, "DeformSelection list heads corrupted");       
         return false;
      }
      headsProcessed++;
   }
   AssertFatal(headsProcessed == hashesProcessed, "DeformSelection's number of hashes and number of list heads differ.");
   return true;
}

bool DeformSelection::getInfo(Point2I pos, GridInfo & info)
{

   S32 index = lookup(pos);
   if(index == -1)
      return(false);

   info = (*this)[index];
   return(true);
}

F32  DeformSelection::getAvgHeight()
{
   if(!size())
      return(0);

   F32 avg = 0.f;
   for(U32 i = 0; i < size(); i++)
      avg += (*this)[i].mHeight;

   return(avg / size());
}

F32  DeformSelection::getMinHeight()
{
   if(!size())
      return(0);

   F32 minHeight = (*this)[0].mHeight;
   for(U32 i = 1; i < size(); i++)
      minHeight = getMin(minHeight, (*this)[i].mHeight);

   return minHeight;
}

F32  DeformSelection::getMaxHeight()
{
   if(!size())
      return(0);

   F32 maxHeight = (*this)[0].mHeight;
   for(U32 i = 1; i < size(); i++)
      maxHeight = getMax(maxHeight, (*this)[i].mHeight);

   return maxHeight;
}

//------------------------------DEFORM BRUSHES----------------------------------
DeformBrush::DeformBrush(TerrainDeformer * editor) : mTerrainDeformer(editor)
{
   mSize = mTerrainDeformer->getBrushSize();
}

const Point2I & DeformBrush::getPosition(){return(mGridPoint.gridPos);}
const GridPoint & DeformBrush::getGridPoint(){return mGridPoint;}
void DeformBrush::setPosition(const Point3F & wPos)
{
   mTerrainDeformer->worldToGrid(wPos, mGridPoint);
   update();
}

void DeformBrush::setPosition(const Point2I & gPos)
{
   mGridPoint.gridPos = gPos;
   update();
}

void DeformBrush::update()
{
   rebuild();
}

void DeformBoxBrush::rebuild()
{
   reset();
   mRenderList.setSize(mSize.x*mSize.y);
   Filter filter;
   filter.set(1, &mTerrainDeformer->mSoftSelectFilter);
   S32 centerX = (mSize.x - 1) / 2;
   S32 centerY = (mSize.y - 1) / 2;
   F32 xFactorScale = F32(centerX) / (F32(centerX) + 0.5);
   F32 yFactorScale = F32(centerY) / (F32(centerY) + 0.5);
   
   const F32 softness = mTerrainDeformer->getBrushSoftness();
   const F32 pressure = mTerrainDeformer->getBrushPressure();

   for(S32 x = 0; x < mSize.x; x++)
   {
      for(S32 y = 0; y < mSize.y; y++)
      {
         Vector<GridInfo> infos;
         GridPoint gridPoint = mGridPoint;
         gridPoint.gridPos.set(mGridPoint.gridPos.x + x - centerX, mGridPoint.gridPos.y + y - centerY);

         // Check that the grid point is valid within the terrain.  This assumes
         // that there is no wrap around past the edge of the terrain.
         if(!mTerrainDeformer->isPointInTerrain(gridPoint))
         {
            mRenderList[x*mSize.x+y] = -1;
            continue;
         }

         mTerrainDeformer->getGridInfos(gridPoint, infos);

         F32 xFactor = 0.0f;
         if(centerX > 0)
            xFactor = (mAbs(centerX - x) / F32(centerX)) * xFactorScale;

         F32 yFactor = 0.0f;
         if(centerY > 0)
            yFactor = (mAbs(centerY - y) / F32(centerY)) * yFactorScale;

         for (U32 z = 0; z < infos.size(); z++)
         {
            infos[z].mWeight = pressure *
               mLerp( infos[z].mWeight, filter.getValue(xFactor > yFactor ? xFactor : yFactor), softness );

            push_back(infos[z]);
         }

         mRenderList[x*mSize.x+y] = size()-1;
      }
   }
}

void DeformEllipseBrush::rebuild()
{
   reset();
   mRenderList.setSize(mSize.x*mSize.y);
   Point3F center(F32(mSize.x - 1) / 2, F32(mSize.y - 1) / 2, 0);
   Filter filter;
   filter.set(1, &mTerrainDeformer->mSoftSelectFilter);
   F32 a = 1 / (F32(mSize.x) * 0.5);
   F32 b = 1 / (F32(mSize.y) * 0.5);
   const F32 softness = mTerrainDeformer->getBrushSoftness();
   const F32 pressure = mTerrainDeformer->getBrushPressure();

   for(S32 x = 0; x < mSize.x; x++)
   {
      for(S32 y = 0; y < mSize.y; y++)
      {
         F32 xp = center.x - x;
         F32 yp = center.y - y;

         F32 factor = (a * a * xp * xp) + (b * b * yp * yp);
         if(factor > 1)
         {
            mRenderList[x*mSize.x+y] = -1;
            continue;
         }

         Vector<GridInfo> infos;
         GridPoint gridPoint = mGridPoint;
         gridPoint.gridPos.set((S32)(mGridPoint.gridPos.x + x - (S32)center.x), (S32)(mGridPoint.gridPos.y + y - (S32)center.y));

         // Check that the grid point is valid within the terrain.  This assumes
         // that there is no wrap around past the edge of the terrain.
         if(!mTerrainDeformer->isPointInTerrain(gridPoint))
         {
            mRenderList[x*mSize.x+y] = -1;
            continue;
         }

         mTerrainDeformer->getGridInfos(gridPoint, infos);

         for (U32 z = 0; z < infos.size(); z++)
         {
            infos[z].mWeight = pressure * mLerp( infos[z].mWeight, filter.getValue( factor ), softness ); 
            push_back(infos[z]);
         }

         mRenderList[x*mSize.x+y] = size()-1;
      }
   }
}

DeformSelectionBrush::DeformSelectionBrush(TerrainDeformer * Deformer) : DeformBrush(Deformer){}
void DeformSelectionBrush::rebuild(){reset();}
//------------------------CONSTRUCTOR & DESTRUCTOR------------------------------
TerrainDeformer::TerrainDeformer() :
   mActiveTerrain(0),
   mDeformPos(0,0,0),
   mDeformBrush(0),
   mInAction(false),
   mGridUpdateMin( S32_MAX, S32_MAX ),
   mGridUpdateMax( 0, 0 ),
   mMaxBrushSize(48,48),
   mNeedsGridUpdate( false ),
   mNeedsMaterialUpdate( false )
{

   VECTOR_SET_ASSOCIATION(mActions);

   resetCurrentSel();
   getTerrainBlocks();

   mBrushPressure = 1.0f;
   mBrushSize.set(1,1);
   mBrushSoftness = 1.0f;
   mBrushChanged = true;
   mDeformBrush = new DeformEllipseBrush(this);
   mSeq = 0;
   mIsDirty = false;
   mIsMissionDirty = false;
   mDefaultPaintIndex = -1;
   mSteepPaintIndex = -1;

   // Add In All The Actions Here
   mActions.push_back(new DeformPaintMaterialAction(this));
   mActions.push_back(new DeformRaiseHeightAction(this));
   mActions.push_back(new DeformLowerHeightAction(this));
   mActions.push_back(new DeformSetHeightAction(this));
   mActions.push_back(new DeformSetEmptyAction(this));
   mActions.push_back(new DeformClearEmptyAction(this));
   mActions.push_back(new DeformBrushAdjustHeightAction(this));
   mActions.push_back(new DeformAdjustHeightAction(this));
   mActions.push_back(new DeformFlattenHeightAction(this));
   mActions.push_back(new DeformSmoothHeightAction(this));
   mActions.push_back(new DeformPaintNoiseAction(this));
   mActions.push_back(new DeformSoftSelectAction(this));

   // Set The Default Actions
   mFirstAction = mActions[0];
   mSecondAction = NULL;
   mThirdAction = NULL;

   // Persist Data Defaults
   mRenderBorder = true;
   mBorderHeight = 10;
   mBorderFillColor.set(0,255,0,20);
   mBorderFrameColor.set(0,255,0,128);
   mBorderLineMode = false;
   mSelectionHidden = false;
   mRenderVertexSelection = false;
   mRenderSolidBrush = false;
   mProcessUsesBrush = false;
   mAdjustHeightVal = 50;
   mSetHeightVal = 50;
   mScaleVal = 1;
   mSmoothFactor = 0.1f;
   mNoiseFactor = 1.0f;
   mMaterialGroup = 0;
   mSoftSelectRadius = 50.f;
   mAdjustHeightMouseScale = 0.1f;
   mManualUpdate = false;

   mSoftSelectDefaultFilter = StringTable->insert("1.000000 0.900000 0.800000 0.700000 0.600000 0.500000 0.400000");
   mSoftSelectFilter = mSoftSelectDefaultFilter;

   mSlopeMinAngle = 0.0f;
   mSlopeMaxAngle = 90.0f;

   mDeformObject = NULL;
   mLivingTicks = 0;
   mCurTick = 0;

}

TerrainDeformer::~TerrainDeformer()
{
   // Clean Up
   delete mDeformBrush;

   U32 i;
   for(i = 0; i < mActions.size(); i++)
      delete mActions[i];
}

//-------------------------INITIALIZATION METHODS-------------------------------
void TerrainDeformer::initPersistFields(){

   Parent::initPersistFields();
}

bool TerrainDeformer::onAdd()
{
   return Parent::onAdd();
}
//--------------------------CONVERSION METHODS----------------------------------
bool checkTerrainBlock(TerrainDeformer * object, const char * funcName)
{
   if(!object->terrainBlockValid())
   {
      Con::errorf(ConsoleLogEntry::Script, "TerrainDeformer::%s: not attached to a terrain block!", funcName);
      return(false);
   }
   return(true);
}
bool TerrainDeformer::gridToWorld(const GridPoint & gPoint, Point3F & wPos)
{
   const MatrixF & mat = gPoint.terrainBlock->getTransform();
   Point3F origin;
   mat.getColumn(3, &origin);

   wPos.x = gPoint.gridPos.x * gPoint.terrainBlock->getSquareSize() + origin.x;
   wPos.y = gPoint.gridPos.y * gPoint.terrainBlock->getSquareSize() + origin.y;
   wPos.z = getGridHeight(gPoint) + origin.z;

   return true;
}

bool TerrainDeformer::gridToWorld(const Point2I & gPos, Point3F & wPos, TerrainBlock* terrain)
{
   GridPoint gridPoint;
   gridPoint.gridPos = gPos;
   gridPoint.terrainBlock = terrain;

   return gridToWorld(gridPoint, wPos);
}

bool TerrainDeformer::worldToGrid(const Point3F & wPos, GridPoint & gPoint)
{
   // If the grid point TerrainBlock is NULL then find the closest Terrain underneath that
   // point - pad a little upward in case our incoming point already lies exactly on the terrain
   if (!gPoint.terrainBlock)
      gPoint.terrainBlock = getTerrainUnderWorldPoint(wPos + Point3F(0.0f, 0.0f, 0.05f));

   if (gPoint.terrainBlock == NULL)
      return false;

   const MatrixF & worldMat = gPoint.terrainBlock->getWorldTransform();
   Point3F tPos = wPos;
   worldMat.mulP(tPos);

   F32 squareSize = (F32) gPoint.terrainBlock->getSquareSize();
   F32 halfSquareSize = squareSize / 2;

   F32 x = (tPos.x + halfSquareSize) / squareSize;
   F32 y = (tPos.y + halfSquareSize) / squareSize;

   gPoint.gridPos.x = (S32)mFloor(x);
   gPoint.gridPos.y = (S32)mFloor(y);

   return true;
}
bool TerrainDeformer::worldToGrid(const Point3F & wPos, Point2I & gPos, TerrainBlock* terrain)
{
   GridPoint gridPoint;
   gridPoint.terrainBlock = terrain;

   bool ret = worldToGrid(wPos, gridPoint);

   gPos = gridPoint.gridPos;

   return ret;
}

//-----------------------------GRID METHODS-------------------------------------
bool TerrainDeformer::getGridInfo(const GridPoint & gPoint, GridInfo & info)
{
   //
   info.mGridPoint = gPoint;
   info.mMaterial = getGridMaterial(gPoint);
   info.mHeight = getGridHeight(gPoint);
   info.mWeight = 1.f;
   info.mPrimarySelect = true;
   info.mMaterialChanged = false;

   return true;
}

bool TerrainDeformer::getGridInfo(const Point2I & gPos, GridInfo & info, TerrainBlock* terrain)
{
   GridPoint gridPoint;
   gridPoint.gridPos = gPos;
   gridPoint.terrainBlock = terrain;

   return getGridInfo(gridPoint, info);
}

U8   TerrainDeformer::getGridMaterial( const GridPoint &gPoint ) const
{
   const TerrainFile *file = gPoint.terrainBlock->getFile();
   return file->getLayerIndex( gPoint.gridPos.x, gPoint.gridPos.y );
}

F32  TerrainDeformer::getGridHeight(const GridPoint & gPoint)
{
   const TerrainFile *file = gPoint.terrainBlock->getFile();
   return fixedToFloat( file->getHeight( gPoint.gridPos.x, gPoint.gridPos.y ) );
}
F32  TerrainDeformer::getGridHeight(const Point2I gPos)
{
   const TerrainFile *file = mActiveTerrain->getFile();
   return fixedToFloat( file->getHeight( gPos.x, gPos.y ) );
}
void TerrainDeformer::getGridInfos(const GridPoint & gPoint, Vector<GridInfo>& infos)
{
   // First we test against the DeformBrush terrain so that we can
   // favor it (this should be the same as the active terrain)
   bool foundBrush = false;

   GridInfo baseInfo;
   if (getGridInfo(gPoint, baseInfo))
   {
      infos.push_back(baseInfo);

      foundBrush = true;
   }

   // We are going to need the world position to test against
   Point3F wPos;
   gridToWorld(gPoint, wPos);

   // Now loop through our terrain blocks and decide which ones hit the point
   // If we already found a hit against our DeformBrush terrain we only add points
   // that are relatively close to the found point
   for (U32 i = 0; i < mTerrainBlocks.size(); i++)
   {
      // Skip if we've already found the point on the DeformBrush terrain
      if (foundBrush && mTerrainBlocks[i] == baseInfo.mGridPoint.terrainBlock)
         continue;

      // Get our grid position
      Point2I gPos;
      worldToGrid(wPos, gPos, mTerrainBlocks[i]);

      GridInfo info;
      if (getGridInfo(gPos, info, mTerrainBlocks[i]))
      {
         // Skip adding this if we already found a GridInfo from the DeformBrush terrain
         // and the resultant world point isn't equivalent
         if (foundBrush)
         {
            // Convert back to world (since the height can be different)
            // Possibly use getHeight() here?
            Point3F testWorldPt;
            gridToWorld(gPos, testWorldPt, mTerrainBlocks[i]);

            if (mFabs( wPos.z - testWorldPt.z ) > 4.0f )
               continue;
         }

         infos.push_back(info);
      }
   }
}

void TerrainDeformer::setGridInfo(const GridInfo & info, bool checkActive)
{
   setGridHeight(info.mGridPoint, info.mHeight);
   setGridMaterial(info.mGridPoint, info.mMaterial);
}

void TerrainDeformer::setGridHeight(const GridPoint & gPoint, const F32 height)
{
   mGridUpdateMin.setMin( gPoint.gridPos );
   mGridUpdateMax.setMax( gPoint.gridPos );

   gPoint.terrainBlock->setHeight(gPoint.gridPos, height);
}

void TerrainDeformer::setGridMaterial( const GridPoint &gPoint, U8 index )
{
   TerrainFile *file = gPoint.terrainBlock->getFile();

   // If we changed the empty state then we need
   // to do a grid update as well.
   U8 currIndex = file->getLayerIndex( gPoint.gridPos.x, gPoint.gridPos.y );
   if (  ( currIndex == (U8)-1 && index != (U8)-1 ) || 
         ( currIndex != (U8)-1 && index == (U8)-1 ) )
   {
      mGridUpdateMin.setMin( gPoint.gridPos );
      mGridUpdateMax.setMax( gPoint.gridPos );
      mNeedsGridUpdate = true;
   }

   file->setLayerIndex( gPoint.gridPos.x, gPoint.gridPos.y, index );
}

void TerrainDeformer::gridUpdateComplete( bool materialChanged )
{
	mActiveTerrain->updateGrid(mGridUpdateMin, mGridUpdateMax, true);

	if ( materialChanged )
	{
		mActiveTerrain->updateGridMaterials(mGridUpdateMin, mGridUpdateMax);
		mNeedsMaterialUpdate = false;
	}
			 
	mGridUpdateMin.set( S32_MAX, S32_MAX );

	mGridUpdateMax.set( 0, 0 );

	mNeedsGridUpdate = false;
}

//------------------------ COLLISION METHODS------------------------------------
bool TerrainDeformer::collidingWithTerrain(DeformEvent & deformEvent)
{

   // Get the grid positions Height 
   GridPoint mGridPoint;
   RayInfo rInfo;
   F32 height;

   mGridPoint.gridPos.x = deformEvent.gPos.x;
   mGridPoint.gridPos.y = deformEvent.gPos.y;
   mGridPoint.terrainBlock = mActiveTerrain;

   height = getGridHeight(mGridPoint); 

   if( gClientContainer.castRay( deformEvent.wPos + Point3F(0, 0, height), deformEvent.wPos, TerrainObjectType, &rInfo) )
		return true;

   return false;
}
//--------------------------RENDER METHODS--------------------------------------
void TerrainDeformer::completeUpdates(const DeformEvent & deformEvent)
{
   if(mTerrainBlocks.size() == 0)
      return;

	mSeq++;

	if (mFirstAction != NULL)
		mFirstAction->process(mDeformBrush, deformEvent, true, DeformAction::End);
	
	if (mSecondAction != NULL)
		mSecondAction->process(mDeformBrush, deformEvent, false, DeformAction::End);

	if (mThirdAction != NULL)
		mThirdAction->process(mDeformBrush, deformEvent, false, DeformAction::End);


	// Render any updates we need to display, unless it's manual
	if (!mManualUpdate)
		renderUpdates();
}

void TerrainDeformer::renderUpdates()
{
   if ( mNeedsGridUpdate )         
      gridUpdateComplete( mNeedsMaterialUpdate );
}
//--------------------------PROCESS EVENTS--------------------------------------
class TerrainProcessActionEvent : public SimEvent
{
   U32 mSequence;
public:
   TerrainProcessActionEvent(U32 seq)
   {
      mSequence = seq;
   }
   void process(SimObject *object)
   {
      ((TerrainDeformer *) object)->processActionTick(mSequence);
   }
};
void TerrainDeformer::processTick(const Move* move)
{

	if (isClientObject())
		return;

	// Are we attathed to something?
	if (mDeformObject != NULL){

		// Is it still part of the scene?
		if (mDeformObject->isRemoved()){

			mDeformObject = NULL;
			return;	
		}
	}
	else
		return;


	if (mCurTick <= mLivingTicks)
	{

		// First let's setup an event
		DeformEvent newEvent;
		newEvent.wPos = mDeformObject->getPosition();

		// Get the terrain to test against
		mActiveTerrain = getTerrainUnderWorldPoint(newEvent.wPos);

		if (mActiveTerrain == NULL)
			return;

		worldToGrid(newEvent.wPos, newEvent.gPos, mActiveTerrain);
		
		// If our shape is colliding,  process the event.
		if (collidingWithTerrain(newEvent))
		{
				doDeform(newEvent);

				completeUpdates(newEvent);

				if (mLivingTicks > 0) mCurTick ++;
		}
	}
}


void TerrainDeformer::processAction(const char* sAction)
{
   if(!checkTerrainBlock(this, "processAction"))
      return;

   DeformAction * previousAction = mFirstAction;
   DeformAction * newAction = mFirstAction;

   if (dStrcmp(sAction, "") != 0)
   {
      newAction = lookupAction(sAction);

      if(!newAction)
      {
         Con::errorf(ConsoleLogEntry::General, "TerrainDeformer::cProcessAction: invalid action name '%s'.", sAction);
         return;
      }
	  else
	  {
		 mFirstAction = newAction;
	  }
   }

   DeformEvent deformEvent;
   deformEvent.wPos = mDeformObject->getPosition();
   worldToGrid(deformEvent.wPos, deformEvent.gPos, mActiveTerrain);

   mDeformPos = deformEvent.wPos;

   mDeformBrush->setPosition(mDeformPos);

   newAction->process(mDeformBrush, deformEvent, true, DeformAction::Process);

   mFirstAction = previousAction;
}

void TerrainDeformer::processActionTick(U32 sequence)
{
   if(mSeq == sequence)
   {
	  DeformEvent newEvent;

      Sim::postEvent(this, new TerrainProcessActionEvent(mSeq), Sim::getCurrentTime() + 30);

	  mFirstAction->process(mDeformBrush, newEvent, false, DeformAction::Update);
   }
}

void TerrainDeformer::doDeform(const DeformEvent & deformEvent)
{
	if(mActiveTerrain == NULL)
		return;

	Con::executef(this, "onActiveTerrainChange", Con::getIntArg(mActiveTerrain->getId()), 
											     Con::getFloatArg(deformEvent.wPos.x), 
											     Con::getFloatArg(deformEvent.wPos.y), 
											     Con::getFloatArg(deformEvent.wPos.z));

	mDeformBrush->setTerrain(mActiveTerrain);

	mDeformPos = deformEvent.wPos;

	mDeformBrush->setPosition(mDeformPos);

	mSeq++;

	mFirstAction->process(mDeformBrush, deformEvent, true, DeformAction::Begin);

	// process on ticks - every 30th of a second.
	Sim::postEvent(this, new TerrainProcessActionEvent(mSeq), Sim::getCurrentTime() + 30);

	if (mSecondAction != NULL)
	{
		mSeq++;

		mSecondAction->process(mDeformBrush, deformEvent, true, DeformAction::Begin);

		Sim::postEvent(this, new TerrainProcessActionEvent(mSeq), Sim::getCurrentTime() + 30);
	}

	if (mThirdAction != NULL)
	{
		mSeq++;

		mThirdAction->process(mDeformBrush, deformEvent, true, DeformAction::Begin);

		Sim::postEvent(this, new TerrainProcessActionEvent(mSeq), Sim::getCurrentTime() + 30);
	}
}

//-------------------------------MISC-------------------------------------------
DeformAction * TerrainDeformer::lookupAction(const char * name)
{
   for(U32 i = 0; i < mActions.size(); i++)
      if(!dStricmp(mActions[i]->getName(), name))
         return(mActions[i]);
   return(0);
}

bool TerrainDeformer::isPointInTerrain( const GridPoint & gPoint)
{
   const TerrainFile *file = gPoint.terrainBlock->getFile();
   return file->isPointInTerrain( gPoint.gridPos.x, gPoint.gridPos.y );
}

void TerrainDeformer::onDeleteNotify(SimObject * object)
{
   Parent::onDeleteNotify(object);

   for (U32 i = 0; i < mTerrainBlocks.size(); i++)
   {
      if(mTerrainBlocks[i] != dynamic_cast<TerrainBlock*>(object))
         continue;

      if (mTerrainBlocks[i] == mActiveTerrain)
         mActiveTerrain = NULL;
   }
}
void TerrainDeformer::attachTerrain(TerrainBlock *terrBlock)
{
   mActiveTerrain = terrBlock;

   for (U32 i = 0; i < mTerrainBlocks.size(); i++)
   {
      if (mTerrainBlocks[i] == terrBlock)
         return;
   }

   mTerrainBlocks.push_back(terrBlock);
}

void TerrainDeformer::detachTerrain(TerrainBlock *terrBlock)
{
   if (mActiveTerrain == terrBlock)
      mActiveTerrain = NULL; //do we want to set this to an existing terrain?

   if (mDeformBrush->getGridPoint().terrainBlock == terrBlock)
      mDeformBrush->setTerrain(NULL);

   // reset the DeformBrush as its gridinfos may still have references to the old terrain
   mDeformBrush->reset();

   for (U32 i = 0; i < mTerrainBlocks.size(); i++)
   {
      if (mTerrainBlocks[i] == terrBlock)
      {
         mTerrainBlocks.erase_fast(i);
         break;
      }
   }
}

void TerrainDeformer::resetSelWeights(bool clear)
{
   //
   if(!clear)
   {
      for(U32 i = 0; i < mDefaultSel.size(); i++)
      {
         mDefaultSel[i].mPrimarySelect = false;
         mDefaultSel[i].mWeight = 1.f;
      }
      return;
   }

   DeformSelection sel;

   U32 i;
   for(i = 0; i < mDefaultSel.size(); i++)
   {
      if(mDefaultSel[i].mPrimarySelect)
      {
         mDefaultSel[i].mWeight = 1.f;
         sel.add(mDefaultSel[i]);
      }
   }

   mDefaultSel.reset();

   for(i = 0; i < sel.size(); i++)
      mDefaultSel.add(sel[i]);
}

void TerrainDeformer::clearSelection()
{
	mDefaultSel.reset();
}


//--------------------------------SET-------------------------------------------
void TerrainDeformer::setBrushSize( S32 w, S32 h )
{
   w = mClamp( w, 1, mMaxBrushSize.x );
   h = mClamp( h, 1, mMaxBrushSize.y );

   if ( w == mBrushSize.x && h == mBrushSize.y )
      return;

	mBrushSize.set( w, h );
   mBrushChanged = true;

   if ( mDeformBrush )
   {
   	mDeformBrush->setSize( mBrushSize );

      if ( mDeformBrush->getGridPoint().terrainBlock )
         mDeformBrush->rebuild();
   }
}

void TerrainDeformer::setBrushPressure( F32 pressure )
{
   pressure = mClampF( pressure, 0.01f, 1.0f );
   
   if ( mBrushPressure == pressure )
      return;

   mBrushPressure = pressure;
   mBrushChanged = true;

   if ( mDeformBrush && mDeformBrush->getGridPoint().terrainBlock )
      mDeformBrush->rebuild();
}

void TerrainDeformer::setBrushSoftness( F32 softness )
{
   softness = mClampF( softness, 0.01f, 1.0f );

   if ( mBrushSoftness == softness )
      return;

   mBrushSoftness = softness;
   mBrushChanged = true;

   if ( mDeformBrush && mDeformBrush->getGridPoint().terrainBlock )
      mDeformBrush->rebuild();
}

void TerrainDeformer::setBrushPos(Point2I pos)
{
   AssertFatal(mDeformBrush!=NULL, "TerrainDeformer::setBrushPos: no mouse DeformBrush!");
   mDeformBrush->setPosition(pos);
}

void TerrainDeformer::setFirstAction(const char* action)
{
   for(U32 i = 0; i < mActions.size(); i++)
   {
      if(!dStricmp(mActions[i]->getName(), action))
      {
         mFirstAction = mActions[i];
         return;
      }
   }
}
void TerrainDeformer::setSecondAction(const char* action)
{
   for(U32 i = 0; i < mActions.size(); i++)
   {
      if(!dStricmp(mActions[i]->getName(), action))
      {
         mSecondAction = mActions[i];
         return;
      }
   }
}
void TerrainDeformer::setThirdAction(const char* action)
{
   for(U32 i = 0; i < mActions.size(); i++)
   {
      if(!dStricmp(mActions[i]->getName(), action))
      {
         mThirdAction = mActions[i];
         return;
      }
   }
}
void TerrainDeformer::setSceneDeformObject(SceneObject* Object)
{
	mDeformObject = Object;
}
void TerrainDeformer::setBrushType( const char *type )
{
   if ( mDeformBrush && dStrcmp( mDeformBrush->getType(), type ) == 0 )
      return;

   if(!dStricmp(type, "box"))
   {
      delete mDeformBrush;
      mDeformBrush = new DeformBoxBrush(this);
      mBrushChanged = true;
   }
   else if(!dStricmp(type, "ellipse"))
   {
      delete mDeformBrush;
      mDeformBrush = new DeformEllipseBrush(this);
      mBrushChanged = true;
   }
   else if(!dStricmp(type, "DeformSelection"))
   {
      delete mDeformBrush;
      mDeformBrush = new DeformSelectionBrush(this);
      mBrushChanged = true;
   }
   else {}   
}

void TerrainDeformer::setDefaultPaintTexture(const char* textureName)
{
   const U32 count = mActiveTerrain->getMaterialCount();

   for( U32 i = 0; i < count; ++ i )
      if( dStricmp( textureName, mActiveTerrain->getMaterialName( i ) ) == 0 )
         mDefaultPaintIndex = i;
}
void TerrainDeformer::setSteepPaintTexture(const char* textureName)
{
   const U32 count = mActiveTerrain->getMaterialCount();

   for( U32 i = 0; i < count; ++ i )
      if( dStricmp( textureName, mActiveTerrain->getMaterialName( i ) ) == 0 )
         mSteepPaintIndex = i;
}
void TerrainDeformer::getTerrainBlocks()
{

   mTerrainBlocks.clear();

   SimSet * missionGroup = dynamic_cast<SimSet*>(Sim::findObject("MissionGroup"));
   if (!missionGroup)
   {
      Con::errorf(ConsoleLogEntry::Script, "TerrainDeformer::attach: no mission group found");
      return;
   }

   VectorPtr<TerrainBlock*> terrains;

	for(SimSetIterator itr(missionGroup); *itr; ++itr)
	{
		TerrainBlock* terrBlock = dynamic_cast<TerrainBlock*>(*itr);

		if (terrBlock)
			mTerrainBlocks.insert(mTerrainBlocks.begin(), terrBlock);
	}

	return;

}
//--------------------------------GET-------------------------------------------
F32  TerrainDeformer::getHeight(const Point3F & wPos)
{
   const MatrixF & worldMat = mActiveTerrain->getWorldTransform();
   Point3F tPos = wPos;
   worldMat.mulP(tPos);

   return tPos.z;
}
S32  TerrainDeformer::getNumActions()
{
	return(mActions.size());
}
S32  TerrainDeformer::getNumTextures()
{
   if(!checkTerrainBlock(this, "getNumTextures"))
      return(0);

   // walk all the possible material lists and count them..
   U32 count = 0;
   for (U32 t = 0; t < mTerrainBlocks.size(); t++)
      count += mTerrainBlocks[t]->getMaterialCount();

   return count;
}

void TerrainDeformer::getTerrainBlocksMaterialList(Vector<StringTableEntry>& list)
{
   for(S32 i=0; i<mTerrainBlocks.size(); ++i)
   {
      TerrainBlock* tb = mTerrainBlocks[i];
      if(!tb)
         continue;

      for(S32 m=0; m<tb->getMaterialCount(); ++m)
      {
         TerrainMaterial* mat = tb->getMaterial(m);
         if(!mat)
            continue;

         StringTableEntry name = mat->getInternalName();

         // Add the name to the list if it doesn't already exist
         bool found = false;
         for(S32 j=0; j<list.size(); ++j)
         {
            if(list[j] == name)
            {
               found = true;
               break;
            }
         }

         if(!found)
         {
            list.push_back(name);
         }
      }
   }
}

const char* TerrainDeformer::getActionName(U32 index)
{
   if(index >= mActions.size())
      return("");
   return(mActions[index]->getName());
}

const char* TerrainDeformer::getCurrentAction() const
{
   return(mFirstAction->getName());
}

const char* TerrainDeformer::getBrushType() const
{
   if ( mDeformBrush )
      return mDeformBrush->getType();

   return "";
}

const char* TerrainDeformer::getBrushPos()
{
   AssertFatal(mDeformBrush!=NULL, "TerrainDeformer::getBrushPos: no mouse DeformBrush!");

   Point2I pos = mDeformBrush->getPosition();
   char * ret = Con::getReturnBuffer(32);
   dSprintf(ret, 32, "%d %d", pos.x, pos.y);
   return(ret);
}

TerrainBlock* TerrainDeformer::getClientTerrain( TerrainBlock *serverTerrain ) const
{


   if ( !serverTerrain && !mActiveTerrain )
      return NULL;

   serverTerrain = mActiveTerrain; // WEIRD STUFF!

   return dynamic_cast<TerrainBlock*>( serverTerrain->getClientObject() );


}

TerrainBlock* TerrainDeformer::getTerrainUnderWorldPoint(const Point3F & wPos)
{
   // Cast a ray straight down from the world position and see which
   // Terrain is the closest to our starting point
   //Point3F startPnt = wPos;
	Point3F startPnt = wPos + Point3F(0.0f, 0.0f, +1000.0f);;
   Point3F endPnt = wPos + Point3F(0.0f, 0.0f, -1000.0f);

   S32 blockIndex = -1;
   F32 nearT = 1.0f;

   for (U32 i = 0; i < mTerrainBlocks.size(); i++)
   {
      Point3F tStartPnt, tEndPnt;

      mTerrainBlocks[i]->getWorldTransform().mulP(startPnt, &tStartPnt);
      mTerrainBlocks[i]->getWorldTransform().mulP(endPnt, &tEndPnt);

      RayInfo ri;
      if (mTerrainBlocks[i]->castRayI(tStartPnt, tEndPnt, &ri, true))
      {
         if (ri.t < nearT)	
         {
            blockIndex = i;
            nearT = ri.t;
         }
      }
   }

   if (blockIndex > -1)
      return mTerrainBlocks[blockIndex];

   return NULL;
}

TerrainBlock* TerrainDeformer::getTerrainBlock(S32 index)
{
   if(index < 0 || index >= mTerrainBlocks.size())
      return NULL;

   return mTerrainBlocks[index];
}
//-------------------------CONSOLE METHODS--------------------------------------
ConsoleMethod( TerrainDeformer, resetSelWeights, void, 3, 3, "( bool clear ) resets the current selection weights.")
{
	object->resetSelWeights(dAtob(argv[2]));
}


ConsoleMethod( TerrainDeformer, updateMaterial, bool, 4, 4, "( int index, string matName ) Changes the material name at the index." )
{
   TerrainBlock *terr = object->getClientTerrain();
   if ( !terr )
      return false;
   
   U32 index = dAtoi( argv[2] );
   if ( index >= terr->getMaterialCount() )
      return false;

   terr->updateMaterial( index, argv[3] );

   object->setDirty();

   return true;
}

ConsoleMethod( TerrainDeformer, addMaterial, S32, 3, 3, "( string matName ) Adds a new material." )
{
   TerrainBlock *terr = object->getClientTerrain();
   if ( !terr )
      return false;
   
   terr->addMaterial( argv[2] );

   object->setDirty();

   return true;
}

ConsoleMethod( TerrainDeformer, removeMaterial, void, 3, 3, "( int index ) Removes the material at the given index." )
{
   TerrainBlock *terr = object->getClientTerrain();
   if ( !terr )
      return;
      
   S32 index = dAtoi( argv[ 2 ] );
   if( index < 0 || index >= terr->getMaterialCount() )
   {
      Con::errorf( "TerrainDeformer::removeMaterial - index out of range!" );
      return;
   }
   
   terr->removeMaterial( index );

   object->setDirty();
}

ConsoleMethod( TerrainDeformer, resetLife, void, 2, 2, "() Reset the Deformers life.")
{
	object->mCurTick = 0;
}
ConsoleMethod( TerrainDeformer, getTerrainBlocks, void, 2, 2, "() Re-adds all the terrains in the mission.")
{
	object->getTerrainBlocks();
}
ConsoleMethod( TerrainDeformer, completeUpdates, void, 2, 2, "() Renders all outstanding updates.")
{
	object->renderUpdates();
}
ConsoleMethod( TerrainDeformer, enableManualUpdate, void, 2, 2, "() Terrain deformer stops updating terrian automatically.")
{
	object->mManualUpdate = true;
}
ConsoleMethod( TerrainDeformer, disableManualUpdate, void, 2, 2, "() Terrain deformer updates the terrain automatically.")
{
	object->mManualUpdate = false;
}
//-- GET
ConsoleMethod( TerrainDeformer, getTerrainBlock, S32, 3, 3, "( int terBlock ) Returns the terrain block at the specified index.")
{
   TerrainBlock* tb = object->getTerrainBlock(dAtoi(argv[2]));
   if(!tb)
      return 0;
   else
      return tb->getId();
}

ConsoleMethod( TerrainDeformer, getTerrainBlocksMaterialList, const char *, 2, 2, "() gets the list of current terrain materials.")
{
   Vector<StringTableEntry> list;
   object->getTerrainBlocksMaterialList(list);

   if(list.size() == 0)
      return "";

   // Calculate the size of the return buffer
   S32 size = 0;
   for(U32 i = 0; i < list.size(); ++i)
   {
      size += dStrlen(list[i]);
      ++size;
   }
   ++size;

   // Copy the material names
   char *ret = Con::getReturnBuffer(size);
   ret[0] = 0;
   for(U32 i = 0; i < list.size(); ++i)
   {
      dStrcat( ret, list[i] );
      dStrcat( ret, "\n" );
   }

   return ret;
}

ConsoleMethod( TerrainDeformer, getBrushType, const char*, 2, 2, "() Returns the deformers current brush type.")
{
   return object->getBrushType();
}

ConsoleMethod( TerrainDeformer, getBrushSize, const char*, 2, 2, "() Returns the deformers current brush size.")
{
   Point2I size = object->getBrushSize();

   char * ret = Con::getReturnBuffer(32);
   dSprintf(ret, 32, "%d %d", size.x, size.y);
   return ret;
}

ConsoleMethod( TerrainDeformer, getBrushPressure, F32, 2, 2, "() Returns the deformers current brush pressure.")
{
   return object->getBrushPressure();
}

ConsoleMethod( TerrainDeformer, getBrushSoftness, F32, 2, 2, "() Returns the deformers current brush softness.")
{
   return object->getBrushSoftness();
}


ConsoleMethod( TerrainDeformer, getActionName, const char*, 3, 3, "( int Index ) Returns the Action name at the specified index.")
{
	return (object->getActionName(dAtoi(argv[2])));
}

ConsoleMethod( TerrainDeformer, getNumActions, S32, 2, 2, "() Returns the deformers current number of actions.")
{
	return(object->getNumActions());
}

ConsoleMethod( TerrainDeformer, getCurrentAction, const char*, 2, 2, "() Returns the deformers current action.")
{
	return object->getCurrentAction();
}

ConsoleMethod( TerrainDeformer, getActiveTerrain, S32, 2, 2, "() Returns the ID of the terrain currently attached to the deformer.")
{
   S32 ret = 0;

   TerrainBlock* terrain = object->getActiveTerrain();

   if (terrain)
      ret = terrain->getId();

	return ret;
}

ConsoleMethod( TerrainDeformer, getNumTextures, S32, 2, 2, "() Returns the number of textures currently used by the deformer.")
{
	return object->getNumTextures();
}

ConsoleMethod( TerrainDeformer, getMaterialCount, S32, 2, 2, "() Returns the current material count." )
{
   TerrainBlock *terr = object->getClientTerrain();
   if ( terr )
      return terr->getMaterialCount();

   return 0;
}

ConsoleMethod( TerrainDeformer, getMaterials, const char *, 2, 2, "() Returns the list of current terrain materials.")
{
   TerrainBlock *terr = object->getClientTerrain();
   if ( !terr )
      return "";

   char *ret = Con::getReturnBuffer(4096);
   ret[0] = 0;
   for(U32 i = 0; i < terr->getMaterialCount(); i++)
   {
      dStrcat( ret, terr->getMaterialName(i) );
      dStrcat( ret, "\n" );
   }

   return ret;
}

ConsoleMethod( TerrainDeformer, getMaterialName, const char*, 3, 3, "( int ) - Returns the name of the material at the given index." )
{
   TerrainBlock *terr = object->getClientTerrain();
   if ( !terr )
      return "";
      
   S32 index = dAtoi( argv[ 2 ] );
   if( index < 0 || index >= terr->getMaterialCount() )
   {
      Con::errorf( "TerrainDeformer::getMaterialName - index out of range!" );
      return "";
   }
   
   const char* name = terr->getMaterialName( index );
   return Con::getReturnBuffer( name );
}

ConsoleMethod( TerrainDeformer, getMaterialIndex, S32, 3, 3, "( string ) Returns the index of the material with the given name or -1." )
{
   TerrainBlock *terr = object->getClientTerrain();
   if ( !terr )
      return -1;
      
   const char* name = argv[ 2 ];
   const U32 count = terr->getMaterialCount();
   
   for( U32 i = 0; i < count; ++ i )
      if( dStricmp( name, terr->getMaterialName( i ) ) == 0 )
         return i;
         
   return -1;
}

ConsoleMethod( TerrainDeformer, getTerrainUnderWorldPoint, S32, 3, 5, "( int x, int y, int z ) Returns the ID of the requested terrain block (0 if not found).")
{   
   TerrainDeformer *tDeformer = (TerrainDeformer *) object;
   if(tDeformer == NULL)
      return 0;
   Point3F pos;
   if(argc == 3)
      dSscanf(argv[2], "%f %f %f", &pos.x, &pos.y, &pos.z);
   else if(argc == 5)
   {
      pos.x = dAtof(argv[2]);
      pos.y = dAtof(argv[3]);
      pos.z = dAtof(argv[4]);
   }

   else
   {
      Con::errorf("TerrainDeformer.getTerrainUnderWorldPoint(): Invalid argument count! Valid arguments are either \"x y z\" or x,y,z\n");
      return 0;
   }

   TerrainBlock* terrain = tDeformer->getTerrainUnderWorldPoint(pos);
   if(terrain != NULL)
   {
      return terrain->getId();
   }

   return 0;
}

ConsoleMethod( TerrainDeformer, getSlopeLimitMinAngle, F32, 2, 2, 0)
{
   return object->mSlopeMinAngle;
}

ConsoleMethod( TerrainDeformer, getSlopeLimitMaxAngle, F32, 2, 2, 0)
{
   return object->mSlopeMaxAngle;
}

//-- SET 
ConsoleMethod( TerrainDeformer, setBrushType, void, 3, 3, "( string type ) Box or Ellipse.")
{
	object->setBrushType(argv[2]);
}

ConsoleMethod( TerrainDeformer, setBrushSize, void, 3, 4, "( int w, int h ) Set's the brushes width and height.")
{
   S32 w = dAtoi(argv[2]);
   S32 h = argc > 3 ? dAtoi(argv[3]) : w;
	object->setBrushSize( w, h );
}

ConsoleMethod( TerrainDeformer, setBrushPressure, void, 3, 3, "( float pressure )")
{
   object->setBrushPressure( dAtof( argv[2] ) );
}

ConsoleMethod( TerrainDeformer, setBrushSoftness, void, 3, 3, "( float softness )")
{
   object->setBrushSoftness( dAtof( argv[2] ) );
}

ConsoleMethod( TerrainDeformer, setFirstAction, void, 3, 3, "( string action ) Set's the deformers first action.")
{
	object->setFirstAction(argv[2]);
}
ConsoleMethod( TerrainDeformer, setSecondAction, void, 3, 3, "( string action ) Set's the deformers second action.")
{
	object->setSecondAction(argv[2]);
}
ConsoleMethod( TerrainDeformer, setThirdAction, void, 3, 3, "( string action ) Set's the deformers third action.")
{
	object->setThirdAction(argv[2]);
}

ConsoleMethod( TerrainDeformer, setSlopeLimitMinAngle, F32, 3, 3, 0)
{
	F32 angle = dAtof( argv[2] );	
	if ( angle < 0.0f )
		angle = 0.0f;
   if ( angle > object->mSlopeMaxAngle )
      angle = object->mSlopeMaxAngle;

	object->mSlopeMinAngle = angle;
	return angle;
}

ConsoleMethod( TerrainDeformer, setSlopeLimitMaxAngle, F32, 3, 3, 0)
{
	F32 angle = dAtof( argv[2] );	
	if ( angle > 90.0f )
		angle = 90.0f;
   if ( angle < object->mSlopeMinAngle )
      angle = object->mSlopeMinAngle;
      
	object->mSlopeMaxAngle = angle;
	return angle;
}


ConsoleMethod( TerrainDeformer, setDeformObject, void, 2, 3, "( string object ) Set's the Object the deformer will use for positioning.")
{
	// Try to get the terrain.
	SceneObject* myObject = dynamic_cast<SceneObject*>(Sim::findObject(argv[2]));
   
	if (!myObject)
	{
		Con::errorf(ConsoleLogEntry::Script, "TerrainDeformer::setSceneDeformObject() failed to find object '%s'", argv[2]);
		return;
	}
	else
	{
		object->setSceneDeformObject(myObject);
	}

}

ConsoleMethod( TerrainDeformer, setDefaultPaintTexture, void, 3, 3, "( string texture ) Set's the material to use when painting the terrain.")
{
   const char* name = argv[ 2 ];
   object->setDefaultPaintTexture(name);
}
ConsoleMethod( TerrainDeformer, setSteepPaintTexture, void, 3, 3, "( string texture ) Set's the material to use when painting steep terrain.")
{
   const char* name = argv[ 2 ];
   object->setSteepPaintTexture(name);
}
ConsoleMethod( TerrainDeformer, setLifeTime, void, 3, 3, "( int ticks ) Set's how many ticks the deformer processes before stopping.")
{
	object->mLivingTicks = dAtoi( argv[ 2 ] );
}