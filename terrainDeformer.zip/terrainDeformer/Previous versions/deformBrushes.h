class DeformBrush : public DeformSelection
{
   protected:

      TerrainDeformer *		mTerrainDeformer;
      Point2I				mSize;
      GridPoint				mGridPoint;

   public:

      enum {MaxBrushDim = 40};

      DeformBrush(TerrainDeformer * editor);

      virtual ~DeformBrush(){};

      virtual const char *getType() const = 0;

      bool validate() {return true;}

      void setPosition(const Point3F & pos);

      void setPosition(const Point2I & pos);

      const Point2I & getPosition();

      const GridPoint & getGridPoint();

      void setTerrain(TerrainBlock* terrain) { mGridPoint.terrainBlock = terrain; };

      void update();

      virtual void rebuild() = 0;

      virtual void render(Vector<GFXVertexPC> & vertexBuffer, S32 & verts, S32 & elems, S32 & prims, const ColorF & inColorFull, const ColorF & inColorNone, const ColorF & outColorFull, const ColorF & outColorNone) const = 0;

      Point2I getSize() const {return(mSize);}

      virtual void setSize(const Point2I & size){mSize = size;}
};

class DeformBoxBrush : public DeformBrush
{
   protected:

      Vector<S32>   mRenderList;

   public:

      DeformBoxBrush(TerrainDeformer * editor) : DeformBrush(editor){}
      
      const char *getType() const { return "box"; }

      void rebuild();

      void render(Vector<GFXVertexPC> & vertexBuffer, S32 & verts, S32 & elems, S32 & prims, const ColorF & inColorFull, const ColorF & inColorNone, const ColorF & outColorFull, const ColorF & outColorNone) const;
};

class DeformEllipseBrush : public DeformBrush
{
   protected:

      Vector<S32>   mRenderList;

   public:

      DeformEllipseBrush(TerrainDeformer * editor) : DeformBrush(editor){}
      
      const char *getType() const { return "ellipse"; }

      void rebuild();

      void render(Vector<GFXVertexPC> & vertexBuffer, S32 & verts, S32 & elems, S32 & prims, const ColorF & inColorFull, const ColorF & inColorNone, const ColorF & outColorFull, const ColorF & outColorNone) const;
};

class DeformSelectionBrush : public DeformBrush
{
   public:

      DeformSelectionBrush(TerrainDeformer * editor);

      const char *getType() const { return "DeformSelection"; }

      void rebuild();

      void render(Vector<GFXVertexPC> & vertexBuffer, S32 & verts, S32 & elems, S32 & prims, const ColorF & inColorFull, const ColorF & inColorNone, const ColorF & outColorFull, const ColorF & outColorNone) const;

      void setSize(const Point2I &){}
};