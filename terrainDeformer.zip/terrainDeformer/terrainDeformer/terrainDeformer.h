#ifndef _TERRAINDEFORMER_H_

	#define _TERRAINDEFORMER_H_

	#ifndef _GAMEBASE_H_
		#include "T3D/gameBase/gameBase.h" 
	#endif

	#ifndef _TERRDATA_H_
		#include "terrain/terrData.h"
	#endif

	//----------------------------STRUCTURES / OBJECTS------------------------------
	struct DeformEvent{Point3F wPos; Point2I gPos;};
	struct GridPoint
	{
		Point2I        gridPos;
		TerrainBlock*  terrainBlock;
		GridPoint() { gridPos.set(0, 0); terrainBlock = NULL; };
	};
	class GridInfo
	{
		public:
			GridPoint                  mGridPoint;
			U8                         mMaterial;
			F32                        mHeight;
			F32                        mWeight;
			F32                        mStartHeight;
			bool                       mPrimarySelect;
			bool                       mMaterialChanged;
			S32                        mNext;
			S32                        mPrev;
	};

	class DeformSelection : public Vector<GridInfo>
	{
		private:

			StringTableEntry     mName;
			BitSet32             mUndoFlags;
			Vector<S32>          mHashLists;
			U32                  mHashListSize;

			S32	lookup(const Point2I & pos);

			void	insert(GridInfo info);

			U32	getHashIndex(const Point2I & pos);

			bool	validate();

		public:

			DeformSelection();

			virtual ~DeformSelection();

			void reset();
			void setName(StringTableEntry name);

			bool add(const GridInfo &info);
			bool getInfo(Point2I pos, GridInfo & info);
			bool setInfo(GridInfo & info);
			bool remove(const GridInfo &info);

			StringTableEntry getName(){return(mName);}
			
			F32 getAvgHeight();
			F32 getMinHeight();
			F32 getMaxHeight();
	};

	class DeformAction;
	class TerrainDeformer;
	class TerrainDeformerData;
	//-------------------------------DEFORM BRUSHES---------------------------------
	class DeformBrush : public DeformSelection
	{
		protected:

			TerrainDeformer *		mTerrainDeformer;
			Point2I					mSize;
			GridPoint				mGridPoint;

		public:

			enum {MaxBrushDim = 40};
			
			DeformBrush(TerrainDeformer * editor);

			virtual ~DeformBrush(){};
			virtual const char *getType() const = 0;
			virtual void rebuild() = 0;
			virtual void setSize(const Point2I & size){mSize = size;}
			bool validate() {return true;}
			
			void setPosition(const Point3F & pos);
			void setPosition(const Point2I & pos);
			void setTerrain(TerrainBlock* terrain) { mGridPoint.terrainBlock = terrain; };
			void update();

			const Point2I & getPosition();
			const GridPoint & getGridPoint();

			Point2I getSize() const {return(mSize);}
	};

	class DeformBoxBrush : public DeformBrush
	{
		protected:

			Vector<S32>   mRenderList;

		public:

			DeformBoxBrush(TerrainDeformer * editor) : DeformBrush(editor){}
			const char *getType() const { return "box"; }
			void rebuild();
	};

	class DeformEllipseBrush : public DeformBrush
	{
		protected:

			Vector<S32>   mRenderList;

		public:

			DeformEllipseBrush(TerrainDeformer * editor) : DeformBrush(editor){}
			const char *getType() const{ return "ellipse"; }
			void rebuild();
	};

	class DeformSelectionBrush : public DeformBrush
	{
		public:

			DeformSelectionBrush(TerrainDeformer * editor);

			const char *getType() const { return "DeformSelection"; }
			
			void rebuild();
			void setSize(const Point2I &){}
	};
	//----------------------------------DATABLOCK-----------------------------------
	class TerrainDeformerData : public GameBaseData {
	  
	public:

		typedef GameBaseData Parent;

		enum TerrainDeformerActions{

		  raiseHeight,
		  lowerHeight,
		  setHeight,
		  setEmpty, 
		  clearEmpty,
		  smoothHeight,
		  paintNoise,

		};


		bool newEvent;

		S32 terrainId;

		S32 lifetime;

		S32 FirstAction;
		S32 SecondAction;
		S32 ThirdAction;

	public:
	   
		TerrainDeformerData();

		bool onAdd();
		bool preload(bool server, String errorBuffer);

		static void  initPersistFields();

		virtual void packData(BitStream* stream);
		virtual void unpackData(BitStream* stream);

		DECLARE_CONOBJECT(TerrainDeformerData);
	};
	//------------------------------TERRAIN DEFORMER--------------------------------
	class TerrainDeformer : public GameBase
	{
		typedef GameBase Parent;

		private:	

		//-- private VARIABLES

			TerrainDeformerData*		mDataBlock;

			TerrainBlock*				mActiveTerrain;

			VectorPtr<TerrainBlock*>	mTerrainBlocks;
			Vector<DeformAction *>		mActions;

			Point2I						mGridUpdateMin;
			Point2I						mGridUpdateMax;
			Point2I						mBrushSize;

			U32							mSeq;

			S32							mDefaultPaintIndex;
			S32							mSteepPaintIndex;

			F32							mBrushPressure;
			F32							mBrushSoftness;

			Point3F						mDeformPos;

			bool						mNeedsGridUpdate;
			bool						mNeedsMaterialUpdate;
			bool						mIsDirty; 
			bool						mIsMissionDirty; 
			bool						mBrushChanged;
			bool						mInAction;

			DeformBrush *				mDeformBrush;

			DeformAction *				mFirstAction;
			DeformAction *				mSecondAction;
			DeformAction *				mThirdAction;

			DeformSelection *			mCurrentSel;
			DeformSelection				mDefaultSel;

			SceneObject*				mDeformObject;

		//-- private METHODS

			F32 getGridHeight(const GridPoint & gPoint);
			

			U8 getGridMaterial( const GridPoint &gPoint ) const;
			U8 getGridMaterialGroup(const GridPoint & gPoint);
			
			void processTick(const Move* move);
			void updateBrush(DeformBrush & DeformBrush, const Point2I & gPos);
			void setGridMaterial( const GridPoint & gPoint, U8 index );
			void setGridHeight(const GridPoint & gPoint, const F32 height);
			void setGridMaterialGroup(const GridPoint & gPoint, U8 group);
			void updateCollisionRadius(DeformEvent & deformEvent);

			bool collidingWithTerrain(DeformEvent & deformEvent);

		public:

			TerrainDeformer();
			~TerrainDeformer();

		//-- public VARIABLES

			bool                 mRenderBorder;
			bool                 mBorderLineMode;
			bool                 mSelectionHidden;
			bool                 mRenderVertexSelection;
			bool                 mRenderSolidBrush;
			bool                 mProcessUsesBrush;
			bool				 mManualUpdate;

			F32					 mSlopeMinAngle;
			F32					 mSlopeMaxAngle;
			F32                  mAdjustHeightMouseScale;
			F32                  mBorderHeight;
			F32                  mAdjustHeightVal;
			F32                  mSetHeightVal;
			F32                  mScaleVal;
			F32                  mSmoothFactor;
			F32                  mNoiseFactor;
			S32                  mMaterialGroup;
			F32                  mSoftSelectRadius;

			StringTableEntry     mSoftSelectFilter;
			StringTableEntry     mSoftSelectDefaultFilter;
			
			Point2I              mMaxBrushSize;

			S32					 mLivingTicks;
			S32					 mCurTick;

		//-- public METHODS

			TerrainBlock* getTerrainUnderWorldPoint(const Point3F & wPos);
			TerrainBlock* isColliding(DeformEvent & deformEvent);
			TerrainBlock* getTerrainBlock() const { return mActiveTerrain; }
			TerrainBlock* getClientTerrain( TerrainBlock *serverTerrain = NULL ) const;
			TerrainBlock* getClientTerrain();
			TerrainBlock* getTerrainBlock(S32 index);
			TerrainBlock* getActiveTerrain() { return mActiveTerrain; };


			bool gridToWorld(const GridPoint & gPoint, Point3F & wPos);
			bool gridToWorld(const Point2I & gPos, Point3F & wPos, TerrainBlock* terrain);
			bool worldToGrid(const Point3F & wPos, GridPoint & gPoint);
			bool worldToGrid(const Point3F & wPos, Point2I & gPos, TerrainBlock* terrain = NULL);
			bool getGridInfo(const GridPoint & gPoint, GridInfo & info);
			bool getGridInfo(const Point2I & gPos, GridInfo & info, TerrainBlock* terrain);
			bool terrainBlockValid() { return(mActiveTerrain ? true : false); }
			bool isPointInTerrain(const GridPoint & gPoint);
			bool onNewDataBlock(GameBaseData* dptr);
			bool onAdd();

			void attachTerrain(TerrainBlock *terrBlock);
			void detachTerrain(TerrainBlock *terrBlock);
			void getTerrainBlocksMaterialList(Vector<StringTableEntry>& list); 
			void getGridInfos(const GridPoint & gPoint, Vector<GridInfo>& infos);
			void gridUpdateComplete( bool materialChanged = false );
			void materialUpdateComplete();
			void processActionTick(U32 sequence);
			void resetCurrentSel(){ mCurrentSel = &mDefaultSel; }
			void setCurrentSel(DeformSelection * sel) { mCurrentSel = sel; }
			void setBrushPressure( F32 pressure );
			void setBrushSoftness( F32 softness );
			void setDirty() { mIsDirty = true; }
			void setMissionDirty()  { mIsMissionDirty = true; }
			void setBrushPos(Point2I pos);
			void setBrushType(const char* type);
			void setBrushSize(S32 w, S32 h);
			void setFirstAction(const char* action);
			void setSecondAction(const char* action);
			void setThirdAction(const char* action);
			void setDefaultPaintTexture(const char* textureName);
			void setSteepPaintTexture(const char* textureName);
			void setSceneDeformObject(SceneObject* Object);
			void setGridInfo(const GridInfo & info, bool checkActive = false);
			void setGridInfoHeight(const GridInfo & info);
			void processAction(const char* sAction);
			void resetSelWeights(bool clear);
			void clearSelection();
			void scheduleGridUpdate() { mNeedsGridUpdate = true; }
			void scheduleMaterialUpdate() { mNeedsMaterialUpdate = true; }
			void onDeleteNotify(SimObject * object);
			void renderUpdates();
			void updateGuiInfo();
			void getTerrainBlocks();

			DeformSelection * getCurrentSel(){return(mCurrentSel);}
			
			F32 getBrushPressure() const {return mBrushPressure;}
			F32 getBrushSoftness() const {return mBrushSoftness;}
			F32 getGridHeight(const Point2I gPos);
			F32 getHeight(const Point3F & wPos);
			
			Point2I getBrushSize() {return(mBrushSize);}
			
			DeformAction * lookupAction(const char * name);

			S32 getNumActions();
			S32 getNumTextures();
			S32 getDefaultPaintMaterialIndex() const {return mDefaultPaintIndex;}
			S32 getSteepPaintMaterialIndex() const {return mSteepPaintIndex;}
			
			const char* getActionName(U32 index);
			const char* getBrushType() const;
			const char* getBrushPos();
			const char* getCurrentAction() const;

			virtual void completeUpdates(const DeformEvent & deformEvent);
			virtual void doDeform(const DeformEvent & deformEvent);

			static void initPersistFields();

			DECLARE_CONOBJECT(TerrainDeformer);

	protected:

			U32  packUpdate(NetConnection *conn, U32 mask, BitStream *stream);

			void unpackUpdate(NetConnection *conn, BitStream *stream);
			void onRemove();
	};

	//----------------------------------METHODS-------------------------------------
	inline void TerrainDeformer::setGridInfoHeight(const GridInfo & info){setGridHeight(info.mGridPoint, info.mHeight);}

#endif