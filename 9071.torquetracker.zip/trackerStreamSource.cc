//--------------------------------------
// vorbisStreamSource.cc
// implementation of streaming audio source
//
// Kurtis Seebaldt
//--------------------------------------

#include "audio/trackerStreamSource.h"
#include "vorbis/codec.h"
#include "console/console.h"

#define BUFFERSIZE 32768
#define CHUNKSIZE 4096

#if defined(TORQUE_BIG_ENDIAN)
	#define ENDIAN 1
#else
	#define ENDIAN 0
#endif

// Not using the music handler yet
//extern const char * MusicPlayerStreamingHook(const AUDIOHANDLE & handle);

TrackerStreamSource::TrackerStreamSource(const char *filename)  {
   stream = NULL;
   bIsValid = false;
   bBuffersAllocated = false;
   bDumbFileInitialized = false;
   mBufferList[0] = 0;
   clear();

   mFilename = filename;
   mPosition = Point3F(0.f,0.f,0.f);
}

TrackerStreamSource::~TrackerStreamSource() {
	if(bReady && bIsValid)
	{
		duh_end_sigrenderer(sr);
		unload_duh(duh);
	}
}

void TrackerStreamSource::clear()
{
	//if(stream)
	//	freeStream();

	mHandle           = NULL_AUDIOHANDLE;
	mSource			  = NULL;

	if(mBufferList[0] != 0)
		alDeleteBuffers(NUMBUFFERS, mBufferList);
	for(int i = 0; i < NUMBUFFERS; i++)
		mBufferList[i] = 0;

	dMemset(&mDescription, 0, sizeof(Audio::Description));
	mEnvironment = 0;
	mPosition.set(0.f,0.f,0.f);
	mDirection.set(0.f,1.f,0.f);
	mPitch = 1.f;
	mScore = 0.f;
	mCullTime = 0;

	bReady = false;
	bFinishedPlaying = false;
	bIsValid = false;
	bBuffersAllocated = false;
	bDumbFileInitialized = false;
}

bool TrackerStreamSource::initStream() {
	vorbis_info *vi;

   ALint			error;

   int n_channels = 2;
   bFinished = false;
   freq = 44100;
   format = AL_FORMAT_STEREO16;

   // JMQ: changed buffer to static and doubled size.  workaround for
   // https://206.163.64.242/mantis/view_bug_page.php?f_id=0000242
   static char data[BUFFERSIZE*2];

   alSourceStop(mSource);
   alSourcei(mSource, AL_BUFFER, 0);

   // load a file using dumb
   	//atexit(&dumb_exit);
	dumb_register_stdfiles();
	dumb_it_max_to_mix = 256;

	duh = load_duh(mFilename);
	if (!duh) {
		duh = dumb_load_it_quick(mFilename);
		if (!duh) {
			duh = dumb_load_xm_quick(mFilename);
			if (!duh) {
				duh = dumb_load_s3m_quick(mFilename);
				if (!duh) {
					duh = dumb_load_mod_quick(mFilename);
					if (!duh) {
						Con::errorf("Unable to open %s!\n", mFilename);
						return false;
					}
				}
			}
		}
	}

	sr = duh_start_sigrenderer(duh, 0, n_channels, 0);
	if (!sr) {
		unload_duh(duh);
		Con::errorf("Error initializing %s!\n", mFilename);
		return false;
	}

	/* Install dumb_it_callback_terminate() as the loop and XM speed zero
	 * callbacks. That means DUMB will stop generating samples
	 * immediately upon either of these events occurring.
	 * The callback function itself is provided by DUMB.
	 */
	{
		DUMB_IT_SIGRENDERER *itsr = duh_get_it_sigrenderer(sr);
		dumb_it_set_loop_callback(itsr, &dumb_it_callback_terminate, NULL);
		dumb_it_set_xm_speed_zero_callback(itsr, &dumb_it_callback_terminate, NULL);
	}


	bDumbFileInitialized = true;

	// Clear Error Code
	alGetError();


	alGenBuffers(NUMBUFFERS, mBufferList);
	if ((error = alGetError()) != AL_NO_ERROR)
		return false;

	bBuffersAllocated = true;

	int numBuffers = 0;
	for(int loop = 0; loop < NUMBUFFERS; loop++)
	{
		long ret = dumbRead(data, BUFFERSIZE, ENDIAN, &current_section);
		if(ret <= 0) {
			bFinished = AL_TRUE;
			break;
		}

		alBufferData(mBufferList[loop], format, data, ret, freq);
		++numBuffers;

		if ((error = alGetError()) != AL_NO_ERROR)
			return false;
		if(bFinished)
			break;
	}

	// Queue the buffers on the source
	alSourceQueueBuffers(mSource, NUMBUFFERS, mBufferList);
	if ((error = alGetError()) != AL_NO_ERROR)
		return false;

	alSourcei(mSource, AL_LOOPING, AL_FALSE);
	bReady = true;

	bIsValid = true;

   return true;
}

bool TrackerStreamSource::updateBuffers() {

	ALint			processed;
	ALuint			BufferID;
	ALint			error;
        // JMQ: changed buffer to static and doubled size.  workaround for
        // https://206.163.64.242/mantis/view_bug_page.php?f_id=0000242
	static char data[BUFFERSIZE*2];

	// don't do anything if stream not loaded properly
	if(!bIsValid)
		return false;

	if(bFinished && mDescription.mIsLooping)
      resetStream();

	// reset AL error code
	alGetError();

#if 1 //def TORQUE_OS_LINUX
        // JMQ: this doesn't really help on linux.  it may make things worse.
        // if it doesn't help on mac/win either, could disable it.
	ALint state;
	alGetSourcei(mSource, AL_SOURCE_STATE, &state);
	if (state == AL_STOPPED)
	{
		// um, yeah.  you should be playing
		// restart
		alSourcePlay(mSource);
//#ifdef TORQUE_DEBUG
//Con::errorf(">><<>><< THE MUSIC STOPPED >><<>><<");
//#endif
		return true;
	}
#endif

#ifdef TORQUE_OS_LINUX
        checkPosition();
#endif

	// Get status
	alGetSourcei(mSource, AL_BUFFERS_PROCESSED, &processed);

	// If some buffers have been played, unqueue them and load new audio into them, then add them to the queue
	if (processed > 0)
	{
		while (processed)
		{
			alSourceUnqueueBuffers(mSource, 1, &BufferID);
			if ((error = alGetError()) != AL_NO_ERROR)
				return false;

			if (!bFinished)
			{
				long ret = dumbRead(data, BUFFERSIZE, ENDIAN, &current_section);
				if(ret > 0) {
					alBufferData(BufferID, format, data, ret, freq);
					if ((error = alGetError()) != AL_NO_ERROR)
						return false;

					// Queue buffer
					alSourceQueueBuffers(mSource, 1, &BufferID);
					if ((error = alGetError()) != AL_NO_ERROR)
						return false;
				}
				else
				{
					// Stop playing when the file is finished
					bFinished = AL_TRUE;
				}

				processed--;

				if(bFinished && mDescription.mIsLooping) {
					resetStream();
				}
			}
			else
			{
				buffersinqueue--;
				processed--;

				if (buffersinqueue == 0)
				{
					bFinishedPlaying = AL_TRUE;
					return AL_FALSE;
				}
			}
		}
	}

	return true;
}

void TrackerStreamSource::freeStream() {
	bReady = false;

	if(bBuffersAllocated) {
		if(mBufferList[0] != 0)
			alDeleteBuffers(NUMBUFFERS, mBufferList);
		for(int i = 0; i < NUMBUFFERS; i++)
			mBufferList[i] = 0;

		bBuffersAllocated = false;
	}

	if(bDumbFileInitialized) {
		duh_end_sigrenderer(sr);
		unload_duh(duh);
		bDumbFileInitialized = false;
	}
}

void TrackerStreamSource::resetStream()
{
   // MusicPlayerStreamingHook allow you to create a handler
   // where you can rotate through streaming files
   // Comment in and provide hook if desired.
   //
   //const char * newFile = MusicPlayerStreamingHook(mHandle);
   //if (newFile)
   //{
   //   setNewFile(newFile);
   //   return;
   //}
   //else
   //{
   	//vf.ov_pcm_seek(0);
   	//DataLeft = DataSize;
   	//bFinished = AL_FALSE;
	//}

	int n_channels = 2;

	if(bReady && bIsValid)
	{
		duh_end_sigrenderer(sr);
		unload_duh(duh);
	}

	dumb_register_stdfiles();
	dumb_it_max_to_mix = 256;

	duh = load_duh(mFilename);
	if (!duh) {
		duh = dumb_load_it_quick(mFilename);
		if (!duh) {
			duh = dumb_load_xm_quick(mFilename);
			if (!duh) {
				duh = dumb_load_s3m_quick(mFilename);
				if (!duh) {
					duh = dumb_load_mod_quick(mFilename);
					if (!duh) {
						Con::errorf("Unable to open %s!\n", mFilename);
						return;
					}
				}
			}
		}
	}

	sr = duh_start_sigrenderer(duh, 0, n_channels, 0);
	if (!sr) {
		unload_duh(duh);
		Con::errorf("Error initializing %s!\n", mFilename);
		return;
	}

	bFinished = AL_FALSE;
}

long TrackerStreamSource::dumbRead(char *buffer,int slength, int bigendianp,int *bitstream)
{
	int depth = 16;
	int bigendian = bigendianp;
	int unsign = 0;
	int freq = 44100;
	int n_channels = 2;
	float volume = 1.0f;
	float delta= 65536.0f / freq;


	long l = duh_render(sr, depth, unsign, volume, delta, slength/4, buffer);

#ifdef TORQUE_BIG_ENDIAN
	short* sbuffer = (short*)buffer;
	for (int c=0; c < l * n_channels; c++)
	{
		short val = sbuffer[c];
		buffer[i*2] = (char)(val >> 8);
		buffer[i*2+1] = (char)val;
	}
#endif


	// returns 0 when the file is done
	return l*4;
}


