//--------------------------------------------
// wavStreamSource.h
// header for streaming audio source for WAV
//--------------------------------------------

#ifndef _TRACKERSTREAMSOURCE_H_
#define _TRACKERSTREAMSOURCE_H_

#ifndef _AUDIOSTREAMSOURCE_H_
#include "audio/audioStreamSource.h"
#endif

#include "dumb.h"

class TrackerStreamSource: public AudioStreamSource
{
	public:
		TrackerStreamSource(const char *filename);
		virtual ~TrackerStreamSource();

		virtual bool initStream();
		virtual bool updateBuffers();
		virtual void freeStream();

	private:
		ALuint				    mBufferList[NUMBUFFERS];
		S32						mNumBuffers;
		S32						mBufferSize;
		Stream				   *stream;

		bool					bReady;
		bool					bFinished;

		ALenum  format;
		ALsizei size;
		ALsizei freq;


		ALuint			buffersinqueue;

		bool			bBuffersAllocated;
		bool			bDumbFileInitialized;


		DUH *duh;
		DUH_SIGRENDERER *sr;
		LONG_LONG length;
		LONG_LONG done;

		int current_section;

		void clear();
		long dumbRead(char *buffer,int length, int bigendianp,int *bitstream);
		void resetStream();
};  

#endif // _TRACKERSTREAMSOURCE_H_
