The first steps are to download the Dumb playback library from http://dumb.sourceforge.net/.  This resource is made using TGE 1.3 and Dumb version 0.9.3.  It should probably work with other version of Torque and Dumb, but was tested using those versions.  In addition I didn't worry about Mac support yet, but it should be easy enough to add.

You will have to build Dumb, using the instructions that come with the distrobution, and add to your Torque build.  If you know how to compile programs, this shouldn't be a big deal.

Once you have Torque and Dumb working together, add the trackerAudioSource.cc and trackerAudioSource.h files to the engine/audio directory.  You will also have to add these files to your build process.  After you have done that, add the following changes to the Torque C++ code.

Change the following in audio/audio.cc Line 13:
[code]
#include "audio/audioStreamSourceFactory.h"

#ifdef TORQUE_OS_MAC
//#define REL_WORKAROUND
#endif
[/code]

To the following:
[code]
#include "audio/audioStreamSourceFactory.h"
#include "dumb.h"

#ifdef TORQUE_OS_MAC
//#define REL_WORKAROUND
#endif
[/code]

Change the following in audio/audio.cc Line 2459:
[code]
   OpenALDLLShutdown();
}
[/code]

To the following:
[code]
   OpenALDLLShutdown();
   dumb_exit();
}
[/code]


Change the following in audio/audioStreamSourceFactory.cc Line 21:
[code]
	if(len > 3 && !dStricmp(filename + len - 4, ".wav"))
		return new WavStreamSource(filename);
	else if(len > 3 && !dStricmp(filename + len - 4, ".ogg"))
		return new VorbisStreamSource(filename);
[/code]

To the following
[code]
	if(len > 3 && !dStricmp(filename + len - 4, ".wav"))
		return new WavStreamSource(filename);
	else if(len > 3 && !dStricmp(filename + len - 4, ".ogg"))
		return new VorbisStreamSource(filename);
	else if(len > 3 && !dStricmp(filename + len - 3, ".it"))
		return new TrackerStreamSource(filename);
	else if(len > 3 && !dStricmp(filename + len - 3, ".xm"))
		return new TrackerStreamSource(filename);
	else if(len > 3 && !dStricmp(filename + len - 4, ".s3m"))
		return new TrackerStreamSource(filename);
	else if(len > 3 && !dStricmp(filename + len - 4, ".mod"))
		return new TrackerStreamSource(filename);
[/code]

Once you have those changes added, and you build Torque, you will be able to use Tracker Files inside of Torque.  If you want to try it out, add the following to client/scripts/audioProfiles.cs, in TorqueScript:

[code]
new AudioDescription(AudioMusic){
   volume   = 1.0;   
   isLooping = true;   
   isStreaming = true;    
   is3D     = false;
   type     = $GuiAudioType;
};

new AudioProfile(InGameMusic){
   filename    = "~/data/music/4K4K4K4K.S3M";
   description = "AudioMusic";    
   preload = false;
};
[/code]


Now add the include s3m file 4K4K4K4K.S3M into data/music (you will probably have to create that flder, load up Torque and type the following:
[code]
$music = alxplay(InGameMusic);
[/code]

If you want to stop the music type:
[code]
alxstop($music);
[/code]


