//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

//
//  Torque2DAppDelegate.h
//  Torque2D
//
//  Created by puap on 7/28/08.
//  Copyright  PUAP 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Torque2DAppDelegate : NSObject <UIApplicationDelegate> {
	IBOutlet UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end

