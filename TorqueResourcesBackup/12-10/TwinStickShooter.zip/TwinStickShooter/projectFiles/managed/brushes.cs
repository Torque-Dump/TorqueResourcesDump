$brushSet = new SimSet() {
   canSaveDynamicFields = "1";
   PlatformTarget = "UNIVERSAL";
      setType = "Brushes";
};
