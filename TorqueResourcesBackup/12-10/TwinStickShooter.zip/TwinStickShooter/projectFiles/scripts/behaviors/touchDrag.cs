//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

// Create this behavior only if it does not already exist
if (!isObject(TouchDrag))
{
   // Create this behavior from the blank BehaviorTemplate
   // Name it TouchDrag
   %template = new BehaviorTemplate(TouchDrag);
   
   // friendlyName will be what is displayed in the editor
   // behaviorType organize this behavior in the editor
   // description briefly explains what this behavior does
   %template.friendlyName = "Touch Drag";
   %template.behaviorType = "Movement Styles";
   %template.description  = "Allows the user to drag the object using the touch screen";
}

function TouchDrag::onBehaviorAdd(%this)
{
   %this.touchID = "";
   %this.owner.setUseMouseEvents(true);
}

function TouchDrag::onTouchDown(%this, %touchID, %worldPos)
{
   // If we are already dragging, do nothing
   // Otherwise, enable the drag variable
   if(%this.touchID $="")
   {
      %this.touchID = %touchID;
   }
}

function TouchDrag::onTouchUp(%this, %touchID, %worldPos)
{
   if(%this.touchID $= %touchID)
   {
      %this.touchID = "";
   }
}

function TouchDrag::onTouchDragged(%this, %touchID, %worldPos)
{
   if(%this.touchID $= "")
      %this.touchID = %touchID;
      
   if(%this.touchID $= %touchID)
   {
      %this.owner.setPosition(%worldPos);
   }
}