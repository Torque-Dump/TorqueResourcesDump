if (!isObject(DPadBehavior))  
{  
    %template = new BehaviorTemplate(DPadBehavior);  
  
    %template.friendlyName = "D Pad";  
    %template.behaviorType = "Control";  
    %template.description  = "Joystick-like control";  
     
    %template.addBehaviorField(thumbdisk, "The disk that appears under the thumb", object, "", t2dSceneObject);  
    %template.addBehaviorField(targetObject, "The object that gets moved", object, "", t2dSceneObject);  
  
    %template.addBehaviorField(scale, "Scale the effect on the object", float , 1.0 );  
    %template.addBehaviorField(flipX, "Flip Horizontal because of movement", bool, true);  
}  
  
function DPadBehavior::onBehaviorAdd(%this)  
{  
    if (isObject(%this.targetObject))  
        %this.targetObject.setUsesPhysics(true);  
    %this.owner.oldX = %this.owner.getPositionX();
    %this.owner.oldY = %this.owner.getPositionY();      
    %this.owner.setUseMouseEvents(true);  
    %this.owner.CollisionDetectionMode = "CIRCLE";
    //%this.owner.setCollisionCircleSuperscribed(true);  
}  
  
function DPadBehavior::Update(%this, %worldPos)  
{  
    %vec = t2dVectorSub(%worldPos, %this.owner.getPosition());  
  
    if (t2dVectorLength(%vec) > %this.size)  
        %vec = t2dVectorScale(%vec, 1/(t2dVectorLength(%vec)/%this.size));  
      
    %this.thumbdisk.setPosition(t2dVectorAdd(%this.owner.getPosition(), %vec));  
  
    %move = t2dVectorScale(%vec, %this.scale);  
    %this.targetObject.setLinearVelocity(%move);  
  
    if (%this.flipX)  
        %this.targetObject.setFlipX(%move.x > 0);  
}  
  
function DPadBehavior::onTouchDown(%this, %touchId, %worldPos)  
{  
    if (!%this.owner.getIsPointInObject(%worldPos))  
        return;  
  
    %this.thumbpos = %worldPos;  
    %this.thumbdisk.setPosition(%this.thumbpos);  
    %this.tid = %touchId;  
  
    %this.Update(%worldPos);  
}  
  
function DPadBehavior::onLevelLoaded(%this)  
{  
    %size = %this.owner.getSize();  
    %this.size = ( %size.x > %size.y ) ? %size.x/2 : %size.y/2;  
    %this.thumbdisk.setPosition(%this.owner.getPosition());  
}  
  
function DPadBehavior::onTouchDragged(%this, %touchId, %worldPos)  
{  
    if (%touchId != %this.tid) return;  
      
    %this.Update(%worldPos);  
}  
  
function DPadBehavior::onTouchUp(%this, %touchId, %worldPos) 
{  
    if (%touchId != %this.tid) return;  
  
    %this.thumbpos = %worldPos;  
    %this.thumbdisk.setPosition(%this.owner.getPosition());  
      
    %this.tid = 0;  
    %this.targetObject.setAtRest();  
    
    
}  
  
function DPadBehavior::onMouseLeave(%this, %touchID, %worldPos)  
{  
    %this.onTouchUp(%this, %touchID, %worldPos);  
}  