if (!isObject(FirePadBehavior))  
{  
    %template = new BehaviorTemplate(FirePadBehavior);  
  
    %template.friendlyName = "FirePad";  
    %template.behaviorType = "Control";  
    %template.description  = "Joystick-like control";  
     
    %template.addBehaviorField(thumbdisk, "The disk that appears under the thumb", object, "", t2dSceneObject);  
    %template.addBehaviorField(targetObject, "The object that gets moved", object, "", t2dSceneObject);  
  
    %template.addBehaviorField(scale, "Scale the effect on the object", float , 1.0 );  
    %template.addBehaviorField(flipX, "Flip Horizontal because of movement", bool, true);  
    %template.addBehaviorField(firingSpeed, "Speed of ball", float, 10);
   
   %template.addBehaviorField(firingRate, "Rate of fire", float, 0.1);
}  
  
function FirePadBehavior::onBehaviorAdd(%this)  
{  
    if (isObject(%this.targetObject))  
        %this.targetObject.setUsesPhysics(true);  
    %this.owner.oldX = %this.owner.getPositionX();
    %this.owner.oldY = %this.owner.getPositionY();      
    %this.owner.setUseMouseEvents(true);  
    %this.owner.CollisionDetectionMode = "CIRCLE";
    //%this.owner.setCollisionCircleSuperscribed(true); 
    %this.timer = 0; 
}  
  
function FirePadBehavior::Update(%this, %worldPos)  
{  
    %vec = t2dVectorSub(%worldPos, %this.owner.getPosition());  
  
    if (t2dVectorLength(%vec) > %this.size)  
        %vec = t2dVectorScale(%vec, 1/(t2dVectorLength(%vec)/%this.size));  
      
    %this.thumbdisk.setPosition(t2dVectorAdd(%this.owner.getPosition(), %vec));  
  
    %move = t2dVectorScale(%vec, %this.scale);  
    //%this.targetObject.setLinearVelocity(%move);  
  
    //if (%this.flipX)  
    //    %this.targetObject.setFlipX(%move.x > 0);  
}  
  
function FirePadBehavior::onTouchDown(%this, %touchId, %worldPos)  
{  
    if (!%this.owner.getIsPointInObject(%worldPos))  
        return;  
  
    %this.thumbpos = %worldPos;  
    %this.thumbdisk.setPosition(%this.thumbpos);  
    %this.tid = %touchId;  
  
    %this.Update(%worldPos);  
    
    %this.mousePos = %worldPos;
   schedule( %this.firingRate, 0, "fireUsingSchedule", %this, %worldPos );

}  
  
function FirePadBehavior::onLevelLoaded(%this)  
{  
    %size = %this.owner.getSize();  
    %this.size = ( %size.x > %size.y ) ? %size.x/2 : %size.y/2;  
    %this.thumbdisk.setPosition(%this.owner.getPosition());  
}  
  
function FirePadBehavior::onTouchDragged(%this, %touchId, %worldPos)  
{  
    if (%touchId != %this.tid) return;  
   
    %this.Update(%worldPos);  
    %this.mousePos = %worldPos;
}  

function FirePadBehavior::onTouchDown(%this, %touchID, %worldPos)
{
   %this.tid = %touchId;
   %this.touchID =  %touchId;
   schedule( %this.firingRate *1000, 0, "fireUsingSchedule", %this, %worldPos );
}
  
function FirePadBehavior::onTouchUp(%this, %touchId, %worldPos) 
{  
    if (%touchId != %this.tid) return;  
  
    %this.thumbpos = %worldPos;  
    %this.thumbdisk.setPosition(%this.owner.getPosition());  
      
    %this.tid = 0;  
    //%this.targetObject.setAtRest();  
    %this.touchID = "";
    
}  
  
function FirePadBehavior::onMouseLeave(%this, %touchID, %worldPos)  
{  
    %this.onTouchUp(%this, %touchID, %worldPos);  
}

function FirePadBehavior::getAngleAndVectorToPointer( %this, %worldPos )
{
   // get position of mouse
      %x = getWord(%worldPos,0);
      %y = getWord(%worldPos,1);
      
      // get this position
      %x1 = %this.owner.getPositionX();
      %y1 = %this.owner.getPositionY();
      
      // get the vector to the point
      %vx = %x - %x1;
      %vy = %y - %y1;
      
      // get the length of a vector 
      %vLen = mSqrt((%vx * %vx) + (%vy * %vy));
      
      // normalise the vector (make it a value between 0 and 1
      %nx = %vx / %vLen;
      %ny = %vy / %vLen;
      
      // get the arc tangent of the normalised vector (so we can shoot as well)
      %degree = mRadToDeg(mAtan( %vy, %vx ));
      
      return ( %degree SPC %nx SPC %ny );
}  

// remember only global functions work with schedule
function fire( %parent, %mousePos )
{
   echo(%parent);
   %obj = new t2dStaticSprite() {
         imageMap = "pinballImageMap";
         frame = "0";
         mUseSourceRect = "0";
         sourceRect = "0 0 0 0";
         canSaveDynamicFields = "1";
         PlatformTarget = "UNIVERSAL";
         WorldLimitMode = "KILL";
         WorldLimitMin = "-255.231 -195.618";
         WorldLimitMax = "260.462 215.065";
         CollisionActiveSend = "1";
         CollisionActiveReceive = "1";
         CollisionMaxIterations = "3";
         CollisionResponseMode = "BOUNCE";
         CollisionGroups = "2";
         CollisionLayers = "2";
         GraphGroup = "0";
         AlphaTestValue = "-1";
         UsesPhysics = "1";
            mountID = "5";
      };
      
   // add it to scene graph
   %obj.scenegraph = %parent.owner.scenegraph;
   
   // fire at mouse
   %angleVector = %parent.getAngleAndVectorToPointer( %mousePos );
   
   // move to target object
   %obj.setPosition(%parent.targetObject.getPosition());
   
   // move it
   %obj.setLinearVelocityX(getWord(%angleVector,1) * %parent.firingSpeed );
   %obj.setLinearVelocityY(getWord(%angleVector,2) * %parent.firingSpeed );
   
}

// schedule firing
function fireUsingSchedule( %parent, %mousePos )
{
   // fire as normal
   echo(%parent);
   fire( %parent, %mousePos );
   
   // keep going unless mouse is up
   if (%parent.touchID !$= "")
   {
      schedule( %parent.firingRate *1000, 0, "fireUsingSchedule", %parent, %parent.mousePos );
   }
   
}