//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

$iOS::constant::iPhone = 0;
$iOS::constant::iPad = 1;
$iOS::constant::iPhone4 = 2;

$iOS::constant::Landscape = 0;
$iOS::constant::Portrait = 1;
$iOS::constant::ResolutionFull = 0;
$iOS::constant::ResolutionSmall = 1;

//These constants are just used carefully around. 
//They are always landscape, so invert them when needed.
//Add resolutions here if you want to expand.

$iOS::constant::iPhoneWidth = 480;
$iOS::constant::iPhoneHeight = 320;

$iOS::constant::iPhone4Width = 960;
$iOS::constant::iPhone4Height = 640;

$iOS::constant::iPadWidth = 1024;
$iOS::constant::iPadHeight = 768;

//For autorotate and onOrientationChange callback
//function oniPhoneChangeOrientation(%newOrientation)

$iOS::constant::OrientationUnknown				= 0;
$iOS::constant::OrientationLandscapeLeft		= 1;
$iOS::constant::OrientationLandscapeRight		= 2;
$iOS::constant::OrientationPortrait				= 3;
$iOS::constant::OrientationPortraitUpsideDown	= 4;

//
// Save config data
//
function _saveGameConfigurationData( %projectFile )
{
   export("$Game::*", "./prefs.cs", true, false);
   export("$pref::iOS::*", "./prefs.cs", true, true);
   export("$pref::Audio::*", "./prefs.cs", true, true);
   export("$pref::T2D::*", "./prefs.cs", true, true);
   export("$pref::OpenGL::gammaCorrection", "./prefs.cs", true, true);
}

//
// Load config data
//
function _loadGameConfigurationData()
{
   if(isFile("./prefs.cs"))
      exec("./prefs.cs");
}

//
// Load config data
//
function _defaultGameConfigurationData()
{
   exec("./defaultPrefs.cs");
}
