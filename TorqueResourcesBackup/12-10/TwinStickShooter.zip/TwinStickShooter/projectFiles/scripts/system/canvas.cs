//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------


function iOSResolutionFromSetting( %deviceType, %deviceScreenOrientation )
{
   // A helper function to get a string based resolution from the settings given.
   %x = 0;
   %y = 0;
   
   switch(%deviceType)
   {
      case $iOS::constant::iPhone:
         if(%deviceScreenOrientation == $iOS::constant::Landscape)
         {
            %x =  $iOS::constant::iPhoneWidth;
            %y =  $iOS::constant::iPhoneHeight;
         }
         else
         {
            %x =  $iOS::constant::iPhoneHeight;
            %y =  $iOS::constant::iPhoneWidth;
         }
      
      case $iOS::constant::iPhone4:
         if(%deviceScreenOrientation == $iOS::constant::Landscape)
         {
            %x =  $iOS::constant::iPhoneWidth;
            %y =  $iOS::constant::iPhoneHeight;
         }
         else
         {
            %x =  $iOS::constant::iPhoneHeight;
            %y =  $iOS::constant::iPhoneWidth;
         }
         
      case $iOS::constant::iPad:
         if(%deviceScreenOrientation == $iOS::constant::Landscape)
         {
            %x =  $iOS::constant::iPadWidth;
            %y =  $iOS::constant::iPadHeight;
         }
         else
         {
            %x =  $iOS::constant::iPadHeight;
            %y =  $iOS::constant::iPadWidth;
         }
   }
   return %x @ " " @ %y;
}

//------------------------------------------------------------------------------
// initializeCanvas
// Constructs and initializes the default canvas window.
//------------------------------------------------------------------------------
$canvasCreated = false;
function initializeCanvas(%windowName)
{
   // Don't duplicate the canvas.
   if($canvasCreated)
   {
      error("Cannot instantiate more than one canvas!");
      return;
   }
   
   videoSetGammaCorrection($pref::OpenGL::gammaCorrection);
   
   if (!createCanvas(%windowName))
   {
      error("Canvas creation failed. Shutting down.");
      quit();
   }

   //Luma: Apply the settings to the game from the commonConfig iOSSettings section.
   //For the resolution options, its two sided. 1) Landscape/Portrait and 2) the chosen size (full or small).
      //Todo : dont hardcore this, add it as an invisible setting. default should be 16
      
   $pref::iOS::ScreenDepth = 32;
   %res = iOSResolutionFromSetting($pref::iOS::DeviceType, $pref::iOS::ScreenOrientation);
      
   setScreenMode( GetWord( %res , 0 ), GetWord( %res, 1 ), $pref::iOS::ScreenDepth, false );

   $canvasCreated = true;
}

//------------------------------------------------------------------------------
// resetCanvas
// Forces the canvas to redraw itself.
//------------------------------------------------------------------------------
function resetCanvas()
{
   if (isObject(Canvas))
      Canvas.repaint();
}

new GuiCursor(DefaultCursor)
{
   hotSpot = "4 4";
   renderOffset = "0 0";
   bitmapName = "data/images/cursor";
};