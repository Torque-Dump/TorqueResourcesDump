//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

///
/// iOS Properties
///
$Game::CompanyName         = "Independent";
$Game::ProductName         = "defaultName";
$Game::DefaultScene        = "data/levels/emptyLevel.t2d";

//set default iOS settings.

$pref::iOS::DeviceType          = $iOS::constant::iPhone;
$pref::iOS::ScreenOrientation   = $iOS::constant::Landscape;
$pref::iOS::ScreenDepth		   = 32;

// Turn all features off by default
$pref::iOS::UseGameKit          = 0;
$pref::iOS::UseMusic            = 0;
$pref::iOS::UseMoviePlayer      = 0;
$pref::iOS::UseAutoRotate       = 0;   
$pref::iOS::EnableOrientationRotation      = 0;   
$pref::iOS::StatusBarType       = 0;

///
/// Audio
///
$pref::Audio::driver = "OpenAL";
$pref::Audio::forceMaxDistanceUpdate = 0;
$pref::Audio::environmentEnabled = 0;
$pref::Audio::masterVolume   = 0.8;
$pref::Audio::channelVolume1 = 0.8;
$pref::Audio::channelVolume2 = 0.8;
$pref::Audio::channelVolume3 = 0.8;

// Audio profiles for default
$pref::Audio::sfxVolume = 0.8;
$pref::Audio::musicVolume = 0.8;

///
/// TGB
///
$pref::T2D::dualCollisionCallbacks = 1;
$pref::T2D::imageMapDumpTextures = 0;
$pref::T2D::imageMapEchoErrors = 1;
$pref::T2D::imageMapFixedMaxTextureError = 1;
$pref::T2D::imageMapFixedMaxTextureSize = 0;
$pref::T2D::imageMapShowPacking = 0;
$pref::T2D::imageMapPreloadDefault = true;
$pref::T2D::imageMapAllowUnloadDefault = false;
$pref::T2D::particleEngineQuantityScale = 1.0;
$pref::T2D::renderContactChange = 0.5;
$pref::T2D::renderContactMax = 16;
$pref::T2D::warnFileDeprecated = 1;
$pref::T2D::warnSceneOccupancy = 1;

///
/// Video
///
$pref::Video::appliedPref = 0;
$pref::Video::disableVerticalSync = 1;
$pref::Video::displayDevice = "OpenGL";
$pref::Video::preferOpenGL = 1;
$pref::Video::fullScreen = 0;
$pref::OpenGL::gammaCorrection = 0.5;