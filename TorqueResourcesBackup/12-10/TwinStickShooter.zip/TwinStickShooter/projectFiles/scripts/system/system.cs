//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

//------------------------------------------------------------------------------
// initializeSystem
// Perform core system initialization code here
//------------------------------------------------------------------------------
function initializeSystem()
{
   // Very basic functions used by everyone.
   exec("./openal.cs");
   exec("./canvas.cs");

   // Seed the random number generator.
   setRandomSeed();
   
   // Initialize the canvas.
   initializeCanvas( $Game::ProductName );
   
   // Start up the audio system.
   initializeOpenAL();
   
   // Important Scripts.
   %startTime = getRealTime();
   
   exec("./projectManagement.cs");
   exec("./levelManagement.cs");

   // Set a default cursor.
   Canvas.setCursor(DefaultCursor);
   Canvas.showCursor();
}

function shutdownSystem()
{
   if(isFunction("shutdownProject"))
      shutdownProject();
      
   shutdownOpenAL();
}

//------------------------------------------------------------------------------
// Helper function used for loading separate packages
// This relies on the mod path having a main.cs
//------------------------------------------------------------------------------
function loadDir( %dir )
{
   // Set Mod Paths.
   setModPaths( getModPaths() @ ";" @ %dir );
   
   // Execute Boot-strap file.
   exec( %dir @ "/main.cs" );
}

//------------------------------------------------------------------------------
// Cursor toggle functions.
//------------------------------------------------------------------------------
$cursorControlled = false;
function showCursor()
{
   if ($cursorControlled)
      lockMouse(false);
   Canvas.cursorOn();
}

function hideCursor()
{
   if ($cursorControlled)
      lockMouse(true);
   Canvas.cursorOff();
}

//------------------------------------------------------------------------------
// Rounds a number
//------------------------------------------------------------------------------
function mRound(%num)
{
   if((%num-mFloor(%num)) >= 0.5)
   {
      %value = mCeil(%num);
   }
   else
   {
      %value = mFloor(%num);
   }    

   return %value;
}