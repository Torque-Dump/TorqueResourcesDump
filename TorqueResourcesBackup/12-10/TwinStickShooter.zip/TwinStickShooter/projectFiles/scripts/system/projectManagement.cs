//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

//------------------------------------------------------------------------------
// initializeProject
// Responsible for loading the script files containing the following:
// - Behaviors
// - Datablocks
// - Brushes
// - Profiles
// - Resources
//------------------------------------------------------------------------------
function _initializeProject()
{
   // Managed File Paths
   //we dont want datablocks loaded for iPhone, but we do want to have them in the editor - sven
   if($LevelEditorActive)
   {
      %dbFile = expandFilename("managed/datablocks.cs");
      %persistFile = expandFilename("managed/persistent.cs");
      %brushFile = expandFilename("managed/brushes.cs");
   }
   
   %behaviorsDirectory = expandFilename("scripts/behaviors");   
   %userDatablockFile = expandFilename("scripts/datablocks.cs");
   %userGUIProfileFile = expandFilename("gui/profiles.cs");
   
   //---------------------------------------------------------------------------   
   // Project Resources
   //---------------------------------------------------------------------------
   // --  This MUST be done BEFORE datablocks and persistent objects are loaded.
   %resPath = expandFileName("resources");

   // Index resources
   addResPath( %resPath );
   
   
   if( !isObject( $dependentResourceGroup ) )
      $dependentResourceGroup = new SimGroup();
   
   %resList = getDirectoryList( %resPath, 0 );
   %resCount = getFieldCount( %resList );

   for( %i = 0; %i < %resCount; %i++ )
   {
      %resName = getField( %resList, %i );
      %resFile = %resPath @ "/" @ %resName;
      
      %resObject = ResourceObject::load( %resFile );
      if( !isObject( %resObject ) )
      {
         error(" % Game Resources : FAILED Loading Resource" SPC %resName );
         continue;
      }
      else
         echo(" % Game Resources : Loaded Resource" SPC %resName);
         
      // Create a dependentResourcegroup object
      %entry = new ScriptObject() { Name = %resName; };
      $dependentResourceGroup.add( %entry );
   }

   //---------------------------------------------------------------------------
   // Managed Datablocks
   //---------------------------------------------------------------------------
   if ( isFile( %dbFile ) || isFile( %dbFile @ ".dso" ) )
      exec( %dbFile );
     
   if( !isObject( $managedDatablockSet ) )   
      $managedDatablockSet = new SimSet();

   //---------------------------------------------------------------------------
   // Managed Persistent Objects
   //---------------------------------------------------------------------------
   if ( isFile( %persistFile ) || isFile( %persistFile @ ".dso" ) )
      exec( %persistFile );

   if( !isObject( $persistentObjectSet ) )   
      $persistentObjectSet = new SimSet();
      
   //---------------------------------------------------------------------------
   // Managed Brushes
   //---------------------------------------------------------------------------
   if ( isFile( %brushFile ) || isFile( %brushFile @ ".dso" ) )
      exec( %brushFile );
   
   if( !isObject( $brushSet ) )   
      $brushSet = new SimSet();

   //---------------------------------------------------------------------------
   // User Defined Datablocks
   //---------------------------------------------------------------------------
   addResPath( %userDatablockFile );   
   if( isFile( %userDatablockFile ) )
      exec( %userDatablockFile );
      
   //---------------------------------------------------------------------------
   // Behaviors
   //---------------------------------------------------------------------------
   addResPath(%behaviorsDirectory);
   
   // Compile all the cs files.
   %behaviorsSpec = %behaviorsDirectory @ "/*.cs";
   for (%file = findFirstFile(%behaviorsSpec); %file !$= ""; %file = findNextFile(%behaviorsSpec))
      compile(%file);
   
   // And exec all the dsos.
   %behaviorsSpec = %behaviorsDirectory @ "/*.cs.dso";
   for (%file = findFirstFile(%behaviorsSpec); %file !$= ""; %file = findNextFile(%behaviorsSpec))
      exec(strreplace(%file, ".cs.dso", ".cs"));

   //---------------------------------------------------------------------------
   // User Defined GUI Profiles
   //---------------------------------------------------------------------------
   addResPath( %userGUIProfileFile );   
   if( isFile( %userGUIProfileFile ) )
      exec( %userGUIProfileFile );
}

if( !isObject( $resourceGroup ) )
   $resourceGroup = new SimGroup( "ResourceGroup" );

// Index resources
addResPath( expandFileName("resources"), true );

//------------------------------------------------------------------------------
// Load a resource object into the active resource tree
//------------------------------------------------------------------------------
function ResourceObject::load( %resourcePath )
{
   // Clear instant resource
   $instantResource = 0;
   
   // Generate resource file path
   %resourceFile = %resourcePath @ "/resourceDatabase.cs";

   // Non-Existent Resource
   if( !isFile( %resourceFile ) && !isFile( %resourceFile @ ".dso" ) )
      return 0;

   // Load resource script      
   exec( %resourceFile );
   
   // Validate resource object
   if( !isObject( $instantResource ) || !ResourceObject::Validate( $instantResource ) )
   {
      error("Resource with name" SPC %resourceName SPC "found but invalid resource object contained inside resource!");
      return 0;
   }
   
   // Add to active resource tree
   $resourceGroup.add( $instantResource );
      
   eval( $instantResource.LoadFunction @ "(" @ $instantResource @ ");" );
   
   %resourceObj = $instantResource;
   
   // Clear instant resource
   $instantResource = 0;         
   
   return %resourceObj;

}

//------------------------------------------------------------------------------
// Unload a resource object from the active resource tree
//------------------------------------------------------------------------------
function ResourceObject::Unload( %resourceName )
{
   %resourceObject = ResourceFinder::getResource( %resourceName );

   if( !isObject( %resourceObject ) )
      return false;
      
   // Remove from active resource tree
   if( $resourceGroup.isMember( %resourceObject ) )
      $resourceGroup.remove( %resourceObject );
   
   // Invoke resource unload
   eval( %resourceObject.UnloadFunction @ "(" @ %resourceObject @ ");" );
   
   // Some resources may delete themselves, but we check to be sure.
   if( isObject( %resourceObject ) )
      %resourceObject.delete();

   return true;
}

//------------------------------------------------------------------------------
// Validate a resource object format
//------------------------------------------------------------------------------
function ResourceObject::Validate( %resourceObject )
{
   if( !isObject( %resourceObject ) )
      return false;
      
   // Validate Resource Name
   if( %resourceObject.Name $= "" )
      return false;

   // Validate Resource User (Who makes use of this resource (TGB, TGE, TSE, etc)
   if( %resourceObject.User $= "" )
      return false;

   // Validate Resource LoadFunction
   if( %resourceObject.LoadFunction $= "" )
      return false;

   // Validate Resource UnloadFunction
   if( %resourceObject.UnloadFunction $= "" )
      return false;
   
   // Validate Resource Data Set
   if( %resourceObject.Data $= "" )
      return false;

   // Valid Resource   
   return true;
   
}

function ResourceFinder::getResource( %resourceName )
{
   if( !isObject( $resourceGroup ) )
      return 0;
      
   for( %i = 0; %i < $resourceGroup.getCount(); %i++ )
   {
      %resourceObject = $resourceGroup.getObject( %i );
      if( !isObject( %resourceObject ) )
         continue;
      
      if( %resourceObject.Name $= %resourceName )         
         return %resourceObject;
   }

   return 0;

}