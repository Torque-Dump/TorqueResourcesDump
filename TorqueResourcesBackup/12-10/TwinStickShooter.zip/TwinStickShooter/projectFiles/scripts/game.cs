//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

function setResolution()
{
   if(isObject(mainScreenGui) && isObject(sceneWindow2D))
   {
      if($pref::iOS::ScreenOrientation == 1) //portrait
      {
         if(($pref::iOS::DeviceType != $iOS::constant::iPad))
         {
            echo(" % - MainScreen set to Portrait! 320x480");
            mainScreenGui.Extent = "320 480";
            sceneWindow2D.Extent = "320 480";
         }
         else
         {
            echo(" % - MainScreen set to Portrait! 768x1024");
            mainScreenGui.Extent = "768 1024";
            sceneWindow2D.Extent = "768 1024";
         }
      }
      else
      {
         if(($pref::iOS::DeviceType != $iOS::constant::iPad))
         {
            echo(" % - MainScreen set to Landscape! 480x320 ");
            mainScreenGui.Extent = "480 320";
            sceneWindow2D.Extent = "480 320";
         }
         else
         {
            echo(" % - MainScreen set to Landscape! 1024x768 ");
            mainScreenGui.Extent = "1024 768";
            sceneWindow2D.Extent = "1024 768";
         }
      }
   }
}

function initializeGame()
{
   //  Execute our game-specific scripts here
   
   // Set the game's resolution based on device type
   setResolution();

   // This is where the game starts. Right now, we are just starting the first level. You will
   // want to expand this to load up a splash screen followed by a main menu depending on the
   // specific needs of your game. Most likely, a menu button will start the actual game, which
   // is where startGame should be called from.
   startGame( expandFilename($Game::DefaultScene) );
}

//------------------------------------------------------------------------------
// startGame
// All game logic should be set up here. This will be called by the level 
// builder when you select "Run Game" or by the startup process of your game 
// to load the first level.
//------------------------------------------------------------------------------
function startGame(%level)
{
   // Push the parent GUI for the game (found in game/gui/mainScreen.gui)
   Canvas.setContent(mainScreenGui);
   
    // exec game scripts
   exec("./menuCommands.cs");
   
   // Report the time it took to load the game to this point
   %runTime = getRealTime() - $Debug::loadStartTime;
   echo(" % - Game load time : " @ %runTime @ " ms");

   // Create a new ActionMap for input binding
   new ActionMap(moveMap);
   
   // Enable DirectInput for Windows development
   $enableDirectInput = true;
   activateDirectInput();

   // Load the .t2d file for this game
   sceneWindow2D.loadLevel(%level);
   
   // Execute the following code on iOS only
   if($platform $= "iphone" || $platform $= "ipad" || $platform $= "iphone4")
   {
      // Bind core touch reactions to functions
      // Function names are completely up to you
      moveMap.bind(touchdevice, touchdown, "touchesDown");
      moveMap.bind(touchdevice, touchmove, "touchesMove");
      moveMap.bind(touchdevice, touchup, "touchesUp");
      
      // Hide the "mouse" cursor on iOS
      hideCursor();
      
      // Push the moveMap bindings
      moveMap.push();
   }
}

//------------------------------------------------------------------------------
// endGame
// Game cleanup should be done here.
//------------------------------------------------------------------------------
function endGame()
{
   sceneWindow2D.endLevel();
   moveMap.pop();
   moveMap.delete();
}

//------------------------------------------------------------------------------
// oniPhoneResignActive
// Callback sent from the engine when the device has triggered an exit, 
// like pressing the home button. This is where you want to execute emergency 
// code, like game saving, data storage and general cleanup
//------------------------------------------------------------------------------
function oniPhoneResignActive()
{
}

//------------------------------------------------------------------------------
// oniPhoneBecomeActive
// Callback sent from the engine when the device has triggered a resume to app
// This is where you want to execute resume code, like showing a paused screen,
// rescheduling, etc.
//------------------------------------------------------------------------------
function oniPhoneBecomeActive()
{
}

//------------------------------------------------------------------------------
// oniPhoneChangeOrientation
// Callback sent from the engine when the device's orientation has adjusted
//------------------------------------------------------------------------------
function oniPhoneChangeOrientation(%newOrientation)
{
	%new = "Unkown";
	if(%newOrientation == $iOS::constant::OrientationLandscapeLeft)
	{
		%new = "Landscape Left (Home Button on the right)";
	}
	else if(%newOrientation == $iOS::constant::OrientationLandscapeRight)
	{
		%new = "Landscape Right (Home Button on the left)";
	}
	else if(%newOrientation == $iOS::constant::OrientationPortrait)
	{
		%new = "Portrait (Home Button on the bottom)";
	}
	else if(%newOrientation == $iOS::constant::OrientationPortraitUpsideDown)
	{
		%new = "Portrait Upside Down (Home Button on the top)";
	}
		
	echo("newOrientation: " @ %new);
}

//------------------------------------------------------------------------------
// touchesDown
// Called whenever a finger touches the screen, if moveMap is pushed
//
// %touchIDs - List of unique ID numbers, one per-finger
// %touchesX - List of coordinates in the X axis
// %touchesY - List of coordinates in the Y axis
//------------------------------------------------------------------------------
function touchesDown(%touchIDs, %touchesX, %touchesY)
{
   echo("Entered touch down function");

   // How many fingers are down
   %numTouches = getWordCount( %touchIDs );

   // Loop through each finger and print its coordinates
   for(%count = 0; %count < %numTouches; %count++)
   {
      // Finger ID
      %curTouch = getWord( %touchIDs, %count );
      
      // X screen coordinate
      %curX = getWord( %touchesX, %count );
      
      // Y screen coordinate
      %curY = getWord( %touchesY , %count );

      // World position
      %worldPos = sceneWindow2D.getWorldPoint(%curX, %curY);

      // Print results
      echo("Scanning touch " @ curTouch @ " at " @ %worldPos);
   }
}

//------------------------------------------------------------------------------
// touchesMove
// Called whenever a finger drags across the screen, if moveMap is pushed
//
// %touchIDs - List of unique ID numbers, one per-finger
// %touchesX - List of coordinates in the X axis
// %touchesY - List of coordinates in the Y axis
//------------------------------------------------------------------------------
function touchesMove(%touchIDs, %touchesX, %touchesY)
{
   echo("Entered touch move function");

   // How many fingers are down
   %numTouches = getWordCount( %touchIDs );

   // Loop through each finger and print its coordinates
   for(%count = 0; %count < %numTouches; %count++)
   {
      // Finger ID
      %curTouch = getWord( %touchIDs, %count );
      
      // X screen coordinate
      %curX = getWord( %touchesX, %count );
      
      // Y screen coordinate
      %curY = getWord( %touchesY , %count );

      // World position
      %worldPos = sceneWindow2D.getWorldPoint(%curX, %curY);

      // Print results
      echo("Scanning touch " @ curTouch @ " at " @ %worldPos);
   }
}

//------------------------------------------------------------------------------
// touchesUp
// Called whenever a finger is lifted from the screen, if moveMap is pushed
//
// %touchIDs - List of unique ID numbers, one per-finger
// %touchesX - List of coordinates in the X axis
// %touchesY - List of coordinates in the Y axis
//------------------------------------------------------------------------------
function touchesUp(%touchIDs, %touchesX, %touchesY)
{
   echo("Entered touch up function");

   // How many fingers are down
   %numTouches = getWordCount( %touchIDs );

   // Loop through each finger and print its coordinates
   for(%count = 0; %count < %numTouches; %count++)
   {
      // Finger ID
      %curTouch = getWord( %touchIDs, %count );
      
      // X screen coordinate
      %curX = getWord( %touchesX, %count );
      
      // Y screen coordinate
      %curY = getWord( %touchesY , %count );

      // World position
      %worldPos = sceneWindow2D.getWorldPoint(%curX, %curY);

      // Print results
      echo("Scanning touch " @ curTouch @ " at " @ %worldPos);
   }
}

// gravityXFunction
// Called when the user tilts the device
function gravityXFunction(%val)
{
   // Print the value of the gravity shift
   // If the value is outside of the range of the dead zone
   // Only zero will be passed as a value
   if(%val > 0.2)
      echo("Gravity X value: " @ %val);
   else if(%val < -0.2)
      echo("Gravity X value: " @ %val);
}

function gravityYFunction(%val)
{
   // Print the value of the gravity shift
   // If the value is outside of the range of the dead zone
   // Only zero will be passed as a value
   if(%val > 0.2)
      echo("Gravity Y value: " @ %val);
   else if(%val < -0.2)
      echo("Gravity Y value: " @ %val);
}

function pitchFunction(%val)
{
   // Print the value of the pitch shift
   // If the value is outside of the range of the dead zone
   // Only zero will be passed as a value
   if(%val > 0.2)
      echo("Device pitch value: " @ %val);
   else if(%val < -0.2)
      echo("Device pitch value: " @ %val);
}

function yawFunction(%val)
{
   // Print the value of the pitch shift
   // If the value is outside of the range of the dead zone
   // Only zero will be passed as a value
   if(%val > 0.2)
      echo("Device yaw value: " @ %val);
   else if(%val < -0.2)
      echo("Device yaw value: " @ %val);
}

function rollFunction(%val)
{
   // Print the value of the pitch shift
   // If the value is outside of the range of the dead zone
   // Only zero will be passed as a value
   if(%val > 0.2)
      echo("Device roll value: " @ %val);
   else if(%val < -0.2)
      echo("Device roll value: " @ %val);
}