//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

//enableDebugOutput( true );
dbgSetParameters( 6060, "password", false );

//------------------------------------------------------------------------------
// onStart
// This is the startup procedure for this iTorque 2D Project
//------------------------------------------------------------------------------
function onStart()
{
   // Timestamp the initialization process start
   $Debug::loadStartTime = getRealTime();
   
   // System version printout
   echo("\niTorque 2D (" @ getT2DVersion() @ ") initializing...");
   
   // Locate the cached font directory
   $Gui::fontCacheDirectory = expandFilename("data/fonts");
   
   // Load preferences.
   exec("scripts/system/properties.cs");
   
   // Load up helper modules and system
   exec("scripts/system/xml.cs");
   exec("scripts/system/system.cs");
   
   // Exec game scripts.   
   exec("scripts/game.cs");
   
   _defaultGameconfigurationData();
   
   _loadGameConfigurationData();
   
   switch$($platform)
   {
      case "iphone":
         $pref::iOS::DeviceType = $iOS::constant::iPhone;
      case "iphone4":
         $pref::iOS::DeviceType = $iOS::constant::iPhone4;
      case "ipad":
         $pref::iOS::DeviceType = $iOS::constant::iPad;
   }
   
   // Initialize the core systems (canvas, t2dSceneGraph, OpenAL, etc
   if( !isFunction( "initializeSystem" ) )
   {
      messageBox( "Game Startup Error", "'initializeSystem' function could not be found." @
                  "\nThis could indicate a bad or corrupt scripts/system directory for your game." @
                  "\n\nThe Game will now shutdown because it cannot properly function", "Ok", "MIStop" );
      quit();
   }
   
   initializeSystem();
   
   // Initialize project management for game and editor
   if( !isFunction( "initializeGame" ) || !isFunction( "_initializeProject" ) )
   {
      messageBox( "Game Startup Error", "'initializeGame'  or '_initializeProject' functions could not be found." @
                  "\nThis could indicate a system directory for your game." @
                  "\n\nThe Game will now shutdown because it cannot properly function", "Ok", "MIStop" );
      quit();
   }
   
   // Responsible for loading behaviors, datablocks, brushes, etc
   _initializeProject();

   // Load up the in-game gui.
   // Size and orientation will be set in initializeGame()
   exec("gui/mainScreen.gui");
   
   // Startup the game project
   initializeGame();
}

function onExit()
{
   if($platform $= "windows" || $platform $= "macos")
      _saveGameConfigurationData();
}

// Output a console log
setLogMode(6);

//----------------------------
// BEGIN GAME START UP PROCESS
//----------------------------
onStart();
