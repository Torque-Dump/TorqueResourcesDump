function twillexUpdate(%twill)
{
   if(isObject(%twill))
   {
      myTweenEngine.onUpdate();
      schedule(32, 0, twillexUpdate, myTweenEngine);
   }
}

exec("./Twillex.cs");
Twillex::create(myTweenEngine);
twillexUpdate(myTweenEngine);