//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

#ifndef _PARTICLEEMITTERDUMMY_H_
#define _PARTICLEEMITTERDUMMY_H_

#ifndef _GAMEBASE_H_
#include "T3D/gameBase/gameBase.h"
#endif

class ParticleEmitterData;
class ParticleEmitter;

//*****************************************************************************
// ParticleEmitterNodeData
//*****************************************************************************
class ParticleEmitterNodeData : public GameBaseData
{
   typedef GameBaseData Parent;

  protected:
   bool onAdd();

   //-------------------------------------- Console set variables
  public:
   F32 timeMultiple;

   //-------------------------------------- load set variables
  public:

  public:
   ParticleEmitterNodeData();
   ~ParticleEmitterNodeData();

   void packData(BitStream*);
   void unpackData(BitStream*);
   bool preload(bool server, String &errorStr);

   DECLARE_CONOBJECT(ParticleEmitterNodeData);
   static void initPersistFields();
};


//*****************************************************************************
// ParticleEmitterNode
//*****************************************************************************
class ParticleEmitterNode : public GameBase
{
   typedef GameBase Parent;

   enum MaskBits
   {
      StateMask      = Parent::NextFreeMask << 0,
      EmitterDBMask  = Parent::NextFreeMask << 1,
      NextFreeMask   = Parent::NextFreeMask << 2,
	  emitterEdited	 = Parent::NextFreeMask << 3,
   };

  private:
   ParticleEmitterNodeData* mDataBlock;

  protected:
   bool onAdd();
   void onRemove();
   bool onNewDataBlock( GameBaseData *dptr, bool reload );
   void inspectPostApply();

   void ParticleEmitterNode::onStaticModified(const char* slotName, const char*newValue);
   void ParticleEmitterNode::onDynamicModified(const char* slotName, const char*newValue);

   ParticleEmitterData* mEmitterDatablock;
   S32                  mEmitterDatablockId;

   bool             mActive;

   SimObjectPtr<ParticleEmitter> mEmitter;
   F32              mVelocity;

  public:

	//------------------------- Stand alone variables
   bool standAloneEmitter;
   S32   sa_ejectionPeriodMS;                   ///< Time, in Milliseconds, between particle ejection
   S32   sa_periodVarianceMS;                   ///< Varience in ejection peroid between 0 and n

   F32   sa_ejectionVelocity;                   ///< Ejection velocity
   F32   sa_velocityVariance;                   ///< Variance for velocity between 0 and n
   F32   sa_ejectionOffset;                     ///< Z offset from emitter point to eject from

   F32   sa_thetaMin;                           ///< Minimum angle, from the horizontal plane, to eject from
   F32   sa_thetaMax;                           ///< Maximum angle, from the horizontal plane, to eject from

   F32   sa_phiReferenceVel;                    ///< Reference angle, from the verticle plane, to eject from
   F32   sa_phiVariance;                        ///< Varience from the reference angle, from 0 to n

   ParticleEmitterNode();
   ~ParticleEmitterNode();
   
   ParticleEmitter *getParticleEmitter() {return mEmitter;}
   
   // Time/Move Management
  public:
   void processTick(const Move* move);
   void advanceTime(F32 dt);

   DECLARE_CONOBJECT(ParticleEmitterNode);
   static void initPersistFields();

   U32  packUpdate  (NetConnection *conn, U32 mask, BitStream* stream);
   void unpackUpdate(NetConnection *conn,           BitStream* stream);

   inline bool getActive( void )        { return mActive;                             };
   inline void setActive( bool active ) { mActive = active; setMaskBits( StateMask ); };

   void setEmitterDataBlock(ParticleEmitterData* data);
};

#endif // _H_PARTICLEEMISSIONDUMMY

