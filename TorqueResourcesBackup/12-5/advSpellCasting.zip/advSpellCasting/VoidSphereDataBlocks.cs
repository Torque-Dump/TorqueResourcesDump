datablock ParticleData(voidParticle : DefaultParticle)
{
   inheritedVelFactor = "0";
   textureName = "art/shapes/particles/ember.png";
   animTexName = "art/shapes/particles/ember.png";
   colors[0] = "0.160784 0.0392157 0.203922 1";
   colors[1] = "0.666667 0.0980392 0.815686 0.573";
   colors[2] = "0.454902 0.00392157 0.607843 1";
   colors[3] = "0.792157 0 1 0";
   sizes[0] = "1.04167";
   sizes[1] = "3.125";
   sizes[2] = "2.08333";
   sizes[3] = "2.08333";
   times[0] = "0.145833";
   times[1] = "0.291667";
   lifetimeMS = "563";
   lifetimeVarianceMS = "562";
};

datablock ParticleEmitterData(voidSphereEmitter : DefaultEmitter)
{
   particles = "voidParticle";
   ejectionPeriodMS = "1";
   ejectionVelocity = "0";
   ejectionOffset = "5";
   thetaMax = "0";
   blendStyle = "NORMAL";
   softnessDistance = "1";
};