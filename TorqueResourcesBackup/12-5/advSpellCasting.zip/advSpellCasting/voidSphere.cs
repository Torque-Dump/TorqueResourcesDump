//Advanced spell script 1
   new ScriptObject( voidSphere ){
      superClass = Spell;
      type = "AOE";
      raytype = "point";
   };
   spells.add(voidSphere);

function getvoidSphereScriptObject()
{
   return voidSphere;
}
//4143
function voidSphere::Cast(%this, %pos, %trans, %path, %team, %client)
{
   if(%pos $= ""){
      error("No pos on Rogue::Cast");
      return false;
   }
   if(%trans $= ""){
      error("No trans on Rogue::Cast");
      return false;
   }
   if(%team $= ""){
      error("No team on Rogue::Cast");
      return false;
   }
   //assignPersistentId
   %newEmitter = new ParticleEmitterNode(){
      position = %pos;
      rotation = "1 0 0 0";
      scale = "1 1 1 1";
      dataBlock = broadNode;
      emitter = voidSphereEmitter;
      velocity = 1;
      standAloneEmitter = 1;
      //sa_ejectionPeriodMS = "1";
      //sa_ejectionVelocity = "0";
      //sa_ejectionOffset = "5";
      //sa_thetaMax = "0";
   };
   %p1 = MyTweenEngine.to(1500, %newEmitter, "sa_phiVariance:230", "");
   %p2 = MyTweenEngine.to(1000, %newEmitter, "sa_ejectionOffset:0", "");
   //%p3 = MyTweenEngine.to(2000, testEmitter.emitter, "ejectionVelocity:2", "");

   %p1.tweenData.onComplete = %p2@".play";
   %p2.tweenData.onComplete = %newEmitter@".delete";
   //%p2.tweenData.onComplete = "$p3.play";   
   
   %p1.play();
   
   radiusDamage(%col, %pos, 2.5, 20, "Projectile", 0);
   commandToClient(%client, 'BeginCast', 2000, 1);

   return %bullet;
}
