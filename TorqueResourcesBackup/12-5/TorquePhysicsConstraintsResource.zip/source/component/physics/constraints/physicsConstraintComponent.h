//
// Copyright (c) 2012 Simon Wittenberg simon_wittenberg@gmx.net
//             and   Lethal Concept, LLC
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//
#ifndef _PHYSICS_CONSTRAINT_COMPONENT_H_
#define _PHYSICS_CONSTRAINT_COMPONENT_H_

#include "T3D/physics/physicsConstraint.h"
#include "component/physics/physicsComponent.h"

class PhysicsConstraintComponent : public GameComponent
{
public:
    PhysicsConstraintComponent(String typeString = "PhysicsGizmo", String nameString = "Constraint", S32 maxInstances = 0);
    ~PhysicsConstraintComponent();

    DECLARE_CONOBJECT(PhysicsConstraintComponent);
    typedef GameComponent Parent;

    static void initPersistFields();
    virtual bool onAdd();
    virtual void onRemove();
    virtual bool serialize(BitStream *stream);
    virtual bool deserialize(BitStream *stream);
    virtual bool initComponent();
    virtual bool deinitComponent();


    void onInitialization(bool init, PhysicsComponent* physCmp);

    void setEnabled( bool enabled )
    {
        bool before = mConstraintEnabled;
        mConstraintEnabled = enabled;
        if(mConstraint)
            mConstraint->setEnabled(enabled);
        onEnabled(mConstraintEnabled, before);
    };
    void setLimits(F32* lowLin = NULL, F32* highLin = NULL, F32* lowAng = NULL, F32* highAng = NULL, U32 idx = 0)
    {
        RETURN_VOID_UNLESS(idx < 3)
        if(lowLin)  mLowerLinearLimit[idx]   = *lowLin;
        if(highLin) mUpperLinearLimit[idx]   = *highLin;
        if(lowAng)  mLowerAngularLimit[idx]  = *lowAng;
        if(highAng) mUpperAngularLimit[idx]  = *highAng;

        if(mConstraint)
            mConstraint->setLimits(lowLin, highLin, lowAng, highAng, idx);
    }
    void setLinearMotorEnabled(bool enabled, U32 idx = 0)
    {
        RETURN_VOID_UNLESS(idx < 3)
        mConstraintLinearMotorEnabled[idx] = enabled;
        if(mConstraint)
            mConstraint->enableLinearMotor(enabled, idx);
    };
    void setAngularMotorEnabled(bool enabled, U32 idx = 0)
    {
        RETURN_VOID_UNLESS(idx < 3)
        mConstraintAngularMotorEnabled[idx] = enabled;
        if(mConstraint)
            mConstraint->enableAngularMotor(enabled, idx);
    };
    void setMaxLinearMotorForce(F32 max, U32 idx = 0)
    {
        RETURN_VOID_UNLESS(idx < 3)
        mConstraintLinearMotorMaxForce[idx] = max;
        if(mConstraint)
            mConstraint->setLinearMotorMaxForce(max, idx);
    };
    void setMaxAngularMotorForce(F32 max, U32 idx = 0)
    {
        RETURN_VOID_UNLESS(idx < 3)
        mConstraintAngularMotorMaxForce[idx] = max;
        if(mConstraint)
            mConstraint->setAngularMotorMaxForce(max, idx);
    };
    void setBreakingImuplseThreshold(F32 threshold)
    {
        mConstraintBreakingImuplseThreshold = threshold;
        if(mConstraint)
            mConstraint->setBreakingImpulseThreshold(mConstraintBreakingImuplseThreshold);
    };
    void setLinearSoftness(Point3F linSoft)
    {
        mConstraintLinearSoftness = linSoft;
        if(mConstraint)
        {
            for(U32 i = 0; i < 3; i++)
                mConstraint->setSoftness(mConstraintLinearSoftness[i], i);
        }
    };
    void setAngularSoftness(Point3F angSoft)
    {
        mConstraintAngularSoftness = angSoft;
        if(mConstraint)
        {
            for(U32 i = 0; i < 3; i++)
                mConstraint->setSoftness(mConstraintAngularSoftness[i], i+3);
        }
    };
    void setLinearMotorSpeed(F32 speed, U32 idx = 0)
    {
        RETURN_VOID_UNLESS(idx < 3)
        if(mConstraint)
            mConstraint->setLinearMotorSpeed(speed, idx);
    };
    Point3F getLinearMotorSpeed()
    {
        Point3F returnSpeed = Point3F::Zero;

        if(mConstraint)
            returnSpeed = mConstraint->getLinearMotorSpeed();

        return returnSpeed;
    };
    void setAngularMotorSpeed(F32 speed, U32 idx = 0)
    {
        RETURN_VOID_UNLESS(idx < 3)
        if(mConstraint)
            mConstraint->setAngularMotorSpeed(speed, idx);
    };
    Point3F getAngularMotorSpeed()
    {
        Point3F returnSpeed = Point3F::Zero;

        if(mConstraint)
            returnSpeed = mConstraint->getAngularMotorSpeed();

        return returnSpeed;
    };
    void setAxis(Point3F axis, U32 idx = 0, Point3F* otherAxis = NULL)
    {
        RETURN_VOID_UNLESS(idx < 3)
        mConstraintAxis[idx] = axis;
        if(mConstraint)
            mConstraint->setAxis(axis, idx);
    };

protected:
    virtual void registerInterfacesTo(GameComponent* root);

    virtual void onEnabled(bool now, bool before){AssertFatal(0, "Never call this.");};

    PhysicsConstraint::PHYSICS_CONSTRAINT_TYPE mConstraintType;
    PhysicsConstraint* mConstraint;

    // General
    bool mConstraintEnabled;
    bool mConstraintAngularMotorEnabled[3];
    bool mConstraintLinearMotorEnabled[3];
    F32 mConstraintLinearMotorMaxForce[3];
    F32 mConstraintAngularMotorMaxForce[3];
    F32 mConstraintBreakingImuplseThreshold;
    Point3F mConstraintAxis[3];
    Point3F mConstraintAngularSoftness;
    Point3F mConstraintLinearSoftness;
    Point3F mLowerLinearLimit;
    Point3F mUpperLinearLimit;
    Point3F mLowerAngularLimit;
    Point3F mUpperAngularLimit;


    static bool setFieldConstraintEnabled( void *component, const char *index, const char *data );
    static bool setFieldMaxLinearForce( void *component, const char *index, const char *data );
    static bool setFieldMaxAngularForce( void *component, const char *index, const char *data );
    static bool setFieldEnableLinearMotor( void *component, const char *index, const char *data );
    static bool setFieldEnableAngularMotor( void *component, const char *index, const char *data );
    static bool setFieldConstraintBreakingImuplseThreshold( void *component, const char *index, const char *data );
    static bool setFieldLinearSpeed( void *component, const char *index, const char *data );
    static const char* getFieldLinearSpeed( void *object, const char *data );
    static bool setFieldAngularSpeed( void *component, const char *index, const char *data );
    static const char* getFieldAngularSpeed( void *object, const char *data );
    


private:
};

#endif // _PHYSICS_CONSTRAINT_COMPONENT_H_
