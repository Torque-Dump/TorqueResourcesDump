//
// Copyright (c) 2012 Simon Wittenberg simon_wittenberg@gmx.net
//             and   Lethal Concept, LLC
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef _PHYSICS_CONE_TWIST_CONSTRAINT_COMPONENT_H_
#define _PHYSICS_CONE_TWIST_CONSTRAINT_COMPONENT_H_
#include "physicsConstraintcomponent.h"

class PhysicsConeTwistConstraintComponent : public PhysicsConstraintComponent
{
public:
    PhysicsConeTwistConstraintComponent(String typeString = "PhysicsGizmo", String nameString = "ConeTwistConstraint", S32 maxInstances = 0);
    ~PhysicsConeTwistConstraintComponent();

    DECLARE_CONOBJECT(PhysicsConeTwistConstraintComponent);
    typedef PhysicsConstraintComponent Parent;

    static void initPersistFields();
    virtual bool onAdd();
    virtual void onRemove();
    virtual bool serialize(BitStream *stream);
    virtual bool deserialize(BitStream *stream);
    virtual bool initComponent();
    virtual bool deinitComponent();

protected:
    virtual void registerInterfacesTo(GameComponent* root);

    virtual void onEnabled(bool now, bool before);

    static bool setFieldTwistSpan( void *component, const char *index, const char *data );
    static bool setFieldSwingSpan1( void *component, const char *index, const char *data );
    static bool setFieldSwingSpan2( void *component, const char *index, const char *data );
    static bool setFieldMotorTarget( void *component, const char *index, const char *data );
};

#endif // _PHYSICS_CONE_TWIST_CONSTRAINT_COMPONENT_H_
