//
// Copyright (c) 2012 Simon Wittenberg simon_wittenberg@gmx.net
//             and   Lethal Concept, LLC
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//
#include "PhysicsConstraintComponent.h"
#include "T3D/physics/physicscommon.h"
#include "T3D/physics/physicsPlugin.h"
#include "T3D/physics/physicsBody.h"
#include "T3D/physics/physicsWorld.h"
#include "T3D/physics/physicsCollision.h"


IMPLEMENT_CO_NETOBJECT_V1(PhysicsConstraintComponent);


PhysicsConstraintComponent::PhysicsConstraintComponent(String typeString /*= "PhysicsGizmo"*/, String nameString/* = "Constraint"*/, S32 maxInstances /*= 0*/)
:GameComponent(typeString, nameString, GameComponents::PHYSICS_GIZMO_TYPE, maxInstances)
{
    mConstraint = NULL;
    mConstraintType = PhysicsConstraint::NO_CONSTRAINT;

    mConstraintEnabled = true;
    mConstraintBreakingImuplseThreshold = 0; // 0 makes it unbreakable. or really hard to break

    for(U32 i = 0; i < 3; i++)
    {
        mConstraintAngularMotorEnabled[i]  = false;
        mConstraintLinearMotorEnabled[i]  = false;
        mConstraintLinearMotorMaxForce[i] = 0.0f;
        mConstraintAngularMotorMaxForce[i]  = 0.0f;
    }

    mConstraintAxis[0].set(0.0f, 0.0f, 1.0f);
    mConstraintAxis[1].set(0.0f, 1.0f, 0.0f);
    mConstraintAxis[2].set(1.0f, 0.0f, 0.0f);

    mConstraintAngularSoftness.set(0);
    mConstraintLinearSoftness.set(0);
    mLowerLinearLimit.set(0);
    mUpperLinearLimit.set(0);
    mLowerAngularLimit.set(0);
    mUpperAngularLimit.set(0);
}
PhysicsConstraintComponent::~PhysicsConstraintComponent()
{

}

void PhysicsConstraintComponent::initPersistFields()
{
    addGroup( "Constraint",NULL, AbstractClassRep::FIELD_PreviewGroup);

    
    addProtectedField( "constraintEnabled", TypeBool, Offset( mConstraintEnabled, PhysicsConstraintComponent ),
        &setFieldConstraintEnabled, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    addProtectedField( "breakingImpulseThreshold", TypeF32, Offset( mConstraintBreakingImuplseThreshold, PhysicsConstraintComponent ),
        &setFieldConstraintBreakingImuplseThreshold, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    addProtectedField( "maxLinearMotorForce", TypePoint3F, Offset( mConstraintLinearMotorMaxForce, PhysicsConstraintComponent ),
        &setFieldMaxLinearForce, &defaultProtectedGetFn, 
        "TODO: Write Doc" );
    addProtectedField( "maxAngularMotorForce", TypePoint3F, Offset( mConstraintAngularMotorMaxForce, PhysicsConstraintComponent ),
        &setFieldMaxAngularForce, &defaultProtectedGetFn, 
        "TODO: Write Doc" );
    addArray("Motor De/Activation", 3/*MagicNumber!*/);
        addProtectedField( "enableAngularMotor", TypeBool, Offset( mConstraintAngularMotorEnabled, PhysicsConstraintComponent ),
            &setFieldEnableAngularMotor, &defaultProtectedGetFn, 3/*MagicNumber!*/,
            "TODO: Write Doc" );
        addProtectedField( "enableLinearMotor", TypeBool, Offset( mConstraintLinearMotorEnabled, PhysicsConstraintComponent ),
            &setFieldEnableLinearMotor, &defaultProtectedGetFn, 3/*MagicNumber!*/,
            "TODO: Write Doc" );
    endArray("Motor De/Activation");

    addProtectedField( "linearSpeed", TypePoint3F, NULL,
        &setFieldLinearSpeed, &getFieldLinearSpeed, 
        "TODO: Write Doc" );
    addProtectedField( "angularSpeed", TypePoint3F, NULL,
        &setFieldAngularSpeed, &getFieldAngularSpeed, 
        "TODO: Write Doc" );

    endGroup("Constraint");
    Parent::initPersistFields();
}

bool PhysicsConstraintComponent::onAdd()
{
    RETURN_FALSE_UNLESS(Parent::onAdd())

    return true;
}
void PhysicsConstraintComponent::onRemove()
{
    Parent::onRemove();
}
bool PhysicsConstraintComponent::serialize(BitStream *stream)
{
    RETURN_FALSE_UNLESS(Parent::serialize(stream))

    return true;
}
bool PhysicsConstraintComponent::deserialize(BitStream *stream)
{
    RETURN_FALSE_UNLESS(Parent::deserialize(stream))

    return true;
}
bool PhysicsConstraintComponent::initComponent()
{
    RETURN_FALSE_UNLESS(mConstraintType != PhysicsConstraint::NO_CONSTRAINT)

    RETURN_FALSE_UNLESS(Parent::initComponent())

    PhysicsComponent* localPhysCmp = getParent<PhysicsComponent>();
    RETURN_FALSE_UNLESS_EXISTS(localPhysCmp)
    
    localPhysCmp->getInitializationSignal().notify(this, &PhysicsConstraintComponent::onInitialization);


    if(localPhysCmp->isPassiveMode())
        return true;

    
    GET_SPATIAL_PARENT_CHECK_FALSE_FROM(localPhysCmp, parentSpat)

    if(mConstraint)
        mConstraint->deinit();
    SAFE_DELETE(mConstraint);

    
    if(parentSpat->isSubSpatial())
    {
        SpatialComponent* grandParentSpat = parentSpat->getParent<SpatialComponent>();
        AssertFatal(grandParentSpat, "Parent of Spatial is not Spatial! Something ain't right!");

        PhysicsComponent* parentPhysicsCmp = NULL;
        grandParentSpat->findComponent(parentPhysicsCmp);
        if(parentPhysicsCmp)
        {
            MatrixF mountTransform = parentPhysicsCmp->getMountTransform(0);
            MatrixF mountedTransform = parentSpat->getLocalWorldTransform();
            mConstraint = PHYSICSMGR->createConstraint();
            if(mConstraint)
            {
                for(U32 i = 0; i < 3; i++)
                {
                    mConstraint->setAngularMotorMaxForce(mConstraintAngularMotorMaxForce[i], i);
                    mConstraint->setLinearMotorMaxForce(mConstraintLinearMotorMaxForce[i], i);
                    mConstraint->enableAngularMotor(mConstraintAngularMotorEnabled[i], i);
                    mConstraint->enableLinearMotor(mConstraintLinearMotorEnabled[i], i);
                    mConstraint->setAxis(mConstraintAxis[i], i);
                    mConstraint->setSoftness(mConstraintLinearSoftness[i], i);
                    mConstraint->setSoftness(mConstraintAngularSoftness[i], i+3);
                    mConstraint->setLimits(&mLowerLinearLimit[i], &mUpperLinearLimit[i], &mLowerAngularLimit[i], &mUpperAngularLimit[i], i);
                }
                mConstraint->setBreakingImpulseThreshold(mConstraintBreakingImuplseThreshold);

                PhysicsBody *parentBody = parentPhysicsCmp->getPhysicsRep(), *localBody = localPhysCmp->getPhysicsRep();
                if(mConstraint->init(localBody->getWorld(), mConstraintType, parentBody, localBody,
                        &mountTransform, &mountedTransform))
                {
                    parentPhysicsCmp->getInitializationSignal().notify(this, &PhysicsConstraintComponent::onInitialization);
#ifdef PHYSICS_CONSTRAINTS_DEBUG_SPEW
                    Con::errorf(":::::::::::::: CONSTRAINT INITIALIZED SUCCESSFULLY! ::::::::::::::");
#endif
                    return true;
                }
            }
        }
#ifdef PHYSICS_CONSTRAINTS_DEBUG_SPEW
        Con::errorf(":::::::::::::: CONSTRAINT CREATION FAILED ! ::::::::::::::");
#endif
        return false;
    }
#ifdef PHYSICS_CONSTRAINTS_DEBUG_SPEW
    Con::errorf(":::::::::::::: CONSTRAINT FOUND NO PHYSICS PARENT! ::::::::::::::");
#endif
    return true;
}


bool PhysicsConstraintComponent::deinitComponent()
{
    RETURN_FALSE_UNLESS(Parent::deinitComponent())

    if(mConstraint)
    {
        PhysicsBody *A = NULL, *B = NULL;
        mConstraint->getPhysicsBodies(A, B);
        if(A)
        {
            PhysicsComponent* cmpA = A->getUserData().getObject();
            cmpA->getInitializationSignal().remove(this, &PhysicsConstraintComponent::onInitialization);
        }
        if(B)
        {
            PhysicsComponent* cmpB = B->getUserData().getObject();
            cmpB->getInitializationSignal().remove(this, &PhysicsConstraintComponent::onInitialization);
        }
        mConstraint->deinit();
    }
    SAFE_DELETE(mConstraint);

    return true;
}

void PhysicsConstraintComponent::onInitialization(bool init, PhysicsComponent* physCmp)
{
    RETURN_VOID_UNLESS_EXISTS(physCmp)
    PhysicsComponent* localPhysCmp = getParent<PhysicsComponent>();
    RETURN_VOID_UNLESS_EXISTS(localPhysCmp) // bail out if we are not child of a physicsComponent

    PhysicsComponent* localParentPhysCmp = localPhysCmp->getPhysicsParent();
    
    // this must come from either our very own physics component or its parent
    RETURN_VOID_UNLESS( (localParentPhysCmp == physCmp ) || ( localPhysCmp == physCmp) ) 

    deinitComponent();
    if(init)
        initComponent();
}

void PhysicsConstraintComponent::registerInterfacesTo(GameComponent* root)
{
    RETURN_VOID_UNLESS_EXISTS(root)
    Parent::registerInterfacesTo(root);
}

bool PhysicsConstraintComponent::setFieldConstraintEnabled( void *component, const char *index, const char *data )
{
    PhysicsConstraintComponent* constrCmp = static_cast<PhysicsConstraintComponent*>( component );
    if(constrCmp)
    {
        bool enabled;
        Con::setData( TypeBool, &enabled, 0, 1, &data );
        constrCmp->setEnabled(enabled);
    }
    return false;
}

bool PhysicsConstraintComponent::setFieldMaxLinearForce( void *component, const char *index, const char *data )
{
    PhysicsConstraintComponent* constrCmp = static_cast<PhysicsConstraintComponent*>( component );
    if(constrCmp)
    {
        F32 force;
        Con::setData( TypeF32, &force, 0, 1, &data );
        constrCmp->setMaxLinearMotorForce(force);
    }
    return false;
}
bool PhysicsConstraintComponent::setFieldMaxAngularForce( void *component, const char *index, const char *data )
{
    PhysicsConstraintComponent* constrCmp = static_cast<PhysicsConstraintComponent*>( component );
    if(constrCmp)
    {
        F32 force;
        Con::setData( TypeF32, &force, 0, 1, &data );
        constrCmp->setMaxAngularMotorForce(force);
    }
    return false;
}
bool PhysicsConstraintComponent::setFieldEnableLinearMotor( void *component, const char *index, const char *data )
{
    PhysicsConstraintComponent* constrCmp = static_cast<PhysicsConstraintComponent*>( component );
    if(constrCmp)
    {
        bool enabled;
        Con::setData( TypeBool, &enabled, 0, 1, &data );
        U32 idx;
        Con::setData( TypeU32, &idx, 0, 1, &index );
        constrCmp->setLinearMotorEnabled(enabled, idx);
    }
    return false;
}
bool PhysicsConstraintComponent::setFieldEnableAngularMotor( void *component, const char *index, const char *data )
{
    PhysicsConstraintComponent* constrCmp = static_cast<PhysicsConstraintComponent*>( component );
    if(constrCmp)
    {
        bool enabled;
        Con::setData( TypeBool, &enabled, 0, 1, &data );
        U32 idx;
        Con::setData( TypeU32, &idx, 0, 1, &index );
        constrCmp->setAngularMotorEnabled(enabled, idx);
    }
    return false;
}

bool PhysicsConstraintComponent::setFieldConstraintBreakingImuplseThreshold( void *component, const char *index, const char *data )
{
    PhysicsConstraintComponent* constrCmp = static_cast<PhysicsConstraintComponent*>( component );
    if(constrCmp)
    {
        F32 breakImpulse;
        Con::setData( TypeF32, &breakImpulse, 0, 1, &data );
        constrCmp->setBreakingImuplseThreshold(breakImpulse);
    }
    return false;
}

bool PhysicsConstraintComponent::setFieldLinearSpeed( void *object, const char *index, const char *data )
{
   PhysicsConstraintComponent* constrCmp = static_cast<PhysicsConstraintComponent*>( object );
   if ( constrCmp )
   {
      Point3F speed;
      Con::setData( TypePoint3F, &speed, 0, 1, &data );
      for(U32 i=0; i<3; i++)
        constrCmp->setLinearMotorSpeed(speed[i], i);
   }
   return false;
}

const char *PhysicsConstraintComponent::getFieldLinearSpeed( void *object, const char *data )
{
    PhysicsConstraintComponent* constrCmp = static_cast<PhysicsConstraintComponent*>( object );
    if ( constrCmp )
    {
        Point3F speed = constrCmp->getLinearMotorSpeed();
        char buf[64];
        dSprintf( buf, sizeof( buf ), "%g %g %g", speed.x, speed.y, speed.z );
        char* returnString = Con::getReturnBuffer( dStrlen( buf ) + 1 );
        dStrcpy( returnString, buf );
        
        return( returnString );
    }
    else
        return "0 0 0";
}


bool PhysicsConstraintComponent::setFieldAngularSpeed( void *object, const char *index, const char *data )
{
   PhysicsConstraintComponent* constrCmp = static_cast<PhysicsConstraintComponent*>( object );
   if ( constrCmp )
   {
      Point3F speed;
      Con::setData( TypePoint3F, &speed, 0, 1, &data );
      for(U32 i=0; i<3; i++)
        constrCmp->setAngularMotorSpeed(speed[i], i);
   }
   return false;
}

const char *PhysicsConstraintComponent::getFieldAngularSpeed( void *object, const char *data )
{
    PhysicsConstraintComponent* constrCmp = static_cast<PhysicsConstraintComponent*>( object );
    if ( constrCmp )
    {
        Point3F speed = constrCmp->getAngularMotorSpeed();
        char buf[64];
        dSprintf( buf, sizeof( buf ), "%g %g %g", speed.x, speed.y, speed.z );
        char* returnString = Con::getReturnBuffer( dStrlen( buf ) + 1 );
        dStrcpy( returnString, buf );
        
        return( returnString );
    }
    else
        return "0 0 0";
}