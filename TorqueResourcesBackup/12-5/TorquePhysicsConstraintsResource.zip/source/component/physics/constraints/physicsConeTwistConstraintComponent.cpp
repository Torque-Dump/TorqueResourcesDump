//
// Copyright (c) 2012 Simon Wittenberg simon_wittenberg@gmx.net
//             and   Lethal Concept, LLC
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//
#include "PhysicsConeTwistConstraintComponent.h"


IMPLEMENT_CO_NETOBJECT_V1(PhysicsConeTwistConstraintComponent);


PhysicsConeTwistConstraintComponent::PhysicsConeTwistConstraintComponent(String typeString /*= "PhysicsGizmo"*/, String nameString/* = "ConeTwistConstraint"*/, S32 maxInstances /*= 0*/)
:PhysicsConstraintComponent(typeString, nameString, maxInstances)
{
    mConstraintType = PhysicsConstraint::CONE_TWIST_CONSTRAINT;
    mLowerAngularLimit.set(0);
    mUpperAngularLimit.set(0);
}
PhysicsConeTwistConstraintComponent::~PhysicsConeTwistConstraintComponent()
{

}

void PhysicsConeTwistConstraintComponent::initPersistFields()
{
    addGroup( "Cone Twist Constraint",NULL, AbstractClassRep::FIELD_PreviewGroup);

    addProtectedField( "twistSpan", TypeF32, Offset( mLowerAngularLimit[0], PhysicsConeTwistConstraintComponent ),
        &setFieldTwistSpan, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    addProtectedField( "swingSpan1", TypeF32, Offset( mLowerAngularLimit[1], PhysicsConeTwistConstraintComponent ),
        &setFieldSwingSpan1, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    addProtectedField( "swingSpan2", TypeF32, Offset( mLowerAngularLimit[2], PhysicsConeTwistConstraintComponent ),
        &setFieldSwingSpan2, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    addProtectedField( "coneTwistMotorTarget", TypePoint3F, Offset( mUpperAngularLimit, PhysicsConeTwistConstraintComponent ),
        &setFieldMotorTarget, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    endGroup("Cone Twist Constraint");
    Parent::initPersistFields();


}
bool PhysicsConeTwistConstraintComponent::onAdd()
{
    RETURN_FALSE_UNLESS(Parent::onAdd())

    return true;
}
void PhysicsConeTwistConstraintComponent::onRemove()
{
    Parent::onRemove();
}
bool PhysicsConeTwistConstraintComponent::serialize(BitStream *stream)
{
    RETURN_FALSE_UNLESS(Parent::serialize(stream))

    return true;
}
bool PhysicsConeTwistConstraintComponent::deserialize(BitStream *stream)
{
    RETURN_FALSE_UNLESS(Parent::deserialize(stream))

    return true;
}
bool PhysicsConeTwistConstraintComponent::initComponent()
{
    RETURN_FALSE_UNLESS(Parent::initComponent())

    return true;
}
bool PhysicsConeTwistConstraintComponent::deinitComponent()
{
    RETURN_FALSE_UNLESS(Parent::deinitComponent())

    return true;

}
void PhysicsConeTwistConstraintComponent::registerInterfacesTo(GameComponent* root)
{
    RETURN_VOID_UNLESS_EXISTS(root)
    Parent::registerInterfacesTo(root);
}

void PhysicsConeTwistConstraintComponent::onEnabled(bool now, bool before)
{
}

bool PhysicsConeTwistConstraintComponent::setFieldTwistSpan( void *component, const char *index, const char *data )
{
    PhysicsConeTwistConstraintComponent* constrCmp = static_cast<PhysicsConeTwistConstraintComponent*>( component );
    if(constrCmp)
    {
        F32 twist;
        Con::setData( TypeF32, &twist, 0, 1, &data );
        constrCmp->setLimits(NULL, NULL, &twist, NULL, 0);
    }
    return false;
}

bool PhysicsConeTwistConstraintComponent::setFieldSwingSpan1( void *component, const char *index, const char *data )
{
    PhysicsConeTwistConstraintComponent* constrCmp = static_cast<PhysicsConeTwistConstraintComponent*>( component );
    if(constrCmp)
    {
        F32 swing1;
        Con::setData( TypeF32, &swing1, 0, 1, &data );
        constrCmp->setLimits(NULL, NULL, &swing1, NULL, 1);
    }
    return false;
}

bool PhysicsConeTwistConstraintComponent::setFieldSwingSpan2( void *component, const char *index, const char *data )
{
    PhysicsConeTwistConstraintComponent* constrCmp = static_cast<PhysicsConeTwistConstraintComponent*>( component );
    if(constrCmp)
    {
        F32 swing2;
        Con::setData( TypeF32, &swing2, 0, 1, &data );
        constrCmp->setLimits(NULL, NULL, &swing2, NULL, 2);
    }
    return false;
}

bool PhysicsConeTwistConstraintComponent::setFieldMotorTarget( void *component, const char *index, const char *data )
{
    PhysicsConeTwistConstraintComponent* constrCmp = static_cast<PhysicsConeTwistConstraintComponent*>( component );
    if(constrCmp)
    {
        Point3F motorTarget;
        Con::setData( TypePoint3F, &motorTarget, 0, 1, &data );
        for(U32 i = 0; i < 3; i++)
            constrCmp->setLimits(NULL, NULL, NULL, &motorTarget[i], i);
    }
    return false;
}
