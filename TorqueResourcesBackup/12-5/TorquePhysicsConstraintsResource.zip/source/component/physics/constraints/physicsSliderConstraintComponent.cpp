//
// Copyright (c) 2012 Simon Wittenberg simon_wittenberg@gmx.net
//             and   Lethal Concept, LLC
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//
#include "PhysicsSliderConstraintComponent.h"


IMPLEMENT_CO_NETOBJECT_V1(PhysicsSliderConstraintComponent);


PhysicsSliderConstraintComponent::PhysicsSliderConstraintComponent(String typeString /*= "PhysicsGizmo"*/, String nameString/* = "SliderConstraint"*/, S32 maxInstances /*= 0*/)
:PhysicsConstraintComponent(typeString, nameString, maxInstances)
{
    mConstraintType = PhysicsConstraint::SLIDER_CONSTRAINT;
}
PhysicsSliderConstraintComponent::~PhysicsSliderConstraintComponent()
{

}

void PhysicsSliderConstraintComponent::initPersistFields()
{
    addGroup( "Slider Constraint",NULL, AbstractClassRep::FIELD_PreviewGroup);

    addProtectedField( "linearLimitLow", TypeF32, Offset( mLowerLinearLimit[0], PhysicsSliderConstraintComponent ),
        &setFieldLinearLimitLow, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    addProtectedField( "linearLimitHigh", TypeF32, Offset( mUpperLinearLimit[0], PhysicsSliderConstraintComponent ),
        &setFieldLinearLimitHigh, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    addProtectedField( "angularLimitLow", TypeF32, Offset( mLowerAngularLimit[0], PhysicsSliderConstraintComponent ),
        &setFieldAngularLimitLow, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    addProtectedField( "angularLimitHigh", TypeF32, Offset( mUpperAngularLimit[0], PhysicsSliderConstraintComponent ),
        &setFieldAngularLimitHigh, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    endGroup("Slider Constraint");
    Parent::initPersistFields();


}
bool PhysicsSliderConstraintComponent::onAdd()
{
    RETURN_FALSE_UNLESS(Parent::onAdd())

    return true;
}
void PhysicsSliderConstraintComponent::onRemove()
{
    Parent::onRemove();
}
bool PhysicsSliderConstraintComponent::serialize(BitStream *stream)
{
    RETURN_FALSE_UNLESS(Parent::serialize(stream))

    return true;
}
bool PhysicsSliderConstraintComponent::deserialize(BitStream *stream)
{
    RETURN_FALSE_UNLESS(Parent::deserialize(stream))

    return true;
}
bool PhysicsSliderConstraintComponent::initComponent()
{
    RETURN_FALSE_UNLESS(Parent::initComponent())

    return true;
}
bool PhysicsSliderConstraintComponent::deinitComponent()
{
    RETURN_FALSE_UNLESS(Parent::deinitComponent())

    return true;

}

void PhysicsSliderConstraintComponent::registerInterfacesTo(GameComponent* root)
{
    RETURN_VOID_UNLESS_EXISTS(root)
    Parent::registerInterfacesTo(root);
}

void PhysicsSliderConstraintComponent::onEnabled(bool now, bool before)
{
}

bool PhysicsSliderConstraintComponent::setFieldLinearLimitLow( void *component, const char *index, const char *data )
{
    PhysicsSliderConstraintComponent* constrCmp = static_cast<PhysicsSliderConstraintComponent*>( component );
    if(constrCmp)
    {
        F32 low;
        Con::setData( TypeF32, &low, 0, 1, &data );
        constrCmp->setLimits(&low, NULL, NULL, NULL);
    }
    return false;
}
bool PhysicsSliderConstraintComponent::setFieldLinearLimitHigh( void *component, const char *index, const char *data )
{
    PhysicsSliderConstraintComponent* constrCmp = static_cast<PhysicsSliderConstraintComponent*>( component );
    if(constrCmp)
    {
        F32 high;
        Con::setData( TypeF32, &high, 0, 1, &data );
        constrCmp->setLimits(NULL, &high, NULL, NULL);
    }
    return false;
}


bool PhysicsSliderConstraintComponent::setFieldAngularLimitLow( void *component, const char *index, const char *data )
{
    PhysicsSliderConstraintComponent* constrCmp = static_cast<PhysicsSliderConstraintComponent*>( component );
    if(constrCmp)
    {
        F32 low;
        Con::setData( TypeF32, &low, 0, 1, &data );
        constrCmp->setLimits(NULL, NULL, &low, NULL);
    }
    return false;
}
bool PhysicsSliderConstraintComponent::setFieldAngularLimitHigh( void *component, const char *index, const char *data )
{
    PhysicsSliderConstraintComponent* constrCmp = static_cast<PhysicsSliderConstraintComponent*>( component );
    if(constrCmp)
    {
        F32 high;
        Con::setData( TypeF32, &high, 0, 1, &data );
        constrCmp->setLimits(NULL, NULL, NULL, &high);
    }
    return false;
}
