//
// Copyright (c) 2012 Simon Wittenberg simon_wittenberg@gmx.net
//             and   Lethal Concept, LLC
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//

#include "PhysicsHingeConstraintComponent.h"


IMPLEMENT_CO_NETOBJECT_V1(PhysicsHingeConstraintComponent);


PhysicsHingeConstraintComponent::PhysicsHingeConstraintComponent(String typeString /*= "PhysicsGizmo"*/, String nameString/* = "HingeConstraint"*/, S32 maxInstances /*= 0*/)
:PhysicsConstraintComponent(typeString, nameString, maxInstances)
{
    mConstraintType = PhysicsConstraint::HINGE_CONSTRAINT;
    mConstraintAxis[0].set(0.0f, 0.0f, 1.0f);
    mConstraintAngularMotorMaxForce[0] = 1000.0f;
    mLowerAngularLimit[0] = -2.0f;
    mUpperAngularLimit[0] = 0.0f;
}
PhysicsHingeConstraintComponent::~PhysicsHingeConstraintComponent()
{

}

void PhysicsHingeConstraintComponent::initPersistFields()
{
    addGroup( "Hinge Constraint",NULL, AbstractClassRep::FIELD_PreviewGroup);

    addProtectedField( "axis", TypePoint3F, Offset( mConstraintAxis[0], PhysicsHingeConstraintComponent ),
        &setFieldHingeAxis, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    addProtectedField( "angularLimitLow", TypeF32, Offset( mLowerAngularLimit[0], PhysicsHingeConstraintComponent ),
        &setFieldHingeLimitLow, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    addProtectedField( "angularLimitHigh", TypeF32, Offset( mUpperAngularLimit[0], PhysicsHingeConstraintComponent ),
        &setFieldHingeLimitHigh, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    addProtectedField( "softness", TypeF32, Offset( mConstraintAngularSoftness[0], PhysicsHingeConstraintComponent ),
        &setFieldHingeSoftness, &defaultProtectedGetFn, 
        "TODO: Write Doc." );

    endGroup("Hinge Constraint");
    Parent::initPersistFields();


}
bool PhysicsHingeConstraintComponent::onAdd()
{
    RETURN_FALSE_UNLESS(Parent::onAdd())

    return true;
}
void PhysicsHingeConstraintComponent::onRemove()
{
    Parent::onRemove();
}
bool PhysicsHingeConstraintComponent::serialize(BitStream *stream)
{
    RETURN_FALSE_UNLESS(Parent::serialize(stream))

    return true;
}
bool PhysicsHingeConstraintComponent::deserialize(BitStream *stream)
{
    RETURN_FALSE_UNLESS(Parent::deserialize(stream))

    return true;
}
bool PhysicsHingeConstraintComponent::initComponent()
{
    RETURN_FALSE_UNLESS(Parent::initComponent())

    return true;
}
bool PhysicsHingeConstraintComponent::deinitComponent()
{
    RETURN_FALSE_UNLESS(Parent::deinitComponent())

    return true;

}
void PhysicsHingeConstraintComponent::registerInterfacesTo(GameComponent* root)
{
    RETURN_VOID_UNLESS_EXISTS(root)
    Parent::registerInterfacesTo(root);
}

void PhysicsHingeConstraintComponent::onEnabled(bool now, bool before)
{
}

bool PhysicsHingeConstraintComponent::setFieldHingeAxis( void *component, const char *index, const char *data )
{
    PhysicsHingeConstraintComponent* constrCmp = static_cast<PhysicsHingeConstraintComponent*>( component );
    if(constrCmp)
    {
        Point3F axis;
        Con::setData( TypePoint3F, &axis, 0, 1, &data );
        constrCmp->setAxis(axis);
    }
    return false;
}

bool PhysicsHingeConstraintComponent::setFieldHingeLimitLow( void *component, const char *index, const char *data )
{
    PhysicsHingeConstraintComponent* constrCmp = static_cast<PhysicsHingeConstraintComponent*>( component );
    if(constrCmp)
    {
        F32 low;
        Con::setData( TypeF32, &low, 0, 1, &data );
        constrCmp->setLimits(NULL, NULL, &low, NULL, 0);
    }
    return false;
}
bool PhysicsHingeConstraintComponent::setFieldHingeLimitHigh( void *component, const char *index, const char *data )
{
    PhysicsHingeConstraintComponent* constrCmp = static_cast<PhysicsHingeConstraintComponent*>( component );
    if(constrCmp)
    {
        F32 high;
        Con::setData( TypeF32, &high, 0, 1, &data );
        constrCmp->setLimits(NULL, NULL, NULL, &high, 0);
    }
    return false;
}
bool PhysicsHingeConstraintComponent::setFieldHingeSoftness( void *component, const char *index, const char *data )
{
    PhysicsHingeConstraintComponent* constrCmp = static_cast<PhysicsHingeConstraintComponent*>( component );
    if(constrCmp)
    {
        F32 softness;
        Con::setData( TypeF32, &softness, 0, 1, &data );
        constrCmp->setAngularSoftness(Point3F(softness,0,0));
    }
    return false;
}