//
// Copyright (c) 2012 Simon Wittenberg simon_wittenberg@gmx.net
//             and   Lethal Concept, LLC
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//
#include "PhysicsDOF6ConstraintComponent.h"


IMPLEMENT_CO_NETOBJECT_V1(PhysicsDOF6ConstraintComponent);


PhysicsDOF6ConstraintComponent::PhysicsDOF6ConstraintComponent(String typeString /*= "PhysicsGizmo"*/, String nameString/* = "DOF6Constraint"*/, S32 maxInstances /*= 0*/)
:PhysicsConstraintComponent(typeString, nameString, maxInstances)
{
    mConstraintType = PhysicsConstraint::DOF6_CONSTRAINT;
}
PhysicsDOF6ConstraintComponent::~PhysicsDOF6ConstraintComponent()
{

}

void PhysicsDOF6ConstraintComponent::initPersistFields()
{
    addGroup( "DOF6 Constraint",NULL, AbstractClassRep::FIELD_PreviewGroup);

    /*addProtectedField( "axis", TypePoint3F, Offset( mHingeAxis, PhysicsDOF6ConstraintComponent ),
        &setFieldHingeAxis, &defaultProtectedGetFn, 
        "TODO: Write Doc" );*/

    addProtectedField( "angularSoftness", TypePoint3F, Offset( mConstraintAngularSoftness, PhysicsDOF6ConstraintComponent ),
        &setFieldAngularSoftness, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    addProtectedField( "linearSoftness", TypePoint3F, Offset( mConstraintLinearSoftness, PhysicsDOF6ConstraintComponent ),
        &setFieldLinearSoftness, &defaultProtectedGetFn, 
        "TODO: Write Doc" );
    
    addProtectedField( "linearLimitLow", TypePoint3F, Offset( mLowerLinearLimit, PhysicsDOF6ConstraintComponent ),
        &setFieldLinearLimitLow, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    addProtectedField( "linearLimitHigh", TypePoint3F, Offset( mUpperLinearLimit, PhysicsDOF6ConstraintComponent ),
        &setFieldLinearLimitHigh, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    addProtectedField( "angularLimitLow", TypePoint3F, Offset( mLowerAngularLimit, PhysicsDOF6ConstraintComponent ),
        &setFieldAngularLimitLow, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    addProtectedField( "angularLimitHigh", TypePoint3F, Offset( mUpperAngularLimit, PhysicsDOF6ConstraintComponent ),
        &setFieldAngularLimitHigh, &defaultProtectedGetFn, 
        "TODO: Write Doc" );

    endGroup("DOF6 Constraint");
    Parent::initPersistFields();


}
bool PhysicsDOF6ConstraintComponent::onAdd()
{
    RETURN_FALSE_UNLESS(Parent::onAdd())

    return true;
}
void PhysicsDOF6ConstraintComponent::onRemove()
{
    Parent::onRemove();
}
bool PhysicsDOF6ConstraintComponent::serialize(BitStream *stream)
{
    RETURN_FALSE_UNLESS(Parent::serialize(stream))

    return true;
}
bool PhysicsDOF6ConstraintComponent::deserialize(BitStream *stream)
{
    RETURN_FALSE_UNLESS(Parent::deserialize(stream))

    return true;
}
bool PhysicsDOF6ConstraintComponent::initComponent()
{
    RETURN_FALSE_UNLESS(Parent::initComponent())

    return true;
}
bool PhysicsDOF6ConstraintComponent::deinitComponent()
{
    RETURN_FALSE_UNLESS(Parent::deinitComponent())

    return true;

}

void PhysicsDOF6ConstraintComponent::registerInterfacesTo(GameComponent* root)
{
    RETURN_VOID_UNLESS_EXISTS(root)
    Parent::registerInterfacesTo(root);
}


void PhysicsDOF6ConstraintComponent::onEnabled(bool now, bool before)
{
}

bool PhysicsDOF6ConstraintComponent::setFieldLinearSoftness( void *component, const char *index, const char *data )
{
    PhysicsDOF6ConstraintComponent* constrCmp = static_cast<PhysicsDOF6ConstraintComponent*>( component );
    if(constrCmp)
    {
        Point3F linearSoftness;
        Con::setData( TypePoint3F, &linearSoftness, 0, 1, &data );
        constrCmp->setLinearSoftness(linearSoftness);
    }
    return false;
}

bool PhysicsDOF6ConstraintComponent::setFieldAngularSoftness( void *component, const char *index, const char *data )
{
    PhysicsDOF6ConstraintComponent* constrCmp = static_cast<PhysicsDOF6ConstraintComponent*>( component );
    if(constrCmp)
    {
        Point3F angularSoftness;
        Con::setData( TypePoint3F, &angularSoftness, 0, 1, &data );
        constrCmp->setAngularSoftness(angularSoftness);
    }
    return false;
}

bool PhysicsDOF6ConstraintComponent::setFieldLinearLimitLow( void *component, const char *index, const char *data )
{
    PhysicsDOF6ConstraintComponent* constrCmp = static_cast<PhysicsDOF6ConstraintComponent*>( component );
    if(constrCmp)
    {
        Point3F low;
        Con::setData( TypePoint3F, &low, 0, 1, &data );
        for(U32 i=0; i<3; i++)
            constrCmp->setLimits(&low[i], NULL, NULL, NULL, i);
    }
    return false;
}
bool PhysicsDOF6ConstraintComponent::setFieldLinearLimitHigh( void *component, const char *index, const char *data )
{
    PhysicsDOF6ConstraintComponent* constrCmp = static_cast<PhysicsDOF6ConstraintComponent*>( component );
    if(constrCmp)
    {
        Point3F high;
        Con::setData( TypePoint3F, &high, 0, 1, &data );
        for(U32 i=0; i<3; i++)
            constrCmp->setLimits(NULL, &high[i], NULL, NULL, i);
    }
    return false;
}


bool PhysicsDOF6ConstraintComponent::setFieldAngularLimitLow( void *component, const char *index, const char *data )
{
    PhysicsDOF6ConstraintComponent* constrCmp = static_cast<PhysicsDOF6ConstraintComponent*>( component );
    if(constrCmp)
    {
        Point3F low;
        Con::setData( TypePoint3F, &low, 0, 1, &data );
        for(U32 i=0; i<3; i++)
            constrCmp->setLimits(NULL, NULL, &low[i], NULL, i);
    }
    return false;
}
bool PhysicsDOF6ConstraintComponent::setFieldAngularLimitHigh( void *component, const char *index, const char *data )
{
    PhysicsDOF6ConstraintComponent* constrCmp = static_cast<PhysicsDOF6ConstraintComponent*>( component );
    if(constrCmp)
    {
        Point3F high;
        Con::setData( TypePoint3F, &high, 0, 1, &data );
        for(U32 i=0; i<3; i++)
            constrCmp->setLimits( NULL, NULL, NULL, &high[i], i);
    }
    return false;
}
