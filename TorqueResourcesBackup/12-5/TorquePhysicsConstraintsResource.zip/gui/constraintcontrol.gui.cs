//
// Copyright (c) 2012 Simon Wittenberg simon_wittenberg@gmx.net
//             and   Lethal Concept, LLC
//
// This software is provided 'as-is', without any express or implied
// warranty.  In no event will the authors be held liable for any damages
// arising from the use of this software.
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//

function ConstraintControlGui::onWake(%this)
{  
   // Reset ALL the controls
   
   // General
   ConstraintControlGui-->DOF6Page.setActive(false);
   ConstraintControlGui-->sliderPage.setActive(false);
   ConstraintControlGui-->hingePage.setActive(false);
   ConstraintControlGui-->coneTwistPage.setActive(false);
   
   ConstraintControlGui.currentObject = 0;
   ConstraintControlGui-->curConstComp.setText(ConstraintControlGui.currentObject);
   ConstraintControlGui-->enableButton.setValue(0);
   ConstraintControlGui-->objIdField.setText("Enter ID");
   

   // Slider   
   ConstraintControlGui-->linearButton.setValue(0);         
   ConstraintControlGui-->lowLinearField.setText(0);
   ConstraintControlGui-->highLinearField.setText(0);
   ConstraintControlGui-->maxLinearForceField.setText(0);
   ConstraintControlGui-->linearSpeedField.setText(0);
   ConstraintControlGui-->linearButton.setValue(0);         
   
   // Hinge
   ConstraintControlGui-->angularButton.setValue(0);         
   ConstraintControlGui-->lowAngularField.setText(0);
   ConstraintControlGui-->highAngularField.setText(0);
   ConstraintControlGui-->maxAngularForceField.setText(0);
   ConstraintControlGui-->angularSpeedField.setText(0);
   ConstraintControlGui-->angularButton.setValue(0);         

   // DOF6
   ConstraintControlGui-->lowLinearFieldDOF.setText("0 0 0");
   ConstraintControlGui-->highLinearFieldDOF.setText("0 0 0");
   ConstraintControlGui-->maxLinearForceFieldDOF.setText("0 0 0");
   ConstraintControlGui-->linearSpeedFieldDOF.setText("0 0 0");
   ConstraintControlGui-->lowAngularFieldDOF.setText("0 0 0");
   ConstraintControlGui-->highAngularFieldDOF.setText("0 0 0");
   ConstraintControlGui-->maxAngularForceFieldDOF.setText("0 0 0");
   ConstraintControlGui-->angularSpeedFieldDOF.setText("0 0 0");
   ConstraintControlGui-->linearXButton.setValue(0);         
   ConstraintControlGui-->linearYButton.setValue(0);         
   ConstraintControlGui-->linearZButton.setValue(0);         
   ConstraintControlGui-->angularXbutton.setValue(0);         
   ConstraintControlGui-->angularYbutton.setValue(0);         
   ConstraintControlGui-->angularZbutton.setValue(0);         

   // Cone Twist               
   ConstraintControlGui-->motorTargetField.setText("0 0 0");
   ConstraintControlGui-->twistSpanField.setText(0);
   ConstraintControlGui-->swingSpan2Field.setText(0);
   ConstraintControlGui-->swingSpan1Field.setText(0);     
   ConstraintControlGui-->coneTwistMotorButton.setValue(0);         
}
function ObjectSelectionField::onReturn(%this)
{
   %object = %this.getText();
   //echo("onReturn" SPC %this SPC %object);
   if(isObject(%object))
   {
      echo("Found Object!");
      %class = %object.getClassname();
      if(%class $= "PhysicsSliderConstraintComponent"
         || %class $= "PhysicsHingeConstraintComponent"
         || %class $= "PhysicsDOF6ConstraintComponent"
         || %class $= "PhysicsConeTwistConstraintComponent"  )
      {
   
         //echo("It's a" SPC %class SPC"!");
         ConstraintControlGui.currentObject = %object;
         ConstraintControlGui-->curConstComp.setText(ConstraintControlGui.currentObject);
         ConstraintControlGui-->enableButton.setValue(%object.constraintEnabled);
         
         if(%class $= "PhysicsSliderConstraintComponent")
         {
            %this.setText("Slider");
            ConstraintControlGui-->DOF6Page.setActive(false);
            ConstraintControlGui-->sliderPage.setActive(true);
            ConstraintControlGui-->hingePage.setActive(false);
            ConstraintControlGui-->coneTwistPage.setActive(false);

            ConstraintControlGui-->linearButton.setValue(%object.enableLinearMotor[0]);         
            
            ConstraintControlGui-->lowLinearField.setText(%object.linearLimitLow);
            ConstraintControlGui-->highLinearField.setText(%object.linearLimitHigh);
            ConstraintControlGui-->maxLinearForceField.setText(getWord(%object.maxLinearMotorForce, 0));
            ConstraintControlGui-->linearSpeedField.setText(getWord(%object.linearSpeed, 0));
            return;
         }
         else
         {
            if(%class $= "PhysicsHingeConstraintComponent")
            {
               %this.setText("Hinge");
               ConstraintControlGui-->DOF6Page.setActive(false);
               ConstraintControlGui-->sliderPage.setActive(false);
               ConstraintControlGui-->hingePage.setActive(true);
               ConstraintControlGui-->coneTwistPage.setActive(false);
               
               ConstraintControlGui-->angularButton.setValue(%object.enableAngularMotor[0]);         
               
               ConstraintControlGui-->lowAngularField.setText(%object.angularLimitLow);
               ConstraintControlGui-->highAngularField.setText(%object.angularLimitHigh);
               ConstraintControlGui-->maxAngularForceField.setText(getWord(%object.maxAngularMotorForce, 0));
               ConstraintControlGui-->angularSpeedField.setText(getWord(%object.angularSpeed, 0));
               return;
            }
            else
            {
               if(%class $= "PhysicsDOF6ConstraintComponent")
               {
                  %this.setText("DOF6");              
                  ConstraintControlGui-->DOF6Page.setActive(true);
                  ConstraintControlGui-->sliderPage.setActive(false);
                  ConstraintControlGui-->hingePage.setActive(false);
                  ConstraintControlGui-->coneTwistPage.setActive(false);
                  
                  ConstraintControlGui-->lowLinearFieldDOF.setText(%object.linearLimitLow);
                  ConstraintControlGui-->highLinearFieldDOF.setText(%object.linearLimitHigh);
                  ConstraintControlGui-->maxLinearForceFieldDOF.setText(%object.maxLinearMotorForce);
                  ConstraintControlGui-->linearSpeedFieldDOF.setText(%object.linearSpeed);
                  ConstraintControlGui-->lowAngularFieldDOF.setText(%object.angularLimitLow);
                  ConstraintControlGui-->highAngularFieldDOF.setText(%object.angularLimitHigh);
                  ConstraintControlGui-->maxAngularForceFieldDOF.setText(%object.maxAngularMotorForce);
                  ConstraintControlGui-->angularSpeedFieldDOF.setText(%object.angularSpeed);
                  
                  ConstraintControlGui-->linearXButton.setValue(%object.enableLinearMotor[0]);         
                  ConstraintControlGui-->linearYButton.setValue(%object.enableLinearMotor[1]);         
                  ConstraintControlGui-->linearZButton.setValue(%object.enableLinearMotor[2]);         
                  ConstraintControlGui-->angularXbutton.setValue(%object.enableAngularMotor[0]);
                  ConstraintControlGui-->angularYbutton.setValue(%object.enableAngularMotor[1]);
                  ConstraintControlGui-->angularZbutton.setValue(%object.enableAngularMotor[2]);
                  return;
               }
               else if (%class $= "PhysicsConeTwistConstraintComponent")
               {
                  %this.setText("Cone Twist");
                  ConstraintControlGui-->DOF6Page.setActive(false);
                  ConstraintControlGui-->sliderPage.setActive(false);
                  ConstraintControlGui-->hingePage.setActive(false);
                  ConstraintControlGui-->coneTwistPage.setActive(true);
                  
                  ConstraintControlGui-->twistSpanField.setText(ConstraintControlGui.currentObject.twistSpan);
                  ConstraintControlGui-->swingSpan2Field.setText(ConstraintControlGui.currentObject.swingSpan1);
                  ConstraintControlGui-->swingSpan1Field.setText(ConstraintControlGui.currentObject.swingSpan2);
                  
                  ConstraintControlGui-->coneTwistMotorButton.setValue(%object.enableAngularMotor[0]);
                  return;
               }
            }        
         }
      }
   }
   //echo("Found no Object or wrong class.!" SPC %this.text );
   %this.settext("INVALID");
}


function ConstraintControlGui::getEnableResultFromControl(%this, %control)
{
   %toEnable = -1;
   %bTest = %control.getValue();
   if(%bTest == 1)
   {
      %toEnable = true;
   }
   else
   {
      %toEnable = false;
   }
   
   return %toEnable;
}


function ConstraintToggle::onAction(%this)
{
   echo("ConstraintToggle toggled!" SPC %this.getValue());
   if(isObject(ConstraintControlGui.currentObject))
   {
      %onOff = ConstraintControlGui.getEnableResultFromControl(%this);
      ConstraintControlGui.currentObject.constraintEnabled = %onOff;
      ConstraintControlGui-->enableButton.setValue(ConstraintControlGui.currentObject.constraintEnabled);
   }
}


function MaxLinForceField::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.maxLinearMotorForce = %this.getText();
      ConstraintControlGui-->maxLinearForceField.setText(getWord(ConstraintControlGui.currentObject.maxLinearMotorForce, 0));
   }
   
}
function LinSpeedField::onReturn(%this)
{
    // we have nowhere to save this, so it is just a local value in the control
   //if(isObject(ConstraintControlGui.currentObject))
   //{
      
   //}
}

function LowLinField::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.linearLimitLow = %this.getText();
      ConstraintControlGui-->lowLinearField.setText(ConstraintControlGui.currentObject.linearLimitLow);
   }
}
function HighLinField::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.linearLimitHigh = %this.getText();
      ConstraintControlGui-->highLinearField.setText(ConstraintControlGui.currentObject.linearLimitHigh);
   }
}

function LinearToggle::onAction(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      %onOff = %this.getValue();
      ConstraintControlGui.currentObject.enableLinearMotor[0] = %onOff;
      ConstraintControlGui-->linearButton.setValue(ConstraintControlGui.currentObject.enableLinearMotor[0]);
   }
}

function SliderButtonUp::onMouseDown(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.linearSpeed = ConstraintControlGui-->linearSpeedField.getText() SPC "0 0";
   }
}

function SliderButtonUp::onMouseUp(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.linearSpeed = "0 0 0";
   }
}
function SliderButtonDown::onMouseDown(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.linearSpeed = "-" @ ConstraintControlGui-->linearSpeedField.getText() SPC "0 0";
   }
}

function SliderButtonDown::onMouseUp(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.linearSpeed = "0 0 0";
   }
}


function MaxAngForceField::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.maxAngularMotorForce = %this.getText();
      ConstraintControlGui-->maxAngularForceField.setText(getWord(ConstraintControlGui.currentObject.maxAngularMotorForce, 0));
   }
}

function AngSpeedField::onReturn(%this)
{
    // we have nowhere to save this, so it is just a local value in the control
   //if(isObject(ConstraintControlGui.currentObject))
   //{
   //}
}

function LowAngField::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.angularLimitLow = %this.getText();
      ConstraintControlGui-->lowAngularField.setText(ConstraintControlGui.currentObject.angularLimitLow);
   }
}
function HighAngField::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.angularLimitHigh = %this.getText();
      ConstraintControlGui-->highAngularField.setText(ConstraintControlGui.currentObject.angularLimitHigh);
   }
}

function AngularToggle::onAction(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      %onOff = %this.getValue();
      ConstraintControlGui.currentObject.enableAngularMotor[0] = %onOff;
      ConstraintControlGui-->angularButton.setValue(ConstraintControlGui.currentObject.enableAngularMotor[0]);
   }
}

function HingeButtonUp::onMouseDown(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.angularSpeed = ConstraintControlGui-->angularSpeedField.getText() SPC "0 0";
   }
}

function HingeButtonUp::onMouseUp(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.angularSpeed = "0 0 0";
   }
}
function HingeButtonDown::onMouseDown(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.angularSpeed = "-" @ ConstraintControlGui-->angularSpeedField.getText() SPC "0 0";
   }
}

function HingeButtonDown::onMouseUp(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.angularSpeed = "0 0 0";
   }
}


function MaxLinForceFieldDOF::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.maxLinearMotorForce = %this.getText();
      ConstraintControlGui-->maxLinearForceFieldDOF.setText(ConstraintControlGui.currentObject.maxLinearMotorForce);
   }
   
}
function LinSpeedFieldDOF::onReturn(%this)
{
    // we have nowhere to save this, so it is just a local value in the control
   //if(isObject(ConstraintControlGui.currentObject))
   //{
   //}
}

function LowLinFieldDOF::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.linearLimitLow = %this.getText();
      ConstraintControlGui-->lowLinearFieldDOF.setText(ConstraintControlGui.currentObject.linearLimitLow);
   }
}
function HighLinFieldDOF::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.linearLimitHigh = %this.getText();
      ConstraintControlGui-->highLinearFieldDOF.setText(ConstraintControlGui.currentObject.linearLimitHigh);
   }
}


function MaxAngForceFieldDOF::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.maxAngularMotorForce = %this.getText();
      ConstraintControlGui-->maxAngularForceFieldDOF.setText(ConstraintControlGui.currentObject.maxAngularMotorForce);
   }
}
function AngSpeedFieldDOF::onReturn(%this)
{
    // we have nowhere to save this, so it is just a local value in the control
   //if(isObject(ConstraintControlGui.currentObject))
   //{
   //}
}

function LowAngFieldDOF::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.angularLimitLow = %this.getText();
      ConstraintControlGui-->lowAngularFieldDOF.setText(ConstraintControlGui.currentObject.angularLimitLow);
   }
}

function HighAngFieldDOF::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.angularLimitHigh = %this.getText();
      ConstraintControlGui-->highAngularFieldDOF.setText(ConstraintControlGui.currentObject.angularLimitHigh);
   }
}

function AngularXToggle::onAction(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      %onOff = %this.getValue();
      ConstraintControlGui.currentObject.enableAngularMotor[0] = %onOff;
      ConstraintControlGui-->angularXbutton.setValue(ConstraintControlGui.currentObject.enableAngularMotor[0]);
   }
}

function AngularYToggle::onAction(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      %onOff = %this.getValue();
      ConstraintControlGui.currentObject.enableAngularMotor[1] = %onOff;
      ConstraintControlGui-->angularYbutton.setValue(ConstraintControlGui.currentObject.enableAngularMotor[1]);
   }
}

function AngularZToggle::onAction(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      %onOff = %this.getValue();
      ConstraintControlGui.currentObject.enableAngularMotor[2] = %onOff;
      ConstraintControlGui-->angularZbutton.setValue(ConstraintControlGui.currentObject.enableAngularMotor[2]);
   }
}

function LinearXToggle::onAction(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      %onOff = %this.getValue();
      ConstraintControlGui.currentObject.enableLinearMotor[0] = %onOff;
      ConstraintControlGui-->linearXbutton.setValue(ConstraintControlGui.currentObject.enableLinearMotor[0]);
   }
}

function LinearYToggle::onAction(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      %onOff = %this.getValue();
      ConstraintControlGui.currentObject.enableLinearMotor[1] = %onOff;
      ConstraintControlGui-->linearYbutton.setValue(ConstraintControlGui.currentObject.enableLinearMotor[1]);
   }
}

function LinearZToggle::onAction(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      %onOff = %this.getValue();
      ConstraintControlGui.currentObject.enableLinearMotor[2] = %onOff;
      ConstraintControlGui-->linearZbutton.setValue(ConstraintControlGui.currentObject.enableLinearMotor[2]);
   }
}

function ConeTwistTwistSpanField::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.twistSpan = %this.getText();
      ConstraintControlGui-->twistSpanField.setText(ConstraintControlGui.currentObject.twistSpan);
   }
}

function ConeTwistSwingSpan1Field::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.swingSpan1 = %this.getText();
      ConstraintControlGui-->swingSpan1Field.setText(ConstraintControlGui.currentObject.swingSpan1);
   }
}

function ConeTwistSwingSpan2Field::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.swingSpan2 = %this.getText();
      ConstraintControlGui-->swingSpan2Field.setText(ConstraintControlGui.currentObject.swingSpan2);
   }
}

function ConeTwistMotorTargetField::onReturn(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      ConstraintControlGui.currentObject.coneTwistMotorTarget = %this.getText();
      ConstraintControlGui-->motorTargetField.setText(ConstraintControlGui.currentObject.coneTwistMotorTarget);
   }
}

function ConeTwistMotorToggle::onAction(%this)
{
   if(isObject(ConstraintControlGui.currentObject))
   {
      %onOff = %this.getValue();
      ConstraintControlGui.currentObject.enableAngularMotor[0] = %onOff;
      ConstraintControlGui-->coneTwistMotorButton.setValue(ConstraintControlGui.currentObject.enableAngularMotor[0]);
   }
}