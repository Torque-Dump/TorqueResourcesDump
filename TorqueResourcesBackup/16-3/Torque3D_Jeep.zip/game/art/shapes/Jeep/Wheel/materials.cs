









singleton Material(newMaterial24)
{
   mapTo = "_JeepWheelgreen_metal";
   diffuseMap[0] = "art/shapes/Jeep/Wheel/images/0_green_metal.jpg";
   materialTag0 = "Miscellaneous";
   doubleSided = "1";
   normalMap[0] = "art/shapes/Jeep/Wheel/images/0_green_metal_N.jpg";
   specular[0] = "0.529412 0.529412 0.529412 1";
   specularPower[0] = "1";
   specularStrength[0] = "1.07843";
   pixelSpecular[0] = "1";
};


singleton Material(wheel__JeepWheel_1)
{
   mapTo = "_JeepWheel_1";
   diffuseMap[0] = "art/shapes/Jeep/Wheel/images/2__1";
   normalMap[0] = "art/shapes/Jeep/Wheel/images/2__1_N.jpg";
   specular[0] = "0.33 0.33 0.33 1";
   specularPower[0] = "19";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
   pixelSpecular[0] = "1";
};

singleton Material(wheel__JeepWheelrubber)
{
   mapTo = "_JeepWheelrubber";
   diffuseMap[0] = "art/shapes/Jeep/Wheel/images/1_rubber";
   specular[0] = "0.603922 0.603922 0.603922 1";
   specularPower[0] = "1";
   translucentBlendOp = "None";
   normalMap[0] = "art/shapes/Jeep/Wheel/images/1_rubber_N.jpg";
   materialTag0 = "Miscellaneous";
   specularStrength[0] = "0.784314";
   pixelSpecular[0] = "1";
};

singleton Material(wheel__JeepWheel_1_1_)
{
   mapTo = "_JeepWheel_1_1_";
   diffuseMap[0] = "art/shapes/Jeep/Wheel/images/3__1_1_";
   specular[0] = "0.33 0.33 0.33 1";
   specularPower[0] = "114";
   translucentBlendOp = "None";
   normalMap[0] = "art/shapes/Jeep/Wheel/images/2__1_N.jpg";
   materialTag0 = "Miscellaneous";
   specularStrength[0] = "1.17647";
   pixelSpecular[0] = "1";
};

singleton Material(wheel__JeepWheel_1_1_)
{
   mapTo = "_JeepWheel_1_1_";
   diffuseMap[0] = "art/shapes/Jeep/Wheel/images/3__1_1_";
   specular[0] = "0.33 0.33 0.33 1";
   specularPower[0] = "128";
   translucentBlendOp = "None";
};

singleton Material(wheel__JeepWheelM_0058_Olive)
{
   mapTo = "_JeepWheelM_0058_Olive";
   diffuseColor[0] = "0.223529 0.239216 0.168627 1";
   specular[0] = "0.33 0.33 0.33 1";
   specularPower[0] = "128";
   translucentBlendOp = "None";
};

