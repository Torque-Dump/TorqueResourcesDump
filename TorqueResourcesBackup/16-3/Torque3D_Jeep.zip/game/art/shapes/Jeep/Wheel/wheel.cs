
singleton TSShapeConstructor(WheelDAE2)
{
   baseShape = "./wheel.DAE";
   adjustCenter = "1";
   loadLights = "0";
   unit = "0.01750";
};
