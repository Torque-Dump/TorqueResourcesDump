
singleton Material(jeep_gun_green_metal)
{
   mapTo = "green_metal";
   diffuseMap[0] = "art/shapes/Jeep/Gun/images/0_green_metal";
   specular[0] = "0.607843 0.607843 0.607843 1";
   specularPower[0] = "64";
   translucentBlendOp = "None";
   doubleSided = "0";
   specularStrength[0] = "0.882353";
   pixelSpecular[0] = "1";
   normalMap[0] = "art/shapes/Jeep/Wheel/images/0_green_metal_N.jpg";
   vertLit[0] = "1";
   accuEnabled[0] = "0";
   accuScale[0] = "22.5974";
   accuStrength[0] = "0.54902";
   accuCoverage[0] = "1.21569";
   accuSpecular[0] = "0.980392";
   accuDirection[0] = "-0.72549";
   diffuseColor[1] = "1 1 1 1";
};
