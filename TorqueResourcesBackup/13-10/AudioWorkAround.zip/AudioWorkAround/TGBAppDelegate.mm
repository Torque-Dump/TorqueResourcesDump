//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------


#import "TGBAppDelegate.h"
#include "platform/platformInput.h"

#if defined(_USE_SOCIAL_NETWORKING)
#include "platformiPhone/iPhoneSocialNetworkingManager.h"
#endif // _USE_SOCIAL_NETWORKING

#include "platformiPhone/iPhoneUtil.h"

#import "platformiPhone/platformiPhone.h"
#import <sys/utsname.h>
#import <objc/runtime.h>

#define DEAD_SOUND - 1000

extern int _iPhoneRunTorqueMain( id appID,  UIView *Window, UIApplication *app );
extern void _iPhoneGameInnerLoop();
extern void _iPhoneGameResignActive();
extern void _iPhoneGameBecomeActive();
extern void _iPhoneGameWillTerminate();

bool _iPhoneTorqueFatalError = false;

//Luma: Store current orientation for easy access
extern void _iPhoneGameChangeOrientation(S32 newOrientation);

@implementation AVAudioPlayer (TaggedAudioPlayer)
static char tagKey;

- (void) setTag:(int)tag
{
    objc_setAssociatedObject( self, &tagKey, [NSNumber numberWithInt:tag], OBJC_ASSOCIATION_RETAIN );
}

- (int) tag
{
    return [objc_getAssociatedObject( self, &tagKey ) intValue];
}

- (void) fadeOut
{
    self.tag = DEAD_SOUND;
    
    if([self volume] > 0)
    {
        self.volume -= 0.1;
        [self performSelector:@selector(fadeOut) withObject:nil afterDelay:0.005];
    }
    else
    {
        [self stop];
    }
}

@end

@implementation TGBAppDelegate

UIDeviceOrientation currentOrientation;

@synthesize window;

- (void)applicationDidFinishLaunching:(UIApplication *)application {

	_iPhoneTorqueFatalError = false;
	if(!_iPhoneRunTorqueMain( self, window, application ))
	{
		_iPhoneTorqueFatalError = true;
		return;
	};
    
    self.sounds = [NSMutableArray array];
    soundCount = 0;
    soundPaused = NO;
	
	
	[[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
	//Also we set the currentRotation up so its not invalid
	currentOrientation = [UIDevice currentDevice].orientation;
	//So we make a selector to handle that, called didRotate (lower down in the code)
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(didRotate:)
												 name:UIDeviceOrientationDidChangeNotification
											   object:nil];	
	
#if defined(_USE_SOCIAL_NETWORKING)
    socialNetworkingInit(self);
#endif //_USE_SOCIAL_NETWORKING
    //iADs
    //UIViewController *view_controller = [[myAdViewController alloc] init];
    //[window addSubview: view_controller.view];
    //view_controller.view.frame = CGRectMake(0, 0, 320, 50); 
    //iAds
}


- (void)applicationWillResignActive:(UIApplication *)application {
	_iPhoneGameResignActive();	
    
#if defined(_USE_SOCIAL_NETWORKING)
    socialNetworkingManager->socialNetworkingToResignActive();
#endif //_USE_SOCIAL_NETWORKING
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
	if(!_iPhoneTorqueFatalError)
	{
		_iPhoneGameBecomeActive();
        
 
        
#if defined(_USE_SOCIAL_NETWORKING)
        socialNetworkingManager->socialNetworkingBecameActive();
#endif //_USE_SOCIAL_NETWORKING
	}
	else 
	{
		//Luma : Tell us why, and then quit
		//Note, engine has shutdown internally already!
		//Another note, Alerts get hidden/broken by default.png not being "finished" yet, causing a "freeze" in the alert run loop
		exit(0);
	}

}

//Luma:	pick up memory warnings
- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
	printf("\n\nMEMORY WARNING: Received Memory Warning from iPhone OS!\n");
}


- (void)applicationWillTerminate:(UIApplication *)application {

	_iPhoneGameWillTerminate();
	
	[[UIDevice currentDevice] endGeneratingDeviceOrientationNotifications];

#if defined(_USE_SOCIAL_NETWORKING)
    socialNetworkingCleanup();
#endif //_USE_SOCIAL_NETWORKING
}


- (void)didRotate:(NSNotification *)notification
{	
	//Default to landscape left
	UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
	if(currentOrientation != orientation)
	{
		//Change the orientation
		currentOrientation = orientation;
		//Tell the rest of the engine
		_iPhoneGameChangeOrientation(currentOrientation);
	}
}


- (void) runMainLoop {
	_iPhoneGameInnerLoop();
}

- (void)dealloc {
	[window release];
	[super dealloc];
}


//CG Audio ----------------------------------------------------------------------------------------
ConsoleFunction(iPlaySound, int, 3, 3, "")
{
    NSArray* parts = [[NSString stringWithUTF8String:argv[1]] componentsSeparatedByString:@"."];
    
    if([parts count] > 1)
    {
        TGBAppDelegate* del = (TGBAppDelegate*)[UIApplication sharedApplication].delegate;
        return [del playSound:parts[0] withFormat:parts[1] shouldLoop:dAtob(argv[2])];
    }
    
    return 0;
}

ConsoleFunction(iFadeSound, void, 2, 2, "")
{
    TGBAppDelegate* del = (TGBAppDelegate*)[UIApplication sharedApplication].delegate;
    [del fadeSound:dAtoi(argv[1])];
}

ConsoleFunction(iStopSound, void, 2, 2, "")
{
    TGBAppDelegate* del = (TGBAppDelegate*)[UIApplication sharedApplication].delegate;
    [del stopSound:dAtoi(argv[1])];
}

ConsoleFunction(iStopSoundByURL, void, 2, 2, "")
{
    TGBAppDelegate* del = (TGBAppDelegate*)[UIApplication sharedApplication].delegate;
    [del stopSoundByURL:[NSString stringWithUTF8String:argv[1]]];
}

ConsoleFunction(iUnpauseSound, bool, 2, 2, "")
{
    TGBAppDelegate* del = (TGBAppDelegate*)[UIApplication sharedApplication].delegate;
    return [del unpauseSound:dAtoi(argv[1])];
}

ConsoleFunction(iSoundIsPlaying, bool, 2, 2, "")
{
      TGBAppDelegate* del = (TGBAppDelegate*)[UIApplication sharedApplication].delegate;
      return [del isSoundPlaying:dAtoi(argv[1])];
}

ConsoleFunction(iStopAllSound, void, 1, 1, "")
{
    TGBAppDelegate* del = (TGBAppDelegate*)[UIApplication sharedApplication].delegate;
    [del stopAllSound];
}

ConsoleFunction(iPauseSound, void, 2, 2, "")
{
    TGBAppDelegate* del = (TGBAppDelegate*)[UIApplication sharedApplication].delegate;
    [del pauseSound:dAtoi(argv[1])];
}

ConsoleFunction(iPauseAllSound, void, 1, 1, "")
{
    TGBAppDelegate* del = (TGBAppDelegate*)[UIApplication sharedApplication].delegate;
    [del toggleSound];
}

-(bool)isSoundPlaying:(int)castID
{
    NSArray* tempSounds = _sounds;
    for(AVAudioPlayer* player in tempSounds)
    {
        if(player.tag == castID)
            return YES;
    }
    return NO;
}

-(void)toggleSound
{
    soundPaused = !soundPaused;
    if(soundPaused)
    {
        NSArray* tempSounds = _sounds;
        for(AVAudioPlayer* player in tempSounds)
        {
            if(player.tag != DEAD_SOUND)
                [player pause];
        }
    }
    else
    {
        NSArray* tempSounds = _sounds;
        for(AVAudioPlayer* player in tempSounds)
        {
            if(player.tag != DEAD_SOUND)
                [player play];
        }
    }
}

-(void)stopAllSound
{
    NSArray* tempSounds = _sounds;
    for(AVAudioPlayer* player in tempSounds)
    {
        player.tag = DEAD_SOUND;
        [player stop];
    }
    
    [_sounds removeAllObjects];
}

-(void)fadeSound:(int)castID
{
    NSArray* tempSounds = _sounds;
    for(AVAudioPlayer* player in tempSounds)
    {
        if(player.tag == castID)
        {
            [player fadeOut];
            break;
        }
    }
}

-(void)stopSound:(int)castID
{
    NSArray* tempSounds = _sounds;
    for(AVAudioPlayer* player in tempSounds)
    {
        if(player.tag == castID)
        {
            player.tag = DEAD_SOUND;
            [player stop];
            break;
        }
    }
}

-(void)stopSoundByURL:(NSString*)fullURL
{
    NSString* url = [[fullURL componentsSeparatedByString:@"/"] lastObject];
    
    NSArray* tempSounds = _sounds;
    for(AVAudioPlayer* player in tempSounds)
    {
        NSString* lurl = [[[player.url absoluteString] componentsSeparatedByString:@"/"] lastObject];
        
        if([lurl isEqualToString:url])
            [self fadeSound:player.tag];
    }
}

-(bool)unpauseSound:(int)castID
{
    NSArray* tempSounds = _sounds;
    for(AVAudioPlayer* player in tempSounds)
    {
        if(player.tag == castID && player.tag != DEAD_SOUND)
        {
            [player play];
            return YES;
        }
    }
    return NO;
}

-(void)pauseSound:(int)castID
{
    NSArray* tempSounds = _sounds;
    for(AVAudioPlayer* player in tempSounds)
    {
        if(player.tag == castID && player.tag != DEAD_SOUND)
        {
            [player pause];
            break;
        }
    }
}

- (int)playSound:(NSString*)sound withFormat:(NSString*)format shouldLoop:(bool)loop

{
    int tag = soundCount++;
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void)
                   {
                       //Background Thread
                       NSString *soundFilePath = [[NSBundle mainBundle] pathForResource: sound ofType: format];
                       //NSString *soundFilePath = @"modules/TNT/1/assets/audio/boom.wav";
                       //NSLog(@"File %@",sound);
                       //NSLog(@"Path %@",soundFilePath);
                       
                       
                       AVAudioPlayer *audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:soundFilePath] error:nil];
                       
                       if(audioPlayer)
                       {
                           audioPlayer.delegate = self;
                           audioPlayer.tag = tag;
                           
                           if(loop)
                               audioPlayer.numberOfLoops = -1;
                           else
                               audioPlayer.numberOfLoops = 0;
                           
                           @try {
                               [audioPlayer prepareToPlay];
                               [audioPlayer play];
                           }
                           @catch (NSException *exception) {
                               NSLog(@"Can't play %@",sound);
                           }
                           @finally {
                               dispatch_async(dispatch_get_main_queue(), ^(void)
                                              {
                                                  [_sounds addObject:audioPlayer];
                                              });
                           }
                       }
                   });
    
    return tag;
}

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    player.tag = DEAD_SOUND;
}

- (void)audioPlayerDecodeErrorDidOccur:(AVAudioPlayer *)player error:(NSError *)error
{
    NSLog(@"Error: %@",error);
    player.tag = DEAD_SOUND;
    [player stop];
}

@end