//-----------------------------------------------------------------------------
// Copyright (c) 2013 GarageGames, LLC
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//-----------------------------------------------------------------------------

#import "platformiOS/T2DAppDelegate.h"

#include "platform/platformInput.h"
#include "platformiOS/iOSUtil.h"
#include "console/console.h"

//#include "platformiPhone/iPhoneUtil.h"
#import <sys/utsname.h>
#import <objc/runtime.h>

#define DEAD_SOUND -1000

extern void _iOSGameInnerLoop();
extern void _iOSGameResignActive();
extern void _iOSGameBecomeActive();
extern void _iOSGameWillTerminate();

// Store current orientation for easy access
extern void _iOSGameChangeOrientation(S32 newOrientation);
UIDeviceOrientation currentOrientation;

bool _iOSTorqueFatalError = false;

@implementation AVAudioPlayer (TaggedAudioPlayer)
static char tagKey;

- (void) setTag:(int)tag
{
    objc_setAssociatedObject( self, &tagKey, [NSNumber numberWithInt:tag], OBJC_ASSOCIATION_RETAIN );
}

- (int) tag
{
    return [objc_getAssociatedObject( self, &tagKey ) intValue];
}

- (void) fadeOut
{
    self.tag = DEAD_SOUND;
    
    if([self volume] > 0)
    {
        self.volume -= 0.1;
        [self performSelector:@selector(fadeOut) withObject:nil afterDelay:0.005];
    }
    else
    {
        [self stop];
    }
}

@end

@implementation T2DAppDelegate

@synthesize window = _window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {
    
	[[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
	//Also we set the currentRotation up so its not invalid
	currentOrientation = [UIDevice currentDevice].orientation;
	//So we make a selector to handle that, called didRotate (lower down in the code)
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(didRotate:)
												 name:UIDeviceOrientationDidChangeNotification
											   object:nil];
    
    self.sounds = [NSMutableArray array];
    soundCount = 0;
    soundPaused = NO;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    _iOSGameResignActive();
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    if(!_iOSTorqueFatalError)
        _iOSGameBecomeActive();
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    _iOSGameWillTerminate();
	
	[[UIDevice currentDevice] endGeneratingDeviceOrientationNotifications];
}

- (void)didRotate:(NSNotification *)notification
{
    //Default to landscape left
	UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
	if(currentOrientation != orientation)
	{
		//Change the orientation
		currentOrientation = orientation;
		//Tell the rest of the engine
		_iOSGameChangeOrientation(currentOrientation);
	}
}

- (void) runMainLoop
{
	_iOSGameInnerLoop();
}

ConsoleFunction(iPlaySound, int, 3, 3, "")
{
    NSArray* parts = [[NSString stringWithUTF8String:argv[1]] componentsSeparatedByString:@"."];
    Con::printf("testing %s",argv[0]);
    Con::printf("testing %s",argv[1]);
    Con::printf("testing %s",argv[2]);
    
    if([parts count] > 1)
    {
        T2DAppDelegate* del = (T2DAppDelegate*)[UIApplication sharedApplication].delegate;
        return [del playSound:parts[0] withFormat:parts[1] shouldLoop:dAtob(argv[2])];
    }
    
    return 0;
}

ConsoleFunction(iFadeSound, void, 2, 2, "")
{
    T2DAppDelegate* del = (T2DAppDelegate*)[UIApplication sharedApplication].delegate;
    [del fadeSound:dAtoi(argv[1])];
}

ConsoleFunction(iStopSound, void, 2, 2, "")
{
    T2DAppDelegate* del = (T2DAppDelegate*)[UIApplication sharedApplication].delegate;
    [del stopSound:dAtoi(argv[1])];
}

ConsoleFunction(iStopSoundByURL, void, 2, 2, "")
{
    T2DAppDelegate* del = (T2DAppDelegate*)[UIApplication sharedApplication].delegate;
    [del stopSoundByURL:[NSString stringWithUTF8String:argv[1]]];
}

ConsoleFunction(iSoundIsPlaying, bool, 2, 2, "")
{
    T2DAppDelegate* del = (T2DAppDelegate*)[UIApplication sharedApplication].delegate;
    return [del isSoundPlaying:dAtoi(argv[1])];
}

ConsoleFunction(iUnpauseSound, bool, 2, 2, "")
{
    T2DAppDelegate* del = (T2DAppDelegate*)[UIApplication sharedApplication].delegate;
    return [del unpauseSound:dAtoi(argv[1])];
}

ConsoleFunction(iStopAllSound, void, 1, 1, "")
{
    T2DAppDelegate* del = (T2DAppDelegate*)[UIApplication sharedApplication].delegate;
    [del stopAllSound];
}

ConsoleFunction(iPauseSound, void, 2, 2, "")
{
    T2DAppDelegate* del = (T2DAppDelegate*)[UIApplication sharedApplication].delegate;
    [del pauseSound:dAtoi(argv[1])];
}

ConsoleFunction(iPauseAllSound, void, 1, 1, "")
{
    T2DAppDelegate* del = (T2DAppDelegate*)[UIApplication sharedApplication].delegate;
    [del toggleSound];
}

-(bool)isSoundPlaying:(int)castID
{
    NSArray* tempSounds = _sounds;
    for(AVAudioPlayer* player in tempSounds)
    {
        if(player.tag == castID)
            return YES;
    }
    return NO;
}

-(void)toggleSound
{
    soundPaused = !soundPaused;
    if(soundPaused)
    {
        NSArray* tempSounds = _sounds;
        for(AVAudioPlayer* player in tempSounds)
        {
            if(player.tag != DEAD_SOUND)
                [player pause];
        }
    }
    else
    {
        NSArray* tempSounds = _sounds;
        for(AVAudioPlayer* player in tempSounds)
        {
            if(player.tag != DEAD_SOUND)
                [player play];
        }
    }
}

-(void)stopAllSound
{
    NSArray* tempSounds = _sounds;
    for(AVAudioPlayer* player in tempSounds)
    {
        player.tag = DEAD_SOUND;
        [player stop];
    }
    
    [_sounds removeAllObjects];
}

-(void)fadeSound:(int)castID
{
    NSArray* tempSounds = _sounds;
    for(AVAudioPlayer* player in tempSounds)
    {
        if(player.tag == castID)
        {
            [player fadeOut];
            break;
        }
    }
}

-(void)stopSound:(int)castID
{
    NSArray* tempSounds = _sounds;
    for(AVAudioPlayer* player in tempSounds)
    {
        if(player.tag == castID)
        {
            player.tag = DEAD_SOUND;
            [player stop];
            break;
        }
    }
}

-(void)stopSoundByURL:(NSString*)fullURL
{
    NSString* url = [[fullURL componentsSeparatedByString:@"/"] lastObject];
    
    NSArray* tempSounds = _sounds;
    for(AVAudioPlayer* player in tempSounds)
    {
        NSString* lurl = [[[player.url absoluteString] componentsSeparatedByString:@"/"] lastObject];
        
        if([lurl isEqualToString:url])
            [self fadeSound:player.tag];
    }
}

-(bool)unpauseSound:(int)castID
{
    NSArray* tempSounds = _sounds;
    for(AVAudioPlayer* player in tempSounds)
    {
        if(player.tag == castID && player.tag != DEAD_SOUND)
        {
            [player play];
            return YES;
        }
    }
    return NO;
}

-(void)pauseSound:(int)castID
{
    NSArray* tempSounds = _sounds;
    for(AVAudioPlayer* player in tempSounds)
    {
        if(player.tag == castID && player.tag != DEAD_SOUND)
        {
            [player pause];
            break;
        }
    }
}

- (int)playSound:(NSString*)sound withFormat:(NSString*)format shouldLoop:(bool)loop

{
    int tag = soundCount++;
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void)
                   {
                       //Background Thread
                       NSString *soundFilePath = [[NSBundle mainBundle] pathForResource: sound ofType: format];
                       //NSString *soundFilePath = @"modules/TNT/1/assets/audio/boom.wav";
                       //NSLog(@"File %@",sound);
                       //NSLog(@"Path %@",soundFilePath);
                       
                       
                       AVAudioPlayer *audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:soundFilePath] error:nil];
                       
                       if(audioPlayer)
                       {
                           audioPlayer.delegate = self;
                           audioPlayer.tag = tag;
                           
                           if(loop)
                               audioPlayer.numberOfLoops = -1;
                           else
                               audioPlayer.numberOfLoops = 0;
                           
                           @try {
                               [audioPlayer prepareToPlay];
                               [audioPlayer play];
                           }
                           @catch (NSException *exception) {
                               NSLog(@"Can't play %@",sound);
                           }
                           @finally {
                               dispatch_async(dispatch_get_main_queue(), ^(void)
                                              {
                                                  [_sounds addObject:audioPlayer];
                                              });
                           }
                       }
                   });
    
    return tag;
}

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    player.tag = DEAD_SOUND;
}

- (void)audioPlayerDecodeErrorDidOccur:(AVAudioPlayer *)player error:(NSError *)error
{
    NSLog(@"Error: %@",error);
    player.tag = DEAD_SOUND;
    [player stop];
}

@end