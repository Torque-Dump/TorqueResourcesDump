//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

// The intent of this object is that it will allow iPhone features to be used
// by various parts of the torque iPhone platform, without having to include
// the <UIKit/UIKit.h> header(s), or any extra Torque headers.

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>//CG Audio
//CG Audio

@interface AVAudioPlayer (TaggedAudioPlayer)
@property int tag;
-(void)fadeOut;
@end

//CG Audio
@interface TGBAppDelegate : NSObject <UIApplicationDelegate, AVAudioPlayerDelegate> {
	IBOutlet UIWindow *window;
    
    int soundCount;   //CG Audio
    bool soundPaused; //CG Audio
    bool soundWait; //CG Audio
}



@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, strong)NSMutableArray *sounds; //CG Audio

@end
