//-----------------------------------------------------------------------------
// Simple Spellcasting resource
// Copyright Lukas J�rgensen, 2012
//-----------------------------------------------------------------------------

// Simply execute all scripts

exec("./commands.cs");
exec("./movement.cs");
exec("./spellindicator.cs");
exec("./raycasts.cs");
