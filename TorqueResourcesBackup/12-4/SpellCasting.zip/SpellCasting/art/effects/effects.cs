//-----------------------------------------------------------------------------
// Simple Spellcasting resource
// Copyright Lukas J�rgensen, 2012
//-----------------------------------------------------------------------------

// Load all the particles, projectiles and other datablocks which is needed for 
//  the spell effects.

//exec("./fireballProjectile.cs");
exec("./particles.cs");