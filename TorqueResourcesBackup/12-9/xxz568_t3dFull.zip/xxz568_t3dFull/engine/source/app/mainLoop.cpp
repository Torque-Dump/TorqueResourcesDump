.
.
.
.
// For the TickMs define... fix this for T2D...
#include "T3D/gameBase/processList.h"

//ADD THIS:
// Phantom139: Do not alter these defines. PGDMain.h controls which of these packages will be
//  loaded based on the other definitions found in that file.
#define _LOADAUTH 1
#include "PGD/Control/PGDMain.h"
.
.
.
.
.
void StandardMainLoop::init()
{
.
.
.
   // Set up the resource manager and get some basic file types in it.
   Con::init();
   Platform::initConsole();
   NetStringTable::create();

	//ADD THIS BLOCK
   #ifdef _PGDAUTH
      Con::printf("PGD: xxz568 package activating...");
      xxz568::create();
   #endif
   //END
.
.
}