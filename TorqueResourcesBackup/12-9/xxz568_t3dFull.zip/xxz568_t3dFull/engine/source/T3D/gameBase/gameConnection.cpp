//Add this to the  bottom of the file

/**
PGD Authentiaction (xxz568)
**/
#ifndef _PGDAUTH
DefineConsoleMethod(GameConnection, verifyClientSignature, void, (),, "(Disabled)") {  
   Con::printf("This executable is running on a non-auth based game, this function has been disabled for that purpose.");
}
#endif

#ifdef _PGDAUTH
DefineConsoleMethod(GameConnection, verifyClientSignature, void, (const char *sig, const char *det),, "verifys the client signature on the server-side") {  
   bool result = object->verifyClientSig(sig, det);  
   if(result == true) {  
     
   }  
   else {  
      Con::printf("Client Disconnected, invalid account signature.");  
      object->setDisconnectReason("The server has denied your account certificate");  
      object->deleteObject();  
   }  
}  
  
bool GameConnection::verifyClientSig(const char * signature, const char * details) {  
   std::string toWhrl = details;  
   std::string toWhrl_final = toWhrl;  
   toWhrl_final = cryptoPackage->whirlpool(toWhrl);  
   std::string hexSig;  
   hexSig.assign(std::string(signature));  
   //  
   bool result = cryptoPackage->caVerify(toWhrl_final, hexSig);  
   return result;  
}  
#endif