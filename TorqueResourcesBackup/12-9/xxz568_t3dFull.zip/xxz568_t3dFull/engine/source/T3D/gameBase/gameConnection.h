//Headers
//Add this after all of the others
#define _LOADAUTH 1
#include "PGD/Control/PGDMain.h"

class GameConnection : public NetConnection
{
	.
   .
	.
public:
	F32 getDamageFlash() const { return mDamageFlash; }
   F32 getWhiteOut() const { return mWhiteOut; }

   void setBlackOut(bool fadeToBlack, S32 timeMS);
   F32  getBlackOut();

   //Add this!
   #ifdef _PGDAUTH
      bool verifyClientSig(const char * signature, const char * details);
   #endif
}