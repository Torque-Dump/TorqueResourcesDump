/**
Phantom Games Development MAIN control header
This file is the central "command and control" for all of the PGD project
source code details and information...
**/

//System build settings
#define _PGDAUTH 1 //DEFINE 1 to build with XXZ568 Package

/**
Please do not modify anthing below this line!
This is the initiator handle, IE: it tells the files which headers to load
**/
#ifdef _PGDAUTH
   #ifdef _LOADAUTH
      #include "PGD/Crypto/cryptoPackage.h"
   #endif
#endif