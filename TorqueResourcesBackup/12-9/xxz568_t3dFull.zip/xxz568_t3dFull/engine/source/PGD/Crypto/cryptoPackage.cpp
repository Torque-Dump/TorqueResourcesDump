/**
cryptoPackage.cpp
source cryptoPP function calls

Phantom Games Development Authentication Package xxz568
Package Version: 1.5, Compiled Sept. 1, 2012
Created By: Robert Clayton Fritzen (Phantom139)
Copyright 2011, Phantom Games Development

Libraries Used In Development: CryptoPP

Credit to the security and cryptography functions go to Wei Dai, who created the CryptoPP library, 
Phantom Games Development does not take any credit for these functions, or the provided function examples
used from the CryptoPP Library, all rights and provided licence agreements to those are reserved 
by the CryptoPP Group and their respective authors.

Unauthorized usage of this system is strictly prohibited, and may be met with legal measures.
This system cannot be used in countries to which the United States Of America has embargoed goods to.
**/

#include <fstream>
#include "cryptoPackage.h"

xxz568 *cryptoPackage = NULL;
xxz568::xxz568() {}
xxz568::~xxz568() {}
void xxz568::create() {
   if(cryptoPackage == NULL) {
      cryptoPackage = new xxz568();
   }
}

void xxz568::destroy() {
   if(cryptoPackage != NULL) {
      delete cryptoPackage;
	  cryptoPackage = NULL;
   }
}

InvertibleRSAFunction xxz568::rsaGenerate(int bytes) {
   AutoSeededRandomPool rng;
   InvertibleRSAFunction parameters;

   while(parameters.Validate(rng, 3) == false) {
      parameters.GenerateRandomWithKeySize(rng, bytes);
      //parameters.SetPublicExponent(65537);
      RSA::PrivateKey privateKey(parameters);
      RSA::PublicKey publicKey(parameters);
   }

   //bool test = parameters.Validate(rng, 3);
   //cout << "Valid: " << test << endl;

   return parameters;
}

InvertibleRSAFunction xxz568::rsaLoad(std::string e, std::string n, std::string d) {
   InvertibleRSAFunction parameters;
   parameters.Initialize((const Integer)n.c_str(), (const Integer)e.c_str(), (const Integer)d.c_str());
   return parameters;
}

int xxz568::rsaSign(InvertibleRSAFunction rsa, std::string message, std::string &output) {
   AutoSeededRandomPool rng;
   RSA::PrivateKey privateKey(rsa);
   std::string holder;

   RSASSA_PKCS1v15_SHA_Signer signer(privateKey);

   StringSource(message, true, 
       new SignerFilter(rng, signer,
           new StringSink(holder)
      ) // SignerFilter
   ); // StringSource

   HexEncode(holder, output);

   return 1;
}

bool xxz568::rsaVerify(InvertibleRSAFunction rsa, std::string message, std::string textSig) {
   
   RSA::PublicKey publicKey(rsa);
   std::string holder;

   try {
      RSASSA_PKCS1v15_SHA_Verifier verifier(publicKey);

      HexDecode(textSig, holder);

      StringSource(message+holder, true,
          new SignatureVerificationFilter(
              verifier, NULL,
              SignatureVerificationFilter::THROW_EXCEPTION
         ) // SignatureVerificationFilter
      ); // StringSource
   }
   catch(std::exception e) {
      return false;
   }

   return true;
}

const char * xxz568::caPublic() {
   return "bf60ffc404f4d0523b1abfa5229f3d46660b9d4459bac82cd334ce02e88c4c3df38b538c91cd344a5e125112c73e21c16bd3d275db541b7ba46db594fc0e010315ff314638d64169dd10392803999f17b5b7acc858f1eac66a2d92b5b4b580e34b02777cc47b878a81e8588aec1f0866f280f0d5343caf077bc6eff0b5e39fa3";
}

const char * xxz568::AESFileKey() { return "PhantomDevAESEncryptionCycles"; }

std::string xxz568::sha1(std::string text) {
   CryptoPP::SHA1 hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

std::string xxz568::whirlpool(std::string text) {
   CryptoPP::Whirlpool hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

std::string xxz568::tiger(std::string text) {
   CryptoPP::Tiger hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

std::string xxz568::sha224(std::string text) {
   CryptoPP::SHA224 hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

std::string xxz568::sha256(std::string text) {
   CryptoPP::SHA256 hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

std::string xxz568::sha384(std::string text) {
   CryptoPP::SHA384 hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

std::string xxz568::sha512(std::string text) {
   CryptoPP::SHA512 hash;  

   std::string digest;
   // Thank you, Wei Dai, for making this possible:
   CryptoPP::StringSource foo(text, true,
      new CryptoPP::HashFilter(hash,
	     new CryptoPP::HexEncoder(
            new CryptoPP::StringSink(digest), false)));

   return digest;
}

//xxz568 AES Encryption/Decryption, Modifications for 1.1
//Addition of PBKDF, and AES fixes using SecByteBlock
//Credit to these modifications go to: Geoff Beier, geoffbeier@gmail.com
int xxz568::AESEncrypt(std::string key, std::string input, std::string &output, unsigned int PBKDFiterations) {

   std::string hashedKey = whirlpool(key);

   AutoSeededX917RNG<AES> rng;

   SecByteBlock iv(AES::BLOCKSIZE);
   rng.GenerateBlock(iv,iv.size());

   // See NIST SP 800-132 for detailed recommendations on length, generation and
   // format of the salt. This test program will just generate a random one. That
   // might not be sufficient for every application.
   SecByteBlock pwsalt(AES::DEFAULT_KEYLENGTH);
   rng.GenerateBlock(pwsalt,pwsalt.size());

   SecByteBlock derivedkey(AES::DEFAULT_KEYLENGTH);
   PKCS5_PBKDF2_HMAC<SHA256> pbkdf;
   pbkdf.DeriveKey(
      // buffer that holds the derived key
	  derivedkey, derivedkey.size(),
	   // purpose byte. unused by this PBKDF implementation.
	   0x00,
	   // password bytes. careful to be consistent with encoding...
	   (byte *) hashedKey.data(), hashedKey.size(),
	   // salt bytes
	   pwsalt, pwsalt.size(),
	   // iteration count. See SP 800-132 for details. You want this as large as you can tolerate.
	   // make sure to use the same iteration count on both sides...
	   PBKDFiterations
   );
   std::string ciphertext;

   CBC_Mode<AES>::Encryption aesencryption(derivedkey,derivedkey.size(),iv);
   // encrypt message using key derived above, storing the hex encoded result into ciphertext
   StringSource encryptor(input, true,
      new StreamTransformationFilter(aesencryption, new HexEncoder( new StringSink(ciphertext), false))
   );
   std::string hexsalt, hexiv;
   ArraySource saltEncoder(pwsalt,pwsalt.size(), true, new HexEncoder(new StringSink(hexsalt), false));
   ArraySource ivEncoder(iv,iv.size(), true, new HexEncoder(new StringSink(hexiv), false));

   output.assign(hexsalt);
   output.append(hexiv);
   output.append(ciphertext);
   //
   return 1;
}

int xxz568::AESDecrypt(std::string key, std::string input, std::string &output, unsigned int PBKDFiterations) {

   std::string hashedKey = whirlpool(key);

   std::string saltPull, ivPull, cipherPull, store;
   store.assign(input);
   saltPull.assign(store.substr(0, 32));
   store.assign(store.substr(32, store.length()));
   ivPull.assign(store.substr(0, 32));
   store.assign(store.substr(32, store.length()));
   cipherPull.assign(store.substr(0, store.length()));

   // now recover the plain text given the password, salt, IV and ciphertext
   PKCS5_PBKDF2_HMAC<SHA256> pbkdf;
   SecByteBlock recoveredkey(AES::DEFAULT_KEYLENGTH);
   SecByteBlock recoveredsalt(AES::DEFAULT_KEYLENGTH);
   StringSource saltDecoder(saltPull,true,new HexDecoder(new ArraySink(recoveredsalt, recoveredsalt.size())));
   pbkdf.DeriveKey(recoveredkey, recoveredkey.size(), 0x00, (byte *) hashedKey.data(), hashedKey.size(),
      recoveredsalt, recoveredsalt.size(), PBKDFiterations);
   SecByteBlock recoverediv(AES::BLOCKSIZE);
   StringSource ivDecoder(ivPull,true,new HexDecoder(new ArraySink(recoverediv, recoverediv.size())));
   try {
      CBC_Mode<AES>::Decryption aesdecryption(recoveredkey, recoveredkey.size(), recoverediv);
      StringSource decryptor(cipherPull, true, new HexDecoder(
         new StreamTransformationFilter(aesdecryption, new StringSink(output))
      ));
   }
   catch(CryptoPP::Exception e) {
	  output = "Decryption Error: ";
	  output.append(e.GetWhat());
   }
   return 1;
}

int xxz568::HexEncode(std::string input, std::string &output) {
   CryptoPP::StringSource foo(input, true,
	  new CryptoPP::HexEncoder(
         new CryptoPP::StringSink(output), false));
   return 1;
}

int xxz568::HexDecode(std::string input, std::string &output) {
   CryptoPP::StringSource foo(input, true,
	  new CryptoPP::HexDecoder(
         new CryptoPP::StringSink(output)));
   return 1;
}

unsigned int xxz568::getUTC() {
   unsigned int uiTime = static_cast<unsigned int>( time( NULL ) );
   return uiTime;
}

long xxz568::getPGDAssignedDateInteger() {
   long PADI;
   time_t rawtime;
   struct tm * timeinfo;
   char buffer [80];

   time ( &rawtime );
   timeinfo = localtime ( &rawtime );

   strftime (buffer,80,"%Y%m%d",timeinfo);
   PADI = atoi(buffer);
   return PADI;
}

int xxz568::Base64Encode(std::string input, std::string &output) {
   StringSink* sink = new StringSink(output);
   Base64Encoder* base64_enc = new Base64Encoder(sink);
   StringSource source(input, true, base64_enc);
   return 1;
}

int xxz568::Base64Decode(std::string input, std::string &output) {
   StringSink* sink = new StringSink(output);
   Base64Decoder* base64_dec = new Base64Decoder(sink);
   StringSource source(input, true, base64_dec);
   return 1;
}

std::string xxz568::IntegerToString(const Integer refs) {
   std::ostrstream oss;
   oss << refs;
   oss << std::hex << refs; // use this for hex output
   std::string s(oss.str());
   s = s.substr(0, s.find_first_of("."));
   return s;// output is now in s
}

bool xxz568::caVerify(std::string message, std::string signature) {
   std::string dec, fin;
   fin.assign(caPublic());
   fin.append("h");
   Integer rsaPub(fin.c_str()), rsaexp("65537");
   
   std::string holder;

   try {
      RSASSA_PKCS1v15_SHA_Verifier verifier;
      verifier.AccessKey().Initialize(rsaPub, rsaexp);

      HexDecode(signature, holder);

      StringSource(message+holder, true,
          new SignatureVerificationFilter(
              verifier, NULL,
              SignatureVerificationFilter::THROW_EXCEPTION
         ) // SignatureVerificationFilter
      ); // StringSource
   }
   catch(CryptoPP::Exception e) {
      return false;
   }

   return true;
}

const char * xxz568::iToCC(int in) {
   char newVal[sizeof(int)];
	_itoa(in, newVal, 10);
	return newVal;
}

std::string xxz568::rsaEncrypt(Integer e, Integer n, std::string message) {
   AutoSeededRandomPool rng;
   std::string holder, output;

   RSAES_OAEP_SHA_Encryptor enc;
   enc.AccessKey().Initialize(n, e);

   StringSource(message, true, 
       new PK_EncryptorFilter(rng, enc,
           new StringSink(holder)
      ) // SignerFilter
   ); // StringSource

   HexEncode(holder, output);

   return output;
}

CryptoPP::Integer xxz568::load(std::string inbound, int r) {
   std::string move;
   move.assign(inbound);
   switch(r) {
	  case 10:
	     break;
	  case 16:
	     move.append("h");
		 break;
	  default:
	     break;
   }
   CryptoPP::Integer hold(move.c_str());
   return hold;
}


/**
 AES FILE ENCRYPTION CYCLES
**/
int xxz568::AESEnc_File(std::string key, std::string path, unsigned int PBKDFiterations) {

   std::string hashedKey = whirlpool(key);

   AutoSeededX917RNG<AES> rng;

   SecByteBlock iv(AES::BLOCKSIZE);
   rng.GenerateBlock(iv,iv.size());

   // See NIST SP 800-132 for detailed recommendations on length, generation and
   // format of the salt. This test program will just generate a random one. That
   // might not be sufficient for every application.
   SecByteBlock pwsalt(AES::DEFAULT_KEYLENGTH);
   rng.GenerateBlock(pwsalt,pwsalt.size());

   SecByteBlock derivedkey(AES::DEFAULT_KEYLENGTH);
   PKCS5_PBKDF2_HMAC<SHA256> pbkdf;
   pbkdf.DeriveKey(
      // buffer that holds the derived key
	  derivedkey, derivedkey.size(),
	   // purpose byte. unused by this PBKDF implementation.
	   0x00,
	   // password bytes. careful to be consistent with encoding...
	   (byte *) hashedKey.data(), hashedKey.size(),
	   // salt bytes
	   pwsalt, pwsalt.size(),
	   // iteration count. See SP 800-132 for details. You want this as large as you can tolerate.
	   // make sure to use the same iteration count on both sides...
	   PBKDFiterations
   );

   CBC_Mode<AES>::Encryption aesencryption(derivedkey,derivedkey.size(),iv);
   std::string hexsalt, hexiv;
   ArraySource saltEncoder(pwsalt,pwsalt.size(), true, new HexEncoder(new StringSink(hexsalt), false));
   ArraySource ivEncoder(iv,iv.size(), true, new HexEncoder(new StringSink(hexiv), false));

   std::string storeThat, fileInputData, fileOut;
   std::ifstream inData;
	inData.clear();
   inData.open(path.c_str());
   while(!inData.eof()) {
	  std::getline(inData, storeThat);
	  fileInputData.append(storeThat).append("\n");
	  storeThat = "";
   }

   StringSource encryptor(fileInputData, true,
      new StreamTransformationFilter(aesencryption, new HexEncoder( new StringSink(fileOut), false))
   );

   std::ofstream fileEdit(path.c_str(), std::ios::out);
	fileEdit << "Phantom Games Development: " << path.c_str() << "\n";
   fileEdit << hexsalt << hexiv;
   fileEdit << fileOut;
   fileEdit.close();
   //
   return 1;
}

int xxz568::AESDec_File(std::string key, std::string path, unsigned int PBKDFiterations) {

   std::string hashedKey = whirlpool(key);
   std::string store, saltPull, ivPull, cipherData, outData;
   
   std::ifstream inReader;//(path.c_str(), std::ios::in);
	inReader.clear();
	inReader.open(path.c_str(), std::ios::in);
	//skip the first line
	std::getline(inReader, store);
	store = ""; //empty it...
	//
   std::getline(inReader, store); //read the first line (encryption data);
 
   saltPull.assign(store.substr(0, 32));
   store.assign(store.substr(32, store.length()));
   ivPull.assign(store.substr(0, 32));
	store.assign(store.substr(32, store.length()));
	cipherData.append(store);
   //if anything is left, grab it.
   while(!inReader.eof()) {
     std::getline(inReader, store);
	  cipherData.append(store);
	  store = "";
   }
	inReader.close();
   // now recover the plain text given the password, salt, IV and ciphertext
   PKCS5_PBKDF2_HMAC<SHA256> pbkdf;
   SecByteBlock recoveredkey(AES::DEFAULT_KEYLENGTH);
   SecByteBlock recoveredsalt(AES::DEFAULT_KEYLENGTH);
   StringSource saltDecoder(saltPull,true,new HexDecoder(new ArraySink(recoveredsalt, recoveredsalt.size())));
   pbkdf.DeriveKey(recoveredkey, recoveredkey.size(), 0x00, (byte *) hashedKey.data(), hashedKey.size(),
      recoveredsalt, recoveredsalt.size(), PBKDFiterations);
   SecByteBlock recoverediv(AES::BLOCKSIZE);
   StringSource ivDecoder(ivPull,true,new HexDecoder(new ArraySink(recoverediv, recoverediv.size())));
   try {
      CBC_Mode<AES>::Decryption aesdecryption(recoveredkey, recoveredkey.size(), recoverediv);
      StringSource decryptor(cipherData, true, new HexDecoder(
         new StreamTransformationFilter(aesdecryption, new StringSink(outData))
      ));
   }
   catch(CryptoPP::Exception e) {
	  cipherData = "Decryption Error: ";
	  cipherData.append(e.GetWhat());
   }

   //_unlink(path.c_str());
   std::ofstream fileReplace(path.c_str(), std::ios::out); //overwrite existing.
   fileReplace << outData << std::endl;
   fileReplace.close();

   return 1;
}