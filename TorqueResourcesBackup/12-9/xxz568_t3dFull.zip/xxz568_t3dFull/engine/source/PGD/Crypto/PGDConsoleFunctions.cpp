/**
Phantom Games Development:
Cryptography Based Console Functions/Methods

Created by: Robert C. Fritzen

You are more than welcome to modify and use this file, please do not remove this header line and just
slap your name on it, and please, share any improvements or bug fixes with the GG community.

*** Not For Use in any Other Engine than Torque 3D
**/
#pragma warning (disable : 4996)
#pragma warning (disable : 4239)

#define _LOADAUTH 1
#define _LOADALL 1
#include "PGD/Control/PGDMain.h"

#include "platform/platform.h"
#include "console/console.h"
#include "console/consoleInternal.h"
#include "console/engineAPI.h"

#include <fstream>
#include <string>
using namespace std; 

//console functions
//ConsoleFunctionGroupBegin(PGDCryptoFunctions, "PGD's crypto library functions for RSA, AES, and Hashing.");
#ifndef _PGDAUTH
   //inform the user that this .exe is not using the crypto lib.
   DefineEngineFunction(getFileMD5, void, (),, "(Disabled)") {
      Con::printf("This executable is running on a non-auth based game, this function has been disabled for that purpose.");
   }
   DefineEngineFunction(whirlpool, void, (),, "(Disabled)") {
      Con::printf("This executable is running on a non-auth based game, this function has been disabled for that purpose.");
   }
   DefineEngineFunction(sha1, void, (),, "(Disabled)") {
      Con::printf("This executable is running on a non-auth based game, this function has been disabled for that purpose.");
   }
   DefineEngineFunction(generateRSA2048, void, (),, "(Disabled)") {
      Con::printf("This executable is running on a non-auth based game, this function has been disabled for that purpose.");
   }
   DefineEngineFunction(base64encode, void, (),, "(Disabled)") {
      Con::printf("This executable is running on a non-auth based game, this function has been disabled for that purpose.");
   }
   DefineEngineFunction(base64decode, void, (),, "(Disabled)") {
      Con::printf("This executable is running on a non-auth based game, this function has been disabled for that purpose.");
   }
   DefineEngineFunction(getUTC, void, (),, "(Disabled)") {
      Con::printf("This executable is running on a non-auth based game, this function has been disabled for that purpose.");
   }
   DefineEngineFunction(encryptAccountKey, void, (),, "(Disabled)") {
      Con::printf("This executable is running on a non-auth based game, this function has been disabled for that purpose.");
   }
   DefineEngineFunction(DecryptAccount, void, (),, "(Disabled)") {
      Con::printf("This executable is running on a non-auth based game, this function has been disabled for that purpose.");
   }
   DefineEngineFunction(StoreSuccessfulLogin, void, (),, "(Disabled)") {
      Con::printf("This executable is running on a non-auth based game, this function has been disabled for that purpose.");
   }
   DefineEngineFunction(GatherAccountDetails, void, (),, "(Disabled)") {
      Con::printf("This executable is running on a non-auth based game, this function has been disabled for that purpose.");
   }
   DefineEngineFunction(AESEncrypt, void, (),, "(Disabled)") {
      Con::printf("This executable is running on a non-auth based game, this function has been disabled for that purpose.");
   }
   DefineEngineFunction(AESDecrypt, void, (),, "(Disabled)") {
      Con::printf("This executable is running on a non-auth based game, this function has been disabled for that purpose.");
   }
#endif

DefineEngineFunction(ConvertNumber, const char *, (const char * input, const char * newBase),, "converts a number") {
   int number = atoi(input);
   char * final = (char *)malloc(strlen(input));
   _itoa(number, final, atoi(newBase));

   return (const char *)final;
}

#ifdef _PGDAUTH
DefineEngineFunction(getFileMD5, const char *, (const char *input),, "Obtain a file's MD5 Hash") {
   std::string result;  
   //check if the file exists  
   if(!Platform::isFile(input)) {  
      //do not remove this if!!! you WILL get a crash if you do and point to a non existing file.  
      return "File Not Found";  
   }  
   //  
   const char * done = (const char *)malloc(64);  
  
   CryptoPP::Weak::MD5 hash;  
   CryptoPP::FileSource(input,true,new  
   CryptoPP::HashFilter(hash,new CryptoPP::HexEncoder(new  
   CryptoPP::StringSink(result),false)));   
  
   strcpy((char *)done, result.c_str());  
  
   return done;  
}

DefineEngineFunction(whirlpool, const char *, (const char *input),, "Hashes a string with the whirlpool hash") {
   std::string output_hash = cryptoPackage->whirlpool(input);
   const char *done = (const char *)malloc(128);
   strcpy((char *)done, output_hash.c_str());
   return done;
}

DefineEngineFunction(sha1, const char *, (const char *input),, "Hashes a string with the sha1 hash") {
   std::string output_hash = cryptoPackage->sha1(input);
   const char *done = (const char *)malloc(64);
   strcpy((char *)done, output_hash.c_str());
   return done;
}

DefineEngineFunction(generateRSA2048, int, (),, "generates an RSA 2048 keypair and stored them in a variable") {
   //generate RSA
   Con::printf("Generating Account Key");
   InvertibleRSAFunction pgdKey = cryptoPackage->rsaGenerate(1024);
   Con::printf("Storing Account Key");
   Con::setVariable("$Account::RSAKey::E", cryptoPackage->IntegerToString(pgdKey.GetPublicExponent()).c_str());
   Con::setVariable("$Account::RSAKey::N", cryptoPackage->IntegerToString(pgdKey.GetModulus()).c_str());
   Con::setVariable("$Account::RSAKey::D", cryptoPackage->IntegerToString(pgdKey.GetPrivateExponent()).c_str());
   Con::printf("Done Storing...");

   return 1;
}

DefineEngineFunction(base64encode, const char *, (const char *input),, "(string) returns the base64 encoded value of a string") {
   std::string output_b64E; 
   cryptoPackage->Base64Encode(input, output_b64E);
   return output_b64E.c_str();
}

DefineEngineFunction(base64decode, const char *, (const char *input),, "(string) returns the base64 decoded value of a string") {
   std::string output_b64D;
   cryptoPackage->Base64Decode(input, output_b64D);
   return output_b64D.c_str();
}

DefineEngineFunction(getUTC, int, (),,"(string) returns the UTC time string") {
   unsigned int utc = cryptoPackage->getUTC();
   int out = (int)utc;
   return out;
}

DefineEngineFunction(AESEncrypt, const char *, (const char *input, const char *key),, "(string) [input, key] AES Encrypt") {  
   std::string out;  
   cryptoPackage->AESEncrypt(string(key), string(input), out, 1024);  
      
   char *str = Con::getReturnBuffer(out.size() +1);  
   dStrcpy(str, out.c_str());  
      
   return str;  
}  

DefineEngineFunction(AESDecrypt, const char *, (const char *input, const char *key),, "(string) [input, key] AES Decrypt") {  
   std::string out;  
   cryptoPackage->AESDecrypt(string(key), string(input), out, 1024);  
      
   char *str = Con::getReturnBuffer(out.size() +1);  
   dStrcpy(str, out.c_str());  
      
   return str;  
}  

DefineEngineFunction(encryptAccountKey, const char *, (const char *key, const char *D_data),, "(string) encrypts the private account key sector using AES-256-CBC") {
   //Variables: D Exponent, AES_KEY
   std::string holderString, encoded, decodeResult;
   try {
      cryptoPackage->AESEncrypt(string(key), string(D_data), holderString, 1024);
   }
   catch(CryptoPP::Exception e) {
      holderString = "encryptfail";
	  Con::errorf("encryptAccountKey: Failed, %s", e.GetWhat().c_str());
   }
   
   char *encodedResult = Con::getReturnBuffer(holderString.size() +1);  
   dStrcpy(encodedResult, holderString.c_str());  

   return encodedResult;  
}

DefineEngineFunction(DecryptAccount, const char *, (const char *data, const char *decHash, const char *key),, "(string) decrypts an account running AES-CBC cipher") {
   //vars: encoded exponent, decrypted hash, password input
   std::string holderStringDec, decodedToStr, fin;
   std::string aes_cipher_key = key;
   aes_cipher_key.append(decHash);
   // run AES rounds, then compare to decoded hash
   std::string decodeHex = data;
   cryptoPackage->AESDecrypt(aes_cipher_key, decodeHex, holderStringDec, 1024);
   if(cryptoPackage->whirlpool(holderStringDec).compare(std::string(decHash)) == 0) {
      fin = holderStringDec;
   }
   else {
      fin = "INVALID_PASSWORD";
   }
   //Con::printf("Account Password Check Cycle:\nWant: %s\nGot:  %s\nDEEMS: %s", decHash, holderStringDec.c_str(), fin.c_str());

   char *str = Con::getReturnBuffer(fin.size() +1);  
   dStrcpy(str, fin.c_str());  
      
   return str;
}

DefineEngineFunction(StoreSuccessfulLogin, int, (const char *E, const char *N, const char *S),, "stores account exponents in a data structure") {
   char * EE = (char *)malloc(512);
   char * NE = (char *)malloc(512);
   //char * DE = (char *)malloc(512);
   char * SE = (char *)malloc(512);
   //
   strcpy(EE, E);
   strcpy(NE, N);
   //strcpy(DE, argv[3]);
   strcpy(SE, S);

   Con::setVariable("$ClientKey_E", EE);
   Con::setVariable("$ClientKey_N", NE);
   Con::setVariable("$ClientKey_S", SE);
   return 1;
}

DefineEngineFunction(GatherAccountDetails, void, (const char *det, const char *E, const char *N, const char *S),, 
	"(string) returns a long appended string of account details (E, N, SIG)") {
   //RSA_Verify Time :D
   //what is needed:
      //1: Full Details: whirlpool($guid@$name)
      //2: The Signature: base64
   //We are given the guid, email, and name by the client, attach E and N, then calc a whirlpool hash.
   std::string toWhrl = det;
   toWhrl.append(E);
   toWhrl.append(N);
   std::string toWhrl_final = toWhrl;
   toWhrl_final = cryptoPackage->whirlpool(toWhrl);
   //
   std::string hexSig;
   hexSig.assign(string(S));
   //Con::printf("CA_V: Debug: %s | %s | %s", toWhrl.c_str(), toWhrl_final.c_str(), hexSig.c_str());
   //
   bool rsaverifyresult = cryptoPackage->caVerify(toWhrl_final, hexSig);   
   if(rsaverifyresult != true) {
	   //Naughty Naughty... someone is using a bogus certificate
	   //Kill Them!!!
	   Con::printf("CA_Verify has denied this account certificate.");
	   Con::executef("MessageBoxOk", "Invalid Account", "Invalid Account Certificate");
	   Con::executef("disconnect");
	   return;
   }
   // give our client E/N in an appending sig to work with
   Con::setVariable("AuthenticationDetails", "");
   std::string worker;
   worker.assign(E);
   worker.append(N);
   Con::setVariable("AuthenticationDetails", worker.c_str());
   //give the client his signature too!
   Con::setVariable("AuthenticationSignature", "");
   std::string clientSig;
   clientSig.assign(S);
   Con::setVariable("AuthenticationSignature", clientSig.c_str());
   //
   Con::setVariable("AccountDetails", "");
   std::string hold;
   hold.assign(E);
   hold.append(":");
   hold.append(N);
   hold.append(":");
   hold.append(S);
   //Store it
   Con::setVariable("AccountDetails", hold.c_str());
   Con::printf("AccountDetails is stored.");
}
#endif