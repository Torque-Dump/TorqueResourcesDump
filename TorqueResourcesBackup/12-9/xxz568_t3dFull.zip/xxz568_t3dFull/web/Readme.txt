Install this auth folder somewhere on your website.

Then open the admin/globals.php file and read it. Then make all necessary adjustments to it!
