<?php

   function XXZHash($string) {
      $exterior = hash('whirlpool', $string);
      return $exterior;  
   }

   function getUTC() {
      return time();
   }
   
   function collapseEscape($str) {
      $exploded = explode($str);
      $out = "";
      for ($i = 0; $i < strlen($str); $i++)
         $out += "\\x" . bin2hex($exploded[$i]);
	
      return $out;
   }
   
   function expandEscape($str) {
      $out = "";
      for ($i = 0; $i < strlen($str); $i++)
         $out += "\\x" . bin2hex($str[$i]);
	
      return $out;
   }   
   
   function hex2bin($data) {
      $len = strlen($data);
      for($i=0;$i<$len;$i+=2) {
         $newdata .= pack("C",hexdec(substr($data,$i,2)));
      }
      return $newdata;
   }

function CA_private() {
   $privateKey = "-----BEGIN RSA PRIVATE KEY-----
MIICWwIBAAKBgQC/YP/EBPTQUjsav6Uinz1GZgudRFm6yCzTNM4C6IxMPfOLU4yR
zTRKXhJREsc+IcFr09J121Qbe6RttZT8DgEDFf8xRjjWQWndEDkoA5mfF7W3rMhY
8erGai2StbS1gONLAnd8xHuHioHoWIrsHwhm8oDw1TQ8rwd7xu/wteOfowIDAQAB
AoGAFJlOLj0SVLHlJrXmAln9cGxfZ6gJuG7/VCRk4C9Dmpk4c5CkmrTpoe+KLSvG
QkvD0+VSy9i1rteaFSzsQk0HkquAmyPtLJs81ItNPLN8BjR1rlnbe3yLaR2UurDl
S/x/1JgTSVgl4atChoSv9PsBToJZeqe+53tRFhhCNpbuLMECQQD39hGAJAuQ5ybd
optXYTqH0R0x+I+R/fyrYlWOYDEQfSrcSxO3nlWgQxhGafXWKoAsXw/WPCPBCbvc
TnloEnEzAkEAxZVUvW6z4i2B3Et/p3nft77CIHOz46FjASPs4/k/o0lFPg6+t/hY
/uyoLcP+0IONp5NKH8roADBcgG5Dp+/30QJAW1OsOnAMOoCIlhUv9cz/y8o/YIpW
BsVvbIg5TskrCRGw2ZZlWrnce7x6kmSwgQMCVlVk9dkMqiq1oHzexnAUdQJAWuyo
jXA3SZtlikoYGasFH9qiHSsBmnw3QlwU9KhL98mNGszQSXr5AX9IuZ7bUXtoobgv
QUgv0X5v4w5bBhpxMQJANrUvLkvSnGktDPrjl6DZMtk9BRgHlNw3RplcdOplAh77
nMQ0t4O0SeSVBzXsTsTWbZXzxm0+F6c3O5dlxCQg7w==
-----END RSA PRIVATE KEY-----";
      return $privateKey;
   }
function CA_public() {
   $publicKey = "-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC/YP/EBPTQUjsav6Uinz1GZgud
RFm6yCzTNM4C6IxMPfOLU4yRzTRKXhJREsc+IcFr09J121Qbe6RttZT8DgEDFf8x
RjjWQWndEDkoA5mfF7W3rMhY8erGai2StbS1gONLAnd8xHuHioHoWIrsHwhm8oDw
1TQ8rwd7xu/wteOfowIDAQAB
-----END PUBLIC KEY-----";
      return $publicKey;
   }
?>
