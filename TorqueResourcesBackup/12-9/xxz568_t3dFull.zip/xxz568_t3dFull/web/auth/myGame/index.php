<?php
   //requires
   require_once("pgdFunctions.php");
   require("../admin/globals.php");
   
   include_once("../admin/sources/php/Crypt/RSA.php");
   //-- end requires
   $mode = $_POST["authMode"];
   $current = "".substr(dirname($_SERVER[PHP_SELF]),strrpos(dirname($_SERVER[PHP_SELF]),'/') + 1)."";
   if(!isSet($mode)) {
      die("This portion of our site is off limits....");
   }
   $con = mysql_connect($XXZVariables["dbAccess"][$current], $XXZVariables["db_username"][$current], $XXZVariables["db_password"][$current]) or die("$"."INTERNAL_ERROR\n");
   mysql_select_db($XXZVariables["database"][$current], $con);
   //begin the processes here
   switch($mode) {
      case 1:
         //1: Check name
         //Phantom139: This is no longer active as of 3/28/12
         //All username checks are now directly handled during the registration message.
         $nameToTest = $_POST["name"];
         $cond = checkName($nameToTest, $con);
         if($cond == 0) {
            die("$"."PGD"."$"."NAME_OK");
         }
         else if($cond == 1) {
            die("$"."PGD"."$"."NERR_EMPTY");
         }
         else if($cond == 2) {
            die("$"."PGD"."$"."NERR_TOOSMALL");
         }
         else if($cond == 3) {
            die("$"."PGD"."$"."NERR_TOOLONG");
         }   
         else if($cond == 4) {
            die("$"."PGD"."$"."NERR_INVLDCHRS");
         }  
         else if($cond == 5) {
            die("$"."PGD"."$"."NERR_TAKEN");
         }                          
      case 2:
         //2: Verify Data, Check Key, and Sign Certificate
         //Stage 1: Data verification
         $name = $_POST["name"];
         $cond = checkName($name, $con);
         if($cond == 1 || $cond == 2 || $cond == 3 || $cond == 4) {
            die("$"."PGD"."$"."BAD_NAME");
         }    
         else if ($cond == 5) {
            die("$"."PGD"."$"."NAME_TAKEN");
         }
      	 $email = $_POST["email"];
    	 if(!isSet($_POST["email"])) {
            die("$"."PGD"."$"."NO_EMAIL");
         }
         if( strStr($email, "@") == -1 || strStr($email, ".") == -1 ) {
            die("$"."PGD"."$"."BAD_EMAIL");
         }
         $key = $_POST["key"];
         if(!isSet($_POST["key"])) {
            die("$"."PGD"."$"."NO_KEY");
         }
         if(!preg_match("/^[a-zA-Z0-9]+?$/", $key)) {
            die("$"."PGD"."$"."INVALID_KEY");
         }        
         //Stage 2: Key Check (Server Stores Whirlpool(Key))
         $AT = $XXZVariables["key_table"][$current];
   	     $result2 = mysql_query("SELECT * FROM $AT") or die("$"."INTERNAL_ERROR");
   	     while($row2 = mysql_fetch_array($result2)) {
            if(strCmp($row2["AccKey"], $key) == 0)  {
               $PurchCode[$key] = $row2["PurchaseCode"];
               $PurchEmail[$key] = $row2["Email"];
            }
         }
         //echo "SERV: ".$PurchEmail[$key]." ".$email;
         if (strcmp(strtolower($PurchEmail[$key]), strtolower($email)) != 0 && $XXZVariables["AK_BindEmail"][$current] == 1 && strcmp(strtolower($PurchEmail[$key]), "any") != 0) {
            mysql_close($con); 
            die("$"."PGD"."$"."EMAIL_NOT_BOUND");
         }
         //ok, all the data looks good, now lets go!
         //Stage 3: Certificate Signing / database adding
         //fields we now have: username ($name), password($hashpass), email($email)
         //key ($key)
         $email = strtolower($email);
         $guid = CreateGUID($con);
         $private = $_POST["privateKey"]; //client encrypts before sending 
         $priv_dec_hash = $_POST["privDecHash"];
         $public = $_POST["publicKey"];
         $exp = $_POST["publicExponent"];
         $accountData = $_POST["accData"]; //Whirlpool(username @ password @ 2.71828)
         //
         //
         $FullAccountData = XXZHash($guid.$name.$exp.$public); //what we need
         $rsa = new Crypt_RSA();  
	     $rsa->loadKey(CA_private());

	     $rsa->setSignatureMode(CRYPT_RSA_SIGNATURE_PKCS1);
	     $signature = $rsa->sign($FullAccountData);
         //openssl_sign($FullAccountData, $signature, CA_private());
         //$ok = openssl_verify($FullAccountData, $signature, CA_public());
         $rsa->loadKey(CA_public());
         $ok = $rsa->verify($FullAccountData, $signature);
         if($ok == 1) {
            $sigFinal = bin2hex($signature);       
            //successful account creation
            //update the database adding the new user's data
            //openssl_free_key($pkey);
            //openssl_free_key($pubkey);
            $AT = $XXZVariables["account_table"][$current];
            $AK = $XXZVariables["key_table"][$current];
            
            $sql="INSERT INTO $AT (guid, E, N, D, D_DEC_HASH, signature, username, email, hashpass)
            VALUES ('$guid', '$exp', '$public', '$private', '$priv_dec_hash', '$sigFinal', '$name', '$email', '$accountData')";
            $result = "DELETE FROM $AK WHERE AccKey='$key' AND Email='$email'";
      
            mysql_query($sql,$con) or die("$".'INTERNAL_ERROR\n');
            mysql_query($result, $con) or die("$".'INTERNAL_ERROR\n');           
            echo "$"."PGD"."$"."CERT ". $name ."\t". $guid ."\t". $email ."\n";
            echo "$"."PGD"."$"."CERT2 ". $exp ."\t". $public ."\t". $sigFinal ."\n"; // complete their public certificate
            die("$"."PGD"."$"."CERT3 "); //order the client to construct their certificate.
         }
         else {
            die("$"."PGD"."$"."SIGN_ERROR ".$ok."");
         }
      case 3:
         //3: Account Re-Download (Certificate Lookup)
         $sentHash = $_POST["hashsend"]; //correct hash = whirlpool(base64(salt)) @ whirlpool(username @ password @ 2.71828) <- //what the DB stores
         $utc = time();
         $utc = "$utc";
         $salt = substr($utc, 0, -3);  
         $saltHash = XXZHash($salt);

         $AT = $XXZVariables["account_table"][$current];
         $result = mysql_query("SELECT * FROM $AT", $con) or die("$"."INTERNAL_ERROR\n");

         while($row = mysql_fetch_array($result))  {
            if(strCmp(strtolower($row["username"]), strtolower($_POST["request"])) == 0) {       
               //ok, this is the account we are looking for
               $storedPassword = $row["hashpass"];
               //tag the UTC to it for a salt against replay attacks
               $check = $saltHash . $storedPassword;
               if(strCmp($sentHash, $check) == 0) {
                  echo "$"."PGD"."$"."RECVR ". $row["username"] ."[NL]". $row["guid"] ."[NL]". $row["email"] ."[NL]". $row["E"] ."\n"; 
                  die("$"."PGD"."$"."RECVR2 ". $row["N"] ."[NL]". $row["signature"] ."[NL]". $row["D_DEC_HASH"] ."[NL]". $row["D"] ."[NL]");
               }
               else {
                  die("$"."PGD"."$"."INCORRECT_PASS");
               }
            }
         } 
         die("$"."PGD"."$"."NO_SUCH_ACCOUNT");
      case 4:
         //4: Verify Server
         $ip = $_SERVER['SERVER_ADDR'];
         die("$"."PGD". $ip ."\t". XXZHash($ip));
   }
   
   function CreateGUID($con) {
      global $XXZVariables;
      $current = "".substr(dirname($_SERVER[PHP_SELF]),strrpos(dirname($_SERVER[PHP_SELF]),'/') + 1)."";
   
      $startingVal = 10000003; //8 digit number
      $iteration = rand(13, 29);
      //Ok, here's how this works

      //Step 1: Access the Database, and sort it by the guids
      $AT = $XXZVariables["account_table"][$current];
      $result = mysql_query("SELECT * FROM $AT ORDER BY guid ASC");
      $i = 0;
      while($row = mysql_fetch_array($result)) {
         $i++;
         $rowGuid[$i] = $row["guid"];
         //echo "ROW ".$i.": ".$rowGuid[$i]." or ".$row["guid"]."\n";
      }
      //Step 2: Pick the final entry in the database
      $lastguid = $rowGuid[$i];
      if(!isSet($lastguid)) {
         //lets go one before it
         $i--;
         $lastguid = $rowGuid[$i];
         //is it still not there?
         if(!isSet($lastguid)) {
            //we must be the first guy, lulz
            return $startingVal;
         }
         else {
            //Iterate the last guid with a random iteration (from 13-29)
            $newGuid = $lastguid + $iteration;
            //Step 4: Return the Added Number
            return $newGuid;
         }
      }
      else {
         //Iterate the last guid with a random iteration (from 13-29)
         $newGuid = $lastguid + $iteration;
         //Step 4: Return the Added Number
         return $newGuid;
      }
   }
   
   function checkName($name, $con) {
      global $XXZVariables;
      $current = "".substr(dirname($_SERVER[PHP_SELF]),strrpos(dirname($_SERVER[PHP_SELF]),'/') + 1)."";
   
      if (!isset($name)) {
         //die("$"."EMPTY?");
         return 1;
      }
      if (strLen($name) < 5) {
         //die("$"."TOO_LONG");
         return 2;
      }
      if (strLen($name) > 30) {
         //die("$"."TOO_LONG");
         return 3;
      }
      if (!preg_match("/^[A-Za-z0-9]+?$/", $name)) {
         //die("$"."BAD_CHARS\n");
         return 4;
      }

      $AT = $XXZVariables["account_table"][$current];
      $result = mysql_query("SELECT * FROM $AT", $con) or die("$"."INTERNAL_ERROR\n");

      while($row = mysql_fetch_array($result))  {
         if(strCmp(strtolower($row["username"]), strtolower($name)) == 0) {
            return 5;
         }
      }
      return 0;
   }
?>
