//Login.cs
//Robert Fritzen (Phantom139)
//(c)Phantom Games Development 2011
//This script handles the log-in process

function getAccountList() {
   %account = 0;
   if(!isFile("game/client/accounts/certs.xml")) {
      error("AUTH 001: Missing certs.xml file");
      return;
   }
   %xml = new SimXMLDocument() {};
   %xml.loadFile("game/client/accounts/certs.xml");
   %xml.pushChildElement("AccountList");
   %xml.pushFirstChildElement("AccountData");
   while(true) {
      %xml.pushFirstChildElement("Account");
      %username = %xml.getData();
      $Auth::AccountName[%account] = %username;
      %account++;
      
      if (!%xml.nextSiblingElement("AccountData")) break;
   }
   
   %xml.clear();
   %xml.delete();
}

function getPublicCertificate(%name) {
   %xml = new SimXMLDocument() {};
   %xml.loadFile("game/client/accounts/certs.xml");
   %xml.pushChildElement("AccountList");
   %xml.pushFirstChildElement("AccountData");
   while(true) {
      %xml.pushFirstChildElement("Account");
      %username = %xml.getData();
      if(strlwr(%username) $= strlwr(%name)) {
         %xml.nextSiblingElement("AccountGUID");
         %guid = %xml.getData();
         %xml.nextSiblingElement("AccountEMAIL");
         %email = %xml.getData();
         %xml.nextSiblingElement("AccountRSA");
         %ensig = %xml.getData();

         %e = getSubStr(%ensig, 0, strPos(%ensig, ":"));
         %ensig = getSubStr(%ensig, strPos(%ensig, ":")+1, strlen(%ensig));
         %n = getSubStr(%ensig, 0, strPos(%ensig, ":"));
         %sig = getSubStr(%ensig, strPos(%ensig, ":")+1, strlen(%ensig));

         %line = %username TAB %guid TAB %email TAB %e TAB %n TAB %sig;
         %xml.clear();
         %xml.delete();
         return %line;
      }
      else {
         if (!%xml.nextSiblingElement("AccountData")) break;
      }
   }
   %xml.clear();
   %xml.delete();
   return "NOT_FOUND";
}

function getPrivateCertificate(%name) {
   %xml = new SimXMLDocument() {};
   %xml.loadFile("game/client/accounts/certs.xml");
   %xml.pushChildElement("AccountList");
   %xml.pushFirstChildElement("AccountData");
   while(true) {
      %xml.pushFirstChildElement("Account");
      %username = %xml.getData();
      if(strlwr(%username) $= strlwr(%name)) {
         %xml.nextSiblingElement("AccountRSAP");
         %rsaD = %xml.getData();
         %line = %username TAB %rsaD;
         
         %xml.clear();
         %xml.delete();
         return %line;
      }
      else {
         if (!%xml.nextSiblingElement("AccountData")) break;
      }
   }
   %xml.clear();
   %xml.delete();
   return "NOT_FOUND";
}

function TCPConnectionList::AssembleLoginRecovery(%this, %password) {
   %user = recUsernameEnter.getText();
   %hashpass = whirlpool(%user @ %password @ "2.71828"); //what the auth will store
   %tLen = strLen(getUTC());
   %time = getSubStr(getUTC(), 0, %tLen - 3);
   %enc = whirlpool(%time);
   %result = %enc @ %hashpass;
   
   //echo(%time TAB %enc TAB %result);

   %this.getRandomSeperator(16);
   %header = %this.assembleHTTP1_1Header("POST", "PGD Account System", "Content-Type: multipart/form-data; boundary="@%this.currentSeparator@"\r\n");
   %dispo = %this.makeDisposition(authMode, 3);
   %dispo = %dispo @ %this.makeDisposition(request, %user);
   %dispo = %dispo @ %this.makeDisposition(hashsend, %result, 1);
   
   %this.lastPassword = %password;
   %this.TCPConnection.doSingleLineEval = 1;

   %header = %header @ "Content-Length: " @ strLen(%dispo) @ "\r\n\r\n";

   %this.finishFunction = "validateLoginRecovery";
   return %header @ %dispo;
}

function PGDConnection::validateLoginRecovery(%this, %response) {
   closeMessagePopup();
   %response = stripchars(%response, "$\n");
   echo(%response TAB firstWord(%response));
   switch$(firstWord(%response)) {
       case "INCORRECT_PASS" or "NO_SUCH_ACCOUNT":
          MessageBoxOK("Error", "Invalid username/password.");
       case "RECVR":
          //ok, recovery is a go
          %certline = strReplace(%response, "RECVR ", "");
          %certline = strReplace(%certline, "[NL]", "\n");
          //Now it is split like so:
          $username = getWord(%certline, 0); //username
          $guid     = getWord(%certline, 1); //guid
          $email    = getWord(%certline, 2); //email
          $e        = getWord(%certline, 3); //e
       case "RECVR2":
          %certline = strReplace(%response, "RECVR2 ", "");
          %certline = strReplace(%certline, "[NL]", "\n");
          $n        = getWord(%certline, 0); //n
          $sig      = getWord(%certline, 1); //sig
          $dhash    = getWord(%certline, 2); //decoded hash
          $d        = getWord(%certline, 3); //d
          //
          WriteAccountCertificate($username, $guid, $email, $e, $n, $sig, $dhash, $d);
          //re-populate main menu
          MessagePopup("Success", "Your account has been recovered, you may now log in.");
          schedule(1000, 0, "CloseMessagePopup");
          AccountSelector_DropBox.schedule(1000, populate);
   }
}
