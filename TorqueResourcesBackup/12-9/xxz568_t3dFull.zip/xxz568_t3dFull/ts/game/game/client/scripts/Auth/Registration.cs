//Registration.cs
//Robert Fritzen (Phantom139)
//(c)Phantom Games Development 2011
//This script handles the scripts for PGD side Registration checks, as well as the actual registration process

//=====================================================================================================
//  REGISTRATION PROCESS
//=====================================================================================================
function TCPConnectionList::performRegistration(%this) {
   %public_e = $Account::RSAKey::E;
   %public_n = $Account::RSAKey::N;
   %hashpass = whirlpool(%this.REGuser @ %this.REGpassword @ "2.71828");
   $Account::Stor_Dec_Hash = whirlpool($Account::RSAKey::D);
   %aes_key = %this.REGpassword @ $Account::Stor_Dec_Hash;
   %encrypted = encryptAccountKey(%aes_key, $Account::RSAKey::D);
   
   if(%encrypted $= "encryptfail") {
      MessageBoxOK("Account Encryption Failure", "Failed to encrypt your account key.\nGenerating a new RSA key, please try again.");
      GenerateRSA2048();
      return;
   }
   
   $Account::RSAKey::D = %encrypted;
   
   %this.getRandomSeperator(16);
   %header = %this.assembleHTTP1_1Header("POST", "PGD Account System", "Content-Type: multipart/form-data; boundary="@%this.currentSeparator@"\r\n");

   %dispo = %this.makeDisposition(authMode, 2);
   %dispo = %dispo @ %this.makeDisposition(name, %this.REGuser);
   %dispo = %dispo @ %this.makeDisposition(email, %this.REGemail);
   %dispo = %dispo @ %this.makeDisposition(key, whirlpool(%this.REGkey));     //10/19/10- Added a crypto layer to the key interface
   %dispo = %dispo @ %this.makeDisposition(privateKey, %encrypted);
   %dispo = %dispo @ %this.makeDisposition(publicKey, %public_n);
   %dispo = %dispo @ %this.makeDisposition(publicExponent, %public_e);
   %dispo = %dispo @ %this.makeDisposition(privDecHash, $Account::Stor_Dec_Hash);
   %dispo = %dispo @ %this.makeDisposition(accData, %hashpass, 1);

   %header = %header @ "Content-Length: " @ strLen(%dispo) @ "\r\n\r\n";

   %this.TCPConnection.doSingleLineEval = 1;
   %this.finishFunction = "checkRegistrationDone";
   return %header @ %dispo;
}

function PGDConnection::checkRegistrationDone(%this, %response) {
   closeMessagePopup();
   $Authentication::ConnectionContainer.REGuser = "";
   $Authentication::ConnectionContainer.REGpassword = "";
   $Authentication::ConnectionContainer.REGemail = "";
   $Authentication::ConnectionContainer.REGkey = "";
   %response = stripchars(%response, "$\n");
   switch$(firstWord(%response)) {
       case "BAD_NAME":
          MessageBoxOk("Error", "This server has denied your username\nPlease check for invalid characters or words.");
       case "NAME_TAKEN":
          MessageBoxOk("Error", "This username is in use.");
       case "NO_EMAIL":
          MessageBoxOK("Error", "Your email field is missing.");
       case "BAD_EMAIL":
          MessageBoxOK("Error", "Your email contains invalid characters, or is invalid.");
       case "NO_KEY":
          MessageBoxOK("Error", "Your account key field is empty.");
       case "INVALID_KEY":
          MessageBoxOK("Error", "Your account key field contains invalid characters.");
       case "INTERNAL_ERROR":
          MessageBoxOK("Error", "The server encountered an internal error, please try again later.");
       case "EMAIL_NOT_BOUND":
          MessageBoxOK("Error", "This account key can not be used with your email address.");
       case "SIGN_FAILURE":
          MessageBoxOK("Error", "The server has failed to generate a signature, please contact support@phantomdev.net.");
       case "SIGN_ERROR":
          MessageBoxOK("Error", "The server has failed to sign your account certificate.");
       case "CERT":
          %certline = strreplace(%response, "CERT ", "");
          $userField = getField(%certline, 0);
          $guidField = getField(%certline, 1);
          $emailField = getField(%certline, 2);
       case "CERT2":
          %certline = strreplace(%response, "CERT2 ", "");
          $e = getField(%certline, 0);
          $n = getField(%certline, 1);
          $certsig = getField(%certline, 2);
       case "CERT3":
          %certline = strreplace(%response, "CERT3 ", "");
          WriteAccountCertificate($userField, $guidField, $emailField, $e, $n, $certsig, $Account::Stor_Dec_Hash, $Account::RSAKey::D);
          $Account::RSAKey::D = ""; // kill the private exponent field now that it's stored
          MessageBoxOK("Registration Successful", "Thank you for registering, you can now login with your new account.");
          //==============================================
          Canvas.popDialog(AccountRegistrationWindow);
          AccountSelector_DropBox.populate();
   }
}
//=====================================================================================================
//  END REGISTRATION PROCESS
//=====================================================================================================

//=====================================================================================================
//  ASSET FUNCTIONS
//=====================================================================================================
function WriteAccountCertificate(%user, %guid, %email, %e, %n, %sig, %sdh, %d) {
   %xml = new SimXMLDocument() {};
   if(isFile("game/client/accounts/certs.xml")) {
      %xml.loadFile("game/client/accounts/certs.xml");
      %xml.pushChildElement("AccountList");
      %xml.addComment("Account Data for: "@%user@"");
      %xml.pushNewElement("AccountData");
      %xml.pushNewElement("Account");
      %xml.addData(%user);
      %xml.popElement();
      %xml.pushNewElement("AccountGUID");
      %xml.addData(%guid);
      %xml.popElement();
      %xml.pushNewElement("AccountEMAIL");
      %xml.addData(%email);
      %xml.popElement();
      %xml.pushNewElement("AccountRSA");
      %xml.addData(%e @":"@ %n @":"@ %sig);
      %xml.popElement();
      %xml.pushNewElement("AccountRSAP");
      %xml.addData(%sdh@":"@%d);
      %xml.popElement();
   }
   else {
      %f = new FileObject();
      %f.openForWrite("game/client/accounts/certs.xml");
      %f.close();
      %f.close();
   
      %xml.addHeader();
      %xml.addComment("Accounts File");
      %xml.addNewElement("AccountList");
      %xml.addComment("Account Data for: "@%user@"");
      %xml.pushNewElement("AccountData");
      %xml.pushNewElement("Account");
      %xml.addData(%user);
      %xml.popElement();
      %xml.pushNewElement("AccountGUID");
      %xml.addData(%guid);
      %xml.popElement();
      %xml.pushNewElement("AccountEMAIL");
      %xml.addData(%email);
      %xml.popElement();
      %xml.pushNewElement("AccountRSA");
      %xml.addData(%e @":"@ %n @":"@ %sig);
      %xml.popElement();
      %xml.pushNewElement("AccountRSAP");
      %xml.addData(%sdh@":"@%d);
      %xml.popElement();
   }
   
   %xml.saveFile("game/client/accounts/certs.xml");
   %xml.clear();
   %xml.delete();
}

//=====================================================================================================
//  END ASSET FUNCTIONS
//=====================================================================================================
