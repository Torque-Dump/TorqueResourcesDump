//ServerTest.cs
//Robert Fritzen (Phantom139)
//(c)Phantom Games Development 2011
//This script is in place to test server validation scripts

function TestServerList() {
   if($Authentication::gotAServer > 0) {
      return "yes";
   }

   %initial = 0;
   while($Authentication::ServerList[%initial] !$= "") {
      $Authentication::ConnectionContainer.addTaskToList($Authentication::ServerList[%initial],
                                                         $Authentication::AuthTestPort[%initial],
                                                         "generateServerTest",
                                                         %initial);
      %initial++;
   }
   $Authentication::LastServer = %initial - 1;
}

function TCPConnectionList::generateServerTest(%this, %counter) {
   if($Authentication::gotAServer > 0 || $Authentication::testingServers) {
      return "NIL_REQUEST";
   }
   
   $Authentication::testingServers = 1;
   %this.getRandomSeperator(16);
   %header = %this.assembleHTTP1_1Header("POST", "PGD Account System", "Content-Type: multipart/form-data; boundary="@%this.currentSeparator@"\r\n");
   %dispo = %this.makeDisposition(authMode, "4", 1);

   %header = %header @ "Content-Length: " @ strLen(%dispo) @ "\r\n\r\n";

   %this.TCPConnection.serverIndex = %counter;
   %this.TCPConnection.callOnConnect = "$Authentication::testingServers = 1;";
   %this.TCPConnection.callOnDisconnect = "$Authentication::testingServers = 0;";
   
   %this.finishFunction = "verifyAuthServer";
   return %header @ %dispo;
}

function PGDConnection::verifyAuthServer(%this, %response) {
   if(trim(%response) !$= "") {
      //IP Address /t Hash
      %ip = getField(%response, 1);
      %Check = getField(%response, 2);
      
      if(%ip $= "" || %Check $= "") {
         $Authentication::ConnectedServer = "";
         $Authentication::ServerAuthorityHash = "";

         if($Authentication::LastServer == %this.serverIndex) {
            $Authentication::gotAServer = -1;
         }
         //issue ignore stop.
         return;
      }
      //
      %pgdIP = Whirlpool(%ip);
      //
      if(%pgdIP !$= %Check) {
         $Authentication::ConnectedServer = "";
         $Authentication::ServerAuthorityHash = "";
         
         if($Authentication::LastServer == %this.serverIndex) {
            $Authentication::gotAServer = -1;
         }
      }
      else {
         $Authentication::ConnectedServer = $Authentication::ServerList[%this.serverIndex];
         $Authentication::ServerAuthorityHash = %pgdIP;
         $Authentication::ConnectedServerIndex = %this.serverIndex;
         
         $Authentication::gotAServer = 1;
      }
   }
   else {
      %_BAD = "game/data/image/guiIcons/tickMark_BAD.png";
      //bad server, set status as no server
      AS_StatIcon.setBitmap(%_BAD);
      AS_StatIcon.tooltip = "No Servers";
      AS_Stat.setText("<Font:Arial:16>Server Status: No Validated Servers Found, Please Try Again Later");
   }
   //Issue disconnect
   %this.disconnect();
}
