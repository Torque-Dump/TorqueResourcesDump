//authLoad.cs
//Load all of the authentication system files
exec("art/gui/AccountRegistrationWindow.gui");
exec("art/gui/LoginWindow.gui");

// Auth Scripts
exec("./Auth/GUIWindows.cs");
exec("./Auth/Registration.cs");
exec("./Auth/Login.cs");
exec("./Auth/ServerTest.cs");
exec("./Auth/ServerChallenge.cs");
