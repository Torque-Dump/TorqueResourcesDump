//---------------------------------------------------------------------------------------------
// CorePackage
// Adds functionality for this mod to some standard functions.
//---------------------------------------------------------------------------------------------
package CorePackage
{
//---------------------------------------------------------------------------------------------
// onStart
// Called when the engine is starting up. Initializes this mod.
//---------------------------------------------------------------------------------------------
function onStart()
{
   Parent::onStart();
   .
   .
   .
   .
   .
   if ($platform $= "macos")
      $pref::Video::displayDevice = "OpenGL";
   else
      $pref::Video::displayDevice = "D3D9";

   //Add this line!
   exec("./PGD/Connectivity.cs");
}
