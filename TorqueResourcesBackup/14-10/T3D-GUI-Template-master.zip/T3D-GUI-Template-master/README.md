T3D-GUI-Template
================

This repository holds an updated GUI Template for T3D. 

The files in the .zip can be extracted to the /game folder of a new Full Template project. 

Features
================
Skin Selection and XML Saving:
Introduction to T3D's SimXMLDocument allows the user to choose a skin color and have that
data stored on the server in .xml format. When users log in under the same character name,
login, and password they will begin the mission with the stored skin color.

GUI Art:
Included in the template are updated modular art files that will overwrite some of the old 
art files of stock Torque3D. These provide a modernized look and feel to the game GUI's, 
and introduce the developer to the power of altering Torque's modular art. Art is designed 
and created by Jesse Allen. 

*Orbitron fonts are licensed under SIL Open Font License by Matt McInerey.
