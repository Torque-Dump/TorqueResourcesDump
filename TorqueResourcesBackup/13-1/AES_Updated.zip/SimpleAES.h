
#ifndef _SimpleAES_H_
#define _SimpleAES_H_

#ifndef _SIMBASE_H_
#include "console/simBase.h"
#endif

#ifndef _BOXCONVEX_H_
#include "collision/boxConvex.h"
#endif

#include "core/util/tVector.h"

#include "Rijndael.h"

class SimpleAES : public SimObject
{
	protected:
		typedef SimObject Parent;

	public:
		//con destr
		SimpleAES();
		~SimpleAES();

		//defaultstuff
		bool processArguments(S32 argc, const char **argv);
		bool onAdd();
		void onRemove();
		static void initPersistFields();
		
		//var
		F32  FloatExample;
        StringTableEntry StringTableExample;
		bool BooleanExample;

		//function
		F32 getVariable();
		bool setVariable(F32 _FloatExample, char * _StringTableExample, bool _BooleanExample);

		//AES Object
		
		
		CRijndael AESCrypt;
		
		StringTableEntry cryptLine(StringTableEntry cryptMe);
		StringTableEntry decryptLine(StringTableEntry decryptMe);

	private:
	public:
   		DECLARE_CONOBJECT(SimpleAES);

};

#endif // _SimpleAES_H_