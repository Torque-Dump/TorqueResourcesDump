#include "rpg_engine/AES/SimpleAES.h"

#include "console/simBase.h"
#include "console/consoleInternal.h"
#include <STDLIB.H>
#include "console/engineAPI.h"

IMPLEMENT_CONOBJECT(SimpleAES);

//Change this to your own key
#define CRYPTSIZE 32
char Key[]="1qaz2wsx3edc4rfv5tgb6yhn7ujm8ik9";
char chail[]="\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";

SimpleAES::SimpleAES()
{
	FloatExample=0.0f;
	StringTableExample= StringTable->insert("??????");
	BooleanExample=false;
	AESCrypt.MakeKey(Key, chail, CRYPTSIZE, CRYPTSIZE);
}

SimpleAES::~SimpleAES()
{

}

bool SimpleAES::processArguments(S32 argc, const char **argv)
{
   if(argc == 0)
      return true;
   else 
      return true;

}

bool SimpleAES::onAdd()
{
   if (!Parent::onAdd())
      return false;

   const char *name = getName();
   if(name && name[0] && getClassRep())
   {
      Namespace *parent = getClassRep()->getNameSpace();
      Con::linkNamespaces(parent->mName, name);
      mNameSpace = Con::lookupNamespace(name);
   }
   return true;
}

void SimpleAES::onRemove()
{
   Parent::onRemove();
}

void SimpleAES::initPersistFields()
{
	addField( "FloatExample", TypeF32, Offset(FloatExample, SimpleAES),
		"@FloatExample Description \n\n");
	addField( "StringTableExample", TypeString, Offset(StringTableExample, SimpleAES),
		"@StringTableExample Description \n\n");
	addField( "BooleanExample", TypeBool, Offset(BooleanExample, SimpleAES),
		"@BooleanExample Description \n\n");

   Parent::initPersistFields();
}

//-----------------------------------------------------------------------
DefineEngineMethod( SimpleAES, getVariable, F32, ( ),,
	"getVariable( ).  Returns value.")
{
	return object->getVariable();
}
F32 SimpleAES::getVariable(){
	return FloatExample;
}
//--------------------------------------------------------------------------------------------------------------------------
/* 
   base64.cpp and base64.h

   Copyright (C) 2004-2008 Ren� Nyffenegger

   This source code is provided 'as-is', without any express or implied
   warranty. In no event will the author be held liable for any damages
   arising from the use of this software.

   Permission is granted to anyone to use this software for any purpose,
   including commercial applications, and to alter it and redistribute it
   freely, subject to the following restrictions:

   1. The origin of this source code must not be misrepresented; you must not
      claim that you wrote the original source code. If you use this source code
      in a product, an acknowledgment in the product documentation would be
      appreciated but is not required.

   2. Altered source versions must be plainly marked as such, and must not be
      misrepresented as being the original source code.

   3. This notice may not be removed or altered from any source distribution.

   Ren� Nyffenegger rene.nyffenegger@adp-gmbh.ch

*/

#include <iostream>
#include <string>
static const std::string base64_chars = 
             "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
             "abcdefghijklmnopqrstuvwxyz"
             "0123456789+/";


static inline bool is_base64(unsigned char c) {
  return (isalnum(c) || (c == '+') || (c == '/'));
}

std::string base64_encode(unsigned char const* bytes_to_encode, unsigned int in_len) {
  std::string ret;
  int i = 0;
  int j = 0;
  unsigned char char_array_3[3];
  unsigned char char_array_4[4];

  while (in_len--) {
    char_array_3[i++] = *(bytes_to_encode++);
    if (i == 3) {
      char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
      char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
      char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
      char_array_4[3] = char_array_3[2] & 0x3f;

      for(i = 0; (i <4) ; i++)
        ret += base64_chars[char_array_4[i]];
      i = 0;
    }
  }

  if (i)
  {
    for(j = i; j < 3; j++)
      char_array_3[j] = '\0';

    char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
    char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
    char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
    char_array_4[3] = char_array_3[2] & 0x3f;

    for (j = 0; (j < i + 1); j++)
      ret += base64_chars[char_array_4[j]];

    while((i++ < 3))
      ret += '=';

  }

  return ret;

}

std::string base64_decode(std::string const& encoded_string) {
  int in_len = encoded_string.size();
  int i = 0;
  int j = 0;
  int in_ = 0;
  unsigned char char_array_4[4], char_array_3[3];
  std::string ret;

  while (in_len-- && ( encoded_string[in_] != '=') && is_base64(encoded_string[in_])) {
    char_array_4[i++] = encoded_string[in_]; in_++;
    if (i ==4) {
      for (i = 0; i <4; i++)
        char_array_4[i] = base64_chars.find(char_array_4[i]);

      char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
      char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
      char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

      for (i = 0; (i < 3); i++)
        ret += char_array_3[i];
      i = 0;
    }
  }

  if (i) {
    for (j = i; j <4; j++)
      char_array_4[j] = 0;

    for (j = 0; j <4; j++)
      char_array_4[j] = base64_chars.find(char_array_4[j]);

    char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
    char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
    char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

    for (j = 0; (j < i - 1); j++) ret += char_array_3[j];
  }

  return ret;
}
#define MAX_SIZE 8192
//--------------------------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------------------------
StringTableEntry SimpleAES::cryptLine(StringTableEntry cryptMe){
	
	std::string strCrypt="";
	StringTableEntry returnCryptTable="";
	String toCrypt=StringTable->insert(cryptMe);
	toCrypt+=":=="; 
	while(toCrypt.length() % CRYPTSIZE !=0){
		toCrypt+="=";
	}
	try{
			char cryptLength[MAX_SIZE];
			memset(cryptLength,0,sizeof(char)*MAX_SIZE);
			AESCrypt.Encrypt(toCrypt.c_str(), cryptLength,toCrypt.length(),CRijndael::ECB);
			strCrypt.append(base64_encode((unsigned char *)cryptLength,toCrypt.length()));
	}
	catch(exception& roException)
	{
		Con::printf( "Encryption Error", roException.what() );
	}
	returnCryptTable = StringTable->insert(strCrypt.c_str());
	return returnCryptTable;
}
DefineEngineMethod( SimpleAES, cryptLine, StringTableEntry, (StringTableEntry cryptMe),,
	"cryptLine( ).  Returns value.")
{
	return object->cryptLine(cryptMe);
}
//--------------------------------------------------------------------------------------------------------------------------
StringTableEntry SimpleAES::decryptLine(StringTableEntry decryptMe){
	
	std::string strDeCrypted="";
	StringTableEntry returnCryptTable="";
	String toDeCrypt=StringTable->insert(decryptMe);
	
	std::string strReturn="";
	try{
			char toDecrypt[MAX_SIZE];
			memset(toDecrypt,0,sizeof(char)*MAX_SIZE);
			char cryptLength[MAX_SIZE];
			memset(cryptLength,0,sizeof(char)*MAX_SIZE);
			strDeCrypted=base64_decode(toDeCrypt.c_str());
			memcpy(toDecrypt,strDeCrypted.c_str(),toDeCrypt.length());
			AESCrypt.Decrypt(toDecrypt, cryptLength,strDeCrypted.length(),CRijndael::ECB);
			strReturn=cryptLength;
	}
	catch(exception& roException)
	{
		Con::printf( "Encryption Error", roException.what() );
	}
	int pos=strReturn.find(":==");
	returnCryptTable = StringTable->insert(strReturn.substr(0,pos).c_str());
	return returnCryptTable;
}
DefineEngineMethod( SimpleAES, decryptLine, StringTableEntry, (StringTableEntry decryptMe),,
	"cryptLine( ).  Returns value.")
{
	return object->decryptLine(decryptMe);
}