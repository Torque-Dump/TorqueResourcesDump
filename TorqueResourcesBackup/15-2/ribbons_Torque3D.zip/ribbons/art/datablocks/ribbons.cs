new ShaderData( basicRibbonShader )
{
   DXVertexShaderFile   = "shaders/ribbons/basicRibbonShaderV.hlsl";
   DXPixelShaderFile    = "shaders/ribbons/basicRibbonShaderP.hlsl";
 
   pixVersion = 2.0;
};
 
//custom material////////////////////////////////////
 
singleton CustomMaterial( basicRibbonGlow )
{
   shader = basicRibbonShader;
   version = 2.0;
   
   emissive[0] = true;
   glow[0] = true;
   
   doubleSided = false;
   translucent = true;
   BlendOp = AddAlpha;
   translucentBlendOp = AddAlpha;
   
   preload = false;//yorks
};
 
//ribbon data////////////////////////////////////////
 
datablock RibbonData(basicRibbon)
{
	category = "Misc";
	
   size[0] = 0.8;
   color[0] = "1.0 0.3 0.0 1.0";
   position[0] = 1.0;
 
   size[1] = 0;
   color[1] = "1.0 0 0.0 0.0";
   position[1] = 0.0;
 
   RibbonLength = 6;
   fadeAwayStep = 0.25;
   RibbonMaterial =  basicRibbonGlow;
};

datablock RibbonData(longRibbon)
{
   size[0] = 0.5;
   color[0] = "0.6 0.7 0.8 1.0";
   position[0] = 1.0;
 
   size[1] = 0.25;
   color[1] = "0.6 0.7 0.8 0.5";
   position[1] = 0.5;
   
   size[2] = 0;
   color[2] = "0.6 0.7 0.8 0.0";
   position[2] = 0.0;
 
   RibbonLength = 40;
   fadeAwayStep = 0.25;
   UseFadeOut = true;
   RibbonMaterial = basicRibbonGlow;
};

datablock RibbonData(fireRibbon)
{
   size[0] = 0.5;
   color[0] = "1.0 0.3 0.0 1.0";
   position[0] = 1.0;
 
   size[1] = 0.25;
   color[1] = "1.0 0.3 0.0 0.5";
   position[1] = 0.5;
   
   size[2] = 0;
   color[2] = "1.0 0.3 0.0 0.0";
   position[2] = 0.0;
 
   RibbonLength = 40;
   fadeAwayStep = 0.25;
   UseFadeOut = true;
   RibbonMaterial = basicRibbonGlow;
};

datablock RibbonData(amberRibbon)
{
   size[0] = 0.2;
   color[0] = "1.0 0.65 0.1 1.0";
   position[0] = 1.0;
   
   size[1] = 0;
   color[1] = "1.0 0.65 0.1 0.0";
   position[1] = 0.0;
 
   RibbonLength = 30;
   fadeAwayStep = 0.25;
   UseFadeOut = true;
   RibbonMaterial = basicRibbonGlow;
};

datablock RibbonData(greenRibbon)
{
   size[0] = 0.2;
   color[0] = "0.0 1.0 0.0 1.0";
   position[0] = 1.0;
   
   size[1] = 0;
   color[1] = "0.0 1.0 0.0 0.0";
   position[1] = 0.0;
 
   RibbonLength = 30;
   fadeAwayStep = 0.25;
   UseFadeOut = true;
   RibbonMaterial = basicRibbonGlow;
};

datablock RibbonData(redRibbon)
{
   size[0] = 0.2;
   color[0] = "1.0 0.0 0.0 1.0";
   position[0] = 1.0;
   
   size[1] = 0;
   color[1] = "1.0 0.0 0.0 0.0";
   position[1] = 0.0;
 
   RibbonLength = 10;
   fadeAwayStep = 0.25;
   UseFadeOut = true;
   RibbonMaterial = basicRibbonGlow;
};

datablock RibbonNodeData(DefaultRibbonNodeData)
{
   timeMultiple = 1.0;
};

function createRibbon(%emitter, %pos)
{
   %r = new RibbonNode()
   {
      datablock = DefaultRibbonNodeData;
      emitter = %emitter;
      position = %pos;
   };
   if(isObject(MissionCleanup))
      MissionCleanup.add(%r);

   return %r;
}