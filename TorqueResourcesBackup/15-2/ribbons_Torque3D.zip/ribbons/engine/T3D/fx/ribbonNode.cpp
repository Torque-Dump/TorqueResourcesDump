//-----------------------------------------------------------------------------
// Copyright (c) 2012 GarageGames, LLC
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//-----------------------------------------------------------------------------

#include "ribbonNode.h"
#include "console/consoleTypes.h"
#include "core/stream/bitStream.h"
#include "T3D/fx/ribbon.h"
#include "math/mathIO.h"
#include "sim/netConnection.h"
#include "console/engineAPI.h"

IMPLEMENT_CO_DATABLOCK_V1(RibbonNodeData);
IMPLEMENT_CO_NETOBJECT_V1(RibbonNode);

ConsoleDocClass(RibbonNodeData,
	"@brief Contains additional data to be associated with a ParticleEmitterNode."
	"@ingroup FX\n"
	);

ConsoleDocClass(RibbonNode, ""
	);


//-----------------------------------------------------------------------------
// ParticleEmitterNodeData
//-----------------------------------------------------------------------------
RibbonNodeData::RibbonNodeData()
{
	timeMultiple = 1.0;
}

RibbonNodeData::~RibbonNodeData()
{

}

//-----------------------------------------------------------------------------
// initPersistFields
//-----------------------------------------------------------------------------
void RibbonNodeData::initPersistFields()
{
	addField("timeMultiple", TYPEID< F32 >(), Offset(timeMultiple, RibbonNodeData),
		"@brief Time multiplier for particle emitter nodes.\n\n"
		"Increasing timeMultiple is like running the emitter at a faster rate - single-shot "
		"emitters will complete in a shorter time, and continuous emitters will generate "
		"particles more quickly.\n\n"
		"Valid range is 0.01 - 100.");

	Parent::initPersistFields();
}

//-----------------------------------------------------------------------------
// onAdd
//-----------------------------------------------------------------------------
bool RibbonNodeData::onAdd()
{
	if (!Parent::onAdd())
		return false;

	if (timeMultiple < 0.01 || timeMultiple > 100)
	{
		Con::warnf("ParticleEmitterNodeData::onAdd(%s): timeMultiple must be between 0.01 and 100", getName());
		timeMultiple = timeMultiple < 0.01 ? 0.01 : 100;
	}

	return true;
}


//-----------------------------------------------------------------------------
// preload
//-----------------------------------------------------------------------------
bool RibbonNodeData::preload(bool server, String &errorStr)
{
	if (Parent::preload(server, errorStr) == false)
		return false;

	return true;
}


//-----------------------------------------------------------------------------
// packData
//-----------------------------------------------------------------------------
void RibbonNodeData::packData(BitStream* stream)
{
	Parent::packData(stream);

	stream->write(timeMultiple);
}

//-----------------------------------------------------------------------------
// unpackData
//-----------------------------------------------------------------------------
void RibbonNodeData::unpackData(BitStream* stream)
{
	Parent::unpackData(stream);

	stream->read(&timeMultiple);
}


//-----------------------------------------------------------------------------
// ParticleEmitterNode
//-----------------------------------------------------------------------------
RibbonNode::RibbonNode()
{
	// Todo: ScopeAlways?
	mNetFlags.set(Ghostable);
	mTypeMask |= EnvironmentObjectType;

	mActive = true;

	mDataBlock = NULL;
	mEmitterDatablock = NULL;
	mEmitterDatablockId = 0;
	mEmitter = NULL;
	mVelocity = 1.0;
}

//-----------------------------------------------------------------------------
// Destructor
//-----------------------------------------------------------------------------
RibbonNode::~RibbonNode()
{
	//
}

//-----------------------------------------------------------------------------
// initPersistFields
//-----------------------------------------------------------------------------
void RibbonNode::initPersistFields()
{
	addField("active", TYPEID< bool >(), Offset(mActive, RibbonNode),
		"Controls whether particles are emitted from this node.");
	addField("emitter", TYPEID< RibbonData >(), Offset(mEmitterDatablock, RibbonNode),
		"Datablock to use when emitting particles.");
	addField("velocity", TYPEID< F32 >(), Offset(mVelocity, RibbonNode),
		"Velocity to use when emitting particles (in the direction of the "
		"ParticleEmitterNode object's up (Z) axis).");

	Parent::initPersistFields();
}

//-----------------------------------------------------------------------------
// onAdd
//-----------------------------------------------------------------------------
bool RibbonNode::onAdd()
{
	if (!Parent::onAdd())
		return false;

	if (!mEmitterDatablock && mEmitterDatablockId != 0)
	{
		if (Sim::findObject(mEmitterDatablockId, mEmitterDatablock) == false)
			Con::errorf(ConsoleLogEntry::General, "ParticleEmitterNode::onAdd: Invalid packet, bad datablockId(mEmitterDatablock): %d", mEmitterDatablockId);
	}

	if (isClientObject())
	{
		setEmitterDataBlock(mEmitterDatablock);
	}
	else
	{
		setMaskBits(StateMask | EmitterDBMask);
	}

	mObjBox.minExtents.set(-0.5, -0.5, -0.5);
	mObjBox.maxExtents.set(0.5, 0.5, 0.5);
	resetWorldBox();
	addToScene();

	return true;
}

//-----------------------------------------------------------------------------
// onRemove
//-----------------------------------------------------------------------------
void RibbonNode::onRemove()
{
	removeFromScene();
	if (isClientObject())
	{
		if (mEmitter)
		{
			mEmitter->deleteOnEnd();
			mEmitter = NULL;
		}
	}

	Parent::onRemove();
}

//-----------------------------------------------------------------------------
// onNewDataBlock
//-----------------------------------------------------------------------------
bool RibbonNode::onNewDataBlock(GameBaseData *dptr, bool reload)
{
	mDataBlock = dynamic_cast<RibbonNodeData*>(dptr);
	if (!mDataBlock || !Parent::onNewDataBlock(dptr, reload))
		return false;

	// Todo: Uncomment if this is a "leaf" class
	scriptOnNewDataBlock();
	return true;
}

//-----------------------------------------------------------------------------
void RibbonNode::inspectPostApply()
{
	Parent::inspectPostApply();
	setMaskBits(StateMask /*| EmitterDBMask*/);
}

//-----------------------------------------------------------------------------
// advanceTime
//-----------------------------------------------------------------------------
void RibbonNode::processTick(const Move* move)
{
	Parent::processTick(move);

	if (isMounted())
	{
		MatrixF mat;
		mMount.object->getMountTransform(mMount.node, mMount.xfm, &mat);
		setTransform(mat);
	}
}

void RibbonNode::advanceTime(F32 dt)
{
	Parent::advanceTime(dt);

	if (!mActive || mEmitter.isNull() || !mDataBlock)
		return;

	Point3F emitPoint, emitVelocity;
	Point3F emitAxis(0, 0, 1);
	getTransform().mulV(emitAxis);
	getTransform().getColumn(3, &emitPoint);
	emitVelocity = emitAxis * mVelocity;

	MatrixF trans(getTransform());

	mEmitter->addSegmentPoint(emitPoint, trans);
}

//-----------------------------------------------------------------------------
// packUpdate
//-----------------------------------------------------------------------------
U32 RibbonNode::packUpdate(NetConnection* con, U32 mask, BitStream* stream)
{
	U32 retMask = Parent::packUpdate(con, mask, stream);

	if (stream->writeFlag(mask & InitialUpdateMask))
	{
		mathWrite(*stream, getTransform());
		mathWrite(*stream, getScale());
	}

	if (stream->writeFlag(mask & EmitterDBMask))
	{
		if (stream->writeFlag(mEmitterDatablock != NULL))
		{
			stream->writeRangedU32(mEmitterDatablock->getId(), DataBlockObjectIdFirst,
				DataBlockObjectIdLast);
		}
	}

	if (stream->writeFlag(mask & StateMask))
	{
		stream->writeFlag(mActive);
		stream->write(mVelocity);
	}

	return retMask;
}

//-----------------------------------------------------------------------------
// unpackUpdate
//-----------------------------------------------------------------------------
void RibbonNode::unpackUpdate(NetConnection* con, BitStream* stream)
{
	Parent::unpackUpdate(con, stream);

	if (stream->readFlag())
	{
		MatrixF temp;
		Point3F tempScale;
		mathRead(*stream, &temp);
		mathRead(*stream, &tempScale);

		setScale(tempScale);
		setTransform(temp);
	}

	if (stream->readFlag())
	{
		mEmitterDatablockId = stream->readFlag() ?
			stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast) : 0;

		RibbonData *emitterDB = NULL;
		Sim::findObject(mEmitterDatablockId, emitterDB);
		if (isProperlyAdded())
			setEmitterDataBlock(emitterDB);
	}

	if (stream->readFlag())
	{
		mActive = stream->readFlag();
		stream->read(&mVelocity);
	}
}

void RibbonNode::setEmitterDataBlock(RibbonData* data)
{
	if (isServerObject())
	{
		setMaskBits(EmitterDBMask);
	}
	else
	{
		Ribbon* pEmitter = NULL;
		if (data)
		{
			// Create emitter with new datablock
			pEmitter = new Ribbon;
			pEmitter->onNewDataBlock(data, false);
			if (pEmitter->registerObject() == false)
			{
				Con::warnf(ConsoleLogEntry::General, "Could not register base emitter for particle of class: %s", data->getName() ? data->getName() : data->getIdString());
				delete pEmitter;
				return;
			}
		}

		// Replace emitter
		if (mEmitter)
			mEmitter->deleteOnEnd();

		mEmitter = pEmitter;
	}

	mEmitterDatablock = data;
}

DefineEngineMethod(RibbonNode, setEmitterDataBlock, void, (RibbonData* emitterDatablock), (0),
	"Assigns the datablock for this emitter node.\n"
	"@param emitterDatablock ParticleEmitterData datablock to assign\n"
	"@tsexample\n"
	"// Assign a new emitter datablock\n"
	"%emitter.setEmitterDatablock( %emitterDatablock );\n"
	"@endtsexample\n")
{
	if (!emitterDatablock)
	{
		Con::errorf("ParticleEmitterData datablock could not be found when calling setEmitterDataBlock in particleEmitterNode.");
		return;
	}

	object->setEmitterDataBlock(emitterDatablock);
}

DefineEngineMethod(RibbonNode, setActive, void, (bool active), ,
	"Turns the emitter on or off.\n"
	"@param active New emitter state\n")
{
	object->setActive(active);
}
