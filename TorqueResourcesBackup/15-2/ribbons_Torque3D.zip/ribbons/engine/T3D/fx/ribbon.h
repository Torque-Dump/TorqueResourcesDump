//-----------------------------------------------------------------------------
// Torque Game Engine
// 
// Copyright (c) 2001 GarageGames.Com
// Portions Copyright (c) 2001 by Sierra Online, Inc.
// Portions Copyright (c) 2012 by Max Gaming Technologies, LLC
//-----------------------------------------------------------------------------

#ifndef _RIBBON_H_
#define _RIBBON_H_

#ifndef _GAMEBASE_H_
#include "T3D/gameBase/gameBase.h"
#endif

#ifndef _GFXPRIMITIVEBUFFER_H_
#include "gfx/gfxPrimitiveBuffer.h"
#endif

#ifndef _GFXVERTEXBUFFER_H_
#include "gfx/gfxVertexBuffer.h"
#endif

#include "materials/materialParameters.h"
#include "math/util/matrixSet.h"

#define RIBBON_NUM_FIELDS 4

//--------------------------------------------------------------------------
class RibbonData : public GameBaseData
{
	typedef GameBaseData Parent;

protected:
	bool onAdd();

public:

	U32 mRibbonLength;
	F32 radius[RIBBON_NUM_FIELDS];
	ColorF RibbonColor[RIBBON_NUM_FIELDS];
	F32 lengthPosition[RIBBON_NUM_FIELDS];
	StringTableEntry mMatName;
	bool mUseFadeOut;
	F32 mFadeAwayStep;
	S32 segmentsPerUpdate;
	F32 mTileScale;
	bool mFixedTexcoords;
	S32 mSegmentSkipAmount;

	RibbonData();

	void packData(BitStream*);
	void unpackData(BitStream*);
	bool preload(bool server, String &errorBuffer);

	static void initPersistFields();
	DECLARE_CONOBJECT(RibbonData);
};

//--------------------------------------------------------------------------
class Ribbon : public GameBase
{
	typedef GameBase Parent;
	RibbonData* mDataBlock;
	Vector<Point3F> mSegmentPoints;
	BaseMatInstance *mRibbonMat;
	MaterialParameterHandle* mRadiusSC;
	MaterialParameterHandle* mRibbonProjSC;
	GFXPrimitiveBufferHandle primBuffer;
	GFXVertexBufferHandle<GFXVertexPCNTT> verts;
	bool mUpdateBuffers;
	bool mDeleteOnEnd;
	bool mUseFadeOut;
	F32 mFadeAwayStep;
	F32 mFadeOut;
	U32 mSegmentOffset;
	U32 mSegmentIdx;

protected:

	bool onAdd();
	void processTick(const Move*);
	void advanceTime(F32);
	void interpolateTick(F32 delta);

	// Rendering
	virtual void prepRenderImage(SceneRenderState *state);
	// virtual void renderObject( ObjectRenderInst *ri, SceneRenderState *state, BaseMatInstance *mi );

	//Checks to see if ribbon is too long
	U32 checkRibbonDistance(S32 segments);
	void setShaderParams();
	void createBuffers(SceneRenderState *state, GFXVertexBufferHandle<GFXVertexPCNTT> &verts, GFXPrimitiveBufferHandle &pb, U32 segments);

public:
	Ribbon();
	~Ribbon();

	DECLARE_CONOBJECT(Ribbon);
	static void initPersistFields();
	bool onNewDataBlock(GameBaseData*, bool);
	void addSegmentPoint(Point3F &point, MatrixF &mat);  //used to add another segment to the ribbon
	void clearSegments() { mSegmentPoints.clear(); }
	void deleteOnEnd();
	void onRemove();

};

#endif // _H_RIBBON

