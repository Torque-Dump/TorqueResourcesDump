
singleton Material(mmoAlertExclamation_mat)
{
   mapTo = "mmoAlertExclamation";
   diffuseMap[0] = "art/shapes/MMOAlerts/exclamation";
   specular[0] = "1 1 1 1";
   specularPower[0] = "8";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   glow[0] = "1";
};


singleton Material(mmoAlertQuestion_mat)
{
   mapTo = "mmoAlertQuestion";
   diffuseMap[0] = "art/shapes/MMOAlerts/question.png";
   specular[0] = "1 1 1 1";
   specularPower[0] = "8";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   glow[0] = "1";
};

singleton Material(mmoAlertTalkBubble_mat)
{
   mapTo = "mmoAlertTalkBubble";
   diffuseMap[0] = "art/shapes/MMOAlerts/talkbubble";
   specular[0] = "1 1 1 1";
   specularPower[0] = "8";
   translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   glow[0] = "1";
};
