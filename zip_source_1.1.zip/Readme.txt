The subdirectories are empty, but show you where to put the files that are modified by the diff.
I did leave main.cpp in the main directory as there just is no significant code in there.