//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

datablock TSShapeConstructor(PlayerDts)
{
   baseShape = "./player.dts";
   sequence0 = "./player_root.dsq root";
   sequence1 = "./player_forward.dsq run";
   sequence2 = "./player_back.dsq back";
   sequence3 = "./player_side.dsq sidel";
   sequence4 = "./player_side.dsq sider";
   sequence5 = "./player_lookde.dsq look";
   sequence6 = "./player_head.dsq head";
   sequence7 = "./player_fall.dsq fall";
   sequence8 = "./player_land.dsq land";
   sequence9 = "./player_jump.dsq runjump";
   sequence10  = "./player_diehead.dsq death1";
   sequence11 = "./player_diechest.dsq death2";
   sequence12 = "./player_dieback.dsq death3";
   sequence13 = "./player_diesidelf.dsq death4";
   sequence14 = "./player_diesidert.dsq death5";
   sequence15 = "./player_dieleglf.dsq death6";
   sequence16 = "./player_dielegrt.dsq death7";
   sequence17 = "./player_dieslump.dsq death8";
   sequence18 = "./player_dieknees.dsq death9";
   sequence19 = "./player_dieforward.dsq death10";  
   sequence20 = "./player_diespin.dsq death11";
   sequence21 = "./player_looksn.dsq looksn";
   sequence22 = "./player_lookms.dsq lookms";
   sequence23 = "./player_scoutroot.dsq scoutroot";
   sequence24 = "./player_headside.dsq headside";
   sequence25 = "./player_recoilde.dsq light_recoil";
   sequence26 = "./player_sitting.dsq sitting";
   sequence27 = "./player_celsalute.dsq celsalute";
   sequence28 = "./player_celwave.dsq celwave";
   sequence29 = "./player_standjump.dsq jump";
   sequence30 = "./player_looknw.dsq looknw";
};         
