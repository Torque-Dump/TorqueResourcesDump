//	Filename : Zodiac.cs

// Zodiac Audio

datablock AudioProfile(ZodiacSoftImpactSound)
{
   filename    = "~/data/sound/Xplode.wav";
   description = AudioClose3d;
   preload = true;
   effect = SoftImpactEffect;
};

datablock AudioProfile(ZodiacHardImpactSound)
{
   filename    = "~/data/sound/Xplode.wav";
   description = AudioClose3d;
   preload = true;
   effect = HardImpactEffect;
};

datablock AudioProfile(ZodiacExitWaterMediumSound)
{
   fileName = "~/data/sound/Thrust.WAV";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(ZodiacImpactWaterSoftSound)
{
   fileName = "~/data/sound/Thrust.WAV";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(ZodiacImpactWaterMediumSound)
{
   fileName = "~/data/sound/Thrust.WAV";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(ZodiacWakeMediumSplashSound)
{
   fileName = "~/data/sound/Thrust.WAV";
   description = AudioClose3d;
   preload = true;
};

datablock AudioProfile(ZodiacThrustSound)
{
   filename    = "~/data/sound/Thrust.WAV";
   description = AudioDefaultLooping3d;
   preload = true;
   effect = ScoutFlyerThrustEffect;
};

datablock AudioProfile(ZodiacEngineSound)
{
   filename    = "~/data/sound/EngineHum.WAV";
   description = AudioDefaultLooping3d;
   preload = true;
};
// End Zodiac Audio
//-------------------------------------------------------------
// Vehicle Zodiac Explosion
datablock ParticleData(ZodiacExplosionParticle)
{
   dragCoefficient      = 2;
   gravityCoefficient   = 0.2;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 750;
   lifetimeVarianceMS   = 150;
   textureName          = "~/data/shapes/smokeParticle";
   colors[0]     = "0 0.2 1 1.0";
   colors[1]     = "0 0.2 1 0.0";
   sizes[0]      = 0.5;
   sizes[1]      = 1.0;
};

datablock ParticleEmitterData(ZodiacExplosionEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   ejectionVelocity = 1;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 60;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   particles		= "ZodiacExplosionParticle";
};

datablock ExplosionData(ZodiacVehicleExplosion)
{
   explosionShape = "~/data/shapes/zodiac/zodiac.dts";

   particleEmitter = ZodiacExplosionEmitter;
   particleDensity = 50;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;
};
// End Zodiac Explosion
//---------------------------------------------------------------------------------------
// Vehicle Zodiac Debris
datablock DebrisData(ZodiacShapeDebris)
{
	explodeOnMaxBounce = false;

	elasticity = 0.15;
	friction = 0.5;

	lifetime = 4.0;
	lifetimeVariance = 0.0;

	minSpinSpeed = 40;
	maxSpinSpeed = 600;

	numBounces = 5;
	bounceVariance = 0;

	staticOnMaxBounce = true;
	gravModifier = 1.0;

	useRadiusMass = true;
	baseRadius = 1;

	velocity = 20.0;
	velocityVariance = 12.0;
};

datablock ParticleData(ZodiacContrailParticle)
{
   dragCoefficient      = 1.5;
   gravityCoefficient   = 0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 3000;
   lifetimeVarianceMS   = 0;
   textureName          = "~/data/shapes/smokeParticle";
   colors[0]     = "0.6 0.6 0.6 0.5";
   colors[1]     = "0.2 0.2 0.2 0";
   sizes[0]      = 0.6;
   sizes[1]      = 5;
};

datablock ParticleEmitterData(ZodiacContrailEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 0;
   ejectionVelocity = 1;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 10;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   particles = "ZodiacContrailParticle";
};

datablock ParticleData(ZodiacJetParticle)
{
   dragCoefficient      = 1.5;
   gravityCoefficient   = 0;
   inheritedVelFactor   = 0.2;
   constantAcceleration = 0.0;
   lifetimeMS           = 200;
   lifetimeVarianceMS   = 0;
   textureName          = "~/data/shapes/smokeParticle";
   colors[0]     = "0.9 0.7 0.3 0.6";
   colors[1]     = "0.3 0.3 0.5 0";
   sizes[0]      = 2;
   sizes[1]      = 6;
};

datablock ParticleEmitterData(ZodiacJetEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 20;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 10;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   particles = "ZodiacJetParticle";
};
// End Zodiac Debris
//---------------------------------------------------------------------------------------
// Zodiac Definition
datablock WaterCraftData(Zodiac)
{
	spawnOffset						= "0 0 2";
	emap							   = true;
	category					   	= "Vehicles";
	shapeFile						= "~/data/shapes/zodiac/zodiac.dts";
	multipassenger					= false;
	computeCRC						= true;
									
	debrisShapeName					= "~/data/shapes/zodiac/zodiac.dts";
	debris							= ZodiacShapeDebris;
	renderWhenDestroyed				= false;

	density							= 1.0;
// 
	minMountDist					= 3;
	mountPose[0]					= sitting;
	numMountPoints					= 1;
	isProtectedMountPoint[0]		= true;
	cameraMaxDist					= 20;
	cameraOffset					= 1;
	cameraLag						= 3;

	maxDamage						= 50.40;
	destroyedLevel					= 50.40;
									
	isShielded						= true; 
	energyPerDamagePoint			= 160;
	maxEnergy						= 280;      // Afterburner and any energy weapon pool
	rechargeRate					= 0.8;

	minDrag							= 20;           // Linear Drag (eventually slows you down when not thrusting...constant drag)


	// Maneuvering
	maxSteeringAngle				= 5;    // Max radiens you can rotate the wheel. Smaller number is more maneuverable.
	maxForwardSpeed					= 30;  // speed in which forward thrust force is no longer applied (meters/second)

	// Rigid body
	mass							= 50;        // Mass of the vehicle
	bodyFriction					= 0;     // Don't mess with this.
	bodyRestitution					= 0.05;   // When you hit the ground, how much you rebound. (between 0 and 1)
	minRollSpeed					= 2000;     // Don't mess with this.
	softImpactSpeed					= 3;       // Sound hooks. This is the soft hit.
	hardImpactSpeed					= 15;    // Sound hooks. This is the hard hit.

	dragForce			   = 0.20;
   vertFactor           = 0.05;
   floatingThrustFactor = 0.15;

   mainThrustForce    = 300;
   reverseThrustForce = 200;
   strafeThrustForce  = 100;
   turboFactor        = 1.0;

   stabLenMin = 1.0;
   stabLenMax = 5.0;
   stabSpringConstant  = 10;
   stabDampingConstant = 10;

   gyroDrag = 30;
   normalForce = 30;
   restorativeForce = 1;
	steeringForce					= 350;         // Steering jets (force applied when you move the mouse)
   rollForce = -15;
   pitchForce = 1;

   dustTrailFreqMod = 15.0;
   triggerTrailHeight = 2.5;

   floatingGravMag = 1;
   brakingForce = 0.2;
   brakingActivationSpeed = 0.2;


	// Ground Impact Damage (uses DamageType::Ground)
	minImpactSpeed					= 5;      // If hit ground at speed above this then it's an impact. Meters/second
	speedDamageScale				= 0.06;

	// Object Impact Damage (uses DamageType::Impact)
	collDamageThresholdVel			= 23.0;
	collDamageMultiplier			= 0.02;

	//
	minTrailSpeed					= 1;      // The speed your contrail shows up at.
	trailEmitter					= ZodiacContrailEmitter;
	forwardJetEmitter				= ZodiacJetEmitter;
	downJetEmitter					= ZodiacJetEmitter;

	//
	jetSound				  		   = ZodiacThrustSound;
	engineSound						= ZodiacEngineSound;
	softImpactSound					= ZodiacSoftImpactSound;
	hardImpactSound					= ZodiacHardImpactSound;
	//
	softSplashSoundVelocity			= 10.0; 
	mediumSplashSoundVelocity		= 15.0;   
	hardSplashSoundVelocity			= 20.0;   
	exitSplashSoundVelocity			= 10.0;

	exitingWater					= ZodiacExitWaterMediumSound;
	impactWaterEasy					= ZodiacImpactWaterSoftSound;
	impactWaterMedium				= ZodiacImpactWaterMediumSound;
	impactWaterHard					= ZodiacImpactWaterMediumSound;
	waterWakeSound					= ZodiacWakeMediumSplashSound; 
	
	triggerDustHeight				= 4.0;
	dustHeight						= 1.0;
	damageEmitterOffset[0]			= "0.0 -3.0 0.0 ";
	damageLevelTolerance[0]			= 0.3;
	damageLevelTolerance[1]			= 0.7;
	numDmgEmitterAreas				= 3;
						



	splashEmitter[0]				= VehicleFoamDropletsEmitter;
	splashEmitter[1]				= VehicleFoamEmitter;

	shieldImpact					= VehicleShieldImpact;

	cmdCategory						= "Tactical";
	cmdIcon							= CMDWaterCraftIcon;
	cmdMiniIconName				= "commander/MiniIcons/com_scout_grey";
	targetNameTag					= 'Zodiac';
	targetTypeTag					= 'WaterCraft';
	sensorData						= AWACPulseSensor;
	sensorRadius					= AWACPulseSensor.detectRadius;
	sensorColor						= "255 194 9";
									
	checkRadius						= 5.5;
	observeParameters				= "1 10 10";
									
	shieldEffectScale				= "0.937 1.125 0.60";
};

// Zodiac Functions
//
// note: this function not complete 
//
function Zodiac::onDamage(%this, %obj, %delta)
{
   return;
	Parent::onDamage(%this, %obj);
	%currentDamage = %obj.getDamageLevel();
	if(%currentDamage > %obj.destroyedLevel)
	{
		if(%obj.getDamageState() !$= "Destroyed")
		{
			if(%obj.respawnTime !$= "")
				%obj.marker.schedule = %obj.marker.data.schedule(%obj.respawnTime, "respawn", %obj.marker); 
			%obj.setDamageState(Destroyed);
		}
	}
	else
	{
		if(%obj.getDamageState() !$= "Enabled")
			%obj.setDamageState(Enabled);
	}
}

function WaterCraftData::create(%block)
{
   %obj = new WaterCraft() {
      dataBlock = %block;
   };
   %obj.mountable = true;
   return(%obj);
}


// End Zodiac Definition
//----------------------------------------------------------------------------------------