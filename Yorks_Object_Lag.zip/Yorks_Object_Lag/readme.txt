hi, how you doing?


I believe that the fix for displaying > 1024 in world editor is in T3d 1.1 Preview - 

- but it doesn't work the same it did in 1.1 Beta3 (Dusty Monk I think posted it, but I could be wrong on that - but soemone did)

All is fine until you add Ai and then all hell breaks loose with "Player_updatePos",
and the whole thing grinds to a halt.

To test:
Place files in relevant places, start mission, in console get:
metrics(fps);

Next call:
bigSpawn();

And watch your fps die to 0.6 frames per second ....

Hold down CTRL and F3 for a while to get a profile, see that "Player_UpdatePos" is eating performance.



...



...


..

FIX IT!