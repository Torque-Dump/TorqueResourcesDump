//-----------------------------------------------------------------------------
// Torque
// Copyright GarageGames, LLC 2011
//-----------------------------------------------------------------------------

#ifndef _SKYBOX_H_
#define _SKYBOX_H_

#ifndef _SCENEOBJECT_H_
#include "scene/sceneObject.h"
#endif

#ifndef _GFXDEVICE_H_
#include "gfx/gfxDevice.h"
#endif

#ifndef _CUBEMAPDATA_H_
#include "gfx/sim/cubemapData.h"
#endif

#ifndef _MATERIALLIST_H_
#include "materials/materialList.h"
#endif

#ifndef _GFXVERTEXBUFFER_H_
#include "gfx/gfxVertexBuffer.h"
#endif

#ifndef _GFXPRIMITIVEBUFFER_H_
#include "gfx/gfxPrimitiveBuffer.h"
#endif

// JY - STARS >>>
#define MAX_NUM_LAYERS 3
#define MAX_BAN_POINTS 20
#define MAX_STARS 5000
// <<< STARS

GFXDeclareVertexFormat( GFXSkyVertex )
{
   Point3F point;
   Point3F normal;
   GFXVertexColor color;
};


struct SkyMatParams
{
   void init( BaseMatInstance *matInst ) {};
};

class MatrixSet;

class SkyBox : public SceneObject
{
   typedef SceneObject Parent;

public:

   SkyBox();
   virtual ~SkyBox();

   DECLARE_CONOBJECT( SkyBox );

   // SimObject
   void onStaticModified( const char *slotName, const char *newValue );

   // ConsoleObject
   virtual bool onAdd();
   virtual void onRemove();
   static void initPersistFields();
   virtual void inspectPostApply();      

   // NetObject
   virtual U32 packUpdate( NetConnection *conn, U32 mask, BitStream *stream );
   virtual void unpackUpdate( NetConnection *conn, BitStream *stream );

   // SceneObject
   void prepRenderImage( SceneRenderState* state );

   /// Our render delegate.
   void _renderObject( ObjectRenderInst *ri, SceneRenderState *state, BaseMatInstance *mi );

   /// Prepares rendering structures and geometry.
   void _initRender();

   // JY - STARS >>>
   // JL: Star background members
   StringTableEntry mStarListName;
   F32 mStarPoints[MAX_STARS][3];
   F32 mStarColors[MAX_STARS][4];
   U16 mNumStars;
   bool mRenderStars;
   // <<< STARS

protected:

   // Material 
   String mMatName;
   BaseMatInstance *mMatInstance;
   SkyMatParams mMatParamHandle;

   SimObjectPtr<Material> mMaterial;
   
   GFXVertexBufferHandle<GFXVertexPNTT> mVB;

   GFXVertexBufferHandle<GFXVertexPC> mFogBandVB;
   Material *mFogBandMat;
   BaseMatInstance *mFogBandMatInst;

   ColorF mLastFogColor;

   bool mDrawBottom;
   bool mIsVBDirty;
   U32 mPrimCount;

   MatrixSet *mMatrixSet;

   F32 mFogBandHeight;   

   void _updateMaterial();
   void _initMaterial();

   // JY - STARS >>>
   // JL: Load star list from disk
   bool loadStars();
   // <<< STARS

   BaseMatInstance* _getMaterialInstance();
};

#endif // _SKYBOX_H_