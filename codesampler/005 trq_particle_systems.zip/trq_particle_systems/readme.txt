--------------------------------------------------------------------------------

NOTE:

This Torque Game Engine tutorial is meant to be used in conjunction with the 
"tutorial.base" example, which ships with the Torque Game Engine (v1.3).

It's also important to note that this tutorial assumes that the "tutorial.base" 
example will run automatically when the "torqueDemo.exe" application is 
executed. If this is not so, you'll need to edit the "main.cs" file so 
"tutorial.base" will be loaded as the default. 

To do this, edit the script like so:

Change this line...

$defaultGame = "starter.fps";

To this...

$defaultGame = "tutorial.base";

Thanks, Kevin Harris 

--------------------------------------------------------------------------------
