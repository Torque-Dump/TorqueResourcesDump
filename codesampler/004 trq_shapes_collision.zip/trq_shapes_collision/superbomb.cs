
//-----------------------------------------------------------------------------
// Datablocks are special objects that are used to transmit static data from 
// server to client. Datablocks are declared as followed:
//
//	datablock datablock_class (datablock_name)
//	{
//		field1 = value;
//	};
//
// Here's the datablock for our new Super Bomb power-up...
//
//-----------------------------------------------------------------------------
datablock ItemData( SuperBomb )
{
    // The mission editor uses the "category" variable to organize this new 
    // item under the "shapes" root category.
    category = "Bombs";

    // Next, we'll tell the mission editor where to find the .dts shape file 
	// that defines our Super Bomb's geometry.
    shapeFile = "~/data/shapes/superbomb/superbomb.dts";
};

//-----------------------------------------------------------------------------
// The mission editor will invoke this create() method when it wants to create 
// an object of our new datablock type. This is a good time to setup any
// default behavior for our object. For example, our new object's default 
// behavior is to be unmovable or static and rotate in place.
//-----------------------------------------------------------------------------
function ItemData::create( %data )
{
	echo( "ItemData::create for SuperBomb called --------------------------" );

	%obj = new Item()
	{
		dataBlock = %data;
		rotate = true; // All Super Bomb power-ups will rotate.
		static = true; // Super Bombs should stay put so they don't slide away.
	};

	return %obj;
}

//-----------------------------------------------------------------------------
// And, of course, what good is a Super Bomb power-up if we can't tell when 
// the player is touching it? Every time our player touches a Super Bomb the
// onCollision() function below will get called.
//-----------------------------------------------------------------------------
function SuperBomb::onCollision( %this, %obj, %col )
{
    echo( "SuperBomb::onCollision called ----------------------------------" );

	// TO DO: Add code here to have the player react to touching the power-up!
}
