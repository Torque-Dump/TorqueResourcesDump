<?
/*
1. variable names in DB
user_id,password,nick_name

2. variables passed from the game client:
user, password

3. member_table creation example for this resource:
create table member_table(
user_id varchar(20),
password varchar(32),
nick_name varchar(255),
primary key(user_id)
);
4. notice : before writing onto DB, password have to be md5ed using md5($userinputpassword)
*/

//SQL server variables
$auth_host = "localhost";
$auth_user = "yourID";
$auth_pass = "yourPassword";
$auth_dbase = "relatedDB";

//check if id is passed
if(is_null($user) || $user=="" || $user==" ")
{
	echo "Invalid ID <br>";
	exit();
}

//check if password is passed
if(is_null($password) || $password == "" || $password ==" ")
{
	echo "Invalid password <br>";
	exit();
}

//===========================================================
//=====Check if password and username match
//===========================================================
if(!$home)
   $home = mysql_connect($auth_host, $auth_user, $auth_pass);
if($home==-1)
{
   echo "N connection failed \n";
   exit();
}
mysql_select_db($auth_dbase);
$query = "select user_id, password, nick_name from member_table where user_id='$user'";
$result = mysql_query($query, $home);
$row = mysql_fetch_assoc($result);

$temppass = $row['password'];
$userid = $row['user_id'];
$nickname = $row['nick_name'];

//It seems like some useless data is added to the end of passwords.
//So I decided to select 32 digits for passwords comparision.
$passSvr = substr($temppass,0,31);
$passCl = substr($password,0,31);

//PHP is case sensitive.
if(strtoupper($passSvr) != $passCl)
{
	echo "N unmatch $passSvr $passCl\n";
	exit();
}

if($nickname!="")  //nickname is registered.
{
	echo "Y Y $nickname\n";
	//$itemOutput=getItemInfo($userid);
	//echo "Item $itemOutput\n";
}
else	//No nickname yet.
	echo "Y N \n";

mysql_free_result($result);
mysql_close($home);

?>