
singleton TSShapeConstructor(ToycarDAE)
{
   baseShape = "./toycar.DAE";
   adjustCenter = "1";
   loadLights = "0";
};
