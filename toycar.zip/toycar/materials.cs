//--- toycar.DAE MATERIALS BEGIN ---
singleton Material(toycar_ColorEffectR255G255B255_material)
{
	mapTo = "ColorEffectR255G255B255-material";

	diffuseMap[0] = "art/gui/background.png";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.533333 0.403922 0.113725 1";
	specular[0] = "1 1 1 1";
	specularPower[0] = 10;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   materialTag0 = "RoadAndPath";
};

singleton Material(toycar_Metal_DiskChrome)
{
	mapTo = "Metal_DiskChrome";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.545098 0.545098 0.54902 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = "4";

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   cubemap = "DefaultSkyCubemap";
   materialTag0 = "vegetation";
};

singleton Material(toycar_Metal_Chrome)
{
	mapTo = "Metal_Chrome";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.439216 0.439216 0.439216 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 38;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   cubemap = "DefaultSkyCubemap";
   materialTag0 = "RoadAndPath";
};

singleton Material(toycar_Metal_Chrome)
{
	mapTo = "Metal_Chrome";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.439216 0.439216 0.439216 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 20;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
};

singleton Material(toycar_GlassBlue)
{
	mapTo = "GlassBlue";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.776471 0.835294 0.847059 1";
	specular[0] = "1 1 1 1";
	specularPower[0] = 24;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   alphaTest = "1";
   alphaRef = "255";
};

singleton Material(toycar_Material__37)
{
	mapTo = "Material__37";

	diffuseMap[0] = "art/gui/background.png";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.0941177 0.0941177 0.0941177 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = "41";

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   materialTag0 = "vegetation";
};

singleton Material(toycar_Material__38)
{
	mapTo = "Material__38";

	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "1 0.0784314 0.0784314 1";
	specular[0] = "0.733333 0.854902 0.941176 1";
	specularPower[0] = "70";

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   subSurface[0] = "1";
   subSurfaceRolloff[0] = "0";
   materialTag0 = "vegetation";
};

singleton Material(toycar_Material__38)
{
	mapTo = "Material__38";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "1 0.0784314 0.0784314 1";
	specular[0] = "0.996078 0.996078 0.996078 1";
	specularPower[0] = "41";

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   subSurface[0] = "1";
   subSurfaceRolloff[0] = "0";
};

singleton Material(toycar_Material__166)
{
	mapTo = "Material__166";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.0941177 0.0941177 0.0941177 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 5;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
};

singleton Material(toycar_Material__37)
{
	mapTo = "Material__37";

	diffuseMap[0] = "XtraWeelText_Small";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "1 1 1 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 5;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
};

singleton Material(toycar_Material__39)
{
	mapTo = "Material__39";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.0941177 0.0941177 0.0941177 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = "21";

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   materialTag0 = "vegetation";
};

singleton Material(toycar_Material__38)
{
	mapTo = "Material__38";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.0941177 0.0941177 0.0941177 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 6;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
};

singleton Material(toycar_Material__38)
{
	mapTo = "Material__38";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "1 0.0784314 0.0784314 1";
	specular[0] = "0.733333 0.854902 0.941176 1";
	specularPower[0] = 70;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
};

singleton Material(toycar_Material__174)
{
	mapTo = "Material__174";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.376471 0.376471 0.376471 0.6";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 93;

	doubleSided = false;
	translucent = true;
	translucentBlendOp = "LerpAlpha";
};

singleton Material(toycar_Material__33)
{
	mapTo = "Material__33";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.211765 0.211765 0.211765 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 71;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   pixelSpecular[0] = "1";
};

singleton Material(toycar_MirrorGlass)
{
	mapTo = "MirrorGlass";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.701961 0.745098 0.831373 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 93;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   cubemap = "nightCubemap";
};

singleton Material(toycar_Material__40)
{
	mapTo = "Material__40";

	diffuseMap[0] = "art/gui/background.png";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.278431 0.105882 0.0588235 1";
	specular[0] = "1 1 1 1";
	specularPower[0] = "64";

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   subSurfaceColor[0] = "0.337255 0.0705882 0.0705882 1";
   subSurfaceRolloff[0] = "0";
};

singleton Material(toycar_Material__34)
{
	mapTo = "Material__34";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0 0 0 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 66;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
};

singleton Material(toycar_Material__170)
{
	mapTo = "Material__170";

	diffuseMap[0] = "art/gui/background.png";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.501961 0.427451 0.227451 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 30;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   subSurfaceColor[0] = "0.321569 0.309804 0.176471 1";
};

singleton Material(toycar_Material__172)
{
	mapTo = "Material__172";

	diffuseMap[0] = "art/gui/background.png";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.470588 0.396078 0.180392 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = "1";

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   pixelSpecular[0] = "0";
};

singleton Material(toycar_Metal_Chrome)
{
	mapTo = "Metal_Chrome";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.439216 0.439216 0.439216 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 38;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
};

singleton Material(toycar_Material__41)
{
	mapTo = "Material__41";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.658823 0.486275 0.215686 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 78;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
};

singleton Material(toycar_Material__184)
{
	mapTo = "Material__184";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "1 1 1 1";
	specular[0] = "0.266667 0.266667 0.266667 0.349";
	specularPower[0] = "124";

	doubleSided = false;
	translucent = "1";
	translucentBlendOp = "LerpAlpha";
};

singleton Material(toycar_Material__26)
{
	mapTo = "Material__26";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.572549 0.572549 0.572549 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 38;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
};

singleton Material(toycar_Material__36)
{
	mapTo = "Material__36";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.117647 0 0 1";
	specular[0] = "0.952941 0.901961 0.905882 1";
	specularPower[0] = 38;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
};

singleton Material(toycar_Material__42)
{
	mapTo = "Material__42";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.117647 0 0 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 38;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
};

singleton Material(toycar_Material__54)
{
	mapTo = "Material__54";

	diffuseMap[0] = "art/gui/background.png";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0 0 0 1";
	specular[0] = "0.988235 0.803922 0.0588235 1";
	specularPower[0] = 80;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   pixelSpecular[0] = "1";
};

singleton Material(toycar_TurnRed)
{
	mapTo = "TurnRed";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.882353 0 0 1";
	specular[0] = "0.984314 0.941176 0.937255 1";
	specularPower[0] = 70;

	doubleSided = "1";
	translucent = "1";
	translucentBlendOp = "Mul";
};

singleton Material(toycar_BlueGlass)
{
	mapTo = "BlueGlass";

	diffuseMap[0] = "art/gui/background.png";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.266667 0.301961 0.760784 0.622";
	specular[0] = "0.45098 0.701961 1 1";
	specularPower[0] = 40;

	doubleSided = false;
	translucent = "1";
	translucentBlendOp = "Mul";
};

singleton Material(toycar_Material__97)
{
	mapTo = "Material__97";

	diffuseMap[0] = "art/gui/background.png";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.521569 0.0980392 0.0392157 1";
	specular[0] = "0.733333 0.854902 0.941176 1";
	specularPower[0] = 65;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   pixelSpecular[0] = "1";
};

singleton Material(toycar_Material__169)
{
	mapTo = "Material__169";

	diffuseMap[0] = "art/gui/background.png";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "1 0.815686 0.0784314 1";
	specular[0] = "0.945098 0.823529 0 1";
	specularPower[0] = 65;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   pixelSpecular[0] = "1";
   subSurface[0] = "1";
   subSurfaceRolloff[0] = "0";
};

singleton Material(toycar_Material__186)
{
	mapTo = "Material__186";

	diffuseMap[0] = "MERARADI";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "1 1 1 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 10;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
};

singleton Material(toycar_Metal_Brake)
{
	mapTo = "Metal_Brake";

	diffuseMap[0] = "art/gui/background.png";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.745098 0.384314 0 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = "26";

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
   pixelSpecular[0] = "1";
};

singleton Material(toycar_Material__185)
{
	mapTo = "Material__185";

	diffuseMap[0] = "MANDOS";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "1 1 1 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 5;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
};

singleton Material(toycar_Metal_Brake)
{
	mapTo = "Metal_Brake";

	diffuseMap[0] = "";
	normalMap[0] = "";
	specularMap[0] = "";

	diffuseColor[0] = "0.745098 0.384314 0 1";
	specular[0] = "0.9 0.9 0.9 1";
	specularPower[0] = 26;

	doubleSided = false;
	translucent = false;
	translucentBlendOp = "None";
};

//--- toycar.DAE MATERIALS END ---

