//-----------------------------------------------------------------------------
// Torque Game Engine
// 
// Copyright (c) 2001 GarageGames.Com
// Portions Copyright (c) 2001 by Sierra Online, Inc.
//-----------------------------------------------------------------------------

// This file is exec()'ed in to get values to store into the player array
%pName = "Orc Warrior";
%pDesc = "A versatile fighter adept at close and mid-range combat.";
%pWeapon = "Crossbow";
%pWeaponDTS = "rw/data/shapes/crossbow/weapon.dts";
%pModel = 1;
%pToughness = 0.70;
%pSpeed = 0.6;
%pCombat = 0.7;
%pMagic = 0.1;
