//-----------------------------------------------------------------------------
// Torque3D - PostFX Options Dialog 0.2
// Copyright (C)
//-----------------------------------------------------------------------------

function postProcessOptionsDlg::onDialogPush( %this )
{
//------------------------------------
// SSAO Settings
//------------------------------------

   //Add the items we need to display
   ppOptionsSSAOQuality.clear();
   ppOptionsSSAOQuality.add("Low", 0);
   ppOptionsSSAOQuality.add("Medium", 1);
   ppOptionsSSAOQuality.add("High", 2);
   
   //Set the selected, after adding the items!
   ppOptionsSSAOQuality.setSelected($SSAOPostFx::quality);
   
   //SSAO - Set the values of the sliders, General Tab
   ppOptionsSSAOOverallStrength.setValue($SSAOPostFx::overallStrength);
   ppOptionsSSAOBlurDepth.setValue($SSAOPostFx::blurDepthTol);
   ppOptionsSSAOBlurNormal.setValue($SSAOPostFx::blurNormalTol);
      
   //SSAO - Set the values for the near tab
   ppOptionsSSAONearDepthMax.setValue($SSAOPostFx::sDepthMax);
   ppOptionsSSAONearDepthMin.setValue($SSAOPostFx::sDepthMin);
   ppOptionsSSAONearRadius.setValue($SSAOPostFx::sRadius);
   ppOptionsSSAONearStrength.setValue($SSAOPostFx::sStrength);
   ppOptionsSSAONearToleranceNormal.setValue($SSAOPostFx::sNormalTol);
   ppOptionsSSAONearTolerancePower.setValue($SSAOPostFx::sNormalPow);
   
   //SSAO - Set the values for the far tab
   ppOptionsSSAOFarDepthMax.setValue($SSAOPostFx::lDepthMax);
   ppOptionsSSAOFarDepthMin.setValue($SSAOPostFx::lDepthMin);
   ppOptionsSSAOFarRadius.setValue($SSAOPostFx::lRadius);
   ppOptionsSSAOFarStrength.setValue($SSAOPostFx::lStrength);
   ppOptionsSSAOFarToleranceNormal.setValue($SSAOPostFx::lNormalTol);
   ppOptionsSSAOFarTolerancePower.setValue($SSAOPostFx::lNormalPow);
   
//------------------------------------
// HDR Settings
//------------------------------------
   
   ppOptionsHDRBloom.setValue($HDRPostFX::enableBloom);
   ppOptionsHDRBloomBlurBrightPassThreshold.setValue($HDRPostFX::brightPassThreshold);
   ppOptionsHDRBloomBlurMean.setValue($HDRPostFX::gaussMean);
   ppOptionsHDRBloomBlurMultiplier.setValue($HDRPostFX::gaussMultiplier);
   ppOptionsHDRBloomBlurStdDev.setValue($HDRPostFX::gaussStdDev);
   ppOptionsHDRBrightnessAdaptRate.setValue($HDRPostFX::adaptRate);
   ppOptionsHDREffectsBlueShift.setValue($HDRPostFX::enableBlueShift);
   ppOptionsHDREffectsBlueShiftColor.BaseColor = $HDRPostFX::blueShiftColor;
   ppOptionsHDREffectsBlueShiftColor.PickColor = $HDRPostFX::blueShiftColor;
   ppOptionsHDRKeyValue.setValue($HDRPostFX::keyValue);
   ppOptionsHDRMinLuminance.setValue($HDRPostFX::minLuminace);
   ppOptionsHDRToneMapping.setValue($HDRPostFX::enableToneMapping);
   ppOptionsHDRWhiteCutoff.setValue($HDRPostFX::whiteCutoff);
   
//------------------------------------
// Light Rays Settings
//------------------------------------   

   ppOptionsLightRaysBrightScalar.setValue($LightRayPostFX::brightScalar);
}

function postProcessOptionsDlg::applySettingsFromPrefs(%this)
{
//SSAO Settings
   $SSAOPostFx::blurDepthTol           = $pref::SSAOPostFx::blurDepthTol;
   $SSAOPostFx::blurNormalTol          = $pref::SSAOPostFx::blurNormalTol;
   $SSAOPostFx::lDepthMax              = $pref::SSAOPostFx::lDepthMax;
   $SSAOPostFx::lDepthMin              = $pref::SSAOPostFx::lDepthMin;
   $SSAOPostFx::lDepthPow              = $pref::SSAOPostFx::lDepthPow;
   $SSAOPostFx::lNormalPow             = $pref::SSAOPostFx::lNormalPow;
   $SSAOPostFx::lNormalTol             = $pref::SSAOPostFx::lNormalTol;
   $SSAOPostFx::lRadius                = $pref::SSAOPostFx::lRadius;
   $SSAOPostFx::lStrength              = $pref::SSAOPostFx::lStrength;
   $SSAOPostFx::overallStrength        = $pref::SSAOPostFx::overallStrength;
   $SSAOPostFx::quality                = $pref::SSAOPostFx::quality;
   $SSAOPostFx::sDepthMax              = $pref::SSAOPostFx::sDepthMax;
   $SSAOPostFx::sDepthMin              = $pref::SSAOPostFx::sDepthMin;
   $SSAOPostFx::sDepthPow              = $pref::SSAOPostFx::sDepthPow;
   $SSAOPostFx::sNormalPow             = $pref::SSAOPostFx::sNormalPow;
   $SSAOPostFx::sNormalTol             = $pref::SSAOPostFx::sNormalTol;
   $SSAOPostFx::sRadius                = $pref::SSAOPostFx::sRadius;
   $SSAOPostFx::sStrength              = $pref::SSAOPostFx::sStrength;
   
   //HDR settings
   $HDRPostFX::adaptRate               = $pref::HDRPostFX::adaptRate;
   $HDRPostFX::blueShiftColor          = $pref::HDRPostFX::blueShiftColor;
   $HDRPostFX::brightPassThreshold     = $pref::HDRPostFX::brightPassThreshold; 
   $HDRPostFX::enableBloom             = $pref::HDRPostFX::enableBloom;
   $HDRPostFX::enableBlueShift         = $pref::HDRPostFX::enableBlueShift;
   $HDRPostFX::enableToneMapping       = $pref::HDRPostFX::enableToneMapping;
   $HDRPostFX::gaussMean               = $pref::HDRPostFX::gaussMean;
   $HDRPostFX::gaussMultiplier         = $pref::HDRPostFX::gaussMultiplier;
   $HDRPostFX::gaussStdDev             = $pref::HDRPostFX::gaussStdDev;
   $HDRPostFX::keyValue                = $pref::HDRPostFX::keyValue;
   $HDRPostFX::minLuminace             = $pref::HDRPostFX::minLuminace;
   $HDRPostFX::whiteCutoff             = $pref::HDRPostFX::whiteCutoff;
   
   //Light rays settings
   $LightRayPostFX::brightScalar       = $pref::LightRayPostFX::brightScalar;
}

function postProcessOptionsDlg::applySettings(%this)
{
   //SSAO Settings
   $pref::SSAOPostFx::blurDepthTol     = $SSAOPostFx::blurDepthTol;
   $pref::SSAOPostFx::blurNormalTol    = $SSAOPostFx::blurNormalTol;
   $pref::SSAOPostFx::lDepthMax        = $SSAOPostFx::lDepthMax;
   $pref::SSAOPostFx::lDepthMin        = $SSAOPostFx::lDepthMin;
   $pref::SSAOPostFx::lDepthPow        = $SSAOPostFx::lDepthPow;
   $pref::SSAOPostFx::lNormalPow       = $SSAOPostFx::lNormalPow;
   $pref::SSAOPostFx::lNormalTol       = $SSAOPostFx::lNormalTol;
   $pref::SSAOPostFx::lRadius          = $SSAOPostFx::lRadius;
   $pref::SSAOPostFx::lStrength        = $SSAOPostFx::lStrength;
   $pref::SSAOPostFx::overallStrength  = $SSAOPostFx::overallStrength;
   $pref::SSAOPostFx::quality          = $SSAOPostFx::quality;
   $pref::SSAOPostFx::sDepthMax        = $SSAOPostFx::sDepthMax;
   $pref::SSAOPostFx::sDepthMin        = $SSAOPostFx::sDepthMin;
   $pref::SSAOPostFx::sDepthPow        = $SSAOPostFx::sDepthPow;
   $pref::SSAOPostFx::sNormalPow       = $SSAOPostFx::sNormalPow;
   $pref::SSAOPostFx::sNormalTol       = $SSAOPostFx::sNormalTol;
   $pref::SSAOPostFx::sRadius          = $SSAOPostFx::sRadius;
   $pref::SSAOPostFx::sStrength        = $SSAOPostFx::sStrength;
   
   //HDR settings
   $pref::HDRPostFX::adaptRate         = $HDRPostFX::adaptRate;
   $pref::HDRPostFX::blueShiftColor    = $HDRPostFX::blueShiftColor;
   $pref::HDRPostFX::brightPassThreshold = $HDRPostFX::brightPassThreshold;
   $pref::HDRPostFX::enableBloom       = $HDRPostFX::enableBloom;
   $pref::HDRPostFX::enableBlueShift   = $HDRPostFX::enableBlueShift;
   $pref::HDRPostFX::enableToneMapping = $HDRPostFX::enableToneMapping;
   $pref::HDRPostFX::gaussMean         = $HDRPostFX::gaussMean;
   $pref::HDRPostFX::gaussMultiplier   = $HDRPostFX::gaussMultiplier;
   $pref::HDRPostFX::gaussStdDev       = $HDRPostFX::gaussStdDev;
   $pref::HDRPostFX::keyValue          = $HDRPostFX::keyValue;
   $pref::HDRPostFX::minLuminace       = $HDRPostFX::minLuminace;
   $pref::HDRPostFX::whiteCutoff       = $HDRPostFX::whiteCutoff;
   
   //Light rays settings
   $pref::LightRayPostFX::brightScalar = $LightRayPostFX::brightScalar;
}

//Other controls, Quality dropdown
function ppOptionsSSAOQuality::onSelect( %this, %id, %text )
{
   if(%id > -1 && %id < 3)
   {
      $SSAOPostFx::quality = %id;
   }
}

//SSAO Slider controls
//General Tab
function ppOptionsSSAOOverallStrength::onMouseDragged(%this)
{
   $SSAOPostFx::overallStrength = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

function ppOptionsSSAOBlurDepth::onMouseDragged(%this)
{
   $SSAOPostFx::blurDepthTol = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

function ppOptionsSSAOBlurNormal::onMouseDragged(%this)
{
   $SSAOPostFx::blurNormalTol = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

//Near Tab
function ppOptionsSSAONearRadius::onMouseDragged(%this)
{
   $SSAOPostFx::sRadius = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

function ppOptionsSSAONearStrength::onMouseDragged(%this)
{
   $SSAOPostFx::sStrength = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

function ppOptionsSSAONearDepthMin::onMouseDragged(%this)
{
   $SSAOPostFx::sDepthMin = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

function ppOptionsSSAONearDepthMax::onMouseDragged(%this)
{
   $SSAOPostFx::sDepthMax = %this.value;
   %this.ToolTip = "Value : " @ %this.value;   
}

function ppOptionsSSAONearToleranceNormal::onMouseDragged(%this)
{
   $SSAOPostFx::sNormalTol = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

function ppOptionsSSAONearTolerancePower::onMouseDragged(%this)
{
   $SSAOPostFx::sNormalPow = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

//Far Tab
function ppOptionsSSAOFarRadius::onMouseDragged(%this)
{
   $SSAOPostFx::lRadius = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}
function ppOptionsSSAOFarStrength::onMouseDragged(%this)
{
   $SSAOPostFx::lStrength = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}
function ppOptionsSSAOFarDepthMin::onMouseDragged(%this)
{
   $SSAOPostFx::lDepthMin = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}
function ppOptionsSSAOFarDepthMax::onMouseDragged(%this)
{
   $SSAOPostFx::lDepthMax = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}
function ppOptionsSSAOFarToleranceNormal::onMouseDragged(%this)
{
   $SSAOPostFx::lNormalTol = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}
function ppOptionsSSAOFarTolerancePower::onMouseDragged(%this)
{
   $SSAOPostFx::lNormalPow = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

//HDR Slider Controls
//Brighness tab
function ppOptionsHDRKeyValue::onMouseDragged(%this)
{
   $HDRPostFX::keyValue = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

function ppOptionsHDRMinLuminance::onMouseDragged(%this)
{
   $HDRPostFX::minLuminace = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

function ppOptionsHDRWhiteCutoff::onMouseDragged(%this)
{
   $HDRPostFX::whiteCutoff = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

function ppOptionsHDRBrightnessAdaptRate::onMouseDragged(%this)
{
   $HDRPostFX::adaptRate = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

//Blur tab
function ppOptionsHDRBloomBlurBrightPassThreshold::onMouseDragged(%this)
{
   $HDRPostFX::brightPassThreshold = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

function ppOptionsHDRBloomBlurMultiplier::onMouseDragged(%this)
{
   $HDRPostFX::gaussMultiplier = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

function ppOptionsHDRBloomBlurMean::onMouseDragged(%this)
{
   $HDRPostFX::gaussMean = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

function ppOptionsHDRBloomBlurStdDev::onMouseDragged(%this)
{
   $HDRPostFX::gaussStdDev = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}

function ppOptionsHDRBloom::onAction(%this)
{
   $HDRPostFX::enableBloom =  %this.getValue();
}

function ppOptionsHDRToneMapping::onAction(%this)
{
   $HDRPostFX::enableToneMapping =  %this.getValue();
}

function ppOptionsHDREffectsBlueShift::onAction(%this)
{
   $HDRPostFX::enableBlueShift = %this.getValue();
}

function ppOptionsHDREffectsBlueShiftColor::onAction(%this)
{
   $HDRPostFX::blueShiftColor = %this.PickColor;
   %this.ToolTip = "Color Values : " @ %this.PickColor;   
}

//Light rays Slider Controls
function ppOptionsLightRaysBrightScalar::onMouseDragged(%this)
{
   $LightRayPostFX::brightScalar = %this.value;
   %this.ToolTip = "Value : " @ %this.value;
}
