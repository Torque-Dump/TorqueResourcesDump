http://www.garagegames.com/community/resources/view/18479/

** THIS WAS ALREADY INCLUDED IN THE ENGINE **

To install : 

First, load the GUI's in game/core/main.cs ( I load it right after the options GUI : about line 79 ).


exec("./scripts/gui/postProcessOptionsDlg.cs");     
exec("./art/gui/postProcessOptionsDlg.gui");  


Second, add the menu item in game/tools/worldEditor/scripts/menus.ed.cs (about line 139)

item[14] = "Post Process Options" TAB "" TAB "Canvas.pushDialog(postProcessOptionsDlg);";  


Third, i added a "ctrl [" shortcut so i can load it in game, without loading the editor.
in game/scripts/client/default.bind.cs (Around line 468) :

function bringUpPostFXOptions(%val)
{
   if (%val)
      Canvas.pushDialog(postProcessOptionsDlg);
}

GlobalActionMap.bind(keyboard, "ctrl [", bringUpPostFXOptions);

That should be all!
Enjoy :)