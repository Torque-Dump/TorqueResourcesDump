// phdana turrets ->

datablock DebrisData(TurretDebris)
{
	explodeOnMaxBounce = false;

	elasticity = 0.15;
	friction = 0.5;

	lifetime = 2.0;
	lifetimeVariance = 0.0;

	minSpinSpeed = 40;
	maxSpinSpeed = 200;

	numBounces = 5;
	bounceVariance = 0;

	staticOnMaxBounce = true;
	gravModifier = 1.0;

	useRadiusMass = true;
	baseRadius = 1;

	velocity = 30.0;
	velocityVariance = 12.0;
};

datablock TurretData(GenericTurret)
{
	category						= "Turrets";
    numPoints                       = 100;
    
	shapeFile						= "art/shapes/turrets/smallTurret.dts";
    maxDamage                       = 110;
    explosion                       = GenericMediumExplosion;
    destroyedLevel                  = 110;
    disabledLevel                   = 0.84;
	//debrisShapeName		   	        = "art/shapes/turrets/smallTurret.dts";
    debris                          = TargetMajorDebris;
    renderWhenDestroyed             = false;
  	mountPose[0]					= sitting;
	numMountPoints					= 2;
	isProtectedMountPoint[0]		= true;
	cameraMaxDist					= 10;
	cameraOffset					= 2.5;
	maxEnergy						= 280;
	rechargeRate					= 0.8;
 	heat                            = 1.0;
  
    // turret specific stuff
    //minYaw = -90.0;
    //maxYaw = 90;
    componentPower = 200500;
    componentType = 0;
	
	// mounting stuff
	passengerLimit					= 1;
  
    // mounted by default in TurretData if specified
    barrelSlot                      = 0;
    barrel                          = SmallTurretGun;
};

datablock ShapeBaseImageData(SmallTurretGun)
{
   // Basic Item properties
   shapeFile = "art/shapes/turrets/smallTurretGun.dts";
   mass = 15;
   //category					= "Turrets";  // you dont want to place these

   mountPoint = 0;
   offset = "0 0 0";

   projectile = RocketLauncherProjectile; // [HNT] Picked a projectile that exists in stock T3D
   projectileType = Projectile;
   correctMuzzleVector = false;   // not sure how this is used

   // I dont implement use of these in script
   // but old turret stuff had this...
   usesEnergy = true;
   fireEnergy = 10;
   minEnergy = 4;

   // Images have a state system which controls how the animations
   // are run, which sounds are played, script callbacks, etc. This
   // state system is downloaded to the client so that clients can
   // predict state changes and animate accordingly.  The following
   // system supports basic ready->fire->reload transitions as
   // well as a no-ammo->dryfire idle state.

   // Initial start up state
      // State transitions
   stateName[0]                     = "Activate";
   stateTimeoutValue[0]             = 0.01;
   stateTransitionOnTimeout[0]      = "Ready";
   //stateSound[0]                    = TurretSwitchSound;

   stateName[1]                     = "Ready";
   stateTransitionOnTriggerDown[1]  = "Fire";
   stateTransitionOnNoAmmo[1]       = "NoAmmo";

   stateName[2]                     = "Fire";
   stateTransitionOnTimeout[2]      = "Reload";
   stateTimeoutValue[2]             = 0.13; // .13
   stateFire[2]                     = true;
   stateRecoil[2]                   = LightRecoil;
   stateAllowImageChange[2]         = false;
   stateSequence[2]                 = "Fire";
   //stateSound[2]                    = BlastFire1Sound;
   stateScript[2]                   = "onFire";

   stateName[3]                     = "Reload";
   stateTimeoutValue[3]             = 0.05; // .4
   stateAllowImageChange[3]         = false;
   stateTransitionOnTimeout[3]      = "Ready";
   stateTransitionOnNoAmmo[3]       = "NoAmmo";

   stateName[4]                     = "NoAmmo";
   stateTransitionOnAmmo[4]         = "Reload";
   stateSequence[4]                 = "NoAmmo";
};

function GenericTurret::onAdd(%this,%obj)
{
   // we specified a barrel so the parent class does all the work
   // in fact we could remove this GenericTurret::onAdd() method completely
   Parent::onAdd(%this,%obj);
   
   // if you do not specify a barrel then you
   // need to do this...
   //%turretSlot = 0;
   //%obj.setEnergyLevel(%this.MaxEnergy);
   //%obj.getMountedImage(%turretSlot);
   //echo("Created Generic Turret By hand");
   //%obj.mountImage(SmallTurretGun,%turretSlot);
}

// [HNT] Define onFire on a per-weapon basis instead of using
//       a generic ShapeBaseImageData::onFire
function SmallTurretGun::onFire(%data, %obj, %slot)
{
   //echo("ShapeBaseImageData::onFire()");

	%projectile = %data.projectile;

	%muzzleVector = %obj.getMuzzleVector(%slot);
   %objectVelocity = %obj.getVelocity();

   %muzzleVelocity = VectorAdd(
      VectorScale(%muzzleVector, %projectile.muzzleVelocity),
      VectorScale(%objectVelocity, %projectile.velInheritFactor));

       %p = new (%data.projectileType)() {
         dataBlock        = RocketLauncherProjectile;
         initialVelocity  = %muzzleVelocity;
         initialDirection = %obj.getMuzzleVector(%slot);
         initialPosition  = %obj.getMuzzlePoint(%slot);
         sourceObject     = %obj;
         sourceSlot       = %slot;
      };

   if (isObject(%obj.lastProjectile) && %obj.deleteLastProjectile)
      %obj.lastProjectile.delete();

   %obj.lastProjectile = %p;
   %obj.deleteLastProjectile = %data.deleteLastProjectile;

   MissionCleanup.add(%p);

   return %p;
}
// [/HNT]

// <- phdana turrets

