  
      
      
    datablock FlyingVehicleData(flyingCar)     
    {     
       category = "Vehicles";           // category for the editor     
       shapeFile = "art/shapes/vehicles/flyingCar/cheetah/Cheetah_Body.DAE";  
       useEyePoint = true;  // Use the vehicle's camera node rather than the player's   
       mountPose[0]=sitting; 
       //useEyePoint = true;
       // Allowable weapon inventory items     
       // Just be aware that vehicles can have weapons ;)     
                
       // Explosion and debris setup     
       explosionDamage = 40;         // How much damage is applied through the radiusDamage function call     
       explosionRadius = 20;         // Radius for the radiusDamage function call     
       debrisShapeName = "art/shapes/vehicles/flyingCar/cheetah/Cheetah_Body.DAE";  // Debris shape (contains the explosion parts)     
       renderWhenDestroyed = false;  // don't render normal shape when destroyed, only debris shape     
               
       // Sounds     
           
       engineSound = "cheetahEngine";  
       
      //nameTag = 'flyingCar';
      
      //mountPose0 = "sitting";     
              
       // Object Impact Damage     
       collDamageThresholdVel = 10.0;     
       collDamageMultiplier   = 0.05;        
       minImpactSpeed = 0.5;         // If hit ground at speed above this then it's an impact. Meters / second     
       speedDamageScale = 0.5;         
               
       // Misc     
       computeCRC = true;     
       numMountPoints = 1;     
       // Damage/Energy     
       maxDamage = 1000.01;              // total damage until explosion     
       maxEnergy = 200;                   
       energyPerDamagePoint = 150;     
       destroyedLevel = 1000;     
       rechargeRate = 0.4;               
       softImpactSpeed = 2;          // This is a soft hit     
       hardImpactSpeed = 6;          // This is a hard hit   
       
         // Engine
      engineTorque = 4300;       // Engine power
      engineBrake = "50";         // Braking when throttle is 0
      brakeTorque = "5000";        // When brakes are applied
           // Engine scale by current speed / max speed

  

  
   
     
            
         
        
       // Velocities     
       softSplashSoundVelocity     = 10.0;     
       mediumSplashSoundVelocity   = 15.0;     
       hardSplashSoundVelocity     = 20.0;     
       exitSplashSoundVelocity     = 10.0;     
            
       // Emitter stuff     
       minTrailSpeed = 15;           // The speed at which contrail shows up at     
       forwardJetEmitter = SmokeEmitter;          
       backwardJetEmitter = SmokeEmitter;         
       downJetEmitter = FireEmitter;         
       splashEmitter = SmokeEmitter;   // water splash stuff     
       //dustEmitter = DustEmitter; // dust emitter when hovering over the ground     
       //triggerDustHeight = 8; // DONT THINK THIS WORKS??     
       dustHeight = 8;       
            
       // Damage emitters     
       damageEmitter[0]         ="SmokeEmitter" ;     
       damageEmitter[2]         = "FireEmitter";     
       damageEmitterOffset[0]   = "0 0 0";     
       damageLevelTolerance[0]  = 0.3;     
       damageLevelTolerance[1]  = 0.7;     
       numDmgEmitterAreas       = 3;       
        
       // camera     
       cameraRoll     = true;  // Roll the camera with the vehicle     
       cameraMaxDist  = 10;     // Far distance from vehicle     
       cameraOffset   = 1.5;   // Vertical offset from camera mount point     
       cameraLag      = 0.1;   // Velocity lag of camera     
       cameraDecay    = 0.75;  // Decay per sec. rate of velocity lag     
    // Physics -- following fields commented from several sources on forums, TDN, and FGE     
       drag    = 0.2;     
       density = 1.0;     
       minDrag = 50;                 // Linear Drag (eventually slows you down when not thrusting...constant drag)     
       rotationalDrag = 100;          // Anguler Drag (dampens the drift after you stop moving the mouse...also tumble drag)     
       maxAutoSpeed = 300;            // Autostabilizer kicks in when less than this speed. (meters / second)     
       autoAngularForce = 15;        // Angular stabilizer force (this force levels you out when autostabilizer kicks in)     
       autoLinearForce = 15;         // Linear stabilzer force (this slows you down when autostabilizer kicks in)     
       autoInputDamping = 0.95;      // Dampen control input so you don't` whack out at very slow speeds     
       maxSteeringAngle = 50;         // Max radiens you can rotate the wheel. Smaller number is more maneuverable.     
       horizontalSurfaceForce = 1000;  // Horizontal center "wing" (provides "bite" into the wind for climbing/diving and turning)     
       verticalSurfaceForce = 2000;   // Vertical center "wing" (controls side slip. lower numbers make MORE slide.)     
       maneuveringForce = 5000;      // Horizontal jets (W,S,D,A key thrust)     
       steeringForce = 5000;          // Steering jets (force applied when you move the mouse)     
       steeringRollForce = 0;        // Steering jets (how much you heel over when you turn) 8     
       rollForce = 200;               // Auto-roll (self-correction to right you after you roll/invert)     
       hoverHeight = 2;              // Height off the ground at rest     
       createHoverHeight = 2;        // Height off the ground when created     
       jetForce = 100;              // Afterburner thrust (this is in addition to normal thrust)     
       minJetEnergy = 0;            // Afterburner can't be used if below this threshhold.     
       jetEnergyDrain = 0;         // Energy use of the afterburners (lower number is less drain)          
       vertThrustMultiple = 10.0;     
       integration = 3;              // Physics integration: TickSec/Rate     
       collisionTol = 1;           // Collision distance tolerance     
       contactTol = .5;             // Contact velocity tolerance     
       mass = 50;                   // Mass of the vehicle     
       bodyFriction = 0;             // Don't change this.     
       bodyRestitution = 0.2;        // When you hit the ground, how much you rebound. (between 0 and 1)     
       minRollSpeed = 0;             // Don't change this.    
       damageEmitterOffset[1] = "8.40779e-044 9.80909e-044 6.9084e-043";  
       dustEmitter = "LiftoffDustEmitter";  
       exitingWater = "FootLightUnderwaterSound";  
       impactWaterEasy = "HeavyRainSound";  
       impactWaterMedium = "ThunderCrash2Sound";  
       impactWaterHard = "FootLightWadingSound";  
       waterWakeSound = "ThunderCrash3Sound";  
       cameraMinDist = "10";  
       aiAvoidThis = "0";  
       class = "balloon";  
       isInvincible = "0";  
       maxDismountSpeed = 100;  
       maxMountSpeed = 100;  
       shadowSize = "128";  
       observeThroughObject = "1";  
        
       maxInv[GrenadeLauncherAmmo] = 2000;  
       maxInvGrenadeLauncherAmmo = "2000";
       

         
      
      
    };    
    function flyingCar::onAdd(%data, %obj)  
    { //mount weapon on add  
       %obj.mountable=true;  
           
       // nothing for now...  
    }  
