datablock ParticleData(Volcano1)
{
   textureName          = "~/data/shapes/particles/volcano";
   dragCoefficient      = 0.0;
   gravityCoefficient   = 1;
   windCoefficient      = 0;
   inheritedVelFactor   = 0.00;
   lifetimeMS           = 5000;
   lifetimeVarianceMS   = 1000;
   useInvAlpha = false;

   colors[0]     = "1.0 0.0 0.0 1.0";
   colors[1]     = "1.0 0.5 0.0 1.0";

   sizes[0]      = 1.0;
   sizes[1]      = 1.0;

   times[0]      = 1.0;
   times[1]      = 1.0;
};

datablock ParticleData(Volcano2)
{
   textureName          = "~/data/shapes/particles/volcano";
   dragCoefficient      = 0.0;
   gravityCoefficient   = 1;
   windCoefficient      = 0;
   inheritedVelFactor   = 0.00;
   lifetimeMS           = 15000;
   lifetimeVarianceMS   = 1000;
   useInvAlpha = false;

   colors[0]     = "1.0 0.0 0.0 1.0";
   colors[1]     = "1.0 0.5 0.0 1.0";

   sizes[0]      = 1.0;
   sizes[1]      = 1.0;

   times[0]      = 1.0;
   times[1]      = 1.0;
};

datablock ParticleEmitterData(VolcanoEmitter1)
{
   ejectionPeriodMS = 2.5;
   periodVarianceMS = 3;

   ejectionVelocity = 40;
   velocityVariance = 0.30;

   thetaMin         = 0;
   thetaMax         = 45.0;
   
   phiRefrenceVel   = 0.0;
   phiVariance      = 360.0;

   particles = Volcano1;
};

datablock ParticleEmitterData(VolcanoEmitter2)
{
   ejectionPeriodMS = 2.5;
   periodVarianceMS = 3;

   ejectionVelocity = 80;
   velocityVariance = 0.30;

   thetaMin         = 0;
   thetaMax         = 10;

   phiRefrenceVel   = 0.0;
   phiVariance      = 360.0;

   particles = Volcano2;
};

datablock ParticleEmitterNodeData(VolcanoEmitterNode)
{
   timeMultiple = 1;
};
