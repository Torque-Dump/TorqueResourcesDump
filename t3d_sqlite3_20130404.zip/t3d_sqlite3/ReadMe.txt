Resource: SQLite 3 Implementing (Latest - No lib required)
Link:     http://www.garagegames.com/community/resources/view/22113
Authors:  John Vanderbeck (SQLiteObject), Kevin Mitchell
Date:     2013-01-13
Updated:  2013-04-04


Steps to use:
1) Open Torque 3D solution in Visual Studio and create a new filter under 
   DLL project in tree "Source Files/Engine" and name it "sqlite3" without
   the quotes.

2) Right-click on the newly created filter/folder "sqlite3" and then do
   Add -> Existing Item then select all files, this ReadMe.txt is optional,
   that are provided in this zip file and click OK to add the files to the
   project.

3) Build Torque 3D by clicking on Build menu -> Build solution. Or hit F7.

4) SQLite3 should now be usable via SQLiteObject in TorqueScript. Enjoy!

Note: View the original resource for the SQLiteObject from John Vanderbeck
to understand how to use the script object from the following link:
http://www.garagegames.com/community/resources/view/5531


	- Nathan Martin
	ReadMe.txt author.
