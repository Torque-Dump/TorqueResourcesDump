TgeLobby v1.0 - Readme file.
Created by Sean Pollock aka DarkRaven
www.darkravenstudios.com

Please read the documentation files located in /documentation very carefully before using TgeLobby.  If you have any questions after reading the docs and the source code then please let me know.

Thank you for downloading this and I hope to hear from you.