//-----------------------------------------------------------------------------
// GuiLobby and Game Browser AutoExec Code
// Programmed by Sean Pollock aka DarkRaven
// sean@darkravenstudios.com
//-----------------------------------------------------------------------------

exec("./tgelobby_vars.cs");
exec("./lobby_profiles.cs");
exec("./GuiLobby.gui");
exec("./GuiLogonDlg.gui");
exec("./CreateRoom_Dlg.gui");

exec("./GuiLobby.cs");
