

RPGDialog - NPC interaction system
http://www.garagegames.com/community/resources/view/3531