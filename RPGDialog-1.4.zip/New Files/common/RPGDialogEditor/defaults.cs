$RPGDialogEditorPref::ActionPath = "rw/data/dialogs/dla/";
$RPGDialogEditorPref::QuestionPath = "rw/data/dialogs/dlq/";
$RPGDialogEditorPref::PortraitsPath = "rw/data/dialogs/portraits/";
$RPGDialogEditorPref::mainMod="rw";
$RPGDialogEditorPref::MaxOptions = 100;
