$RPGDialogEditorPref::ActionPath = "starter.fps/data/dialogs/dla/";
$RPGDialogEditorPref::mainMod = "starter.fps";
$RPGDialogEditorPref::MaxOptions = 100;
$RPGDialogEditorPref::PortraitsPath = "starter.fps/data/dialogs/portraits/";
$RPGDialogEditorPref::QuestionPath = "starter.fps/data/dialogs/dlq/";
