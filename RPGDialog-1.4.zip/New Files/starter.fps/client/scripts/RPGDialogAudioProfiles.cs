new AudioDescription(DialogSound)
{
   volume   = 1.2;
   isLooping= false;
   is3D     = false;
   type     = $MessageAudioType;
};

new AudioProfile(test)
{
   filename = "~/data/dialogs/sounds/test.wav";
   description = "DialogSound";
   preload = false;
};

new AudioProfile(test2)
{
   filename = "~/data/dialogs/sounds/test2.wav";
   description = "DialogSound";
   preload = false;
};
