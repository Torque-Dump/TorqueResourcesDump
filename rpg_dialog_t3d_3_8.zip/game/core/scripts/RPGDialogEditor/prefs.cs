$RPGDialogEditorPref::ActionPath = "art/dialogs/dla/";
$RPGDialogEditorPref::mainMod = "art";
$RPGDialogEditorPref::MaxOptions = 100;
$RPGDialogEditorPref::PortraitsPath = "art/dialogs/portraits/";
$RPGDialogEditorPref::QuestionPath = "art/dialogs/dlq/";
