$RPGDialogEditorPref::ActionPath = "art/dialogs/dla/";
$RPGDialogEditorPref::QuestionPath = "art/dialogs/dlq/";
$RPGDialogEditorPref::PortraitsPath = "art/dialogs/portraits/";
$RPGDialogEditorPref::mainMod="art";
$RPGDialogEditorPref::MaxOptions = 100;
