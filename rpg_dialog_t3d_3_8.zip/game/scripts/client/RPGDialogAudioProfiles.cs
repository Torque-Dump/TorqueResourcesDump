new SFXDescription(DialogSound)
{
   volume   = 1.2;
   isLooping= false;
   is3D     = false;
   type     = $MessageAudioType;
};

new SFXProfile(test)
{
   filename = "art/dialogs/sounds/test.wav";
   description = "DialogSound";
   preload = false;
};

new SFXProfile(test2)
{
   filename = "art/dialogs/sounds/test2.wav";
   description = "DialogSound";
   preload = false;
};
